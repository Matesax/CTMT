"""New round-trip development battery. Synthetic records only; c=1 numerically."""
import json, math
from pathlib import Path
import numpy as np
from scipy.integrate import quad,solve_ivp
from scipy.optimize import least_squares
import sympy as s
OUT=Path('/mnt/data'); tests=[]
def check(name,ok,value=None):
 tests.append(dict(name=name,passed=bool(ok),value=value))
 if not ok: raise AssertionError((name,value))
def metric(r,p):
 m,g,q,b=p; A=1-2*m/r+q*(m/r)**2; H=1-2*g*m/r+b*(m/r)**2
 if A<=0 or H<=0: raise ValueError('outside static admitted domain')
 return math.sqrt(A),1/math.sqrt(H)
def radar(p,r0,r1):
 n0=metric(r0,p)[0]
 return 2*n0*quad(lambda r:metric(r,p)[1]/metric(r,p)[0],r0,r1,epsabs=1e-11,epsrel=1e-12)[0]
def angle(p,v,bimpact=40.):
 m,g,q,b=p; e=m/bimpact
 def fun(phi,z):
  u,w=z; A=1-2*e*u+q*e*e*u*u; H=1-2*g*e*u+b*e*e*u*u
  Q=(1/A-(1-v*v))/(v*v)-u*u
  Qp=(2*e-2*q*e*e*u)/(v*v*A*A)-2*u
  Hp=-2*g*e+2*b*e*e*u
  return [w,.5*(Qp*H+Q*Hp)]
 def stop(phi,z): return z[0]
 stop.direction=-1;stop.terminal=True
 sol=solve_ivp(fun,[0,15],[0,1],events=stop,rtol=2e-11,atol=2e-13,max_step=.025)
 if len(sol.t_events[0])!=1: raise ValueError('no escape')
 return float(sol.t_events[0][0]-math.pi)
# Four parameters need four records; do not pretend two angles + one timing identify four.
def records(p):
 return np.array([angle(p,.5),angle(p,.9),radar(p,10,30),metric(30,p)[0]/metric(10,p)[0]])
truths=[[1,1,0,0],[.8,.4,.3,.5],[1.2,1.3,-.2,.2]]
scales=np.array([.1,.1,40.,1.])
fits=[]
for truth in truths:
 target=records(truth)
 fit=least_squares(lambda p:(records(p)-target)/scales,[.95,.8,.1,.1],bounds=([.4,-.5,-2,-2],[1.6,2,2,2]),xtol=1e-12,ftol=1e-12,gtol=1e-12,diff_step=1e-4,max_nfev=100)
 err=float(np.max(np.abs((records(fit.x)-target)/scales)))
 check('finite-family forward inverse '+str(truth),fit.success and err<1e-8,err)
 check('parameter recovery '+str(truth),np.max(np.abs(fit.x-truth))<2e-4,float(np.max(np.abs(fit.x-truth))))
 held=[abs(angle(fit.x,.7)-angle(truth,.7)),abs(radar(fit.x,12,45)-radar(truth,12,45))]
 check('held-out third speed and radar '+str(truth),held[0]<1e-8 and held[1]<1e-6,held)
 sv=np.linalg.svd(fit.jac,compute_uv=False)
 check('four-record local rank '+str(truth),sv[-1]>1e-7,sv.tolist())
 fits.append(dict(truth=truth,recovered=fit.x.tolist(),scaled_record_error=err,held_out_errors=held,scaled_jacobian_singular_values=sv.tolist(),condition_number=float(sv[0]/sv[-1])))
# Previous two-angle collision, independently recomputed using orbit ODE.
p0=[1,1,0,0];pc=[1,1.0078727217683385,-.01030885838607218,.8]
da=[angle(pc,v)-angle(p0,v) for v in [.5,.9]]
dt=radar(pc,10,30)-radar(p0,10,30)
check('previous collision independently reproduced',max(map(abs,da))<2e-9,da)
check('radar breaks previous collision',abs(dt)>1e-4,dt)
# Function-level round trip, numerical derivatives of finite proper-time records.
function_errors=[]
for p in truths:
 r0=10.;n0=metric(r0,p)[0]
 for r in [15.,20.,25.]:
  h=1e-3
  tp=(radar(p,r0,r-2*h)-8*radar(p,r0,r-h)+8*radar(p,r0,r+h)-radar(p,r0,r+2*h))/(12*h)
  z=metric(r,p)[0]/n0
  Brec=.5*z*tp
  err=abs(Brec-metric(r,p)[1]);function_errors.append(err)
check('clock plus differential radar recovers B',max(function_errors)<2e-9,max(function_errors))
# Exact symbolic reconstruction, acceleration and curvature formulas.
r,c=s.symbols('r c',positive=True);z=s.Function('z')(r);T=s.Function('T')(r)
B=c*z*s.diff(T,r)/2;D=s.diff(T,r)
Kang=s.simplify((1-B**-2)/r**2)
Krad=s.simplify(s.diff(B,r)/(r*B**3))
check('angular curvature formula',s.simplify(Kang-(1-4/(c*c*z*z*D*D))/r**2)==0)
check('radial curvature formula',s.simplify(Krad-4*(s.diff(z,r)/z+s.diff(T,r,2)/D)/(c*c*r*z*z*D*D))==0)
acc=s.simplify(c*c*s.diff(z,r)/(z*B))
check('support acceleration formula',s.simplify(acc-2*c*s.diff(z,r)/(z*z*D))==0)
# Flat-space exact round trip and proper-time factor mutation.
check('flat-space radar',abs(radar([0,0,0,0],10,30)-40)<1e-12)
p=truths[0];r0=10.;r1=20.;h=1e-3
slope=(radar(p,r0,r1+h)-radar(p,r0,r1-h))/(2*h)
wrong=.5*metric(r1,p)[0]*slope
check('missing emitter normalization canary',abs(wrong-metric(r1,p)[1])>1e-3)
# Exact finite-radar collision with unchanged clocks: delta(B/N) has zero integral.
R,L,k=s.symbols('R L k',positive=True);x=s.symbols('x',real=True)
f=(x-R)*(L-x)*(x-(R+L)/2)
check('finite endpoint radar nullspace',s.simplify(s.integrate(f,(x,R,L)))==0)
check('nullspace changes local slope',s.simplify(f.subs(x,R+(L-R)/4))!=0)
# Second derivatives amplify high-frequency timing perturbations.
n=s.symbols('n',positive=True);pert=s.sin(n*x)/n**s.Rational(3,2)
check('timing derivative instability canary',s.simplify(s.diff(pert,x,2).subs(x,s.pi/(2*n)))==-s.sqrt(n))
result=dict(scope='Synthetic static spherical development battery, not empirical validation',passed=sum(t['passed'] for t in tests),total=len(tests),tests=tests,fits=fits,previous_collision=dict(angle_differences=da,proper_radar_difference=dt),max_function_B_error=max(function_errors),limitations=['Four-parameter fits are numerical local recoveries, not global uniqueness','Function-level theorem requires anchored areal radius and ideal clock/radar functions','Finite data require regularity, error bounds, and conditioning','No stress or field equation is derived'])
(OUT/'rg_roundtrip_results.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
