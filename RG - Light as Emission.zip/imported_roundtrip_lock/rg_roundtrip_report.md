# RG round-trip formula lock

## Scope and provenance
New synthetic development battery: 23/23 assertions passed. Three static spherical four-parameter geometries were forward-modelled, inverted from four records, and used to predict a third-speed deflection and a second radar interval. This is same-model numerical recovery, not empirical validation, independent blind validation, exhaustive search, or global uniqueness. One initial symbolic assertion compared an unsimplified integral directly with zero; adding symbolic simplification fixed that assertion without changing the mathematical test or tolerance.

The earlier hostile harness was not present in the execution directory. This turn constructed a new harness from the explicitly stated metric family and independently reproduced the earlier two-speed collision by orbit ODE.

## Exact conditional reconstruction theorem
Assume a static spherical admitted region, N,B>0, calibrated areal radius r and c, static clocks and mirrors, metric null propagation, and zero or calibrated reflection delay. Let r>=r0, N0=N(r0), and define z(r)=N(r)/N0 as a clock-rate ratio, not conventional redshift minus one. Let T(r) be the elapsed proper time on the emitter clock at r0 for an out-and-back radial light signal reflected at r.

    T(r) = (2 N0/c) integral_[r0,r] B(s)/N(s) ds
         = (2/c) integral_[r0,r] B(s)/z(s) ds.

Thus:

    B(r) = (c/2) z(r) T'(r).

With t0=N0 t, the reconstructed metric is:

    ds^2 = -z(r)^2 c^2 dt0^2 + [(c/2) z(r) T'(r)]^2 dr^2 + r^2 dOmega^2.

Proof of round trip: differentiation recovers B from forward records. Conversely, substituting B=(c/2)zT' in the forward timing integral recovers T(r)-T(r0); T(r0)=0 fixes the integration constant. Equal ideal functions z,T therefore identify the metric in this declared chart and clock normalization. Absolute N0 is a time-coordinate normalization, not needed for B. An independent radius/length anchor remains essential.

This is a proper-time, finite-radar-record formulation of the clock/null-slope reconstruction already present in RG_Gravitation_Computation. It is not claimed as new gravitational dynamics.

## Curvature and response directly from records
Write P=T', with derivatives taken with respect to calibrated areal radius. The angular spatial sectional curvature and radial spatial sectional curvature are:

    K_angular = [1-4/(c^2 z^2 P^2)]/r^2,
    K_radial  = 4 [z'/z + T''/T']/(c^2 r z^2 P^2).

The latter equals the Gaussian curvature of an equatorial spatial plane. These are spatial curvatures, not the full spacetime Riemann tensor. Full spacetime curvature is determined by the reconstructed metric under Levi-Civita coupling with adequate derivative control; it also includes lapse-dependent components.

The signed outward support acceleration is:

    a_support = c^2 z'/(z B) = 2c z'/(z^2 T').

This supplies an independent accelerometer prediction if accelerometer data were not used to infer z or T.

On the simple asymptotic scattering domain of the earlier decomposition:

    AS = integral_path [1-2/(c z T')] dphi.

The path must be independently observed or predicted by the reconstructed metric; this is not a formula extracting AS from two angles alone. The data must cover the path and required exterior domain, or the exterior must be separately declared.

## Numerical results
Previous collision: two angle differences are 1.07e-14 and 1.28e-13 rad, while the emitter proper radar time from r0=10 to r=30 differs by -0.04537429373205981 in c=G=1 units.

Four fitted parameters are (m,gamma,q,beta), with N^2=1-2m/r+q(m/r)^2 and B^-2=1-2gamma m/r+beta(m/r)^2. Beta is not standard PPN beta. Fitted records: deflections at speeds 0.5 and 0.9 with impact parameter 40, one proper radar interval [10,30], and one clock ratio N(30)/N(10). Held-out records: speed 0.7 deflection and radar interval [12,45].

All three parameter sets were recovered to better than 5.2e-10 maximum absolute component error. Largest held-out angle error was 7.55e-14 rad; largest held-out radar error was 1.95e-12 numerical time units. Finite-difference reconstruction of B from timing records had maximum error 3.29e-12.

The scaled numerical Jacobian condition numbers were approximately 745, 4539, and 2225. These depend on the explicit record and parameter scaling; they are not uncertainty estimates. Exact-data recovery therefore does not establish practical robustness.

Secondary independent checks: Schwarzschild radar quadrature agrees with its closed logarithmic expression to below 1e-12; analytic timing differentiation recovers B; angular curvature agrees with 2m/r^3 at tested radii. These secondary checks are additional to the 23 assertions in the saved harness.

## Canary boundaries
- Flat-space timing recovers B=1.
- Omitting emitter normalization while using absolute N produces a detected error.
- One finite radar interval leaves an exact nullspace: a small perturbation of B/N proportional to (r-r0)(R-r)(r-(r0+R)/2) integrates to zero while changing local geometry.
- Small timing errors do not guarantee curvature control: sin(nr)/n^(3/2) has vanishing amplitude and first derivative but unbounded second derivative.
- Two angles plus one timing do not identify four free parameters. The clock ratio is a fourth independent record; numerical local rank was checked.

## Lock boundary
Locked conditionally: exact function-level metric reconstruction from anchored clock ratios and differential proper radar time, with a two-sided forward/inverse identity. Numerically supported: local recovery and held-out synthetic prediction in the declared finite family. Not locked: arbitrary-function reconstruction from finitely many records, practical noisy-data curvature certification, universal two-speed discrimination, stress identification, or a gravitational source law.
