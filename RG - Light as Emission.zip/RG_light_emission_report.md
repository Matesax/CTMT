# RG light as emission: lock report

**Projection formula (locked).** The received field is the sum of the free propagation of all emitters:
the sources, plus the induced currents J_ind = X(G J_src + G J_ind), which are solved self-consistently.
There is no bounce term. Reflection, refraction and extinction are all emission.

**Exact reductions.**

| ID | Reduction | Witness |
|---|---|---|
| L01 | Perfect-conductor sheet: in front, the emission is the reflected wave; behind, it cancels the incident wave | sympy |
| L02 | Planar mirror = CP image: E_r(x) = −R E_i(Rx), B_r(x) = R B_i(Rx) | sympy, TE/TM oblique |
| L03 | The image is a quotient point; only a probe behind the surface separates "mirror" from "image emitter" | 400 dipoles, machine zero |
| L04 | Ewald–Oseen: emission alone reproduces the Airy slab values and extinguishes the vacuum wave | order-2 convergence, 1e-6 |
| L05 | A mirror reverses front–back only; "left–right" depends on the comparison rotation; chirality and helicity are invariant | exact |
| L06 | Planet as a convex mirror: the image lies inside the planet, at depth R/2; your own image at sR/(R+2s) | ray trace |
| L07 | Moving mirror = Lorentz-reflected image (Einstein 1905); your own image approaching at β is shifted by (1+β)/(1−β) | sympy |
| L08 | Any 1+1 mirror worldline: g = −f∘p, Doppler p′; a uniformly accelerated mirror's image freezes at a horizon | sympy |
| L09 | Static gravity: radar = emission plus reception; B = (c/2) z T′; your own image in a static mirror is never shifted | sympy and quadrature |
| L10 | Penetration depth λ/(4πκ): light does not physically cut through planets | — |
| L11 | Boundary: quantum vacuum emission is −{p,v}/24π of the same classical map p (imported) | sympy |

**RG typing.**
- Bounce, image and emission form one correspondence for far-field data.
- Emission is locked by protocols that probe the reflector itself: extinction, material dependence,
  penetration depth, and mirror motion.
- The image is real at the level of the quotient and fictitious as a latent location.

**Gaps of current physics.**
- None in the physics of the mirror.
- The gap is descriptive: the three readings are used interchangeably.
- Open items at the edges: photon localization, momentum of light in media (two modules), and vacuum
  emission (quantum).

**Battery.**
- 11 attacks: 10 locked, 1 boundary.
- 7 canaries, all rejected by computed criteria. Master seed 20261025.
- Reruns are identical.
- The round-trip lock (23/23) is imported.

**Limits.**
- Synthetic data only.
- The Ewald–Oseen check is one-dimensional, at normal incidence.
- Ideal geometric optics for the planet.
- Quantum statements are imported, not computed.
