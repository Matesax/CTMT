"""RG light as emission: hostile lock battery.
Claim attacked: received light is a projection of EMISSION events (sources plus self-consistently induced
re-emitters); a 'bounce' is the stationary-phase shorthand; a mirror image is an equality-of-law quotient point;
the image carries the observer's CP-transformed, Doppler-shifted, delayed field; static gravity enters only
through the optical metric.  Synthetic / analytic fixtures, c = 1 unless stated.
Run: python rg_light_attacks.py --out DIR    (numpy, scipy, sympy)
"""
import argparse, hashlib, json, math, pathlib, platform, sys, time
import numpy as np, sympy as sp
from scipy.integrate import quad

MASTER_SEED = 20261025
RES, CAN = [], []


def must(c, m):
    if not c:
        raise AssertionError(m)


def rec(i, claim, status, witness, details=None):
    RES.append(dict(id=i, claim=claim, status=status, witness=witness, details=details or {}))


def can(statement, rejected, witness):
    """rejected must be a COMPUTED boolean (the evidence that refutes the statement)."""
    must(bool(rejected), "canary accepted: " + statement)
    CAN.append(dict(statement=statement, accepted=False, witness=witness))


R = np.diag([1.0, 1.0, -1.0])        # reflection through the plane z = 0


# ============================================================ L01 sheet emission and extinction
def L01():
    z, k, E0, Z0 = sp.symbols("z k E0 Z0", positive=True)
    Einc = E0 * sp.exp(-sp.I * k * z)                    # x-polarized, travelling toward -z, conductor at z<0
    Hinc = -E0 / Z0 * sp.exp(-sp.I * k * z)              # y-component
    K = -2 * Hinc.subs(z, 0)                             # K = z_hat x (2 H_inc) -> x-component = -2*H_y
    sheet = lambda zz: -(Z0 / 2) * K * sp.exp(sp.I * k * sp.Abs(zz))
    inside = sp.simplify(Einc.subs(z, -z) + sheet(-z))   # evaluate at -z (z>0 symbol) i.e. behind the surface
    outside = sp.simplify(sheet(z) - (-E0 * sp.exp(sp.I * k * z)))
    must(inside == 0 and outside == 0, "sheet emission")
    rec("L01", "Reflection is emission: the induced surface current radiates the reflected wave in front and "
        "exactly cancels the incident wave behind the surface (extinction)", "LOCKED",
        "sympy, PEC normal incidence: K = 2 n x H_inc radiates -(Z0/2)K e^{ik|z|}; behind: E_inc + E_sheet = 0 "
        "identically; in front: E_sheet = the reflected wave -E0 e^{ikz}. No bounce term exists.")


# ============================================================ L02 CP-image theorem (symbolic, oblique, both polarizations)
def L02():
    x, y, z, t = sp.symbols("x y z t", real=True)
    kx, kz = sp.symbols("k_x k_z", positive=True)
    w = sp.sqrt(kx ** 2 + kz ** 2)
    kv = sp.Matrix([kx, 0, kz])
    out = {}
    for pol, E0 in (("TE", sp.Matrix([0, 1, 0])), ("TM", sp.Matrix([kz, 0, -kx]) / w)):
        ph = sp.exp(sp.I * (kx * x + kz * z - w * t))
        Ein = E0 * ph
        Bin = kv.cross(E0) / w * ph
        Rm = sp.diag(1, 1, -1)
        sub = {z: -z}
        Eim = -Rm * Ein.subs(sub)                          # charge conjugation x parity
        Bim = Rm * Bin.subs(sub)
        X = (x, y, z)
        curl = lambda F: sp.Matrix([sp.diff(F[2], X[1]) - sp.diff(F[1], X[2]),
                                    sp.diff(F[0], X[2]) - sp.diff(F[2], X[0]),
                                    sp.diff(F[1], X[0]) - sp.diff(F[0], X[1])])
        div = lambda F: sum(sp.diff(F[i], X[i]) for i in range(3))
        maxwell = [sp.simplify(e) for e in list(curl(Eim) + sp.diff(Bim, t)) + list(curl(Bim) - sp.diff(Eim, t))
                   + [div(Eim), div(Bim)]]
        Et = (Ein + Eim).subs(z, 0); Bt = (Bin + Bim).subs(z, 0)
        bc = [sp.simplify(Et[0]), sp.simplify(Et[1]), sp.simplify(Bt[2])]
        out[pol] = all(m == 0 for m in maxwell) and all(b == 0 for b in bc)
    must(all(out.values()), "CP image")
    rec("L02", "Planar mirror = CP map: E_r(x) = -R E_i(Rx), B_r(x) = R B_i(Rx) solves Maxwell and the PEC "
        "boundary conditions exactly", "LOCKED",
        "sympy, oblique plane waves, TE and TM: the CP image satisfies all eight Maxwell equations and "
        "E_tan = 0, B_n = 0 on the mirror. By uniqueness it IS the reflected field.", out)


# ============================================================ L03 dipole near a mirror; quotient and its breaking
def dipole_E(p, x0, X, k=1.0):
    """Complex E of an oscillating electric dipole (Gaussian-like units, e^{-iwt}, c=1)."""
    rv = X - x0; r = np.linalg.norm(rv); n = rv / r
    e = np.exp(1j * k * r)
    return (k * k * np.cross(np.cross(n, p), n) * e / r
            + (3 * n * (n @ p) - p) * (1 / r ** 3 - 1j * k / r ** 2) * e)


def dipole_B(p, x0, X, k=1.0):
    rv = X - x0; r = np.linalg.norm(rv); n = rv / r
    return k * k * np.cross(n, p) * np.exp(1j * k * r) / r * (1 - 1 / (1j * k * r))


def L03():
    rng = np.random.default_rng(MASTER_SEED + 3)
    worst_t = worst_n = 0.0; behind_A = behind_B = 0.0
    for _ in range(20):
        p = rng.standard_normal(3) + 1j * rng.standard_normal(3)
        x0 = np.r_[rng.uniform(-2, 2, 2), rng.uniform(0.3, 3)]
        pim = -R @ p; xim = R @ x0
        for _ in range(20):
            X = np.r_[rng.uniform(-5, 5, 2), 0.0]
            E = dipole_E(p, x0, X) + dipole_E(pim, xim, X)
            B = dipole_B(p, x0, X) + dipole_B(pim, xim, X)
            sc = np.linalg.norm(dipole_E(p, x0, X)) + 1e-30
            worst_t = max(worst_t, np.linalg.norm(E[:2]) / sc)
            worst_n = max(worst_n, abs(B[2]) / (np.linalg.norm(dipole_B(p, x0, X)) + 1e-30))
            Xb = np.r_[X[:2], -rng.uniform(0.5, 3)]
            behind_B = max(behind_B, np.linalg.norm(dipole_E(p, x0, Xb) + dipole_E(pim, xim, Xb)))
    must(worst_t < 1e-12 and worst_n < 1e-12 and behind_B > 1e-2, "dipole image")
    rec("L03", "The mirror image is an equality-of-law quotient point: on the observer half-space, "
        "{source + mirror} and {source + CP-image emitter, no mirror} have identical fields; only a protocol "
        "behind the surface separates them", "LOCKED",
        f"400 random dipoles/plane points (full near+far field): tangential E residual {worst_t:.1e}, normal B "
        f"{worst_n:.1e} (relative; machine zero, exact symmetry). Behind the plane, configuration A has field 0 (extinction, L01) while the "
        f"free-space image configuration has |E| up to {behind_B:.2f}: the fibre is broken only by looking "
        f"'through' the mirror.", dict(behind_free_image=behind_B))
    inside_zero = (np.linalg.norm(dipole_E(p, x0, Xb) + dipole_E(pim, xim, Xb)) > 1e-3)  # free image is nonzero there
    can("light from the image really passes through the mirror", inside_zero,
        "behind a perfect mirror the total field is exactly zero (L01); the image is a quotient point, not a "
        "latent source location")


# ============================================================ L04 Ewald-Oseen: dielectric reflection from emission only
def slab_emission(chi, kd, Npts, k=1.0):
    d = kd / k
    zs = np.linspace(0, d, Npts); h = zs[1] - zs[0]
    wts = np.full(Npts, h); wts[0] = wts[-1] = h / 2
    Kmat = (1j * k * chi / 2) * np.exp(1j * k * np.abs(zs[:, None] - zs[None, :])) * wts[None, :]
    E = np.linalg.solve(np.eye(Npts) - Kmat, np.exp(1j * k * zs))
    r = (1j * k * chi / 2) * np.sum(wts * np.exp(1j * k * zs) * E)
    tco = 1 + (1j * k * chi / 2) * np.sum(wts * np.exp(-1j * k * zs) * E)
    return r, tco, zs, E


def slab_exact(chi, kd):
    n = np.sqrt(1 + chi + 0j); r12 = (1 - n) / (1 + n); ph = np.exp(2j * n * kd)
    r = r12 * (1 - ph) / (1 - r12 ** 2 * ph)
    t = (4 * n / (1 + n) ** 2) * np.exp(1j * (n - 1) * kd) / (1 - r12 ** 2 * ph)
    return r, t, n


def L04():
    out = {}
    for label, chi in (("glass n=1.5", 1.25), ("absorbing", 1.25 + 0.4j)):
        kd = 3.7
        rex, tex, n = slab_exact(chi, kd)
        errs = []
        for N in (400, 800, 1600):
            r, tc, zs, E = slab_emission(chi, kd, N)
            errs.append(max(abs(r - rex), abs(tc - tex)))
        order = math.log2(errs[1] / errs[2])
        # extinction: inside, the field is a combination of e^{+-i n k z}; the vacuum wave e^{ikz} is absent
        sel = (zs > 0.3) & (zs < kd - 0.3)
        M = np.vstack([np.exp(1j * n * zs[sel]), np.exp(-1j * n * zs[sel]), np.exp(1j * zs[sel])]).T
        coef, *_ = np.linalg.lstsq(M, E[sel], rcond=None)
        born = (1j * chi / 2) * (np.exp(2j * kd) - 1) / (2j)
        out[label] = dict(err_r_t=errs, order=order, vacuum_wave_coeff=abs(coef[2]),
                          medium_coeffs=[abs(coef[0]), abs(coef[1])], r_exact=abs(rex), born_error=abs(born - rex))
    must(all(o["err_r_t"][-1] < 1e-5 and 1.8 < o["order"] < 2.2 and o["vacuum_wave_coeff"] < 1e-4
             and o["born_error"] > 1e-2 for o in out.values()), "Ewald-Oseen")
    rec("L04", "Ewald-Oseen: a medium made only of self-consistent emitters reproduces Fresnel/Airy reflection and "
        "transmission, and extinguishes the incident vacuum wave inside", "LOCKED",
        "1D self-consistent emission (Nystrom, Green's function e^{ik|z-z'|}) for a glass slab and an absorbing "
        "slab: |r - r_Airy|, |t - t_Airy| -> " + ", ".join(f"{o['err_r_t'][-1]:.1e}" for o in out.values())
        + " with convergence order " + ", ".join(f"{o['order']:.2f}" for o in out.values())
        + "; the vacuum wave e^{ikz} has coefficient " + ", ".join(f"{o['vacuum_wave_coeff']:.0e}" for o in out.values())
        + " inside (extinguished); only e^{+-inkz} survive.", out)
    can("single-pass (non-self-consistent) emission gives the reflection coefficient",
        all(o["born_error"] > 1e-2 for o in out.values()),
        "first Born approximation misses the Airy value by " + ", ".join(f"{o['born_error']:.3f}" for o in out.values()))


# ============================================================ L05 mirror logic: what is reversed, helicity
def L05():
    MFB = sp.diag(1, 1, -1); MLR = sp.diag(-1, 1, 1); MUD = sp.diag(1, -1, 1)
    Ry = sp.diag(-1, 1, -1); Rx = sp.diag(1, -1, -1)       # rotations by pi about vertical / horizontal axes
    must(Ry * MLR == MFB and Rx * MUD == MFB and Ry.det() == 1 and Rx.det() == 1 and MFB.det() == -1, "mirror")
    e = np.array([1, 1j, 0]) / math.sqrt(2)
    hel = lambda E, kh: float(np.imag(np.cross(np.conj(E), E)) @ kh)
    h_in = hel(e, np.array([0, 0, 1.0]))
    Er = -(np.diag([1, 1, -1]) @ e)                          # CP image amplitude at normal incidence
    h_out = hel(Er, np.array([0, 0, -1.0]))
    must(h_in > 0 and h_out < 0, "helicity flip")
    rec("L05", "Logic of the mirror: it reverses front-back (along the normal) only; 'left-right' is a "
        "choice-dependent attribution; the invariant is chirality (det = -1), and photon helicity flips", "LOCKED",
        "Exact: M_FB = Rot_pi(vertical) M_LR = Rot_pi(horizontal) M_UD, so the same image is 'left-right "
        "reversed' or 'upside-down' depending on which rotation one compares with. Only det = -1 is invariant. "
        f"Circular light: helicity {h_in:+.0f} in, {h_out:+.0f} out.")
    can("a mirror intrinsically swaps left and right", (Rx * MUD == MFB) and (Ry * MLR == MFB) and MLR != MUD,
        "the same reflection factors as (vertical rotation) x (left-right) and as (horizontal rotation) x (up-down)")
    can("reflection preserves photon helicity", h_out * h_in < 0, f"helicity {h_in:+.0f} -> {h_out:+.0f}")


# ============================================================ L06 planet as convex mirror: the image lies inside
def reflect_sphere(P, d, Rs=1.0):
    b = P @ d; c = P @ P - Rs * Rs
    disc = b * b - c
    tt = -b - math.sqrt(disc)
    X = P + tt * d; nrm = X / Rs
    dr = d - 2 * (d @ nrm) * nrm
    return X, dr


def axis_cross(X, dr):
    """back-extend the reflected ray and intersect with the x = 0 axis (meridional plane)."""
    s = -X[0] / dr[0]
    return X[2] + s * dr[2]


def L06():
    Rs = 1.0; out = {}
    zs = [axis_cross(*reflect_sphere(np.array([h, 0, 5.0]), np.array([0, 0, -1.0]), Rs)) for h in (1e-4, 1e-3)]
    depth_inf = Rs - zs[0]
    out["distant source image depth"] = depth_inf
    for s in (0.5, 2.0, 10.0):
        P = np.array([0, 0, Rs + s]); h = 1e-4
        dvec = np.array([h, 0, -(s)]); dvec /= np.linalg.norm(dvec)
        X, dr = reflect_sphere(P, dvec, Rs)
        depth = Rs - axis_cross(X, dr)
        out[f"observer at s={s}"] = dict(depth=depth, predicted=s * Rs / (Rs + 2 * s), magnification=Rs / (Rs + 2 * s))
    ab = Rs - axis_cross(*reflect_sphere(np.array([0.5, 0, 5.0]), np.array([0, 0, -1.0]), Rs))
    out["non-paraxial h=0.5 depth"] = ab
    must(abs(depth_inf - Rs / 2) < 1e-6 and all(abs(v["depth"] - v["predicted"]) < 1e-6
         for k, v in out.items() if k.startswith("observer")) and ab < Rs / 2, "convex mirror")
    rec("L06", "A planet as a convex mirror: re-projection places the image INSIDE the planet - depth R/2 for "
        "distant sources, sR/(R+2s) for an observer at height s, magnification R/(R+2s)", "LOCKED",
        f"Exact ray trace on a sphere: paraxial depth {depth_inf:.8f} R (distant source); observer images match "
        f"sR/(R+2s) to 1e-6; at aperture 0.5 R the depth is {ab:.4f} R (spherical aberration; caustic). The line "
        f"of sight 'cuts through' the planet to a virtual point, while the field there is zero.", out)
    can("the virtual image of a distant source sits at the planet's centre", abs(depth_inf - Rs) > 0.1, f"depth {depth_inf:.4f} R, not 1 R")


# ============================================================ L07 moving mirror: Lorentz-reflected image
def L07():
    b, th = sp.symbols("beta theta", real=True)
    g = 1 / sp.sqrt(1 - b ** 2)
    L = lambda bb: sp.Matrix([[1 / sp.sqrt(1 - bb ** 2), 0, -bb / sp.sqrt(1 - bb ** 2)], [0, 1, 0],
                              [-bb / sp.sqrt(1 - bb ** 2), 0, 1 / sp.sqrt(1 - bb ** 2)]])   # (t, x_parallel, z)
    k = sp.Matrix([1, sp.sin(th), sp.cos(th)])                  # incident (omega=1) toward +z; mirror moves +z
    km = L(b) * k; km[2] = -km[2]; kr = L(-b) * km
    nu = sp.simplify(kr[0]); cos_r = sp.simplify(kr[2] / kr[0])
    nu_E = (1 - 2 * b * sp.cos(th) + b ** 2) / (1 - b ** 2)
    cos_E = -((1 + b ** 2) * sp.cos(th) - 2 * b) / (1 - 2 * b * sp.cos(th) + b ** 2)
    must(sp.simplify(nu - nu_E) == 0 and sp.simplify(cos_r - cos_E) == 0, "Einstein moving mirror")
    normal = sp.simplify(nu.subs(th, 0)); own = sp.simplify(normal.subs(b, -b))
    must(sp.simplify(normal - (1 - b) / (1 + b)) == 0 and sp.simplify(own - (1 + b) / (1 - b)) == 0, "doppler")
    gal = 1 - 2 * b
    diff = sp.series(normal - gal, b, 0, 3).removeO()
    must(sp.simplify(diff - 2 * b ** 2) == 0, "galilean differs at beta^2")
    rec("L07", "Moving mirror = Lorentz-reflected image: reflect the wave 4-vector in the mirror rest frame and boost "
        "back; this reproduces Einstein's 1905 formulas exactly", "LOCKED",
        "sympy: frequency (1 - 2 beta cos theta + beta^2)/(1 - beta^2) and reflection angle identical to Einstein's. "
        "Normal incidence: receding mirror (1-beta)/(1+beta); your own image while you approach a mirror at beta: "
        "(1+beta)/(1-beta).")
    can("the Galilean double shift 1 - 2 beta is exact", sp.simplify(diff) != 0, "differs from (1-beta)/(1+beta) by 2 beta^2 + O(beta^3)")


# ============================================================ L08 accelerated mirror: exact 1+1 projection
def L08():
    t, a, v, bt = sp.symbols("t a v beta", positive=True)
    zt = sp.sqrt(a ** 2 + t ** 2) - a                            # hyperbolic (uniformly accelerated) mirror
    tv = ((v + a) ** 2 - a ** 2) / (2 * (v + a))                 # solves t + z(t) = v
    root = v + a - tv                                            # sqrt(a^2 + tv^2) on the branch root > 0
    must(sp.simplify(root ** 2 - (a ** 2 + tv ** 2)) == 0 and sp.simplify(root - (v * v + 2 * a * v + 2 * a * a) / (2 * (v + a))) == 0,
         "inverse")
    p = sp.simplify(tv - (root - a))
    zdot = tv / root                                             # dz/dt = t / sqrt(a^2 + t^2) at t = t(v)
    dop = sp.simplify(sp.diff(p, v) - (1 - zdot) / (1 + zdot))
    must(dop == 0, "instantaneous doppler")
    import random
    rnd = random.Random(MASTER_SEED)
    for _ in range(20):                                          # numeric cross-check of the branch
        av, vv = rnd.uniform(0.1, 3), rnd.uniform(0.01, 10)
        tn = float(tv.subs({a: av, v: vv}))
        must(abs(tn + math.sqrt(av * av + tn * tn) - av - vv) < 1e-12, "branch")
    pu = sp.simplify((v / (1 + bt)) * (1 - bt))                  # uniform z = beta t
    rec("L08", "Exact projection for any mirror worldline (1+1, perfect mirror): reflected wave g(v) = -f(p(v)) with "
        "p(v) = t(v) - z(t(v)), t + z(t) = v; local Doppler (1 - zdot)/(1 + zdot) at the emission event", "LOCKED",
        f"sympy, hyperbolic mirror z = sqrt(a^2+t^2) - a: p(v) = {p}; dp/dv equals (1 - zdot)/(1 + zdot) exactly. "
        "Uniform motion gives p = v(1-beta)/(1+beta), the L07 factor. The mirror re-emits the incident wave "
        "re-projected along its own null map (Moore 1970).", dict(p=str(p)))


# ============================================================ L09 static gravity: radar as emission/reception
def L09():
    r, r0, m, c = sp.symbols("r r_0 m c", positive=True)
    N = sp.sqrt(1 - 2 * m / r); N0 = N.subs(r, r0)
    T_closed = 2 * N0 * ((r - r0) + 2 * m * sp.log((r - 2 * m) / (r0 - 2 * m)))
    must(sp.simplify(sp.diff(T_closed, r) - 2 * N0 * (1 / N) / N) == 0, "Schwarzschild radar")
    num = 2 * math.sqrt(1 - 2 / 10) * quad(lambda x: 1 / (1 - 2 / x), 10, 30, epsabs=1e-14)[0]
    cl = float(T_closed.subs({m: 1, r0: 10, r: 30}))
    zf, Tf = sp.Function("z")(r), sp.Function("T")(r)
    Bfun = sp.Function("B")(r); Nf = sp.Function("N")(r)
    Tprime = 2 * N0 * Bfun / Nf
    must(sp.simplify((sp.Rational(1, 2) * (Nf / N0) * Tprime) - Bfun) == 0, "B = z T'/2")
    # own image in a static mirror: Killing frequency conserved -> local ratio exactly 1
    nu0, Nm = sp.symbols("nu_0 N_m", positive=True)
    omega = N0 * nu0; nu_mirror = omega / Nm; back = nu_mirror * Nm / N0
    must(sp.simplify(back - nu0) == 0, "own image unshifted")
    proper = quad(lambda x: 1 / math.sqrt(1 - 2 / x), 10, 30)[0]
    radar_len = num / (2 * math.sqrt(1 - 2 / 10))                      # coordinate optical length
    emitter_dist = num / 2                                              # c T / 2 in emitter proper time
    must(abs(num - cl) < 1e-10 and abs(emitter_dist - proper) > 0.5, "radar vs proper")
    rec("L09", "Static gravity: the echo is emission at the reflector; delay = optical length int B/N dr; "
        "B = (c/2) z T' (round-trip lock); your own image in a static mirror is never frequency-shifted", "LOCKED",
        f"Schwarzschild closed form T = 2N0[(r - r0) + 2m ln((r-2m)/(r0-2m))] matches quadrature ({abs(num - cl):.0e}); "
        f"B = (1/2) z T' symbolically; Killing-frequency conservation gives own-image ratio exactly 1. From r0=10m to "
        f"30m: proper distance {proper:.4f}, radar half-delay {emitter_dist:.4f}, optical length {radar_len:.4f}.",
        dict(proper=proper, radar_half=emitter_dist, optical=radar_len))
    can("radar distance equals proper distance in a gravitational field", abs(emitter_dist - proper) > 0.5,
        f"{emitter_dist:.4f} vs {proper:.4f} (m units)")


# ============================================================ L10 penetration: how far light 'cuts in'
def L10():
    kap, k, zz = sp.symbols("kappa k z", positive=True)
    np_ = sp.symbols("n_r", positive=True)
    field = sp.exp(sp.I * (np_ + sp.I * kap) * k * zz)
    I = sp.simplify(sp.Abs(field) ** 2)
    depth = sp.simplify(1 / (2 * kap * k))
    must(sp.simplify(I - sp.exp(-2 * kap * k * zz)) == 0, "decay")
    lam, Rp = 500e-9, 6.371e6
    log10T = -Rp / float(depth.subs({kap: 1, k: 2 * math.pi / lam})) / math.log(10)
    rec("L10", "Penetration is finite and exponential: intensity depth lambda/(4 pi kappa); light does not "
        "physically cut through a planet", "LOCKED",
        f"For kappa = 1 at 500 nm the intensity depth is {lam / (4 * math.pi):.1e} m; transmission through an Earth "
        f"radius is 10^({log10T:.2e}). What 'cuts through' is only the virtual line of sight of L06.")


# ============================================================ L11 the classical map p is the input of quantum vacuum emission
def L11():
    v, a = sp.symbols("v a", positive=True)
    schw = lambda f: sp.simplify(sp.diff(f, v, 3) / sp.diff(f, v) - sp.Rational(3, 2) * (sp.diff(f, v, 2) / sp.diff(f, v)) ** 2)
    p_hyp = a * v / (a + v)
    p_gen = v - sp.Rational(1, 2) * sp.tanh(v)
    S_hyp = schw(p_hyp); S_gen = schw(p_gen)
    vals = [float(S_gen.subs(v, x)) for x in (0.3, 0.8, 1.5)]
    pd = sp.diff(p_gen, v)
    subluminal = all(0 < float(pd.subs(v, x)) for x in np.linspace(-5, 5, 41))
    must(S_hyp == 0 and max(abs(x) for x in vals) > 1e-2 and subluminal, "schwarzian")
    rec("L11", "Boundary: quantum vacuum emission from a moving mirror (Fulling-Davies flux -{p,v}/24 pi) is a "
        "functional of the SAME classical projection map p; uniform acceleration (a Moebius map) emits nothing",
        "BOUNDARY (imported)", f"sympy: Schwarzian of p = av/(a+v) is {S_hyp}; for p = v - tanh(v)/2 (a subluminal "
        f"mirror) it is {[round(x, 4) for x in vals]} at v = 0.3, 0.8, 1.5. The classical formula does not produce "
        f"the quantum flux; it supplies its complete input.")


def main(outdir):
    out = pathlib.Path(outdir); out.mkdir(parents=True, exist_ok=True)
    src = pathlib.Path(__file__).read_bytes()
    man = dict(master_seed=MASTER_SEED, blind=False, data="analytic / synthetic only",
               source_sha256=hashlib.sha256(src).hexdigest(),
               written_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), attacks=[f"L{i:02d}" for i in range(1, 12)])
    mt = json.dumps(man, indent=2); (out / "rg_light_manifest.json").write_text(mt)
    t0 = time.time()
    for f in (L01, L02, L03, L04, L05, L06, L07, L08, L09, L10, L11):
        f(); print(RES[-1]["id"], RES[-1]["status"], round(time.time() - t0, 1), flush=True)
    res = dict(manifest_sha256=hashlib.sha256(mt.encode()).hexdigest(), python=sys.version.split()[0],
               numpy=np.__version__, sympy=sp.__version__, platform=platform.platform(),
               runtime_s=round(time.time() - t0, 1), attacks=RES, canaries=CAN,
               summary=dict(locked=sum(r["status"] == "LOCKED" for r in RES), boundary=sum(r["status"].startswith("BOUNDARY") for r in RES), total=len(RES), canaries_rejected=len(CAN)))
    (out / "rg_light_results.json").write_text(json.dumps(res, indent=2, default=str))
    print(json.dumps(res["summary"]))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default="."); main(ap.parse_args().out)
