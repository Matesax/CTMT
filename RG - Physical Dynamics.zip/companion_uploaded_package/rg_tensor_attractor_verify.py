from pathlib import Path
import csv,json,hashlib
import numpy as np
P=Path(__file__).resolve().parent
res=json.loads((P/'rg_tensor_attractor_results.json').read_text())
assert hashlib.sha256((P/'rg_tensor_attractor.py').read_bytes()).hexdigest()==res['source_sha256']
assert res['passed']==res['total_checks']==15
rows=list(csv.DictReader((P/'rg_tensor_attractor_runs.csv').open())); assert len(rows)==res['rows']
trajectories={}; maxerr=0.; maxinc=-1.
b=np.sqrt(2/3); lam=.03
for r in rows:
 if r['family']!='homogeneous_fR': continue
 a=float(r['alpha']); chi=float(r['chi']); v=float(r['velocity']); phi=np.exp(b*chi); z=1/phi
 W=lam*z*z+(1-z)**2/(8*a); H=np.sqrt((v*v/2+W)/3)
 dp=-2*b*lam*z*z+b*z*(1-z)/(4*a); dv=-3*H*v-dp
 HJ=np.sqrt(phi)*(H-b*v/2); dHJ=phi*(b*v*(H-b*v/2)/2-v*v/2-b*dv/2)
 rr=6*(dHJ+2*HJ*HJ)
 maxerr=max(maxerr,abs(rr-float(r['R_J_geometry'])),abs((phi-1)/(2*a)-float(r['R_J_scalar'])),abs(v*v/2+W-float(r['energy'])))
 trajectories.setdefault((a,int(r['case'])),[]).append(r)
assert len(trajectories)==24
final=[]
for (a,j),rs in trajectories.items():
 rs.sort(key=lambda r:float(r['t'])); energies=np.array([float(r['energy']) for r in rs]); maxinc=max(maxinc,float(np.max(np.diff(energies))))
 assert energies[0]<1/(8*a)
 end=rs[-1]; target=np.log(1+8*a*lam)/b; final.append(float(np.hypot(float(end['chi'])-target,float(end['velocity']))))
assert maxerr<1e-10 and maxinc<1e-10 and max(final)<1e-6
out={'source_hash_matches':True,'all_15_battery_groups_pass':True,'raw_rows':len(rows),'trajectories':len(trajectories),'max_recomputed_record_error':maxerr,'max_energy_increment':maxinc,'max_final_scalar_distance':max(final),'scope':'Independent raw-record algebra/hash verification, not a physical-model validation.'}
(P/'rg_tensor_attractor_verification.json').write_text(json.dumps(out,indent=2)+'\n'); print(json.dumps(out,indent=2))
