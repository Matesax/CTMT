"""Declared tensor-attractor models: symbolic identities and synthetic dynamics.
Run python rg_tensor_attractor.py. No observational data are used.
"""
from pathlib import Path
import json,csv,hashlib
import numpy as np
import sympy as s
from scipy.integrate import solve_ivp
P=Path(__file__).resolve().parent
checks=[]; rows=[]
def ck(name,ok,value):
 checks.append(dict(name=name,passed=bool(ok),value=value))
 if not ok: print('FAILED',name,value)
R,alpha,Lambda,phi=s.symbols('R alpha Lambda phi',positive=True)
f=R-2*Lambda+alpha*R**2; fp=s.diff(f,R)
V=s.simplify((phi*R-f).subs(R,(phi-1)/(2*alpha)))
W=V/(2*phi**2); ps=1+8*alpha*Lambda
ck('S01 fR_trace_algebra',s.simplify(fp*R-2*f+R-4*Lambda)==0,str(s.expand(fp*R-2*f)))
ck('S02 scalar_potential',s.simplify(V-2*Lambda-(phi-1)**2/(4*alpha))==0,str(V))
ck('S03 Einstein_stationary_point',s.simplify(s.diff(W,phi).subs(phi,ps))==0,str(ps))
mass=s.simplify(s.Rational(2,3)*ps**2*s.diff(W,phi,2).subs(phi,ps))
ck('S04 positive_scalar_mass_formula',s.simplify(mass-1/(6*alpha*ps))==0,str(mass))
ck('S05 constant_scalar_GR_subsector',s.simplify(V.subs(phi,ps)/(2*ps)-Lambda)==0,str(s.simplify(V.subs(phi,ps)/(2*ps))))
A,B,C,D,E=s.symbols('A B C D E')
sol=s.solve([A+B,B+C,D+E,A+B,B+D,C+E],[B,C,D,E],dict=True)
ck('S06 linear_tensor_coefficient_selection',sol==[{B:-A,C:A,D:A,E:-A}],str(sol))
# Passivity is an extra assumption: reciprocal shift-blind operators can be unstable.
L=np.array([[1.,-1.],[-1.,1.]])
ck('N01 reciprocity_does_not_imply_passivity',np.linalg.eigvalsh(-L).min()<0,np.linalg.eigvalsh(-L).tolist())
# A passive connected graph has exact source-selected equilibrium and contraction.
rng=np.random.default_rng(20261109); n=24; edges=[(i,(i+1)%n) for i in range(n)]+[(i,(i+5)%n) for i in range(n)]
Inc=np.zeros((len(edges),n))
for j,(a,b) in enumerate(edges): Inc[j,a]=1; Inc[j,b]=-1
weights=rng.uniform(.5,1.5,len(edges)); Lap=Inc.T@(weights[:,None]*Inc)
w,Q=np.linalg.eigh(Lap); rho=rng.normal(size=n); rho-=rho.mean(); star=-Q[:,1:]@((Q[:,1:].T@rho)/w[1:]); residual=np.linalg.norm(Lap@star+rho)
err=[]
for j in range(8):
 x=rng.normal(size=n); x-=x.mean(); diff=x-star; t=20/w[1]; final=Q[:,1:]@(np.exp(-w[1:]*t)*(Q[:,1:].T@diff)); ratio=np.linalg.norm(final)/np.linalg.norm(diff); err.append(ratio)
 rows.append(dict(family='graph_relaxation',case=j,contraction_ratio=float(ratio),spectral_bound=float(np.exp(-w[1]*t))))
ck('N02 graph_equilibrium',residual<1e-10,float(residual))
ck('N03 graph_gap_contraction',max(err)<=np.exp(-20)*(1+1e-6),float(max(err)))
# Vacuum, homogeneous, spatially flat, expanding Einstein-frame f(R) model.
b=np.sqrt(2/3); lam=.03; cases=[]; all_geom=[]; all_energy=[]
for a in [.2,1.,5.]:
 phistar=1+8*a*lam; chistar=np.log(phistar)/b; Wstar=lam/phistar; Hstar=np.sqrt(Wstar/3); plateau=1/(8*a)
 def pot(chi):
  z=np.exp(-b*chi); return lam*z*z+(1-z)**2/(8*a)
 def dp(chi):
  z=np.exp(-b*chi); return -2*b*lam*z*z+b*z*(1-z)/(4*a)
 def rhs(t,y):
  chi,v=y; H=np.sqrt((v*v/2+pot(chi))/3); return [v,-3*H*v-dp(chi)]
 for j in range(8):
  # Accepted initial points are in a compact sublevel below the asymptotic plateau.
  while True:
   chi0=chistar+rng.uniform(-.7,.7); v0=rng.uniform(-.15,.15)
   if v0*v0/2+pot(chi0)<Wstar+.7*(plateau-Wstar): break
  ts=np.linspace(0,14/Hstar,1401)
  out=solve_ivp(rhs,(0,ts[-1]),[chi0,v0],t_eval=ts,method='DOP853',rtol=2e-10,atol=2e-12)
  assert out.success,out.message
  chi,v=out.y; ph=np.exp(b*chi); WW=pot(chi); energy=v*v/2+WW; HH=np.sqrt(energy/3); dv=-3*HH*v-dp(chi)
  HJ=np.sqrt(ph)*(HH-.5*b*v)
  dotHJ=ph*(.5*b*v*(HH-.5*b*v)-.5*v*v-.5*b*dv)
  Rgeom=6*(dotHJ+2*HJ*HJ); Rscalar=(ph-1)/(2*a)
  geom=float(np.max(abs(Rgeom-Rscalar))); inc=float(np.max(np.diff(energy)))
  final=float(np.hypot(chi[-1]-chistar,v[-1])); cases.append(final); all_geom.append(geom); all_energy.append(inc)
  for k in range(len(ts)):
   rows.append(dict(family='homogeneous_fR',alpha=a,case=j,t=float(ts[k]),chi=float(chi[k]),velocity=float(v[k]),energy=float(energy[k]),H_E=float(HH[k]),H_J=float(HJ[k]),R_J_geometry=float(Rgeom[k]),R_J_scalar=float(Rscalar[k])))
ck('D01 admitted_expanding_solutions_converge',max(cases)<1e-6,float(max(cases)))
ck('D02 physical_scalar_energy_nonincrease',max(all_energy)<1e-10,float(max(all_energy)))
ck('D03 Jordan_curvature_matches_scalar_relation',max(all_geom)<1e-10,float(max(all_geom)))
# Local mode classification: damping and positive mass, not 'GR' label, cause attraction.
mode=[]
for H,m2,label in [(.2,1.,'EXPANDING_STABLE'),(0.,1.,'CONSERVATIVE_CENTER'),(-.2,1.,'CONTRACTING_UNSTABLE'),(.2,-1.,'TACHYON_UNSTABLE')]:
 eig=np.linalg.eigvals(np.array([[0.,1.],[-m2,-3*H]])); real=np.real(eig)
 predicted='STABLE' if max(real)<-1e-10 else ('CENTER' if max(abs(real))<1e-10 else 'UNSTABLE')
 expected={'EXPANDING_STABLE':'STABLE','CONSERVATIVE_CENTER':'CENTER','CONTRACTING_UNSTABLE':'UNSTABLE','TACHYON_UNSTABLE':'UNSTABLE'}[label]
 mode.append(dict(label=label,eigenvalues=[[float(z.real),float(z.imag)] for z in eig],classification=predicted,correct=predicted==expected))
ck('D04 stability_and_failure_classification',all(v['correct'] for v in mode),mode)
# Low-frequency decoupling is not uniform in the homogeneous extra mode.
# Static trace transfer: deltaR/(-kappa deltaT)=1/(1+6 alpha k^2).
ratios=[]
for a in [.2,1.,5.]:
 for k in [1.,.1,.01,.001]:
  transfer=1/(1+6*a*k*k); error=abs(transfer-1); ratios.append(error/(6*a*k*k))
  rows.append(dict(family='static_trace_transfer',alpha=a,k=k,transfer=transfer,relative_GR_error=error))
ck('E01 low_frequency_static_decoupling_bound',max(ratios)<=1+1e-8,float(max(ratios)))
# No universal physical-time attraction: exact conservative mode preserves its difference energy.
t=np.linspace(0,20,1001); q=np.cos(t); v=-np.sin(t); drift=float(np.ptp((q*q+v*v)/2))
ck('D05 conservative_difference_energy_not_attracted',drift<1e-12,drift)
keys=['family']+sorted(set().union(*(r.keys() for r in rows))-{'family'})
with (P/'rg_tensor_attractor_runs.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=keys); writer.writeheader(); writer.writerows(rows)
res={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'seed':20261109,'checks':checks,'passed':sum(v['passed'] for v in checks),'total_checks':len(checks),'rows':len(rows),'homogeneous_trajectories':len(cases),'model_scope':'Synthetic passive graph and declared four-dimensional vacuum homogeneous expanding R+alpha R^2-2Lambda theory; no observational data or full PDE stability test.','max_final_scalar_distance':max(cases),'max_energy_increase':max(all_energy),'max_Jordan_curvature_residual':max(all_geom),'limitations':['The action, dimension, Lorentz metric, universal matter coupling and positive-alpha branch are declared.','Convergence proof is for a compact homogeneous expanding basin, not arbitrary inhomogeneous solutions.','GR is an exact constant-scalar vacuum subsector and a controlled low-frequency branch, not a universal global attractor.','No beta functions or quantum renormalization-group flow were computed.']}
(P/'rg_tensor_attractor_results.json').write_text(json.dumps(res,indent=2)+'\n'); print(json.dumps(res,indent=2)); assert res['passed']==len(checks)
if __name__=='__main__': pass
