# From wall-tap structure to tensor dynamics and an attracting Einstein sector

## Status and scope
This is a conditional mathematical reconstruction, not a claim that a wall tap uniquely determines gravity. The attached RG - Source of Gravity.pdf is the research input. It distinguishes algebraic remainders, consistency selectors, auxiliary relaxation, and coarse-scale attraction. Its prior SCAR and numerical claims are source-reported, not rerun here. The present release independently computes a passive graph example, linear tensor coefficient selection, scalar-tensor identities, and 24 homogeneous expanding trajectories in a declared R+alpha R^2-2Lambda theory.

Web search was unavailable. No current literature/priority or observational validation was performed. All new numerical examples are synthetic, in declared dimensionless units. General proofs below carry claims beyond the finite examples; numerical agreement is not their proof.

## 1. Typed assumption path
A0: Stable controlled record laws and consistent continuation protocols. These support observational fibres, predictive states and record processing. They do not select a physical evolution law.
A1: A regular smooth continuum realization of the predictive quotient. A finite-dimensional manifold is an assumption or a separate reconstruction result, not a consequence of a finite record.
A2: A calibrated Lorentzian metric realizes the physical cone and clocks. Dimension four, a common cone and universal metric matter coupling are declared. Fisher positivity alone cannot produce this signature.
A3: A torsion-free metric-compatible connection. These two conditions give the unique connection coefficients Gamma^rho_mn=(1/2)g^rho s(partial_m g_sn+partial_n g_sm-partial_s g_mn), by adding the metric-compatibility equations and using lower-index symmetry. Parallel transport around infinitesimal loops defines curvature through its commutator. This is geometric kinematics, not a field equation.
A4: A local diffeomorphism-invariant variational continuum description, with a separately specified matter action. Extra resolved fields are retained rather than hidden in a fitted source.
A5: For the exact minimal GR branch only: no independent extra fields, and an action of total derivative order at most two, regular at zero curvature, modulo boundary terms.
A6: For an effective GR branch instead: extra fields are massive/stable or controlled, and higher-derivative/nonlocal corrections are small on the declared window. This requires scale separation and initial-state control.
A7: For physical-time attraction: an explicitly defined basin, expansion/damping or other loss mechanism, and a coercive or compact Lyapunov argument. Neither source conservation nor gauge invariance supplies this premise.

The implication path is A0 -> operational quotient; A0+A1+A2+A3 -> physical tensor geometry; A4 -> coupled covariant field equations; A5 -> exact minimal Einstein equation; A6 -> controlled effective Einstein branch; A7 -> attraction in the proved basin. These are different theorem types.

## 2. Network balance and the missing positivity gate
Let B be an oriented edge-node incidence matrix. Since B 1=0, rho_dot=-B^T j implies 1^T rho_dot=0. Pairwise balance is exact.
A linear reciprocal shift-blind response has a symmetric matrix L with L 1=0. Locality specifies its sparsity. These conditions alone do not imply L>=0: minus the two-node positive Laplacian is a counterexample. For an attracting passive response require nonnegative edge weights, L=B^T W B with W>=0 and a connected positive-weight support. Then x^T L x=sum_e w_e(Bx)_e^2>=0 and ker L=span{1}.
For a zero-mean source rho, the declared auxiliary relaxation is phi_s=-(L phi+kappa rho). Its equilibrium on 1-perp is phi_*=-kappa L^+rho. With e=phi-phi_*,
 d/ds ||e||^2/2=-e^T L e<=-lambda2 ||e||^2,
so ||e(s)||<=exp(-lambda2 s)||e(0)||. This is a genuine global finite-network attraction modulo constants. The relaxation parameter s is not automatically physical time.
Neither nearest-neighbour locality nor reciprocity derives a Lorentz cone, a tensor gauge redundancy or universal free fall. A continuum limit also needs a convergent graph/measure/operator family. A single graph or a spectral dimension number does not establish that limit.

## 3. Hidden state elimination produces memory, not automatically GR
For a declared linear resolved/hidden dynamics,
 z_dot=Azz z+Azw w,
 w_dot=Awz z+Aww w,
variation of constants gives exactly
 w(t)=exp(Aww t)w0+integral_0^t exp(Aww(t-s))Awz z(s) ds.
Thus
 z_dot=Azz z+Azw exp(Aww t)w0+integral_0^t Azw exp(Aww(t-s))Awz z(s) ds.
This proves a precise route from a broader dynamics to memory and a hidden-initial-state term. If Aww is exponentially stable, the initial term decays. If z varies slowly relative to the hidden relaxation time, the integral is approximated by -Azw Aww^-1 Awz z, with errors controlled by the time variation of z and the exponential kernel. Hence Aeff=Azz-Azw Aww^-1 Awz. This is a conditional local reduction, not a derivation of a gravitational action or a universal hidden-state gap. In nonlinear or non-Markovian settings those require separate estimates.

## 4. Direct linear tensor selection
Assume a flat Lorentz background, a symmetric perturbation h_mn, translation/Lorentz covariance, parity-even local terms linear in h with exactly two derivatives, and no other background tensors. Put h=eta^mn h_mn and v_n=partial^m h_mn. The general operator in this class is
 E_mn=A box h_mn+B(partial_m v_n+partial_n v_m)+C partial_m partial_n h+D eta_mn partial.v+E eta_mn box h.
For pure gauge h_mn=partial_m xi_n+partial_n xi_m, vanishing requires A+B=0, B+C=0, D+E=0. Identical divergence zero additionally requires B+D=0 and C+E=0. Thus B=-A,C=A,D=A,E=-A. The resulting operator is -2A times the linearized Einstein tensor. This is coefficient selection inside the stated ansatz, not a proof of all-order nonlinear uniqueness.
In particular, the linearized Ricci tensor also vanishes on pure gauge, but its divergence is half the derivative of its trace, not identically zero. Gauge annihilation alone is insufficient to couple an arbitrary conserved source. The divergence identity is essential.

## 5. Direct nonlinear minimal branch without importing a uniqueness theorem
Under A2-A5, use normal coordinates at a point. First metric derivatives vanish there; their invariant second-derivative content is curvature. A scalar action of total derivative order <=2 can contain a constant and a term linear in curvature. Contracting one curvature tensor with the metric gives R; other contractions reduce to R or vanish by its symmetries. There is no nonconstant scalar built from g alone. Consequently, modulo boundary terms,
 S=(1/(2 kappa)) integral sqrt(-g)(R-2 Lambda)+S_m[g,psi].
This argument assumes a natural local scalar density constructed only from the metric, with no independent connection, preferred structure, extra fields, nonanalytic curvature dependence or higher derivative terms. It is not the most general action with second-order equations in arbitrary field content.
For compactly supported metric variations, delta sqrt(-g)=-(1/2)sqrt(-g)g_mn delta g^mn. The variation of R is R_mn delta g^mn plus a covariant divergence after integrating the connection variation. Define the independently specified matter tensor by delta S_m=-(1/2) integral sqrt(-g)T_mn delta g^mn. Stationarity gives
 G_mn+Lambda g_mn=kappa T_mn.
This is an all-order equation obtained by varying the selected action, not by extrapolating a cubic numerical check. Diffeomorphism variation of the matter action, with matter on shell, gives covariant conservation. G and Lambda require anchors; neither their measured values nor the dimension follows from this selection.

## 6. A broad but explicit tensor family
A useful extension, not the unique RG completion, is
 S=(1/(2 kappa)) integral sqrt(-g)[F(chi)R-Z(chi)(grad chi)^2-2U(chi)]+S_m[g,psi].
Variation gives
 F G_mn+(g_mn box-nabla_m nabla_n)F+U g_mn
 =kappa T_mn+Z[partial_m chi partial_n chi-(1/2)g_mn(grad chi)^2],
and
 F' R+2Z box chi+Z'(grad chi)^2-2U'=0.
On shell the diffeomorphism identity guarantees the coupled consistency relation. The scalar-gradient and derivative-F terms are not separately conserved arbitrary matter tensors.
At constant chi=chi_*, the metric equation becomes G+(U_*/F_*)g=(kappa/F_*)T, provided the scalar equation F'_* R-2U'_*=0 also holds. That last equation can obstruct a constant scalar for changing matter trace. A constant-scalar GR sector is not automatic for arbitrary matter.
Other extra fields, independent connections, nonlocal kernels and higher curvature terms remain possible unless excluded. Writing G=kappa(T+T_extra) alone is only a rearrangement and does not identify a predictive broad law.

## 7. Explicit nonlinear example with an exact Einstein sector
Declare four-dimensional metric f(R) gravity with signature (-,+,+,+), kappa>0, alpha>0 and Lambda>0:
 S=(1/(2 kappa)) integral sqrt(-g)[R-2Lambda+alpha R^2]+S_m.
Here alpha has units length squared. Variation gives
 (1+2alpha R)R_mn-(1/2)(R-2Lambda+alpha R^2)g_mn
 +2alpha(g_mn box-nabla_m nabla_n)R=kappa T_mn.
The trace is exactly
 6alpha box R-R+4Lambda=kappa T.
In vacuum, every Einstein metric R_mn=Lambda g_mn is an exact solution for every alpha: R=4Lambda, derivative terms vanish, and the remaining coefficient cancels. This includes nonzero Weyl curvature; it is not restricted to conformally flat metrics. It does not mean every solution of the broad theory is Einstein.

Introduce phi=1+2alpha R>0. An equivalent action is
 S=(1/(2 kappa)) integral sqrt(-g)[phi R-V(phi)]+S_m,
 V(phi)=2Lambda+(phi-1)^2/(4alpha).
Variation with respect to phi gives R=V'=(phi-1)/(2alpha), recovering the original action. The metric equation is
 phi G_mn+(g_mn box-nabla_m nabla_n)phi+(1/2)V g_mn=kappa T_mn.
At phi_*=1+8alpha Lambda, V(phi_*)/(2phi_*)=Lambda. Thus the vacuum Einstein sector is exact.

## 8. A physical-time attraction theorem in a specified basin
Set kappa=1 for the executed dimensionless example. In vacuum use g_E=phi g_J and chi=sqrt(3/2)log phi. This invertible transformation on phi>0 yields a canonical scalar with potential
 W(chi)=Lambda exp(-2b chi)+(1-exp(-b chi))^2/(8alpha), b=sqrt(2/3).
The unique finite stationary point is
 phi_*=1+8alpha Lambda, chi_*=log(phi_*)/b,
 W_*=Lambda/phi_*, m_E^2=W''(chi_*)=1/(6alpha phi_*)>0.
For a spatially flat homogeneous expanding solution,
 chi_dot=v,
 v_dot=-3H v-W'(chi),
 3H^2=v^2/2+W, H>0,
 H_dot=-v^2/2.
The energy E=v^2/2+W obeys E_dot=-3H v^2<=0.

Theorem. If initial E is below W_infinity=1/(8alpha), the solution converges to (chi_*,0,H_*), H_*=sqrt(W_*/3), in this homogeneous vacuum expanding model.
Proof. W tends to infinity as chi tends to minus infinity and tends to W_infinity as chi tends to plus infinity. Since E0<W_infinity, its sublevel in (chi,v) is compact. It is positively invariant because E decreases. H>=H_*>0. The smooth vector field therefore has a global forward solution confined to that compact set. E has a limit. Every omega-limit trajectory stays in the same compact set and has constant limiting energy, by continuity and autonomous-flow invariance. The exact energy identity then forces v=0 throughout that trajectory. Its velocity equation forces W'=0, whose only finite root is chi_*. Hence the omega-limit set is the single equilibrium, and the whole solution converges. In the Jordan frame phi tends to phi_* and H_J tends to sqrt(Lambda/3), an Einstein de Sitter solution. End proof.

This is physical cosmological attraction, not a proof that conservative full phase space contracts. Expansion dilutes the homogeneous scalar energy; a reduced subsystem can approach equilibrium while the complete constrained Hamiltonian description does not acquire a global dissipative attractor. Contracting solutions have anti-damping. Negative scalar mass squared is unstable. Inhomogeneous PDE stability and attraction to the whole Einstein solution family are not proved here.

## 9. GR as a controlled effective branch, not an automatic limit
The trace equation is (1-6alpha box)R=4Lambda-kappa T. For a static Fourier mode around a locally flat background,
 delta R(k)/[-kappa delta T(k)]=1/(1+6alpha k^2).
The relative deviation from the GR trace is 6alpha k^2/(1+6alpha k^2)<=6alpha k^2. This is an exact bound for that static linear trace problem. It is not a bound on all tensor observables or a nonlinear solution norm.
For slowly varying sources, a derivative expansion is valid only when alpha box is small on the admitted modes and boundary/initial conditions control the independent massive scalar. The homogeneous scalar mass squared in Jordan units is 1/(6alpha). As alpha tends to zero, arbitrary extra-mode initial data can oscillate ever faster; convergence to GR is not uniform without well-prepared data or damping.
For a local effective action with finite coefficients and a nonzero Einstein-Hilbert term, higher-curvature corrections to weak-field propagation scale relatively as alpha k^2. This establishes derivative suppression in its window, not a computed renormalization-group beta function or a universal infrared attractor. Light fields, nonlocality, instabilities, strong curvature and a vanishing leading kinetic coefficient can defeat that reduction. The cosmological term also remains relevant; its smallness is not derived.

## 10. SCAR and reduced cosmology: correct use
A residual obtained after removing a chosen source is a diagnostic, not a force law. It can represent unresolved fields, derivative corrections, calibration errors, boundary terms or an incompatible source/geometry model. It is evidence for a specific extra sector only if that sector predicts independent records with jointly identifiable parameters.
Homogeneous cosmology does not constrain every covariant term. For example, Weyl curvature vanishes on FLRW backgrounds, so a Weyl-squared term can be invisible there while affecting other geometries. A reduced cosmological lock cannot establish a general tensor uniqueness theorem. This is why the tensor coefficient derivation, action variation and basin proof are separate from the numerical cosmology witness.

## 11. Executed computation and limits
15/15 aggregate checks pass. There are 24 synthetic homogeneous trajectories: alpha in {0.2,1,5}, Lambda=0.03, eight admitted initial states each. Final scalar-state distance is at most 1.9898768235451874e-9. Maximum sampled energy increase is 6.938893903907228e-18, consistent with floating-point roundoff. The Jordan geometric scalar R=6(dot H_J+2H_J^2) agrees with (phi-1)/(2alpha) to at most 7.771561172376096e-16. Eight passive-graph starts obey the spectral contraction bound. Four linear mode controls distinguish expanding stable, conservative centre, contracting unstable and tachyonic unstable cases. The CSV has 33,644 rows.
These are finite implementation witnesses. The energy/compactness argument proves the stated homogeneous basin result. No full nonlinear inhomogeneous simulation, empirical GR test, source-independent tensor reconstruction or microscopic emergence of universal coupling was performed.

## 12. Lock statement
Conditional on an identified Lorentzian metric realization, universal matter coupling, a local covariant variational description and the declared field content, the two-derivative metric branch is Einstein gravity. The explicit broader R+alpha R^2-2Lambda theory contains the vacuum Einstein sector exactly and has a rigorously attracting homogeneous expanding basin approaching its de Sitter member. A separate controlled static trace limit approaches the GR response at low spatial frequency. Neither result establishes that all admissible RG microscopic dynamics flow to GR, or that all physical GR solutions are attractors.

The open bridge is microscopic selection and preservation of the metric/cone/gauge/universal-coupling class under a defined coarse-graining map, with uniform error estimates and stability beyond symmetry reduction. That is the remaining theorem, not a numerical residual to relabel.

## Reproduction
Run python rg_tensor_attractor.py. Requires numpy, scipy, sympy. Results include source hash. The independent verification script recomputes scalar curvature and energy from CSV. No package installation or network access is needed by the source itself.
