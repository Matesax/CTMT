"""L131 obstruction-tower lock: witnesses for the transporter / obstruction-tower theorem.
OB1  2-cell pi_1 obstruction realized by RG families (persistent repeat, 2x2 symmetric): iso iff |k1| = |k2|;
     explicit extension when the obstruction vanishes, degree certificate when it does not.
OB2  3-cells are unobstructed (pi_2 of a compact Lie group = 0): explicit null-homotopy of a nonconstant S^2 -> SO(3) map.
OB3  4-cells can be obstructed (pi_3(SU(2)) = Z): degree certificate.
OB4  open-cell triviality: adapted frames exist and are continuous on a constant-type cell (Riesz projections).
OB5  discrete stabilizers: the tower collapses to pi_0 on 1-cells (hidden-room theorem), checked against HR3.
Run: python rg_obstruction_tower_lock.py   (numpy)
"""
import itertools, json, math, hashlib, pathlib
import numpy as np
RES = []
def rec(i, verdict, claim, witness, **d): RES.append(dict(id=i, verdict=verdict, claim=claim, witness=witness, details=d))
def must(c, m):
    if not c: raise AssertionError(m)
a = 0.5; D = np.diag([1.0, -1.0])
def R(t): return np.array([[math.cos(t), -math.sin(t)], [math.sin(t), math.cos(t)]])
def frame(C):
    w, U = np.linalg.eigh(C); return U[:, ::-1]
SIGNS = [np.diag(s) for s in itertools.product((1.0, -1.0), repeat=2)]

# ---------------- OB1
def fam(k):
    def C(x, y):
        r = math.hypot(x, y)
        if r <= 1: return a * np.eye(2)
        th = math.atan2(y, x); return a * np.eye(2) + (r - 1) * R(k * th) @ D @ R(k * th).T
    return C
def annulus_gauge(k1, k2, d, r):
    """forced gauge on the annulus: g = F2 d F1^T with frames R(k theta)"""
    return lambda th: R(k2 * th) @ d @ R(k1 * th).T
def degree(loopf, N=4000):
    angs = []
    for j in range(N + 1):
        g = loopf(2 * math.pi * j / N)
        if np.linalg.det(g) < 0: g = g @ D
        angs.append(math.atan2(g[1, 0], g[0, 0]))
    un = np.unwrap(np.array(angs)); return int(round((un[-1] - un[0]) / (2 * math.pi)))
table = {}
for k1, k2 in itertools.product((0, 1, -1, 2), repeat=2):
    degs = [degree(annulus_gauge(k1, k2, d, 1.0)) for d in SIGNS]
    iso = any(dg == 0 for dg in degs)
    if iso:   # build the extension explicitly: on the disc use the constant value of the (then constant) loop
        d = SIGNS[degs.index(0)]
        g_ann = annulus_gauge(k1, k2, d, 1.0)
        const = g_ann(0.0); var = max(np.abs(g_ann(t) - const).max() for t in np.linspace(0, 2 * math.pi, 200))
        def g(x, y, const=const, d=d):
            r = math.hypot(x, y)
            return const if r <= 1 else annulus_gauge(k1, k2, d, r)(math.atan2(y, x))
        pts = np.random.default_rng(3).uniform(-2, 2, (400, 2)); pts = pts[np.hypot(pts[:, 0], pts[:, 1]) <= 2]
        err = max(np.abs(g(x, y) @ fam(k1)(x, y) @ g(x, y).T - fam(k2)(x, y)).max() for x, y in pts)
        must(var < 1e-12 and err < 1e-12, "OB1 construction")
    table[f"{k1},{k2}"] = dict(degrees=degs, isomorphic=iso)
    must(iso == (abs(k1) == abs(k2)), "OB1 classification")
rec("OB1", "LOCKED", "Two-cell obstruction in pi_1(SO(2)) classifies the persistent-repeat disc families",
    "Inner disc C = aI (stabilizer O(2)), annulus frame winding k. The section is forced on the annulus up to a constant sign "
    "matrix d; the obstruction on the inner 2-cell is the degree of its boundary loop. Isomorphic iff some d gives degree 0 iff "
    "|k1| = |k2| (reflection acts on pi_1 by -1). When it vanishes an explicit gauge (constant on the disc) conjugates exactly "
    f"(error < 1e-12); otherwise every d gives nonzero degree, and a nonzero-degree loop does not extend over D^2. Table: {table}.",
    table=table)

# ---------------- OB2: pi_2 = 0 -> 3-cells unobstructed (explicit null-homotopy)
rng = np.random.default_rng(132); X = rng.normal(size=(20000, 3)); X /= np.linalg.norm(X, axis=1)[:, None]
q = np.c_[np.zeros(len(X)), X]                 # lift of x -> (rotation by pi about x) to unit pure quaternions (S^2 inside S^3)
cone_min = min(float(np.linalg.norm((1 - r) * np.array([1, 0, 0, 0]) + r * q, axis=1).min()) for r in np.linspace(0, 1, 101))
def quat_to_rot(w, v):
    x, y, z = v; return np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
                                  [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
                                  [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)]])
boundary_ok = max(np.abs(quat_to_rot(0, x) - (2 * np.outer(x, x) - np.eye(3))).max() for x in X[:200])
must(cone_min > 0.7 and boundary_ok < 1e-12, "OB2")
rec("OB2", "LOCKED (imported pi_2(G) = 0)", "Three-cells carry no obstruction",
    "The nonconstant boundary map S^2 -> SO(3), x -> rotation by pi about x, lifts to the pure unit quaternions (an equator "
    f"S^2 in S^3). The normalized cone to 1 stays at norm >= {cone_min:.3f} > 0, so it is an explicit filling over D^3. In "
    "general pi_2 of every compact Lie group vanishes (Cartan), so every 3-cell step is unobstructed once its germ step holds.")

# ---------------- OB3: pi_3 obstruction exists on 4-cells
# imported: deg(id_{S^3}) = 1 and pi_3(SU(2)) = Z; no computation is claimed here
rec("OB3", "IMPORTED (pi_3(SU(2)) = Z)", "Four-cells can be obstructed",
    "The identity S^3 -> SU(2) has degree 1, so it does not extend over D^4 (Brouwer). Its image in SO(3) generates "
    "pi_3(SO(3)) = Z. Your OT3 canary (the naive cone hits 0) is consistent with this. For a block stabilizer containing "
    "O(m), m >= 3, a 4-cell step can carry an integer obstruction.")

# ---------------- OB4: open-cell triviality (adapted frames continuous on a constant-type cell)
def Cop(x, y):     # a 3x3 symmetric family on the open square, constant type: one simple + one repeated cluster
    U = np.linalg.qr(np.array([[1, x, y], [x, 1, x * y], [y, -x, 1.0]]))[0]
    return U @ np.diag([0.8 + 0.1 * x, 0.3 + 0.05 * y, 0.3 + 0.05 * y]) @ U.T
grid = np.linspace(-0.9, 0.9, 61)
def proj(x, y):
    w, V = np.linalg.eigh(Cop(x, y)); return V[:, -1:] @ V[:, -1:].T     # Riesz projection of the simple cluster
Pg = [[proj(x, y) for y in grid] for x in grid]
maxjump = max(max(float(np.abs(Pg[i][j] - Pg[i][j - 1]).max()) for i in range(61) for j in range(1, 61)),
              max(float(np.abs(Pg[i][j] - Pg[i - 1][j]).max()) for i in range(1, 61) for j in range(61)))
must(maxjump < 0.1, "OB4")
rec("OB4", "LOCKED (classical)", "Over each open cell of constant type the transporter is trivial: T = cell x H",
    "Cluster Riesz projections are continuous on a constant-type stratum (maximum neighbour step of the simple-cluster projection on a "
    f"61 x 61 grid, spacing 0.03: {maxjump:.3f}, consistent with continuity). Cluster bundles over a definable cell (contractible) are trivial, "
    "so continuous adapted frames F exist and T(x) = F2(x) H F1(x)^T.")

# ---------------- OB5: discrete stabilizers -> tower collapses to pi_0 (consistency with the hidden-room theorem)
us = np.linspace(-1, 1, 401); phi1 = lambda u: 0.5 * u; phi2 = lambda u: 0.5 * abs(u)
pi0_ok = [(dp, dm) for dp in range(4) for dm in range(4)
          if all(np.allclose(R(phi2(u)) @ SIGNS[dm] @ R(phi1(u)).T, SIGNS[dp], atol=1e-9) for u in us)]
must(not pi0_ok, "OB5")
rec("OB5", "CONSISTENT", "With discrete stabilizers only the 1-cell pi_0 step and the germ steps remain",
    "For discrete H every map S^(r-1) -> H with r >= 2 is constant, so no higher obstructions occur. The HR3 pair fails "
    f"exactly at the pi_0 / germ step along the wall (0 of 16 sign pairs). The tower reduces to the hidden-room descent theorem.")

out = dict(results=RES, verdict=("Obstruction-tower theorem LOCKED: iso <=> transporter section <=> vanishing tower "
           "(germ steps + cell classes in [S^(r-1), H_sigma]). Vanishing: discrete H -> pi_0 only; compact Lie H -> no 3-cell "
           "obstruction; base dim <= 3 -> pi_0 and pi_1 only."),
           source_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest())
pathlib.Path("rg_obstruction_tower_lock_results.json").write_text(json.dumps(out, indent=1, default=str))
for r in RES: print(r["id"], r["verdict"], "|", r["witness"][:220])
print(out["verdict"])
