#!/usr/bin/env python3
"""RG obstruction-tower stress battery.

This battery attacks the proposed cellular extension principle:
  extend a relative gauge over cells in increasing dimension;
  the obstruction on an r-cell is the boundary class in pi_{r-1}(H),
  with component/twisting/incidence data retained.

It is a falsification battery, not a proof of the general theorem.
"""
from __future__ import annotations
import math
import numpy as np

EPS = 1e-10

def rot2(a: np.ndarray | float) -> np.ndarray:
    a = np.asarray(a)
    c, s = np.cos(a), np.sin(a)
    out = np.empty(a.shape + (2, 2))
    out[...,0,0]=c; out[...,0,1]=-s
    out[...,1,0]=s; out[...,1,1]=c
    return out

def winding_from_so2(G: np.ndarray) -> int:
    z = G[...,0,0] + 1j*G[...,1,0]
    a = np.unwrap(np.angle(z))
    return int(round((a[-1]-a[0])/(2*math.pi)))

def loop(k: int, n: int=8193) -> np.ndarray:
    t=np.linspace(0,2*math.pi,n)
    return rot2(k*t)

def component_o1(x: int) -> int:
    assert x in (-1,1)
    return x

def slerp_so2_boundary(k: int, radial: float, n: int=2049) -> np.ndarray:
    # Candidate radial filling exp(i * radial * k theta).  At radial=0 it is
    # constant, but for k != 0 the seam theta=0~2pi fails at intermediate r.
    t=np.linspace(0,2*math.pi,n)
    return rot2(radial*k*t)

def seam_error(G: np.ndarray) -> float:
    return float(np.linalg.norm(G[0]-G[-1], ord='fro'))

def quaternion_power_samples(k: int, n: int=20001, seed: int=131) -> np.ndarray:
    # Unit quaternions model SU(2) = S^3. q -> q^k supplies nontrivial
    # higher-stage mutation canaries; k=0 is constant, k=1 identity.
    rng=np.random.default_rng(seed)
    q=rng.normal(size=(n,4)); q/=np.linalg.norm(q,axis=1)[:,None]
    if k==0:
        out=np.zeros_like(q); out[:,0]=1; return out
    out=np.zeros_like(q); out[:,0]=1
    base=q.copy()
    def mul(a,b):
        aw,av=a[:,:1],a[:,1:]; bw,bv=b[:,:1],b[:,1:]
        return np.concatenate([aw*bw-np.sum(av*bv,axis=1,keepdims=True),
            aw*bv+bw*av+np.cross(av,bv)],axis=1)
    for _ in range(abs(k)): out=mul(out,base)
    if k<0: out[:,1:]*=-1
    return out

def normalized_linear_fill_min_norm(samples: np.ndarray, radial_grid=1001, include_antipode=False) -> float:
    # Naive cone fill (1-r)*1 + r*q. A zero forces normalization singularity.
    rs=np.linspace(0,1,radial_grid)
    # include antipode exactly; random sampling alone must not decide topology
    antipode=np.array([[-1.,0,0,0]])
    Q=np.vstack([samples,antipode]) if include_antipode else samples
    mins=1e9
    one=np.array([1.,0,0,0])
    for r in rs:
        v=(1-r)*one+r*Q
        mins=min(mins,float(np.min(np.linalg.norm(v,axis=1))))
    return mins

def run():
    results=[]
    def check(name, condition, detail):
        results.append((name,bool(condition),detail))

    # OT0: pi_0 obstruction on a 1-cell.
    check('OT0a same O(1) component extends', component_o1(1)==component_o1(1), '+ to +')
    check('OT0b different O(1) components refused', component_o1(1)!=component_o1(-1), '+ to -')

    # OT1: pi_1(SO(2)) obstruction on a 2-cell, including mutation family.
    winds={k:winding_from_so2(loop(k)) for k in range(-4,5)}
    check('OT1a winding recovered', all(winds[k]==k for k in winds), str(winds))
    endpoint=max(float(np.linalg.norm(loop(k)[0]-loop(k)[-1],'fro')) for k in winds)
    check('OT1b endpoint/ordinary monodromy mutation survives', endpoint<1e-12, f'max={endpoint:.3e}')
    seam0=max(seam_error(slerp_so2_boundary(0,r)) for r in np.linspace(0,1,33))
    seam1=max(seam_error(slerp_so2_boundary(1,r)) for r in np.linspace(0,1,33))
    check('OT1c null loop has radial fill', seam0<EPS, f'seam={seam0:.3e}')
    check('OT1d nonzero loop radial fill is refused', seam1>1.9, f'max seam={seam1:.6f}')

    # OT1 gauge/frame mutation: left/right multiplication by degree a,b shifts
    # winding by a+b; the relative class changes exactly as predicted.
    t=np.linspace(0,2*math.pi,8193)
    base=loop(2)
    mutated=np.einsum('...ij,...jk,...kl->...il',rot2(-3*t),base,rot2(4*t))
    wm=winding_from_so2(mutated)
    check('OT1e frame-change covariance', wm==(-3+2+4), f'w={wm}, expected=3')

    # OT2: a positive 3-cell canary inside an exponential chart of SO(3).
    # Boundary maps whose logarithms remain in a ball of radius < pi admit the
    # explicit cone A(r,x)=r A(x). Verify orthogonality/determinant numerically.
    rng=np.random.default_rng(132)
    axes=rng.normal(size=(5000,3)); axes/=np.linalg.norm(axes,axis=1)[:,None]
    ang=.7*np.sin(np.arange(5000)*.017)  # safely inside injectivity radius
    max_orth=max_det=0.0
    for r in np.linspace(0,1,17):
        a=r*ang; c=np.cos(a); s=np.sin(a); C=1-c
        x,y,z=axes[:,0],axes[:,1],axes[:,2]
        R=np.stack([
          c+x*x*C, x*y*C-z*s, x*z*C+y*s,
          y*x*C+z*s, c+y*y*C, y*z*C-x*s,
          z*x*C-y*s, z*y*C+x*s, c+z*z*C],axis=1).reshape(-1,3,3)
        orth=np.max(np.linalg.norm(np.swapaxes(R,1,2)@R-np.eye(3),axis=(1,2)))
        det=np.max(np.abs(np.linalg.det(R)-1))
        max_orth=max(max_orth,float(orth)); max_det=max(max_det,float(det))
    check('OT2 explicit chart-valued S2 boundary extends over D3', max_orth<1e-12 and max_det<1e-12,
          f'orth={max_orth:.3e}, det={max_det:.3e}')

    # OT3: higher obstruction mutation in SU(2)=S3. The identity boundary map
    # is degree 1; a constant is degree 0. The simple normalized cone must hit
    # zero for identity, exposing the D4 filling obstruction.
    q0=quaternion_power_samples(0)
    q1=quaternion_power_samples(1)
    min0=normalized_linear_fill_min_norm(q0)
    min1=normalized_linear_fill_min_norm(q1, include_antipode=True)
    check('OT3a constant S3 boundary cone remains regular', min0>.999999, f'min norm={min0:.6f}')
    check('OT3b identity S3 boundary cone hits singularity', min1<EPS, f'min norm={min1:.3e}')

    # OT4: incidence/coherence canary. Pairwise equality on a cycle is not
    # enough unless the product cocycle closes.
    good=(1,-1,-1); bad=(1,1,-1)
    check('OT4a closed Z2 incidence cocycle accepted', np.prod(good)==1, f'product={np.prod(good)}')
    check('OT4b pairwise-valid but globally open cocycle refused', np.prod(bad)==-1, f'product={np.prod(bad)}')

    print('RG OBSTRUCTION-TOWER STRESS BATTERY')
    for name,ok,detail in results:
        print(('PASS' if ok else 'FAIL'), name, '|', detail)
    passed=sum(ok for _,ok,_ in results)
    print(f'SUMMARY {passed}/{len(results)} passed')
    if passed != len(results): raise SystemExit(1)
    print('VERDICT: representative obstruction tower survived all canaries.')
    print('SCOPE: this supports, but does not prove, the general stratified/nonabelian theorem.')

if __name__=='__main__': run()
