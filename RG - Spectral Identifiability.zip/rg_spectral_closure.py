"""Closure battery for the remaining spectral theorems (supplements the spectral core lock package).
R1  rank-m clusters: orientation holonomy det(H) is reconstructed by sign det(F_i^T F_{i+1}) under the SAME thresholds
    (T3-S/M/N), sharp by block embedding of the rank-one aliases.
R2  the continuous (canonical-connection) holonomy is NOT finitely identifiable: planes in R^3 (normals on S^2),
    holonomy angle = enclosed solid angle; same node planes, different between-node paths, different holonomy.
    Interval bound via the spherical isoperimetric inequality.
R3  statistical rate: Bayes error of an explicit two-node alias pair, and the matching certificate upper bound.
R4  synthetic apparatus (T4-sim): two coupled oscillators encircling the degeneracy at finite rate; parity read out
    with the dynamic phase removed; adiabatic error vs duration; non-encircling control.
Run: python rg_spectral_closure.py   (numpy, scipy)
"""
import json, math, hashlib, pathlib
import numpy as np
from scipy.integrate import solve_ivp
from scipy.stats import norm
rng = np.random.default_rng(20261106)
RES = {}
def must(c, m):
    if not c: raise AssertionError(m)
def rand_orth(n):
    q, r = np.linalg.qr(rng.normal(size=(n, n))); return q * np.sign(np.diag(r))

# ---------------------------------------------------------------- R1 orientation holonomy of rank-m clusters
def plane_frame(P_basis):
    q, _ = np.linalg.qr(P_basis); return q
def orient_parity(frames):
    return int(np.prod([np.sign(np.linalg.det(frames[i].T @ frames[(i + 1) % len(frames)])) for i in range(len(frames))]))
def rank_m_loop(n, m, N, s, parity):
    """m-plane = span(rotating line in a 2-plane, fixed complement of m-1 vectors); line angle steps <= s"""
    target = 0.0 if parity == 1 else math.pi
    steps = list(rng.uniform(-s, s, N - 1)); steps.append(target - sum(steps))
    if any(abs(x) > s for x in steps): return None
    ang = np.concatenate([[0.0], np.cumsum(steps)])[:N]
    Q = rand_orth(n); e1, e2, rest = Q[:, 0], Q[:, 1], Q[:, 2:2 + m - 1]
    # optional slow rotation of the complement inside its own span (does not change parity)
    out = []
    for a in ang:
        line = math.cos(a) * e1 + math.sin(a) * e2
        B = np.column_stack([line, rest]) if m > 1 else line[:, None]
        g = rand_orth(m); out.append(B @ g)          # arbitrary frame of the measured plane (gauge)
    return out
cert = wrong = 0
for trial in range(5000):
    n = int(rng.integers(3, 7)); m = int(rng.integers(1, n)); m = min(m, n - 2) if n - 2 >= 1 else 1
    N = int(rng.integers(4, 30)); s = rng.uniform(0.05, math.pi / 2 - 1e-3); par = int(rng.choice([1, -1]))
    fr = rank_m_loop(n, m, N, s, par)
    if fr is None: continue
    cert += 1
    if orient_parity(fr) != par: wrong += 1
must(cert > 500 and wrong == 0, "R1")
RES["R1"] = dict(claim="Rank-m orientation holonomy det(H) is recovered by prod sign det(F_i^T F_{i+1}) for arbitrary node frames",
                 status="LOCKED (thresholds of T3-S/M/N transfer; sharp by block embedding)", certified=cert, wrong=wrong)

# ---------------------------------------------------------------- R2 continuous holonomy not finitely identifiable
def transport_angle(path):
    """Levi-Civita transport of a tangent frame along a closed normal path on S^2 (= canonical connection on the
    tautological plane bundle of planes in R^3). Returns the rotation angle of the returned frame."""
    n0 = path[0]; e = np.cross(n0, [0.3, 0.5, 0.8]); e /= np.linalg.norm(e); e0 = e.copy()
    for k in range(1, len(path)):
        nk = path[k]; e = e - (e @ nk) * nk; e /= np.linalg.norm(e)         # first-order transport (projection)
    f0 = np.cross(n0, e0)
    return math.atan2(e @ f0, e @ e0)
def slerp(a, b, t):
    om = math.acos(max(-1, min(1, a @ b)))
    return a if om < 1e-15 else (math.sin((1 - t) * om) * a + math.sin(t * om) * b) / math.sin(om)
def bulged(a, b, height, K=4000):
    """path from a to b that bulges sideways by 'height' (radians) at the midpoint"""
    side = np.cross(a, b); side /= np.linalg.norm(side); pts = []
    for j in range(K + 1):
        t = j / K; p = slerp(a, b, t); h = height * math.sin(math.pi * t)
        p = math.cos(h) * p + math.sin(h) * side; pts.append(p / np.linalg.norm(p))
    return pts
nodes = [np.array([math.sin(0.5) * math.cos(phi), math.sin(0.5) * math.sin(phi), math.cos(0.5)]) for phi in np.linspace(0, 2 * math.pi, 7)[:-1]]
def loop(heights):
    pts = []
    for i in range(len(nodes)):
        seg = bulged(nodes[i], nodes[(i + 1) % len(nodes)], heights[i]); pts += seg[:-1]
    pts.append(nodes[0]); return pts
geo = transport_angle(loop([0.0] * 6)); bul = transport_angle(loop([0.15] * 6)); bul2 = transport_angle(loop([-0.15] * 6))
cap_area = 2 * math.pi * (1 - math.cos(0.5))
# per-cell path length budget s_i for the bulged loop and the isoperimetric bound on the extra area
def length(pts): return sum(math.acos(max(-1, min(1, pts[k] @ pts[k + 1]))) for k in range(len(pts) - 1))
s_cell = length(bulged(nodes[0], nodes[1], 0.15)); chord = math.acos(nodes[0] @ nodes[1])
Lc = s_cell + chord; A_max = 2 * math.pi - math.sqrt(4 * math.pi ** 2 - Lc ** 2)
wrap = lambda x: (x + math.pi) % (2 * math.pi) - math.pi
d1, d2 = abs(wrap(bul - geo)), abs(wrap(bul2 - geo))
must(d1 > 0.05 and d2 > 0.05 and d1 <= 6 * A_max + 1e-3 and d2 <= 6 * A_max + 1e-3, "R2")
RES["R2"] = dict(claim="The continuous canonical holonomy is not determined by any finite set of node planes",
                 status="LOCKED (non-identifiability with explicit aliases; interval bound sum_i A(s_i + chord_i))",
                 holonomy_geodesic_polygon=geo, holonomy_bulged_out=bul, holonomy_bulged_in=bul2,
                 differences=[d1, d2], per_cell_isoperimetric_bound=A_max, total_bound=6 * A_max,
                 cap_area_reference=cap_area,
                 note="Same six node planes, admissible between-node paths; holonomy angles differ by the enclosed-area "
                      "difference (Gauss-Bonnet). The finite-sample task for the continuous part is set-valued.")

# ---------------------------------------------------------------- R3 statistical rate (two-node alias)
def two_node_alias(N, s):
    """explicit alias: lifted planar angles a, b; per-cell |increment| <= s; parities + and -;
    node line differences nonzero only at nodes 0 and 1 (each Delta = pi/2 - s). Valid for N >= 4, s in [pi/4, pi/2)."""
    D = math.pi / 2 - s; c = D / (N - 3); cp = s - D
    da = [-s, 0.0] + [c] * (N - 3) + [cp]; db = [s, D] + [c] * (N - 3) + [cp + D]
    a = np.concatenate([[0.0], np.cumsum(da)]); b = np.concatenate([[D], D + np.cumsum(db)])
    return a, b, da, db, D
checks = []
for N in (4, 6, 12, 40):
    for s in (math.pi / 4, 1.0, 1.3, 1.5):
        a, b, da, db, D = two_node_alias(N, s)
        budget_ok = max(map(abs, da)) <= s + 1e-12 and max(map(abs, db)) <= s + 1e-12
        par_ok = abs(a[-1] - a[0]) < 1e-12 and abs((b[-1] - b[0]) - math.pi) < 1e-12
        dist = [abs(((b[i] - a[i]) + math.pi / 2) % math.pi - math.pi / 2) for i in range(N)]
        nonzero = [i for i, d in enumerate(dist) if d > 1e-12]
        checks.append(dict(N=N, s=s, budget_ok=budget_ok, parity_ok=par_ok, nonzero_nodes=nonzero,
                           max_line_diff=max(dist), Delta=D))
        must(budget_ok and par_ok and nonzero == [0, 1] and abs(max(dist) - D) < 1e-12, "R3 alias")
def lower_upper(N, s, sigma, p):
    D = math.pi / 2 - s
    m_lower = 2 * (norm.ppf(1 - p) * sigma / D) ** 2           # Bayes error of the alias pair <= p requires m >= this
    m_upper = 8 * sigma ** 2 * math.log(2 * N / p) / D ** 2    # union-bound certificate with alpha < D/2
    return m_lower, m_upper
rates = {f"N={N},s={s:.3f},p={p}": dict(zip(("m_lower", "m_upper"), lower_upper(N, s, 0.05, p)))
         for N in (6, 40) for s in (1.0, 1.4) for p in (1e-2, 1e-6)}
# Monte Carlo check of the Bayes error of the alias pair at one setting
N, s, sigma, m = 6, 1.2, 0.4, 4
a, b, *_ , D = two_node_alias(N, s)
mc_err = 0; TT = 40000
for _ in range(TT):
    truth = rng.integers(0, 2); th = (a if truth == 0 else b)[:N]
    y = th + sigma / math.sqrt(m) * rng.normal(size=N)
    ll0 = -np.sum(((y - a[:N] + math.pi / 2) % math.pi - math.pi / 2) ** 2)
    ll1 = -np.sum(((y - b[:N] + math.pi / 2) % math.pi - math.pi / 2) ** 2)
    mc_err += int((ll1 > ll0) != (truth == 1))
bayes_formula = norm.cdf(-D * math.sqrt(m / 2) / sigma)
must(abs(mc_err / TT - bayes_formula) < 0.01, "R3 Bayes error")
RES["R3"] = dict(claim="Statistical parity identification: m* in [2 z_p^2 sigma^2/Delta^2, 8 log(2N/p) sigma^2/Delta^2], Delta = pi/2 - s",
                 status="LOCKED (two-point lower bound from an explicit two-node alias; union-bound upper certificate; "
                        "rate sharp up to the factor 4 log(2N/p)/z_p^2)",
                 alias_checks=checks, rates=rates, monte_carlo=dict(N=N, s=s, sigma=sigma, m=m, empirical_error=mc_err / TT,
                                                                    bayes_formula=bayes_formula))

# ---------------------------------------------------------------- R4 synthetic apparatus: coupled oscillators encircling a degeneracy
def run_oscillators(T, rho=0.4, k0=2.0, centre=(0.0, 0.0), noise=0.0):
    def K(t):
        ph = 2 * math.pi * t / T; d = centre[0] + rho * math.cos(ph); c = centre[1] + rho * math.sin(ph)
        return np.array([[k0 + d, c], [c, k0 - d]])
    def top(Kt):
        w, U = np.linalg.eigh(Kt); return w[-1], U[:, -1]
    w0, u0 = top(K(0.0)); om0 = math.sqrt(w0)
    x0 = u0.copy(); v0 = np.zeros(2)
    sol = solve_ivp(lambda t, y: np.r_[y[2:], -K(t) @ y[:2]], [0, T], np.r_[x0, v0], rtol=1e-10, atol=1e-12,
                    dense_output=False, t_eval=[T])
    xT, vT = sol.y[:2, -1], sol.y[2:, -1]
    # dynamic phase from the known model: integral of omega_top(t) dt
    ts = np.linspace(0, T, 4001); oms = [math.sqrt(top(K(t))[0]) for t in ts]
    phase = np.trapezoid(oms, ts); omT = oms[-1]
    z = (u0 @ xT) + 1j * (u0 @ vT) / omT + noise * (rng.normal() + 1j * rng.normal())
    hhat = (z * np.exp(1j * phase)).real
    return hhat
res4 = {}
for T in (50, 100, 200, 400, 800):
    enc = run_oscillators(T); ctl = run_oscillators(T, centre=(0.8 * 0.4 + 0.4, 0.0))
    res4[T] = dict(encircling=enc, control=ctl)
errs = [abs(res4[T]["encircling"] + 1) for T in res4]
must(all(res4[T]["encircling"] < -0.9 for T in (200, 400, 800)) and all(res4[T]["control"] > 0.9 for T in (200, 400, 800))
     and errs[-1] < errs[0], "R4")
RES["R4"] = dict(claim="Synthetic apparatus: encircling the degeneracy flips the readout sign; a non-encircling loop does not",
                 status="LOCKED (simulation only; known dynamic phase; adiabatic error decreases with duration)",
                 readout_by_duration={str(k): v for k, v in res4.items()}, adiabatic_errors=errs,
                 note="K(t) = [[k0+d, c],[c, k0-d]], (d, c) on a circle of radius 0.4 about the degeneracy (encircling) "
                      "or about (0.72, 0) (control). Readout Re(z e^{i int omega dt}) with z the complex mode amplitude.")
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_spectral_closure_results.json").write_text(json.dumps(RES, indent=1, default=float))
for k, v in RES.items():
    if isinstance(v, dict): print(k, "|", v["status"])
print("R2", geo, bul, bul2, A_max); print("R3 mc", mc_err / TT, bayes_formula); print("R4", res4)
