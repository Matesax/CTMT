# Universality stress programme for RG identifiability theorems

A theorem is accepted only after it survives six axes of stress **across its whole declared contract**, not on hand-picked fixtures. Each axis has a pass criterion and a typed output.

## 0. The contract (declare before testing)

| Field | Example (T3c) |
|---|---|
| Prior class 𝒫 | closed real eigenline loops, angular speed ≤ V, any ambient dimension |
| Observation O and noise | node lines on a uniform mesh, angular error ≤ α, arbitrary signs |
| Task τ | orientation holonomy ±1 |
| Certificate C | product of overlap signs, issued iff Vh + 2α < π/2; otherwise abstain |
| Calibrated inputs | V, α, branch correspondence (gap > 0), loop closure |

## The six axes

| Axis | Test | Pass criterion | Typed output |
|---|---|---|---|
| A Soundness | random and adversarial instances inside the contract (worst-case rotation placement, worst-case noise) | zero certified-wrong outputs | LOCKED, or COUNTEREXAMPLE |
| B Sharpness | optimizer or LP searches for **aliases** (two admissible states, consistent observations, different task) at and beyond the threshold | alias threshold = certificate threshold | SHARP, or GAP (report the size) |
| C Necessity | drop each hypothesis alone; construct a certified-wrong canary | every hypothesis has a canary | NECESSARY, or POSSIBLY REMOVABLE (a strengthening candidate) |
| D Invariance | sign gauge, basis rotation, ambient embedding, reparametrization | output unchanged | LOCKED |
| E Composition | chain certificates (matrix noise → angle noise → parity) and test the pipeline end to end | zero certified-wrong outputs | LOCKED |
| F Transfer | rerun A–E in several representations (RP¹, RP², RP⁵) | identical verdicts | UNIVERSAL within the stated class |

**Rules.**
- A theorem without B is a bound, not a lock.
- A hypothesis without C is either unnecessary or untested; neither may be silently kept.
- Abstention counts as correct only if B shows that the abstained region contains aliases.

## Executed: `rg_universality_stress.py` (seed 20261105; reruns identical)

| Axis | Result |
|---|---|
| A T3c | 3,000+ certified instances (random and adversarial; RP¹, RP², RP⁵), **0 wrong** |
| B T3c | LP alias search gives an alias threshold **exactly π/2 − 2α** (agreement to 5e-8 at α = 0, 0.05, 0.1, 0.2, 0.3). A realized alias at α = 0.1 (both loops' measurements within α, opposite parity). **The noisy certificate is minimax-sharp for any estimator.** This closes the package's open item "sharp noisy minimality" for this class. |
| A T2b | 300 adversarial perturbation searches (n = 2–4): the maximum ratio to ε/(g−ε) is 0.886 (sound). The ratio to ε/g reaches **1.054**: ε/g alone is not a valid uniform bound, confirming the package's choice of ε/(g−ε). |
| C | All four hypotheses are necessary. Under-declared speed (same samples, opposite parity), under-declared noise (the LP alias passes an α = 0 certificate), gap dropped (a 10⁻³ tilt at a crossing flips the output), and closure dropped (an open path still returns a "parity") each yield a certified-wrong canary. |
| D | 500 loops: gauge, rotation, embedding and reparametrization: 0 failures |
| E | T2b → T3c pipeline: 0 wrong among certified cases, the rest abstained |

## Next stress targets (in order)

1. **B for T2 coarse protocols.** For each added analyzer set, compute the alias diameter ω(0) by optimization. This gives an exact channel-minimality table for pointwise projector recovery: 0 added channels fail (T2c), 1 suffices in 2×2. Then the n×n question: minimal analyzer count, with sharpness.
2. **Adaptive and nonuniform schedules.** B with variable spacing, i.e. the minimal total samples when V varies along the loop. The alias LP extends directly.
3. **Statistical noise.** Replace the hard bound α by sub-Gaussian errors. A becomes "error probability ≤ p"; B becomes Le Cam two-point bounds built from the LP aliases.
4. **Changing stabilizer type (T1).** Repeated clusters, with cluster-projector tasks: the same six axes on Grassmannian loops (holonomy in O(m)).
5. **T4 physical.** Apply the harness to a simulated two-oscillator apparatus with finite-rate transport and dynamic phase; then to real data.
