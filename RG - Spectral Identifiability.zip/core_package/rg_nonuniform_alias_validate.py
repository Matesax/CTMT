"""Exact nonuniform-budget alias construction, angles measured in units of pi."""
from fractions import Fraction as F
import numpy as np,json
from pathlib import Path

def build(budgets,alpha):
 B=sum(budgets);j=max(range(len(budgets)),key=lambda i:budgets[i]);s=budgets[j]
 assert B>=1 and s+2*alpha>=F(1,2)
 # Cyclic reorder puts the alias interval first.
 ell=budgets[j:]+budgets[:j];S=sum(ell[1:])
 if s>=1:
  da=[F(0)]*len(ell);db=[F(1)]+[F(0)]*(len(ell)-1);r=F(0)
 elif s>=F(1,2):
  da=[s-1]+[(1-s)*x/S for x in ell[1:]]
  db=[s]+[(1-s)*x/S for x in ell[1:]];r=F(0)
 else:
  da=[-s]+[s*x/S for x in ell[1:]]
  db=[s]+[(1-s)*x/S for x in ell[1:]];r=(1-2*s)/2
 a=[F(0)];b=[r]
 for x,y in zip(da,db):a.append(a[-1]+x);b.append(b[-1]+y)
 assert a[-1]==0 and b[-1]-b[0]==1
 assert all(abs(x)<=e and abs(y)<=e for x,y,e in zip(da,db,ell))
 for x,y in zip(a[:-1],b[:-1]):
  d=x-y;assert min(abs(d-k) for k in range(-3,4))<=2*alpha
 return a,b

def run():
 rng=np.random.default_rng(191);aliases=0;trivial=0;safe=0
 for N in range(2,16):
  for _ in range(80):
   budgets=[F(int(x),100) for x in rng.integers(0,130,N)]
   alpha=F(int(rng.integers(0,40)),100)
   if sum(budgets)<1:trivial+=1
   elif max(budgets)+2*alpha<F(1,2):safe+=1
   else:build(budgets,alpha);aliases+=1
 r=dict(exact_nonuniform_aliases=aliases,global_prior_trivial_cases=trivial,
        uniform_sufficient_cases=safe,scope='Known interval budgets; not unknown-speed adaptive optimality.')
 Path('rg_nonuniform_alias_validation.json').write_text(json.dumps(r,indent=2));return r
if __name__=='__main__':print(json.dumps(run(),indent=2))
