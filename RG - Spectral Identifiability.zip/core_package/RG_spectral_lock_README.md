# RG deterministic spectral core closure package

Start with RG_spectral_core_theorems.md and RG_spectral_lock_ledger.json.

The original three attachments are unchanged. The original source hash matches its supplied result record. The unchanged full original rerun hit the execution limit during its optimizer; the new main script reruns reviewed nonoptimizer sections and supplies a separate proof-backed battery. Original status labels are historical data, not accepted proof claims.

All new data are synthetic. Theorems are conditional on the report contracts. No formal verification, external peer review, novelty audit or laboratory validation is asserted.

Reproduction from this directory, with numpy, scipy and sympy installed:

```sh
python rg_spectral_lock.py
python rg_spectral_lock_validate.py
python rg_nonuniform_alias_validate.py
python rg_spectral_additional_checks.py
```

The completed main suite was run twice with byte-identical result JSON. Exact rational/symbolic checks supplement floating-point tests. The nonuniform alias grid targets aliases and global-prior cases; the separate transport audit covers sufficient edgewise certificates. Hashes and environment are recorded in RG_spectral_lock_manifest.json.
