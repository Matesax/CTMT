# RG spectral identifiability: corrected core theorem closure

## Executive verdict
The deterministic real rank-one T2/T3 core is proved below under explicit contracts. This is a mathematical closure within those contracts, not closure of all spectral-degeneracy research, a novelty claim, formal verification, or physical validation. In particular T1 extension classification, arbitrary changing-rank clusters, statistical minimax theory, unknown-speed adaptive design, and T4 apparatus dynamics/data remain open.

The supplied source SHA256 matches its supplied result record. An unchanged full rerun was attempted but stopped at the execution limit during the expensive T2 optimizer. The supplied A/B/C/D/E sections excluding that optimizer were then executed as a clearly labelled subset. A new completed suite replaces optimizer-based proof claims with analytic bounds and explicit aliases, and adds separate exact-arithmetic and nonuniform audits. Original attachments were not overwritten. No external web audit was possible; web search disabled, general knowledge cutoff December 2025.

## 0. Objects, observations and tasks
All matrices are real symmetric in a calibrated fixed ambient Euclidean basis, n>=2. For a simple tracked eigenvalue, P=uu^T is the task, not a gauge-dependent signed eigenvector. Its metric is ||P-Q||_op=sin(theta), theta in [0,pi/2]. Matrix observation error is operator norm. Fixed coordinate intensities diag(P) are a different protocol and do not inherit matrix-error bounds.

A real line loop P:[0,L]->RP^(n-1) is closed and absolutely continuous. A continuous unit lift satisfies u(L)=h u(0), h in {+1,-1}. This orientation holonomy is the task; it is not a general O(m) connection holonomy. At node i the measured line is within projective angular distance alpha of the true line. Error balls are adversarial, with no independence assumption. Each interval has a certified angular path-length budget ell_i, and B=sum ell_i. For a speed bound V(t), ell_i=int_i V(t)dt. Closure, common basis, branch association, and calibration bounds are assumptions, not conclusions extracted from finitely many samples.

Numerical certificates assume at least one compatible physical/mathematical loop exists. They are not complete feasibility solvers. The word UNRESOLVED does not assert that every particular unresolved dataset has an alias.

## 1. T2-F: exact fixed-spectrum pairwise modulus
For A(P)=lambda_minus I+gP in a two-level block, g>0,

 omega_g(eps)=sup{||P-Q||: ||A(P)-A(Q)||<=eps}=min(eps/g,1).

Proof: A(P)-A(Q)=g(P-Q). Rotating one line by theta attains every distance sin(theta) in [0,1]. In the spanning plane, (P-Q)^2=sin²(theta)I. A separated constant spectator embeds this equality in n>=3. This is a pairwise diameter, not an estimator's exact minimax radius. If two models are each delta-close to one observed matrix, their pairwise matrix distance is at most 2delta.

## 2. T2-G: general isolated-line bound
Let A have simple lambda, gap g to all other eigenvalues, B=A+E with ||E||<=eps<g/2. Track the corresponding eigenvalue mu. Then

 ||P_A-P_B|| <= eps/(g-eps).

Proof: min-max bounds each ordered eigenvalue shift by eps, hence |mu-lambda|<=eps. For a unit mu eigenvector v, let Q=I-P_A. Project (A-mu)v=-Ev onto Q. On ran Q the inverse norm of A-mu is <=1/(g-eps). Thus ||Qv||<=eps/(g-eps), which equals the projector distance for rank-one projectors. This proof applies to interior as well as extremal simple eigenvalues. The bound is sufficient, not claimed to be the sharp finite-eps constant.

## 3. T2-E: sharp extremal-line modulus
For the top eigenline, lambda_1(A)-lambda_2(A)>=g>0, ||E||<=eps<g/2, the exact worst-case projector error over this class is

 f(eps/g)=sin( (1/2) asin(2eps/g) ).

Proof of upper bound: write v=cos(theta)u+sin(theta)w, w orthogonal to the original top eigenvector u, and z=-sin(theta)u+cos(theta)w. Since z^T(A+E)v=0,

 eps >= |z^TEv|=sin(theta)cos(theta)[lambda_1-w^TAw]>=g sin(theta)cos(theta).

Follow the simple top eigenline continuously along A+tE, 0<=t<=1. Its gap remains >=g-2eps>0. Starting at theta=0, it cannot reach pi/4 because that would require eps>=g/2. Therefore sin(2theta)<=2eps/g on the branch theta<pi/4, proving the bound.

Attainment: set A=(g/2)diag(1,-1), theta=(1/2)asin(2eps/g), c=cos(2theta), s=sin(2theta), and B=(g/2)c[[c,s],[s,-c]]. Then ||B-A||=eps and the top line rotates by theta. Separated lower spectators preserve the example in every n>=2. The bottom-line version follows by negating matrices. No sharp interior-eigenline constant is asserted here.

At eps/g=.3 the attained error is .3162277660, so eps/g alone is not a uniform finite-error bound. Classical perturbation geometry supplies these ingredients; no priority claim is made.

At g=0 the individual line is not a single-valued matrix task. A set-valued refinement can contain every line in the degenerate eigenspace. A cluster projector with an external gap is a different task and can remain identifiable. Do not silently substitute one for the other.

## 4. T2-C: coarse obstruction and exact analyzer repair
Eigenvalues and fixed coordinate intensities alone can collide at positive gap. For u+=(cos a,sin a), u-=(cos a,-sin a), the two spectra and diag(P) agree, while ||P+-P-||=|sin(2a)|. Thus the coarse protocol has omega(0)>0; Davis-Kahan cannot repair this without a justified inverse map.

Suppose all n coordinate intensities u_i² are already measured, and additional probes are fixed calibrated real rank-one analyzer intensities |a_j^T u|². The minimum number of additional scalar channels for exact uniform recovery of P on all real unit vectors, including zero coordinates, is n-1.

Sufficiency: choose n-1 additional rows so the total 2n-1 analyzer vectors are full spark: every n span R^n. Such choices exist, since the finitely many determinant conditions are nonzero polynomials in the additional rows; their product is not identically zero. If u,v have equal analyzer intensities, each analyzer is orthogonal to either u-v or u+v. One of these two sets has at least n vectors, so spans, forcing u=v or u=-v.

Necessity: with at most 2n-2 total vectors, split them into two sets each of size <=n-1. Choose nonzero x,y orthogonal to the respective spans. Then u=x+y and v=x-y have equal analyzer intensities. Since all coordinate axes are included, each x_i y_i=0, so x and y are orthogonal, u and v have equal nonzero norms, and are not equal up to sign. Normalizing gives a unit-vector alias. This proves the lower bound even with normalization known.

Concrete designs: in 2D add (1,1)/sqrt(2); in 3D add (1,1,1)/sqrt(3) and (1,2,3)/sqrt(14). Thus the answer is ONE extra channel in 2D and TWO in 3D, not three pairwise cross-term channels. The implemented Vandermonde-plus-axes designs in n=2,3,6 have every relevant minor checked exactly in the secondary audit. The 6D design is poorly conditioned; exact identifiability is not a claim of practical noise robustness.

For the 2D design, writing D=P-Q=[[x,y],[y,-x]], the intensity difference vector is (x,-x,y). Therefore ||O(P)-O(Q)||_2²=2x²+y²>=||D||_op². Every D direction with x=0 and ||D||<=1 is attainable by rank-one projector pairs, so the repaired intensity-protocol pairwise modulus is exactly min(eps,1). No spectral gap factor appears because the observed task is already the normalized eigenline.

For any fixed full-spark design, a positive inverse-Lipschitz constant exists on real projectors. Normalize secants D=(P-Q)/||P-Q||_op. Their closure is compact, trace zero, rank two, with eigenvalues +/-1. If the linear intensity map vanished on such D, its positive/negative eigenlines would be an analyzer alias. Injectivity excludes that. Hence c_A=min ||O(D)||_2>0 and ||P-Q||<=||O(P)-O(Q)||_2/c_A. The 3D/6D constants are not sharply computed or interval-certified in this package. Channel count minimality is exact noiseless identification, not minimum statistical effort.

## 5. T3-S: deterministic noisy coverage
For a uniform mesh h=L/N, with per-cell budget s=Vh, if s+2alpha<pi/2, cyclic overlap signs recover h(P) for arbitrary representatives of the measured lines.

Proof: lift each true interval continuously. Choose measured representatives within alpha of the true lifts. Their spherical separation across each interval is at most alpha+s+alpha<pi/2, so the lifted dot product is positive. The sign transitions of arbitrary representatives encode precisely the endpoint sign of the true continuous lift. Multiplying them cancels every node sign and leaves h(P). The argument uses only the sphere-to-projective-space double cover and applies in every real ambient dimension n>=2.

Global exception: if B<pi, every compatible loop has h=+1. A negative loop would lift from u to -u and require spherical length at least pi. No observations are needed to know parity under this strong prior. This exception was absent from the attached blanket sharpness statement.

## 6. T3-M: exact noisy minimax alias threshold, with proof
For N>=2 uniform cells, budget s per cell, angular node error alpha in [0,pi/2), opposite-parity aliases with a common measured dataset exist if and only if

 Ns>=pi AND s+2alpha>=pi/2.

Necessity: Ns<pi forces positive parity. If s+2alpha<pi/2, T3-S reconstructs parity uniformly, so opposite aliases are impossible.

Sufficiency, explicit construction: let t=min(s,pi/2), r=(pi-2t)/2. Start planar lifts at a0=0,b0=r. On the first cell take increments da=-t, db=t. On each of the other N-1 cells take da=t/(N-1), db=(pi-t)/(N-1). The assumptions imply all increment magnitudes <=s. The first lift ends at aN=0; the second at bN=b0+pi. Their node differences, modulo pi, run from -r to +r and back, hence have projective separation <=r<=2alpha. At every node choose a midpoint line; its error from each true line is <=r/2<=alpha. Thus the same noisy observations fit opposite parities. This is an alias for ANY estimator, not merely failure of the overlap estimator. Embed the plane into any n>=2. Piecewise constant angular velocities give Lipschitz loops. Equality is included for this class; a narrower smooth/analytic class requires its own boundary analysis.

Equivalently, the threshold in s at fixed N is max(pi/N,pi/2-2alpha), not always pi/2-2alpha. The supplied N=6, alpha<=.3 experiments lie in the regime where the latter term dominates, so their numerical thresholds are consistent with this corrected theorem. Their approximately 5e-8 offsets are solver-tolerance effects, not exact proofs.

For B=VL>=pi and alpha<pi/4, the minimum number of distinct uniform samples for a uniform guarantee is

 N_min=floor(B/(pi/2-2alpha))+1.

For B<pi, zero samples suffice for parity. For B>=pi and alpha>=pi/4, no finite N gives a uniform guarantee in this adversarial-noise class. A single node cannot distinguish a constant loop from a negative loop of length pi when B>=pi. The theorem concerns exact minimax identification, not a randomized estimator's average error or an adaptive physical experiment.

## 7. T3-N: nonuniform known budgets, also sharp
Let ell_i be arbitrary nonnegative certified per-cell angular budgets, N>=2, B=sum ell_i. Uniform identification for all admissible loops and node errors is possible iff

 B<pi OR max_i ell_i+2alpha<pi/2.

Sufficiency follows from the global prior or the edgewise lift proof. For necessity when both fail, rotate node indexing so the largest budget s is first, and let S=B-s be the remaining budget.

If s<pi/2: take a0=0,b0=r=(pi-2s)/2; first increments (-s,+s); remaining increments da_i=s ell_i/S and db_i=(pi-s)ell_i/S. Since S>=pi-s>=s, every budget is respected. Node differences stay within r of multiples of pi; midpoint errors <=alpha. Endpoints differ by one half-turn.

If pi/2<=s<pi: take a0=b0=0; first increments (s-pi,s); remaining increments da_i=db_i=(pi-s)ell_i/S. Budgets hold because S>=pi-s, node lines agree exactly, and parities differ.

If s>=pi: hold A constant and make B traverse a half-turn entirely in that cell. Again all node lines agree. These constructions prove the claimed iff and transfer to any ambient dimension by embedding.

With a known continuous cumulative speed budget, placing nodes at equal increments of its integral attains the same N_min formula as above. No fixed schedule with fewer nodes can do better, since some ell_i>=B/N. This is optimal design for a KNOWN budget density, not optimal adaptive learning of an unknown V(t). Reparametrization invariance requires transforming V(t)dt; cyclic node shifts alone do not test arbitrary reparametrization.

## 8. T3-D: stronger data-dependent sufficient certificate
Let theta_i be the observed projective angle between consecutive node lines, with theta_i<pi/2. If

 ell_i+2alpha+theta_i<pi for every edge,

the observed cyclic overlap product equals the true parity.

Proof: choose true node representatives within alpha of observed representatives. In the gauge where the observed overlap is positive, a true lift ending with the opposite sign would have spherical endpoint distance at least pi-theta_i-2alpha. The interval budget is strictly smaller, so that transition is impossible. Therefore each true transition matches the observed sign. Multiply around the loop.

This can certify datasets outside the uniform minimax region. Example: N=6,s=1.4,alpha=.1, all observed lines equal. The uniform inequality fails, but 1.4+.2<pi, so every compatible loop has positive parity. Thus blanket abstention is conservative; it is false that each abstained dataset must itself contain aliases. Minimax sharpness only says some ambiguous dataset exists in the regime.

## 9. Matrix-to-angle-to-parity composition
At a node, measured matrix M has tracked gap ghat>2delta and ||A-M||<=delta. Apply T2-G with M as reference to get

 alpha<=asin(delta/(ghat-delta)).

For a C1 true matrix family with ||A'||<=Mbound and a global simple tracked gap >=gmin>0, differentiating the eigenvalue equation gives angular speed ||P'||<=Mbound/gmin. If uniform samples have measured gaps ghat_i and matrix errors <=delta, Weyl/min-max plus gap Lipschitz continuity gives

 gmin>=min_i ghat_i-2delta-Mbound*h.

The gap changes by at most 2Mbound times parameter distance; every point is within h/2 of a sample. Require the right-hand side positive and branch correspondence. Combine with T3-S or T3-D. These are deterministic implications. The implemented noisy-matrix pipeline uses analytically known true speed/gap in its synthetic family; it does not infer an arbitrary derivative bound from data.

A gap is NOT intrinsic to parity of an already supplied continuous line loop. It is needed to derive that line from a matrix branch. The attached gap canary is an arbitrary line list with perturbed angles, not an explicit matrix-family counterexample isolating the gap hypothesis. Open-path parity is undefined, not a wrong value of a defined loop task. These necessity claims must be typed by layer.

## 10. Conditional statistical wrapper, not statistical minimax closure
If simultaneous calibration/noise bounds hold with probability at least 1-p, a deterministic sound certificate has probability at most p of issuing a wrong answer. Proof: wrong certification can occur only outside the calibration event. If each of N angular errors has tail <=2 exp(-m alpha²/(2sigma²)), choose alpha=sigma sqrt(2 log(2N/p)/m) and use a union bound. No independence is needed for this upper bound. The tail model, sigma, effective m, calibration, and any adaptive selection require their own justification. No statistical minimax lower bound, real estimator validation, or confidence calibration is claimed here.

## 11. Audit of supplied claims
- Finite randomized/optimizer stress is corroboration, not proof over an entire contract.
- Supplied LP thresholds are compatible with T3-M for their tested N and alpha, but do not prove all N or alpha.
- The supplied random_loop generator uses one random fixed plane even in n=3,6; ambient embedding is not arbitrary nonplanar coverage. The new suite includes time-varying planes.
- The supplied composition record has 400 certificates and zero abstentions; the new pipeline deliberately includes high-noise cases and abstention.
- The supplied C labels do not prove every hypothesis is intrinsically necessary: gap belongs to a different layer; closure defines the task domain.
- Gauge, constant basis rotation, isometric embedding and loop reversal preserve parity. General reparametrization must preserve the integrated interval budgets.
- A single known transverse conical collision already forces odd parity; it is not a hidden binary task under that same prior. Fixed-basis intensity blindness can occur in broader loop classes; calibrated additional analyzers repair pointwise identification without an absolute phase reference.

## 12. Completed stress evidence
Main completed suite: 9 grouped checks; 60 exact-attainment numerical cases; 1800 random perturbations; 36 optimizer searches; 693 explicit noisy alias embeddings; 40 independent LP feasibility checks; 1200 nonplanar/noisy parity certificates; 4800 invariance checks; 48 noisy-matrix certificates and 24 abstentions; 219 analyzer reconstructions covering 73 nonempty supports; three analyzer lower-bound aliases. No asserted bound failed. Floating-point angle checks allow explicit roundoff tolerances and are not interval-certified.

Additional audit: 800 interior-eigenline perturbation checks, 101 repaired 2D intensity-modulus attainment checks, isolated speed/noise canaries, and the open-path rejection gate passed. The midpoint alias has an exactly orthogonal edge; the noise-understatement canary was moved within the common error-ball slack to avoid mistaking a numerical tie for a robust wrong certificate. The completed main suite was rerun and its result JSON was byte-identical.

Secondary audit: 133 exact rational uniform alias contracts; 475 exactly nonzero analyzer minors; 297 accepted nonuniform/reparametrized noisy-loop certificates; supplied source hash verified; finite-error eps/g canary and one-analyzer 3D collision verified.

Nonuniform alias audit: 1092 exact rational nonuniform aliases and 28 global-prior cases in its randomized budget grid. This grid did not exercise the sufficient-small-edge regime; the separate nonuniform transport audit does. Counts are not universal proof; the arguments above supply that.

## 13. Final lock ledger
PROVED_WITHIN_CONTRACT: T2-F fixed-spectrum modulus; T2-G isolated-line upper bound; T2-E sharp extremal modulus; T2-C fixed-analyzer count and coarse collision; T3-S noisy sufficiency; T3-M exact noisy uniform minimax threshold; T3-N exact known-budget nonuniform threshold and optimal fixed budget spacing; T3-D data-dependent sufficient certificate; deterministic composition; conditional confidence-event transfer.

NOT CLAIMED CLOSED: T1 arbitrary extension classification; changing-rank/stabilizer classification; general O(m) holonomy from finite samples; sharp interior-eigenvalue constants beyond stated bounds; sharp analyzer conditioning in n>=3; statistical minimax sample complexity; unknown-speed adaptive optimality; T4 finite-rate oscillator transport, dynamic-phase subtraction, laboratory data, and novelty.

These are enough to close the deterministic rank-one T2/T3 foundation. They are not all theorems required for the broader physical programme. Calling the entire programme universally locked would be unsupported.

## Reproduction and provenance
Original attachments are included unchanged. New outputs use new filenames. Run rg_spectral_lock.py, rg_spectral_lock_validate.py, rg_nonuniform_alias_validate.py, and rg_spectral_additional_checks.py from the extracted directory. Dependencies: numpy, scipy, sympy. The main suite reads the supplied source to rerun its reviewed nonoptimizer sections; use the packaged original. The unmodified full original run hit the execution limit during optimization; no identical full rerun is claimed. The original source hash is 8311b4e513a0352a159bfd450603cda33e19b5f56860ea7f2e58530bda5d7848.

No hidden or external data, experimental observations, or empirical feasibility are asserted. The mathematical arguments are self-contained human-readable proofs, not machine-checked proofs or independent peer review. The package is an auditable first closure candidate for external checking.
