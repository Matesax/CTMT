"""Interior-line, repaired intensity modulus, and isolated hypothesis controls."""
import numpy as np,math,json
from pathlib import Path
import rg_spectral_lock as B

def run():
 rng=np.random.default_rng(611);interior=0;intensity=0
 for n in [3,6]:
  eig=np.array([-1.,0.,1.] if n==3 else [-3.,-2.,-1.,0.,1.,2.]);j=int(np.where(eig==0)[0][0])
  for _ in range(400):
   O,_=np.linalg.qr(rng.normal(size=(n,n)));A=O@np.diag(eig)@O.T;P=np.outer(O[:,j],O[:,j])
   e=rng.uniform(.0001,.49);Z=rng.normal(size=(n,n));Z=(Z+Z.T)/2;Z*=e/np.linalg.norm(Z,2)
   _,U=np.linalg.eigh(A+Z);Q=np.outer(U[:,j],U[:,j]);assert np.linalg.norm(P-Q,2)<=e/(1-e)+1e-10;interior+=1
 for d in np.linspace(0,1,101):
  t=(1+math.sqrt(max(0,1-d*d)))/2
  u=np.array([math.sqrt(t),math.sqrt(1-t)]);v=u*np.array([1.,-1.])
  P=np.outer(u,u);Q=np.outer(v,v);A=B.fullspark(2)
  assert abs(np.linalg.norm(P-Q,2)-d)<1e-8
  assert abs(np.linalg.norm((A@u)**2-(A@v)**2)-d)<1e-8;intensity+=1
 # Speed canary: exact same measured nodes, different continuous completions.
 aa=[0,math.pi/3,2*math.pi/3,math.pi]
 bb=[0,4*math.pi/3,5*math.pi/3,2*math.pi]
 assert all(np.allclose(np.outer(B.vec(a),B.vec(a)),np.outer(B.vec(b),B.vec(b))) for a,b in zip(aa,bb))
 out=B.cert([B.vec(a) for a in aa[:-1]],math.pi/3+.01,0)
 assert out['status']=='CERTIFIED' and out['parity']==-1 # wrong for B, whose speed bound was understated
 # Noise canary, both paths have valid speed but actual errors exceed declared zero.
 a,b,m=B.alias(6,math.pi/2-.2+.001,.1)
 # The exact midpoint has an orthogonal edge. Move within the common error-ball slack.
 angle=math.atan2(m[0,1],m[0,0])+.00025;m[0]=B.vec(angle)
 assert all(math.acos(np.clip(abs(m[i]@B.vec(t)),0,1))<=.1+1e-10 for path in [a,b] for i,t in enumerate(path[:-1]))
 out2=B.cert(m,math.pi/2-.2+.001,0)
 assert out2['status']=='CERTIFIED' and out2['parity'] in [-1,1] # wrong for one of the two truths
 assert B.cert([B.vec(0),B.vec(1),B.vec(2)],1.,0,closed=False)['status']=='UNRESOLVED'
 r=dict(interior_eigenline_bound_checks=interior,exact_repaired_2D_intensity_modulus_checks=intensity,
        isolated_speed_canary=True,isolated_noise_canary=True,open_path_domain_gate=True)
 Path('rg_spectral_additional_validation.json').write_text(json.dumps(r,indent=2));return r
if __name__=='__main__':print(json.dumps(run(),indent=2))
