"""Proof-backed core stress battery. Synthetic only; numpy/scipy. No formal verification."""
import numpy as np, math, json, itertools, hashlib, ast
from pathlib import Path
from scipy.optimize import linprog, minimize
PI=math.pi

def parity(v):
 d=np.array([v[i]@v[(i+1)%len(v)] for i in range(len(v))])
 return None if min(abs(d))<1e-10 else int(np.prod(np.sign(d)))
def vec(t,n=2):
 v=np.zeros(n);v[:2]=[math.cos(t),math.sin(t)];return v

def alias(N,s,alpha):
 """Explicit opposite-parity aliases, at and above the exact threshold."""
 assert N>=2 and N*s>=PI-1e-12 and s+2*alpha>=PI/2-1e-12
 t=min(s,PI/2);r=(PI-2*t)/2
 da=np.r_[-t,np.full(N-1,t/(N-1))]
 db=np.r_[t,np.full(N-1,(PI-t)/(N-1))]
 a=np.r_[0,np.cumsum(da)];b=np.r_[r,r+np.cumsum(db)]
 m=[]
 for x,y in zip(a[:-1],b[:-1]):
  u,w=vec(x),vec(y)
  if u@w<0:w=-w
  z=u+w;m.append(z/np.linalg.norm(z))
 return a,b,np.array(m)

def cert(v,s,alpha,closed=True):
 N=len(v)
 if not closed or N<2 or s<0 or not 0<=alpha<PI/2:return {'status':'UNRESOLVED'}
 if any(abs(np.linalg.norm(x)-1)>1e-8 for x in v):return {'status':'UNRESOLVED'}
 if N*s<PI-1e-12:return {'status':'CERTIFIED','parity':1,'reason':'global length prior'}
 h=parity(v)
 if h is None:return {'status':'UNRESOLVED'}
 theta=[math.acos(np.clip(abs(v[i]@v[(i+1)%N]),0,1)) for i in range(N)]
 if max(theta)+s+2*alpha<PI-1e-10:
  return {'status':'CERTIFIED','parity':h,'reason':'data-dependent edge lift bound'}
 return {'status':'UNRESOLVED'}

def top(M):
 _,U=np.linalg.eigh(M);v=U[:,-1];return np.outer(v,v)
def sharp(e,g):return math.sin(.5*math.asin(2*e/g))
def fullspark(n):
 # axes plus n-1 Vandermonde rows. Verified numerically in this battery.
 A=np.vstack([np.eye(n),np.array([[float(j)**k for k in range(n)] for j in range(1,n)])])
 return A/np.linalg.norm(A,axis=1)[:,None]
def reconstruct(v,A):
 I=v*v;obs=(A@v)**2;out=[]
 for signs in itertools.product([-1,1],repeat=len(v)):
  w=np.sqrt(I)*signs
  if np.max(abs((A@w)**2-obs))<1e-10:
   P=np.outer(w,w)
   if not any(np.linalg.norm(P-Q)<1e-8 for Q in out):out.append(P)
 return out

def run():
 rng=np.random.default_rng(20261105);checks=[]
 def check(name,ok,**data):
  assert bool(ok),name;checks.append(dict(name=name,passed=True,**data))
 # Re-execute supplied A,B,C,D,E without its expensive T2 optimizer, not an unchanged full rerun.
 supplied=Path('rg_universality_stress.py')
 if supplied.exists():
  text=supplied.read_text();start=text.index('# --------------------------------------------------------------- A/B for T2b')
  stop=text.index('# --------------------------------------------------------------- C necessity')
  tail=text[stop:];tail=tail[:tail.index('RES["source_sha256"]')]
  ns={'__file__':str(supplied)};exec(compile(text[:start]+tail,str(supplied),'exec'),ns)
  subset={k:v for k,v in ns['RES'].items() if k!='source_sha256'}
  Path('rg_supplied_axes_rerun.json').write_text(json.dumps(subset,indent=2,default=float))
  check('supplied nonoptimizer axes rerun',True,axes=list(subset),
    note='Labels retained as historical output, audited in report; not universal proof.')
 # Exact general extremal eigenline modulus and attainment.
 attain=0;maxerr=0
 for n in [2,3,6]:
  for g in [.001,.2,1,3]:
   for q in [.001,.03,.1,.3,.49]:
    e=q*g;theta=.5*math.asin(2*q);c,s=math.cos(2*theta),math.sin(2*theta)
    A=np.diag([g/2,-g/2]+[-3*g]*(n-2));B=A.copy()
    B[:2,:2]=(g/2)*c*np.array([[c,s],[s,-c]])
    err=abs(np.linalg.norm(B-A,2)-e);maxerr=max(maxerr,err)
    assert err<1e-10 and abs(np.linalg.norm(top(A)-top(B),2)-sharp(e,g))<1e-10;attain+=1
 check('sharp extremal eigenline bound attained',True,cases=attain,max_identity_error=maxerr)
 # adversarial numerical searches reduced to 36 searches, plus 1800 random perturbations.
 searches=0;ratio=0;randomcases=0
 for n in [2,3,6]:
  for _ in range(600):
   g=1.;A=np.diag([0.,-g]+[-2.]*(n-2));e=rng.uniform(.001,.49)
   Z=rng.normal(size=(n,n));Z=(Z+Z.T)/2;Z*=e/np.linalg.norm(Z,2)
   d=np.linalg.norm(top(A+Z)-top(A),2);assert d<=sharp(e,g)+1e-10;randomcases+=1
 for n in [2,3,4]:
  for e in [.1,.3,.49]:
   A=np.diag([.5,-.5]+[-2.]*(n-2));iu=np.triu_indices(n)
   def obj(x):
    E=np.zeros((n,n));E[iu]=x;E=E+E.T-np.diag(np.diag(E));norm=np.linalg.norm(E,2)
    if norm:E*=e/norm
    return -np.linalg.norm(top(A+E)-top(A),2)
   for _ in range(4):
    z=minimize(obj,rng.normal(size=len(iu[0])),method='Nelder-Mead',options={'maxiter':250})
    d=-z.fun;assert d<=sharp(e,1)+1e-8;ratio=max(ratio,d/sharp(e,1));searches+=1
 check('sharp bound random and optimizer attacks',True,random_cases=randomcases,optimizer_searches=searches,max_ratio=ratio)
 # aliases explicit, dimensions 2,3,6, with endpoints/noise/speed verified.
 aliases=0;worstnoise=0;globalcounter=0
 for N in range(2,13):
  for alpha in [0,.05,.1,.2,.3,.6,.78]:
   threshold=max(PI/N,PI/2-2*alpha)
   for slack in [0.,.001,.1]:
    s=threshold+slack;a,b,m=alias(N,s,alpha)
    assert max(abs(np.diff(a)))<=s+1e-10 and max(abs(np.diff(b)))<=s+1e-10
    assert abs(a[-1]-a[0])<1e-10 and abs(b[-1]-b[0]-PI)<1e-10
    for n in [2,3,6]:
     mm=np.pad(m,((0,0),(0,n-2)))
     errors=[math.acos(np.clip(abs(mm[i]@vec(t,n)),0,1)) for path in [a,b] for i,t in enumerate(path[:-1])]
     assert max(errors)<=alpha+3e-8;worstnoise=max(worstnoise,max(errors)-alpha)
     # Cert must not output a parity for both compatible truths.
     assert cert(mm,s,alpha)['status']=='UNRESOLVED';aliases+=1
   s=PI/2-2*alpha
   if N*s<PI-1e-8:globalcounter+=1
 check('explicit noisy aliases and corrected global threshold',True,aliases=aliases,max_noise_roundoff=worstnoise,
       local_threshold_not_sufficient_for_alias=globalcounter)
 # LP independent feasibility at/below/above corrected threshold (reuse supplied function).
 lp=0
 if supplied.exists():
  fn=ns['alias_feasible']
  for N in [2,3,4,6,9]:
   for alpha in [0,.1,.3,.6]:
    t=max(PI/N,PI/2-2*alpha)
    assert not fn(t-1e-5,alpha,N)[0]
    assert fn(t+1e-5,alpha,N)[0];lp+=2
 check('independent LP threshold attacks',True,feasibility_queries=lp)
 # Nonplanar closed lifts: periodic SO rotations, n=3/6.
 sound=0;posterior=0;invariance=0
 for n in [2,3,6]:
  for _ in range(400):
   k=int(rng.integers(-3,4));N=32;alpha=float(rng.uniform(0,.12));t=np.arange(N)*2*PI/N
   O,_=np.linalg.qr(rng.normal(size=(n,n)));vs=[]
   for tt in t:
    v=vec(k*tt/2,n)
    if n>2:
     z=.2*math.sin(tt);Q=np.eye(n);Q[0,0]=Q[2,2]=math.cos(z);Q[0,2]=-math.sin(z);Q[2,0]=math.sin(z);v=Q@v
    w=rng.normal(size=n);w-=v*(w@v);w/=np.linalg.norm(w);err=rng.uniform(0,alpha)
    vs.append((math.cos(err)*v+math.sin(err)*w)*rng.choice([-1,1]))
   s=(abs(k)/2+(.2 if n>2 else 0))*2*PI/N
   out=cert(vs,s,alpha);assert out['status']=='CERTIFIED' and out['parity']==(-1)**k;sound+=1
   for transformed in [[O@v for v in vs],[np.r_[v,0,0] for v in vs],vs[7:]+vs[:7],list(reversed(vs))]:
    assert cert(transformed,s,alpha)['parity']==out['parity'];invariance+=1
 # Explicit outside-uniform but data-dependent identifiable case.
 N=6;s=1.4;alpha=.1;vs=[vec(0)]*N
 assert s+2*alpha>PI/2 and cert(vs,s,alpha)['parity']==1;posterior+=1
 check('sound nonplanar transfer and invariance',True,certified=sound,invariance_checks=invariance,
       data_dependent_beyond_uniform_threshold=posterior)
 # Matrix noise -> calibrated global gap/speed -> parity.
 pipeline=0;abstain=0
 for n in [2,3,6]:
  for k in [0,1,2,3]:
   for delta in [.001,.03,.1,.25,.49,.7]:
    N=32;ts=np.arange(N)*2*PI/N;V=[];gaps=[]
    for t in ts:
     u=vec(k*t/2,n);A=np.outer(u,u)-.5*np.eye(n)
     Z=rng.normal(size=(n,n));Z=(Z+Z.T)/2;Z*=delta/np.linalg.norm(Z,2)
     w,U=np.linalg.eigh(A+Z);V.append(U[:,-1]);gaps.append(w[-1]-w[-2])
    if min(gaps)<=2*delta:abstain+=1;continue
    alpha=max(math.asin(min(1,delta/(g-delta))) for g in gaps)
    out=cert(V,abs(k)*PI/N,alpha)
    if out['status']=='CERTIFIED':assert out['parity']==(-1)**k;pipeline+=1
    else:abstain+=1
 check('matrix-to-angle-to-parity with genuine abstentions',True,certified=pipeline,abstained=abstain)
 # Calibrated analyzer channel repair: axes plus n-1 generic rows.
 reconstruction=0;supports=0;minminor=1.
 for n in [2,3,6]:
  A=fullspark(n)
  for rows in itertools.combinations(range(2*n-1),n):
   d=abs(np.linalg.det(A[list(rows)]));assert d>1e-12;minminor=min(minminor,d)
  for mask in range(1,2**n):
   for _ in range(3):
    v=rng.normal(size=n);v*=np.array([(mask>>i)&1 for i in range(n)]);v/=np.linalg.norm(v)
    R=reconstruct(v,A)
    assert len(R)==1 and np.linalg.norm(R[0]-np.outer(v,v))<1e-8;reconstruction+=1
   supports+=1
 # Any 2n-2 rows: split into n-1 and n-1, use null vectors to build aliases.
 analyzer_alias=0
 for n in [2,3,6]:
  A=fullspark(n)[:-1];S=A[:n-1];T=A[n-1:]
  _,_,vh=np.linalg.svd(S,full_matrices=True);x=vh[-1]
  _,_,vh=np.linalg.svd(T,full_matrices=True);y=vh[-1]
  u=x+y;v=x-y
  assert np.allclose((A@u)**2,(A@v)**2,atol=1e-10)
  assert abs(np.linalg.norm(u)-np.linalg.norm(v))<1e-10
  u/=np.linalg.norm(u);v/=np.linalg.norm(v)
  assert np.linalg.norm(np.outer(u,u)-np.outer(v,v))>1e-5;analyzer_alias+=1
 check('minimal fixed intensity analyzers with all supports',True,reconstructions=reconstruction,supports=supports,
       lower_bound_aliases=analyzer_alias,minimum_fullspark_minor=minminor,
       additional_channels='n-1 with fixed coordinate intensities; 1 in 2D, 2 in 3D, 5 in 6D')
 # Gap is not a premise of a directly supplied eigenline theorem.
 vs=[vec(t/2) for t in np.arange(16)*2*PI/16]
 assert cert(vs,PI/16,0)['parity']==-1
 check('hypothesis typing and task-domain gates',True,
       gap='required for deriving eigenline from matrices, not intrinsic parity of a supplied line loop',
       closure='open path has no loop parity, not a false defined truth',
       unbounded_speed='sample aliases',understated_noise='explicit common-measurement alias',
       arbitrary_reparametrization='must transform interval length budgets; cyclic shift alone is not arbitrary reparametrization')
 return dict(seed=20261105,passed_groups=len(checks),checks=checks,all_data_synthetic=True,
  proof_status='Self-contained arguments in report; no formal verification, novelty audit or physical validation.',
  original_full_rerun='timed out during optimizer; nonoptimizer axes rerun separately; original files preserved')
if __name__=='__main__':
 r=run();Path('rg_spectral_lock_results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
