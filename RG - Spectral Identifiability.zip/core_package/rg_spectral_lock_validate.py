"""Secondary audit: exact aliases, exact minors, nonuniform transport, task controls."""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import numpy as np, sympy as S, json, math
import rg_spectral_lock as B

def run():
 exact=0
 for N in range(2,21):
  for alpha in [F(0),F(1,100),F(1,20),F(1,10),F(1,5),F(1,4),F(1,3)]:
   s=max(F(1,N),F(1,2)-2*alpha);t=min(s,F(1,2));r=(1-2*t)/2
   da=[-t]+[t/(N-1)]*(N-1);db=[t]+[(1-t)/(N-1)]*(N-1)
   aa=[F(0)];bb=[r]
   for x,y in zip(da,db):aa.append(aa[-1]+x);bb.append(bb[-1]+y)
   assert aa[-1]==aa[0] and bb[-1]-bb[0]==1
   assert max(map(abs,da))<=s and max(map(abs,db))<=s
   for x,y in zip(aa[:-1],bb[:-1]):
    d=x-y;dist=min(abs(d-k) for k in [-2,-1,0,1,2]);assert dist<=2*alpha
   exact+=1
 # Exact full spark for the concrete analyzer matrices (normalization irrelevant).
 minors=0
 for n in [2,3,6]:
  A=S.eye(n).col_join(S.Matrix([[j**k for k in range(n)] for j in range(1,n)]))
  for rows in combinations(range(2*n-1),n):assert A[list(rows),:].det()!=0;minors+=1
 # Nonuniform, smoothly reparametrized loops with correctly transformed edge budgets.
 rng=np.random.default_rng(131);nonuniform=0
 for n in [2,3,6]:
  for k in [-3,-1,0,1,2]:
   for _ in range(20):
    N=32;tt=np.r_[0,np.sort(rng.uniform(0,2*np.pi,N-1)),2*np.pi]
    u=tt+.2*np.sin(tt);budgets=abs(k)/2*np.diff(u);alpha=.01
    vs=[]
    for angle in k*u[:-1]/2:
     v=B.vec(angle,n);w=rng.normal(size=n);w-=v*(w@v);w/=np.linalg.norm(w)
     e=rng.uniform(-alpha,alpha);vs.append((np.cos(e)*v+np.sin(e)*w)*rng.choice([-1,1]))
    # Independent edgewise sufficient rule, allowing nonuniform spacing.
    angles=np.array([np.arccos(np.clip(abs(vs[i]@vs[(i+1)%N]),0,1)) for i in range(N)])
    if sum(budgets)<np.pi-1e-10:out=1
    elif np.all(angles+budgets+2*alpha<np.pi-1e-10):out=B.parity(vs)
    else:continue
    assert out==(-1)**k;nonuniform+=1
 # Stronger-than-uniform abstention counterexample: exact planar interval lifts.
 # For constant observed line, true nodes in alpha-balls. Any sign switch needs pi-2alpha.
 assert 1.4+2*.1>np.pi/2 and 1.4<np.pi-2*.1
 # Missing gap is not an intrinsic parity obstruction: supply line loop with A(t)=0.
 vs=[B.vec(t/2) for t in np.arange(32)*2*np.pi/32]
 assert B.cert(vs,np.pi/32,0)['parity']==-1
 # Explicit n=3 one-analyzer collision and two-analyzer reconstruction.
 a=np.array([1.,1.,1.]);u=np.array([1.,-1.,2.]);v=np.array([1.,-1.,-2.]);u/=np.linalg.norm(u);v/=np.linalg.norm(v)
 assert np.allclose(u*u,v*v) and abs((a@u)**2-(a@v)**2)<1e-12
 assert np.linalg.norm(np.outer(u,u)-np.outer(v,v))>.5
 assert len(B.reconstruct(u,B.fullspark(3)))==1
 # T2 finite-epsilon counterexample to eps/g alone, analytic attainment.
 q=.3;theta=.5*math.asin(2*q);assert math.sin(theta)>q
 # Source provenance and original hash match.
 digest=__import__('hashlib').sha256(Path('rg_universality_stress.py').read_bytes()).hexdigest()
 original=json.loads(Path('rg_universality_stress_results.json').read_text())
 assert digest==original['source_sha256']
 return dict(exact_rational_alias_contracts=exact,exact_nonzero_analyzer_minors=minors,
  nonuniform_reparametrized_certificates=nonuniform,
  supplied_source_hash_matches_recorded_results=True,
  epsilon_over_gap_counterexample=dict(epsilon_over_gap=q,projector_error=math.sin(theta)),
  three_dimensional_one_extra_analyzer_alias=True,
  data_specific_abstention_not_necessary=True,
  note='Independent formulations within synthetic models; not human peer review, formal verification or experiment.')
if __name__=='__main__':
 r=run();Path('rg_spectral_lock_validation.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
