#!/usr/bin/env python3
"""
RG groupoid of resolution: battery GR01-GR08
============================================
  GR01 the resolved-null coupling C vanishes identically under the whitening (Cencov) metric; it measures the
       relative position of a declared protocol metric g and the noise metric Sigma^-1 (N_g vs N_{Sigma^-1})
  GR02 C != 0 iff the g-orthogonal projection onto R is not sufficient; the lost Fisher information equals the
       sector mutual information (just-identified case): the coupling theorem is a garbling statement (data processing)
  GR03 two different nulls: the latent kernel V = ker J (the kernel groupoid) is law-intrinsic; the observation
       null N_g depends on g and changes with Sigma_N while the kernel groupoid does not
  GR04 atlas over a varying operating point: protocol-metric invariants tau_g(theta) vary, so no Aut-valued transition
       exists between distinct points (the 'principal Aut(G)-bundle' exists only on level sets of tau); the whitened
       type (r,q) is constant: an O(r) x O(q)-structure always exists, and variation is carried by the Fisher tensor
  GR05 jet isotropy is not global symmetry: every rotation of the whitened resolved sector is a symmetry of the 1-jet,
       but for a nonlinear law it does not integrate to an element of Stab (second-order mismatch); for a linear law it does
  GR06 edge certification: a clean loop product does not certify edges (D^-1 D = I); admissible edges with Cech defect
       Omega = -I; admissible holonomy bounded under iteration, inadmissible defect amplifies
  GR07 H-task changes observable holonomy: Gaussian curvature of SLD and BKM metrics on a qubit slice differ, so the
       Levi-Civita transport of the selected natural metric is task-relative
  GR08 H-cov changes latent holonomy: same law, two declared covariances, different vertical holonomy of a closed
       observed loop

Run:  python3 rg_groupoid_attack.py [--seed 20261005] [--out FILE] [--canary]
"""
import argparse, json, math, sys, time
import numpy as np

RESULTS, MUT = [], {}


def f_(x): return float(np.round(float(x), 12))


def _finite(o):
    if isinstance(o, dict): return all(_finite(v) for v in o.values())
    if isinstance(o, (list, tuple)): return all(_finite(v) for v in o)
    if isinstance(o, float): return math.isfinite(o)
    return True


def register(aid, naive, keep, passed, ev, verdict):
    if not _finite(ev): passed, verdict = False, "NONFINITE"
    RESULTS.append(dict(id=aid, naive_claim=naive, rg_claim=keep, passed=bool(passed), verdict=verdict, evidence=ev))
    print(f"[{'PASS' if passed else 'FAIL'}] {aid} {verdict:16s} {keep[:84]}")


def spd(rng, m, cond=1.0):
    L = rng.normal(size=(m, m)); return L@L.T + cond*np.eye(m)


def msqrt(A, p=0.5):
    w, U = np.linalg.eigh(A); return (U*w**p)@U.T


def adapted_frame(g, J, rng):
    """g-orthonormal frame whose first r columns span R = Im J."""
    m, r = J.shape; gh, ghi = msqrt(g, 0.5), msqrt(g, -0.5)
    Q, _ = np.linalg.qr(np.c_[gh@J, rng.normal(size=(m, m-r))])
    return ghi@Q


def blocks(S, g, J, rng):
    r = J.shape[1]; F = adapted_frame(g, J, rng); Fi = np.linalg.inv(F); Sf = Fi@S@Fi.T
    return Sf[:r, :r], Sf[r:, r:], Sf[:r, r:], F


# ======================================================================= checks
def GR01_whitening(rng):
    cw, cg, angle_link = 0.0, [], 0.0
    for _ in range(200):
        m, r = 6, 2; J = rng.normal(size=(m, r)); S = spd(rng, m)
        cw = max(cw, float(np.linalg.norm(blocks(S, np.linalg.inv(S), J, rng)[2])))
        g = MUT.get("gr01_g", None)
        g = np.eye(m) if g is None else g(S)
        _, _, C, _ = blocks(S, g, J, rng); cg.append(float(np.linalg.norm(C)))
        # N_g vs N_{S^-1}: C = 0 iff the two complements coincide
        Ng = np.linalg.svd(J.T@g)[2][r:].T; Ns = np.linalg.svd(J.T@np.linalg.inv(S))[2][r:].T
        Qg, _ = np.linalg.qr(Ng); Qs, _ = np.linalg.qr(Ns)
        dist = float(np.linalg.norm(Qg@Qg.T-Qs@Qs.T, 2))
        angle_link = max(angle_link, abs((cg[-1] < 1e-9)-(dist < 1e-9)))
    passed = cw < 1e-12 and np.median(cg) > 0.1 and angle_link == 0
    register("GR01", "The resolved-null coupling C is the primary law-intrinsic invariant of resolution geometry.",
             "Under the whitening (Cencov) metric C vanishes identically. C is the relative position of a declared "
             "protocol metric g and the noise metric Sigma^-1: C = 0 iff the g-null and the statistical null coincide.",
             passed, dict(max_C_whitening=f_(cw), median_C_protocol_metric=f_(np.median(cg)), link_violations=int(angle_link)),
             "FALSIFIED-naive")


def GR02_sufficiency(rng):
    worst_suff, worst_id, gaps = 0.0, 0.0, []
    for _ in range(200):
        m, r = 5, 2; J = rng.normal(size=(m, r)); S = spd(rng, m); g = np.eye(m)
        Ifull = J.T@np.linalg.inv(S)@J
        # g-orthogonal projection onto R (resolved-only data), and Sigma^-1-orthogonal projection
        for metric, store in ((g, "g"), (np.linalg.inv(S), "w")):
            P = J@np.linalg.solve(J.T@metric@J, J.T@metric)                 # projector onto R along metric-null
            Z = P; JZ = Z@J; SZ = Z@S@Z.T
            Iz = JZ.T@np.linalg.pinv(SZ)@JZ
            if store == "w": worst_suff = max(worst_suff, float(np.linalg.norm(Iz-Ifull)/np.linalg.norm(Ifull)))
            else: gaps.append(float(np.linalg.norm(Ifull-Iz)/np.linalg.norm(Ifull)))
        # just-identified identity: 1/2 log det(Vres/Vfull) = mutual information between sectors (g = I frame)
        SR, SN, C, F = blocks(S, g, J, rng)
        JR = (np.linalg.inv(F)@J)[:r]
        Vres = np.linalg.inv(JR.T@np.linalg.inv(SR)@JR); Vfull = np.linalg.inv(JR.T@np.linalg.inv(SR-C@np.linalg.inv(SN)@C.T)@JR)
        Ct = msqrt(SR, -0.5)@C@msqrt(SN, -0.5); MI = -0.5*math.log(np.linalg.det(np.eye(r)-Ct@Ct.T))
        worst_id = max(worst_id, abs(0.5*math.log(np.linalg.det(Vres)/np.linalg.det(Vfull))-MI))
    passed = worst_suff < 1e-9 and np.median(gaps) > 1e-2 and worst_id < 1e-9
    register("GR02", "Coupling-aware efficiency is a new property of the resolution geometry.",
             "It is data processing: the Sigma^-1-orthogonal projection onto R is sufficient (no loss), the g-orthogonal one "
             "is a garbling that loses information iff C != 0, and the loss equals the sector mutual information.",
             passed, dict(whitened_projection_loss=f_(worst_suff), median_g_projection_loss=f_(np.median(gaps)),
                          efficiency_information_identity_err=f_(worst_id)), "FALSIFIED-naive")


def GR03_two_nulls(rng):
    kchange, nchange = 0.0, []
    for _ in range(200):
        m, n = 5, 4; J = rng.normal(size=(m, 2))@rng.normal(size=(2, n))      # rank 2: latent kernel dim 2
        V = np.linalg.svd(J)[2][2:].T
        S1 = spd(rng, m); S2 = S1.copy()
        Ng = np.linalg.svd(J.T)[2][2:].T if False else None
        # change Sigma only on the g-null (g = I) block: law-family kernel unchanged
        U = np.linalg.svd(J)[0]; R, N = U[:, :2], U[:, 2:]
        D = spd(rng, 3); S2 = S1 + N@D@N.T
        G1, G2 = J.T@np.linalg.inv(S1)@J, J.T@np.linalg.inv(S2)@J
        kchange = max(kchange, float(np.linalg.norm(G1@V)+np.linalg.norm(G2@V)))       # V is the radical of both
        # observation null under g = I vs g = S^-1: differ
        Nw = np.linalg.svd(J.T@np.linalg.inv(S2))[0]
        Qa, _ = np.linalg.qr(N); Pw = np.linalg.svd(np.linalg.inv(S2)@J, full_matrices=True)[0][:, 2:]
        Qb, _ = np.linalg.qr(Pw); nchange.append(float(np.linalg.norm(Qa@Qa.T-Qb@Qb.T, 2)))
    passed = kchange < 1e-9 and np.median(nchange) > 0.1
    register("GR03", "The null sector N is the observational null of RG.",
             "Two nulls must not be confused: the latent kernel V = ker J (radical of every natural metric, the tangent of "
             "the kernel groupoid) is law-intrinsic and unchanged by Sigma_N; the observation null N depends on the declared "
             "metric (median distance between g-null and whitened null 0.1+).",
             passed, dict(latent_kernel_radical_defect=f_(kchange), median_observation_null_shift=f_(np.median(nchange))), "FALSIFIED-naive")


def GR04_atlas(rng):
    """family J(theta), Sigma(theta) along a path; tau_g = (spec Sigma_R, spec Sigma_N, |C|) in the g = I frame."""
    m, r = 5, 2; J0, J1 = rng.normal(size=(m, r)), rng.normal(size=(m, r)); S0, S1 = spd(rng, m), spd(rng, m)
    taus, wtypes = [], set()
    for t in np.linspace(0, 1, 11):
        J = (1-t)*J0+t*J1; S = (1-t)*S0+t*S1
        SR, SN, C, _ = blocks(S, np.eye(m), J, rng)
        taus.append(np.r_[np.sort(np.linalg.eigvalsh(SR)), np.sort(np.linalg.eigvalsh(SN)), np.linalg.svd(C, compute_uv=False)])
        SRw, SNw, Cw, _ = blocks(S, np.linalg.inv(S), J, rng)
        wtypes.add((int(np.round(np.trace(SRw))), int(np.round(np.trace(SNw))), bool(np.linalg.norm(Cw) < 1e-9)))
    steps = [float(np.linalg.norm(taus[i+1]-taus[i])) for i in range(10)]
    passed = min(steps) > 1e-3 and wtypes == {(r, m-r, True)}
    register("GR04", "Charts at different operating points glue into a principal Aut(G)-bundle (Atlas Globalization).",
             "Only on level sets of the protocol-metric invariant tau_g, which varies continuously along the base (no "
             "admissible transition between distinct points). The whitened type (r, q) is constant, so an O(r) x O(q) "
             "structure always exists; variation is carried by the natural Fisher tensor and its connection.",
             passed, dict(min_tau_step=f_(min(steps)), whitened_types=sorted(list(map(list, wtypes)))), "FALSIFIED-naive")


def GR05_jet_vs_global(rng):
    """mu(t) = (t1, t2, k t1 t2), Sigma = I. At t0, the whitened resolved sector is R = span(dmu); a rotation L of R
    (fixing N) preserves the 1-jet. Does it map the law family to itself (as a set of laws)? Linear k = 0: yes."""
    def mu(t, k): return np.array([t[0], t[1], k*t[0]*t[1]])
    out = {}
    for k in (0.0, 0.8):
        t0 = np.array([0.4, -0.3]); J = np.array([[1, 0], [0, 1], [k*t0[1], k*t0[0]]])
        Q, _ = np.linalg.qr(np.c_[J, np.array([0, 0, 1.0])]); R, N = Q[:, :2], Q[:, 2:]
        th = 0.7; Rot = np.array([[math.cos(th), -math.sin(th)], [math.sin(th), math.cos(th)]])
        L = R@Rot@R.T + N@N.T                                                   # isometry of Sigma = I preserving R, N
        jet_ok = np.linalg.norm(L@J - J@np.linalg.lstsq(J, L@J, rcond=None)[0]) < 1e-12
        # does L map image points mu(t0 + s) (relative to mu(t0)) onto the image?
        worst = 0.0
        for s in np.linspace(-0.2, 0.2, 9):
            for u in np.linspace(-0.2, 0.2, 9):
                y = mu(t0, k) + L@(mu(t0+np.array([s, u]), k)-mu(t0, k))
                # distance to the image surface: solve for t with first two coords (graph over t1,t2)
                tt = y[:2]; worst = max(worst, abs(y[2]-mu(tt, k)[2]))
        out[str(k)] = dict(jet_isotropy=bool(jet_ok), off_image=f_(worst))
    passed = out["0.0"]["jet_isotropy"] and out["0.8"]["jet_isotropy"] and out["0.0"]["off_image"] < 1e-12 and out["0.8"]["off_image"] > 1e-3
    register("GR05", "Local automorphisms of (R, N, Sigma) are symmetries of the observation system.",
             "They are isotropies of the 1-jet. They integrate to elements of Stab for a linear law, but not for a nonlinear "
             "one: the rotated image leaves the law family at second order. Global symmetry is Gamma, computed from the law.",
             passed, dict(by_curvature=out), "FALSIFIED-naive")


def GR06_edges(rng):
    m = 6; S = spd(rng, m); Sh = msqrt(S); Shi = msqrt(S, -0.5)
    D = Sh@np.diag([1, 1, 1, 2, 2, 2.0])@Shi                                    # covariance non-isometry (null inflation)
    resid = float(np.linalg.norm(D@S@D.T-S)/np.linalg.norm(S)); cancel = float(np.linalg.norm(np.linalg.inv(D)@D-np.eye(m)))
    Q, _ = np.linalg.qr(rng.normal(size=(m, m))); A = Sh@Q@Shi                  # admissible isometry
    adm = float(np.linalg.norm(A@S@A.T-S)/np.linalg.norm(S))
    H = Sh@(-np.eye(m))@Shi; omega = H                                            # admissible -I cocycle defect
    norms_ok = [float(np.linalg.norm(np.linalg.matrix_power(A, k))) for k in (1, 8, 32)]
    norms_bad = [float(np.linalg.norm(np.linalg.matrix_power(D, k))) for k in (1, 8, 32)]
    passed = resid > 0.5 and cancel < 1e-12 and adm < 1e-12 and np.linalg.norm(H@S@H.T-S) < 1e-9 and \
        max(norms_ok)/min(norms_ok) < 50 and norms_bad[-1]/norms_bad[0] > 1e6
    register("GR06", "A clean loop product certifies the path.",
             "No (retained from Atlas Globalization): D^-1 D = I with both edges inadmissible; admissible edges can carry a "
             "Cech defect -I; admissible holonomy stays bounded under iteration, inadmissible defects amplify.",
             passed, dict(edge_residual=f_(resid), cancellation=f_(cancel), admissible_residual=f_(adm),
                          admissible_norms=[f_(v) for v in norms_ok], defect_norms=[f_(v) for v in norms_bad]), "HOLDS")


def petz_metric(rho, A, f):
    w, U = np.linalg.eigh(rho); z = U.conj().T@A@U
    return float(sum(abs(z[i, j])**2/(w[j]*f(w[i]/w[j])) for i in range(2) for j in range(2)))


def gauss_curvature(gfun, a, b, h=1e-3):
    """Brioschi formula with finite differences for metric g(a,b) = [[E,F],[F,G]]."""
    def EFG(x, y): g = gfun(x, y); return g[0, 0], g[0, 1], g[1, 1]
    E, F, G = EFG(a, b)
    d = lambda i, x, y: (np.array(EFG(x+h*(i == 0), y+h*(i == 1)))-np.array(EFG(x-h*(i == 0), y-h*(i == 1))))/(2*h)
    Ea, Fa, Ga = d(0, a, b); Eb, Fb, Gb = d(1, a, b)
    Ebb = (EFG(a, b+h)[0]-2*E+EFG(a, b-h)[0])/h**2; Gaa = (EFG(a+h, b)[2]-2*G+EFG(a-h, b)[2])/h**2
    Fab = (EFG(a+h, b+h)[1]-EFG(a+h, b-h)[1]-EFG(a-h, b+h)[1]+EFG(a-h, b-h)[1])/(4*h*h)
    M1 = np.array([[-Ebb/2+Fab-Gaa/2, Ea/2, Fa-Eb/2], [Fb-Ga/2, E, F], [Gb/2, F, G]])
    M2 = np.array([[0, Eb/2, Ga/2], [Eb/2, E, F], [Ga/2, F, G]])
    return (np.linalg.det(M1)-np.linalg.det(M2))/(E*G-F*F)**2


def GR07_task_holonomy(rng):
    sx = np.array([[0, 1], [1, 0]], complex); sz = np.array([[1, 0], [0, -1]], complex)
    fsld = lambda t: (1+t)/2
    fbkm = lambda t: 1.0 if abs(t-1) < 1e-9 else (t-1)/math.log(t)
    fsel = MUT.get("gr07_same_task")
    def gfun(f):
        def g(a, b):
            rho = (np.eye(2)+a*sz+b*sx)/2; T = [sz/2, sx/2]
            G = np.zeros((2, 2))
            for i in range(2):
                for j in range(2):
                    G[i, j] = 0.25*(petz_metric(rho, T[i]+T[j], f)-petz_metric(rho, T[i]-T[j], f))
            return G
        return g
    pts = [(0.3, 0.1), (0.5, -0.2), (0.1, 0.6)]
    Ks = {name: [f_(gauss_curvature(gfun(f), a, b)) for a, b in pts] for name, f in
          (("SLD", fsld), ("BKM", fbkm if not fsel else fsld))}
    gap = max(abs(x-y) for x, y in zip(Ks["SLD"], Ks["BKM"]))
    passed = gap > 0.05
    register("GR07", "Observable transport on the quotient is one object, independent of the quantum task.",
             "No: the Levi-Civita transport of the selected natural metric has curvature (hence small-loop holonomy) that "
             "differs between SLD (estimation) and BKM (Stein testing) on the same state slice. H-task changes the holonomy.",
             passed, dict(gaussian_curvature=Ks, max_gap=f_(gap)), "FALSIFIED-naive")


def GR08_cov_holonomy(rng):
    F = lambda x: np.array([x[0]+0.5*x[2]**2, x[1]+0.8*x[0]*x[2]])
    DF = lambda x: np.array([[1, 0, x[2]], [0.8*x[2], 1, 0.8*x[0]]])
    def hol(P, side=0.02, steps=300):
        x = np.array([0.2, -0.1, 0.4]); x0 = x.copy()
        corners = [np.array(c, float) for c in ((0, 0), (side, 0), (side, side), (0, side), (0, 0))]
        for c0, c1 in zip(corners[:-1], corners[1:]):
            dy = (c1-c0)/steps
            for _ in range(steps):
                v = lambda z: P@DF(z).T@np.linalg.solve(DF(z)@P@DF(z).T, dy)
                k1 = v(x); k2 = v(x+k1/2); k3 = v(x+k2/2); k4 = v(x+k3); x = x+(k1+2*k2+2*k3+k4)/6
        return float(np.linalg.norm(x-x0))
    h1, h2 = hol(np.eye(3)), hol(np.diag([1.0, 2.0, 0.5]))
    passed = abs(h1-h2)/h1 > 0.05 and h1 > 1e-6
    register("GR08", "Latent holonomy is a property of the observation system.",
             "It is a property of the declared covariance (H-cov): identical laws, two declared P, different vertical "
             "holonomy of the same closed observed loop.", passed, dict(holonomy_P1=f_(h1), holonomy_P2=f_(h2)), "FALSIFIED-naive")


ATTACKS = [GR01_whitening, GR02_sufficiency, GR03_two_nulls, GR04_atlas, GR05_jet_vs_global, GR06_edges, GR07_task_holonomy,
           GR08_cov_holonomy]


def run_all(seed):
    for a in ATTACKS:
        rng = np.random.default_rng([seed, ATTACKS.index(a)])
        try: a(rng)
        except Exception as ex: register(a.__name__[:4], "?", f"EXCEPTION {ex!r}", False, {}, "ERROR")


def canary(seed):
    muts = [("GR01", {"gr01_g": lambda S: np.linalg.inv(S)}),        # protocol metric = whitening: no coupling to find
            ("GR07", {"gr07_same_task": True})]                        # same task twice: no holonomy gap
    ok = True
    for tgt, m in muts:
        RESULTS.clear(); MUT.clear(); MUT.update(m); print(f"--- canary {tgt}: {list(m)}")
        a = next(x for x in ATTACKS if x.__name__.startswith(tgt))
        try: a(np.random.default_rng([seed, ATTACKS.index(a)])); caught = not RESULTS[-1]["passed"]
        except Exception as ex: print(f"    exception {ex!r} (not a clean catch)"); caught = False
        ok &= caught; print(f"    {'CAUGHT' if caught else 'NOT CAUGHT'}")
    MUT.clear(); print("CANARY:", "all caught" if ok else "BATTERY TOO WEAK"); return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--seed", type=int, default=20261005)
    ap.add_argument("--out", default="rg_groupoid_results.json"); ap.add_argument("--canary", action="store_true")
    a = ap.parse_args()
    if a.canary: sys.exit(canary(a.seed))
    t0 = time.time(); print(f"RG groupoid battery, seed {a.seed}\n"); run_all(a.seed)
    n = sum(r["passed"] for r in RESULTS)
    summ = dict(seed=a.seed, n_checks=len(RESULTS), n_pass=n, runtime_s=round(time.time()-t0, 1))
    json.dump(dict(summary=summ, results=RESULTS), open(a.out, "w"), indent=2,
              default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print(f"\n{n}/{len(RESULTS)} pass."); sys.exit(0 if n == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
