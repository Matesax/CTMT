# RG - The Groupoid of Resolution: battery GR01-GR08

    python3 rg_groupoid_attack.py            # seed 20261005
    python3 rg_groupoid_attack.py --canary   # GR01, GR07 sabotaged; each must fail

8/8 on seeds 20261005, 1, 42, 777, 2026; canary 2/2.
Coupling vanishes under whitening; coupling efficiency = data processing; two nulls; atlas types vary (O(r)xO(q) reduction);
jet isotropy does not integrate; edge certification; H-task changes observable holonomy (SLD K=+1 vs BKM K<0); H-cov changes latent holonomy.
