"""Five QM locks for the RG quantum print.
L1  Hamiltonian identification: (a) minimal uniform samples for M Bohr frequencies from one trace = 3M+1, sharp alias at
    3M (palindromic Prony family, roots stay unimodular); (b) local identifiability rank of H from one generic probe;
    symmetric probes lose exactly the symmetry directions (null).
L2  Petz modulus: recovery error vs relative-entropy gap; error <= 2 sqrt(1 - e^-gap) (no violation for the plain Petz map);
    error ~ gap^(1/2) along a near-sufficient family (sharp exponent).
L3  task-declared metrics: SLD = optimal measured Fisher (estimation); BKM = Hessian of relative entropy (thermodynamics);
    WY = skew information on unitary orbits.
L4  minimal environment for non-Markovian memory: dilation dimension >= max_t Choi rank; achieved in the exchange model.
L5  generator forms for d = 3: antiunitary symmetries fail extension; Stone generator Hermitian; GKLS criterion
    (conditional complete positivity) <=> CP semigroup, both directions.
Run: python rg_qm_locks.py   (numpy, scipy)
"""
import json, math, hashlib, pathlib, itertools
import numpy as np
from scipy.linalg import expm, logm, sqrtm
rng = np.random.default_rng(20261110)
RES = {}
def must(c, m):
    if not c: raise AssertionError(m)
def rand_rho(d):
    G = rng.normal(size=(d, d)) + 1j * rng.normal(size=(d, d)); R = G @ G.conj().T; return R / np.trace(R).real
def rand_herm(d):
    G = rng.normal(size=(d, d)) + 1j * rng.normal(size=(d, d)); return (G + G.conj().T) / 2
def rand_unitary(d):
    q, r = np.linalg.qr(rng.normal(size=(d, d)) + 1j * rng.normal(size=(d, d))); return q * (np.diag(r) / abs(np.diag(r)))

# ======================================================================= L1a minimal samples and aliases (palindromic Prony)
def signal(t, c0, amps, oms):
    return c0 + sum(a * math.cos(w * t) + b * math.sin(w * t) for (a, b), w in zip(amps, oms))
def alias_family(M, N, dt=0.3):
    """with N = 3M uniform samples there is a one-parameter family of palindromic real characteristic polynomials of degree
    2M+1 (root 1 plus M unimodular pairs) satisfying all linear-prediction equations; returns two members' frequencies"""
    oms = np.sort(rng.uniform(0.2, 2.5, M)); c0 = rng.normal(); amps = [tuple(rng.normal(size=2)) for _ in range(M)]
    ts = np.arange(N) * dt; y = np.array([signal(t, c0, amps, oms) for t in ts])
    deg = 2 * M + 1
    # roots {1, e^{+-i w_k dt}}: p(z) = (z - 1) prod (z^2 - 2 cos(w dt) z + 1) is ANTI-palindromic, c_j = -c_{deg-j},
    # c_deg = 1, c_0 = -1, free c_1..c_M; p(1) = 0 holds automatically
    def poly(free):
        c = np.zeros(deg + 1); c[deg] = 1.0; c[0] = -1.0
        for j, v in enumerate(free, start=1): c[j] = v; c[deg - j] = -v
        return c
    # prediction equations sum_j c_j y_{n+j} = 0  ->  sum_{j=1..M} c_j (y_{n+j} - y_{n+deg-j}) = y_n - y_{n+deg}
    rows, rhs = [], []
    for n in range(N - deg):
        rows.append([y[n + j] - y[n + deg - j] for j in range(1, M + 1)]); rhs.append(y[n] - y[n + deg])
    A = np.array(rows); b = np.array(rhs)
    sol, *_ = np.linalg.lstsq(A, b, rcond=None)
    return oms, ts, y, A, b, sol, poly, dt
def samples_needed(M, trials=5, dt=0.3):
    """smallest N for which the prediction system (with p(1)=0) has full column rank M generically"""
    for N in range(2 * M + 2, 5 * M + 4):
        ok = True
        for _ in range(trials):
            oms, ts, y, A, b, sol, poly, _ = alias_family(M, N, dt)
            if A.shape[0] == 0 or np.linalg.matrix_rank(A, tol=1e-9) < M: ok = False; break
        if ok: return N
    return None
needed = {M: samples_needed(M) for M in (1, 2, 3)}
must(all(needed[M] == 3 * M + 1 for M in needed), f"L1a counts {needed}")
# explicit alias at N = 3M (M = 2): two parameter values -> different unimodular frequencies, identical samples
M = 2; N = 3 * M
oms, ts, y, A, b, sol, poly, dt = alias_family(M, N)
null = np.linalg.svd(A, full_matrices=True)[2][-1]
roots_true = [1.0] + [np.exp(1j * w * dt) for w in oms] + [np.exp(-1j * w * dt) for w in oms]
c_true = np.real(np.poly(roots_true))[::-1]                      # ascending coefficients, monic
free_true = c_true[1:M + 1]
must(np.allclose(A @ free_true, b, atol=1e-9), "true polynomial satisfies the prediction equations")
def freqs_for(sv):
    c = poly(free_true + sv * null); roots = np.roots(c[::-1])
    return np.allclose(np.abs(roots), 1, atol=1e-8), sorted(abs(np.angle(r)) / dt for r in roots if np.angle(r) > 1e-9)
alias_freqs = [freqs_for(0.0)[1]]
for sv in (0.05, 0.02, 0.01, 0.005, 0.002, -0.002, -0.005, -0.01):
    uni, fr = freqs_for(sv)
    if uni and len(fr) == M:
        alias_freqs.append(fr); alias_s = sv; break
must(len(alias_freqs) == 2, "alias roots unimodular")
# rebuild the alias signal: amplitudes by least squares on the new frequencies must match all N samples
w2 = np.array(alias_freqs[1]); X = np.column_stack([np.ones(N)] + [f(w * ts) for w in w2 for f in (np.cos, np.sin)])
coef, *_ = np.linalg.lstsq(X, y, rcond=None); match = float(np.abs(X @ coef - y).max())
must(match < 1e-8 and np.allclose(alias_freqs[0], sorted(oms), atol=1e-8) and max(abs(np.array(alias_freqs[0]) - np.array(alias_freqs[1]))) > 1e-4
     and max(alias_freqs[1]) < math.pi / dt, "L1a alias")
max_shift = float(max(abs(np.array(alias_freqs[0]) - np.array(alias_freqs[1]))))
RES["L1a"] = dict(claim="One trace with M Bohr frequencies: uniform-sample minimum 3M+1; at 3M an alias with different real frequencies matches every sample",
                  status="LOCKED (counting + executed alias)", N_min=needed,
                  alias=dict(true_freqs=sorted(oms.tolist()), alias_A=alias_freqs[0], alias_B=alias_freqs[1], sample_mismatch=match))
# ======================================================================= L1b local identifiability of H from probes
def series(Hvec, basis, rho0, O, ts):
    H = sum(h * B for h, B in zip(Hvec, basis))
    return np.array([np.trace(expm(-1j * H * t) @ rho0 @ expm(1j * H * t) @ O).real for t in ts])
def su_basis(d):
    B = []
    for i in range(d):
        for j in range(i + 1, d):
            E = np.zeros((d, d), complex); E[i, j] = E[j, i] = 1; B.append(E)
            F = np.zeros((d, d), complex); F[i, j] = -1j; F[j, i] = 1j; B.append(F)
    for k in range(1, d):
        D = np.zeros((d, d), complex); D[:k, :k] = np.eye(k); D[k, k] = -k; B.append(D / math.sqrt(k * (k + 1) / 2))
    return B
def jac_rank(d, rho0, O, ts, Hvec):
    basis = su_basis(d); f0 = series(Hvec, basis, rho0, O, ts); J = []
    for i in range(len(basis)):
        e = np.zeros(len(basis)); e[i] = 1e-6; J.append((series(Hvec + e, basis, rho0, O, ts) - f0) / 1e-6)
    s = np.linalg.svd(np.array(J).T, compute_uv=False); return int((s > 1e-6 * s[0]).sum())
ranks = {}
for d in (2, 3):
    ts = np.linspace(0.1, 6, 40); Hv = rng.normal(size=d * d - 1)
    ranks[d] = jac_rank(d, rand_rho(d), rand_herm(d), ts, Hv)
# symmetric probe: rho0 and O diagonal and H diagonal-dominant -> phases of rotations about the diagonal are null directions
d = 3; ts = np.linspace(0.1, 6, 40)
rho_d = np.diag(rng.dirichlet(np.ones(d))).astype(complex); O_d = np.diag(rng.normal(size=d)).astype(complex)
sym_rank = jac_rank(d, rho_d, O_d, ts, np.zeros(8) + np.r_[np.zeros(6), 0.7, 0.4])
must(ranks[2] == 3 and ranks[3] == 8 and sym_rank < 8, "L1b")
RES["L1b"] = dict(claim="One generic preparation-observable pair locally identifies a generic traceless H (rank d^2 - 1); "
                        "symmetric probes lose the symmetry directions",
                  status="LOCKED (local; global discrete aliases not excluded)", rank_generic=ranks, rank_symmetric_qutrit=sym_rank)

# ======================================================================= L2 Petz modulus
def mpow(A, p):
    w, U = np.linalg.eigh((A + A.conj().T) / 2); w = np.clip(w, 1e-300, None); return (U * w ** p) @ U.conj().T
def apply(K, R): return sum(k @ R @ k.conj().T for k in K)
def adjoint(K, X): return sum(k.conj().T @ X @ k for k in K)
def D(r, s): return float(np.trace(r @ (logm(r) - logm(s))).real)
def petz(K, sigma):
    Ns = apply(K, sigma); s12 = mpow(sigma, 0.5); N12 = mpow(Ns, -0.5); return lambda X: s12 @ adjoint(K, N12 @ X @ N12) @ s12
def tnorm(X): return float(np.abs(np.linalg.eigvalsh((X + X.conj().T) / 2)).sum())
viol = 0; pairs = []
for _ in range(300):
    r, s = rand_rho(2), rand_rho(2); V = rand_unitary(4)[:, :2]; K = [V[:2, :], V[2:, :]]
    gap = D(r, s) - D(apply(K, r), apply(K, s)); err = tnorm(r - petz(K, s)(apply(K, r)))
    bound = 2 * math.sqrt(max(0.0, 1 - math.exp(-gap)))
    if err > bound + 1e-9: viol += 1
    pairs.append((gap, err))
# near-sufficient family: partial trace of rho x tau_eps with tau correlated by eps -> gap and error scaling
fam = []
for eps in (1e-1, 3e-2, 1e-2, 3e-3, 1e-3):
    r1, s1, tau = rand_rho(2), rand_rho(2), rand_rho(2)
    G = rand_herm(4); R = expm(-1j * eps * G) @ np.kron(r1, tau) @ expm(1j * eps * G); S = np.kron(s1, tau)
    Kpt = [np.kron(np.eye(2), e.reshape(1, 2)) for e in np.eye(2)]
    gap = D(R, S) - D(apply(Kpt, R), apply(Kpt, S)); err = tnorm(R - petz(Kpt, S)(apply(Kpt, R))); fam.append((eps, gap, err))
gs = np.log([f[1] for f in fam]); es = np.log([f[2] for f in fam]); slope = float(np.polyfit(gs, es, 1)[0])
must(viol == 0 and 0.35 < slope < 0.65, f"L2 {viol} {slope}")
RES["L2"] = dict(claim="Petz modulus: trace-norm recovery error <= 2 sqrt(1 - e^-gap); along near-sufficient families the error scales as gap^(1/2)",
                 status="LOCKED for the rotated Petz map (imported, Junge-Renner-Sutter-Wilde-Winter 2018); plain Petz: 0/300 violations; exponent 1/2 executed",
                 violations_plain_petz=viol, family=[dict(eps=e, gap=g, error=er) for e, g, er in fam], fitted_exponent=slope)

# ======================================================================= L3 task-declared metrics
def metric(f, rho, A):
    lam, U = np.linalg.eigh(rho); B = U.conj().T @ A @ U
    return float(sum(abs(B[i, j]) ** 2 / (lam[j] * f(lam[i] / lam[j])) for i in range(len(lam)) for j in range(len(lam))))
f_sld = lambda t: (1 + t) / 2
f_bkm = lambda t: (t - 1) / math.log(t) if abs(t - 1) > 1e-12 else 1.0
f_wy = lambda t: ((1 + math.sqrt(t)) / 2) ** 2
def sld_operator(rho, A):
    lam, U = np.linalg.eigh(rho); B = U.conj().T @ A @ U
    L = np.array([[2 * B[i, j] / (lam[i] + lam[j]) for j in range(len(lam))] for i in range(len(lam))]); return U @ L @ U.conj().T
def classical_fisher(rho, A, povm):
    return float(sum(np.trace(A @ E).real ** 2 / np.trace(rho @ E).real for E in povm))
sld_ok = bkm_ok = wy_ok = 0; wy_ratio = []
for _ in range(100):
    d = 3; rho = rand_rho(d); A = rand_herm(d); A -= np.trace(A) / d * np.eye(d)
    L = sld_operator(rho, A); w, U = np.linalg.eigh(L); povm = [np.outer(U[:, k], U[:, k].conj()) for k in range(d)]
    best = classical_fisher(rho, A, povm); sld = metric(f_sld, rho, A)
    rand_povm = []
    for _ in range(20):
        V = rand_unitary(d); rand_povm.append(classical_fisher(rho, A, [np.outer(V[:, k], V[:, k].conj()) for k in range(d)]))
    if abs(best - sld) < 1e-8 * max(1, sld) and max(rand_povm) <= sld + 1e-9: sld_ok += 1
    sc = 1e-2 * min(np.linalg.eigvalsh(rho)) / max(1e-12, np.abs(np.linalg.eigvalsh(A)).max())
    def d2(h): return (D(rho + h * A, rho) + D(rho - h * A, rho)) / h ** 2   # -> metric (Richardson below)
    rich = (4 * d2(sc / 2) - d2(sc)) / 3
    if abs(rich - metric(f_bkm, rho, A)) < 1e-4 * max(1, metric(f_bkm, rho, A)): bkm_ok += 1
    H = rand_herm(d); T = -1j * (H @ rho - rho @ H); sq = mpow(rho, 0.5)
    skew = float(-0.5 * np.trace((sq @ H - H @ sq) @ (sq @ H - H @ sq)).real)
    wy_ratio.append(metric(f_wy, rho, T) / skew)
wy_const = float(np.mean(wy_ratio)); wy_ok = int(np.max(np.abs(np.array(wy_ratio) - wy_const)) < 1e-8 * wy_const)
must(sld_ok == 100 and bkm_ok == 100 and wy_ok == 1, f"L3 {sld_ok} {bkm_ok} {wy_ok}")
RES["L3"] = dict(claim="Each Petz metric is fixed by a task: SLD = maximal measured Fisher (estimation, Braunstein-Caves); "
                       "BKM = Hessian of relative entropy (thermodynamic response); WY = skew information on unitary orbits",
                 status="LOCKED (100/100 each)", wy_metric_over_skew_information=wy_const,
                 meaning="L39 task lock: declaring the task declares the metric; no task-free choice exists in QM.")

# ======================================================================= L4 minimal environment for non-Markovian memory
sx = np.array([[0, 1], [1, 0]], complex); sy = np.array([[0, -1j], [1j, 0]]); sz = np.diag([1, -1]).astype(complex)
def choi_rank_of_reduced(Hab, env, t, d=2):
    U = expm(-1j * Hab * t); C = np.zeros((d * d, d * d), complex)
    for i in range(d):
        for j in range(d):
            Eij = np.zeros((d, d), complex); Eij[i, j] = 1
            R = U @ np.kron(Eij, env) @ U.conj().T; out = R.reshape(d, 2, d, 2).trace(axis1=1, axis2=3); C += np.kron(Eij, out)
    s = np.linalg.eigvalsh((C + C.conj().T) / 2); return int((s > 1e-9).sum())
Hab = 0.7 * (np.kron(sx, sx) + np.kron(sy, sy)) / 2; env = np.diag([1.0, 0.0]).astype(complex)
ranks4 = [choi_rank_of_reduced(Hab, env, t) for t in np.linspace(0.05, 9, 60)]
must(max(ranks4) == 2, "L4")
RES["L4"] = dict(claim="Minimal environment dimension for an exact unitary dilation with a pure environment state is at least max_t Choi rank",
                 status="LOCKED (Stinespring lower bound); achieved by the qubit environment of the exchange model",
                 max_choi_rank=max(ranks4), environment_dimension_used=2,
                 meaning="The hidden memory responsible for backflow needs at least this many environment levels; general achievability open.")

# ======================================================================= L5 generator forms for d = 3
d = 3
phi = np.zeros(d * d, complex)
for i in range(d): phi[i * d + i] = 1 / math.sqrt(d)
PHI = np.outer(phi, phi.conj())
def extend_min(op):
    out = np.zeros((d * d, d * d), complex)
    for i in range(d):
        for j in range(d):
            Eij = np.zeros((d, d), complex); Eij[i, j] = 1
            out += np.kron(op(Eij), PHI.reshape(d, d, d, d)[i, :, j, :])
    return float(np.linalg.eigvalsh((out + out.conj().T) / 2).min())
uni_min = min(extend_min(lambda X, U=rand_unitary(d): U @ X @ U.conj().T) for _ in range(30))
anti_max = max(extend_min(lambda X, U=rand_unitary(d): U @ X.T @ U.conj().T) for _ in range(30))
# Stone: generator of a sampled continuous unitary group is Hermitian
H = rand_herm(d); Ut = expm(-1j * H * 0.37); Hrec = 1j * logm(Ut) / 0.37
herm_err = float(np.abs(Hrec - Hrec.conj().T).max()); rec_err = float(np.abs(Hrec - H).max())
# GKLS criterion: Hermiticity-preserving, trace-annihilating L; CP semigroup iff P_perp C_L P_perp >= 0
def superop(Lfn):
    S = np.zeros((d * d, d * d), complex)
    for k in range(d * d):
        E = np.zeros(d * d, complex); E[k] = 1; S[:, k] = Lfn(E.reshape(d, d)).ravel()
    return S
def choi_of(Lfn):
    C = np.zeros((d * d, d * d), complex)
    for i in range(d):
        for j in range(d):
            Eij = np.zeros((d, d), complex); Eij[i, j] = 1; C += np.kron(Eij, Lfn(Eij))
    return C
Pperp = np.eye(d * d) - PHI
agree = 0; tot = 0; n_ccp = 0
for trial in range(120):
    # random Hermiticity-preserving trace-annihilating generator: L(X) = -i[H,X] + sum_k g_k (A_k X A_k^+ - 1/2{A_k^+A_k, X})
    # with possibly NEGATIVE weights g_k (then it may fail CCP)
    Hm = rand_herm(d); As = [rng.normal(size=(d, d)) + 1j * rng.normal(size=(d, d)) for _ in range(3)]
    g = rng.normal(size=3) + (0.8 if trial % 2 == 0 else -0.3)
    def Lfn(X, Hm=Hm, As=As, g=g):
        return -1j * (Hm @ X - X @ Hm) + sum(gk * (A @ X @ A.conj().T - 0.5 * (A.conj().T @ A @ X + X @ A.conj().T @ A)) for gk, A in zip(g, As))
    C = choi_of(Lfn); ccp = np.linalg.eigvalsh(Pperp @ C @ Pperp).min() > -1e-9
    S = superop(Lfn)
    cp = all(np.linalg.eigvalsh(choi_of(lambda X, Et=expm(t * S): (Et @ X.ravel()).reshape(d, d))).min() > -1e-8
             for t in (1e-3, 1e-2, 0.1, 0.5, 2.0))
    tot += 1; agree += int(ccp == cp); n_ccp += int(ccp)
must(uni_min > -1e-10 and anti_max < -0.2 and herm_err < 1e-10 and rec_err < 1e-8 and agree == tot and 0 < n_ccp < tot, "L5")
RES["L5"] = dict(claim="d = 3: unitary symmetries survive extension, antiunitary ones fail; Stone generator Hermitian; "
                       "GKLS criterion (conditional complete positivity) <=> CP semigroup",
                 status="LOCKED (executed; Wigner, Stone and GKS-Lindblad theorems imported for generality)",
                 unitary_extension_min=uni_min, antiunitary_extension_max=anti_max, stone=dict(hermiticity_error=herm_err, recovery_error=rec_err),
                 gkls=dict(trials=tot, agreement=agree, conditionally_cp=n_ccp))
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_qm_locks_results.json").write_text(json.dumps(RES, indent=1, default=float))
for k, v in RES.items():
    if isinstance(v, dict): print(k, "|", v["status"])
print(json.dumps({k: RES[k] for k in ("L1a",)}, default=float)[:600]); print(RES["L1b"]); print(RES["L2"]["fitted_exponent"], RES["L3"]["wy_metric_over_skew_information"], RES["L5"]["gkls"])
