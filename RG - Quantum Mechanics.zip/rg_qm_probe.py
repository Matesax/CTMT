"""Deeper RG <-> QM compatibility probe (Q1-Q8): where the Theorem Ladder meets quantum kinematics, Petz and dynamics.
Run: python rg_qm_probe.py   (numpy, scipy)
"""
import json, math, hashlib, pathlib, itertools
import numpy as np
from scipy.linalg import expm, logm, sqrtm
rng = np.random.default_rng(20261109)
RES = {}
def must(c, m):
    if not c: raise AssertionError(m)
def rand_rho(d, rank=None):
    r = rank or d; G = rng.normal(size=(d, r)) + 1j * rng.normal(size=(d, r)); R = G @ G.conj().T; return R / np.trace(R).real
def rand_unitary(d):
    q, r = np.linalg.qr(rng.normal(size=(d, d)) + 1j * rng.normal(size=(d, d))); return q * (np.diag(r) / abs(np.diag(r)))
def rand_channel(d, k=3):
    """random CPTP map via Stinespring: Kraus K_i from a random isometry d -> d*k"""
    V = rand_unitary(d * k)[:, :d]; return [V[i * d:(i + 1) * d, :] for i in range(k)]
def apply(K, R): return sum(k @ R @ k.conj().T for k in K)
def adjoint(K, X): return sum(k.conj().T @ X @ k for k in K)
def D(r, s): return float(np.trace(r @ (logm(r) - logm(s))).real)
def mpow(A, p):
    w, U = np.linalg.eigh((A + A.conj().T) / 2); w = np.clip(w, 1e-300, None); return (U * w ** p) @ U.conj().T

# ---------------------------------------------------------------- Q1 (L42) probability descends through the effect quotient -> trace rule
d = 3; rho = rand_rho(d)
effects = []
for _ in range(60):
    G = rng.normal(size=(d, d)) + 1j * rng.normal(size=(d, d)); E = G @ G.conj().T; E = E / (np.linalg.eigvalsh(E).max() * 1.01); effects.append(E)
p = np.array([np.trace(rho @ E).real for E in effects])
# reconstruct the functional from data only: fit a Hermitian W with tr(W E) = p (noncontextual additive assignment)
def herm_vec(M): return np.concatenate([M.real.ravel(), M.imag.ravel()])
A = np.array([herm_vec(E.T) for E in effects]); w, *_ = np.linalg.lstsq(A, p, rcond=None)
W = (w[:d * d] - 1j * w[d * d:]).reshape(d, d); W = (W + W.conj().T) / 2
ok_born = np.allclose(W, rho, atol=1e-8)
# canary: a contextual (nonlinear) assignment violates additivity on a POVM split E = E1 + E2
E = effects[0]; E1 = E / 3; E2 = 2 * E / 3
nonlin = lambda X: np.trace(rho @ X).real ** 2
add_violation = abs(nonlin(E) - nonlin(E1) - nonlin(E2))
must(ok_born and add_violation > 1e-3, "Q1")
RES["Q1"] = dict(rung="L42 (trace rule)", status="LOCKED (Busch form imported; reconstruction executed)",
                 witness="A noncontextual, additive assignment on 60 random qutrit effects is reproduced exactly by tr(rho E) with rho "
                         f"recovered from data; a nonlinear (contextual) assignment violates additivity by {add_violation:.3f}.")

# ---------------------------------------------------------------- Q2 (L35/L38) task descent through channels = Petz sufficiency
def petz(Kraus, sigma):
    Ns = apply(Kraus, sigma); s12 = mpow(sigma, 0.5); Nm12 = mpow(Ns, -0.5)
    return lambda X: s12 @ adjoint(Kraus, Nm12 @ X @ Nm12) @ s12
def fidelity(a, b):
    s = sqrtm(a); return float(np.real(np.trace(sqrtm(s @ b @ s))) ** 2)
# (a) sufficient channel: partial trace of a product with a fixed ancilla state (rho x tau, sigma x tau) -> equality and exact recovery
d = 2; r, s, tau = rand_rho(d), rand_rho(d), rand_rho(2)
Rp, Sp = np.kron(r, tau), np.kron(s, tau)
def ptrace_B(X): return X.reshape(2, 2, 2, 2).trace(axis1=1, axis2=3)
K_pt = [np.kron(np.eye(2), np.eye(2)[i:i + 1, :]) for i in range(2)]       # Kraus of Tr_B
Kpt = [np.kron(np.eye(2), e.reshape(1, 2)) for e in np.eye(2)]
eq_gap = D(Rp, Sp) - D(ptrace_B(Rp), ptrace_B(Sp))
Pz = petz(Kpt, Sp); rec_err_suff = float(np.abs(Pz(ptrace_B(Rp)) - Rp).max())
# (b) generic channels: strict inequality, Petz fails; (c) recovery-fidelity inequality test for the plain Petz map
viol = 0; gaps = []; worst = 1e9
for _ in range(300):
    d = 2; r, s = rand_rho(d), rand_rho(d); K = rand_channel(d, 2)
    gap = D(r, s) - D(apply(K, r), apply(K, s)); gaps.append(gap)
    rec = petz(K, s)(apply(K, r)); rec = (rec + rec.conj().T) / 2
    F = min(1.0, fidelity(r, rec)); lhs = -math.log(max(F, 1e-300))
    worst = min(worst, gap - lhs)
    if gap + 1e-9 < lhs: viol += 1
must(abs(eq_gap) < 1e-9 and rec_err_suff < 1e-9 and min(gaps) > -1e-12 and viol == 0, "Q2")
RES["Q2"] = dict(rung="L35, L38 (data processing; Petz gate)", status="LOCKED (Petz sufficiency theorem imported; executed both directions)",
                 witness=f"Sufficient channel (partial trace of rho x tau): relative-entropy gap {eq_gap:.1e}, Petz recovery error "
                         f"{rec_err_suff:.1e}. 300 random channels: gap >= 0 always (min {min(gaps):.2e}); recovery inequality "
                         f"-2 log F <= gap held in every case for the plain Petz map (min slack {worst:.3e}) - no counterexample "
                         "found; the proven universal form uses the rotated Petz map (Junge et al. 2018).",
                 meaning="RG task descent through a protocol (channel) = Petz sufficiency: the task descends iff data processing "
                         "is saturated, and the recovery map is canonical.")

# ---------------------------------------------------------------- Q3 (L38-L40) quantum Fisher: a band, not a single metric
fs = {"RLD (max metric)": lambda t: 2 * t / (1 + t), "BKM": lambda t: (t - 1) / np.log(t) if abs(t - 1) > 1e-12 else 1.0,
      "WY": lambda t: ((1 + np.sqrt(t)) / 2) ** 2, "SLD (min metric)": lambda t: (1 + t) / 2}
def metric(f, rho, A):
    lam, U = np.linalg.eigh(rho); B = U.conj().T @ A @ U; tot = 0.0
    for i in range(len(lam)):
        for j in range(len(lam)):
            tot += abs(B[i, j]) ** 2 / (lam[j] * f(lam[i] / lam[j]))
    return float(tot)
order_ok = mono_ok = 0; commute_spread = 0.0
for _ in range(200):
    d = 3; rho = rand_rho(d); G = rng.normal(size=(d, d)) + 1j * rng.normal(size=(d, d)); A = G + G.conj().T; A -= np.trace(A) / d * np.eye(d)
    vals = {k: metric(f, rho, A) for k, f in fs.items()}
    if vals["SLD (min metric)"] <= vals["WY"] + 1e-9 <= vals["BKM"] + 2e-9 <= vals["RLD (max metric)"] + 3e-9: order_ok += 1
    K = rand_channel(d, 2); rho2 = apply(K, rho); A2 = apply(K, A)
    if all(metric(f, rho2, A2) <= metric(f, rho, A) + 1e-9 for f in fs.values()): mono_ok += 1
    lam = rng.dirichlet(np.ones(d)); R = np.diag(lam); Ad = np.diag(rng.normal(size=d)); Ad -= np.trace(Ad) / d * np.eye(d)
    cv = [metric(f, R, Ad) for f in fs.values()]; commute_spread = max(commute_spread, max(cv) - min(cv))
must(order_ok == 200 and mono_ok == 200 and commute_spread < 1e-10, "Q3")
RES["Q3"] = dict(rung="L38-L40 (Petz family; task lock; bands)", status="LOCKED (Petz classification imported; ordering, monotonicity and commuting collapse executed)",
                 witness="200 random qutrit states/tangents: SLD <= WY <= BKM <= RLD every time; all four contract under 200 random "
                         f"channels; on commuting (diagonal) data all coincide with classical Fisher (spread {commute_spread:.1e}).",
                 meaning="Classically Cencov makes Fisher unique (H-mono); quantum monotonicity leaves a band, so the task must "
                         "declare the metric. That is exactly L39's task lock.")

# ---------------------------------------------------------------- Q4 (L41) wall specialization iff f(0) > 0
def offdiag_metric(f, eps):
    rho = np.diag([1 - eps, eps]); A = np.array([[0, 1], [1, 0]], complex); return metric(f, rho, A)
wall = {k: [offdiag_metric(f, e) for e in (1e-2, 1e-4, 1e-6)] for k, f in fs.items()}
f0 = {k: float(f(1e-12)) for k, f in fs.items()}
finite = {k: (wall[k][-1] / wall[k][-2] < 1.2) for k in fs}          # converges as eps -> 0 vs keeps growing
must(finite["SLD (min metric)"] and finite["WY"] and not finite["BKM"] and not finite["RLD (max metric)"], "Q4")
RES["Q4"] = dict(rung="L41 (quantum wall specialization)", status="LOCKED (executed)",
                 witness={k: dict(f_at_0=f0[k], metric_at_eps=[float(x) for x in wall[k]], stays_finite=bool(finite[k])) for k in fs},
                 meaning="At a rank wall the coherence direction keeps finite cost iff f(0) > 0 (SLD, WY); BKM and RLD blow up.")

# ---------------------------------------------------------------- Q5 hidden versus null in the Heisenberg picture
sx = np.array([[0, 1], [1, 0]], complex); sy = np.array([[0, -1j], [1j, 0]]); sz = np.diag([1, -1]).astype(complex)
H = sx
def krylov(H, O, n=6):
    span = [O]; X = O
    for _ in range(n):
        X = 1j * (H @ X - X @ H); span.append(X)
    M = np.array([herm_vec(S) for S in span]); return np.linalg.matrix_rank(M, tol=1e-9), span
rank, _ = krylov(H, sz)
# null direction: sx commutes with H and is orthogonal to the Krylov span {sz, sy}
r_true = np.array([0.3, -0.4, 0.5]); rho_t = (np.eye(2) + r_true[0] * sx + r_true[1] * sy + r_true[2] * sz) / 2
ts = np.linspace(0, 6, 61); zs = [np.trace(expm(-1j * H * t) @ rho_t @ expm(1j * H * t) @ sz).real for t in ts]
# model <sz>(t) = rz cos 2t + ry sin 2t  (rx never enters)
M = np.c_[np.cos(2 * ts), np.sin(2 * ts)]; coef, *_ = np.linalg.lstsq(M, zs, rcond=None)
must(rank == 2 and np.allclose(coef, [r_true[2], -r_true[1]], atol=1e-10) or np.allclose(coef, [r_true[2], r_true[1]], atol=1e-10), "Q5")
RES["Q5"] = dict(rung="hidden vs null (Both Sides) -> Heisenberg picture", status="LOCKED",
                 witness=f"Measuring only <sz>(t) under H = sx: the observable Krylov span has rank {rank} (sz, sy). r_y is a hidden value "
                         f"recovered from the history (fit {coef.round(10).tolist()}), r_x commutes with H and is null forever.",
                 meaning="RG's hidden/null typing is the Lie-closure observability of quantum control.")

# ---------------------------------------------------------------- Q6 dynamics classes forced by the extension gate
def choi(channel_fn, d):
    C = np.zeros((d * d, d * d), complex)
    for i in range(d):
        for j in range(d):
            Eij = np.zeros((d, d), complex); Eij[i, j] = 1; C += np.kron(Eij, channel_fn(Eij))
    return C
def lindblad(Hm, Ls):
    def L(X): return -1j * (Hm @ X - X @ Hm) + sum(l @ X @ l.conj().T - 0.5 * (l.conj().T @ l @ X + X @ l.conj().T @ l) for l in Ls)
    return L
def semigroup(Lfn, d, t, steps=400):
    # exp(tL) via the superoperator matrix
    S = np.zeros((d * d, d * d), complex)
    for k in range(d * d):
        E = np.zeros(d * d, complex); E[k] = 1; S[:, k] = Lfn(E.reshape(d, d)).ravel()
    Et = expm(t * S); return lambda X: (Et @ X.ravel()).reshape(d, d)
cp_ok = 0
for _ in range(50):
    d = 2; Hm = rng.normal(size=(2, 2)) + 1j * rng.normal(size=(2, 2)); Hm = Hm + Hm.conj().T
    Ls = [rng.normal(size=(2, 2)) + 1j * rng.normal(size=(2, 2)) for _ in range(2)]
    ok = all(np.linalg.eigvalsh(choi(semigroup(lindblad(Hm, Ls), 2, t), 2)).min() > -1e-9 for t in (0.1, 1.0, 5.0))
    cp_ok += ok
transpose_flow = lambda p: (lambda X: (1 - p) * X + p * X.T)
pos_not_cp = []
for p_ in (0.05, 0.2, 0.4):
    T = transpose_flow(p_); pos = all(np.linalg.eigvalsh(T(rand_rho(2))).min() > -1e-12 for _ in range(200))
    pos_not_cp.append((p_, pos, float(np.linalg.eigvalsh(choi(T, 2)).min())))
must(cp_ok == 50 and all(pos and m < -1e-6 for _, pos, m in pos_not_cp), "Q6")
RES["Q6"] = dict(rung="extension gate (G2/G4) applied to continuous dynamics", status="LOCKED (classes); generator FORM imported (Stone/Wigner; GKS-Lindblad)",
                 witness=f"50 random GKLS generators: e^(tL) completely positive at t = 0.1, 1, 5 in all cases. The flow "
                         f"(1-p) rho + p rho^T is positive on all 200 sampled states but its Choi matrix has a negative eigenvalue "
                         f"{[round(x[2], 4) for x in pos_not_cp]}: admissible alone, excluded under extension.",
                 meaning="Closed dynamics: extension-stable continuous reversible group -> unitary, Hermitian generator. Open dynamics: "
                         "extension-stable continuous semigroups -> GKLS form. RG fixes the CLASS of dynamics, not the Hamiltonian.")

# ---------------------------------------------------------------- Q7 (L53-L55) forgetting = channel contraction
def trace_dist(a, b): return 0.5 * float(np.abs(np.linalg.eigvalsh(a - b)).sum())
pdep = 0.3
dep = lambda X: (1 - pdep) * X + pdep * np.trace(X) * np.eye(2) / 2
a, b = rand_rho(2), rand_rho(2); dists = []
for n in range(10):
    dists.append(trace_dist(a, b)); a, b = dep(a), dep(b)
ratios = [dists[i + 1] / dists[i] for i in range(9)]
unitary = lambda X: sx @ X @ sx
a, b = rand_rho(2), rand_rho(2); d0 = trace_dist(a, b); a, b = unitary(a), unitary(b)
must(max(abs(r - (1 - pdep)) for r in ratios) < 1e-12 and abs(trace_dist(a, b) - d0) < 1e-12, "Q7")
RES["Q7"] = dict(rung="L53-L55 (no uniform forgetting without a class; contraction gate)", status="LOCKED",
                 witness=f"Depolarizing channel: trace distance contracts by exactly {1 - pdep} per step (contraction gate < 1 -> "
                         "uniform forgetting). A unitary channel has contraction coefficient 1: no forgetting at all, so a class "
                         "must be declared.")

# ---------------------------------------------------------------- Q8 where derivation stops (mirror of L128 and the GR no-go)
Hs = [rng.normal(size=(2, 2)) + 1j * rng.normal(size=(2, 2)) for _ in range(5)]; Hs = [h + h.conj().T for h in Hs]
admissible = all(np.allclose(expm(-1j * h) @ expm(-1j * h).conj().T, np.eye(2)) for h in Hs)
RES["Q8"] = dict(rung="L128 mirror", status="NO-GO (structural): every Hermitian H passes every gate",
                 witness=f"5 random Hamiltonians all give extension-stable reversible dynamics ({admissible}). The gates fix the class "
                         "(unitary / GKLS); the specific H is selected or measured, exactly as the Einstein operator's class is fixed "
                         "while G and Lambda are measured.")

# ---------------------------------------------------------------- Q9 non-Markovianity = a hidden value stored in the environment
J = 0.7
Hab = J * (np.kron(sx, sx) + np.kron(sy, sy)) / 2                       # exchange coupling A <-> B
envB = np.diag([1.0, 0.0]).astype(complex)
def reduced(rhoA, t):
    U = expm(-1j * Hab * t); R = U @ np.kron(rhoA, envB) @ U.conj().T
    return R.reshape(2, 2, 2, 2).trace(axis1=1, axis2=3)
a0 = (np.eye(2) + 0.9 * sz) / 2; b0 = (np.eye(2) - 0.9 * sz) / 2
times = np.linspace(0, 2 * math.pi / J, 200)
td = [trace_dist(reduced(a0, t), reduced(b0, t)) for t in times]
increase = max(td[i + 1] - td[i] for i in range(len(td) - 1))
backflow = sum(max(0.0, td[i + 1] - td[i]) for i in range(len(td) - 1))
must(increase > 1e-3, "Q9")
RES["Q9"] = dict(rung="L35 (contraction) + hidden values (Both Sides)", status="LOCKED (typing)",
                 witness=f"Qubit A coupled to qubit B by exchange: the trace distance of two A-states falls to {min(td):.3f} and "
                         f"revives to {max(td[len(td)//2:]):.3f} (total backflow {backflow:.3f}). The reduced protocol violates "
                         "data-processing contraction; the dilated protocol (A+B, unitary) does not.",
                 meaning="Non-Markovian quantum dynamics = a hidden value held by the environment; RG's history-observability typing "
                         "applies: the reduced A-protocol is not closed, the A+B protocol is.")

RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_qm_probe_results.json").write_text(json.dumps(RES, indent=1, default=float))
for k, v in RES.items():
    if isinstance(v, dict): print(k, "|", v["rung"], "|", v["status"])
