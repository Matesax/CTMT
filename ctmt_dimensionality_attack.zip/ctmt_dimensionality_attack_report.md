# CTMT Dimensionality Attack Report

- **baseline_vac_good**: intended d=3, rank=3, λ_max≈4.691e+15, decision: **ACCEPT** — 
- **attack_param_noise**: intended d=3, rank=3, λ_max≈4.691e+15, decision: **REFUSE** — Observable inconsistent with single-control I (per-sensor jitter).
- **attack_axial_only**: intended d=3, rank=3, λ_max≈1.209e+10, decision: **ACCEPT** — unexpected full rank
- **attack_aniso_single_view**: intended d=5, rank=3, λ_max≈4.691e+15, decision: **REFUSE** — Under-determined anisotropy in single view; CTMT refuses interpretation.
- **attack_heteroskedastic_misC**: intended d=3, rank=3, λ_max≈4.691e+15, decision: **REFUSE** — Mis-specified covariance; rupture statistic large → refuse.
- **attack_transport_unit_mismatch**: intended d=3, rank=3, λ_max≈9.381e+15, decision: **ACCEPT** — borderline