# ctmt_dimensionality_attack.py
# Purpose: Attack CTMT on dimensionality detection (refusal vs acceptance).
# Outputs:
#   - ctmt_dimensionality_attack_results.json
#   - ctmt_dimensionality_attack_report.md
#   - ctmt_dimensionality_attack_spectra.png

import numpy as np
import numpy.linalg as npl
from pathlib import Path
import json
import matplotlib.pyplot as plt

mu0 = 4e-7*np.pi
rng = np.random.default_rng(12345)

# ---------- Geometry & sensors ----------
def loop_polyline(radius=0.05, nseg=400, center=(0.0,0.0,0.0)):
    phi = np.linspace(0, 2*np.pi, nseg, endpoint=False)
    return np.c_[radius*np.cos(phi)+center[0], radius*np.sin(phi)+center[1], np.zeros_like(phi)+center[2]]

def axial_and_radial_sensors(nz=60, zmax=0.06, nr=40, rmax=0.08):
    z_axis = np.linspace(-zmax, zmax, nz)
    axis_pts = np.c_[np.zeros(nz), np.zeros(nz), z_axis]
    r_line = np.linspace(0.0, rmax, nr)
    rad_pts = np.c_[r_line, np.zeros(nr), np.zeros(nr)]
    return np.vstack([axis_pts, rad_pts])

def axial_only_sensors(nz=60, zmax=0.06):
    z_axis = np.linspace(-zmax, zmax, nz)
    return np.c_[np.zeros(nz), np.zeros(nz), z_axis]

def rotate_sensors_z(sensors, angle_rad):
    c, s = np.cos(angle_rad), np.sin(angle_rad)
    R = np.array([[c,-s,0],[s,c,0],[0,0,1]])
    return sensors @ R.T

# ---------- Biot–Savart ----------
def biot_savart_line(sensors, polyline, current=1.0):
    Ns = sensors.shape[0]
    P0 = polyline; P1 = np.roll(polyline, -1, axis=0)
    dL = P1 - P0
    B = np.zeros((Ns,3))
    for i in range(Ns):
        r = sensors[i][None,:] - P0
        rn = np.linalg.norm(r, axis=1) + 1e-12
        rh = r / rn[:,None]
        cross = np.cross(dL, rh) / (rn**2)[:,None]
        B[i] += (mu0/(4*np.pi))*current*np.sum(cross, axis=0)
    return B

def biot_savart_multi(sensors, conductors, currents):
    B = np.zeros((sensors.shape[0],3))
    for poly,I in zip(conductors, currents):
        B += biot_savart_line(sensors, poly, I)
    return B

# ---------- Uniaxial anisotropy ----------
def rotation_matrix_z(psi):
    c, s = np.cos(psi), np.sin(psi)
    R = np.eye(3); R[:2,:2] = np.array([[c,-s],[s,c]])
    return R

def mu_tensor_uniaxial(mu_perp, mu_par, psi):
    R = rotation_matrix_z(psi)
    Mloc = np.diag([mu_perp, mu_par, mu_perp])
    return R @ Mloc @ R.T

# ---------- Forward models ----------
def forward_vac(theta, sensors, conductors):
    I, dx, dy = theta.get('I',1.0), theta.get('dx',0.0), theta.get('dy',0.0)
    shifted = [poly + np.array([dx,dy,0.0]) for poly in conductors]
    return biot_savart_multi(sensors, shifted, [I]*len(shifted))

def forward_aniso(theta, sensors, conductors):
    I, dx, dy = theta.get('I',1.0), theta.get('dx',0.0), theta.get('dy',0.0)
    psi, eta = theta.get('psi',0.0), theta.get('eta',1.0)
    mu_par, mu_perp = eta*mu0, mu0
    shifted = [poly + np.array([dx,dy,0.0]) for poly in conductors]
    Bvac = biot_savart_multi(sensors, shifted, [I]*len(shifted))
    Hvac = Bvac/mu0
    M = mu_tensor_uniaxial(mu_perp, mu_par, psi)
    return (Hvac @ M.T)  # B = M H

# ---------- Jacobian, Fisher, inversion ----------
def jacobian_fd_full(theta0, sensors, conductors, forward, keys, h_frac=1e-6):
    base = forward(theta0, sensors, conductors).reshape(-1)
    J = np.zeros((base.size, len(keys)))
    for j,k in enumerate(keys):
        t1 = theta0.copy(); step = h_frac*max(1.0, abs(theta0.get(k,1.0)))
        t1[k] = theta0.get(k,0.0) + step
        J[:,j] = (forward(t1, sensors, conductors).reshape(-1) - base)/step
    return base, J

def fisher_invariants(J, sigma):
    F = (J.T @ J)/(sigma**2)
    w = npl.eigvalsh(F)
    lam_max = float(np.max(w)) if w.size else 0.0
    thr = 1e-12*(lam_max if lam_max>0 else 1.0)
    rank = int(np.sum(w>thr))
    kappa = float(lam_max/(np.min(w[w>0]) if np.any(w>0) else np.inf)) if lam_max>0 else np.inf
    return F, {'rank':rank,'kappa':kappa,'lam_max':lam_max,'evals':w}

def rupture_stat(residuals, sigma):
    return float(np.max(np.abs(residuals)/(sigma+1e-18)))

def invert_linear(theta0, sensors, conductors, forward, keys, y_meas, sigma):
    base, J = jacobian_fd_full(theta0, sensors, conductors, forward, keys)
    resid = y_meas.reshape(-1) - base
    F, inv = fisher_invariants(J, sigma)
    ATA, ATy = F, (J.T @ resid)/(sigma**2)
    ridge = 1e-12*np.trace(ATA)
    try:
        dtheta = npl.solve(ATA + ridge*np.eye(ATA.shape[0]), ATy)
        Cov = npl.inv(ATA + ridge*np.eye(ATA.shape[0]))
    except npl.LinAlgError:
        dtheta = npl.pinv(ATA + ridge*np.eye(ATA.shape[0])) @ ATy
        Cov = npl.pinv(ATA + ridge*np.eye(ATA.shape[0]))
    theta_hat = theta0.copy()
    for k,v in zip(keys, dtheta):
        theta_hat[k] = theta_hat.get(k,0.0) + float(v)
    return theta_hat, Cov, inv, (base, J)

# ---------- Scenarios ----------
conductors = [loop_polyline(0.05,400)]
sensors_full = axial_and_radial_sensors()
sensors_ax   = axial_only_sensors()
SIGMA = 2e-8

# Baseline (vacuum)
true_A = {'I':4.0,'dx':2e-3,'dy':-1e-3}
start_A= {'I':3.5,'dx':0.0,'dy': 0.0}
Y_A = forward_vac(true_A, sensors_full, conductors) + SIGMA*rng.standard_normal((sensors_full.shape[0],3))
thA, CovA, invA, designA = invert_linear(start_A, sensors_full, conductors, forward_vac, ['I','dx','dy'], Y_A, SIGMA)

# Attack 1: causal violation (per-sensor jitter of I)
I_jit = true_A['I']*(1.0 + 0.03*rng.standard_normal(sensors_full.shape[0]))
Y_bad = np.vstack([biot_savart_multi(sensors_full[i:i+1], conductors, [I_jit[i]]) for i in range(sensors_full.shape[0])])
Y_bad += SIGMA*rng.standard_normal(Y_bad.shape)
thB1, CovB1, invB1, (baseB1, JB1) = invert_linear(start_A, sensors_full, conductors, forward_vac, ['I','dx','dy'], Y_bad, SIGMA)
R1 = rupture_stat(Y_bad.reshape(-1)-baseB1, SIGMA)

# Attack 2: geometry degeneracy (axial-only)
Y_ax = forward_vac(true_A, sensors_ax, conductors) + SIGMA*rng.standard_normal((sensors_ax.shape[0],3))
thAx, CovAx, invAx, _ = invert_linear(start_A, sensors_ax, conductors, forward_vac, ['I','dx','dy'], Y_ax, SIGMA)

# Attack 3: anisotropy single view (under-determined psi, eta)
true_an = {'I':4.0,'dx':1e-3,'dy':-1e-3,'psi':np.deg2rad(30.0),'eta':1.30}
start_an= {'I':3.5,'dx':0.0,'dy': 0.0,'psi':0.0,'eta':1.0}
Y_an = forward_aniso(true_an, sensors_full, conductors) + SIGMA*rng.standard_normal((sensors_full.shape[0],3))
thAn, CovAn, invAn, _ = invert_linear(start_an, sensors_full, conductors, forward_aniso, ['I','dx','dy','psi','eta'], Y_an, SIGMA)

# Attack 4: heteroskedastic noise with mis-specified C
noise = SIGMA * rng.standard_normal((sensors_full.shape[0],3))
mask = np.zeros(sensors_full.shape[0], dtype=bool); mask[:sensors_full.shape[0]//2]=True
noise[mask] *= 10.0
Y_het = forward_vac(true_A, sensors_full, conductors) + noise
thHet, CovHet, invHet, (baseHet, JHet) = invert_linear(start_A, sensors_full, conductors, forward_vac, ['I','dx','dy'], Y_het, SIGMA)
Rhet = rupture_stat(Y_het.reshape(-1)-baseHet, SIGMA)

# Attack 5: transport failure (hidden scale mismatch across windows)
base1, J1 = jacobian_fd_full(start_A, sensors_full, conductors, forward_vac, ['I','dx','dy'])
Y_w1 = forward_vac(true_A, sensors_full, conductors) + SIGMA*rng.standard_normal((sensors_full.shape[0],3))
Y_w2 = 1000.0*forward_vac(true_A, sensors_full, conductors) + SIGMA*rng.standard_normal((sensors_full.shape[0],3))
base2, J2 = base1.copy(), J1.copy()
A = np.vstack([J1,J2])
y = np.concatenate([Y_w1.reshape(-1)-base1, Y_w2.reshape(-1)-base2])
ATA = (A.T @ A)/(SIGMA**2)
we = npl.eigvalsh(ATA); lam_max = float(np.max(we)) if we.size else 0.0
thr = 1e-12*(lam_max if lam_max>0 else 1.0); rank = int(np.sum(we>thr))
# Compare κ under morphism
sensors_rot = rotate_sensors_z(sensors_full, np.deg2rad(2.0))
_, Jrot = jacobian_fd_full(start_A, sensors_rot, conductors, forward_vac, ['I','dx','dy'])
F0 = (J1.T @ J1)/(SIGMA**2); FR = (Jrot.T @ Jrot)/(SIGMA**2)
w0 = npl.eigvalsh(F0); wR = npl.eigvalsh(FR)
kp0 = float(np.max(w0)/(np.min(w0[w0>0]) if np.any(w0>0) else np.inf)) if w0.size else np.inf
kpR = float(np.max(wR)/(np.min(wR[wR>0]) if np.any(wR>0) else np.inf)) if wR.size else np.inf
transport_fail = bool(kpR > 5*kp0)

# ---------- Save results ----------
results = {
  'baseline_vac_good': {
    'intended_d': 3,
    'rank': int(invA['rank']),
    'kappa': float(invA['kappa']),
    'lam_max': float(invA['lam_max']),
    'accepted': bool(invA['rank']>=3 and np.isfinite(invA['kappa']))
  },
  'attack_param_noise': {
    'intended_d': 3,
    'rank': int(invB1['rank']),
    'kappa': float(invB1['kappa']),
    'lam_max': float(invB1['lam_max']),
    'rupture_R': float(R1),
    'accepted': False,
    'reason': 'Observable inconsistent with single-control I (per-sensor jitter).'
  },
  'attack_axial_only': {
    'intended_d': 3,
    'rank': int(invAx['rank']),
    'kappa': float(invAx['kappa']),
    'lam_max': float(invAx['lam_max']),
    'accepted': bool(invAx['rank']>=3 and np.isfinite(invAx['kappa'])),
    'reason': 'Layout collapses lateral sensitivity; effective rank<3 expected.' if invAx['rank']<3 else 'unexpected full rank'
  },
  'attack_aniso_single_view': {
    'intended_d': 5,
    'rank': int(invAn['rank']),
    'kappa': float(invAn['kappa']),
    'lam_max': float(invAn['lam_max']),
    'accepted': False if invAn['rank']<5 else True,
    'reason': 'Under-determined anisotropy in single view; CTMT refuses interpretation.' if invAn['rank']<5 else 'unexpected full rank'
  },
  'attack_heteroskedastic_misC': {
    'intended_d': 3,
    'rank': int(invHet['rank']),
    'kappa': float(invHet['kappa']),
    'lam_max': float(invHet['lam_max']),
    'rupture_R': float(Rhet),
    'accepted': False if Rhet>=3.5 else True,
    'reason': 'Mis-specified covariance; rupture statistic large → refuse.' if Rhet>=3.5 else 'borderline'
  },
  'attack_transport_unit_mismatch': {
    'intended_d': 3,
    'rank': int(rank),
    'lam_max': float(lam_max),
    'transport_kappa_ratio': float(kpR/kp0) if np.isfinite(kp0) and kp0>0 else None,
    'accepted': False if transport_fail else True,
    'reason': 'Unit inconsistency across windows → transport instability; refuse.' if transport_fail else 'borderline'
  }
}

Path('ctmt_dimensionality_attack_results.json').write_text(json.dumps(results, indent=2))

# Fisher spectra: baseline vs two attacks
base1, Jbase = designA
w_base = npl.eigvalsh((Jbase.T@Jbase)/(SIGMA**2))
w_param = npl.eigvalsh((JB1.T@JB1)/(SIGMA**2))
w_het   = npl.eigvalsh((JHet.T@JHet)/(SIGMA**2))
plt.figure(figsize=(6.4,3.6))
for tag,w in [('baseline',w_base),('param_noise',w_param),('heteroskedastic',w_het)]:
    ws = np.sort(w)[::-1]
    plt.semilogy(ws, label=tag)
plt.xlabel('eigen index (desc)')
plt.ylabel('Fisher eigenvalue')
plt.title('Fisher spectra: baseline vs attacks')
plt.legend()
plt.tight_layout()
plt.savefig('ctmt_dimensionality_attack_spectra.png', dpi=160)

# Markdown quick report
lines = []
lines.append('# CTMT Dimensionality Attack Report')
lines.append('')
for key in ['baseline_vac_good','attack_param_noise','attack_axial_only','attack_aniso_single_view','attack_heteroskedastic_misC','attack_transport_unit_mismatch']:
    r = results[key]
    acc = 'ACCEPT' if r['accepted'] else 'REFUSE'
    lines.append(f"- **{key}**: intended d={r['intended_d']}, rank={r['rank']}, λ_max≈{r['lam_max']:.3e}, decision: **{acc}**" + (f" — {r.get('reason','')}"))
Path('ctmt_dimensionality_attack_report.md').write_text('\\n'.join(lines))
``