"""RG Realization Atlas, layer 1. Exact finite set/graph battery.
All examples synthetic. Python standard library only. No physical data.
"""
from itertools import product, combinations
from collections import deque
from fractions import Fraction
import json, hashlib
from pathlib import Path

def partitions(n):
    if n==0:yield ();return
    def rec(a):
        if len(a)==n:yield tuple(a);return
        for v in range(max(a)+2):yield from rec(a+[v])
    yield from rec([0])

def components(n,edges):
    parent=list(range(n))
    def root(a):
        while parent[a]!=a:a=parent[a]
        return a
    for a,b in edges:parent[root(a)]=root(b)
    return tuple(root(i) for i in range(n))

def atlas_certificate(F,cover):
    n=len(F); covered=set().union(*cover) if cover else set()
    if covered!=set(range(n)):return dict(status='UNCOVERED',uncovered=sorted(set(range(n))-covered))
    edges={(i,j) for U in cover for i in U for j in U if F[i]==F[j]}
    comp=components(n,edges)
    witness=next(((i,j) for i in range(n) for j in range(i) if F[i]==F[j] and comp[i]!=comp[j]),None)
    if witness:
        i,j=witness;task=tuple(int(comp[k]==comp[i]) for k in range(n))
        return dict(status='FIBRE_DISCONNECTED',pair=[i,j],task=list(task),
                    local_basic=True,global_basic=False)
    return dict(status='SET_DESCENT_CERTIFIED',quotient_classes=len(set(F)),
                coverage='all latent states',fibre_components=len(set(comp)))

def basic(F,a,U):
    return all(F[i]!=F[j] or a[i]==a[j] for i in U for j in U)

def run():
    checks=[];counts={}; examples={}
    def check(name,ok,**kw):
        assert ok,name;checks.append(dict(name=name,passed=True,**kw))
    contracts=0;task_tests=0;connected=0;disconnected=0;saturated=0;good_nonsat=0
    # All partitions, all covers with <=3 distinct nonempty members, n<=4.
    for n in range(1,5):
        subsets=[frozenset(i for i in range(n) if mask>>i&1) for mask in range(1,1<<n)]
        for F in partitions(n):
            for k in range(1,min(3,len(subsets))+1):
                for cover in combinations(subsets,k):
                    if set().union(*cover)!=set(range(n)):continue
                    cert=atlas_certificate(F,cover);good=cert['status']=='SET_DESCENT_CERTIFIED'
                    sat=all(all((i in U)==(j in U) for i in range(n) for j in range(n) if F[i]==F[j]) for U in cover)
                    if sat:assert good;saturated+=1
                    if good:connected+=1;good_nonsat+=not sat
                    else:
                        disconnected+=1;a=cert['task']
                        assert all(basic(F,a,U) for U in cover) and not basic(F,a,range(n))
                    # Independent universal binary-task test; no use of component routine.
                    implication=True
                    for a in product([0,1],repeat=n):
                        local=all(basic(F,a,U) for U in cover)
                        global_=basic(F,a,range(n))
                        if local and not global_:implication=False
                        task_tests+=1
                    assert implication==good
                    # Each local quotient embeds into global Q, but raw overlap can miss image overlap.
                    for U,V in combinations(cover,2):
                        actual={F[i] for i in U&V};image={F[i] for i in U}&{F[i] for i in V}
                        assert actual<=image
                        if sat:assert actual==image
                    contracts+=1
    check('fibre-connectivity iff universal task descent',True,contracts=contracts,binary_tasks=task_tests,
          certified=connected,obstructed=disconnected)
    check('saturation sufficient but not necessary',saturated>0 and good_nonsat>0,saturated=saturated,
          connected_nonsaturated=good_nonsat)
    # Minimal obstruction and repaired common observable overlap.
    F=(0,0);cover=[{0},{1}];bad=atlas_certificate(F,cover)
    check('raw disjointness can hide observational overlap',bad['status']=='FIBRE_DISCONNECTED')
    examples['phantom_overlap']=dict(F=list(F),cover=[[0],[1]],local_tasks=[[0],[1]],
        raw_overlap=[],observable_overlap=[0],certificate=bad,
        repair='Use cross-chart law-equality relation, not only raw set intersection.')
    # Complete cross-chart equivalence relation gluing works for arbitrary covers.
    cross_tests=0
    for n in range(1,5):
        for F in partitions(n):
            cover=[{i} for i in range(n)]
            copies=[(k,i) for k,U in enumerate(cover) for i in U]
            edges=[(a,b) for a,(k,i) in enumerate(copies) for b,(l,j) in enumerate(copies) if F[i]==F[j]]
            comp=components(len(copies),edges)
            assert all((comp[a]==comp[b])==(F[i]==F[j]) for a,(_,i) in enumerate(copies) for b,(_,j) in enumerate(copies))
            cross_tests+=1
    check('full law-equality overlaps recover quotient',True,partition_contracts=cross_tests)
    # Chart relabelings: effective gluing to existing quotient via actual overlaps.
    charts=0;triple_checks=0
    for F in partitions(4):
        Q=sorted(set(F));images=[set(Q),set(Q[::2]),set(Q[1:])]
        images=[S for S in images if S]
        encode=[{q:(i,17+3*q) for q in S} for i,S in enumerate(images)]
        trans={(i,j):{encode[i][q]:encode[j][q] for q in images[i]&images[j]} for i in range(len(images)) for j in range(len(images))}
        for i,j,k in product(range(len(images)),repeat=3):
            for q in images[i]&images[j]&images[k]:
                assert trans[j,k][trans[i,j][encode[i][q]]]==trans[i,k][encode[i][q]];triple_checks+=1
        copies=[(i,q) for i,S in enumerate(images) for q in S]
        cc=components(len(copies),[(a,b) for a,(_,q) in enumerate(copies) for b,(_,r) in enumerate(copies) if q==r])
        assert len(set(cc))==len(Q);charts+=1
    check('coordinate cocycle and effective quotient gluing',True,atlases=charts,triple_point_checks=triple_checks)
    # Inconsistent transition triangle: edge 01=id,12=id,02=swap.
    copies=[(i,v) for i in range(3) for v in [0,1]]
    edges=[]
    for i,j,flip in [(0,1,0),(1,2,0),(0,2,1)]:
        for v in [0,1]:edges.append((copies.index((i,v)),copies.index((j,v^flip))))
    cc=components(6,edges)
    check('cocycle mutation collapses a local chart',cc[0]==cc[1])
    # Valid local systems on cycle graph: nontrivial holonomy is not failed descent.
    bundles=0;nontrivial=0
    for n in range(3,8):
        for flips in product([0,1],repeat=n):
            sections=[a for a in product([0,1],repeat=n) if all(a[(i+1)%n]==(a[i]^flips[i]) for i in range(n))]
            edges=[(2*i+v,2*((i+1)%n)+(v^flips[i])) for i in range(n) for v in [0,1]]
            cc=components(2*n,edges);twist=sum(flips)%2
            assert len(sections)==(0 if twist else 2)
            assert len(set(cc))==(1 if twist else 2)
            # This is a graph covering, not quotienting edge endpoints into one base point.
            for i in range(n):
                for v in [0,1]:assert (v^flips[i]) in [0,1]
            bundles+=1;nontrivial+=twist
    check('effective graph-cover gluing does not imply global parallel section',True,
          cycle_local_systems=bundles,nontrivial_holonomy=nontrivial)
    # Protocol conversions: exact kernels, correspondence, composition.
    funcs=list(product([0,1],repeat=4));pairs=0;factor=0;nonfactor=0;chains=0
    for F,G in product(funcs,repeat=2):
        R={f:{G[i] for i in range(4) if F[i]==f} for f in set(F)}
        exists=all(len(v)==1 for v in R.values())
        inclusion=all(F[i]!=F[j] or G[i]==G[j] for i in range(4) for j in range(4))
        assert exists==inclusion
        # independent brute search of all candidate quotient functions
        possible=[dict(zip(sorted(set(F)),values)) for values in product(sorted(set(G)),repeat=len(set(F)))]
        solutions=[h for h in possible if all(h[F[i]]==G[i] for i in range(4))]
        assert len(solutions)==int(exists)
        pairs+=1;factor+=exists;nonfactor+=not exists
        if exists:
            h=solutions[0]
            for H in funcs:
                if all(G[i]!=G[j] or H[i]==H[j] for i in range(4) for j in range(4)):
                    k={g:H[G.index(g)] for g in set(G)}
                    assert all(k[h[F[i]]]==H[i] for i in range(4));chains+=1
    check('kernel-inclusion factorization and composition',True,protocol_pairs=pairs,
          unique_maps=factor,correspondences_required=nonfactor,composable_chains=chains)
    # Relational composition over-approximates if intermediate observation loses alignment.
    F=(0,1);G=(0,0);H=(0,1)
    direct={(F[i],H[i]) for i in range(2)}
    composed={(F[i],H[j]) for i in range(2) for j in range(2) if G[i]==G[j]}
    check('independent correspondence composition can add spurious outcomes',direct<composed)
    examples['composition_obstruction']=dict(F=F,G=G,H=H,direct=sorted(direct),composed=sorted(composed),
        repair='Retain common latent/joint witness or accept the conservative larger relation.')
    # Exact stochastic laws: marginal equality does not specify joint law.
    law0={(0,0):Fraction(1,2),(1,1):Fraction(1,2)}
    law1={(0,1):Fraction(1,2),(1,0):Fraction(1,2)}
    marginal=lambda L,k:{v:sum(p for xy,p in L.items() if xy[k]==v) for v in [0,1]}
    check('marginal protocol atlas does not identify joint law',all(marginal(law0,k)==marginal(law1,k) for k in [0,1]) and law0!=law1)
    # A genuinely incompatible set of pair laws, all single marginals consistent.
    assignments=list(product([0,1],repeat=3))
    possible=[a for a in assignments if a[0]!=a[1] and a[1]!=a[2] and a[0]!=a[2]]
    check('pairwise compatible marginals need not have a global joint law',not possible)
    examples['marginal_obstruction']=dict(pair_laws='Each of AB, BC, AC is uniform perfect anticorrelation.',
        singleton_laws='All uniform Bernoulli.',global_joint_exists=False,
        proof='Each pair-equality event must have probability zero; no binary triple satisfies all three inequalities.')
    # Typed coverage: no certificate for an uncovered state.
    check('uncovered state blocks atlas certificate',atlas_certificate((0,1,2),[{0},{1}])['status']=='UNCOVERED')
    # Exact rational overlap error control for scalar tasks on a fixed finite Q.
    # Select one local representative per q; all other local values within eps.
    eps=Fraction(1,10);errors=[]
    for q in range(10):
        values=[Fraction(q)+Fraction(k,100) for k in range(4)]
        assert max(values)-min(values)<=eps
        glued=values[0];errors.extend(abs(v-glued) for v in values)
    check('bounded scalar overlap disagreement gives approximate glue',max(errors)<=eps,
          epsilon=str(eps),maximum_error=str(max(errors)),scope='finite labelled base; scalar tasks; pairwise diameter bound')
    return dict(layer='L1: exact set-level realization descent',checks=checks,passed=len(checks),
        examples=examples,limitations=['All data synthetic. No smooth, topological, metric or physical atlas certified.',
        'Finite tests corroborate written proofs; they are not proofs of arbitrary cases.',
        'Law equality is given exactly, not inferred from samples.',
        'No claim of novel mathematics or independent proof review.',
        'Web search disabled; external references not checked; knowledge cutoff December 2025.'])

if __name__=='__main__':
    a=run();b=run();assert a==b;a['deterministic_rerun_identical']=True
    Path('rg_atlas_layer1_results.json').write_text(json.dumps(a,indent=2))
    print(json.dumps(a,indent=2))
