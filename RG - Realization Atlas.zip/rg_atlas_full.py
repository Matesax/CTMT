"""RG Realization Atlas, layers A2-A9 (A1 = rg_atlas_layer1.py, imported and rerun).
A2 regular structured descent   A3 metric layer (Fisher charts)   A4 strata, walls, specialization
A5 symmetry (Gamma-equivariant charts)   A6 global gluing (cocycles, twisted forms, Leray)
A7 quantitative stability (approximate gluing, conditioning, finite-sample charts)
A8 physical anchors (dilation fibre, counted channel)   A9 realization registry with per-layer certificates.
Synthetic/analytic only. Run: python rg_atlas_full.py --out DIR   (numpy, scipy, sympy)
"""
import argparse, hashlib, itertools, json, math, pathlib, subprocess, sys, time
import numpy as np, sympy as sp
from scipy.optimize import minimize

SEED = 20261102
RES = {}


def must(c, m):
    if not c:
        raise AssertionError(m)


def rec(layer, name, status, witness, details=None):
    RES.setdefault(layer, []).append(dict(name=name, status=status, witness=witness, details=details or {}))


# ============================================================ A2 regular structured descent
def A2():
    x, y, z = sp.symbols("x y z", real=True)
    F = sp.Matrix([x ** 2 + y ** 2, z])                     # rotation quotient R^3 \ axis -> (s, z)
    J = F.jacobian([x, y, z])
    rank_generic = J.subs({x: 1.3, y: -0.4, z: 2}).rank(); rank_axis = J.subs({x: 0, y: 0, z: 2}).rank()
    must(rank_generic == 2 and rank_axis == 1, "constant rank off the axis")
    V = sp.Matrix([-y, x, 0])                               # vertical (fibre) generator
    must(sp.simplify(J * V) == sp.zeros(2, 1), "vertical field")
    # functions: basic iff V(f) = 0
    s_, z_ = sp.symbols("s z_", real=True); g = sp.exp(s_) * sp.sin(z_)
    f_basic = g.subs({s_: x ** 2 + y ** 2, z_: z}); f_non = x * z
    Vf = lambda f: sp.simplify(sum(V[i] * sp.diff(f, v) for i, v in enumerate((x, y, z))))
    must(Vf(f_basic) == 0 and Vf(f_non) != 0, "basic functions")
    # vector fields: projectable iff J*W is constant along fibres
    def pushed(W):
        return sp.simplify(J * W)
    rad = sp.Matrix([x, y, 0]); dx = sp.Matrix([1, 0, 0])
    pr = pushed(rad); pdx = pushed(dx)
    proj_rad = all(sp.simplify(Vf(e)) == 0 for e in pr); proj_dx = all(sp.simplify(Vf(e)) == 0 for e in pdx)
    must(proj_rad and not proj_dx and sp.simplify(pr[0] - 2 * (x ** 2 + y ** 2)) == 0, "projectable fields")
    # covariant 2-tensors: descend iff horizontal (i_V T = 0) and invariant (L_V T = 0)
    eucl = sp.eye(3)
    h = sp.Matrix([[1, 0], [0, 1]])                       # a metric on Q in (s, z)
    pull = J.T * h * J                                     # pullback: basic by construction
    horiz = lambda T: sp.simplify(T * V) == sp.zeros(3, 1)
    must(horiz(pull) and not horiz(eucl), "basic tensors")
    rec("A2", "Regular structured descent", "LOCKED (imported: submersion descent; RG L18-L20)",
        "F = (x^2+y^2, z) has constant rank 2 off the axis (rank 1 on it: singular stratum, A4). Basic functions "
        "(V f = 0) descend, x z does not; the radial field projects to 2s d_s, d_x does not; a pulled-back metric is "
        "horizontal and invariant and descends, the Euclidean metric is invariant but not horizontal and does not.",
        dict(rank_generic=int(rank_generic), rank_axis=int(rank_axis)))
    return dict(rank_generic=int(rank_generic))


# ============================================================ A3 metric layer
def fisher_gauss(params, mu_expr, sig_expr):
    """Fisher information of N(mu(theta), sigma(theta)^2)."""
    Jm = sp.Matrix([mu_expr]).jacobian(params); Js = sp.Matrix([sig_expr]).jacobian(params)
    return sp.simplify(Jm.T * Jm / sig_expr ** 2 + 2 * Js.T * Js / sig_expr ** 2)


def A3():
    a, b, s = sp.symbols("a b sigma", positive=True)
    I_lat = fisher_gauss([a, b, s], a + b, s)
    ns = I_lat.nullspace()
    kerDF = sp.Matrix([[1, 1, 0], [0, 0, 1]]).nullspace()[0]          # D(mu, sigma)/D(a, b, sigma)
    must(I_lat.rank() == 2 and len(ns) == 1 and sp.Matrix.hstack(ns[0], kerDF).rank() == 1, "Fisher radical = ker DF")
    mu, sg, t = sp.symbols("mu sigma_q t", real=True)
    I_q = fisher_gauss([mu, sg], mu, sg)
    must(sp.simplify(I_q - sp.diag(1 / sg ** 2, 2 / sg ** 2)) == sp.zeros(2, 2), "quotient chart metric")
    I_log = fisher_gauss([mu, t], mu, sp.exp(t))
    Jc = sp.Matrix([[1, 0], [0, sp.exp(t)]])
    must(sp.simplify(Jc.T * I_q.subs(sg, sp.exp(t)) * Jc - I_log) == sp.zeros(2, 2), "tensorial chart change")
    # distance: closed form vs discretized geodesic in both charts
    def closed(p, q):
        m1, s1 = p; m2, s2 = q
        return math.sqrt(2) * math.acosh(1 + ((m1 - m2) ** 2 / 2 + (s1 - s2) ** 2) / (2 * s1 * s2))
    P, Qp = (0.0, 1.0), (1.5, 2.0); K = 40
    def length(points, metric):
        L = 0.0
        for u, v in zip(points[:-1], points[1:]):
            mid = (u + v) / 2; d = v - u
            L += math.sqrt(max(d @ metric(mid) @ d, 0))
        return L
    met_q = lambda m: np.diag([1 / m[1] ** 2, 2 / m[1] ** 2])
    met_l = lambda m: np.diag([math.exp(-2 * m[1]), 2.0])
    def geo(A_, B_, metric):
        A_, B_ = np.array(A_), np.array(B_)
        init = np.linspace(A_, B_, K + 1)[1:-1].ravel()
        f = lambda v: length(np.vstack([A_, v.reshape(-1, 2), B_]), metric)
        return minimize(f, init, method="L-BFGS-B", options=dict(maxiter=3000)).fun
    d_q = geo(P, Qp, met_q); d_l = geo((P[0], math.log(P[1])), (Qp[0], math.log(Qp[1])), met_l); d_c = closed(P, Qp)
    must(abs(d_q - d_c) / d_c < 2e-3 and abs(d_l - d_c) / d_c < 2e-3, "distance chart-free")
    # data processing: binning a Gaussian location reduces Fisher information
    from scipy.stats import norm
    def fisher_binned(m, edges):
        p = np.diff(norm.cdf(edges - m)); dp = -np.diff(norm.pdf(edges - m))
        return float(np.sum(dp ** 2 / np.maximum(p, 1e-300)))
    fb = fisher_binned(0.3, np.array([-np.inf, -1, 0, 1, np.inf]))
    must(fb < 1.0, "data processing")
    rec("A3", "Metric charts", "LOCKED (imported: Fisher naturality, Cencov under H-mono; RG L28-L35, L59)",
        f"Redundant Gaussian (mu = a + b): latent Fisher rank 2, radical spanned by (1,-1,0) = ker DF; the descended chart "
        f"metric is diag(1, 2)/sigma^2; the chart change sigma = e^t transforms it exactly as a tensor. The geodesic "
        f"distance between (0,1) and (1.5,2) is {d_q:.5f} in the (mu, sigma) chart, {d_l:.5f} in the (mu, log sigma) chart and "
        f"{d_c:.5f} in closed form. Binning lowers Fisher information from 1 to {fb:.4f} (data processing).",
        dict(d_chart=d_q, d_logchart=d_l, d_closed=d_c, fisher_binned=fb))


# ============================================================ A4 strata, walls, specialization
def A4():
    # fold: F(x) = x^2
    xs = np.linspace(-2, 2, 401); ranks = (np.abs(2 * xs) > 1e-12).astype(int)
    odd_task_fails = any(abs(v - (-v)) > 0 for v in xs if v != 0)        # f(x) = x differs on the fibre {x, -x}
    must(ranks[200] == 0 and ranks[0] == 1 and odd_task_fails, "fold stratum")
    # specialization family F_eps(x1, x2) = (x1, eps x2): kernel inclusion K_eps subset K_0
    rng = np.random.default_rng(SEED)
    base = rng.standard_normal((40, 2)); pts = np.vstack([base, np.c_[base[:, 0], rng.standard_normal(40)]])   # shared x1
    F0 = lambda p: (round(p[0], 12),)
    Fe = lambda p, e: (round(p[0], 12), round(e * p[1], 12))
    incl = all(F0(p) == F0(q) for p in pts for q in pts if Fe(p, 0.3) == Fe(q, 0.3))
    rev = any(Fe(p, 0.3) != Fe(q, 0.3) for p in pts for q in pts if F0(p) == F0(q) and not np.allclose(p, q))
    # Gaussian protocol N((x1, eps x2), I): Fisher for x2 = eps^2 -> CR bound 1/eps^2
    crs = {e: 1 / e ** 2 for e in (1.0, 0.1, 0.01)}
    # wall monodromy: eigenline of [[t, s],[s, -t]] flips sign around the collision
    v0 = v = None
    for th in np.linspace(0, 2 * math.pi, 1001):
        w, U = np.linalg.eigh(np.array([[math.cos(th), math.sin(th)], [math.sin(th), -math.cos(th)]]))
        top = U[:, 1]
        if v is None:
            v0 = v = top
        else:
            v = top if top @ v > 0 else -top
    mono = float(v @ v0)
    must(incl and rev and abs(mono + 1) < 1e-9, "walls")
    rec("A4", "Strata, walls, specialization", "LOCKED (RG L21-L27, L37, L122)",
        f"Fold x^2: rank 1 off the wall, 0 on it; the quotient chart has a boundary. Specialization (x1, eps x2) -> x1 "
        f"exists because K_eps is contained in K_0 (checked on 80 seeded points, 40 pairs sharing x1); the reverse map does not exist. "
        f"Cramer-Rao for x2 grows as 1/eps^2: {crs}. Around a codimension-2 eigenvalue collision the eigenline returns "
        f"with sign {mono:+.0f}, so charts on the regular stratum carry forced monodromy.", dict(cramer_rao=crs))


# ============================================================ A5 symmetry
def A5():
    th = sp.symbols("theta", real=True)
    R = sp.Matrix([[sp.cos(th), -sp.sin(th)], [sp.sin(th), sp.cos(th)]])
    Fisher = sp.eye(2)                                      # isotropic Gaussian location: I = identity
    must(sp.simplify(R.T * Fisher * R - Fisher) == sp.zeros(2, 2), "Gamma-invariant natural module")
    # stabilizer dimension of a point m under SO(2): 1 at the origin (cone point), 0 elsewhere
    gen = sp.Matrix([[0, -1], [1, 0]])
    stab = {k: (1 if (gen * sp.Matrix(v)).norm() == 0 else 0) for k, v in (("origin", [0, 0]), ("m=(1,0)", [1, 0]))}
    # polar charts: transition equivariant: rotation acts as phi -> phi + theta, r fixed
    r, ph = sp.symbols("r phi", positive=True)
    m = sp.Matrix([r * sp.cos(ph), r * sp.sin(ph)]); rot = sp.simplify(R * m - sp.Matrix([r * sp.cos(ph + th), r * sp.sin(ph + th)]))
    # gauge: a latent nuisance angle psi that does not enter the law acts trivially on Q
    psi = sp.symbols("psi"); law = lambda mm, ps: mm
    must(rot == sp.zeros(2, 1) and stab == {"origin": 1, "m=(1,0)": 0} and law(m, psi) == law(m, psi + 1), "symmetry")
    rec("A5", "Gamma-equivariant charts", "LOCKED (RG L6-L11, L25)",
        "Isotropic Gaussian location in R^2 with a nuisance angle: the nuisance is gauge (Gau) and acts trivially on Q; "
        "Gamma = O(2) acts faithfully; the Fisher module is Gamma-invariant; polar charts are equivariant "
        f"(phi -> phi + theta). Stabilizer dimension {stab}: the origin is a cone point of Q/Gamma, so a slice chart is "
        "needed there.", dict(stabilizer_dim=stab))


# ============================================================ A6 global gluing
def A6():
    # (a) twisted form over S^1 with constant local invariants (Moebius line)
    def frame(t):
        return np.array([math.cos(t / 2), math.sin(t / 2)])
    flip = float(frame(2 * math.pi) @ frame(0))
    # (b) H^1(S^1; G) by brute gauge orbits on a 3-cycle for G = Z2 and S3
    def orbits(G, mul, inv, gens):
        states = list(itertools.product(G, repeat=3)); seen = set(); n = 0
        for st in states:
            if st in seen:
                continue
            n += 1; stack = [st]; seen.add(st)
            while stack:
                cur = stack.pop()
                for v in range(3):
                    for hh in gens:
                        new = list(cur)
                        for k, (i, j) in enumerate(((0, 1), (1, 2), (2, 0))):
                            g = new[k]
                            if i == v:
                                g = mul(hh, g)
                            if j == v:
                                g = mul(g, inv(hh))
                            new[k] = g
                        new = tuple(new)
                        if new not in seen:
                            seen.add(new); stack.append(new)
        return n
    S3 = list(itertools.permutations(range(3)))
    mulp = lambda a_, b_: tuple(a_[b_[i]] for i in range(3)); invp = lambda a_: tuple(sorted(range(3), key=lambda i: a_[i]))
    n_s3 = orbits(S3, mulp, invp, [(1, 0, 2), (0, 2, 1)])
    n_z2 = orbits([0, 1], lambda a_, b_: (a_ + b_) % 2, lambda a_: a_, [1])
    # (c) Leray: three 250-degree arcs on S^1 (componentwise Cech vs naive nerve)
    N = 360; arc = lambda a0: {(a0 + k) % N for k in range(250)}; U = [arc(0), arc(120), arc(240)]
    def comps(S):
        S = set(S); out = []
        while S:
            x0 = S.pop(); c = {x0}; st = [x0]
            while st:
                y0 = st.pop()
                for z0 in ((y0 + 1) % N, (y0 - 1) % N):
                    if z0 in S:
                        S.remove(z0); c.add(z0); st.append(z0)
            out.append(frozenset(c))
        return out
    pairs = [(0, 1), (0, 2), (1, 2)]
    C1 = [(pr, c) for pr in pairs for c in comps(U[pr[0]] & U[pr[1]])]; C2 = comps(U[0] & U[1] & U[2])
    def rank2(rows):
        rows = [r for r in rows if r]; rk = 0
        while rows:
            p_ = rows.pop()
            if not p_:
                continue
            rk += 1; lb = p_ & -p_; rows = [r ^ p_ if r & lb else r for r in rows]
        return rk
    d0 = [sum(1 << n for n, (pr, c) in enumerate(C1) if v in pr) for v in range(3)]
    d1 = [sum(1 << next(n for n, (pp, c) in enumerate(C1) if pp == pr and kap <= c) for pr in pairs) for kap in C2]
    ker = sum(1 for mm in range(1 << len(C1)) if all(bin(mm & r).count("1") % 2 == 0 for r in d1))
    H1 = int(math.log2(ker)) - rank2(d0)
    must(abs(flip + 1) < 1e-12 and n_s3 == 3 and n_z2 == 2 and H1 == 1, "global")
    rec("A6", "Global gluing", "LOCKED (RG L111, L119-L122; imported Giraud/Serre)",
        f"Twisted form: a frame transported around S^1 returns with sign {flip:+.0f} while every local invariant is constant. "
        f"Forms over S^1 by brute gauge orbits: Z2 -> {n_z2}, S3 -> {n_s3} (conjugacy classes). Leray cover check: three 250-degree "
        f"arcs give componentwise Cech H^1 = Z2^{H1} (correct), while a naive nerve (filled triangle) would give 0.",
        dict(Z2=n_z2, S3=n_s3, H1_cech=H1))


# ============================================================ A7 quantitative stability
def A7():
    rng = np.random.default_rng(SEED + 7)
    # (a) approximate gluing: chart transitions with errors <= delta; chain inconsistency <= path length * delta
    n_ch, delta = 12, 1e-4
    q = rng.standard_normal(5); chain = [q.copy()]
    for _ in range(n_ch - 1):                                   # each transition errs by at most delta (sup norm)
        chain.append(chain[-1] + rng.uniform(-delta, delta, 5))
    drift = [float(np.abs(c_ - q).max()) for c_ in chain]
    worst_pair = max(drift)
    must(all(d_ <= k * delta + 1e-15 for k, d_ in enumerate(drift)), "chain drift bound k*delta")
    # cycle defect certification: a true holonomy h is certified iff |h| > sum of transition errors on the cycle
    cyc = 6; errs = rng.uniform(0, delta, cyc); bound = errs.sum()
    certified = {h: (abs(h) > bound) for h in (0.0, 0.5 * bound, 3 * bound)}
    # (b) near-wall conditioning: decoder of x2 from F_eps has Lipschitz 1/eps
    lips = {e: 1 / e for e in (1.0, 0.1, 0.01)}
    # (c) finite-sample chart: Hoeffding confidence set for a Bernoulli law, coverage by seeded simulation
    p_true, n, alpha = 0.3, 400, 0.05; rad = math.sqrt(math.log(2 / alpha) / (2 * n))
    cover = np.mean([abs(rng.binomial(n, p_true) / n - p_true) <= rad for _ in range(4000)])
    task_interval = (math.log(max(p_true - rad, 1e-12) / (1 - p_true + rad)), math.log((p_true + rad) / (1 - p_true - rad)))
    must(cover >= 1 - alpha and certified[3 * bound] and not certified[0.5 * bound], "stability")
    rec("A7", "Quantitative stability", "LOCKED (RG L16, L44-L48, L114)",
        f"A chain of 12 charts with transition errors <= {delta}: drift after k steps <= k delta (worst {worst_pair:.2e} <= "
        f"{(n_ch - 1) * delta:.1e}). A cycle "
        f"holonomy h is certified nonzero only when |h| > sum of cycle errors ({bound:.2e}): h = 0.5 x bound is not, 3 x bound "
        f"is. Near a wall the decoder Lipschitz constant is 1/eps: {lips}. A finite-sample Bernoulli chart (n = {n}, Hoeffding "
        f"radius {rad:.4f}) covers the truth in {cover:.4f} of 4000 seeded trials (>= 0.95); its log-odds task is returned as the "
        f"interval {tuple(round(v, 3) for v in task_interval)}, never as a point.", dict(coverage=cover, radius=rad))


# ============================================================ A8 physical anchors
def A8():
    c = 299792458.0; dnu = 9192631770.0
    d_true = 3335.3913                                       # metres (illustrative)
    lam = {"lab A": 1.0, "lab B (units x 7.3)": 7.3}
    # RG chart: ratios of distances are dimensionless and unit-free
    pts = np.array([0.0, d_true, 2.5 * d_true])
    ratios = {k: (pts[2] - pts[0]) * v / ((pts[1] - pts[0]) * v) for k, v in lam.items()}
    same_chart = len({round(r, 12) for r in ratios.values()}) == 1
    # counted channel: radar cycle count n fixes the metre
    n_cs = 2 * d_true / c * dnu
    d_rad = c / (2 * dnu) * n_cs
    must(same_chart and abs(d_rad - d_true) < 1e-6, "anchor")
    rec("A8", "Physical anchors", "LOCKED (RG L94-L109; illustrative numbers)",
        f"Two laboratories whose length units differ by 7.3 have identical RG charts (ratio {list(ratios.values())[0]:.3f}): "
        f"the dilation fibre. A counted two-way caesium channel (n = {n_cs:.6e} cycles) fixes d = c n/(2 dnu) = {d_rad:.4f} m. "
        "Atlas charts become physical charts only through such anchors.")


# ============================================================ A9 registry
REGISTRY = [
    dict(id="R1 finite saturated (layer-1 package)", A1="CERTIFIED"),
    dict(id="R2 rotation quotient R^3 -> (x^2+y^2, z)", A1="CERTIFIED", A2="CERTIFIED off axis", A4="SINGULAR STRATUM (axis)"),
    dict(id="R3 redundant Gaussian (mu = a+b, sigma)", A1="CERTIFIED", A2="CERTIFIED", A3="CERTIFIED"),
    dict(id="R4 fold and specialization family", A4="CERTIFIED (specialization), WALL (fold)", A7="CONDITIONING 1/eps"),
    dict(id="R5 isotropic location with nuisance", A5="CERTIFIED; cone point at origin", A3="CERTIFIED"),
    dict(id="R6 Moebius second-order family", A6="TWISTED (no global section)", A2="CERTIFIED"),
    dict(id="R7 noisy chart network", A7="CERTIFIED within bounds"),
    dict(id="R8 radar-anchored distance", A8="CERTIFIED"),
    dict(id="R9 Schwarzschild exterior (companion papers)", A2="CERTIFIED (r > 2m)", A4="WALL (horizon chart boundary)",
         A6="INTERIOR PERMANENT FIBRE", A8="CERTIFIED (radar, Kepler GM only)"),
    dict(id="R10 eccentric binary, full computation loop", A3="TENSOR DECODERS", A7="FORECAST BUDGETS",
         A6="WEYL HIDDEN STATE (nonlocal)"),
]


def main(outdir):
    out = pathlib.Path(outdir); out.mkdir(parents=True, exist_ok=True); t0 = time.time()
    l1 = subprocess.run([sys.executable, "rg_atlas_layer1.py"], capture_output=True, text=True)
    l1v = subprocess.run([sys.executable, "rg_atlas_layer1_validate.py"], capture_output=True, text=True)
    a1_ok = l1.returncode == 0 and l1v.returncode == 0
    rec("A1", "Exact gluing, task descent, conversions", "LOCKED (imported layer-1 package, rerun)" if a1_ok else "FAILED",
        "Layer-1 battery rerun: 5,651 contracts, 88,482 binary task checks, fibre-chain criterion, cocycle and "
        "composition counterexamples; validator rerun." + ("" if a1_ok else " RERUN FAILED"))
    must(a1_ok, "layer 1 rerun")
    A2(); A3(); A4(); A5(); A6(); A7(); A8()
    layers = sorted(RES)
    for entry in REGISTRY:
        for k in entry:
            if k.startswith("A"):
                must(k in RES, f"registry layer {k} executed")
    res = dict(seed=SEED, layers={k: RES[k] for k in layers}, registry=REGISTRY, runtime_s=round(time.time() - t0, 1),
               python=sys.version.split()[0], numpy=np.__version__, sympy=sp.__version__,
               source_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest())
    (out / "rg_atlas_full_results.json").write_text(json.dumps(res, indent=1, default=float))
    for k in layers:
        for r_ in RES[k]:
            print(k, r_["status"], "|", r_["witness"][:200])


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default="."); main(ap.parse_args().out)
