"""Checks for the closed print: ladder integrity (L0-L131) and the Lorentzian boundary witness (L127)."""
import json, re, sys, pathlib
import sympy as sp

def ladder(tex):
    s = pathlib.Path(tex).read_text()
    body = s[s.index(r"\itshape Exact layer"):]; body = body[:body.index(r"\bottomrule")]
    rows = [m.groups() for m in (re.match(r"^L(\d+) & (.*) & (.*?) & (.*?) & \\ref\{(.*?)\}\\\\$", l.strip()) for l in body.splitlines()) if m]
    def deps(raw):
        out = []
        if raw.strip() == "---":
            return out
        for part in raw.split(","):
            part = part.strip()
            if "--" in part:
                a, b = part.split("--"); out += list(range(int(a.lstrip("L")), int(b.lstrip("L")) + 1))
            else:
                out.append(int(part.lstrip("L")))
        return out
    ids = [int(r[0]) for r in rows]
    opens = [int(r[0]) for r in rows if r[2].strip() == "O"]
    labels = set(re.findall(r"\\label\{(.*?)\}", s))
    return dict(rungs=len(rows), contiguous=ids == list(range(len(rows))),
                backward_only=all(d < int(r[0]) for r in rows for d in deps(r[3])),
                open_rungs=opens, nothing_depends_on_open=not any(d in opens for r in rows for d in deps(r[3])),
                all_refs_resolve=all(r[4] in labels for r in rows))

def ppwave():
    u, v, x, y = sp.symbols("u v x y", real=True); A = sp.Function("A")(u); X = (u, v, x, y)
    g = sp.Matrix([[A * (x**2 - y**2), 1, 0, 0], [1, 0, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]); gi = g.inv(); n = 4
    Gm = [[[sp.simplify(sum(gi[a, d] * (sp.diff(g[d, b], X[c]) + sp.diff(g[d, c], X[b]) - sp.diff(g[b, c], X[d])) for d in range(n)) / 2)
            for c in range(n)] for b in range(n)] for a in range(n)]
    R = {(a, b, c, d): sp.simplify(sp.diff(Gm[a][b][d], X[c]) - sp.diff(Gm[a][b][c], X[d])
                                   + sum(Gm[a][c][e] * Gm[e][b][d] - Gm[a][d][e] * Gm[e][b][c] for e in range(n)))
         for a in range(n) for b in range(n) for c in range(n) for d in range(n)}
    Ric = sp.Matrix(4, 4, lambda b, d: sp.simplify(sum(R[a, b, a, d] for a in range(n))))
    Rl = {k: sp.simplify(sum(g[k[0], e] * R[e, k[1], k[2], k[3]] for e in range(n))) for k in R}
    K = sp.simplify(sum(Rl[k] * sum(gi[k[0], a] * gi[k[1], b] * gi[k[2], c] * gi[k[3], d] * Rl[a, b, c, d]
                                     for a in range(n) for b in range(n) for c in range(n) for d in range(n))
                        for k in Rl if Rl[k] != 0))
    a_ = sp.symbols("a", positive=True); U = [a_, -1 / (2 * a_), 0, 0]
    E = sp.Matrix(2, 2, lambda i, j: sp.simplify(sum(Rl[(p, i + 2, q, j + 2)] * U[p] * U[q] for p in range(4) for q in range(4))))
    nonzero = sum(1 for k in Rl if Rl[k] != 0)
    return dict(ricci_zero=all(e == 0 for e in Ric), kretschmann=str(K), riemann_nonzero_components=nonzero,
                observer_tidal=str(E), boost_scaling=str(sp.simplify(E[1, 1] / (a_**2))))

if __name__ == "__main__":
    L = ladder("Resolution_Geometry.tex"); W = ppwave()
    ok = (L["rungs"] == 132 and L["contiguous"] and L["backward_only"] and L["nothing_depends_on_open"]
          and L["all_refs_resolve"] and L["open_rungs"] == [129, 130, 131]
          and W["ricci_zero"] and W["kretschmann"] == "0" and W["riemann_nonzero_components"] > 0)
    out = dict(ladder=L, lorentzian_boundary_L127=W, all_passed=ok)
    pathlib.Path("rg_close_checks_results.json").write_text(json.dumps(out, indent=1))
    print(json.dumps(out, indent=1))
    sys.exit(0 if ok else 1)
