# RG Realization Atlas: Layer 1
## Exact observational gluing, task descent, and conversion certificates

### Status and scope
This is a new first-layer construction, not a rerun of earlier unavailable executables. The manuscript search supplied the observation-law/kernel framework as context; the theorems below are stated and proved here under their own contracts. No additional manuscript theorem is assumed proved by a search snippet.

LOCKED here means: a precise set-level statement with a written elementary proof and executable finite witnesses. It does not mean independent peer review, formal proof-assistant verification, empirical confirmation, or historical novelty. All examples are synthetic. Exact observation laws/equality are supplied, not estimated from samples. Web search is disabled; external references were not checked; knowledge cutoff December 2025.

Layer L1 has no topology, smooth structure, Fisher tensor, metric, physical interpretation or latent connection. A finite deterministic observation map is a valid special case of a law map by assigning a Dirac observation law to each output. Rational stochastic counterexamples test limits of extending this layer to marginal-law assembly.

## Contract
Let F:X->L be a specified map, Q=F(X), and let (U_i) cover X. Define x~y iff F(x)=F(y). Local quotients Q_i=U_i/~ are canonically identified with F(U_i). A task a_i:U_i->Z is locally basic iff equal-law points inside U_i have equal task values. Tasks use a common declared codomain Z; different local codomains would require their own descent data. Raw compatibility means a_i=a_j on U_i intersection U_j.

Two notions of overlap must be kept distinct:
- Raw overlap: U_i intersection U_j.
- Observational overlap: equal-law pairs (x,y) in U_i x U_j, or F(U_i) intersection F(U_j) after local quotienting.
The first can be empty while the second is nonempty.

## L1.1: Effective set-level quotient gluing
Statement. Form the disjoint union of local quotients Q_i and identify two chart classes exactly when their observation-law values agree. Its quotient is canonically bijective to Q. Compatible maps Q_i->Z agreeing on every observational overlap glue uniquely to a map Q->Z.

Proof. Send a chart class [x]_i to F(x). This is well-defined and surjective because the U_i cover X. Its fibres are exactly the declared cross-chart identifications, so it induces a bijection. Agreement on observational overlaps makes the proposed global task value independent of chart; coverage gives existence everywhere, and surjectivity gives uniqueness.

Interpretation. This is effective descent of sets and set-valued functions over a specified law image. It is not a theorem that arbitrary local statistical laws extend to a joint law, nor a reconstruction of an unknown F from data. Supplying the correct cross-chart equality is a substantive input, not something the gluing algorithm discovers automatically.

## L1.2: Sharp criterion for descent from raw overlaps
For each q in Q, make a graph whose vertices are F^(-1)(q). Join two vertices when they lie together in some U_i. Connectivity means finite edge-chain connectivity, not topological connectivity.

Statement. The following are equivalent:
(a) Every fibre graph is connected.
(b) Every raw-compatible family of locally basic binary tasks glues to a task on Q.
(c) Every raw-compatible family of locally basic tasks with any common codomain glues uniquely to Q.

Proof. Raw-compatible tasks first glue to a unique function a:X->Z by ordinary set-cover gluing. Local basicness makes a constant along every graph edge. Under (a), it is constant on each entire fibre and therefore factors uniquely through Q. This proves (a)->(c)->(b). If a fibre has two components, label one component 1 and all other vertices of X 0. This binary task is constant on every local equal-law class and hence yields raw-compatible local tasks, but is not constant on that fibre. Thus (b) fails, proving the converse.

Corollary. A saturated cover, U_i=F^(-1)(V_i) for V_i subsets of Q, satisfies the criterion. Saturation is sufficient, not necessary. For example F constant on {0,1,2}, U_0={0,1}, U_1={1,2} gives a connected fibre graph without saturated members.

For one fixed task, fibre connectivity is not necessary: the task may happen to agree across disconnected components. The theorem concerns all locally basic tasks. The executable returns an explicit binary obstruction when the universal condition fails.

## L1.3: Coordinate atlas and global task uniqueness
Statement. Given subsets V_i covering Q and bijections phi_i:V_i->A_i, transitions t_ij=phi_j composed with phi_i^(-1), on the actual image of V_i intersection V_j, obey identity, inverse and cocycle laws. Gluing chart copies by these transitions recovers Q. Compatible chart tasks glue uniquely.

Proof. Every transition preserves the same q. Thus t_jk(t_ij(phi_i(q)))=phi_k(q)=t_ik(phi_i(q)) wherever all three are defined. Chart-copy equivalence is exactly equality of q; apply L1.1. Compatible tasks are independent of the selected chart.

This is a coordinate corollary for an existing set Q. It does not assert that arbitrary partial bijections with vaguely specified overlap domains define a valid atlas. Abstract gluing requires precise domain and equivalence-relation axioms; topology and smoothness require further hypotheses.

Mutation witness. Three full two-point charts with transitions 01=identity, 12=identity and 02=swap violate the triple cocycle. Quotienting by all those identifications collapses the two points of each chart. Pairwise invertibility alone is insufficient.

## L1.4: Protocol conversion and its exact composition boundary
Let F:X->Y and G:X->Z. Define the exact conversion correspondence R_FG={(F(x),G(x)):x in X} on the attained images.

Statement. A unique map h:F(X)->G(X) with G=h composed with F exists iff ker F is contained in ker G. Otherwise R_FG is a total, generally multivalued correspondence. If G=hF and H=kG, then H=(kh)F and the induced maps compose exactly.

Proof. Necessity follows by applying h to equal F values. For sufficiency set h(F(x))=G(x); kernel inclusion gives independence of representative, and attained-image surjectivity gives uniqueness. The composition identity follows by substitution.

Important limitation. For general correspondences, R_FH is contained in R_GH composed with R_FG, but equality can fail. The composition allows different latent witnesses x,y with G(x)=G(y). It can therefore add F-H combinations not attained by any single state. Equality holds exactly when every such composed pair is attained jointly. Retaining a common latent/joint witness preserves the exact direct relation; otherwise the composed relation is a conservative over-approximation.

Counterexample. F=H=identity on {0,1}; G is constant. The direct F-H relation is diagonal, while relational composition through G is the full four-pair square. This is a first-layer warning against silently treating arbitrary conversion correspondences as lossless.

## Additional obstruction controls
### Effective global object versus global section
A two-sheet local system over a cycle graph is specified by a flip bit on each edge. It always constructs a graph covering. If the sum of flips is odd, the covering graph is connected and has no global parallel section; if even, it has two components and two parallel sections. This distinguishes existence of a glued object from existence of a global trivialization or a section compatible with transport. The test is a graph-cover model, not a proof for arbitrary smooth bundles.

### Marginal laws versus joint laws
Two binary joint laws, uniform on {00,11} and uniform on {01,10}, have identical one-channel marginals but different joint laws. Local marginal protocols do not determine the joint observation kernel.

A stronger obstruction uses three binary channels: each pair AB, BC and AC is uniformly perfectly anticorrelated. Their singleton marginals agree. No global joint law exists: each pair-equality event must have probability zero, yet no binary triple satisfies all three inequalities. This does not contradict L1.1, which starts with a specified global law map and full observational overlap, not arbitrary marginal distributions.

### Limited approximate task gluing
For a fixed finite labelled base Q, suppose the scalar values proposed by all charts at each q have diameter <=epsilon. Selecting any one value per q gives a global scalar function within epsilon of every proposal. This is a simple approximate gluing bound. It establishes neither uniqueness, smoothness, inverse stability, nor finite-sample certification. The rational example used epsilon=1/10 and attained maximum error 3/100.

## Executed results
13 grouped checks passed. Exhaustive finite scope: all partitions of X for 1<=|X|<=4, and all covering families with at most three distinct nonempty subsets. There were 5,651 contracts and 88,482 binary task checks. Exactly 4,216 contracts satisfied universal raw-overlap descent and 1,435 had explicit disconnected-fibre obstructions. Of the successful contracts, 735 used saturated covers and 3,481 did not.

An independent Floyd-Warshall implementation checked all 5,651 contracts against the union-find certificate. An independent chart-copy equality computation recovered the correct quotient on all 5,651 contracts. The main run also checked 15 relabelled atlases and 429 triple-point cocycle identities.

Protocol tests enumerated 256 pairs of binary maps on four states: 60 admitted a unique conversion map and 196 required a correspondence. There were 176 composable map chains checked. Cycle graph tests covered 248 flip assignments on cycles of lengths 3 through 7; 124 had nontrivial holonomy and no parallel section. Six explicit mutation canaries were detected. The main run repeated identically after JSON normalization.

The first validation attempt compared Python tuples with JSON lists and failed a serialization comparison, not a mathematical assertion. The validator was corrected to compare normalized JSON structures and rerun successfully. The source and final validation are included for audit.

## First realization entry
The package includes a concrete saturated-cover realization with X={0,...,5}, F=(0,0,1,1,2,2), charts U_0={0,1,2,3} and U_1={2,3,4,5}, and task a=(10,10,20,20,30,30). The observable quotient is {0,1,2}, the chart overlap is {1}, and the descended task is {0:10,1:20,2:30}. The executable certificate checks the cover and fibre criterion. This entry is a finite deterministic law model, not a physical system.

## Certificate and coverage ledger
CERTIFIED_SET_DESCENT: exact declared F, full cover, fibre-chain condition for raw-overlap tasks, or complete observational overlaps.
OBSTRUCTED_FIBRE_DESCENT: explicit equal-law pair and locally basic binary task disagreeing on that pair.
UNCOVERED: some latent states are not covered; no global coverage claim is returned.
CORRESPONDENCE_REQUIRED: a target task/protocol varies inside an input fibre.
JOINT_EXTENSION_OBSTRUCTED: specified local marginal laws have no global extension.
NOT_TESTED: smooth, topological, metric, statistical-confidence, physical and connection-level descent.

These statuses belong to different queries. A realization can have certified quotient gluing and still lack a global parallel section. Do not force them into one mutually exclusive global verdict.

## Next layer, precisely delimited
The next target is regular structured descent: declare a quotient submersion, local sections and a class of tensors or other geometric objects; prove which local compatibility conditions make descent effective and preserve the selected structure. Then separately test singular transitions and quantitative stability. L1 supplies the equality and coverage foundation, but does not prove those stronger claims.

## Reproduction
Run python rg_atlas_layer1.py, then python rg_atlas_layer1_validate.py. Standard library only. The package contains both sources, main and validation JSON, one realization entry, this proof/coverage report and SHA256 hashes. No previous battery or external file is needed.
