# Duality of Gravity: Structure, Energy Footprint, and the Exact Point at Which Newton Fails

Paper: `RG - Duality of Gravity.pdf` (source `RG_Duality_of_Gravity.tex`). The programme's main print and README are
in `Resolution Geometry.pdf` and `README.md`.

| File | What it is |
|---|---|
| `rg_gravity.py` | library: the Jacobi pencil, the exact Newton test, Hamiltonian geodesics against the Jacobi reduction, deflection and Firsov inversion, the turning branch, the Gauss–Bonnet split, the failure theorem from angle errors (transfer to fixed radius, declared tail, Coulomb witness), the six footprint readouts, contracts, the one-footprint closure, constant-density interiors |
| `rg_units.py` | unit tools (Fisher kernels), shared with the dimensional-closure companion |
| `rg_gravity_battery.py` | groups DA–DL; writes `rg_gravity_battery_results.json` |
| `rg_gravity_battery_mutations.py` | twenty-six one-line falsifications; each must fail its target group |

```
pip install -r requirements.txt            # numpy, scipy, sympy, mpmath
python3 -I rg_gravity_battery.py            # about 2 min; byte-identical on rerun
python3 -I rg_gravity_battery_mutations.py --jobs 2
```

- **Pencil and split.** Paths at u = (v/c)² are geodesics of (N⁻² − 1 + u)h, so the reconstructed index is affine: Y = ψ²u + P. The local law and the Gauss–Bonnet split hold.
- **Newton.**
  - Flat structure is exactly Newtonian at any field strength.
  - With functional panels, Newton is representable iff h is flat.
  - One speed never refutes Newton, and finite panels give only correspondences.
- **Structural failure.**
  - Exact on the reconstructed index.
  - From relative angle errors, below ε_crit = γ|u2 − u1|/(2 + γ(u1 + u2)), with the Firsov bound transferred to fixed radius. Read in place it fails in strong fields.
  - Two-sided on weak-field panels: a Coulomb witness exists above ε_crit.
- **Energy footprint** = E∞/E_loc = N.
  - Six readouts return one N; their gradients stand in ratios N² and N³.
  - The energetic boundary depends on the contract.
  - The footprint has a unit hole, and one footprint is a gluing test.
- **Identification.** Structure is PPN γ (Cassini), and one footprint is local position invariance (Galileo redshift). Exterior records do not see the interior. No new physics.

Author: Matěj Rada, MatejRada@email.cz. License: CC BY-NC-ND 4.0.
