#!/usr/bin/env python3
"""Resolution Geometry - the duality of gravity as computation: the structure split and the energy footprint.

A static field is ds^2 = -N^2 c^2 dt^2 + A (dr^2 + r^2 dOmega^2) in a normalized isotropic radius r (A -> 1, N -> 1 at
infinity). Units G = c = 1 and M = 1 unless stated. u = (v/c)^2 is the squared speed at infinity of a probe.

  pencil            Jacobi index n_u^2 = A (N^-2 - 1 + u) / u and Y(u) = u n_u^2 = A u + P, P = A (N^-2 - 1)
  newton_exclusion  exact rational Newton test at one radius: Y_i - u_i must share one intercept within eps
  geodesic_sweep    angle swept between r = R0 inbound and outbound, from the Hamiltonian geodesic equations of the
                    metric (conserved E, L only); jacobi_sweep is the same angle from the Jacobi index (independent)
  deflection        total deflection from the Jacobi index; firsov_n inverts a deflection function (Firsov)
  critical_radius   smallest radius above which rho(r) = r n_u(r) is increasing (unique inversion; orbiting below)
  footprint         the six readouts of the lapse N: clock ratio, lowering energy, rope force at infinity, local
                    support, path intercept, timing ratio
  closure           one-footprint gluing of clock and path readouts at several radii; critical non-metric exponent
  interior          constant-density interior Schwarzschild (areal coordinates) and its exterior

numpy, scipy, sympy, mpmath. Deterministic.
"""
import math
from fractions import Fraction as F
import numpy as np
from scipy.integrate import quad, solve_ivp
from scipy.optimize import brentq


# ------------------------------------------------------------------ metrics (isotropic radius)
def schw(r, M=1.0):
    q = M / (2 * r); return (1 + q) ** 4, ((1 - q) / (1 + q)) ** 2           # A, N^2


def schw_dN_dr(r, M=1.0):
    q = M / (2 * r); return 2 * q / (r * (1 + q) ** 2)                          # N = (1 - q)/(1 + q), dq/dr = -q/r


def mixed(r, a=2.0, b=2.0):
    return 1 + a / r, 1 / (1 + b / r)                                         # A = 1 + a/r, N^-2 = 1 + b/r


def ppn(r, gamma=1.0, beta=1.0, M=1.0):
    U = M / r; return 1 + 2 * gamma * U, 1 - 2 * U + 2 * beta * U * U


def pencil(metric, r, u):
    A, N2 = metric(r); n2 = A * (1 / N2 - 1 + u) / u; return n2, u * n2


def pencil_wrong(metric, r, u):
    """Canary: the pencil without the rest-energy term -1 (A (N^-2 + u) / u)."""
    A, N2 = metric(r); n2 = A * (1 / N2 + u) / u; return n2, u * n2


# ------------------------------------------------------------------ exact Newton structure test
def newton_exclusion(Y, u, eps):
    off = [F(y) - F(v) for y, v in zip(Y, u)]; eps = F(eps)
    lo, hi = max(t - eps for t in off), min(t + eps for t in off); crit = (max(off) - min(off)) / 2
    if lo > hi:
        return {'status': 'EXCLUDED', 'critical': crit}
    return {'status': 'FEASIBLE', 'critical': crit, 'intercept': (lo + hi) / 2}


def third_speed_contrast(Y, u):
    """Affine pencil closure: Y at the middle speed minus the interpolation of the outer two."""
    w0 = (u[2] - u[1]) / (u[2] - u[0]); w2 = (u[1] - u[0]) / (u[2] - u[0]); return Y[1] - w0 * Y[0] - w2 * Y[2]


# ------------------------------------------------------------------ geodesics against the Jacobi reduction
def _metric_derivs(metric, r, h=1e-6):
    A, N2 = metric(r); Ap = (metric(r + h)[0] - metric(r - h)[0]) / (2 * h); N2p = (metric(r + h)[1] - metric(r - h)[1]) / (2 * h)
    return A, N2, Ap, N2p


def geodesic_sweep(metric, u, rho, R0=400.0):
    """Hamiltonian geodesic of -N^2 dt^2 + A(dr^2 + r^2 dphi^2), timelike (u < 1) or null (u = 1), started at r = R0
    inbound with E, L fixed by u and rho; returns the angle swept until r = R0 outbound."""
    if u < 1:
        E = 1 / math.sqrt(1 - u); L = rho * math.sqrt(E * E - 1); mu = 1.0
    else:
        E = 1.0; L = rho; mu = 0.0
    def H_pr(r):
        A, N2 = metric(r); val = A * (E * E / N2 - L * L / (A * r * r) - mu); return math.sqrt(max(val, 0.0))
    def rhs(s, y):
        r, pr, ph = y; A, N2, Ap, N2p = _metric_derivs(metric, r)
        # H = 1/2 (-E^2/N2 + pr^2/A + L^2/(A r^2)); dr/ds = pr/A; dpr/ds = -dH/dr; dphi/ds = L/(A r^2)
        dH = 0.5 * (E * E * N2p / N2 ** 2 - pr * pr * Ap / A ** 2 - L * L * (Ap * r * r + 2 * A * r) / (A * r * r) ** 2)
        return [pr / A, -dH, L / (A * r * r)]
    ev = lambda s, y: y[0] - R0
    ev.terminal = True; ev.direction = 1
    sol = solve_ivp(rhs, [0, 1e7], [R0 - 1e-9, -H_pr(R0), 0.0], events=ev, rtol=1e-12, atol=1e-12, method='DOP853')
    return float(sol.y_events[0][0][2])


def _turning(n2fun, rho, rmax=1e7):
    g = lambda r: r * r * n2fun(r) - rho * rho
    hi = max(rho, 10.0) * 4
    while g(hi) <= 0:
        hi *= 2
    lo = hi
    while g(lo) > 0 and lo > 1e-6:                                            # largest root: walk down from outside
        lo /= 1.05
    return brentq(g, lo, lo * 1.05 if g(lo * 1.05) > 0 else hi, xtol=1e-14, rtol=1e-15)


def jacobi_sweep(n2fun, rho, R0=None):
    """Angle swept from r0 to R0 and back for the optical metric n^2 (dr^2 + r^2 dphi^2); R0 = None gives infinity."""
    r0 = _turning(n2fun, rho); x1 = 0.0 if R0 is None else r0 / R0
    def integrand(s):                                                         # r = r0 / x, x = 1 - s^2 (1 - x1)
        x = 1 - s * s * (1 - x1); r = r0 / x; Fv = r * r * n2fun(r) - rho * rho
        if Fv <= 0:
            return 0.0
        return 2 * s * (1 - x1) * rho / (x * math.sqrt(Fv))
    val = quad(integrand, 0, 1, epsabs=1e-13, epsrel=1e-12, limit=400)[0]
    return 2 * val


def deflection(n2fun, rho): return jacobi_sweep(n2fun, rho) - math.pi


def firsov_n(chi, w, tmax=22.0):
    """Firsov: ln n(w) = (1/pi) int_0^inf chi(w cosh t) dt, w = r n(r) on the monotone branch."""
    return math.exp(quad(lambda t: chi(w * math.cosh(t)), 0, tmax, epsabs=1e-12, epsrel=1e-11, limit=300)[0] / math.pi)


def invert_at(chi, r, wmax):
    """n^2 at isotropic radius r from the deflection function: solve w / n(w) = r."""
    w = brentq(lambda w: w / firsov_n(chi, w) - r, r * 0.999, wmax, xtol=1e-12)
    return firsov_n(chi, w) ** 2


def critical_radius(metric, u, lo=0.51, hi=50.0):
    """Largest radius where d(r^2 n_u^2)/dr = 0; above it rho(r) increases (single turning branch)."""
    rho2 = lambda r: r * r * pencil(metric, r, u)[0]
    d = lambda r: (rho2(r * (1 + 1e-7)) - rho2(r * (1 - 1e-7))) / (2e-7 * r)
    grid = np.geomspace(lo, hi, 4000); vals = [d(r) for r in grid]
    last = max(i for i in range(len(grid) - 1) if vals[i] <= 0 < vals[i + 1])
    return brentq(d, grid[last], grid[last + 1], xtol=1e-13)


def areal(r, M=1.0): return r * (1 + M / (2 * r)) ** 2


# ------------------------------------------------------------------ the energy footprint: six readouts of N
def footprint(N, dN_dl):
    """Readouts per unit rest mass at a point with lapse N and proper-length gradient dN/dl (c = 1):
    clock (redshift to infinity), lowering energy delivered at infinity, rope force at infinity, local support
    (proper acceleration), path intercept P/A = N^-2 - 1, timing (Einstein/Newton coordinate speed)."""
    return {'clock': N, 'lowering': 1 - N, 'rope': dN_dl, 'support': dN_dl / N, 'path': N ** -2 - 1, 'timing': N ** 2}


def N_from(readout, value):
    return {'clock': lambda v: v, 'lowering': lambda v: 1 - v, 'path': lambda v: (1 + v) ** -0.5,
            'timing': lambda v: v ** 0.5}[readout](value)


def contract_boundaries(tol=F(1, 100), b=F(2)):
    """Radius (N^-2 = 1 + b/r) where the support/path discrepancy reaches tol under three contracts:
    exact path reference (1 - N^2), symmetric relative errors ((1 - N^2)/(1 + N^2)), rope at infinity (1 - N^3)."""
    r_exact = b * (1 - tol) / tol                                            # N^2 = 1 - tol
    r_sym = b * (1 - tol) / (2 * tol)                                        # N^2 = (1 - tol)/(1 + tol)
    r_rope = float(b) / ((1 - float(tol)) ** (-2.0 / 3.0) - 1)              # N^3 = 1 - tol
    return r_exact, r_sym, r_rope


# ------------------------------------------------------------------ one-footprint closure (clock against path)
def closure(radii, eps_clock, eps_path, alpha=0.0, noise=None, metric=schw):
    """At each radius the clock reads N^(1+alpha) within eps_clock and the path intercept reads N^-2 - 1 within
    relative eps_path. Returns per-radius N intervals and whether one N fits both everywhere."""
    out = []; ok = True
    for i, r in enumerate(radii):
        N = math.sqrt(metric(r)[1]); c = N ** (1 + alpha); p = N ** -2 - 1
        if noise is not None:
            c += noise[i][0] * eps_clock; p *= 1 + noise[i][1] * eps_path
        cl = (c - eps_clock, c + eps_clock)
        pl = ((1 + p * (1 + eps_path)) ** -0.5, (1 + p * (1 - eps_path)) ** -0.5)
        lo, hi = max(cl[0], pl[0]), min(cl[1], pl[1]); out.append((r, cl, pl)); ok = ok and lo <= hi
    return ok, out


def critical_alpha(radii, eps_clock, eps_path, metric=schw, hi=1.0):
    lo = 0.0
    for _ in range(80):
        mid = (lo + hi) / 2
        lo, hi = (lo, mid) if not closure(radii, eps_clock, eps_path, mid, metric=metric)[0] else (mid, hi)
    return lo, hi


# ------------------------------------------------------------------ interior and exterior (areal radius R)
def interior_N(R, Rs, M=1.0):
    if R >= Rs:
        return math.sqrt(1 - 2 * M / R)
    return 1.5 * math.sqrt(1 - 2 * M / Rs) - 0.5 * math.sqrt(1 - 2 * M * R * R / Rs ** 3)


def interior_grr(R, Rs, M=1.0):
    m = M * min(R, Rs) ** 3 / Rs ** 3 if R < Rs else M
    return 1 / (1 - 2 * m / R)


# ------------------------------------------------------------------ further fixtures
def expo(r, M=1.0):
    return 1.0, math.exp(-2 * M / r)                                          # flat h, N = exp(-M/r)


def coulomb(r, M=1.0):
    return 1.0, 1 / (1 + 2 * M / r)                                           # flat h, N^-2 - 1 = 2M/r: Newton's -M/r


def rutherford(b, u, kappa=1.0):
    """Newton in Phi = -kappa/r at squared speed u: tan(alpha/2) = kappa/(b u)."""
    return 2 * math.atan(kappa / (b * u))


# ------------------------------------------------------------------ Gauss-Bonnet split relative to the static congruence
def gb_split(metric, u, rho, h=1e-6):
    """alpha, A_E = int k_h dl_h (local law), A_S = int (1 - 1/B) dphi (B: areal radial factor), integrated over the
    orbit with dphi/dr from the Jacobi index."""
    n2f = lambda r: pencil(metric, r, u)[0]; r0 = _turning(n2f, rho)
    def dlnN(r): return (math.log(metric(r * (1 + h))[1]) - math.log(metric(r * (1 - h))[1])) / (4 * h * r)
    def dlnsA(r): return (math.log(metric(r * (1 + h))[0]) - math.log(metric(r * (1 - h))[0])) / (4 * h * r)
    def integ(s, which):
        x = 1 - s * s; r = r0 / x; Fv = r * r * n2f(r) - rho * rho
        if Fv <= 0:
            return 0.0
        dphi = 2 * s * rho / (x * math.sqrt(Fv))                              # dphi in the variable s
        if which == 'phi':
            return dphi
        A, N2 = metric(r)
        if which == 'E':
            vloc2 = 1.0 if u >= 1 else 1 - N2 * (1 - u)
            return r * dlnN(r) / vloc2 * dphi
        return -r * dlnsA(r) * dphi                                           # 1 - 1/B = -d ln sqrt(A) / d ln r
    q = lambda w: 2 * quad(lambda s: integ(s, w), 0, 1, epsabs=1e-13, epsrel=1e-12, limit=400)[0]
    return q('phi') - math.pi, q('E'), q('S')


# ------------------------------------------------------------------ failure theorem from relative angle errors
def firsov_L(alpha_fn, s, bmax):
    tm = math.acosh(bmax / s) if bmax > s else 0.0
    return quad(lambda t: alpha_fn(s * math.cosh(t)), 0, tm, epsabs=1e-13, epsrel=1e-11, limit=400)[0] / math.pi, tm


def envelope_ln_n(alpha_hat, rho, eps, bmax, K):
    """Rigorous bounds on ln n at isotropic radius rho from measured deflections alpha_hat with relative error eps
    (|alpha_hat - alpha| <= eps alpha, alpha >= 0) on b <= bmax and a declared tail 0 <= alpha <= K/b beyond.
    At fixed s: L_lo = L_hat/(1+eps), L_hi = L_hat/(1-eps) + tail. Transfer: ln n(rho) = ln(s/rho) with s solving
    s exp(-L_k(s)) = rho; monotone in s, so the true value lies between the two transferred values."""
    def L(s, k):
        Lh, tm = firsov_L(alpha_hat, s, bmax)
        if k == 'lo':
            return Lh / (1 + eps)
        tail = K / (math.pi * s) * (math.pi / 2 - 2 * math.atan(math.tanh(tm / 2)))
        return Lh / (1 - eps) + tail
    out = []
    for k in ('lo', 'hi'):
        s = brentq(lambda s: s * math.exp(-L(s, k)) - rho, rho, rho * 4, xtol=1e-13)
        out.append(math.log(s / rho))
    naive = [L(rho, 'lo'), L(rho, 'hi')]                                       # the fixed-s bound read at s = rho
    return out, naive


def psi2_interval(l1, l2, u1, u2):
    """psi^2 = (u1 n1^2 - u2 n2^2)/(u1 - u2) from intervals of ln n at two speeds (u1 < u2)."""
    n1 = [math.exp(2 * x) for x in l1]; n2 = [math.exp(2 * x) for x in l2]
    num = [u1 * n1[0] - u2 * n2[1], u1 * n1[1] - u2 * n2[0]]
    return sorted(v / (u1 - u2) for v in num)


def eps_crit(u1, u2, gamma=1.0):
    return gamma * abs(u2 - u1) / (2 + gamma * (u1 + u2))


def kappa_opt(u1, u2, gamma=1.0):
    """Coulomb strength whose weak-field relative deflection misses at u1, u2 are equal and opposite."""
    return 2 * (1 + gamma * u1) * (1 + gamma * u2) / (2 + gamma * (u1 + u2))
