#!/usr/bin/env python3
"""Resolution Geometry - hostile battery for the duality of gravity (rg_gravity.py).

  DA the Jacobi pencil, symbolically: from the normalization of timelike geodesics n_u^2 = A (N^-2 - 1 + u)/u, so
     Y = u n_u^2 = A u + P with P = A (N^-2 - 1); light gives A/N^2; Newton is slope one; the cross-speed miss is
     (A - 1)(u2 - u1) with the lapse cancelling; the middle speed of three is an exact affine interpolation
  DB the Jacobi reduction is checked against the Hamiltonian geodesic equations of the metric (conserved E, L only):
     swept angles agree to 1e-8 for Schwarzschild, a mixed fixture and an exponential lapse at u = 1/4, 1/2, 1; a pencil without the
     rest-energy term misses by > 5e-3
  DC the structure boundary in exact rationals: Newton's common intercept is excluded iff the bound is below
     eps* = (max - min of Y - u)/2; at equality a witness; mixed fixture boundary r = 7500 at eps = 1e-4; lapse only
     never excluded; one speed always admits a flat Newtonian mimic, which a second speed refutes; a third speed
     perturbed by 3e-4 breaks the affine pencil against a 2e-4 budget
  DD inversion: Firsov inversion of computed Schwarzschild deflection functions at r = 40 recovers A and N^2 to 1e-9
     and predicts the third speed; the single turning branch ends at the unstable circular orbit of the probe energy,
     (1 - 2/R)^2 (1 - u) = 1 - 3/R (areal 3 for light, 1 + sqrt5 at u = 1/2, 2 sqrt3 at u = 1/4, 4 as u -> 0); below
     it one optical radius has two isotropic radii (counterexample to uniqueness)
  DE identification: in PPN form A - 1 = 2 gamma U and P = 2U + (4 - 2 beta + 4 gamma) U^2; Schwarzschild has
     gamma = beta = 1; light deflection is 2(1 + gamma) M/b (Newton's corpuscle: half); solar limb 1.7512 against
     0.8756 arcsec; Cassini gamma - 1 = (2.1 +- 2.3)e-5 places gamma = 0 (flat structure) 4.3e4 standard errors away
  DF the energy footprint: for general A(r), N(r) the static observer's proper acceleration is d ln N / dl, the Killing
     energy of a static unit mass is N, the rope force at infinity is dN/dl, the timing ratio is N^2; each of the six
     readouts returns the same N; gradient ratios against the path potential are N^2 (support) and N^3 (rope); the 1%
     boundaries of the three contracts are r = 198, 99 and 297.5 for N^-2 = 1 + 2/r
  DG the footprint's unit hole: N -> lambda N, t -> t/lambda leaves the metric unchanged; local support and clock
     ratios do not see lambda (Fisher kernel = log lambda); a clock compared with infinity closes it
  DH one footprint: clock and path readouts at five radii admit one N for a metric field (seeded noise inside the
     bounds); a non-metric clock N^(1+alpha) empties the joint fibre above a critical alpha that equals the minimum
     over radii of the per-radius thresholds; strong fields are the sensitive ones
  DJ the local law and Gauss-Bonnet: paths bend across themselves by -(1/v_loc^2) d ln N (from the Jacobi factor); the
     deflection splits exactly as alpha = A_E + A_S (to 1e-9, three metrics, two speeds, two impact parameters); A_S = 0
     for flat structure; A_S/A_E -> gamma u in the weak field
  DK panels: exact Newton (Rutherford) has non-constant alpha u, yet two-speed inversion gives flat structure to 1e-9;
     a competitor metric matched to Schwarzschild at one impact parameter at two speeds (a CORRESPONDENCE) differs at
     other impact parameters and is separated by functional panels
  DL the failure theorem from relative angle errors, corrected: eps_crit = gamma |u2 - u1| / (2 + gamma (u1 + u2))
     (3/13, 1/3); the Firsov bound holds at fixed optical radius and is transferred to fixed isotropic radius through
     ln n = ln(s/rho), with a declared tail; noisy records exclude Newton at 0.5 eps_crit and not at 2 eps_crit, always
     covering the truth; read at fixed s as if at fixed radius the bound misses the truth in strong fields; noiseless
     thresholds rise to eps_crit with radius; a Coulomb witness fails at 0.99 and holds at 1.1 eps_crit
  DI the source room: constant-density stars of radius 6 and 10 and a point mass have identical exterior lapse and
     radial metric beyond 10 (Birkhoff); interiors differ; the interior lapse joins the exterior continuously

Seeds 1501, 1502. Writes rg_gravity_battery_results.json.
Run:  python3 -I rg_gravity_battery.py     (numpy, scipy, sympy; rg_units.py)
"""
import hashlib, json, math, os, sys, warnings
from fractions import Fraction as F
from pathlib import Path
import numpy as np
import sympy as sp

warnings.filterwarnings('ignore')
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rg_gravity as G
import rg_units as U

R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        if tag not in FAILS:
            FAILS.append(tag)
        print('FAILED', tag, flush=True)


# ------------------------------------------------------------------ DA
def group_DA():
    A, N, u, u1, u2, u3, Phi = sp.symbols('A N u u1 u2 u3 Phi', positive=True)
    E2 = 1 / (1 - u)
    n2 = sp.simplify((E2 / N ** 2 - 1) * A / (E2 - 1))                       # Jacobi factor normalised at infinity
    pencil = sp.simplify(n2 - A * (N ** -2 - 1 + u) / u) == 0
    Y = lambda v: A * v + A * (N ** -2 - 1)
    light = sp.simplify(sp.limit((sp.Symbol('E') ** 2 / N ** 2 - 1) / (sp.Symbol('E') ** 2 - 1), sp.Symbol('E'), sp.oo) * A - A / N ** 2) == 0
    newton = sp.simplify((Y(u).subs({A: 1, N: (1 - 2 * Phi) ** sp.Rational(-1, 2)})) - (u - 2 * Phi)) == 0
    miss = sp.simplify(Y(u2) - (u2 + Y(u1) - u1) - (A - 1) * (u2 - u1)) == 0
    affine = sp.simplify(Y(u2) - ((u3 - u2) / (u3 - u1) * Y(u1) + (u2 - u1) / (u3 - u1) * Y(u3))) == 0
    ok = pencil and light and newton and miss and affine
    must(ok, 'DA')
    R['DA'] = dict(claim='n_u^2 = A (N^-2 - 1 + u)/u; Y = A u + P; light A/N^2; Newton slope one; miss (A-1)(u2-u1); '
                         'three speeds affine', pencil=pencil, light=light, newton_slope_one=newton, cross_speed_miss=miss,
                   affine_three_speeds=affine)


# ------------------------------------------------------------------ DB
def group_DB():
    rows = []; worst = 0.0; canary = np.inf
    for name, met in (('schwarzschild', G.schw), ('mixed', G.mixed), ('exponential_lapse', G.expo)):
        for u in (0.25, 0.5, 1.0):
            g = G.geodesic_sweep(met, u, 15.0, R0=300.0)
            j = G.jacobi_sweep(lambda r: G.pencil(met, r, u)[0], 15.0, R0=300.0)
            w = G.jacobi_sweep(lambda r: G.pencil_wrong(met, r, u)[0], 15.0, R0=300.0)
            worst = max(worst, abs(g - j)); canary = min(canary, abs(g - w)); rows.append([name, u, g, j, abs(g - j)])
    ok = worst < 1e-8 and canary > 5e-3
    must(ok, 'DB')
    R['DB'] = dict(claim='Jacobi reduction agrees with the geodesic equations; the pencil without the rest-energy term does not',
                   rho=15.0, R0=300.0, rows=rows, worst=worst, canary_smallest_miss=canary)


# ------------------------------------------------------------------ DC
def group_DC():
    V = [F(1, 4), F(1, 2), F(1)]; eps = F(1, 10000)
    yy = lambda a, b, r, u: (1 + a / r) * (u + b / r)                       # A = 1 + a/r, N^-2 = 1 + b/r
    fixtures = {'mixed': (F(2), F(2)), 'lapse_only': (F(0), F(2)), 'structure_only': (F(2), F(0)), 'trivial': (F(0), F(0))}
    rows = {}; ok = True
    for name, (a, b) in fixtures.items():
        st = []
        for r in (4, 10, 40, 200, 10000):
            Y = [yy(a, b, F(r), u) for u in V]; c = G.newton_exclusion(Y, V, eps)
            ok = ok and c['critical'] == abs(a / r) * (V[-1] - V[0]) / 2
            edge = G.newton_exclusion(Y, V, c['critical']); ok = ok and edge['status'] == 'FEASIBLE'
            ok = ok and G.third_speed_contrast(Y, V) == 0
            st.append(c['status'])
        rows[name] = st
    ok = ok and all(s == 'FEASIBLE' for s in rows['lapse_only'] + rows['trivial']) and rows['mixed'][0] == 'EXCLUDED'
    rcrit = F(2) * (V[-1] - V[0]) / (2 * eps)                                # mixed: eps* = (2/r)(3/4)/2
    Yc = [yy(F(2), F(2), rcrit, u) for u in V]
    at = G.newton_exclusion(Yc, V, eps)['status']; below = G.newton_exclusion([yy(F(2), F(2), rcrit - 1, u) for u in V], V, eps)['status']
    mimic_ok = True
    for r in (4, 10, 40):
        Y1 = yy(F(2), F(2), F(r), V[0]); K = Y1 - V[0]                        # flat Newton fit at the first speed
        mimic_ok = mimic_ok and (V[0] + K == Y1) and (V[-1] + K != yy(F(2), F(2), F(r), V[-1]))
    Y = [yy(F(2), F(2), F(10), u) for u in V]; Y[1] += 3 * eps; contrast = G.third_speed_contrast(Y, V)
    ok = ok and rcrit == 7500 and at == 'FEASIBLE' and below == 'EXCLUDED' and mimic_ok and abs(contrast) > 2 * eps
    must(ok, 'DC')
    R['DC'] = dict(claim='Exact structure boundary eps* = half span of Y - u; r = 7500 for the mixed fixture; one speed always '
                         'mimicked; a perturbed third speed breaks the pencil', statuses=rows, mixed_boundary_r=str(rcrit),
                   status_at_boundary=at, status_just_inside=below, one_speed_mimic_refuted_by_second=mimic_ok,
                   third_speed_contrast=str(contrast), budget=str(2 * eps))


# ------------------------------------------------------------------ DD
def group_DD():
    r = 40.0; rec = {}
    for u in (0.25, 1.0, 0.5):
        n2f = lambda rr, u=u: G.pencil(G.schw, rr, u)[0]
        rec[u] = G.invert_at(lambda rho, n2f=n2f: G.deflection(n2f, rho), r, 3 * r)
    Y1, Y2 = 0.25 * rec[0.25], rec[1.0]; A = (Y2 - Y1) / 0.75; P = Y1 - A * 0.25; N2 = 1 / (1 + P / A)
    At, N2t = G.schw(r); pred = A + P / 0.5
    crit = {}
    for u in (1.0, 0.5, 0.25, 1e-4):
        rc = G.critical_radius(G.schw, u); Rc = G.areal(rc); x = 1 / Rc
        crit[u] = dict(isotropic=rc, areal=Rc, circular_orbit_residual=(1 - 2 * x) ** 2 * (1 - u) - (1 - 3 * x))
    rc1 = G.critical_radius(G.schw, 1.0); rho = lambda rr: rr * math.sqrt(G.pencil(G.schw, rr, 1.0)[0])
    two_radii = rho(0.8 * rc1) > rho(rc1) and rho(1.25 * rc1) > rho(rc1)
    ok = (abs(A - At) < 1e-9 and abs(N2 - N2t) < 1e-9 and abs(pred - rec[0.5]) < 1e-9
          and abs(crit[1.0]['areal'] - 3) < 1e-6 and abs(crit[0.5]['areal'] - (1 + math.sqrt(5))) < 1e-6
          and abs(crit[0.25]['areal'] - 2 * math.sqrt(3)) < 1e-6 and abs(crit[1e-4]['areal'] - 4) < 1e-3
          and all(abs(v['circular_orbit_residual']) < 1e-8 for v in crit.values()) and two_radii)
    must(ok, 'DD')
    R['DD'] = dict(claim='Firsov inversion at two speeds recovers A and N^2 and predicts a third; the turning branch ends at '
                         'the unstable circular orbit of the probe energy', r=r, recovered_A=A, true_A=At, recovered_N2=N2,
                   true_N2=N2t, third_speed_prediction_error=abs(pred - rec[0.5]), critical={str(k): v for k, v in crit.items()},
                   two_isotropic_radii_share_an_optical_radius=two_radii)


# ------------------------------------------------------------------ DE
def group_DE():
    Us, g, b = sp.symbols('U gamma beta', positive=True)
    A = 1 + 2 * g * Us; N2 = 1 - 2 * Us + 2 * b * Us ** 2
    P = sp.series(A * (1 / N2 - 1), Us, 0, 3).removeO()
    Pok = sp.expand(P - (2 * Us + (4 - 2 * b + 4 * g) * Us ** 2)) == 0
    As = sp.series((1 + Us / 2) ** 4, Us, 0, 2).removeO(); Ns = sp.series(((1 - Us / 2) / (1 + Us / 2)) ** 2, Us, 0, 3).removeO()
    gr = (sp.expand(As - 1).coeff(Us, 1) / 2 == 1) and (sp.expand(Ns).coeff(Us, 2) / 2 == 1)
    bimp = 1e5; defl = {}
    for gam in (1.0, 0.0):
        met = lambda r, gam=gam: G.ppn(r, gam, 1.0)
        defl[gam] = G.deflection(lambda r: G.pencil(met, r, 1.0)[0], bimp) * bimp / 2
    GM, Rsun, c = 1.32712440018e20, 6.957e8, 299792458.0; arc = 180 / math.pi * 3600
    limb_gr = 4 * GM / (Rsun * c * c) * arc; limb_newton = limb_gr / 2
    cassini = (2.1e-5, 2.3e-5); sigmas = (1 + cassini[0]) / cassini[1]
    ok = Pok and gr and abs(defl[1.0] - 2) < 1e-3 and abs(defl[0.0] - 1) < 1e-3 and abs(limb_gr - 1.7512) < 5e-4 and sigmas > 4e4
    must(ok, 'DE')
    R['DE'] = dict(claim='Structure channel = PPN gamma, footprint second order = beta; light bends 2(1+gamma)M/b; Cassini '
                         'excludes flat structure', P_series=str(sp.expand(P)), schwarzschild_gamma_beta_one=gr,
                   deflection_in_units_2M_over_b={'gamma=1': defl[1.0], 'gamma=0': defl[0.0]}, solar_limb_arcsec_GR=limb_gr,
                   solar_limb_arcsec_newton_corpuscle=limb_newton, cassini_gamma_minus_1=cassini, flat_structure_sigmas=sigmas)


# ------------------------------------------------------------------ DF
def group_DF():
    t, r, th, ph = sp.symbols('t r theta phi'); Af = sp.Function('A')(r); Nf = sp.Function('N')(r)
    g = sp.diag(-Nf ** 2, Af, Af * r ** 2, Af * r ** 2 * sp.sin(th) ** 2); X = [t, r, th, ph]; gi = g.inv()
    Gam = lambda a, b_, c_: sum(gi[a, d] * (sp.diff(g[d, b_], X[c_]) + sp.diff(g[d, c_], X[b_]) - sp.diff(g[b_, c_], X[d])) for d in range(4)) / 2
    ut = 1 / Nf; ar = sp.simplify(Gam(1, 0, 0) * ut ** 2)                      # static observer: a^r = Gamma^r_tt (u^t)^2
    support = sp.simplify(sp.sqrt(Af) * ar - sp.diff(Nf, r) / (Nf * sp.sqrt(Af))) == 0      # |a| = d ln N / dl
    killing_E = sp.simplify(-g[0, 0] * ut - Nf) == 0                          # E = -p_t = N^2 u^t = N
    v = sp.symbols('v', positive=True); Np = sp.symbols('N', positive=True)
    ein = Np * sp.sqrt(1 - Np ** 2 * (1 - v ** 2)); new = sp.sqrt(v ** 2 - 1 + Np ** -2)
    timing = sp.simplify(ein / new - Np ** 2) == 0
    kin = (1 - Np ** -2) / 2; ratios = (sp.simplify(sp.diff(sp.log(Np), Np) / sp.diff(kin, Np)), sp.simplify(1 / sp.diff(kin, Np)))
    ratio_ok = sp.simplify(ratios[0] - Np ** 2) == 0 and sp.simplify(ratios[1] - Np ** 3) == 0
    rr = 10.0; A0, N20 = G.schw(rr); N0 = math.sqrt(N20)
    dN_dl = G.schw_dN_dr(rr) / math.sqrt(A0)
    rd = G.footprint(N0, dN_dl); back = {k: G.N_from(k, rd[k]) for k in ('clock', 'lowering', 'path', 'timing')}
    from scipy.integrate import quad
    sup = lambda s: G.footprint(math.sqrt(G.schw(s)[1]), G.schw_dN_dr(s) / math.sqrt(G.schw(s)[0]))
    back['support'] = math.exp(-quad(lambda s: sup(s)['support'] * math.sqrt(G.schw(s)[0]), rr, np.inf, epsabs=1e-14, epsrel=1e-13, limit=400)[0])
    back['rope'] = 1 - quad(lambda s: sup(s)['rope'] * math.sqrt(G.schw(s)[0]), rr, np.inf, epsabs=1e-14, epsrel=1e-13, limit=400)[0]
    spread = max(abs(v_ - N0) for v_ in back.values())
    re, rs, rp = G.contract_boundaries(); Nsq = lambda rr_: 1 / (1 + 2 / rr_)
    contracts_ok = (re == 198 and rs == 99 and abs((1 - Nsq(float(re))) - 0.01) < 1e-15
                    and abs((1 - Nsq(float(rs))) / (1 + Nsq(float(rs))) - 0.01) < 1e-15 and abs(1 - Nsq(rp) ** 1.5 - 0.01) < 1e-12)
    expo = {r_: dict(support=(math.log(G.expo(r_ * (1 + 1e-7))[1]) - math.log(G.expo(r_ * (1 - 1e-7))[1])) / (4e-7 * r_) * r_ * r_,
                     ratio_N2=G.expo(r_)[1]) for r_ in (3.0, 1e4)}
    expo_ok = all(abs(v_['support'] - 1) < 1e-6 for v_ in expo.values()) and abs(expo[3.0]['ratio_N2'] - math.exp(-2 / 3)) < 1e-15
    ok = support and killing_E and timing and ratio_ok and spread < 1e-11 and contracts_ok and expo_ok
    must(ok, 'DF')
    R['DF'] = dict(claim='Six readouts of one lapse; support = dlnN/dl, Killing energy N, timing N^2; ratios N^2, N^3; three '
                         'contract boundaries', support_is_dlnN_dl=support, killing_energy_is_N=killing_E, timing_ratio_N2=timing,
                   gradient_ratios=[str(x) for x in ratios], N_true=N0, N_from_each=back, spread=spread,
                   one_percent_boundaries={'exact_path_reference': str(re), 'symmetric_errors': str(rs), 'rope_at_infinity': rp},
                   exponential_lapse_support_times_r2_and_N2=expo)


# ------------------------------------------------------------------ DG
def group_DG():
    lam, Nf, t, dt, dl = sp.symbols('lambda N t dt dl', positive=True)
    ds2 = -Nf ** 2 * dt ** 2 + dl ** 2; ds2b = -(lam * Nf) ** 2 * (dt / lam) ** 2 + dl ** 2
    invariant = sp.simplify(ds2 - ds2b) == 0
    r1, r2 = 6.0, 20.0
    def anchor_free(q):
        lamv, M = math.exp(q[0]), math.exp(q[1]); N = lambda r: lamv * math.sqrt(G.schw(r, M)[1])
        dN = lambda r: lamv * G.schw_dN_dr(r, M) / math.sqrt(G.schw(r, M)[0])          # gradient of lambda N per proper length
        return np.array([math.log(dN(r1) / N(r1)), math.log(dN(r2) / N(r2)), math.log(N(r1) / N(r2))])
    def anchored(q):
        lamv, M = math.exp(q[0]), math.exp(q[1]); return np.r_[anchor_free(q), math.log(lamv * math.sqrt(G.schw(r1, M)[1]))]
    q0 = np.array([0.0, 0.0]); K1, _ = U.fisher_kernel(anchor_free, q0); K2, _ = U.fisher_kernel(anchored, q0)
    ok = invariant and K1.shape[1] == 1 and abs(abs(K1[0, 0]) - 1) < 1e-9 and K2.shape[1] == 0
    must(ok, 'DG')
    R['DG'] = dict(claim='N -> lambda N, t -> t/lambda is a gauge; anchor-free readouts leave log lambda; a clock against '
                         'infinity closes it', metric_invariant=invariant, kernel_anchor_free=(K1[:, 0] * np.sign(K1[0, 0])).round(10).tolist() if K1.shape[1] else [],
                   kernel_with_clock_to_infinity=int(K2.shape[1]))


# ------------------------------------------------------------------ DH
def group_DH():
    radii = [3.0, 5.0, 10.0, 30.0, 100.0]; ec, ep = 1e-6, 1e-5
    rng = np.random.default_rng(1501); noise = rng.uniform(-0.9, 0.9, (len(radii), 2))
    ok_metric, _ = G.closure(radii, ec, ep, 0.0, noise)
    lo, hi = G.critical_alpha(radii, ec, ep)
    per = []
    for r in radii:
        f = lambda a, r=r: (lambda ok: 0.5 if ok else -0.5)(G.closure([r], ec, ep, a)[0])
        a_lo, a_hi = 0.0, 1.0
        for _ in range(80):
            m = (a_lo + a_hi) / 2; a_lo, a_hi = (m, a_hi) if f(m) > 0 else (a_lo, m)
        per.append(a_hi)
    above = G.closure(radii, ec, ep, 2 * hi)[0]; below = G.closure(radii, ec, ep, 0.5 * lo)[0]
    weak = G.critical_alpha([1e6], ec, ep)[1]
    ok = ok_metric and abs(hi - min(per)) < 1e-12 and not above and below and int(np.argmin(per)) == 0 and weak > 100 * hi
    must(ok, 'DH')
    R['DH'] = dict(claim='One footprint glues clock and path readouts; a non-metric clock N^(1+alpha) breaks it above the '
                         'smallest per-radius threshold; strong fields are sensitive', seed=1501, radii=radii, eps_clock=ec,
                   eps_path_relative=ep, metric_glues=bool(ok_metric), critical_alpha=[lo, hi], per_radius=per, weak_field_r_1e6=weak,
                   identification_galileo_redshift=dict(value=0.19e-5, sigma=2.48e-5, ref='Delva et al. PRL 121, 231101 (2018)'))


# ------------------------------------------------------------------ DI
def group_DI():
    outside = [10.0, 15.0, 40.0, 200.0]
    ext_same = max(abs(G.interior_N(R_, Rs) - math.sqrt(1 - 2 / R_)) + abs(G.interior_grr(R_, Rs) - 1 / (1 - 2 / R_))
                   for R_ in outside for Rs in (6.0, 10.0))
    inside_diff = abs(G.interior_N(8.0, 10.0) - G.interior_N(8.0, 6.0))
    join = max(abs(G.interior_N(Rs * (1 - 1e-12), Rs) - math.sqrt(1 - 2 / Rs)) for Rs in (6.0, 10.0))
    ok = ext_same < 1e-14 and inside_diff > 1e-3 and join < 1e-10
    must(ok, 'DI')
    R['DI'] = dict(claim='Exterior records do not see the interior: two stars and a point mass share the exterior (A, N)',
                   exterior_max_difference=ext_same, interior_difference_at_R8=inside_diff, surface_join=join)


# ------------------------------------------------------------------ DJ
def group_DJ():
    E, N, dN = sp.symbols('E N dN', positive=True)
    Fj = E ** 2 / N ** 2 - 1; vloc2 = 1 - N ** 2 / E ** 2
    local = sp.simplify(sp.diff(sp.log(Fj), N) * dN / 2 + dN / (N * vloc2)) == 0      # (1/2) d ln F = -(1/v_loc^2) d ln N
    rows = []; worst = 0.0; flat_S = 0.0; ratio = {}
    for name, met in (('schwarzschild', G.schw), ('mixed', G.mixed), ('exponential_lapse', G.expo)):
        for u in (0.25, 1.0):
            for rho in (15.0, 1e4):
                a, Ae, As = G.gb_split(met, u, rho); worst = max(worst, abs(a - Ae - As)); rows.append([name, u, rho, a, Ae, As])
                if name == 'exponential_lapse':
                    flat_S = max(flat_S, abs(As))
                if name == 'schwarzschild' and rho == 1e4:
                    ratio[u] = As / Ae
    ok = local and worst < 1e-9 and flat_S < 1e-12 and abs(ratio[0.25] - 0.25) < 1e-3 and abs(ratio[1.0] - 1.0) < 1e-3
    must(ok, 'DJ')
    R['DJ'] = dict(claim='Local law: paths bend by -(1/v_loc^2) d ln N across them; Gauss-Bonnet: alpha = A_E + A_S, A_S = 0 '
                         'for flat structure, A_S/A_E -> gamma u', local_law=local, gauss_bonnet_worst=worst,
                   flat_structure_A_S=flat_S, weak_field_ratio_AS_over_AE={str(k): v for k, v in ratio.items()}, rows=rows)


# ------------------------------------------------------------------ DK
def group_DK():
    from scipy.optimize import fsolve
    ruth_err = max(abs(G.deflection(lambda r: G.pencil(G.coulomb, r, u)[0], b) - G.rutherford(b, u)) for u in (0.25, 1.0) for b in (5.0, 50.0))
    slope = [u * G.rutherford(12.0, u) for u in (0.25, 1.0)]
    rec = {}
    for u in (0.25, 1.0):
        rec[u] = G.invert_at(lambda b, u=u: G.rutherford(b, u), 40.0, 120.0)
    psi2_coulomb = (rec[1.0] - 0.25 * rec[0.25]) / 0.75
    sch = {u: G.deflection(lambda r: G.pencil(G.schw, r, u)[0], 15.0) for u in (0.25, 1.0)}
    def comp(p, u, b):
        met = lambda r: G.mixed(r, p[0], p[1]); return G.deflection(lambda r: G.pencil(met, r, u)[0], b)
    p = fsolve(lambda p: [comp(p, u, 15.0) - sch[u] for u in (0.25, 1.0)], [2.0, 2.0], xtol=1e-13)
    match = max(abs(comp(p, u, 15.0) - sch[u]) for u in (0.25, 1.0))
    split = {b: abs(comp(p, 1.0, b) - G.deflection(lambda r: G.pencil(G.schw, r, 1.0)[0], b)) for b in (30.0, 100.0, 1000.0)}
    inv = {}
    for name, met in (('schwarzschild', G.schw), ('competitor', lambda r: G.mixed(r, p[0], p[1]))):
        n = {u: G.invert_at(lambda b, u=u, met=met: G.deflection(lambda r: G.pencil(met, r, u)[0], b), 40.0, 120.0) for u in (0.25, 1.0)}
        inv[name] = (n[1.0] - 0.25 * n[0.25]) / 0.75
    sep = abs(inv['schwarzschild'] - inv['competitor']); floor = abs(inv['schwarzschild'] - G.schw(40.0)[0])
    ok = (ruth_err < 1e-11 and abs(slope[0] - slope[1]) > 1e-3 and abs(psi2_coulomb - 1) < 1e-9 and match < 1e-10
          and min(split.values()) > 1e-6 and sep > 1e-4 and floor < 1e-9)
    must(ok, 'DK')
    R['DK'] = dict(claim='Exact Newton (Coulomb) has non-constant alpha u yet inverts to flat structure; a competitor matched '
                         'at one impact parameter at two speeds is a CORRESPONDENCE, separated by functional panels',
                   rutherford_error=ruth_err, alpha_u_at_b12=slope, coulomb_psi2_at_r40=psi2_coulomb,
                   competitor_params=[float(x) for x in p], match_at_b15=match, differences_elsewhere={str(k): v for k, v in split.items()},
                   functional_psi2=inv, separation=sep, reconstruction_floor=floor)


# ------------------------------------------------------------------ DL
def group_DL():
    u1, u2 = 0.25, 1.0; ec = G.eps_crit(u1, u2); bmax = 1e7; K = {u: 2 * (1 / u + 1) * 1.05 for u in (u1, u2)}
    true = {u: (lambda b, u=u: G.deflection(lambda r: G.pencil(G.schw, r, u)[0], b)) for u in (u1, u2)}
    rng = np.random.default_rng(1502); ph = rng.uniform(0, 2 * np.pi, 2); kk = rng.uniform(0.5, 1.5, 2)
    def test(eps, rho, noisy):
        ls, nv = [], []
        for i, u in enumerate((u1, u2)):
            f = true[u] if not noisy else (lambda b, u=u, i=i: true[u](b) * (1 + 0.9 * eps * math.sin(kk[i] * math.log(b) + ph[i])))
            band, naive = G.envelope_ln_n(f, rho, eps, bmax, K[u]); ls.append(band); nv.append(naive)
        return G.psi2_interval(ls[0], ls[1], u1, u2), G.psi2_interval(nv[0], nv[1], u1, u2)
    radii = (40.0, 100.0, 1e3, 1e4); noisy = {}
    for fac in (0.5, 2.0):
        st = []
        for rho in radii:
            P, _ = test(fac * ec, rho, True); At = G.schw(rho)[0]; st.append((P[0] > 1 or P[1] < 1, P[0] <= At <= P[1]))
        noisy[fac] = st
    counter = []
    for rho in (12.0, 15.0, 20.0, 40.0):
        P, Pn = test(1e-3, rho, False); At = G.schw(rho)[0]; counter.append((P[0] <= At <= P[1], Pn[0] <= At <= Pn[1]))
    thr = {}
    for rho in (40.0, 1e3, 1e4):
        lo, hi = 0.5 * ec, 1.5 * ec
        for _ in range(20):
            m = (lo + hi) / 2; P, _ = test(m, rho, False); lo, hi = (m, hi) if (P[0] > 1 or P[1] < 1) else (lo, m)
        thr[rho] = lo / ec
    kw = 1 + (u1 + u2) / 2; grid = np.geomspace(1e3, 1e7, 60)
    wit = {fac: max(abs(true[u](b) - G.rutherford(b, u, kw)) / (G.rutherford(b, u, kw) * fac * ec) for b in grid for u in (u1, u2)) for fac in (0.99, 1.1)}
    ok = (abs(ec - 3 / 13) < 1e-15 and abs(G.eps_crit(0.0, 1.0) - 1 / 3) < 1e-15
          and all(e and c for e, c in noisy[0.5]) and all((not e) and c for e, c in noisy[2.0])
          and all(b_ and not n_ for b_, n_ in counter)
          and 0.95 < thr[40.0] < thr[1e3] < 1.0 and thr[1e4] > 0.995 and wit[0.99] > 1 and wit[1.1] < 1)
    must(ok, 'DL')
    R['DL'] = dict(claim='Failure theorem from relative angle errors, corrected: band transfer to fixed radius, declared tail, '
                         'witness; the fixed-s reading fails in strong fields', seed=1502, eps_crit_v05_light=ec,
                   eps_crit_slow_light=G.eps_crit(0.0, 1.0), noisy_excluded_and_covered={str(k): v for k, v in noisy.items()},
                   band_vs_fixed_s_cover_at_eps_1e_3={str(r_): v for r_, v in zip((12, 15, 20, 40), counter)},
                   noiseless_threshold_over_eps_crit={str(k): v for k, v in thr.items()},
                   coulomb_witness_ratio_panel_b_ge_1e3=wit, witness_kappa=kw, tail_K=K, bmax=bmax)


GROUPS = dict(DA=group_DA, DB=group_DB, DC=group_DC, DD=group_DD, DE=group_DE, DF=group_DF, DG=group_DG, DH=group_DH, DI=group_DI, DJ=group_DJ, DK=group_DK, DL=group_DL)


def main():
    want = os.environ.get('RG_GRAVITY_GROUPS'); sel = want.split(',') if want else list(GROUPS)
    for g in sel:
        GROUPS[g]()                                               # a crash writes no results: never a pass, never a catch
        print(g, 'done', flush=True)
    R['failures'] = FAILS; R['groups_run'] = sel
    R['source_sha256'] = {f: hashlib.sha256((HERE / f).read_bytes()).hexdigest() for f in ('rg_gravity.py', 'rg_gravity_battery.py')}
    (HERE / 'rg_gravity_battery_results.json').write_text(json.dumps(R, indent=1, sort_keys=True, default=float))
    print(json.dumps({k: R[k] for k in sel}, indent=1, sort_keys=True, default=float)[:8000])
    return 1 if FAILS else 0


if __name__ == '__main__':
    sys.exit(main())
