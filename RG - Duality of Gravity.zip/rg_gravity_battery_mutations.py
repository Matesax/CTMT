#!/usr/bin/env python3
"""Mutation suite for rg_gravity_battery.py.

Each mutation changes one line of the library (or of the battery's reference computation) so that a claim of the
duality-of-gravity paper becomes false. It is caught only when the targeted group fails; the battery is run on that
group alone. A survivor is a defect of the battery; a crash is a defect of the suite, not a catch. Runs in temporary
copies.

    python3 -I rg_gravity_battery_mutations.py [--jobs 2] [--only UA,UB]
"""
import argparse, json, os, shutil, subprocess, sys, tempfile
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
NAME = 'rg_gravity_battery'
LIB = 'rg_gravity.py'
BAT = NAME + '.py'
MUTATIONS = [  # (group, description, file, old, new)
    ('DA', 'Jacobi factor without the rest-energy term', BAT, 'n2 = sp.simplify((E2 / N ** 2 - 1) * A / (E2 - 1))', 'n2 = sp.simplify((E2 / N ** 2) * A / (E2 - 1))'),
    ('DA', 'Newton given a spatial factor', BAT, 'subs({A: 1, N:', 'subs({A: 2, N:'),
    ('DB', 'pencil with a wrong rest-energy coefficient', LIB, 'A, N2 = metric(r); n2 = A * (1 / N2 - 1 + u) / u; return n2, u * n2', 'A, N2 = metric(r); n2 = A * (1 / N2 - 0.9 + u) / u; return n2, u * n2'),
    ('DB', 'geodesic angular momentum from E instead of the momentum at infinity', LIB, 'L = rho * math.sqrt(E * E - 1); mu = 1.0', 'L = rho * math.sqrt(E * E); mu = 1.0'),
    ('DC', 'critical bound halved', LIB, 'crit = (max(off) - min(off)) / 2', 'crit = (max(off) - min(off)) / 4'),
    ('DC', 'affine weights swapped', LIB, 'w0 = (u[2] - u[1]) / (u[2] - u[0]); w2 = (u[1] - u[0]) / (u[2] - u[0])', 'w2 = (u[2] - u[1]) / (u[2] - u[0]); w0 = (u[1] - u[0]) / (u[2] - u[0])'),
    ('DD', 'Firsov transform with a doubled denominator', LIB, 'epsrel=1e-11, limit=300)[0] / math.pi)', 'epsrel=1e-11, limit=300)[0] / (2 * math.pi))'),
    ('DD', 'deflection measured from a wrong straight line', LIB, 'def deflection(n2fun, rho): return jacobi_sweep(n2fun, rho) - math.pi', 'def deflection(n2fun, rho): return jacobi_sweep(n2fun, rho) - 0.99 * math.pi'),
    ('DE', 'second-order footprint coefficient with 2 gamma', BAT, '(4 - 2 * b + 4 * g)', '(4 - 2 * b + 2 * g)'),
    ('DE', 'structure channel with gamma, not 2 gamma', LIB, 'U = M / r; return 1 + 2 * gamma * U, 1 - 2 * U + 2 * beta * U * U', 'U = M / r; return 1 + gamma * U, 1 - 2 * U + 2 * beta * U * U'),
    ('DF', 'support read as the lapse gradient, not its logarithm', LIB, "'support': dN_dl / N", "'support': dN_dl"),
    ('DF', 'path readout inverted with the wrong power', LIB, "'path': lambda v: (1 + v) ** -0.5", "'path': lambda v: (1 + v) ** -1.0"),
    ('DF', 'symmetric contract with 1 + tol', LIB, 'r_sym = b * (1 - tol) / (2 * tol)', 'r_sym = b * (1 + tol) / (2 * tol)'),
    ('DG', 'an anchored readout put among the anchor-free ones', BAT, 'math.log(dN(r2) / N(r2)), math.log(N(r1) / N(r2))])', 'math.log(dN(r2) / N(r2)), math.log(N(r1))])'),
    ('DH', 'path interval without its error', LIB, 'pl = ((1 + p * (1 + eps_path)) ** -0.5, (1 + p * (1 - eps_path)) ** -0.5)', 'pl = ((1 + p) ** -0.5, (1 + p) ** -0.5)'),
    ('DH', 'non-metric exponent ignored by the clock', LIB, 'c = N ** (1 + alpha); p = N ** -2 - 1', 'c = N; p = N ** -2 - 1'),
    ('DI', 'exterior lapse depends on the star radius', LIB, '    if R >= Rs:\n        return math.sqrt(1 - 2 * M / R)', '    if R >= Rs:\n        return math.sqrt(1 - 2 * M / R) * (1 + 1e-9 * Rs)'),
    ('DI', 'exterior mass depends on the star radius', LIB, 'm = M * min(R, Rs) ** 3 / Rs ** 3 if R < Rs else M', 'm = M * min(R, Rs) ** 3 / Rs ** 3 if R < Rs else M * Rs / 10'),
    ('DJ', 'local speed of a massive probe taken as one', LIB, 'vloc2 = 1.0 if u >= 1 else 1 - N2 * (1 - u)', 'vloc2 = 1.0'),
    ('DJ', 'structural term with the wrong sign', LIB, 'return -r * dlnsA(r) * dphi', 'return r * dlnsA(r) * dphi'),
    ('DK', 'Rutherford with the speed, not its square', LIB, 'return 2 * math.atan(kappa / (b * u))', 'return 2 * math.atan(kappa / (b * math.sqrt(u)))'),
    ('DK', 'inversion with kinematic weight v instead of v^2', BAT, 'psi2_coulomb = (rec[1.0] - 0.25 * rec[0.25]) / 0.75', 'psi2_coulomb = (rec[1.0] - 0.5 * rec[0.25]) / 0.5'),
    ('DL', 'fixed-s bound read at fixed radius', LIB, '        out.append(math.log(s / rho))', '        out.append(L(rho, k))'),
    ('DL', 'critical bound with 1 for 2', LIB, 'return gamma * abs(u2 - u1) / (2 + gamma * (u1 + u2))', 'return gamma * abs(u2 - u1) / (1 + gamma * (u1 + u2))'),
    ('DL', 'witness strength equalising errors relative to the truth', BAT, 'kw = 1 + (u1 + u2) / 2', 'kw = G.kappa_opt(u1, u2)'),
    ('DL', 'lower Firsov bound without its error', LIB, '            return Lh / (1 + eps)', '            return Lh'),
]


def run(mut):
    group, desc, rel, old, new = mut
    base = open(os.path.join(HERE, rel)).read()
    if base.count(old) != 1:
        return group, desc, 'anchor not found exactly once -> SUITE DEFECT', False
    with tempfile.TemporaryDirectory() as tmp:
        work = os.path.join(tmp, 'b')
        shutil.copytree(HERE, work, ignore=shutil.ignore_patterns('__pycache__', NAME + '_results.json', NAME + '_mutations.py',
                                                                  '*.log', 'paper', '*.zip', 'r[0-9]*.json', 'RG_*bundle*', 'run*.log'))
        open(os.path.join(work, rel), 'w').write(base.replace(old, new))
        env = dict(os.environ, RG_GRAVITY_GROUPS=group)
        subprocess.run([sys.executable, '-I', NAME + '.py'], cwd=work, capture_output=True, text=True, env=env)
        try:
            fails = json.load(open(os.path.join(work, NAME + '_results.json')))['failures']
        except Exception:
            fails = ['CRASHED']
    ok = group in fails
    return group, desc, ('caught ' if ok else 'SURVIVED ') + str(fails), ok


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--jobs', type=int, default=2); ap.add_argument('--only', default='')
    a = ap.parse_args(); sel = [m for m in MUTATIONS if not a.only or m[0] in a.only.split(',')]
    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(run, sel))
    for g, d, msg, _ in res:
        print(f'{g}  {d}: {msg}', flush=True)
    caught = sum(r[3] for r in res)
    print(f'{caught} / {len(sel)} caught')
    return 0 if caught == len(sel) else 1


if __name__ == '__main__':
    sys.exit(main())
