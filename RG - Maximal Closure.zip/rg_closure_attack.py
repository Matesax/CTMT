#!/usr/bin/env python3
"""
RG maximal closure: battery CL01-CL06
=====================================
The dispatcher is wired to REAL certifiers (rank with double escalation, nonparametric Petz band, declared
anchor) on synthetic experiments with known ground truth; nothing is a hand-set boolean except declarations
(task, anchor), which are declarations by definition.

  CL01 totality and determinism of the dispatcher (structural lemma; exhaustive over certificate outcomes)
  CL02 composite soundness: false LOCKED rate with real certifiers vs the union bound; power on lockable cases
  CL03 sabotaged certifiers (single-shot rank, panel argmin, silent scale) produce false LOCKs (negative control)
  CL04 walls are window-indexed: a true wall and a near-wall full-rank law receive the same STRUCTURAL_WALL[eps]
  CL05 stationary slices: radar distance between co-rotating observers = Landau-Lifshitz spatial distance
  CL06 Sagnac: synchronization holonomy around a rotating loop = 4 Omega A / (c^2 sqrt(1 - Omega^2 R^2/c^2))

Run:  python3 rg_closure_attack.py [--seed 20261003] [--out FILE] [--canary]
"""
import argparse, itertools, json, math, sys, time
import numpy as np
from scipy.optimize import brentq

RESULTS, MUT = [], {}
STATUSES = ("LOCKED", "ESCALATE", "CORRESPONDENCE", "VACUOUS", "INCONSISTENT", "STRUCTURAL_WALL", "OUTSIDE_DOMAIN")


def f_(x): return float(np.round(float(x), 12))


def _finite(o):
    if isinstance(o, dict): return all(_finite(v) for v in o.values())
    if isinstance(o, (list, tuple)): return all(_finite(v) for v in o)
    if isinstance(o, float): return math.isfinite(o)
    return True


def register(aid, naive, keep, passed, ev, verdict):
    if not _finite(ev): passed, verdict = False, "NONFINITE"
    RESULTS.append(dict(id=aid, naive_claim=naive, rg_claim=keep, passed=bool(passed), verdict=verdict, evidence=ev))
    print(f"[{'PASS' if passed else 'FAIL'}] {aid} {verdict:16s} {keep[:84]}")


# ------------------------------------------------------------------ dispatcher (pure function of certificates)
def dispatch(c):
    """c: dict of certificate outcomes. Order: domain, consistency, task, vacuity, rank, candidate, scale."""
    if not c["domain"]: return "OUTSIDE_DOMAIN"
    if not c["consistent"]: return "INCONSISTENT"
    if not c["task"]: return "CORRESPONDENCE"                       # undeclared task: the whole family
    if c["task_rank"] == 0: return "VACUOUS"
    if c["rank"] == "UPPER-BOUND": return "ESCALATE" if c["budget"] else "STRUCTURAL_WALL"
    if c["survivors"] == 0: return "INCONSISTENT"
    if c["survivors"] > 1: return "CORRESPONDENCE"
    if not c["scale"]: return "CORRESPONDENCE"                      # scale family (dilation fibre)
    return "LOCKED"


def CL01_totality(rng):
    space = dict(domain=(0, 1), consistent=(0, 1), task=(0, 1), task_rank=(0, 2), rank=("FULL", "UPPER-BOUND"),
                 budget=(0, 1), survivors=(0, 1, 2), scale=(0, 1))
    keys = list(space); n = 0; outs = set(); bad = 0
    for vals in itertools.product(*space.values()):
        c = dict(zip(keys, vals)); o = dispatch(c); n += 1; outs.add(o)
        all_pass = c["domain"] and c["consistent"] and c["task"] and c["task_rank"] and c["rank"] == "FULL" and c["survivors"] == 1 and c["scale"]
        bad += (o == "LOCKED") != bool(all_pass)
        bad += o not in STATUSES
    passed = bad == 0 and outs == set(STATUSES)
    register("CL01", "Closure is an empirical property that stress tests establish.",
             "Totality and determinism are structural: the dispatcher is a decision procedure, so on every combination of "
             "certificate outcomes it returns exactly one status, LOCKED iff every gate passes (exhaustive, by "
             "construction). Its content lies in the soundness of the gates, which CL02 tests.",
             passed, dict(combinations=n, lock_iff_all_pass_violations=int(bad), statuses_reached=sorted(outs)), "HOLDS")


# ------------------------------------------------------------------ real certifiers
def fbkm(t): return 1.0 if abs(t-1) < 1e-9 else (t-1)/math.log(t)
def fsld(t): return (1+t)/2
def fwy(t): return ((1+math.sqrt(t))/2)**2
PANEL = dict(BKM=fbkm, SLD=fsld, WY=fwy)


def rank_cert(s, rng, budget_steps, tau=0.005, single=False):
    """double-escalation certificate on J = diag(1, s) + noise; returns ('FULL'|'UPPER-BOUND', steps used)."""
    def q(n, reps=120):
        v = [np.linalg.svd(np.diag([1.0, s])+rng.normal(0, 0.05/np.sqrt(n), (2, 2)), compute_uv=False)[-1] for _ in range(reps)]
        return np.quantile(v, [0.01, 0.5])
    if single:                                    # sabotage: numerical rank of noisy data (sigma_hat > 0 => full);
        return ("FULL" if q(2000)[1] > 1e-12 else "UPPER-BOUND"), 1   # first version (point estimate vs tau) was too mild
    ns = [2000*4**k for k in range(budget_steps+1)]
    for k in range(len(ns)-1):
        a, b = q(ns[k]), q(ns[k+1])
        if a[0] > tau and b[0] > tau: return "FULL", k+1
    return "UPPER-BOUND", len(ns)-1


def petz_cert(ftrue, noise, rng, argmin=False):
    """nonparametric band: reconstruct f on 30 ratios; survivors = members within 5*noise everywhere."""
    ts = np.linspace(1.1, 30, 30)
    fh = np.array([ftrue(t)*(1+noise*rng.normal()) for t in ts])
    dev = {k: float(np.max(np.abs(fh-np.array([f(t) for t in ts]))/fh)) for k, f in PANEL.items()}
    if argmin: return [min(dev, key=dev.get)], dev
    return [k for k, d in dev.items() if d < 5*noise], dev


def make_instance(rng):
    s = rng.choice([0.0, 0.003, 0.08], p=[0.2, 0.2, 0.6])
    kind = rng.choice(["member", "mix_in", "mix_out"], p=[0.6, 0.2, 0.2])
    noise = float(rng.choice([1e-5, 1e-3]))
    mem = str(rng.choice(list(PANEL)))
    other = str(rng.choice([k for k in PANEL if k != mem]))
    gap = 0.07
    w = {"member": 0.0, "mix_in": 0.1*noise/gap, "mix_out": 0.3}[kind]
    fa, fb = PANEL[mem], PANEL[other]
    ftrue = (lambda t, fa=fa, fb=fb, w=w: (1-w)*fa(t)+w*fb(t))
    return dict(s=s, kind=kind, noise=noise, member=mem, w=w, ftrue=ftrue,
                task=bool(rng.random() < 0.9), task_rank=0 if rng.random() < 0.05 else 2, scale=bool(rng.random() < 0.9))


def truth_lockable(inst, tau=0.005):
    """ground truth: the requested module (metric with sigma_min >= tau, Petz member within band, anchored scale)
    exists uniquely. Band semantics: a member within 5*noise of f_true counts as the true member."""
    ts = np.linspace(1.1, 30, 30)
    within = [k for k, f in PANEL.items() if np.max(np.abs(np.array([inst["ftrue"](t)-f(t) for t in ts]))/np.array([inst["ftrue"](t) for t in ts])) < 2*inst["noise"]]
    ok = inst["task"] and inst["task_rank"] > 0 and inst["s"] >= tau and inst["scale"] and len(within) == 1
    return ok, within


def run_pipeline(inst, rng, sabotage=None):
    sab = sabotage or {}
    rank, _ = rank_cert(inst["s"], rng, 2, single=sab.get("single_rank", False))
    surv, _ = petz_cert(inst["ftrue"], inst["noise"], rng, argmin=sab.get("argmin", False))
    c = dict(domain=1, consistent=1, task=int(inst["task"]), task_rank=inst["task_rank"], rank=rank, budget=0,
             survivors=len(surv), scale=int(inst["scale"] or sab.get("silent_scale", False)))
    return dispatch(c), surv


def CL02_soundness(rng):
    N = MUT.get("cl02_n", 400); false_lock = 0; locks = 0; lockable = 0; locked_lockable = 0; counts = {}
    for _ in range(N):
        inst = make_instance(rng); ok, within = truth_lockable(inst)
        out, surv = run_pipeline(inst, rng, MUT.get("cl02_sabotage"))
        counts[out] = counts.get(out, 0)+1
        if out == "LOCKED":
            locks += 1; false_lock += (not ok) or (surv[0] not in within)
        lockable += ok; locked_lockable += ok and out == "LOCKED"
    power = locked_lockable/max(lockable, 1)
    passed = false_lock == 0 and power > 0.8
    register("CL02", "A dispatcher that never falsely locks on boolean inputs never falsely locks on data.",
             "With real certifiers (double-escalation rank, nonparametric Petz band, declared anchor) on instances with "
             "known truth, false LOCKED = 0 and power on lockable instances > 0.8. Soundness of a LOCK is inherited from "
             "the gates: P(false LOCK) <= sum of gate error rates.",
             passed, dict(instances=N, locks=locks, false_locks=false_lock, lockable=lockable, power=f_(power), status_counts=counts),
             "HOLDS")


def CL03_sabotage(rng):
    out = {}
    for name, sab in (("single_shot_rank", dict(single_rank=True)), ("panel_argmin", dict(argmin=True)),
                      ("silent_scale", dict(silent_scale=True))):
        r = np.random.default_rng(rng.integers(1 << 30)); fl = 0
        for _ in range(300):
            inst = make_instance(r); ok, within = truth_lockable(inst)
            o, surv = run_pipeline(inst, r, sab)
            fl += o == "LOCKED" and ((not ok) or (surv[0] not in within))
        out[name] = fl
    passed = all(v > 0 for v in out.values()) and not MUT.get("cl03_pretend")
    register("CL03", "Any dispatcher with the right decision order is sound.",
             "No: with the same dispatcher, numerical rank of noisy data, a panel argmin, or a silently assigned scale each "
             "produce false LOCKs on real data. Closure is exactly as sound as its weakest certificate.",
             passed, dict(false_locks_per_sabotage=out), "FALSIFIED-naive")


def CL04_window_walls(rng):
    """budget exhausted: true wall (s=0) and near wall (s=0.003, full rank) both end as UPPER-BOUND -> STRUCTURAL_WALL
    with the same eps; a far law (s=0.08) is FULL. The wall certificate is STRUCTURAL_WALL[eps], never absolute."""
    res = {}
    for s in (0.0, 0.003, 0.08):
        r, steps = rank_cert(s, rng, 2)
        c = dict(domain=1, consistent=1, task=1, task_rank=2, rank=r, budget=0, survivors=1, scale=1)
        res[str(s)] = dict(cert=r, status=dispatch(c), steps=steps)
    passed = (res["0.0"]["status"] == res["0.003"]["status"] == "STRUCTURAL_WALL" and res["0.08"]["status"] == "LOCKED")
    register("CL04", "A STRUCTURAL_WALL status certifies persistent rank loss.",
             "Only relative to the escalation window: a true wall and a full-rank law with sigma_min = 0.003 < tau both end "
             "as STRUCTURAL_WALL[eps = tau] after the budget; exact walls come only from the exact (model) layer.",
             passed, dict(by_sigma_min=res), "FALSIFIED-naive")


# ------------------------------------------------------------------ stationary slices (rotating frame, c = 1)
def radar_corotating(R, Om, phi0):
    """inertial computation: observers at radius R rotating with Om; A at angle 0, B at phi0 at t=0.
    Round trip A -> B -> A; proper time at A; radar distance = tau/2 (c = 1)."""
    A = lambda t: R*np.array([math.cos(Om*t), math.sin(Om*t)])
    B = lambda t: R*np.array([math.cos(phi0+Om*t), math.sin(phi0+Om*t)])
    t1 = brentq(lambda t: np.linalg.norm(B(t)-A(0))-t, 1e-12, 10)
    t2 = brentq(lambda t: np.linalg.norm(A(t)-B(t1))-(t-t1), t1+1e-12, t1+10)
    return 0.5*t2*math.sqrt(1-Om*Om*R*R)


def ll_distance(R, Om, phi0):
    """Landau-Lifshitz spatial metric of the rotating frame along the circle r = R (dl = R dphi / sqrt(1-Om^2 R^2))."""
    return R*phi0/math.sqrt(1-Om*Om*R*R)


def CL05_stationary_radar(rng):
    rows = []
    for phi0 in (0.2, 0.1, 0.05, 0.025):
        R, Om = 1.0, 0.5
        rows.append(abs(radar_corotating(R, Om, phi0)/ll_distance(R, Om, phi0)-1))
    order = math.log(rows[0]/rows[-1])/math.log(8)
    naive = abs(radar_corotating(1.0, 0.5, 0.05)/(1.0*0.05)-1)       # rod = Euclidean arc in the inertial frame
    passed = rows[-1] < 1e-3 and abs(order-2) < 0.2 and naive > 0.1
    register("CL05", "Outside static slices radar distance has no geometric meaning.",
             "On stationary (non-static) slices radar distance between nearby observers is the Landau-Lifshitz spatial "
             "metric (error of order 2 in separation); the inertial arc length differs by 15%. Stationary slices are "
             "locked; non-stationary ones remain open.",
             passed, dict(rel_err_by_separation=[f_(x) for x in rows], convergence_order=f_(order), inertial_arc_error=f_(naive)),
             "FALSIFIED-naive")


def CL06_sagnac(rng):
    """co- and counter-propagating light around a ring of radius R rotating with Om; proper-time difference at the
    source vs 4 Om A / sqrt(1 - Om^2 R^2) (c = 1): synchronization holonomy, zero iff Om = 0."""
    out = []
    for Om in (0.0, 0.1, 0.3, 0.6):
        R = 1.0
        tp = 2*math.pi*R/(1-Om*R); tm = 2*math.pi*R/(1+Om*R)            # inertial times (light along the ring)
        dtau = (tp-tm)*math.sqrt(1-Om*Om*R*R)
        pred = 4*Om*math.pi*R*R/math.sqrt(1-Om*Om*R*R)
        out.append((Om, dtau, pred))
    err = max(abs(d-p) for _, d, p in out)
    passed = err < 1e-12 and out[0][1] == 0.0 and out[-1][1] > 1
    register("CL06", "Clock synchronization along closed loops is a convention without invariant content.",
             "On a stationary slice, loop synchronization has holonomy 4 Omega A / sqrt(1-Omega^2 R^2) (Sagnac), "
             "zero iff the slice is static; it is the time-orientation analogue of scale holonomy.",
             passed, dict(rows=[dict(Omega=o, dtau=f_(d), predicted=f_(p)) for o, d, p in out], max_error=f_(err)), "HOLDS")


ATTACKS = [CL01_totality, CL02_soundness, CL03_sabotage, CL04_window_walls, CL05_stationary_radar, CL06_sagnac]


def run_all(seed):
    for a in ATTACKS:
        rng = np.random.default_rng([seed, ATTACKS.index(a)])
        try: a(rng)
        except Exception as ex: register(a.__name__[:4], "?", f"EXCEPTION {ex!r}", False, {}, "ERROR")


def canary(seed):
    muts = [("CL02", {"cl02_sabotage": dict(argmin=True)}), ("CL02", {"cl02_sabotage": dict(single_rank=True)}),
            ("CL02", {"cl02_sabotage": dict(silent_scale=True)})]
    ok = True
    for tgt, m in muts:
        RESULTS.clear(); MUT.clear(); MUT.update(m); print(f"--- canary {tgt}: {m}")
        a = next(x for x in ATTACKS if x.__name__.startswith(tgt))
        try: a(np.random.default_rng([seed, ATTACKS.index(a)])); caught = not RESULTS[-1]["passed"]
        except Exception as ex: print(f"    exception {ex!r} (not a clean catch)"); caught = False
        ok &= caught; print(f"    {'CAUGHT' if caught else 'NOT CAUGHT'}")
    MUT.clear(); print("CANARY:", "all caught" if ok else "BATTERY TOO WEAK"); return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--seed", type=int, default=20261003)
    ap.add_argument("--out", default="rg_closure_results.json"); ap.add_argument("--canary", action="store_true")
    a = ap.parse_args()
    if a.canary: sys.exit(canary(a.seed))
    t0 = time.time(); print(f"RG closure battery, seed {a.seed}\n"); run_all(a.seed)
    n = sum(r["passed"] for r in RESULTS)
    summ = dict(seed=a.seed, n_checks=len(RESULTS), n_pass=n, runtime_s=round(time.time()-t0, 1))
    json.dump(dict(summary=summ, results=RESULTS), open(a.out, "w"), indent=2,
              default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print(f"\n{n}/{len(RESULTS)} pass."); sys.exit(0 if n == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
