# RG - Maximal Closure: battery CL01-CL06

    python3 rg_closure_attack.py            # seed 20261003
    python3 rg_closure_attack.py --canary   # three sabotaged certificates; each must produce false LOCKs

6/6 on seeds 20261003, 1, 42, 777, 2026; canary 3/3.
