"""What the rooting theorem (Cencov + Hessian) closes inside RG. Deterministic battery (no random sampling).
X1 local comparability: D_f / chi^2 -> f''(1)/2 at the diagonal (symbolic series) -> zero sets and exponents are divergence-invariant
X2 forgetting rates: local (Hessian) rate = eta_chi2 = second singular value^2; global band eta_chi2 <= eta_KL <= eta_TV
   (binary symmetric channel: chi2 = KL < TV; Z-channel: strict band)
X3 doubling map at dyadic resolution k: exact Markov partition; information about the initial cell falls by exactly 1 bit per step
   (= Lyapunov exponent / ln 2 = KS entropy) and is zero after k steps; rational rotation (permutation) never forgets
X4 logistic map r = 4: Fisher information about r grows like exp(2 lambda n), lambda = ln 2 (300-digit arithmetic)
X5 walls: RLCT from deterministic quadrature of Z_n = int exp(-n K): theta^4 -> 1/4; theta1^2 theta2^2 -> 1/2 (m = 2); regular -> d/2;
   the singular Bernoulli model gives the same lambda for KL and chi^2 (divergence-invariant)
X6 lossless dynamics: discrete cat map is a permutation; every f-divergence between pushed laws is invariant (exact integers)
Run: python rg_rooting_closure.py   (numpy, scipy, sympy, mpmath)
"""
import json, math, hashlib, pathlib
import numpy as np
import sympy as sp
import mpmath as mp
from scipy.integrate import quad, dblquad
from scipy.optimize import minimize_scalar
RES = {}
def must(c, m):
    if not c: raise AssertionError(m)

# ---------------- X1 local comparability (symbolic)
e = sp.Symbol("e"); fsym = {"KL": lambda t: t * sp.log(t), "Hellinger^2": lambda t: (sp.sqrt(t) - 1) ** 2,
                            "chi2": lambda t: (t - 1) ** 2, "Jensen-Shannon": lambda t: t * sp.log(2 * t / (1 + t)) + sp.log(2 / (1 + t))}
ratios = {}
for name, f in fsym.items():
    # for a single cell with ratio t = 1 + e: f(1+e) / e^2 -> f''(1)/2 ; f''(1) via diff
    t = sp.Symbol("t"); fpp = sp.diff(f(t), t, 2).subs(t, 1)
    lead = sp.limit(f(1 + e) - sp.diff(f(t), t).subs(t, 1) * e, e, 0)
    ser = sp.series(f(1 + e) - sp.diff(f(t), t).subs(t, 1) * e, e, 0, 3).removeO()
    ratios[name] = dict(f2=str(sp.nsimplify(fpp)), leading=str(sp.simplify(ser)))
    must(sp.simplify(ser - fpp / 2 * e ** 2) == 0, f"X1 {name}")
RES["X1"] = dict(claim="Each smooth f-divergence equals (f''(1)/2) chi^2 (1 + O(max|p/q - 1|)): zero sets, vanishing orders, "
                       "Lojasiewicz exponents and RLCTs coincide for all admissible divergences", status="PROVED (Taylor) + symbolic", cases=ratios)

# ---------------- X2 contraction coefficients
def eta_chi2(K, pi):
    """second singular value squared of diag(K pi)^(-1/2) K diag(pi)^(1/2)"""
    q = K @ pi; B = np.diag(q ** -0.5) @ K @ np.diag(pi ** 0.5); s = np.linalg.svd(B, compute_uv=False); return float(s[1] ** 2)
def eta_tv(K): return float(max(0.5 * np.abs(K[:, i] - K[:, j]).sum() for i in range(K.shape[1]) for j in range(K.shape[1])))
def kl(a, b): return float(np.sum(a * np.log(a / b)))
def eta_kl(K, pi, grid=4001):
    best = 0.0
    for a in np.linspace(1e-4, 1 - 1e-4, grid):
        p = np.array([a, 1 - a])
        if abs(a - pi[0]) < 1e-6: continue
        best = max(best, kl(K @ p, K @ pi) / kl(p, pi))
    return best
eps = 0.1; BSC = np.array([[1 - eps, eps], [eps, 1 - eps]]); pi = np.array([0.5, 0.5])
Zc = np.array([[1.0, 0.3], [0.0, 0.7]]); piz = np.array([0.5, 0.5])
x2 = dict(BSC=dict(chi2=eta_chi2(BSC, pi), KL=eta_kl(BSC, pi), TV=eta_tv(BSC), exact_chi2=(1 - 2 * eps) ** 2),
          Z=dict(chi2=eta_chi2(Zc, piz), KL=eta_kl(Zc, piz), TV=eta_tv(Zc)))
must(abs(x2["BSC"]["chi2"] - 0.64) < 1e-12 and abs(x2["BSC"]["KL"] - 0.64) < 1e-4 and abs(x2["BSC"]["TV"] - 0.8) < 1e-12, "X2 BSC")
must(x2["Z"]["chi2"] <= x2["Z"]["KL"] + 1e-9 <= x2["Z"]["TV"] + 1e-9, "X2 band")
RES["X2"] = dict(claim="Local (Hessian) forgetting rate is divergence-independent (= eta_chi2 = squared maximal correlation); finite rates form a band "
                       "eta_chi2 <= eta_f <= eta_TV", status="PROVED (local, via Theorem A) + IMPORTED (band: Cohen-Kemperman-Zbaganu, Raginsky)", values=x2)

# ---------------- X3 doubling map, dyadic Markov partition; rotation canary
def doubling_matrix(k):
    N = 2 ** k; P = np.zeros((N, N))
    for j in range(N): P[(2 * j) % N, j] += 0.5; P[(2 * j + 1) % N, j] += 0.5
    return P
def mutual_info_bits(P, n):
    N = P.shape[0]; Pn = np.linalg.matrix_power(P, n); joint = Pn / N        # uniform prior on initial cells
    py = joint.sum(1); I = 0.0
    for y in range(N):
        for x in range(N):
            if joint[y, x] > 0: I += joint[y, x] * math.log2(joint[y, x] / (py[y] / N))
    return I
k = 6; P = doubling_matrix(k)
info = [mutual_info_bits(P, n) for n in range(0, k + 2)]
must(all(abs(info[n] - max(k - n, 0)) < 1e-9 for n in range(len(info))), "X3 doubling")
R = np.roll(np.eye(2 ** k), 1, axis=0)                                       # rotation by one cell: permutation
rot_info = [mutual_info_bits(R, n) for n in range(0, 8)]
must(all(abs(x - k) < 1e-9 for x in rot_info), "X3 rotation")
RES["X3"] = dict(claim="At dyadic resolution k the doubling map loses exactly 1 bit per step about the initial cell (Lyapunov ln 2 = KS entropy) and "
                       "forgets completely after k steps; a rotation (lossless re-description) never forgets",
                 status="PROVED (exact Markov partition) + executed", info_bits_doubling=[round(x, 12) for x in info], info_bits_rotation=[round(x, 12) for x in rot_info])

# ---------------- X4 logistic map: Fisher about r grows like exp(2 lambda n)
mp.mp.dps = 300
r = mp.mpf(4); x = mp.mpf("0.2137"); s = mp.mpf(0); logs = []
for n in range(1, 81):
    s = x * (1 - x) + r * (1 - 2 * x) * s; x = r * x * (1 - x); logs.append(float(mp.log(s * s)))
ns = np.arange(1, 81); sl = float(np.polyfit(ns[20:], np.array(logs)[20:], 1)[0])
must(abs(sl - 2 * math.log(2)) < 0.15, f"X4 slope {sl}")
RES["X4"] = dict(claim="Chaos amplifies parameter Fisher information: (dx_n/dr)^2 grows like exp(2 lambda n), lambda = ln 2 at r = 4",
                 status="EXECUTED (300-digit arithmetic, one fixed initial point)", fitted_rate=sl, two_lambda=2 * math.log(2))

# ---------------- X5 RLCT by deterministic quadrature
def slope(Zfun, ns, m=1):
    y = np.array([math.log(Zfun(n)) for n in ns]); X = np.column_stack([np.log(ns), np.log(np.log(ns)), np.ones(len(ns))])
    if m == 1: X = X[:, [0, 2]]
    coef = np.linalg.lstsq(X, y, rcond=None)[0]; return float(-coef[0])
ns = np.array([1e3, 3e3, 1e4, 3e4, 1e5, 3e5, 1e6, 3e6, 1e7])
Z1 = lambda n: quad(lambda t: math.exp(-n * t ** 4), -1, 1, points=[0], limit=400)[0]
Zreg = lambda n: (quad(lambda u: math.exp(-u * u), -min(math.sqrt(n), 40.0), min(math.sqrt(n), 40.0), points=[0], limit=400)[0] / math.sqrt(n)) ** 2   # rescaled t = u/sqrt(n)
def Z2(n):
    inner = lambda t2: quad(lambda t1: math.exp(-n * t1 ** 2 * t2 ** 2), -1, 1, points=[0], limit=400)[0]
    return quad(inner, -1, 1, points=[0], limit=400)[0]
p_th = lambda t: np.array([0.5 + t * t, 0.5 - t * t])
KLb = lambda t: float(np.sum(p_th(t) * np.log(p_th(t) / np.array([0.5, 0.5])))) if t != 0 else 0.0
CHb = lambda t: float(np.sum((p_th(t) - 0.5) ** 2 / 0.5))
ZKL = lambda n: quad(lambda t: math.exp(-n * KLb(t)), -0.5, 0.5, points=[0], limit=400)[0]
ZCH = lambda n: quad(lambda t: math.exp(-n * CHb(t)), -0.5, 0.5, points=[0], limit=400)[0]
lam = dict(theta4=slope(Z1, ns), regular_2d=slope(Zreg, ns), product_2d=slope(Z2, ns, m=2),
           bernoulli_singular_KL=slope(ZKL, ns), bernoulli_singular_chi2=slope(ZCH, ns))
must(abs(lam["theta4"] - 0.25) < 0.01 and abs(lam["regular_2d"] - 1.0) < 0.01 and abs(lam["product_2d"] - 0.5) < 0.05
     and abs(lam["bernoulli_singular_KL"] - 0.25) < 0.01 and abs(lam["bernoulli_singular_chi2"] - 0.25) < 0.01, f"X5 {lam}")
RES["X5"] = dict(claim="Wall rates are RLCTs of the divergence germ (Watanabe, imported) and are divergence-invariant (X1)",
                 status="EXECUTED (deterministic quadrature over n = 1e3..1e7)", fitted_lambda=lam,
                 expected=dict(theta4=0.25, regular_2d=1.0, product_2d="0.5 (multiplicity 2)", bernoulli_singular=0.25))

# ---------------- X6 lossless dynamics: discrete cat map permutation keeps every divergence
Nn = 61; idx = lambda a, b: (a % Nn) * Nn + (b % Nn)
perm = np.array([idx(2 * a + b, a + b) for a in range(Nn) for b in range(Nn)])
is_perm = len(set(perm.tolist())) == Nn * Nn
w1 = np.array([((7 * i * i + 3 * i) % 97) + 1 for i in range(Nn * Nn)], dtype=float); w1 /= w1.sum()
w2 = np.array([((5 * i + 11) % 89) + 1 for i in range(Nn * Nn)], dtype=float); w2 /= w2.sum()
push = lambda w: np.bincount(perm, weights=w, minlength=Nn * Nn)
inv = abs(kl(push(w1), push(w2)) - kl(w1, w2)) < 1e-12
must(is_perm and inv, "X6")
RES["X6"] = dict(claim="Invertible dynamics at full resolution is a lossless re-description: every admissible divergence is invariant, so it never forgets",
                 status="PROVED (Lemma: lossless = congruent) + exact witness (cat map on 61 x 61 torus)", permutation=is_perm, kl_invariant=inv)
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_rooting_closure_results.json").write_text(json.dumps(RES, indent=1, default=float))
for k_, v in RES.items():
    if isinstance(v, dict): print(k_, "|", v["status"])
print(x2); print(info, rot_info[:3]); print(sl); print(lam)
