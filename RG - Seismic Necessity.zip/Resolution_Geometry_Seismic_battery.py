import pandas as pd, numpy as np
np.set_printoptions(precision=4,suppress=True)
rng=np.random.default_rng(7)
df=pd.read_csv('earthquake_data.csv')
# physical/intensity features (longitude is the CONDITION, excluded from features)
df['logE']=1.5*df['magnitude']            # log-energy proxy
feats=['magnitude','logE','depth','cdi','mmi','sig','tsunami','gap','nst','dmin']
X=df[feats].to_numpy(float)
# robust standardization (median / MAD)
med=np.median(X,axis=0); mad=np.median(np.abs(X-med),axis=0)+1e-9
Xs=(X-med)/(1.4826*mad)
Xs=np.clip(Xs,-6,6)                        # tame extreme outliers
lon=df['longitude'].to_numpy(float)

def resolved_frames(Xs,labels,K,p):
    frames=[]
    for k in range(K):
        Xk=Xs[labels==k]
        if len(Xk)<p+2: return None
        C=np.cov(Xk.T)
        w,V=np.linalg.eigh(C); frames.append(V[:,np.argsort(w)[::-1][:p]])
    return frames
def holonomy(frames):
    p=frames[0].shape[1]; W=np.eye(p); mino=1.0
    for i in range(len(frames)):
        M=frames[i].T@frames[(i+1)%len(frames)]
        U,s,Vt=np.linalg.svd(M); W=(U@Vt)@W; mino=min(mino,s.min())
    ang=np.sort(np.abs(np.angle(np.linalg.eigvals(W))))[::-1]
    return ang[0],mino,np.linalg.det(W)

def sector_labels_by_lon(lon,K):
    edges=np.linspace(-180,180,K+1)
    lab=np.digitize(lon,edges)-1; lab[lab==K]=K-1
    return lab

print("REAL SEISMIC DATA -- resolved-frame holonomy around the longitude cycle")
print("features:",feats,"\n")
for K in [6,8,12]:
    for p in [3]:
        lab=sector_labels_by_lon(lon,K)
        counts=np.bincount(lab,minlength=K)
        fr=resolved_frames(Xs,lab,K,p)
        if fr is None:
            print("K=%d p=%d: a sector too small (counts=%s)"%(K,p,counts)); continue
        Hobs,mino,det=holonomy(fr)
        # permutation null: shuffle sector labels (destroy spatial structure), keep sizes
        Hnull=[]
        for _ in range(2000):
            perm=rng.permutation(lab)
            f=resolved_frames(Xs,perm,K,p)
            if f is not None: Hnull.append(holonomy(f)[0])
        Hnull=np.array(Hnull); pval=(np.sum(Hnull>=Hobs)+1)/(len(Hnull)+1)
        # bootstrap within sectors: is Hobs stable (not sampling noise)?
        Hboot=[]
        for _ in range(500):
            idx=np.concatenate([rng.choice(np.where(lab==k)[0],np.sum(lab==k),replace=True) for k in range(K)])
            labb=lab[idx]; f=resolved_frames(Xs[idx],labb,K,p)
            if f is not None: Hboot.append(holonomy(f)[0])
        Hboot=np.array(Hboot)
        print("K=%2d p=%d  counts~%d/sector"%(K,p,int(counts.mean())))
        print("   observed holonomy = %.4f rad | min adjacent overlap = %.3f (local check) | det=%.2f"%(Hobs,mino,det))
        print("   permutation null: mean=%.4f  95th=%.4f  ->  p-value=%.4f"%(Hnull.mean(),np.percentile(Hnull,95),pval))
        print("   bootstrap (within-sector): mean=%.4f  [5th,95th]=[%.4f,%.4f]"%(Hboot.mean(),np.percentile(Hboot,5),np.percentile(Hboot,95)))
        # local-check contrast: adjacent overlap real vs permuted
        def mean_adj_overlap(frames):
            o=[]
            for i in range(len(frames)):
                s=np.linalg.svd(frames[i].T@frames[(i+1)%len(frames)],compute_uv=False); o.append(s.min())
            return np.mean(o)
        permov=np.mean([mean_adj_overlap(resolved_frames(Xs,rng.permutation(lab),K,p)) for _ in range(50)])
        print("   mean adjacent overlap: real=%.3f vs permuted=%.3f (real smoother => local checks pass)\n"%(mean_adj_overlap(fr),permov))
import pandas as pd, numpy as np
np.set_printoptions(precision=4,suppress=True)
rng=np.random.default_rng(3)
df=pd.read_csv('earthquake_data.csv'); df['logE']=1.5*df['magnitude']
def rstd(X):
    med=np.median(X,0);mad=np.median(np.abs(X-med),0)+1e-9
    return np.clip((X-med)/(1.4826*mad),-6,6)
def isqrt(A):
    w,V=np.linalg.eigh(A);w=np.clip(w,1e-9,None);return V@np.diag(w**-0.5)@V.T

# ---- Pillar 1 on real data: infer felt-IMPACT (null) from physical SOURCE (resolved) via coupling ----
src=['magnitude','logE','depth','gap','nst','dmin']      # what instruments directly measure
imp=['cdi','mmi','sig','tsunami']                        # felt/impact -- the sector to infer
S=rstd(df[src].to_numpy(float)); I=rstd(df[imp].to_numpy(float))
Z=np.hstack([S,I]); C=np.cov(Z.T); ps=len(src)
SR=C[:ps,:ps]; Cc=C[:ps,ps:]; SN=C[ps:,ps:]
rho=np.sort(np.linalg.svd(isqrt(SR)@Cc@isqrt(SN),compute_uv=False))[::-1]
Schur=SN-Cc.T@np.linalg.inv(SR)@Cc
info=1-np.trace(Schur)/np.trace(SN)
print("PILLAR 1 (real data): infer felt-impact sector from physical-source sector via coupling")
print("   source features:",src)
print("   impact features:",imp)
print("   canonical correlations source<->impact: ",np.round(rho,3))
print("   independent-probe error (ignore coupling) = 1.000 (prior impact variance)")
print("   RG error (Schur, use coupling)           = %.3f"%(np.trace(Schur)/np.trace(SN)))
print("   => %.0f%% of felt-impact variance is recoverable from source features via the coupling."%(100*info))
# honest cross-validated check: predict impact from source out-of-sample
from numpy.linalg import lstsq
idx=rng.permutation(len(df)); tr,te=idx[:600],idx[600:]
B,_,_,_=lstsq(np.hstack([S[tr],np.ones((len(tr),1))]),I[tr],rcond=None)
pred=np.hstack([S[te],np.ones((len(te),1))])@B
sse=((I[te]-pred)**2).sum(0); sst=((I[te]-I[tr].mean(0))**2).sum(0)
r2=1-sse/sst
print("   out-of-sample R^2 per impact feature [cdi,mmi,sig,tsunami]:",np.round(r2,3))
print("   (positive R^2 => coupling genuinely predicts the un-probed sector on held-out events)")

# ---- Pillar 3 on real data: regions genuinely differ; only invariants are comparable ----
print("\nPILLAR 3 (real data): raw loadings vary by region; canonical correlations are invariant")
lon=df['longitude'].to_numpy(float)
feats=src+imp; X=rstd(df[feats].to_numpy(float))
for name,mask in [("Americas (lon<-30)",lon<-30),("Asia/Oceania (lon>90)",lon>90)]:
    Xk=X[mask]; ck=np.cov(Xk.T)
    srk=ck[:ps,:ps];cck=ck[:ps,ps:];snk=ck[ps:,ps:]
    rk=np.sort(np.linalg.svd(isqrt(srk)@cck@isqrt(snk),compute_uv=False))[::-1]
    v=np.linalg.eigh(ck)[1][:,-1]
    print("   %-22s  leading raw loading[0]=%+.3f  |  source-impact canon corr=%s"%(name,v[0],np.round(rk,3)))
print("   (raw loadings differ by region; the coupling invariants are the comparable summary)")
import pandas as pd, numpy as np
rng=np.random.default_rng(1)
df=pd.read_csv('earthquake_data.csv'); df['logE']=1.5*df['magnitude']
def rstd(X):
    med=np.median(X,0);mad=np.median(np.abs(X-med),0)+1e-9
    return np.clip((X-med)/(1.4826*mad),-6,6)
feats=['magnitude','logE','depth','cdi','mmi','sig','tsunami','gap','nst','dmin']
X=rstd(df[feats].to_numpy(float))
# does the resolved frame vary SMOOTHLY along a physical axis (depth), using overlapping windows?
for axis in ['depth','magnitude','latitude']:
    order=np.argsort(df[axis].to_numpy(float)); Xo=X[order]
    n=len(Xo); W=200; step=40; p=3; frames=[]
    for s in range(0,n-W,step):
        C=np.cov(Xo[s:s+W].T); w,V=np.linalg.eigh(C); frames.append(V[:,np.argsort(w)[::-1][:p]])
    ov=[np.linalg.svd(frames[i].T@frames[i+1],compute_uv=False).min() for i in range(len(frames)-1)]
    print("axis=%-10s overlapping-window adjacent overlap: mean=%.3f min=%.3f  (smooth if high)"%(axis,np.mean(ov),np.min(ov)))
print("=> if overlaps are high on a physical axis with overlapping windows, the smooth")
print("   cross-condition structure Pillar 2 needs DOES exist -- but a closed loop (for holonomy)")
print("   requires a cyclic axis or a 2D condition grid with enough events per cell.")
