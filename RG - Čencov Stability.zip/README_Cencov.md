# Quantitative Cencov Stability and Finite-Scale Recovery

Research draft, 30 October 2026.

## Deliverables
- rg_cencov_stability.pdf: 20-page paper with definitions, proofs, theorem/corollary dependency chain, counterexamples, coverage ledger, bibliography, and computational appendix.
- rg_cencov_stability.tex: complete editable LaTeX source.
- rg_cencov_battery.py: classical synthetic numerical checks, including non-permutation-invariant approximate metric families.
- rg_cencov_exact.py: exact rational partition checks and symbolic identities.
- rg_cencov_quantum.py: BKM entropy-Hessian mixture checks on synthetic faithful density matrices.
- rg_cencov_verify.py: hashes, raw-result consistency, and optional fresh-process reproduction.
- JSON results/specification, raw classical/quantum CSV, quantitative figure, provenance, requirements, and SHA-256 manifest.

## Scope and status
The positive finite classical results have analytic proofs under the displayed assumptions. This is not a proof-assistant formalization or an independently refereed paper. No novelty or priority claim is certified.

The central quantitative theorem gives exp(+/-2 epsilon) Fisher distortion with exact permutation symmetry, exp(+/-2(epsilon+delta)) with approximate uniform-law symmetry, and exp(+/-4 epsilon) from uniform sufficient-splitting distortion alone. The assumptions quantify over all finite dimensions, all positive laws, and all sufficient splittings. A finite battery does NOT certify that universal premise.

The recovery results use parameter-independent channels and a fixed positive reference law. The pathwise result needs actual model-path control and output-overlap control. The quantum section does not prove a unique quantum metric or a classical-style quantum recovery inequality.

The no-go results are substantive outcomes: Fisher fields do not determine global experiments; smooth null tangents need not be exact fibres; small deficiency does not control derivatives; unrestricted approximate Rayleigh gates need not have a greatest subspace.

## Executed results
- Classical: 28/28 assertion groups, 1,918 CSV rows.
- Exact rational/symbolic: 8/8 groups, including 222 partition/law cases.
- Quantum: 3/3 groups, 60 matrix cases.
- Mutation/counterexample canaries: 15/15 detected, included in the classical groups.
- Secondary artifact/reproduction verifier: 27/27, including fresh-process exact agreement of result JSON and CSV files in this environment.

All numerical data are synthetic mathematical examples, not empirical observations. Exact rational examples are not universal formal proofs. Seeds and tolerances are in the source and specification. The design is source-defined, not externally preregistered.

## Reproduce
From the extracted package directory, with the dependencies in rg_cencov_requirements.txt:

    python rg_cencov_battery.py --out .
    python rg_cencov_exact.py
    python rg_cencov_quantum.py
    python rg_cencov_verify.py --rerun

Build the paper using standard pdfLaTeX packages:

    pdflatex -interaction=nonstopmode -halt-on-error rg_cencov_stability.tex
    pdflatex -interaction=nonstopmode -halt-on-error rg_cencov_stability.tex

Numerical outputs can vary slightly with library/BLAS versions. Exact fresh-run agreement was checked in the recorded environment. A PDF rebuild changes its timestamp/hash. SHA256SUMS_Cencov.txt records the delivered release, not a cryptographic claim of authorship or correctness.

## Reading order
Section 3: quantitative metric selection.
Sections 4-7: defects, finite recovery, pathwise/global sufficiency, and composition.
Sections 8-11: global nonuniqueness, singularities, derivative/spectral gates, and dominated partition limits.
Section 12: limited quantum bridge.
Sections 13-15 and Appendix A: assembly, coverage, computations, open problems, and proof dependencies.

## Writing choices
The draft separates established imports, proved consequences, numerical checks, and open problems. This prevents RG's operational gates from being mistaken for universal metric or ontological uniqueness claims.
