# RG luck final: executed evidence package

## Status
Large-scale synthetic battery executed. Physical luck certificate NOT ISSUED.
This is not a completed composable device-independent randomness-expansion protocol.
No EAT/QEF proof, trusted physical settings, causal-isolation attestation or certified
full-scale extractor is implemented. Increasing sample size cannot supply those gates.

## Executed scale
- 36 records x 1,048,576 target bits = 37,748,736 Tier-1 bits.
- 8 gamblers per record = 288 tests, with family-wise anytime correction.
- 9 Bell models x 10,000,000 rounds = 90,000,000 synthetic Bell rounds.
- 4,096 null paths x 8,192 bits = 33,554,432 calibration bits.
- 28,672 binomial sufficient-statistic power samples, not full bit streams.
- 37/37 unit checks and 27/27 integration checks passed.
- Independent verifier recomputed all 288 terminal gambler scores and 360 Bell chunks.

The different observation types are not one pool of independent physical samples.
The three paired Bell countermodels deliberately have identical raw transcripts.
All seeds and raw records are public. No output in this package is secret randomness.

## Read first
RG_luck_final_report.md: full design, all source rows, Bell results, assumptions and gates.
rg_final_certificate.json: machine-readable scope and blocked physical-certificate gates.
rg_final_manifest.json: frozen code/configuration hashes, sample sizes and exact power.
rg_final_verification.json: generator-side raw-data and ledger replay audit.
rg_final_independent_verification.json: independent batch-count audit.

## Reproduce the completed audit
Install requirements_final.txt in a compatible Python environment.
From this extracted directory:
python rg_luck_final.py verify --out .
python rg_final_verify_independent.py --out .

To generate a fresh deterministic replay, use a NEW empty directory:
python rg_luck_final.py freeze --out NEW_DIRECTORY
python rg_luck_final.py tier1 --out NEW_DIRECTORY
python rg_luck_final.py bell --out NEW_DIRECTORY
python rg_luck_final.py calibration --out NEW_DIRECTORY
python rg_luck_final.py finish --out NEW_DIRECTORY
python rg_luck_final.py verify --out NEW_DIRECTORY

For the independent verifier, place the unchanged rg_luck_final.py in the output
directory and run rg_final_verify_independent.py --out NEW_DIRECTORY.
The manifest freezes the source bytes, so do not edit that file after freezing.
The same seed reproduces the same software experiment, not new independent evidence.

## Important limits
Non-rejection is not certification of luck. Exact bias power concerns iid Bernoulli
alternatives only. IID entropy numbers are labeled projections, not certified bits.
The Bell local-null e-process tolerates memory only under its declared causal/free-setting null.
IID CHSH intervals are not security bounds for the memory/drift models.
The direct ideal spot-flag sampler costs 7 fair bits per round, plus 2 per test.
The smaller Shannon-entropy seed figure is explicitly an unimplemented sampler projection.
The independent verifier checks every terminal score but not every anytime maximum.
The original verifier additionally replays a representative CTW record and all null paths.
Hashes protect consistency relative to the retained manifest, not against a custodian
regenerating the entire package. No external timestamp or custody is claimed.

## Auditability
All 433 NPZ files are retained: 36 source records, 36 gambler traces, 360 Bell chunks,
and one null-path calibration file. Packed bits use little bit order; each raw file
stores its original length. Bell chunks retain T, X, Y, A, B and the simulated lambda A.
The full package checksum list excludes itself. ZIP CRC and each listed SHA-256 were checked.

## Sources and theorem verification
The attached v2 code and assessment informed the audit. Their entropy/expansion claims
were not accepted as certificates. The quantum guessing curve is retained only as an
unverified imported projection. The NS curve is checked by a one-round 24-vertex LP,
not a general sequential security theorem. Web search is disabled; knowledge cutoff
December 2025. No current primary-source theorem verification is claimed.
