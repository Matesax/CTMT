#!/usr/bin/env python3
"""
CTMT local seismic chart appendix
================================

Purpose
-------
This appendix translates the CTMT morphism-family language into a concrete
local seismic chart built from a declustered earthquake sequence.

The code is intentionally small and explicit.  It does not claim earthquake
prediction.  It demonstrates how the following CTMT objects are represented
in a seismic catalogue:

    raw event cloud             D_raw
    mainshock sector            M
    aftershock sector           A
    declustering projection     Pi_M : D_raw -> M
    local seismic forward map   F(theta)
    finite-difference Jacobian  J = dF/dtheta
    Fisher recognition metric   F^T C^{-1} F
    null sector                 ker(J^T) in observation space
    null-sector covariance      P_N C P_N

The local event table is embedded so that the file is reproducible without
external downloads.

Non-claims
----------
- This is not a seismological forecast model.
- This is not a physical rupture inversion.
- With six events, this is a chart-construction example, not statistical
  validation.
- The purpose is to show how CTMT's morphism diagnostics become operational
  once the transported seismic object is specified.
"""

from __future__ import annotations

import io
import json
from dataclasses import dataclass
from typing import Tuple

import numpy as np
import numpy.linalg as npl
import pandas as pd


# ---------------------------------------------------------------------------
# 1. Local declustered catalogue
# ---------------------------------------------------------------------------

LOCAL_DECLUSTERED_CSV = """Event_ID,Timestamp_UTC,Latitude,Longitude,Depth_km,Magnitude,Type,Distance_Window_km,Time_Window_Days
MX2009_001,2009-08-03T17:59:56,28.983,-113.015,10.0,6.2,M,54.0,79.0
MX2009_002,2009-08-03T18:33:12,28.891,-112.980,12.3,4.8,A,30.5,18.0
MX2009_003,2009-08-03T19:05:44,29.012,-113.110,9.1,5.0,A,32.0,22.0
MX2009_004,2009-08-03T21:40:02,28.950,-112.890,11.5,4.1,A,25.0,11.5
MX2009_005,2009-08-05T02:11:15,29.120,-113.250,8.0,4.3,A,26.5,13.0
MX2009_006,2009-08-07T11:24:00,31.250,-115.420,15.0,5.8,M,48.0,61.0
"""


def load_local_catalogue() -> pd.DataFrame:
    """Load the embedded declustered local seismic catalogue."""
    df = pd.read_csv(io.StringIO(LOCAL_DECLUSTERED_CSV), parse_dates=["Timestamp_UTC"])
    df["is_mainshock"] = df["Type"].eq("M")
    df["relative_time_days"] = (
        df["Timestamp_UTC"] - df["Timestamp_UTC"].min()
    ).dt.total_seconds() / 86400.0
    return df


# ---------------------------------------------------------------------------
# 2. Local physical coordinates
# ---------------------------------------------------------------------------

EARTH_RADIUS_KM = 6371.0


def local_tangent_xy_km(
    lat_deg: np.ndarray,
    lon_deg: np.ndarray,
    lat0_deg: float,
    lon0_deg: float,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Convert latitude/longitude to a local tangent-plane coordinate system.

    This is an equirectangular approximation, sufficient for a small local
    chart.  For a full study, replace this with a geodetic projection.
    """
    lat = np.deg2rad(lat_deg)
    lon = np.deg2rad(lon_deg)
    lat0 = np.deg2rad(lat0_deg)
    lon0 = np.deg2rad(lon0_deg)
    x = EARTH_RADIUS_KM * (lon - lon0) * np.cos(lat0)
    y = EARTH_RADIUS_KM * (lat - lat0)
    return x, y


def attach_local_coordinates(df: pd.DataFrame) -> pd.DataFrame:
    """Attach local x/y coordinates centered on the first mainshock."""
    out = df.copy()
    anchor = out[out["is_mainshock"]].iloc[0]
    x, y = local_tangent_xy_km(
        out["Latitude"].to_numpy(float),
        out["Longitude"].to_numpy(float),
        float(anchor["Latitude"]),
        float(anchor["Longitude"]),
    )
    out["x_km"] = x
    out["y_km"] = y
    out["log10_energy_proxy"] = 1.5 * out["Magnitude"] + 4.8
    return out


# ---------------------------------------------------------------------------
# 3. CTMT seismic chart
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class CTMTLocalChart:
    """
    A minimal CTMT seismic chart around one mainshock.

    theta = [x0, y0, depth0, magnitude0, D_window, T_window]

    x0, y0, depth0, magnitude0
        Mainshock anchor coordinates.

    D_window, T_window
        Declustering distance/time window scales.  In a larger study these
        would come from a Gardner--Knopoff law or supplied catalogue windows.
    """

    theta: np.ndarray
    aftershocks: pd.DataFrame

    @property
    def n_aftershocks(self) -> int:
        return int(len(self.aftershocks))


def build_chart(df: pd.DataFrame) -> CTMTLocalChart:
    """
    Build a local CTMT chart around the first mainshock.

    The aftershock sector consists of dependent A-events after the first
    mainshock and before the next independent mainshock.
    """
    mainshocks = df[df["is_mainshock"]].copy()
    first_m = mainshocks.iloc[0]
    second_m_time = mainshocks.iloc[1]["Timestamp_UTC"] if len(mainshocks) > 1 else pd.Timestamp.max

    after = df[(~df["is_mainshock"]) & (df["Timestamp_UTC"] > first_m["Timestamp_UTC"]) & (df["Timestamp_UTC"] < second_m_time)].copy()

    theta = np.array(
        [
            float(first_m["x_km"]),
            float(first_m["y_km"]),
            float(first_m["Depth_km"]),
            float(first_m["Magnitude"]),
            float(first_m["Distance_Window_km"]),
            float(first_m["Time_Window_Days"]),
        ],
        dtype=float,
    )
    return CTMTLocalChart(theta=theta, aftershocks=after)


# ---------------------------------------------------------------------------
# 4. Forward map: seismic response coordinates
# ---------------------------------------------------------------------------

DEPTH_SCALE_KM = 20.0
MAG_SCALE = 1.0


# These coordinates represent observable responses to perturbations
# of (x0, y0, depth0, magnitude0, D, T).
# Each component is a measurable response coordinate induced
# by perturbations of the mainshock anchor and declustering windows.

def forward_response(theta: np.ndarray, aftershocks: pd.DataFrame) -> np.ndarray:
    """
    CTMT local seismic forward map F(theta).

    For each aftershock event, return normalized response coordinates relative
    to the mainshock anchor:

        r_i(theta) = [
            (x_i - x0) / D,
            (y_i - y0) / D,
            (depth_i - depth0) / DEPTH_SCALE_KM,
            (mag_i - mag0) / MAG_SCALE,
            (time_i - time0) / T,
        ]

    The concatenation of all r_i defines the observation vector.

    Interpretation
    --------------
    These coordinates do not assert a complete seismic law.  They provide a
    local transport representation in which CTMT can ask: what changes under
    perturbations of the mainshock anchor and declustering window?
    """
    x0, y0, depth0, mag0, D, T = theta
    D = max(float(D), 1e-9)
    T = max(float(T), 1e-9)

    rows = []
    for _, ev in aftershocks.iterrows():
        rows.append(
            [
                (float(ev["x_km"]) - x0) / D,
                (float(ev["y_km"]) - y0) / D,
                (float(ev["Depth_km"]) - depth0) / DEPTH_SCALE_KM,
                (float(ev["Magnitude"]) - mag0) / MAG_SCALE,
                float(ev["relative_time_days"]) / T,
            ]
        )
    return np.asarray(rows, dtype=float).reshape(-1)


# ---------------------------------------------------------------------------
# 5. Finite-difference Jacobian
# ---------------------------------------------------------------------------


def finite_difference_jacobian(
    theta: np.ndarray,
    aftershocks: pd.DataFrame,
    rel_step: float = 1e-5,
) -> np.ndarray:
    """
    Compute J = dF/dtheta by centered finite differences.

    J maps infinitesimal perturbations of the local mainshock/window chart to
    perturbations of the aftershock response vector.
    """
    theta = np.asarray(theta, dtype=float)
    y0 = forward_response(theta, aftershocks)
    J = np.zeros((y0.size, theta.size), dtype=float)

    for j in range(theta.size):
        h = rel_step * max(abs(theta[j]), 1.0)
        tp = theta.copy()
        tm = theta.copy()
        tp[j] += h
        tm[j] -= h
        # distance/time windows must remain positive
        if j in (4, 5) and tm[j] <= 0:
            tm[j] = theta[j]
            fp = forward_response(tp, aftershocks)
            fm = forward_response(tm, aftershocks)
            J[:, j] = (fp - fm) / (tp[j] - tm[j])
        else:
            fp = forward_response(tp, aftershocks)
            fm = forward_response(tm, aftershocks)
            J[:, j] = (fp - fm) / (2.0 * h)
    return J


# ---------------------------------------------------------------------------
# 6. Covariance and null sector
# ---------------------------------------------------------------------------


def event_residual_matrix(y: np.ndarray, n_events: int) -> np.ndarray:
    """Convert concatenated response vector to n_events x 5 residual matrix."""
    return np.asarray(y, dtype=float).reshape(n_events, 5)


def observation_covariance_from_aftershocks(y: np.ndarray, n_events: int, ridge: float = 1e-6) -> np.ndarray:
    """
    Estimate observation covariance from the aftershock response cloud.

    We estimate a 5 x 5 covariance across aftershock residual coordinates and
    lift it to the concatenated observation vector as a block diagonal matrix.

    This is the operational CTMT covariance.  It is not a claim that four
    aftershocks determine a stable population covariance; it just makes the
    null-sector computation explicit and reproducible.
    """
    R = event_residual_matrix(y, n_events)
    if n_events >= 2:
        C5 = np.cov(R, rowvar=False, bias=False)
    else:
        C5 = np.eye(5)
    C5 = np.asarray(C5, dtype=float)
    C5 = 0.5 * (C5 + C5.T)
    C5 += ridge * max(float(np.trace(C5)), 1.0) / 5.0 * np.eye(5)
    return np.kron(np.eye(n_events), C5)


def null_projector_from_jacobian(J: np.ndarray, rtol: float = 1e-10) -> Tuple[np.ndarray, int, np.ndarray]:
    """
    Construct observation-space null projector P_N = I - U_r U_r^T.

    The resolved observation sector is Im(J).  The null observation sector is
    the orthogonal complement of Im(J), equivalently ker(J^T).
    """
    U, s, Vt = npl.svd(J, full_matrices=True)
    if s.size == 0:
        rank = 0
    else:
        rank = int(np.sum(s > rtol * max(s[0], 1.0)))
    U_res = U[:, :rank]
    P_res = U_res @ U_res.T if rank > 0 else np.zeros((J.shape[0], J.shape[0]))
    P_null = np.eye(J.shape[0]) - P_res
    return P_null, rank, s


def fisher_metric(J: np.ndarray, C: np.ndarray) -> np.ndarray:
    """Recognition metric F = J^T C^{-1} J."""
    Cinv = npl.pinv(C)
    F = J.T @ Cinv @ J
    return 0.5 * (F + F.T)


# ---------------------------------------------------------------------------
# 7. Run appendix calculation
# ---------------------------------------------------------------------------


def main() -> None:
    df = attach_local_coordinates(load_local_catalogue())
    chart = build_chart(df)

    y = forward_response(chart.theta, chart.aftershocks)
    J = finite_difference_jacobian(chart.theta, chart.aftershocks)
    C = observation_covariance_from_aftershocks(y, chart.n_aftershocks)
    P_null, rank_J, singular_values = null_projector_from_jacobian(J)
    F = fisher_metric(J, C)

    y_null = P_null @ y
    C_null = P_null @ C @ P_null

    eval_F = npl.eigvalsh(F)
    eval_C_null = npl.eigvalsh(0.5 * (C_null + C_null.T))

    summary = {
        "events_total": int(len(df)),
        "mainshocks": int(df["is_mainshock"].sum()),
        "aftershocks": int((~df["is_mainshock"]).sum()),
        "aftershocks_in_first_sequence": int(chart.n_aftershocks),
        "theta_names": ["x0_km", "y0_km", "depth0_km", "mag0", "D_window_km", "T_window_days"],
        "theta": chart.theta.tolist(),
        "observation_dimension": int(y.size),
        "parameter_dimension": int(chart.theta.size),
        "jacobian_rank": int(rank_J),
        "null_dimension": int(y.size - rank_J),
        "jacobian_singular_values": singular_values.tolist(),
        "fisher_eigenvalues": eval_F.tolist(),
        "null_residual_norm": float(npl.norm(y_null)),
        "total_residual_norm": float(npl.norm(y)),
        "null_residual_fraction": float(npl.norm(y_null) / (npl.norm(y) + 1e-30)),
        "null_covariance_trace": float(np.trace(C_null)),
        "null_covariance_positive_eigs": int(np.sum(eval_C_null > 1e-12)),
    }

    # Rich human-readable matrices for inspection.
    response_columns = ["dx_over_D", "dy_over_D", "ddepth_over_20km", "dmag", "dt_over_T"]
    R = event_residual_matrix(y, chart.n_aftershocks)
    response_df = chart.aftershocks[["Event_ID", "Type"]].reset_index(drop=True).copy()
    for i, col in enumerate(response_columns):
        response_df[col] = R[:, i]

    jac_df = pd.DataFrame(
        J,
        columns=summary["theta_names"],
    )
    jac_df.insert(0, "obs_index", np.arange(J.shape[0]))

    df.to_csv("ctmt_local_chart_events_with_coordinates.csv", index=False)
    response_df.to_csv("ctmt_local_chart_response_vectors.csv", index=False)
    jac_df.to_csv("ctmt_local_chart_jacobian.csv", index=False)
    pd.DataFrame(F, columns=summary["theta_names"], index=summary["theta_names"]).to_csv(
        "ctmt_local_chart_fisher_metric.csv"
    )
    pd.DataFrame(C_null).to_csv("ctmt_local_chart_null_covariance.csv", index=False)

    with open("ctmt_local_chart_ctmt_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
