#!/usr/bin/env python3
"""RG true-chaos comparison battery.

Compares ordinary Monte Carlo convergence with structural uncertainty-geometry
certificates across chaotic, periodic, quasi-periodic, and non-identifiable models.
All plots and JSON values are reproducible from a declared seed.
"""
import argparse, json, math, os, time
import numpy as np
from scipy.stats import wasserstein_distance, linregress
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def tv(a, b, bins=120, rng=(0.0, 1.0)):
    ha, _ = np.histogram(a, bins=bins, range=rng)
    hb, _ = np.histogram(b, bins=bins, range=rng)
    pa, pb = ha / max(ha.sum(), 1), hb / max(hb.sum(), 1)
    return 0.5 * np.abs(pa - pb).sum()


def entropy_hist(x, bins=128, rng=(0.0, 1.0)):
    h, _ = np.histogram(x, bins=bins, range=rng)
    p = h[h > 0] / h.sum()
    return float(-(p * np.log(p)).sum())


def logistic(x, r): return r * x * (1.0 - x)
def tent(x): return 1.0 - 2.0 * np.abs(x - 0.5)
def rotation(x, alpha=(math.sqrt(5)-1)/2): return (x + alpha) % 1.0
def flip(x): return 1.0-x


def ensemble_family(rng, n, center=0.3137, width=1e-5):
    return {
        'uniform': np.clip(center + width * (rng.random(n)-0.5), 1e-12, 1-1e-12),
        'gaussian': np.clip(center + width/4 * rng.normal(size=n), 1e-12, 1-1e-12),
        'bimodal': np.clip(center + width/2*np.sign(rng.random(n)-0.5) + width/20*rng.normal(size=n), 1e-12, 1-1e-12),
    }


def max_pairwise(metric, fam):
    keys = list(fam)
    return max(metric(fam[keys[i]], fam[keys[j]]) for i in range(len(keys)) for j in range(i+1, len(keys)))


def finite_time_lyapunov_logistic(x0, r, n=3000, burn=200):
    x = float(x0); vals=[]
    for i in range(n+burn):
        x = logistic(x, r)
        if i >= burn: vals.append(math.log(max(abs(r*(1-2*x)), 1e-300)))
    return float(np.mean(vals))


def bootstrap_mc_mean(rng, sampler, statistic, sizes, reps=120):
    means=[]; ses=[]
    for n in sizes:
        vals=np.array([statistic(sampler(int(n))) for _ in range(reps)])
        means.append(float(vals.mean())); ses.append(float(vals.std(ddof=1)))
    slope=linregress(np.log(sizes), np.log(np.maximum(ses,1e-15))).slope
    return means, ses, float(slope)


def run(seed, outdir):
    os.makedirs(outdir, exist_ok=True)
    rng=np.random.default_rng(seed)
    results={'seed':seed,'tests':{}}

    # 1. Shadowing/divergence slopes and forecast frontier.
    eps=1e-12; steps=np.arange(0,55)
    systems={'logistic r=4':(lambda x:logistic(x,4.0),0.217341),
             'logistic r=3.5':(lambda x:logistic(x,3.5),0.217341),
             'tent':(tent,0.217341),
             'irrational rotation':(rotation,0.217341)}
    divergence={}; lyaps={}
    for name,(f,x0) in systems.items():
        x=x0; y=x0+eps; ds=[]
        for _ in steps:
            ds.append(abs(y-x)); x=f(x); y=f(y)
        divergence[name]=np.array(ds)
    lyaps['logistic r=4']=finite_time_lyapunov_logistic(0.217341,4.0)
    lyaps['logistic r=3.5']=finite_time_lyapunov_logistic(0.217341,3.5)
    lyaps['tent']=math.log(2.0); lyaps['irrational rotation']=0.0
    mask=(divergence['logistic r=4']>1e-10)&(divergence['logistic r=4']<1e-2)
    empirical=linregress(steps[mask],np.log(divergence['logistic r=4'][mask])).slope
    results['tests']['divergence']={'lyapunov':lyaps,'empirical_logistic_slope':float(empirical),
        'pass':abs(empirical-math.log(2))<0.08 and lyaps['logistic r=4']>0.6 and lyaps['logistic r=3.5']<0}

    fig,ax=plt.subplots(figsize=(7.2,4.4))
    for k,v in divergence.items(): ax.semilogy(steps,np.maximum(v,1e-16),label=k)
    ax.axhline(1e-2,color='k',ls=':',lw=.9); ax.set(xlabel='iteration n',ylabel='separation |delta x_n|',title='Finite perturbations: exponential growth is system-specific')
    ax.legend(fontsize=8); fig.tight_layout(); fig.savefig(os.path.join(outdir,'01_divergence_slopes.png'),dpi=190); plt.close(fig)

    # 2. Multi-metric forgetting: TV, Wasserstein, entropy spread.
    N=90000; T=65
    configs={'chaotic logistic r=4':lambda z:logistic(z,4.0),
             'periodic involution':flip,
             'quasi-periodic rotation':rotation,
             'tent map':tent}
    forgetting={}
    for name,f in configs.items():
        fam=ensemble_family(rng,N,width=(.6 if 'periodic' in name else (.08 if 'rotation' in name else 1e-4)),center=(.5 if 'periodic' in name else .3137))
        rows=[]
        for n in range(T+1):
            rows.append((max_pairwise(lambda a,b:tv(a,b),fam),
                         max_pairwise(wasserstein_distance,fam),
                         float(np.ptp([entropy_hist(v) for v in fam.values()]))))
            fam={k:f(v) for k,v in fam.items()}
        forgetting[name]=np.array(rows)
    results['tests']['forgetting']={k:{'late_tv':float(v[-10:,0].max()),'late_w1':float(v[-10:,1].max()),'late_entropy_spread':float(v[-10:,2].max())} for k,v in forgetting.items()}
    results['tests']['forgetting']['pass']=bool(forgetting['chaotic logistic r=4'][-10:,0].max()<0.035 and forgetting['tent map'][-10:,0].max()<0.035 and forgetting['periodic involution'][-10:,0].min()>0.05)
    fig,axs=plt.subplots(1,3,figsize=(12.6,3.8))
    labs=['max pairwise TV','max pairwise Wasserstein-1','entropy spread']
    for j in range(3):
        for k,v in forgetting.items(): axs[j].semilogy(np.maximum(v[:,j],1e-6),label=k)
        axs[j].set(xlabel='iteration n',ylabel=labs[j],title=labs[j])
    axs[0].legend(fontsize=7); fig.tight_layout(); fig.savefig(os.path.join(outdir,'02_multiscale_forgetting.png'),dpi=190); plt.close(fig)

    # 3. Coarse-graining scale comparison: parameter law dependence versus resolution.
    bins_list=np.array([8,16,32,64,128,256,512])
    scale={}
    for name,f in {'chaotic r=4':configs['chaotic logistic r=4'],'periodic involution':configs['periodic involution']}.items():
        fam=ensemble_family(rng,N,width=.6,center=.5)
        for _ in range(60): fam={k:f(v) for k,v in fam.items()}
        vals=[]
        for bins in bins_list: vals.append(max_pairwise(lambda a,b:tv(a,b,bins=int(bins)),fam))
        scale[name]=np.array(vals)
    results['tests']['resolution_scale']={k:[float(x) for x in v] for k,v in scale.items()}
    results['tests']['resolution_scale']['pass']=bool(scale['chaotic r=4'].max()<0.045 and scale['periodic involution'].min()>0.08)
    fig,ax=plt.subplots(figsize=(6.8,4.2))
    for k,v in scale.items(): ax.loglog(bins_list,v,'o-',label=k)
    ax.set(xlabel='histogram resolution (bins)',ylabel='input-law TV after 60 steps',title='Input dependence across observation scales'); ax.legend(); fig.tight_layout(); fig.savefig(os.path.join(outdir,'03_scale_dependence.png'),dpi=190); plt.close(fig)

    # 4. Ordinary MC convergence may look equally healthy for forced and conditional outputs.
    sizes=np.array([250,500,1000,2000,4000,8000,16000])
    def invariant_logistic(n):
        x=rng.random(int(n));
        for _ in range(80): x=logistic(x,4.0)
        return x
    def periodic_phase_a(n):
        x=np.clip(.2+.02*rng.normal(size=int(n)),1e-8,1-1e-8)
        for _ in range(80): x=flip(x)
        return x
    forced=bootstrap_mc_mean(rng,invariant_logistic,np.mean,sizes)
    conditional=bootstrap_mc_mean(rng,periodic_phase_a,np.mean,sizes)
    # Change admissible declaration for periodic system.
    def periodic_phase_b(n):
        x=np.clip(.8+.02*rng.normal(size=int(n)),1e-8,1-1e-8)
        for _ in range(80): x=flip(x)
        return x
    phase_b=np.mean(periodic_phase_b(300000)); phase_a=np.mean(periodic_phase_a(300000))
    results['tests']['mc_convergence']={'forced_se_slope':forced[2],'conditional_se_slope':conditional[2],
        'periodic_declared_mean_gap':float(abs(phase_a-phase_b)),
        'pass':abs(forced[2]+.5)<.12 and abs(conditional[2]+.5)<.12 and abs(phase_a-phase_b)>.02}
    fig,axs=plt.subplots(1,2,figsize=(10.4,4.0))
    axs[0].loglog(sizes,forced[1],'o-',label=f'chaotic forced slope {forced[2]:.2f}')
    axs[0].loglog(sizes,conditional[1],'s-',label=f'periodic conditional slope {conditional[2]:.2f}')
    axs[0].loglog(sizes,forced[1][0]*(sizes/sizes[0])**-.5,'k--',lw=1,label='N^{-1/2}')
    axs[0].set(xlabel='Monte Carlo samples N',ylabel='SD of estimated mean',title='MC error bars converge in both cases'); axs[0].legend(fontsize=8)
    axs[1].bar(['periodic input A','periodic input B'],[phase_a,phase_b],color=['#4C78A8','#F58518'])
    axs[1].set(ylabel='long-run sample mean',title='Yet the periodic answer retains the declaration')
    fig.tight_layout(); fig.savefig(os.path.join(outdir,'04_mc_convergence_vs_structure.png'),dpi=190); plt.close(fig)

    # 5. Fold wall: scalar MC intervals versus geometric preimage correspondence.
    sigma=.05; nobs=50; btrue=-.5; R=5000
    y=(btrue*btrue)+sigma*rng.normal(size=(R,nobs)); ybar=np.maximum(y.mean(axis=1),1e-14)
    bh=np.sqrt(ybar); se=sigma/np.sqrt(nobs)/(2*np.maximum(bh,1e-12))
    wald=((btrue>=bh-1.96*se)&(btrue<=bh+1.96*se)).mean()
    lo=np.maximum(ybar-1.96*sigma/np.sqrt(nobs),0); hi=ybar+1.96*sigma/np.sqrt(nobs)
    geom=((btrue*btrue>=lo)&(btrue*btrue<=hi)).mean()
    results['tests']['fold_wall']={'wald_coverage':float(wald),'geometric_preimage_coverage':float(geom),'pass':bool(wald<.05 and geom>.93)}
    yy=np.linspace(0,.7,300); root=np.sqrt(yy)
    fig,ax=plt.subplots(figsize=(6.8,4.4))
    ax.plot(root,yy,label='positive branch'); ax.plot(-root,yy,label='negative branch')
    obs=btrue*btrue; band=1.96*sigma/np.sqrt(nobs)
    ax.axhspan(max(obs-band,0),obs+band,color='gray',alpha=.18,label='observation interval')
    ax.scatter([btrue,-btrue],[obs,obs],c=['#E45756','#4C78A8'],zorder=3)
    ax.set(xlabel='parameter b',ylabel='observable y=b^2',title='At a fold, uncertainty is a correspondence, not one interval'); ax.legend(); fig.tight_layout(); fig.savefig(os.path.join(outdir,'05_fold_correspondence.png'),dpi=190); plt.close(fig)

    # 6. Summary decision matrix.
    summary={
      'positive_lyapunov_detected':results['tests']['divergence']['pass'],
      'post_frontier_input_forgetting':results['tests']['forgetting']['pass'],
      'scale_robust_forgetting_only_for_mixing':results['tests']['resolution_scale']['pass'],
      'mc_rate_not_a_non_circularity_certificate':results['tests']['mc_convergence']['pass'],
      'geometric_wall_set_has_nominal_coverage':results['tests']['fold_wall']['pass']}
    results['summary']=summary; results['all_pass']=all(summary.values())
    with open(os.path.join(outdir,'rg_true_chaos_results.json'),'w') as f: json.dump(results,f,indent=2,default=lambda o: o.item() if hasattr(o,'item') else str(o))
    return results

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--seed',type=int,default=20261010); p.add_argument('--outdir',default='rg_true_chaos_output')
    a=p.parse_args(); t=time.time(); r=run(a.seed,a.outdir)
    print(json.dumps(r['summary'],indent=2,default=lambda o: o.item() if hasattr(o,'item') else str(o))); print('all_pass=',r['all_pass'],'runtime_s=',round(time.time()-t,2))
