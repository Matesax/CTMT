"""RG Quantum Gravity battery, second edition (print: 'RG - Quantum Gravity').

Every group carries a canary. Groups:
  QA polytope rigidity            QB composition identity K(ab)-K(a)K(b) = -k(k-2)/4 ab(a-1)(b-1)   QC continuum canary
  LA positive-pullback no-go; Poisson volume calibration      LB walk: exact cone, dispersion series
  LC odd anticommutator outside the cone                      LD free Dirac limit bound T a P |M|; exact dispersion
  LE graded locality: even bilinears commute outside the cone
  SA number-current operator balance (not stress)            SB internal holonomy is not curvature (narrow obstruction)
  EA Newton normalization   EB on-shell invariants (Riem^2, Riem^3)   EC one-loop magnitudes   ED anomaly arithmetic
  FA conserved improvement; equal means, unequal fluctuations; truncation defect
  CA relational observable toy      UA TV and KL discrimination bounds, illustrative scales (resource-relative)
  UB classical horizon      UC exact toy propagator versus EFT expansion
  PA entangling phase invariant, negativity; LOCC canary     PB reversible joint, irreversible reduced (correction)
  HA universal action quantum from exchange balance          HB thermal radiation in n space dimensions; Wien roots;
                                                              mode counting; synthetic shape test; radiometric witness;
                                                              FIRAS circularity canary
  KA existence lemma for Gaussian kernels (quotient; definite; indefinite -> amplitude)
  KB linearized gravity: one negative direction on the gauge quotient; scalar lattice action positive
  IA uniform discrete Sobolev in 3-D and its wall           IB 3-D interacting refinement, rate a^2, source variation
  IC predictor: first lattice correction a^2 E_1; cubic-anisotropic dispersion
  ID 3-D obstructions: Nyquist defect; laminate anisotropy; no full-sequence limit
  IE interaction-resolution bound (one loop) with the measured Higgs coupling; asymptotic-freedom canary

Run: python rg_quantum_gravity.py (numpy, scipy, sympy; rg_curv.py alongside). Seed 20261110. Deterministic.
"""
import hashlib, itertools, json, sys
from pathlib import Path
import numpy as np
import sympy as s
from scipy.linalg import expm
from scipy.special import jv

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rg_curv import curvature, invariants  # noqa: E402

SEED = 20261110
rng = np.random.default_rng(SEED)
R, FAILS = {}, []


def must(c, tag):
    if not c:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.12g}')


# =============================================================================================  Q-gate
def QA():
    def affine_group(V):
        n, dim = V.shape
        Vh = np.c_[V, np.ones(n)]
        count = 0
        for perm in itertools.permutations(range(n)):
            W = V[list(perm)]
            M, *_ = np.linalg.lstsq(Vh, W, rcond=None)
            if np.max(np.abs(Vh @ M - W)) < 1e-9:
                count += 1
        return count
    shapes = {
        'simplex_3': np.eye(3)[:, :2] * 0 + np.array([[0, 0], [1, 0], [0, 1]]),
        'simplex_4': np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]], float),
        'square_gbit': np.array([[1, 1], [1, -1], [-1, -1], [-1, 1]], float),
        'hexagon': np.array([[np.cos(a), np.sin(a)] for a in np.arange(6) * np.pi / 3]),
    }
    groups = {k: affine_group(v) for k, v in shapes.items()}
    # a continuous path g(t) of symmetries with g(0) = id fixes every vertex (vertices are isolated); affinely spanning
    # vertices then force g(t) = id: the Lie algebra of fixers is the nullspace of the map A -> (A v_i) for all i
    lie = {}
    for k, V in shapes.items():
        n, dim = V.shape
        Vh = np.c_[V, np.ones(n)]
        lie[k] = int(Vh.shape[1] * dim - np.linalg.matrix_rank(np.kron(np.eye(dim), Vh)))
    # Bloch ball: exp(-i H t) moves |0> continuously to |1>
    X = np.array([[0, 1], [1, 0]], complex)
    path = [abs(np.vdot(np.array([0, 1]), expm(-1j * X * t) @ np.array([1, 0]))) ** 2 for t in np.linspace(0, np.pi / 2, 11)]
    ok = groups == {'simplex_3': 6, 'simplex_4': 24, 'square_gbit': 8, 'hexagon': 12} and all(v == 0 for v in lie.values()) \
        and abs(path[-1] - 1) < 1e-12 and np.all(np.diff(path) > 0)
    must(ok, 'QA')
    R['QA'] = dict(claim='A polytope state space (classical simplex, gbit square, hexagon) has a finite affine symmetry group '
                         '(6, 24, 8, 12 elements) and a zero-dimensional Lie algebra of vertex fixers: continuous reversible '
                         'dynamics acts trivially on its pure states. The Bloch ball admits transitive continuous rotations '
                         '(|0> -> |1> continuously)', status='CONSTRUCTED (exact)', group_orders=groups, lie_dimension=lie,
                   transition_path=[fl(v) for v in path[::5]])


def QB():
    K = lambda k, d: d + k * d * (d - 1) // 2
    alld = {k: all(K(k, a * b) == K(k, a) * K(k, b) for a in range(2, 8) for b in range(2, 8)) for k in [0, 1, 2, 4, 8]}
    kk = s.Symbol('k')
    roots = sorted(int(r) for r in s.solve(4 + 6 * kk - (2 + kk) ** 2, kk))
    a_, b_ = s.symbols('a b', positive=True)
    Ks = lambda d: d + kk * d * (d - 1) / 2
    fact = s.simplify(Ks(a_ * b_) - Ks(a_) * Ks(b_) + kk * (kk - 2) / 4 * a_ * b_ * (a_ - 1) * (b_ - 1))
    must(fact == 0 and roots == [0, 2] and alld[0] and alld[2] and not alld[1] and not alld[4], 'QB')
    R['QB'] = dict(claim='Local tomography with same-type composites: a rank-4 composite of two rank-2 cones has 4 + 6k parameters, '
                         'the product needs (2 + k)^2, so k in {0, 2}. In all dimensions d_A, d_B <= 7, K_AB = K_A K_B holds for '
                         'k = 0 (classical) and k = 2 (complex) only; exactly, K_k(ab) - K_k(a)K_k(b) = -k(k-2)/4 ab(a-1)(b-1) in all ranks. '
                         'Composition alone leaves classical alive; arbitrary convex theories and exceptional Jordan systems are not classified',
                   status='PROVED (exact symbolic factorization)', factorization_residual=str(fact), roots=roots, all_dimensions=alld)


def QC():
    caps = {}
    for Nst in [2, 8, 64, 1024]:
        pts = np.exp(2j * np.pi * np.arange(Nst) / Nst)
        caps[str(Nst)] = int(len(set(np.round(pts, 12))))      # point masses on a circle: all perfectly distinguishable
    rot = lambda z, t: z * np.exp(1j * t)
    moved = abs(rot(1 + 0j, np.pi) - (-1))
    must(all(int(k) == v for k, v in caps.items()) and moved < 1e-15, 'QC')
    R['QC'] = dict(claim='Canary for the scope of QA: a classical continuum (circle phase space) supports continuous reversible transitive '
                         'dynamics on point masses and has unbounded capacity (2, 8, 64, 1024 perfectly distinguishable states and beyond). '
                         'Finite capacity and finite dimension are separate assumptions: polytope rigidity applies to finite-dimensional '
                         'polytopes only', 
                   status='CONSTRUCTED', capacities=caps)


# =============================================================================================  L-gate
def LA():
    worst = np.inf
    for _ in range(200):
        n, m = 4, int(rng.integers(2, 6))
        A = rng.normal(size=(n, n)); G = A @ A.T + 1e-3 * np.eye(n)
        J = rng.normal(size=(n, m))
        worst = min(worst, np.linalg.eigvalsh(J.T @ G @ J).min())
    # order + number (1+1 Minkowski, Poisson sprinkling in light-cone coordinates)
    rho = 4000.0
    res = {}
    for Om in [1.0, 2.0]:
        est = []
        for _ in range(20):
            N = rng.poisson(rho * Om ** 2 * 1.0 * 1.0 / 2)      # diamond u,v in [0,1]: volume 1/2 in (t,x)
            est.append(np.sqrt(2 * N / rho))                     # proper time of the diamond, recovered from the count
        res[str(Om)] = dict(tau_from_count=fl(np.mean(est)), tau_true=fl(Om * 1.0), rel_err=fl(abs(np.mean(est) - Om) / Om))
    ok = worst >= -1e-12 and all(v['rel_err'] < 0.01 for v in res.values())
    must(ok, 'LA')
    R['LA'] = dict(claim='No-go: J^T G J is positive semidefinite for every positive G and real J, so no distinguishability metric '
                         '(Fisher, SLD, Bures) pulls back to a Lorentzian one. Signature must come from order (reachability), which '
                         'fixes the conformal class (HKMM, Malament); order is blind to a constant conformal factor Omega, while the '
                         'count of sprinkled records recovers tau = Omega (order + number = geometry)',
                   status='PROVED (algebra) + EXECUTED (seeded sprinkling) + imported', min_pullback_eigenvalue=fl(worst),
                   sprinkling=res)


def dirac_qca_step(psi, m):
    n = np.sqrt(1 - m * m)
    R_, L_ = psi[0], psi[1]
    Rc = n * R_ - 1j * m * L_
    Lc = -1j * m * R_ + n * L_
    return np.array([np.roll(Rc, 1), np.roll(Lc, -1)])


def LB():
    Nx, T, m = 201, 60, 0.3
    psi = np.zeros((2, Nx), complex); c0 = Nx // 2; psi[0, c0] = 1 / np.sqrt(2); psi[1, c0] = 1j / np.sqrt(2)
    outside = 0.0
    for t in range(1, T + 1):
        psi = dirac_qca_step(psi, m)
        mask = np.abs(np.arange(Nx) - c0) > t
        outside = max(outside, float(np.max(np.abs(psi[:, mask]))))
    norm = float(np.sum(np.abs(psi) ** 2))
    ks = np.linspace(-np.pi, np.pi, 4001)
    vg = {}
    for mm in [0.0, 0.3, 0.8]:
        n = np.sqrt(1 - mm * mm)
        w = np.arccos(n * np.cos(ks))
        vg[str(mm)] = fl(np.max(np.abs(np.gradient(w, ks))))
    k, mu = s.symbols('k mu', positive=True)
    nn = s.sqrt(1 - mu ** 2)
    w0 = s.acos(s.cos(k))
    w2 = s.series(s.acos(nn * s.cos(k)) ** 2, k, 0, 6).removeO()
    m_eff2 = s.simplify(w2.coeff(k, 0)); v2 = s.simplify(w2.coeff(k, 2)); c4 = s.simplify(w2.coeff(k, 4))
    small = {'m_eff^2_minus_mu^2_order': str(s.series(m_eff2 - mu ** 2, mu, 0, 5).removeO()),
             'v^2_minus_1_order': str(s.series(v2 - 1, mu, 0, 3).removeO()), 'k4_coefficient_at_mu0': str(s.limit(c4, mu, 0))}
    ok = outside == 0.0 and abs(norm - 1) < 1e-12 and all(v <= 1 + 1e-6 for v in vg.values()) \
        and s.simplify(w0.subs(k, s.Rational(1, 3)) - s.Rational(1, 3)) == 0
    must(ok, 'LB')
    R['LB'] = dict(claim='Construction: the 1-D Dirac quantum cellular automaton (coin [[n, -i m], [-i m, n]], shift) is local and '
                         'unitary; after t steps the amplitude outside |x - x0| <= t is exactly 0 (strict cone, not a Bessel tail), '
                         'max |d omega/dk| <= 1 for all k, the massless branch omega = |k| is exactly linear, and the massive branch '
                         'obeys omega^2 = m_eff^2 + v^2 k^2 + O(k^4): Dirac at small k with quadratic (not linear) deviation',
                   status='CONSTRUCTED (exact)', max_amplitude_outside_cone=outside, norm=fl(norm), max_group_velocity=vg,
                   series=small)


def LC():
    Nx, T, m = 121, 30, 0.4
    c0 = Nx // 2
    # single-particle propagator columns from site c0 (both components); anticommutator {a_x(t), a_y^dag} = U^t(x, y)
    maxout = 0.0
    for comp in [0, 1]:
        psi = np.zeros((2, Nx), complex); psi[comp, c0] = 1
        for t in range(T):
            psi = dirac_qca_step(psi, m)
        mask = np.abs(np.arange(Nx) - c0) > T
        maxout = max(maxout, float(np.max(np.abs(psi[:, mask]))))
    # continuous-time contrast: nearest-neighbour hopping has nonzero amplitude at every distance
    cont = fl(abs(jv(2 * 40, 2 * 10.0)))
    must(maxout == 0.0 and cont > 0, 'LC')
    R['LC'] = dict(claim='Microcausality: for the QCA field a_x(t) = sum_y U^t(x,y) a_y, the anticommutator {a_x(t), a_y^dag} = U^t(x,y) '
                         'vanishes exactly for |x - y| > t, so the net of local algebras satisfies Haag-Kastler locality exactly. '
                         'Continuous-time hopping leaks at every distance (J_80(20) = %.2e)' % cont,
                   status='CONSTRUCTED (exact)', max_anticommutator_outside=maxout, continuous_time_leak=cont)


# =============================================================================================  S-gate
def SA():
    Nx, T, m = 81, 25, 0.5
    psi = (rng.normal(size=(2, Nx)) + 1j * rng.normal(size=(2, Nx))) * np.exp(-((np.arange(Nx) - 40) / 6.0) ** 2)
    psi /= np.sqrt(np.sum(np.abs(psi) ** 2))
    worst = 0.0
    n = np.sqrt(1 - m * m)
    for _ in range(T):
        Rc = n * psi[0] - 1j * m * psi[1]; Lc = -1j * m * psi[0] + n * psi[1]
        rho_before = np.abs(psi[0]) ** 2 + np.abs(psi[1]) ** 2
        new = np.array([np.roll(Rc, 1), np.roll(Lc, -1)])
        rho_after = np.abs(new[0]) ** 2 + np.abs(new[1]) ** 2
        J = np.abs(Rc) ** 2 - np.abs(np.roll(Lc, -1)) ** 2          # flux across bond x + 1/2 (right movers out, left movers in)
        div = J - np.roll(J, 1)
        worst = max(worst, float(np.max(np.abs(rho_after - rho_before + div))))
        psi = new
    must(worst < 1e-15, 'SA')
    R['SA'] = dict(claim='Number-current balance: the walk obeys the exact discrete continuity equation rho(t+1) - rho(t) = -(J_{x+1/2} - '
                         'J_{x-1/2}) with J = |R_x\'|^2 - |L_{x+1}\'|^2; since the update is one-particle, the second-quantized number '
                         'current obeys the same operator identity. This is a probability-current law, not energy-momentum balance',
                   status='CONSTRUCTED (exact)', max_balance_residual=fl(worst))


def SB():
    Nx, m = 41, 0.4
    n = np.sqrt(1 - m * m)
    coin = np.array([[n, -1j * m], [-1j * m, n]])
    I = np.eye(Nx)
    S = np.zeros((2 * Nx, 2 * Nx), complex)
    S[:Nx, :Nx] = np.roll(I, 1, axis=0); S[Nx:, Nx:] = np.roll(I, -1, axis=0)
    U = S @ np.kron(coin, I)
    Tr = np.kron(np.eye(2), np.roll(I, 1, axis=0))
    glob = np.exp(0.7j) * np.eye(2 * Nx)
    loc = np.diag(np.r_[np.exp(1j * 0.1 * np.arange(Nx)), np.exp(1j * 0.1 * np.arange(Nx))])
    c = lambda A, B: float(np.max(np.abs(A @ B - B @ A)))
    res = dict(global_phase_vs_U=c(glob, U), global_phase_vs_translation=c(glob, Tr), U_vs_translation=c(U, Tr),
               local_phase_vs_U=c(loc, U), local_phase_vs_translation=c(loc, Tr))
    ok = res['global_phase_vs_U'] < 1e-14 and res['global_phase_vs_translation'] < 1e-14 and res['U_vs_translation'] < 1e-14 \
        and res['local_phase_vs_U'] > 1e-3 and res['local_phase_vs_translation'] > 1e-3
    must(ok, 'SB')
    R['SB'] = dict(claim='Internal reference transformations (global phase) commute with evolution and translation; a position-dependent '
                         'internal rotation commutes with neither. Narrow obstruction: a nonzero internal cycle phase on a flat background '
                         'coexists with zero Riemann curvature, so internal holonomy does not by itself determine gravity. Coleman-Mandula '
                         'is not invoked: its mass-gap and S-matrix hypotheses are not checked for massless gravity', status='CONSTRUCTED (toy)', commutators={k: fl(v) for k, v in res.items()})


# =============================================================================================  E-gate
def EA():
    G, mA, mB, q, r = s.symbols('G m_A m_B q r', positive=True)
    kappa = s.sqrt(32 * s.pi * G)
    eta = s.diag(-1, 1, 1, 1)
    TA = s.zeros(4); TA[0, 0] = mA; TB = s.zeros(4); TB[0, 0] = mB
    low = lambda T: eta * T * eta
    num = sum(low(TA)[i, j] * TB[i, j] for i in range(4) for j in range(4)) - s.Rational(1, 2) * sum(eta[i, i] * TA[i, i] for i in range(4)) * sum(eta[i, i] * TB[i, i] for i in range(4))
    Vq = -(kappa / 2) ** 2 * num / q ** 2
    Vr = s.simplify(Vq * q ** 2 / (4 * s.pi * r))          # 1/q^2 -> 1/(4 pi r)
    must(s.simplify(Vr + G * mA * mB / r) == 0, 'EA')
    R['EA'] = dict(claim='Tree-level exchange of the selected massless spin-2 field between static sources, with kappa^2 = 32 pi G and the '
                         'D = 4 numerator, gives V = -G m_A m_B / r', status='PROVED (symbolic)', potential=str(Vr))


def EB():
    t, r, th, ph = s.symbols('t r theta phi'); M = s.Symbol('M', positive=True)
    X = [t, r, th, ph]
    f = 1 - 2 * M / r
    g = s.diag(-f, 1 / f, r ** 2, r ** 2 * s.sin(th) ** 2)
    Rs, Ric2, Riem2, Ric, gi, Gam = invariants(g, X)
    _, _, Rm, _, _ = curvature(g, X)
    n = 4
    Rud = [[[[s.simplify(sum(gi[b, e] * Rm[a][e][c][d] for e in range(n))) for d in range(n)] for c in range(n)] for b in range(n)] for a in range(n)]
    I3 = s.simplify(sum(Rud[a][b][c][d] * Rud[c][d][e][f_] * Rud[e][f_][a][b]
                        for a in range(n) for b in range(n) for c in range(n) for d in range(n) for e in range(n) for f_ in range(n)))
    GB = s.simplify(Riem2 - 4 * Ric2 + Rs ** 2)
    ok = Rs == 0 and Ric2 == 0 and s.simplify(Riem2 - 48 * M ** 2 / r ** 6) == 0 and s.simplify(GB - Riem2) == 0 and I3 != 0
    must(ok, 'EB')
    R['EB'] = dict(claim='On shell (Ricci flat) the one-loop pure-gravity counterterms R^2 and R_ab R^ab vanish and Riemann^2 equals the '
                         'Gauss-Bonnet density (topological in 4-D): one loop is finite on shell (t Hooft-Veltman). The two-loop '
                         'counterterm Riemann^3 is nonzero on Schwarzschild, and its coefficient 209/2880 (4 pi)^-4 is nonzero '
                         '(Goroff-Sagnotti, imported): Einstein-only quantum closure fails', status='PROVED (symbolic) + imported',
                   Kretschmann=str(Riem2), Riemann_cubed=str(I3))


def EC():
    G, hbar, c = 6.67430e-11, 1.054571817e-34, 2.99792458e8
    lP2 = G * hbar / c ** 3
    out = {}
    for label, rr, m1, m2 in [('1 m, 1 kg', 1.0, 1.0, 1.0), ('52 um torsion balance', 52e-6, 1e-3, 1e-3), ('Earth surface', 6.371e6, 5.972e24, 1.0)]:
        out[label] = dict(classical_PN=fl(3 * G * (m1 + m2) / (rr * c ** 2)), quantum=fl(41 / (10 * np.pi) * lP2 / rr ** 2))
    must(out['52 um torsion balance']['quantum'] < 1e-50, 'EC')
    R['EC'] = dict(claim='One-loop gravitational EFT correction V = -G m1 m2/r [1 + 3G(m1+m2)/(r c^2) + 41 G hbar/(10 pi r^2 c^3)] '
                         '(Bjerrum-Bohr, Donoghue, Holstein; imported): the quantum term is unique and parameter-free but of '
                         'relative size l_P^2/r^2', status='IMPORTED coefficient + computed magnitudes', relative_corrections=out)


def ED():
    from fractions import Fraction as F
    # one Standard-Model generation as left-handed Weyl fields: (multiplicity = colour x isospin, hypercharge, su3 rep dim, su2 rep dim)
    fields = {'Q': (6, F(1, 6), 3, 2), 'u^c': (3, F(-2, 3), 3, 1), 'd^c': (3, F(1, 3), 3, 1), 'L': (2, F(-1, 2), 1, 2), 'e^c': (1, F(1), 1, 1)}
    def anomalies(fs):
        grav = sum(m * y for m, y, _, _ in fs.values())                       # mixed gravitational: Tr Y
        y3 = sum(m * y ** 3 for m, y, _, _ in fs.values())                    # U(1)_Y^3
        su2 = sum((m // 2) * y for m, y, c, w in fs.values() if w == 2)       # SU(2)^2 U(1): doublets weighted by colour
        su3 = sum((m // 3) * y for m, y, c, w in fs.values() if c == 3)       # SU(3)^2 U(1): triplets weighted by isospin
        return dict(gravitational=str(grav), Y3=str(y3), SU2_Y=str(su2), SU3_Y=str(su3))
    full = anomalies(fields)
    canary = anomalies({k: v for k, v in fields.items() if k != 'e^c'})
    must(all(v == '0' for v in full.values()) and canary['gravitational'] != '0', 'ED')
    R['ED'] = dict(claim='The perturbative EFT requires anomaly-free matter. One Standard-Model generation has Tr Y = 0 (mixed '
                          'gravitational), Tr Y^3 = 0, and vanishing SU(2)^2 U(1) and SU(3)^2 U(1) anomalies, exactly. Removing the '
                          'right-handed electron breaks the gravitational anomaly (canary)', status='PROVED (exact fractions)',
                    anomalies=full, canary_without_e=canary)


# =============================================================================================  C-gate
def CA():
    X = np.array([[0, 1], [1, 0]], complex); Y = np.array([[0, -1j], [1j, 0]]); Z = np.diag([1., -1.]).astype(complex); I = np.eye(2)
    Cn = np.kron(Z, I) + np.kron(I, Z)
    loc = np.kron(X, I)
    rel = np.kron(X, X) + np.kron(Y, Y)
    c = lambda A, B: float(np.linalg.norm(A @ B - B @ A))
    must(c(rel, Cn) < 1e-14 and c(loc, Cn) > 1, 'CA')
    R['CA'] = dict(claim='Observables must commute with the constraint: the relational exchange X X + Y Y commutes with Z1 + Z2, the local X1 '
                         'does not. In closed vacuum GR no local gauge-invariant observables built from finitely many derivatives exist '
                         '(Torre, imported); RG records are coincidences (relational) by construction', status='CONSTRUCTED (toy) + imported',
                   relational_commutator=fl(c(rel, Cn)), local_commutator=fl(c(loc, Cn)))


# =============================================================================================  U-gate
def UA():
    E_Pl = 1.22089e19          # GeV (Planck energy)
    M_red = 2.435e18           # GeV (reduced Planck mass)
    probes = {'torsion balance 52 um': 3.8e-12, 'LHC 13.6 TeV': 1.36e4, 'UHECR 3e20 eV': 3e11}
    out = {}
    for k, E in probes.items():
        eps = (E / E_Pl) ** 2
        out[k] = dict(eps=fl(eps), samples_needed=fl(0.9 / eps))
    As, r_max = 2.1e-9, 0.036
    H = np.pi * np.sqrt(r_max * As / 2) * M_red
    eps_inf = (H / M_red) ** 2
    modes = sum(2 * l + 1 for l in range(2, 2501))
    out['inflation (r < 0.036)'] = dict(H_GeV=fl(H), eps=fl(eps_inf), samples_needed=fl(0.9 / eps_inf), CMB_modes_to_l2500=modes)
    # KL (Pinsker) version: TV(P^N,Q^N) <= sqrt(N kappa / 2); regular families have kappa = O(eps^2), so N >= 2(1-2delta)^2/kappa
    delta = 0.05
    kl = {}
    for e in [1e-3, 1e-6]:
        p0 = 0.5; P = np.array([p0, 1 - p0]); Qd = np.array([p0 + e, 1 - p0 - e])
        kap = float(np.sum(P * np.log(P / Qd)))
        kl[str(e)] = dict(kappa=fl(kap), kappa_over_eps2=fl(kap / e ** 2), N_KL=fl(2 * (1 - 2 * delta) ** 2 / kap), N_TV=fl((1 - 2 * delta) / e))
    # exact product TV for a small example: N eps bound holds and is nontrivial
    from itertools import product as _prod
    pP, pQ, Nn = 0.5, 0.52, 8
    tv = 0.5 * sum(abs(pP ** sum(b) * (1 - pP) ** (Nn - sum(b)) - pQ ** sum(b) * (1 - pQ) ** (Nn - sum(b))) for b in _prod([0, 1], repeat=Nn))
    ok = all(v['samples_needed'] > 1e9 for v in out.values()) and modes < out['inflation (r < 0.036)']['samples_needed'] \
        and all(abs(v['kappa_over_eps2'] - 2.0) < 0.01 for v in kl.values()) and 0 < tv <= Nn * 0.02
    must(ok, 'UA')
    R['UA'] = dict(claim='Finite-resource discrimination: TV(P^N, Q^N) <= N eps, so error <= delta needs N >= (1 - 2 delta)/eps; with a '
                         'relative-entropy bound kappa, N >= 2(1 - 2 delta)^2/kappa and regular families have kappa ~ 2 eps^2 (Bernoulli '
                         'check), i.e. the stronger eps^-2 scaling. Nominal (E/M)^2 suppressions give eps ~ 1e-61, 1e-30, 6e-16, 4e-10. '
                         'These are illustrative scales: converting an EFT suppression into a uniform law bound needs an observable, '
                         'coefficients, noise and control of all protocols. The conclusion is resource-relative, not exact nullity',
                   status='PROVED (inequalities) + illustrative scales', probes=out, kl_scaling=kl, exact_product_TV_N8=fl(tv))


def UB():
    v, r, M = s.symbols('v r M', positive=True)
    drdv_out = (1 - 2 * M / r) / 2
    inside = s.simplify(drdv_out.subs(r, M))
    horizon = s.simplify(drdv_out.subs(r, 2 * M))
    must(inside < 0 and horizon == 0, 'UB')
    R['UB'] = dict(claim='In ingoing Eddington-Finkelstein coordinates outgoing null rays obey dr/dv = (1 - 2M/r)/2, negative inside r = 2M '
                         'and zero on it: interior records never reach exterior protocols. The interior lies in the observation kernel '
                         'of the exterior (classically); its quantum completion is not decided here',
                   status='PROVED (symbolic)', drdv_at_r_M=str(inside))


def UC():
    x, m = s.symbols('x m', positive=True)
    P = 1 / (x * (1 + x / m ** 2))
    pf = s.apart(P, x)
    res0 = s.residue(P, x, 0); res1 = s.residue(P, x, -m ** 2)
    must(res0 == 1 and res1 == -1, 'UC')
    R['UC'] = dict(claim='Exact fourth-order propagator 1/(k^2(1 + k^2/m^2)) = 1/k^2 - 1/(k^2 + m^2): the second pole has negative residue '
                         '(Stelle ghost in R + Weyl^2); renormalizability bought this way costs unitarity. Treated as an EFT '
                         'expansion it introduces no pole within validity', status='PROVED (symbolic)', partial_fractions=str(pf))


# =============================================================================================  P-gate
def negativity(Rm):
    pt = Rm.reshape(2, 2, 2, 2).transpose(0, 3, 2, 1).reshape(4, 4)
    return float((np.sum(np.abs(np.linalg.eigvalsh(pt))) - 1) / 2)


def PA():
    G, hbar = 6.67430e-11, 1.054571817e-34
    m, d, dx, t = 1e-14, 450e-6, 250e-6, 2.5
    xa = [-dx / 2, dx / 2]; xb = [d - dx / 2, d + dx / 2]
    phi = np.array([[G * m * m * t / (hbar * abs(b - a)) for b in xb] for a in xa])
    Theta = phi[0, 0] + phi[1, 1] - phi[0, 1] - phi[1, 0]
    psi = np.array([np.exp(1j * phi[i, j]) for i in range(2) for j in range(2)]) / 2
    rho = np.outer(psi, psi.conj())
    neg = negativity(rho)
    conc = abs(np.sin(Theta / 2))
    # LOCC canary: mixtures of product unitaries on a product input stay separable
    mx = 0.0
    def ru():
        A = rng.normal(size=(2, 2)) + 1j * rng.normal(size=(2, 2)); Q, _ = np.linalg.qr(A); return Q
    plus = np.array([1, 1]) / np.sqrt(2); p0 = np.outer(np.kron(plus, plus), np.kron(plus, plus).conj())
    for _ in range(200):
        out = np.zeros((4, 4), complex)
        for w in rng.dirichlet(np.ones(4)):
            Uab = np.kron(ru(), ru()); out += w * Uab @ p0 @ Uab.conj().T
        mx = max(mx, negativity(out))
    ok = neg > 1e-3 and abs(neg - conc / 2) < 1e-12 and mx < 1e-12
    must(ok, 'PA')
    R['PA'] = dict(claim='Gravitationally induced entanglement with published parameters (m = 1e-14 kg, d = 450 um, dx = 250 um, t = 2.5 s): '
                         'entangling phase Theta = %.3f rad, negativity |sin(Theta/2)|/2 = %.4f. Mixtures of local operations on product '
                         'inputs never entangle (canary): observed entanglement under the stated locality assumptions witnesses a '
                         'non-classical mediator' % (Theta, neg), status='COMPUTED (assumes the quantum Newton interaction)',
                   Theta=fl(Theta), negativity=fl(neg), LOCC_max_negativity=fl(mx))


def PB():
    # canary: a reversible closed evolution induces irreversible reduced dynamics (CNOT on |+>|0>)
    plus = np.array([1, 1]) / np.sqrt(2)
    psi = np.kron(plus, [1, 0])
    CNOT = np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 0, 1], [0, 0, 1, 0]], complex)
    out = CNOT @ psi
    rho = np.outer(out, out.conj())
    red = np.trace(rho.reshape(2, 2, 2, 2), axis1=1, axis2=3)
    def S(Rm):
        e = np.linalg.eigvalsh(Rm); e = e[e > 1e-14]; return float(-np.sum(e * np.log2(e)))
    unitary = float(np.max(np.abs(CNOT.conj().T @ CNOT - np.eye(4))))
    must(unitary < 1e-15 and abs(S(rho)) < 1e-12 and abs(S(red) - 1) < 1e-12, 'PB')
    R['PB'] = dict(claim='Correction of the first edition: continuous reversibility of closed systems does not exclude decoherence of '
                         'subsystems. A CNOT on |+>|0> is unitary, the joint state stays pure (entropy 0), and the reduced state is I/2 '
                         '(1 bit). Classical-quantum hybrids are therefore not excluded by the reversibility premise alone; the '
                         'decoherence-diffusion trade-off (Oppenheim et al.) is a model-dependent empirical test',
                   status='CONSTRUCTED (canary)', joint_entropy=fl(S(rho)), reduced_entropy=fl(S(red)))


def LD():
    # controlled free Dirac limit on a momentum band: ||U_a(p)^N - exp(-i T H_D(p))|| <= T a P |M|
    Z = np.diag([1., -1.]).astype(complex); X = np.array([[0, 1], [1, 0]], complex)
    T, P, M = 1.0, 3.0, 2.0
    rows = []
    for a in [0.1, 0.05, 0.025, 0.0125]:
        Nst = int(round(T / a)); worst = 0.0
        for pp in np.linspace(-P, P, 61):
            Ua = expm(-1j * a * pp * Z) @ expm(-1j * a * M * X)
            err = np.linalg.norm(np.linalg.matrix_power(Ua, Nst) - expm(-1j * T * (pp * Z + M * X)), 2)
            worst = max(worst, err)
        rows.append(dict(a=a, sup_error=fl(worst), bound=fl(T * a * P * M)))
    # exact massive dispersion: omega^2 = alpha^2 + (alpha n / m) k^2 + O(k^4), alpha = arcsin m; group velocity identity
    k, m = s.symbols('k m', positive=True)
    n = s.sqrt(1 - m ** 2)
    w2 = s.series(s.acos(n * s.cos(k)) ** 2, k, 0, 4).removeO()
    alpha = s.asin(m)
    c0 = max(abs(float((w2.coeff(k, 0) - alpha ** 2).subs(m, mv))) for mv in [0.1, 0.3, 0.7, 0.95])
    c2 = s.simplify((w2.coeff(k, 2) - alpha * n / m).subs(m, s.Rational(3, 10)))
    om = s.acos(n * s.cos(k))
    vg2 = s.simplify(s.diff(om, k) ** 2 - n ** 2 * s.sin(k) ** 2 / (1 - n ** 2 * s.cos(k) ** 2))
    ok = all(r['sup_error'] <= r['bound'] * (1 + 1e-9) for r in rows) and c0 < 1e-12 and abs(float(c2)) < 1e-12 \
        and s.simplify(vg2.subs({m: s.Rational(3, 10), k: s.Rational(7, 10)})) == 0
    must(ok, 'LD')
    R['LD'] = dict(claim='Free Dirac limit on a fixed momentum band: sup_|p|<=P ||U_a(p)^N - exp(-i T (pZ + MX))|| <= T a P |M| (checked for '
                         'a = 0.1 ... 0.0125); exact dispersion omega^2 = alpha^2 + (alpha n/m) k^2 + O(k^4) with alpha = arcsin m and '
                         'omega\'^2 = n^2 sin^2 k/(1 - n^2 cos^2 k) <= 1', status='PROVED (Duhamel) + checked', rows=rows)


def LE():
    # graded locality: odd fields anticommute outside the cone; even bilinears commute outside the cone
    Nx, t_, m = 41, 6, 0.4
    n = np.sqrt(1 - m * m)
    coin = np.array([[n, -1j * m], [-1j * m, n]])
    I = np.eye(Nx)
    Sh = np.zeros((2 * Nx, 2 * Nx), complex)
    Sh[:Nx, :Nx] = np.roll(I, 1, axis=0); Sh[Nx:, Nx:] = np.roll(I, -1, axis=0)
    U = Sh @ np.kron(coin, I)
    Ut = np.linalg.matrix_power(U, t_)
    def Pn(x):
        P_ = np.zeros((2 * Nx, 2 * Nx)); P_[x, x] = 1; P_[Nx + x, Nx + x] = 1; return P_
    x0 = 20
    out_even, in_even, out_odd = 0.0, 0.0, 0.0
    for y in range(Nx):
        Mx = Ut.conj().T @ Pn(x0) @ Ut              # one-particle matrix of n_x(t)
        c = np.linalg.norm(Mx @ Pn(y) - Pn(y) @ Mx)
        odd = np.max(np.abs(Ut[np.ix_([y, Nx + y], [x0, Nx + x0])]))
        if abs(y - x0) > t_:
            out_even = max(out_even, c); out_odd = max(out_odd, odd)
        elif abs(y - x0) <= t_ - 1:
            in_even = max(in_even, c)
    must(out_even == 0 and out_odd == 0 and in_even > 1e-3, 'LE')
    R['LE'] = dict(claim='Graded locality: odd fields have {a_x(t), a_y^dag} = U^t(x,y) = 0 for |x-y| > t; even bilinears n_x(t), n_y '
                         'commute exactly outside the cone and not inside. The even net is the commuting observable net; the odd net is '
                         'graded-local; neither is yet a continuum Haag-Kastler theory', status='CONSTRUCTED (exact)',
                   max_even_commutator_outside=fl(out_even), max_odd_outside=fl(out_odd), max_even_commutator_inside=fl(in_even))


def FA():
    # improvement terms are conserved; equal mean sources need not have equal fluctuations; truncation defect
    t, x, y, z = s.symbols('t x y z'); X = [t, x, y, z]
    eta = s.diag(-1, 1, 1, 1); F = s.Function('F')(*X)
    box = sum(eta[i, i] * s.diff(F, X[i], 2) for i in range(4))
    I_ = s.Matrix(4, 4, lambda i, j: eta[i, j] * box - s.diff(F, X[i], X[j]))
    div = [s.simplify(sum(eta[i, i] * s.diff(I_[i, j], X[i]) for i in range(4))) for j in range(4)]
    H = np.diag([0., 1., 2.])
    r1, r2 = np.diag([0., 1., 0.]), np.diag([.5, 0., .5])
    mv = [(float(np.trace(r @ H)), float(np.trace(r @ H @ H) - np.trace(r @ H) ** 2)) for r in (r1, r2)]
    Nl = 6
    a = np.diag(np.sqrt(np.arange(1, Nl)), 1)
    defect = a @ a.T - a.T @ a - np.eye(Nl)
    ok = all(d == 0 for d in div) and mv[0][0] == mv[1][0] and mv[0][1] != mv[1][1] \
        and abs(defect[Nl - 1, Nl - 1] + Nl) < 1e-12 and np.count_nonzero(np.abs(defect) > 1e-12) == 1
    must(ok, 'FA')
    R['FA'] = dict(claim='(eta box - dd)F is identically conserved (an improvement the conservation law cannot fix); states with equal mean '
                         'energy 1 have variances 0 and 1 (mean-source equations drop fluctuations); the truncated oscillator has '
                         '[a_N, a_N^dag] = I - N|N-1><N-1|, a defect of norm N invisible on the lower block',
                   status='PROVED (exact)', means_variances=mv, defect_corner=fl(defect[Nl - 1, Nl - 1]))


def HA():
    # action quantum: universality from exchange balance. Resonant exchange of one quantum between sectors A and B,
    # both at phase frequency w: A loses hbar_A w, B gains hbar_B w.
    w = 2 * np.pi * 1e14
    rows = {}
    for hA, hB in [(1.0, 1.0), (1.0, 1.001), (1.0, 1.01)]:
        Hswap = np.array([[0, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0], [0, 0, 0, 0]], complex)
        U = expm(-1j * Hswap * np.pi / 2)
        psi0 = np.array([0, 0, 1, 0], complex)                  # |1_A 0_B>
        psi = U @ psi0
        pA = abs(psi[2]) ** 2; pB = abs(psi[1]) ** 2
        E0 = hA * w * 1.0
        E1 = hA * w * pA + hB * w * pB
        rows[f'{hA}_{hB}'] = fl((E1 - E0) / E0)
    must(rows['1.0_1.0'] == 0 and rows['1.0_1.01'] > 5 * rows['1.0_1.001'] > 0, 'HA')
    R['HA'] = dict(claim='The action quantum is the action-to-phase anchor of the complex realization, U = exp(-i H t / hbar); the '
                         'reconstruction fixes no value. If two sectors had hbar_A != hbar_B, a resonant exchange of one quantum at '
                         'common phase frequency would change the mechanical energy ledger by (hbar_B - hbar_A) w: relative drift 0, '
                         '1e-3, 1e-2 for ratios 1, 1.001, 1.01. Exchange balance forces one universal hbar, as one relabeling forces '
                         'one G', status='CONSTRUCTED (toy)', relative_energy_drift=rows)


def HB():
    import math
    from scipy.optimize import brentq
    from scipy.integrate import quad
    h, c, kB = 6.62607015e-34, 299792458.0, 1.380649e-23        # exact SI
    S = lambda n: 2 * math.pi ** (n / 2) / math.gamma(n / 2)
    tab = {}
    for n in [2, 3, 4, 5]:
        xnu = brentq(lambda x: x - n * (1 - math.exp(-x)), 0.5, 20)
        xla = brentq(lambda x: x - (n + 2) * (1 - math.exp(-x)), 0.5, 20)
        b = h * c / (xla * kB)
        pol = n - 1                                              # massless vector: D - 2 polarizations
        integral = quad(lambda x: x ** n / math.expm1(x), 0, 200)[0]
        tab[str(n)] = dict(x_nu=fl(xnu), x_lambda=fl(xla), wien_b=fl(b), photon_polarizations=pol,
                           mode_prefactor=fl(pol * S(n)), energy_scaling_exponent=n + 1, integral=fl(integral))
    # lattice mode counting in an n-dimensional box: number of modes with |k| <= K grows like K^n (density ~ nu^(n-1))
    count = {}
    for n in [2, 3, 4]:
        Ks = [20, 40]
        cnt = []
        for K in Ks:
            rng_ = np.arange(-K, K + 1)
            grids = np.meshgrid(*([rng_] * n), indexing='ij')
            r2 = sum(g_ ** 2 for g_ in grids)
            cnt.append(int(np.sum(r2 <= K * K)))
        count[str(n)] = fl(np.log(cnt[1] / cnt[0]) / np.log(2))
    # recover h from a measured Wien constant, and the frequency/wavelength peak mismatch
    b3 = tab['3']['wien_b']
    h_from_b = b3 * tab['3']['x_lambda'] * kB / c
    T = 2400.0
    mismatch = (c / (b3 / T)) / (tab['3']['x_nu'] * kB * T / h)
    # synthetic shape test (labelled synthetic): n = 3 Planck spectrum with 50 ppm-of-peak noise; best n = 4 form fails
    xs = np.linspace(0.5, 12, 200)
    def shape(n, xx, sc):
        return xx ** n / np.expm1(xx / sc)
    data = shape(3, xs, 1.0)
    noise = 50e-6 * data.max() * rng.normal(size=xs.size)
    data = data + noise
    best = {}
    for n in [3, 4]:
        best_r = np.inf
        for sc in np.linspace(0.5, 1.6, 2201):
            f_ = shape(n, xs, sc)
            A = float(f_ @ data / (f_ @ f_))
            r = np.sqrt(np.mean((data - A * f_) ** 2)) / data.max()
            best_r = min(best_r, r)
        best[str(n)] = fl(best_r)
    # non-circular radiometric witness (correction): absolute cryogenic radiometry, Quinn and Martin 1985,
    # sigma = (5.66967 +- 0.00076)e-8 W m^-2 K^-4 over 233-373 K; theory from exact h, k_B, c in n = 3.
    sig_th = 2 * math.pi ** 5 * kB ** 4 / (15 * h ** 3 * c ** 2)
    z_qm = (5.66967e-8 - sig_th) / 0.00076e-8
    delta_bound = 4 * (0.010 / 373.15) / math.log(373.15 / 273.16)   # exponent bound if T_rad - T_gas <= 10 mK at 373 K
    # circularity canary: a differential null against a blackbody calibrator vanishes for every n (FIRAS cannot witness n)
    nu_ = np.linspace(1.0, 20.0, 100)
    diff_null = max(float(np.max(np.abs(shape(n, nu_, 1.0) - shape(n, nu_, 1.0)))) for n in (2, 3, 4))
    ok_rad = abs(z_qm) < 2 and delta_bound < 1e-3 and diff_null == 0.0
    ok = ok_rad and abs(tab['3']['x_nu'] - 2.821439372) < 1e-8 and abs(tab['3']['x_lambda'] - 4.965114232) < 1e-8 \
        and abs(b3 - 2.897771955e-3) < 1e-12 and abs(tab['3']['mode_prefactor'] - 8 * math.pi) < 1e-9 \
        and abs(h_from_b - h) / h < 1e-9 and abs(count['3'] - 3) < 0.1 and abs(count['2'] - 2) < 0.1 and abs(count['4'] - 4) < 0.1 \
        and best['3'] < 1e-4 and best['4'] > 100 * best['3'] and abs(mismatch - 1.76) < 0.01
    must(ok, 'HB')
    R['HB'] = dict(claim='Thermal radiation of a massless vector in n space dimensions: u(nu,T) = (n-1) S_{n-1} h nu^n / c^n / (e^{h nu/kT} - 1); '
                         'the frequency peak solves x = n(1 - e^{-x}), the wavelength peak x = (n+2)(1 - e^{-x}); total energy ~ T^{n+1}; '
                         'lattice mode counts grow as K^n. For n = 3: prefactor 8 pi, x_nu = 2.821439, x_lambda = 4.965114, '
                         'b = 2.897771955e-3 m K from exact SI constants. Synthetic shape test (property of the forms only): an n = 3 spectrum '
                         'with 50 ppm-of-peak noise is fit by the n = 3 form and rejected by the best n = 4 form. CORRECTION: the FIRAS '
                         'spectrum is not a dimension witness (differential null against a Planck-calibrated blackbody vanishes for '
                         'every n). The witness is absolute radiometry: Quinn-Martin sigma agrees with the n = 3 value at 0.93 sigma, '
                         'and gas-thermometry agreement bounds the exponent offset below 3.4e-4. hbar is not '
                         'derived: a measured b determines h only given c and k_B, and c/lambda_peak is not the frequency peak (factor 1.76)',
                   status='PROVED (exact) + synthetic shape test (labelled) + MEASURED radiometric witness', table=tab, mode_count_exponents=count,
                   sigma_theory=fl(sig_th), quinn_martin_z=fl(z_qm), exponent_delta_bound_10mK=fl(delta_bound), differential_null_any_n=fl(diff_null),
                   h_from_b_rel_err=fl(abs(h_from_b - h) / h), peak_mismatch=fl(mismatch), synthetic_rms_residual_over_peak=best)


# =============================================================================================  K-gate: existence of the kernel
def KA():
    """Existence lemma for Gaussian kernels: quotient; definite -> both kernels; indefinite -> amplitude only."""
    from scipy.integrate import quad
    import math
    lrng = np.random.default_rng(SEED + 101)
    # (a) no positive kernel for an indefinite form: Gibbs integral diverges; level sets have infinite measure (log law)
    gib = [quad(lambda y: math.exp(y * y / 2), 0, Rr)[0] for Rr in (2.0, 4.0, 6.0)]
    s_, dl = 1.0, 0.01
    level = lambda Rr: quad(lambda y: 2 * (math.sqrt(y * y + s_ + dl) - math.sqrt(y * y + s_ - dl)), -Rr, Rr, limit=400)[0]
    growth = [level(10.0 ** k) for k in (1, 2, 3, 4)]
    steps = [growth[i + 1] - growth[i] for i in range(3)]
    log_law = 4 * dl * math.log(10)
    # (b) regularized oscillatory integral by quadrature, one dimension; then the signature phase in the limit
    def fres(lam, eps, L=60.0, n=600001):
        xg = np.linspace(-L, L, n); f = np.exp((1j * lam - eps) * xg ** 2 / 2)
        tz = np.trapezoid if hasattr(np, 'trapezoid') else np.trapz
        Z = tz(f, xg); return Z, tz(xg ** 2 * f, xg) / Z
    qerr = 0.0
    for lam in (1.0, -1.0, 2.5, -0.4):
        Z, m2 = fres(lam, 0.05)
        qerr = max(qerr, abs(Z - np.sqrt(2 * math.pi / (0.05 - 1j * lam))) / abs(Z), abs(m2 - 1 / (0.05 - 1j * lam)) / abs(m2))
    phases = {}
    for (pp, qq) in ((3, 0), (3, 1), (1, 3), (2, 2), (0, 3)):
        lam = np.concatenate([lrng.uniform(0.5, 2, pp), -lrng.uniform(0.5, 2, qq)])
        Zs = [np.prod(np.sqrt(2 * math.pi / (e - 1j * lam))) for e in (1e-4, 1e-6)]
        target = (2 * math.pi) ** ((pp + qq) / 2) / math.sqrt(np.prod(np.abs(lam))) * np.exp(1j * math.pi * (pp - qq) / 4)
        phases[f'{pp},{qq}'] = dict(limit_err=fl(abs(Zs[-1] - target) / abs(target)), cauchy=fl(abs(Zs[-1] - Zs[-2]) / abs(target)))
    # regulator independence: a different positive regulator eps x^T B x / 2 gives the same limit
    reg = 0.0
    for (pp, qq) in ((3, 1), (2, 2)):
        nn = pp + qq; Q_, _r = np.linalg.qr(lrng.normal(size=(nn, nn)))
        lam = np.concatenate([lrng.uniform(0.5, 2, pp), -lrng.uniform(0.5, 2, qq)]); Am = Q_ @ np.diag(lam) @ Q_.T
        Bm = lrng.normal(size=(nn, nn)); Bm = Bm @ Bm.T + nn * np.eye(nn)
        Lc = np.linalg.cholesky(Bm); mu = np.linalg.eigvalsh(np.linalg.solve(Lc, np.linalg.solve(Lc, Am).T))
        Zb = (2 * math.pi) ** (nn / 2) / math.sqrt(np.linalg.det(Bm)) * np.prod(1 / np.sqrt(1e-7 - 1j * mu))
        target = (2 * math.pi) ** (nn / 2) / math.sqrt(abs(np.linalg.det(Am))) * np.exp(1j * math.pi * (pp - qq) / 4)
        reg = max(reg, abs(Zb - target) / abs(target))
    # (c) degenerate direction: divergence like eps^(-1/2) on the full space; limit exists on the quotient
    lam_d = np.array([1.3, -0.7, 0.0])
    Zd = [abs(np.prod(np.sqrt(2 * math.pi / (e - 1j * lam_d)))) for e in (1e-2, 1e-4, 1e-6)]
    blow = [Zd[i + 1] / Zd[i] for i in range(2)]
    Zq = [np.prod(np.sqrt(2 * math.pi / (e - 1j * lam_d[:2]))) for e in (1e-4, 1e-6)]
    quot = abs(Zq[1] - Zq[0]) / abs(Zq[1])
    # (d) covariance of the oscillatory kernel is i A^-1; (e) definite case: Wick phase exp(i pi n / 4)
    A = np.diag([1.3, -0.7]); cov_err = float(np.max(np.abs(np.linalg.inv(1e-9 * np.eye(2) - 1j * A) - 1j * np.linalg.inv(A))))
    lam_p = lrng.uniform(0.5, 2, 4)
    ZE = (2 * math.pi) ** 2 / math.sqrt(np.prod(lam_p)); Zo = np.prod(np.sqrt(2 * math.pi / (1e-9 - 1j * lam_p)))
    wick = abs(Zo - ZE * np.exp(1j * math.pi)) / ZE
    ok = gib[2] > 1e4 * gib[0] and all(abs(st - log_law) < 2e-3 * log_law for st in steps) and qerr < 1e-6 \
        and all(v['limit_err'] < 1e-5 for v in phases.values()) and all(abs(b - 10) < 0.05 for b in blow) and quot < 1e-3 \
        and cov_err < 1e-8 and wick < 1e-8 and reg < 1e-5
    must(ok, 'KA')
    R['KA'] = dict(claim='Existence lemma for Gaussian kernels. S(x) = x^T A x / 2. Degenerate A: no kernel on the full space (the '
                         'regularized integral diverges like eps^(-1/2) per null direction); it exists on the quotient by ker A. '
                         'Definite A: exp(-S) and exp(iS) both exist and differ by exp(i pi n/4). Indefinite A: no positive weight '
                         'w(S) is integrable (shell measure grows by 4 delta ln 10 per decade of radius), while the regularized '
                         'oscillatory integral converges to (2 pi)^(n/2) |det A|^(-1/2) exp(i pi (p-q)/4) with complex covariance '
                         'i A^-1, the same for every positive Gaussian regulator. For an indefinite action the only kernel that exists is an amplitude. Canaries: the positive '
                         'integral diverges; the degenerate case has no limit.',
                   status='PROVED (Gaussian/Fresnel integrals) + quadrature check', gibbs_truncated=[fl(v) for v in gib],
                   shell_growth_per_decade=[fl(v) for v in steps], predicted_growth=fl(log_law), quadrature_err=fl(qerr),
                   signature_phase=phases, regulator_independence_err=fl(reg), degenerate_growth_factor=[fl(b) for b in blow], quotient_limit_change=fl(quot),
                   covariance_err=fl(cov_err), wick_relation_err=fl(wick))


def KB():
    """Linearized gravity: Euclidean quadratic form on the gauge quotient has one negative direction; scalar form is positive."""
    import math
    lrng = np.random.default_rng(SEED + 102)
    out = {}
    for D in (3, 4, 5, 6):
        pv = lrng.normal(size=D); p2 = float(pv @ pv)
        idx = [(i, j) for i in range(D) for j in range(i, D)]
        def basis(k):
            i, j = idx[k]; hh = np.zeros((D, D)); hh[i, j] = hh[j, i] = 1.0 if i == j else 1 / math.sqrt(2); return hh
        def bil(hh, kk):
            ph, pk = pv @ hh, pv @ kk
            return (0.5 * p2 * np.sum(hh * kk) - ph @ pk + 0.5 * (pv @ hh @ pv) * np.trace(kk) + 0.5 * (pv @ kk @ pv) * np.trace(hh)
                    - 0.5 * p2 * np.trace(hh) * np.trace(kk))
        n = len(idx); Qm = np.array([[bil(basis(a), basis(b)) for b in range(n)] for a in range(n)])
        ev = np.linalg.eigvalsh(Qm); tol = 1e-9 * np.max(np.abs(ev))
        sig = (int(np.sum(ev > tol)), int(np.sum(ev < -tol)), int(np.sum(np.abs(ev) <= tol)))
        xi = lrng.normal(size=D); gauge = np.outer(pv, xi) + np.outer(xi, pv); h0 = lrng.normal(size=(D, D)); h0 = h0 + h0.T
        gi = abs(bil(h0 + gauge, h0 + gauge) - bil(h0, h0)) / abs(bil(h0, h0))
        theta = np.eye(D) - np.outer(pv, pv) / p2
        # source existence: the regulated response T (eps + Q)^-1 T has a limit iff the source is conserved (p.T = 0)
        vec = lambda hh: np.array([np.sum(hh * basis(k)) for k in range(n)])
        S0 = lrng.normal(size=(D, D)); S0 = S0 + S0.T; Tc = vec(theta @ S0 @ theta); Tn = vec(S0)
        resp = lambda T_, e: float(T_ @ np.linalg.solve(e * np.eye(n) + Qm, T_))
        cons = abs(resp(Tc, 1e-8) - resp(Tc, 1e-10)) / abs(resp(Tc, 1e-10)); noncons = resp(Tn, 1e-10) / resp(Tn, 1e-8)
        out[str(D)] = dict(positive=sig[0], negative=sig[1], gauge_zero=sig[2], gauge_invariance=fl(gi),
                           conformal_value=fl(bil(theta, theta) / p2), predicted=fl(-0.5 * (D - 1) * (D - 2)),
                           conserved_source_change=fl(cons), nonconserved_source_growth=fl(noncons))
    # scalar lattice action (Euclidean, quartic): Hessian at any field is positive definite: the probability kernel exists on the lattice
    N = 6; I1 = np.eye(N); T1 = 2 * I1 - np.roll(I1, 1, 0) - np.roll(I1, -1, 0)
    K3 = np.kron(np.kron(T1, I1), I1) + np.kron(np.kron(I1, T1), I1) + np.kron(np.kron(I1, I1), T1)
    phi = lrng.normal(size=N ** 3)
    Hs = K3 + np.diag(1.0 + 3 * 3.0 * phi ** 2)
    scalar_min = float(np.min(np.linalg.eigvalsh(Hs)))
    # free lattice field on (16 time steps) x (4 sites): the Lorentzian action form is indefinite, the Euclidean one positive
    def ring(m_, h_):
        I_ = np.eye(m_); return (2 * I_ - np.roll(I_, 1, 0) - np.roll(I_, -1, 0)) / h_ ** 2
    Kt, Kx = ring(16, 0.25), ring(4, 1.0) + np.eye(4)
    evL = np.linalg.eigvalsh(np.kron(Kt, np.eye(4)) - np.kron(np.eye(16), Kx)); evE = np.linalg.eigvalsh(np.kron(Kt, np.eye(4)) + np.kron(np.eye(16), Kx))
    lor = (int(np.sum(evL > 1e-9)), int(np.sum(evL < -1e-9))); euc_min = float(np.min(evE))
    ok = lor[0] > 0 and lor[1] > 0 and euc_min > 0 and all(v['conserved_source_change'] < 1e-6 and 90 < v['nonconserved_source_growth'] < 110
                                                           for v in out.values()) and all(v['negative'] == 1 and v['gauge_zero'] == int(D_) and v['positive'] == int(D_) * (int(D_) + 1) // 2 - int(D_) - 1
             and v['gauge_invariance'] < 1e-9 and abs(v['conformal_value'] - v['predicted']) < 1e-9 for D_, v in out.items()) \
        and scalar_min >= 1.0 - 1e-9
    must(ok, 'KB')
    R['KB'] = dict(claim='Application of the existence lemma. The Euclidean quadratic form of linearized gravity is gauge invariant with D '
                         'zero directions, so its kernel lives on the gauge quotient; on the quotient it has exactly one negative '
                         'direction per momentum, the conformal mode, with value -(D-1)(D-2)/2 p^2 (signature (5,1) in D = 4). No '
                         'positive kernel exists for the gravitational field; the oscillatory kernel exists on the quotient. This is '
                         'the conformal-factor problem, identified. The regulated source response has a limit exactly when the '
                         'source is conserved (it grows like 1/eps otherwise): the Ward identity is the existence condition. The '
                         'Lorentzian action form of a free lattice field is indefinite; its Euclidean form is positive. Contrast '
                         'canary: the Euclidean lattice action of the quartic scalar has a positive definite Hessian at every '
                         'field, so its probability kernel exists.',
                   status='PROVED (finite-dimensional forms) + IDENTIFIED (Gibbons-Hawking-Perry)', signature_by_dimension=out,
                   scalar_hessian_min_eig=fl(scalar_min), lorentzian_form_signs=list(lor), euclidean_form_min_eig=fl(euc_min))


# =============================================================================================  I-gate: interacting 3+1 limit
I_LAM, I_KAP, I_M2, I_T, I_SRC, I_AMP = 3.0, 1.0, 1.0, 0.5, 0.2, 4.0
E_PLANCK_GEV, L_PLANCK_M = 1.220890e19, 1.616255e-35


def _grid(N):
    x = np.arange(N) / N
    return np.meshgrid(x, x, x, indexing='ij')


def _init3(N):
    X, Y, Z = _grid(N); tp = 2 * np.pi
    q = I_AMP * (0.4 * np.cos(tp * X) * np.cos(tp * Y) + 0.15 * np.sin(2 * tp * Z) + 0.1 * np.cos(tp * (X + Y + Z)))
    p = I_AMP * 0.2 * np.sin(tp * X) * np.cos(tp * Z)
    return q, p


def _force3(t, N):
    X, Y, Z = _grid(N); tp = 2 * np.pi
    return (np.cos(tp * X) * np.cos(tp * Y) + 0.5 * np.sin(tp * (Y - Z))) * (1 + 0.3 * np.sin(3 * t))


def _lap3(q):
    N = q.shape[0]
    return N * N * (sum(np.roll(q, s_, ax) for ax in range(3) for s_ in (1, -1)) - 6 * q)


def _grad3(q):
    N = q.shape[0]
    return [N * (np.roll(q, -1, ax) - q) for ax in range(3)]


def _l2(v):
    return float(np.sqrt(np.mean(np.abs(v) ** 2)))


def _enorm(dq, dp):
    return float(np.sqrt(_l2(dp) ** 2 + I_KAP * sum(_l2(g) ** 2 for g in _grad3(dq)) + I_M2 * _l2(dq) ** 2))


def _run3(N, spectral=False, lam=I_LAM, predictor=False, src=I_SRC):
    """Cubic field on the 3-torus. Fields: state (q, p), first source variation (z, w), second source variation (y, v),
    and optionally the first lattice-correction field (e, e'). spectral=True is the continuum reference (Fourier Laplacian)."""
    from scipy.integrate import solve_ivp
    q0, p0 = _init3(N); nf = 8 if predictor else 6; M = N ** 3
    k1 = 2 * np.pi * np.fft.fftfreq(N, d=1 / N); KX, KY, KZ = np.meshgrid(k1, k1, k1, indexing='ij')
    k2 = KX ** 2 + KY ** 2 + KZ ** 2; k4 = KX ** 4 + KY ** 4 + KZ ** 4
    def Lp(v):
        return np.fft.ifftn(-k2 * np.fft.fftn(v)).real if spectral else _lap3(v)
    def rhs(t, Y):
        F = Y[:nf * M].reshape(nf, N, N, N); q, p, z, w, y, v = F[:6]; f = _force3(t, N); mm = I_M2 + 3 * lam * q * q
        out = [p, I_KAP * Lp(q) - I_M2 * q - lam * q ** 3 + src * f, w, I_KAP * Lp(z) - mm * z + f,
               v, I_KAP * Lp(y) - mm * y - 6 * lam * q * z * z]
        if predictor:
            e, ed = F[6], F[7]
            d4 = np.fft.ifftn(k4 * np.fft.fftn(q)).real
            out += [ed, I_KAP * Lp(e) - mm * e + I_KAP * d4 / 12]
        return np.concatenate([o.ravel() for o in out] + [[np.mean(src * f * p)]])
    Y0 = np.concatenate([q0.ravel(), p0.ravel(), np.zeros((nf - 2) * M), [0.0]])
    sol = solve_ivp(rhs, (0, I_T), Y0, method='DOP853', rtol=1e-9, atol=1e-11)
    F = sol.y[:nf * M, -1].reshape(nf, N, N, N)
    return F, float(sol.y[-1, -1])


def _energy3(q, p, lam=I_LAM):
    return float(np.mean(0.5 * p * p + 0.5 * I_KAP * sum(g * g for g in _grad3(q)) + 0.5 * I_M2 * q * q + lam * q ** 4 / 4))


_I_CACHE = {}


def _interacting_runs():
    if not _I_CACHE:
        _I_CACHE['ref'] = _run3(32, spectral=True, predictor=True)
        _I_CACHE['ref16'] = _run3(16, spectral=True)
        _I_CACHE['wrong'] = _run3(32, spectral=True, lam=0.0)
        for N in (8, 16, 32):
            _I_CACHE[N] = _run3(N)
    return _I_CACHE


def _sub(A, st):
    return A[::st, ::st, ::st]


def IA():
    """Uniform discrete Sobolev inequality in three dimensions; adversarial search; the wall in exponent and in dimension."""
    from scipy.optimize import minimize
    lrng = np.random.default_rng(SEED + 103)
    def norms(w, pw):
        return float(np.mean(np.abs(w) ** pw) ** (1 / pw)), float(np.sqrt(sum(_l2(g) ** 2 for g in _grad3(w)) + _l2(w) ** 2))
    conc, delta = {}, {}
    for N in (8, 16, 32, 64):
        X, Y, Z = _grid(N)
        r2 = sum(np.minimum(np.abs(c - 0.5), 1 - np.abs(c - 0.5)) ** 2 for c in (X, Y, Z))
        fam = {'delta': np.zeros((N, N, N))}; fam['delta'][0, 0, 0] = 1.0
        for sg in (1.0 / N, 2.0 / N, 0.05, 0.15):
            fam[f'gauss_{sg:.4f}'] = np.exp(-r2 / (2 * sg * sg))
        for ep in (1.0 / N, 2.0 / N, 0.03):
            fam[f'bubble_{ep:.4f}'] = 1 / np.sqrt(ep * ep + r2)
        fam['white'] = lrng.normal(size=(N, N, N))
        conc[N] = max(norms(w, 6)[0] / norms(w, 6)[1] for w in fam.values())
        delta[N] = {pw: norms(fam['delta'], pw)[0] / norms(fam['delta'], pw)[1] for pw in (6, 8, 10)}
    # adversarial search: maximize the ratio over all lattice functions (full space), and over mean-zero functions
    def ascent(N, meanzero, start):
        def fg(v):
            w = v.reshape(N, N, N); w = w - w.mean() if meanzero else w
            s6 = np.sum(w ** 6); Hw = -I_KAP * _lap3(w) + w; sh = np.sum(w * Hw)
            g = w ** 5 / s6 - Hw / sh
            if meanzero:
                g = g - g.mean()
            return -(np.log(s6) / 6 - np.log(sh) / 2 + np.log(N ** 3) * (0.5 - 1 / 6)), -g.ravel()
        res = minimize(fg, start.ravel(), jac=True, method='L-BFGS-B', options=dict(maxiter=400))
        return float(np.exp(-res.fun))
    adv_full, adv_mz = {}, {}
    for N in (8, 12, 16, 24):
        starts = [lrng.normal(size=(N, N, N)) for _ in range(3)]
        d0 = np.zeros((N, N, N)); d0[0, 0, 0] = 1.0; starts.append(d0 + 1e-3 * lrng.normal(size=(N, N, N)))
        adv_full[N] = max(ascent(N, False, s0) for s0 in starts)
        adv_mz[N] = max(ascent(N, True, s0) for s0 in starts)
    # walls: exponent above 6 in three dimensions; exponent 6 in four dimensions (lattice delta, exact arrays)
    grow8 = delta[64][8] / delta[8][8]; grow10 = delta[64][10] / delta[8][10]; grow6 = delta[64][6] / delta[8][6]
    d4 = {}
    for N in (4, 8, 16):
        w = np.zeros((N,) * 4); w[0, 0, 0, 0] = 1.0
        g2 = sum(np.mean((N * (np.roll(w, -1, ax) - w)) ** 2) for ax in range(4))
        d4[N] = float(np.mean(w ** 6) ** (1 / 6) / np.sqrt(g2 + np.mean(w ** 2)))
    grow4d = d4[16] / d4[4]
    Ns = (8, 12, 16, 24); mz = [adv_mz[N] for N in Ns]
    slope = [(mz[i + 1] - mz[i]) / (1 / Ns[i] - 1 / Ns[i + 1]) for i in range(3)]; mz_limit = mz[-1] + slope[-1] / Ns[-1]
    ok = max(conc.values()) < 0.6 and conc[64] <= conc[32] <= conc[16] <= conc[8] and abs(delta[64][6] - 1 / np.sqrt(6)) < 1e-3 \
        and max(adv_full.values()) < 1.0 + 1e-6 and max(slope) / min(slope) < 1.15 and min(slope) > 0 and mz_limit < 0.55 \
        and abs(grow6 - 1) < 0.01 and abs(grow8 - 8 ** 0.125) < 0.01 and abs(grow10 - 8 ** 0.2) < 0.01 and abs(grow4d - 4 ** (1 / 3)) < 0.02
    must(ok, 'IA')
    R['IA'] = dict(claim='Uniform discrete Sobolev inequality on the three-dimensional lattice torus: ||w||_6 <= C_S ||w||_{H^1_a} with '
                         'C_S independent of the spacing. Test families (lattice delta, Gaussians, bubbles, white noise) give a ratio '
                         'below 0.6 that does not increase with N, the delta giving 1/sqrt(6); an adversarial ascent over all '
                         'lattice functions does not exceed the constant function (ratio 1), and over mean-zero functions it '
                         'returns values that approach a finite limit (0.504) linearly in the spacing. This estimate makes the cubic force Lipschitz from the energy space to L^2. Walls: for '
                         'exponents above 6 the delta ratio grows like N^(1/2 - 3/p) (measured N^(1/8), N^(1/5)); in four space '
                         'dimensions the exponent 6 itself fails (growth N^(1/3)). The cubic force in three space dimensions is the '
                         'endpoint case of the energy method.',
                   status='IMPORTED (Sobolev embedding) + numerical witness + wall canaries',
                   concentrating_sup_by_N={str(k): fl(v) for k, v in conc.items()}, delta_ratio_N64=fl(delta[64][6]),
                   adversarial_full_by_N={str(k): fl(v) for k, v in adv_full.items()},
                   adversarial_meanzero_by_N={str(k): fl(v) for k, v in adv_mz.items()},
                   meanzero_slopes=[fl(s_) for s_ in slope], meanzero_extrapolated=fl(mz_limit),
                   delta_growth_p6=fl(grow6), delta_growth_p8=fl(grow8), delta_growth_p10=fl(grow10), predicted_p8=fl(8 ** 0.125),
                   predicted_p10=fl(8 ** 0.2), four_dim_delta_ratio={str(k): fl(v) for k, v in d4.items()},
                   four_dim_growth=fl(grow4d), predicted_four_dim_growth=fl(4 ** (1 / 3)))


def IB():
    """Three-dimensional interacting refinement: state, first and second source variations converge at rate a^2."""
    C = _interacting_runs(); ref, _ = C['ref']; ref16 = C['ref16'][0]; wrong = C['wrong'][0]
    pair = lambda F, G, st, i: _enorm(F[i] - _sub(G[i], st), F[i + 1] - _sub(G[i + 1], st))
    rows = []
    for N in (8, 16, 32):
        F, work = C[N]; st = 32 // N; q0, p0 = _init3(N)
        rows.append(dict(N=N, state=pair(F, ref, st, 0), first=pair(F, ref, st, 2), second=pair(F, ref, st, 4),
                         work=abs(_energy3(F[0], F[1]) - _energy3(q0, p0) - work)))
    ratios = {k: [rows[i][k] / rows[i + 1][k] for i in range(2)] for k in ('state', 'first', 'second')}
    # reference self-consistency: the spectral reference at N = 16 and N = 32 agree far below the lattice errors
    selfc = max(pair(ref16, ref, 2, i) for i in (0, 2, 4))
    # the interaction is resolved: size of its effect on the continuum state, against the finest lattice error
    effect = _enorm(ref[0] - wrong[0], ref[1] - wrong[1])
    # the variation fields are the derivatives of the state with respect to the source amplitude (N = 8, central differences)
    h = 0.05; Fp, Fm, F0 = _run3(8, src=I_SRC + h)[0], _run3(8, src=I_SRC - h)[0], C[8][0]
    fd1 = _enorm((Fp[0] - Fm[0]) / (2 * h) - F0[2], (Fp[1] - Fm[1]) / (2 * h) - F0[3]) / _enorm(F0[2], F0[3])
    fd2 = _enorm((Fp[0] - 2 * F0[0] + Fm[0]) / h ** 2 - F0[4], (Fp[1] - 2 * F0[1] + Fm[1]) / h ** 2 - F0[5]) / _enorm(F0[4], F0[5])
    # canary: against the wrong continuum law (interaction removed) the error does not decrease under refinement
    bad = [pair(C[N][0], wrong, 32 // N, 0) for N in (8, 16, 32)]
    bad_ratio = bad[1] / bad[2]
    ok = all(3.4 < r[0] < 4.4 and 3.8 < r[1] < 4.2 for r in ratios.values()) and max(r['work'] for r in rows) < 1e-6 \
        and selfc < 1e-3 * rows[2]['state'] and effect > 3 * rows[2]['state'] and fd1 < 1e-3 and fd2 < 1e-2 and bad_ratio < 1.3
    must(ok, 'IB')
    R['IB'] = dict(claim='Interacting refinement in three space dimensions. The cubic lattice field (lambda = 3, amplitude of order '
                         'two) on the 3-torus, with smooth well-prepared data and a smooth additive source, converges to the '
                         'continuum solution in the discrete energy norm at rate a^2; so do its first and second variations with '
                         'respect to the source. The energy/work balance holds to integrator tolerance; the variation fields equal '
                         'finite differences in the source amplitude; the spectral reference is self-consistent far below the '
                         'lattice errors. The proof is the energy argument with the uniform L^6 bound; the observed factors of four '
                         'are a check, not the proof. Canary: against the wrong continuum law (interaction removed) the error stalls '
                         'at the size of the interaction effect.',
                   status='PROVED in a restricted class (energy method) + numerical check',
                   rows=[{k: (v if k == 'N' else fl(v)) for k, v in r.items()} for r in rows],
                   ratios={k: [fl(x) for x in v] for k, v in ratios.items()}, reference_self_consistency=fl(selfc),
                   interaction_effect=fl(effect), first_variation_fd_err=fl(fd1), second_variation_fd_err=fl(fd2),
                   wrong_law_errors=[fl(b) for b in bad], wrong_law_ratio=fl(bad_ratio))


def IC():
    """Predictor and upper bound: first lattice correction a^2 E_1; cubic-anisotropic dispersion; bound on the spacing."""
    import math
    C = _interacting_runs(); ref, _ = C['ref']
    rows = []
    for N in (8, 16, 32):
        F, _ = C[N]; st = 32 // N; a = 1.0 / N
        dq, dp = F[0] - _sub(ref[0], st), F[1] - _sub(ref[1], st)
        pq, pp = a * a * _sub(ref[6], st), a * a * _sub(ref[7], st)
        rows.append(dict(N=N, error=_enorm(dq, dp), predicted=_enorm(pq, pp), residual=_enorm(dq - pq, dp - pp)))
    rel = [r['residual'] / r['error'] for r in rows]
    bound_ok = all(r['error'] <= 1.1 * r['predicted'] for r in rows)
    # dispersion of the nearest-neighbour stencil: omega^2 = m^2 + kappa k^2 - (kappa a^2 / 12) sum k_i^4 + O(a^4)
    a = 1 / 256; kk = 2 * np.pi * 3
    aniso, improved = {}, {}
    for name, n in (('100', (1, 0, 0)), ('110', (1, 1, 0)), ('111', (1, 1, 1))):
        nv = np.array(n, float) / np.linalg.norm(n); k = kk * nv
        om2 = I_M2 + 4 * I_KAP / a ** 2 * np.sum(np.sin(k * a / 2) ** 2)
        aniso[name] = (float((I_M2 + I_KAP * kk ** 2 - om2) / (I_KAP * a ** 2 * kk ** 4 / 12)), float(np.sum(nv ** 4)))
        # boundary canary: the next-neighbour improved stencil (-1/12, 4/3, -5/2, 4/3, -1/12) has no a^2 term
        om2i = I_M2 + I_KAP / a ** 2 * np.sum(2.5 - (8 / 3) * np.cos(k * a) + (1 / 6) * np.cos(2 * k * a))
        improved[name] = float((I_M2 + I_KAP * kk ** 2 - om2i) / (I_KAP * a ** 2 * kk ** 4 / 12))
    an_err = max(abs(c_ - s_) for c_, s_ in aniso.values())
    iso_gap = abs(aniso['111'][0] - 1.0)
    # data: quadratic dispersion bound E^2 = p^2 [1 - (E / E_QG2)^2] with E_QG2 > 6e-8 E_Planck (LHAASO, GRB 221009A, 95% CL)
    # matches a^2 s / 12 = 1 / E_QG2^2, s = sum n_i^4 in [1/3, 1]; the orientation is unknown, so the weakest factor is used
    eqg2 = 6e-8
    a_max = {name: math.sqrt(12 / s_) / eqg2 for name, (_, s_) in aniso.items()}
    a_bound_planck = max(a_max.values()); a_bound_m = a_bound_planck * L_PLANCK_M
    ok = rel[0] > rel[1] > rel[2] and rel[0] / rel[1] > 3.0 and rel[1] / rel[2] > 3.0 and rel[2] < 0.03 and bound_ok and an_err < 5e-4 \
        and iso_gap > 0.6 and max(abs(v) for v in improved.values()) < 5e-3 and 9e7 < a_bound_planck < 1.1e8
    must(ok, 'IC')
    R['IC'] = dict(claim='Predictor and upper bound. The lattice field equals the continuum field plus a^2 E_1 plus a remainder of '
                         'order a^4, where E_1 solves the linearized continuum equation forced by (kappa/12) sum_i d_i^4 u. The '
                         'predicted field accounts for the error up to a relative residual falling by about four per halving, and '
                         'the error is bounded by 1.1 a^2 ||E_1|| on every grid. The first correction is not rotation invariant: '
                         'omega^2 = m^2 + kappa k^2 - (kappa a^2/12) sum_i k_i^4, direction factor sum n_i^4 = 1, 1/2, 1/3 along '
                         '(100), (110), (111): a quadratic, subluminal, cubic-anisotropic violation of Lorentz invariance. With the '
                         'measured bound E_QG2 > 6e-8 E_Planck this limits the spacing of a nearest-neighbour cubic realization of '
                         'the photon band to a < 1.0e8 Planck lengths (1.6e-27 m), for the least favourable orientation. Canaries: '
                         'an isotropic coefficient is wrong by a factor of three along (111); the improved stencil has no a^2 '
                         'term, so the bound is specific to the realization.',
                   status='PROVED (asymptotic error expansion) + IDENTIFIED (Symanzik) + MEASURED input',
                   rows=[{k: (v if k == 'N' else fl(v)) for k, v in r.items()} for r in rows], relative_residual=[fl(r) for r in rel],
                   anisotropy={k: [fl(v[0]), fl(v[1])] for k, v in aniso.items()}, isotropic_guess_gap=fl(iso_gap),
                   improved_stencil_a2_coefficient={k: fl(v) for k, v in improved.items()},
                   spacing_bound_planck_lengths={k: fl(v) for k, v in a_max.items()}, spacing_bound_m=fl(a_bound_m))


def ID():
    """Obstructions in three dimensions: hidden Nyquist defect; laminate anisotropy; no full-sequence limit."""
    from scipy.integrate import solve_ivp
    # (a) alternating field (-1)^(i+j+k): exact invariant subspace of the full cubic dynamics, invisible to low linear records
    N, A = 8, 0.5; a = 1.0 / N
    ii = np.indices((N, N, N)).sum(axis=0); sgn = (-1.0) ** ii
    q0 = a * A * sgn
    def rhs(t, Y):
        q, p = Y[:N ** 3].reshape(N, N, N), Y[N ** 3:].reshape(N, N, N)
        return np.concatenate([p.ravel(), (I_KAP * _lap3(q) - I_M2 * q - I_LAM * q ** 3).ravel()])
    sol = solve_ivp(rhs, (0, 0.05), np.concatenate([q0.ravel(), np.zeros(N ** 3)]), method='DOP853', rtol=1e-11, atol=1e-13)
    qT = sol.y[:N ** 3, -1].reshape(N, N, N)
    pattern = float(np.max(np.abs(qT - sgn * np.mean(qT * sgn))))
    ft = np.fft.fftn(qT) / N ** 3; ft[N // 2, N // 2, N // 2] = 0
    low = float(np.max(np.abs(ft)))
    energies = {}
    for Nn in (8, 16, 32, 64):
        an = 1.0 / Nn; sg = (-1.0) ** np.indices((Nn, Nn, Nn)).sum(axis=0)
        energies[Nn] = _energy3(an * A * sg, np.zeros((Nn, Nn, Nn)))
    sup_q = a * A
    # (b) laminate: bond stiffness alternates 1/2, 3/2 across z; cell problem by direct solve; effective tensor diag(1, 1, 3/4)
    n = 4; kz = np.array([0.5, 1.5] * (n // 2)); dirs = ((1, 0, 0), (0, 1, 0), (0, 0, 1))
    idx = lambda i, j, k: ((i % n) * n + (j % n)) * n + (k % n)
    bonds = [(idx(i, j, k), idx(i + d_[0], j + d_[1], k + d_[2]), ax, kz[k])
             for i in range(n) for j in range(n) for k in range(n) for ax, d_ in enumerate(dirs)]
    def eff(xi):
        M = n ** 3; H = np.zeros((M, M)); b = np.zeros(M)
        for s0, s1, ax, kap in bonds:
            H[s0, s0] += kap; H[s1, s1] += kap; H[s0, s1] -= kap; H[s1, s0] -= kap
            b[s0] += kap * xi[ax]; b[s1] -= kap * xi[ax]
        u = np.linalg.lstsq(H, b, rcond=None)[0]
        return sum(kap * (u[s1] - u[s0] + xi[ax]) ** 2 for s0, s1, ax, kap in bonds) / n ** 3
    Kx, Ky, Kz = eff((1, 0, 0)), eff((0, 1, 0)), eff((0, 0, 1))
    arith = float(np.mean(kz))
    # Bloch check: the long-wave speed across the layers is set by the harmonic mean
    kq = 1e-3; k1_, k2_ = 0.5, 1.5
    Dm = np.array([[k1_ + k2_, -(k1_ + k2_ * np.exp(-2j * kq))], [-(k1_ + k2_ * np.exp(2j * kq)), k1_ + k2_]])
    c2 = float(np.min(np.linalg.eigvalsh(Dm))) / kq ** 2
    # (c) a refinement that alternates the two microstructures has two response limits (no full-sequence limit)
    seq = [1.0 if j % 2 == 0 else Kz for j in range(8)]
    ok = pattern < 1e-10 and low < 1e-12 and abs(energies[64] - 1.5) < 1e-3 and sup_q < 0.07 and abs(Kx - 1) < 1e-9 and abs(Ky - 1) < 1e-9 \
        and abs(Kz - 0.75) < 1e-9 and abs(arith - 1) < 1e-12 and abs(c2 - 0.75) < 1e-4 and abs(seq[-1] - seq[-2]) > 0.2
    must(ok, 'ID')
    R['ID'] = dict(claim='Obstructions persist in three dimensions, so the restricted class cannot be dropped. (a) The alternating field '
                         'a A (-1)^(i+j+k) spans an exact invariant subspace of the cubic dynamics: every retained low Fourier record '
                         'is zero for all times and the field tends to zero uniformly, yet the exchange energy tends to 6 kappa A^2. '
                         '(b) A laminate with bond stiffness 1/2, 3/2 across layers has arithmetic mean 1 in every direction and '
                         'effective tensor diag(1, 1, 3/4): the limit cone is anisotropic, with speed^2 = 3/4 across the layers '
                         '(Bloch check). Isotropy of the limit is matching data. (c) Alternating the two microstructures along the '
                         'refinement gives two response limits. These are defect measures and homogenization, identified.',
                   status='PROVED (exact constructions) + IDENTIFIED (H-measures; H-convergence)', pattern_defect=fl(pattern),
                   low_record_max=fl(low), defect_energy_by_N={str(k): fl(v) for k, v in energies.items()}, field_sup=fl(sup_q),
                   effective_tensor=[fl(Kx), fl(Ky), fl(Kz)], arithmetic_mean=fl(arith), bloch_speed2_across=fl(c2),
                   response_sequence=[fl(s_) for s_ in seq])


def IE():
    """Quantum scalar sector: the vacuum is not well prepared; interaction-resolution bound with the measured Higgs coupling."""
    import math
    from scipy.integrate import solve_ivp
    # (a) zero-point population of the free lattice field on the unit 3-torus: <q^2> ~ a^-2, energy density ~ a^-4
    zp = {}
    for N in (16, 32, 64, 128):
        s2 = np.sin(np.pi * np.arange(N) / N) ** 2
        om = np.sqrt(I_M2 + 4 * I_KAP * N * N * (s2[:, None, None] + s2[None, :, None] + s2[None, None, :]))
        zp[N] = (float(np.sum(1 / (2 * om))), float(np.sum(om / 2)))
    r_q2 = zp[128][0] / zp[64][0]; r_en = zp[128][1] / zp[64][1]
    hartree = [3 * I_LAM * zp[N][0] for N in (16, 32, 64, 128)]
    # (b) one-loop running of the quartic coupling, V = lambda (H^dag H)^2, scalar sector only: d lambda / d ln mu = b lambda^2
    b = 3 / (2 * math.pi ** 2); L = 30.0
    vals = {}
    for lam_uv in (0.1, 1.0, 10.0, 1e3):
        sol = solve_ivp(lambda t, y: b * y * y, (0, -L), [lam_uv], rtol=1e-10, atol=1e-14)
        vals[lam_uv] = float(sol.y[0, -1])
    bound = 1 / (b * L)
    closed = max(abs(vals[u] - 1 / (1 / u + b * L)) for u in vals)
    mH, v = 125.20, 246.22
    lam_H = mH ** 2 / (2 * v ** 2)
    log10_cut = (math.log(mH) + 1 / (b * lam_H)) / math.log(10)
    m = 150.0
    for _ in range(50):
        m = v * math.sqrt(2 / (b * math.log(E_PLANCK_GEV / m)))
    # canary: an asymptotically free coupling (b < 0) has no such bound: any infrared value is reachable for every cutoff
    target = 0.5
    uv_needed = [1 / (1 / target + b * Lx) for Lx in (10.0, 100.0, 1000.0)]
    ok = abs(r_q2 - 4) < 0.05 and abs(r_en - 16) < 0.05 and hartree[-1] > 1e4 \
        and all(vals[u] <= bound * (1 + 1e-9) for u in vals) and vals[1e3] > 0.99 * bound and closed < 1e-8 \
        and lam_H < 1 / (b * math.log(E_PLANCK_GEV / mH)) and 23 < log10_cut < 25 and 135 < m < 150 and all(0 < u < target for u in uv_needed)
    must(ok, 'IE')
    R['IE'] = dict(claim='Quantum scalar sector. (a) The vacuum is not well prepared: zero-point motion populates every lattice mode, '
                         '<q^2> grows like a^-2 and the energy density like a^-4, so the uniform energy bound of the classical '
                         'theorem fails for every quantum state and the leading mass shift 3 lambda <q^2> diverges. (b) After '
                         'renormalization the coupling seen at scale mu from a theory with cutoff Lambda obeys '
                         'lambda(mu) <= 1/(b ln(Lambda/mu)) for every bare coupling (one loop, b = 3/(2 pi^2), scalar sector only): '
                         'removing the cutoff removes the interaction. The rigorous statement for the one-component lattice field is '
                         'the triviality theorem (Aizenman, Duminil-Copin), imported. Data: m_H = 125.20(11) GeV and v = 246.22 GeV '
                         'give lambda = 0.1293, below the scalar-only bound for a Planck-scale cutoff (0.168, m_H < 143 GeV); the '
                         'scalar sector alone admits resolution up to 10^24 GeV. Canary: an asymptotically free sign has no bound, '
                         'so gauge sectors are not closed by this argument.',
                   status='IMPORTED (triviality theorem) + one-loop predictor + MEASURED input',
                   zero_point_q2_by_N={str(k): fl(v_[0]) for k, v_ in zp.items()}, q2_ratio_per_halving=fl(r_q2),
                   energy_ratio_per_halving=fl(r_en), hartree_mass_shift_by_N=[fl(h_) for h_ in hartree],
                   ir_coupling_by_uv={str(k): fl(v_) for k, v_ in vals.items()}, bound=fl(bound), closed_form_err=fl(closed),
                   higgs_lambda=fl(lam_H), planck_bound_lambda=fl(1 / (b * math.log(E_PLANCK_GEV / mH))),
                   log10_max_cutoff_GeV=fl(log10_cut), mH_max_for_planck_cutoff=fl(m),
                   asymptotically_free_uv_couplings=[fl(u) for u in uv_needed])

if __name__ == '__main__':
    for f in [QA, QB, QC, LA, LB, LC, LD, LE, SA, SB, EA, EB, EC, ED, FA, CA, UA, UB, UC, PA, PB, HA, HB, KA, KB, IA, IB, IC, ID, IE]:
        f(); print(f.__name__, flush=True)
    R['source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    R['helper_sha256'] = hashlib.sha256((HERE / 'rg_curv.py').read_bytes()).hexdigest()
    R['seed'] = SEED
    R['failures'] = FAILS
    (HERE / 'rg_quantum_gravity_results.json').write_text(json.dumps(R, indent=1, sort_keys=True, default=str) + '\n')
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
