"""RG Quantum Gravity battery, second edition (print: 'RG - Quantum Gravity').

Every group carries a canary. Groups:
  QA polytope rigidity            QB composition identity K(ab)-K(a)K(b) = -k(k-2)/4 ab(a-1)(b-1)   QC continuum canary
  LA positive-pullback no-go; Poisson volume calibration      LB walk: exact cone, dispersion series
  LC odd anticommutator outside the cone                      LD free Dirac limit bound T a P |M|; exact dispersion
  LE graded locality: even bilinears commute outside the cone
  SA number-current operator balance (not stress)            SB internal holonomy is not curvature (narrow obstruction)
  EA Newton normalization   EB on-shell invariants (Riem^2, Riem^3)   EC one-loop magnitudes   ED anomaly arithmetic
  FA conserved improvement; equal means, unequal fluctuations; truncation defect
  CA relational observable toy      UA TV and KL discrimination bounds, illustrative scales (resource-relative)
  UB classical horizon      UC exact toy propagator versus EFT expansion
  PA entangling phase invariant, negativity; LOCC canary     PB reversible joint, irreversible reduced (correction)
  HA universal action quantum from exchange balance          HB thermal radiation in n space dimensions; Wien roots;
                                                              mode counting; synthetic dimension-shape test

Run: python rg_quantum_gravity.py (numpy, scipy, sympy; rg_curv.py alongside). Seed 20261110. Deterministic.
"""
import hashlib, itertools, json, sys
from pathlib import Path
import numpy as np
import sympy as s
from scipy.linalg import expm
from scipy.special import jv

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rg_curv import curvature, invariants  # noqa: E402

SEED = 20261110
rng = np.random.default_rng(SEED)
R, FAILS = {}, []


def must(c, tag):
    if not c:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.12g}')


# =============================================================================================  Q-gate
def QA():
    def affine_group(V):
        n, dim = V.shape
        Vh = np.c_[V, np.ones(n)]
        count = 0
        for perm in itertools.permutations(range(n)):
            W = V[list(perm)]
            M, *_ = np.linalg.lstsq(Vh, W, rcond=None)
            if np.max(np.abs(Vh @ M - W)) < 1e-9:
                count += 1
        return count
    shapes = {
        'simplex_3': np.eye(3)[:, :2] * 0 + np.array([[0, 0], [1, 0], [0, 1]]),
        'simplex_4': np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]], float),
        'square_gbit': np.array([[1, 1], [1, -1], [-1, -1], [-1, 1]], float),
        'hexagon': np.array([[np.cos(a), np.sin(a)] for a in np.arange(6) * np.pi / 3]),
    }
    groups = {k: affine_group(v) for k, v in shapes.items()}
    # a continuous path g(t) of symmetries with g(0) = id fixes every vertex (vertices are isolated); affinely spanning
    # vertices then force g(t) = id: the Lie algebra of fixers is the nullspace of the map A -> (A v_i) for all i
    lie = {}
    for k, V in shapes.items():
        n, dim = V.shape
        Vh = np.c_[V, np.ones(n)]
        lie[k] = int(Vh.shape[1] * dim - np.linalg.matrix_rank(np.kron(np.eye(dim), Vh)))
    # Bloch ball: exp(-i H t) moves |0> continuously to |1>
    X = np.array([[0, 1], [1, 0]], complex)
    path = [abs(np.vdot(np.array([0, 1]), expm(-1j * X * t) @ np.array([1, 0]))) ** 2 for t in np.linspace(0, np.pi / 2, 11)]
    ok = groups == {'simplex_3': 6, 'simplex_4': 24, 'square_gbit': 8, 'hexagon': 12} and all(v == 0 for v in lie.values()) \
        and abs(path[-1] - 1) < 1e-12 and np.all(np.diff(path) > 0)
    must(ok, 'QA')
    R['QA'] = dict(claim='A polytope state space (classical simplex, gbit square, hexagon) has a finite affine symmetry group '
                         '(6, 24, 8, 12 elements) and a zero-dimensional Lie algebra of vertex fixers: continuous reversible '
                         'dynamics acts trivially on its pure states. The Bloch ball admits transitive continuous rotations '
                         '(|0> -> |1> continuously)', status='CONSTRUCTED (exact)', group_orders=groups, lie_dimension=lie,
                   transition_path=[fl(v) for v in path[::5]])


def QB():
    K = lambda k, d: d + k * d * (d - 1) // 2
    alld = {k: all(K(k, a * b) == K(k, a) * K(k, b) for a in range(2, 8) for b in range(2, 8)) for k in [0, 1, 2, 4, 8]}
    kk = s.Symbol('k')
    roots = sorted(int(r) for r in s.solve(4 + 6 * kk - (2 + kk) ** 2, kk))
    a_, b_ = s.symbols('a b', positive=True)
    Ks = lambda d: d + kk * d * (d - 1) / 2
    fact = s.simplify(Ks(a_ * b_) - Ks(a_) * Ks(b_) + kk * (kk - 2) / 4 * a_ * b_ * (a_ - 1) * (b_ - 1))
    must(fact == 0 and roots == [0, 2] and alld[0] and alld[2] and not alld[1] and not alld[4], 'QB')
    R['QB'] = dict(claim='Local tomography with same-type composites: a rank-4 composite of two rank-2 cones has 4 + 6k parameters, '
                         'the product needs (2 + k)^2, so k in {0, 2}. In all dimensions d_A, d_B <= 7, K_AB = K_A K_B holds for '
                         'k = 0 (classical) and k = 2 (complex) only; exactly, K_k(ab) - K_k(a)K_k(b) = -k(k-2)/4 ab(a-1)(b-1) in all ranks. '
                         'Composition alone leaves classical alive; arbitrary convex theories and exceptional Jordan systems are not classified',
                   status='PROVED (exact symbolic factorization)', factorization_residual=str(fact), roots=roots, all_dimensions=alld)


def QC():
    caps = {}
    for Nst in [2, 8, 64, 1024]:
        pts = np.exp(2j * np.pi * np.arange(Nst) / Nst)
        caps[str(Nst)] = int(len(set(np.round(pts, 12))))      # point masses on a circle: all perfectly distinguishable
    rot = lambda z, t: z * np.exp(1j * t)
    moved = abs(rot(1 + 0j, np.pi) - (-1))
    must(all(int(k) == v for k, v in caps.items()) and moved < 1e-15, 'QC')
    R['QC'] = dict(claim='Canary for the scope of QA: a classical continuum (circle phase space) supports continuous reversible transitive '
                         'dynamics on point masses and has unbounded capacity (2, 8, 64, 1024 perfectly distinguishable states and beyond). '
                         'Finite capacity and finite dimension are separate assumptions: polytope rigidity applies to finite-dimensional '
                         'polytopes only', 
                   status='CONSTRUCTED', capacities=caps)


# =============================================================================================  L-gate
def LA():
    worst = np.inf
    for _ in range(200):
        n, m = 4, int(rng.integers(2, 6))
        A = rng.normal(size=(n, n)); G = A @ A.T + 1e-3 * np.eye(n)
        J = rng.normal(size=(n, m))
        worst = min(worst, np.linalg.eigvalsh(J.T @ G @ J).min())
    # order + number (1+1 Minkowski, Poisson sprinkling in light-cone coordinates)
    rho = 4000.0
    res = {}
    for Om in [1.0, 2.0]:
        est = []
        for _ in range(20):
            N = rng.poisson(rho * Om ** 2 * 1.0 * 1.0 / 2)      # diamond u,v in [0,1]: volume 1/2 in (t,x)
            est.append(np.sqrt(2 * N / rho))                     # proper time of the diamond, recovered from the count
        res[str(Om)] = dict(tau_from_count=fl(np.mean(est)), tau_true=fl(Om * 1.0), rel_err=fl(abs(np.mean(est) - Om) / Om))
    ok = worst >= -1e-12 and all(v['rel_err'] < 0.01 for v in res.values())
    must(ok, 'LA')
    R['LA'] = dict(claim='No-go: J^T G J is positive semidefinite for every positive G and real J, so no distinguishability metric '
                         '(Fisher, SLD, Bures) pulls back to a Lorentzian one. Signature must come from order (reachability), which '
                         'fixes the conformal class (HKMM, Malament); order is blind to a constant conformal factor Omega, while the '
                         'count of sprinkled records recovers tau = Omega (order + number = geometry)',
                   status='PROVED (algebra) + EXECUTED (seeded sprinkling) + imported', min_pullback_eigenvalue=fl(worst),
                   sprinkling=res)


def dirac_qca_step(psi, m):
    n = np.sqrt(1 - m * m)
    R_, L_ = psi[0], psi[1]
    Rc = n * R_ - 1j * m * L_
    Lc = -1j * m * R_ + n * L_
    return np.array([np.roll(Rc, 1), np.roll(Lc, -1)])


def LB():
    Nx, T, m = 201, 60, 0.3
    psi = np.zeros((2, Nx), complex); c0 = Nx // 2; psi[0, c0] = 1 / np.sqrt(2); psi[1, c0] = 1j / np.sqrt(2)
    outside = 0.0
    for t in range(1, T + 1):
        psi = dirac_qca_step(psi, m)
        mask = np.abs(np.arange(Nx) - c0) > t
        outside = max(outside, float(np.max(np.abs(psi[:, mask]))))
    norm = float(np.sum(np.abs(psi) ** 2))
    ks = np.linspace(-np.pi, np.pi, 4001)
    vg = {}
    for mm in [0.0, 0.3, 0.8]:
        n = np.sqrt(1 - mm * mm)
        w = np.arccos(n * np.cos(ks))
        vg[str(mm)] = fl(np.max(np.abs(np.gradient(w, ks))))
    k, mu = s.symbols('k mu', positive=True)
    nn = s.sqrt(1 - mu ** 2)
    w0 = s.acos(s.cos(k))
    w2 = s.series(s.acos(nn * s.cos(k)) ** 2, k, 0, 6).removeO()
    m_eff2 = s.simplify(w2.coeff(k, 0)); v2 = s.simplify(w2.coeff(k, 2)); c4 = s.simplify(w2.coeff(k, 4))
    small = {'m_eff^2_minus_mu^2_order': str(s.series(m_eff2 - mu ** 2, mu, 0, 5).removeO()),
             'v^2_minus_1_order': str(s.series(v2 - 1, mu, 0, 3).removeO()), 'k4_coefficient_at_mu0': str(s.limit(c4, mu, 0))}
    ok = outside == 0.0 and abs(norm - 1) < 1e-12 and all(v <= 1 + 1e-6 for v in vg.values()) \
        and s.simplify(w0.subs(k, s.Rational(1, 3)) - s.Rational(1, 3)) == 0
    must(ok, 'LB')
    R['LB'] = dict(claim='Construction: the 1-D Dirac quantum cellular automaton (coin [[n, -i m], [-i m, n]], shift) is local and '
                         'unitary; after t steps the amplitude outside |x - x0| <= t is exactly 0 (strict cone, not a Bessel tail), '
                         'max |d omega/dk| <= 1 for all k, the massless branch omega = |k| is exactly linear, and the massive branch '
                         'obeys omega^2 = m_eff^2 + v^2 k^2 + O(k^4): Dirac at small k with quadratic (not linear) deviation',
                   status='CONSTRUCTED (exact)', max_amplitude_outside_cone=outside, norm=fl(norm), max_group_velocity=vg,
                   series=small)


def LC():
    Nx, T, m = 121, 30, 0.4
    c0 = Nx // 2
    # single-particle propagator columns from site c0 (both components); anticommutator {a_x(t), a_y^dag} = U^t(x, y)
    maxout = 0.0
    for comp in [0, 1]:
        psi = np.zeros((2, Nx), complex); psi[comp, c0] = 1
        for t in range(T):
            psi = dirac_qca_step(psi, m)
        mask = np.abs(np.arange(Nx) - c0) > T
        maxout = max(maxout, float(np.max(np.abs(psi[:, mask]))))
    # continuous-time contrast: nearest-neighbour hopping has nonzero amplitude at every distance
    cont = fl(abs(jv(2 * 40, 2 * 10.0)))
    must(maxout == 0.0 and cont > 0, 'LC')
    R['LC'] = dict(claim='Microcausality: for the QCA field a_x(t) = sum_y U^t(x,y) a_y, the anticommutator {a_x(t), a_y^dag} = U^t(x,y) '
                         'vanishes exactly for |x - y| > t, so the net of local algebras satisfies Haag-Kastler locality exactly. '
                         'Continuous-time hopping leaks at every distance (J_80(20) = %.2e)' % cont,
                   status='CONSTRUCTED (exact)', max_anticommutator_outside=maxout, continuous_time_leak=cont)


# =============================================================================================  S-gate
def SA():
    Nx, T, m = 81, 25, 0.5
    psi = (rng.normal(size=(2, Nx)) + 1j * rng.normal(size=(2, Nx))) * np.exp(-((np.arange(Nx) - 40) / 6.0) ** 2)
    psi /= np.sqrt(np.sum(np.abs(psi) ** 2))
    worst = 0.0
    n = np.sqrt(1 - m * m)
    for _ in range(T):
        Rc = n * psi[0] - 1j * m * psi[1]; Lc = -1j * m * psi[0] + n * psi[1]
        rho_before = np.abs(psi[0]) ** 2 + np.abs(psi[1]) ** 2
        new = np.array([np.roll(Rc, 1), np.roll(Lc, -1)])
        rho_after = np.abs(new[0]) ** 2 + np.abs(new[1]) ** 2
        J = np.abs(Rc) ** 2 - np.abs(np.roll(Lc, -1)) ** 2          # flux across bond x + 1/2 (right movers out, left movers in)
        div = J - np.roll(J, 1)
        worst = max(worst, float(np.max(np.abs(rho_after - rho_before + div))))
        psi = new
    must(worst < 1e-15, 'SA')
    R['SA'] = dict(claim='Number-current balance: the walk obeys the exact discrete continuity equation rho(t+1) - rho(t) = -(J_{x+1/2} - '
                         'J_{x-1/2}) with J = |R_x\'|^2 - |L_{x+1}\'|^2; since the update is one-particle, the second-quantized number '
                         'current obeys the same operator identity. This is a probability-current law, not energy-momentum balance',
                   status='CONSTRUCTED (exact)', max_balance_residual=fl(worst))


def SB():
    Nx, m = 41, 0.4
    n = np.sqrt(1 - m * m)
    coin = np.array([[n, -1j * m], [-1j * m, n]])
    I = np.eye(Nx)
    S = np.zeros((2 * Nx, 2 * Nx), complex)
    S[:Nx, :Nx] = np.roll(I, 1, axis=0); S[Nx:, Nx:] = np.roll(I, -1, axis=0)
    U = S @ np.kron(coin, I)
    Tr = np.kron(np.eye(2), np.roll(I, 1, axis=0))
    glob = np.exp(0.7j) * np.eye(2 * Nx)
    loc = np.diag(np.r_[np.exp(1j * 0.1 * np.arange(Nx)), np.exp(1j * 0.1 * np.arange(Nx))])
    c = lambda A, B: float(np.max(np.abs(A @ B - B @ A)))
    res = dict(global_phase_vs_U=c(glob, U), global_phase_vs_translation=c(glob, Tr), U_vs_translation=c(U, Tr),
               local_phase_vs_U=c(loc, U), local_phase_vs_translation=c(loc, Tr))
    ok = res['global_phase_vs_U'] < 1e-14 and res['global_phase_vs_translation'] < 1e-14 and res['U_vs_translation'] < 1e-14 \
        and res['local_phase_vs_U'] > 1e-3 and res['local_phase_vs_translation'] > 1e-3
    must(ok, 'SB')
    R['SB'] = dict(claim='Internal reference transformations (global phase) commute with evolution and translation; a position-dependent '
                         'internal rotation commutes with neither. Narrow obstruction: a nonzero internal cycle phase on a flat background '
                         'coexists with zero Riemann curvature, so internal holonomy does not by itself determine gravity. Coleman-Mandula '
                         'is not invoked: its mass-gap and S-matrix hypotheses are not checked for massless gravity', status='CONSTRUCTED (toy)', commutators={k: fl(v) for k, v in res.items()})


# =============================================================================================  E-gate
def EA():
    G, mA, mB, q, r = s.symbols('G m_A m_B q r', positive=True)
    kappa = s.sqrt(32 * s.pi * G)
    eta = s.diag(-1, 1, 1, 1)
    TA = s.zeros(4); TA[0, 0] = mA; TB = s.zeros(4); TB[0, 0] = mB
    low = lambda T: eta * T * eta
    num = sum(low(TA)[i, j] * TB[i, j] for i in range(4) for j in range(4)) - s.Rational(1, 2) * sum(eta[i, i] * TA[i, i] for i in range(4)) * sum(eta[i, i] * TB[i, i] for i in range(4))
    Vq = -(kappa / 2) ** 2 * num / q ** 2
    Vr = s.simplify(Vq * q ** 2 / (4 * s.pi * r))          # 1/q^2 -> 1/(4 pi r)
    must(s.simplify(Vr + G * mA * mB / r) == 0, 'EA')
    R['EA'] = dict(claim='Tree-level exchange of the selected massless spin-2 field between static sources, with kappa^2 = 32 pi G and the '
                         'D = 4 numerator, gives V = -G m_A m_B / r', status='PROVED (symbolic)', potential=str(Vr))


def EB():
    t, r, th, ph = s.symbols('t r theta phi'); M = s.Symbol('M', positive=True)
    X = [t, r, th, ph]
    f = 1 - 2 * M / r
    g = s.diag(-f, 1 / f, r ** 2, r ** 2 * s.sin(th) ** 2)
    Rs, Ric2, Riem2, Ric, gi, Gam = invariants(g, X)
    _, _, Rm, _, _ = curvature(g, X)
    n = 4
    Rud = [[[[s.simplify(sum(gi[b, e] * Rm[a][e][c][d] for e in range(n))) for d in range(n)] for c in range(n)] for b in range(n)] for a in range(n)]
    I3 = s.simplify(sum(Rud[a][b][c][d] * Rud[c][d][e][f_] * Rud[e][f_][a][b]
                        for a in range(n) for b in range(n) for c in range(n) for d in range(n) for e in range(n) for f_ in range(n)))
    GB = s.simplify(Riem2 - 4 * Ric2 + Rs ** 2)
    ok = Rs == 0 and Ric2 == 0 and s.simplify(Riem2 - 48 * M ** 2 / r ** 6) == 0 and s.simplify(GB - Riem2) == 0 and I3 != 0
    must(ok, 'EB')
    R['EB'] = dict(claim='On shell (Ricci flat) the one-loop pure-gravity counterterms R^2 and R_ab R^ab vanish and Riemann^2 equals the '
                         'Gauss-Bonnet density (topological in 4-D): one loop is finite on shell (t Hooft-Veltman). The two-loop '
                         'counterterm Riemann^3 is nonzero on Schwarzschild, and its coefficient 209/2880 (4 pi)^-4 is nonzero '
                         '(Goroff-Sagnotti, imported): Einstein-only quantum closure fails', status='PROVED (symbolic) + imported',
                   Kretschmann=str(Riem2), Riemann_cubed=str(I3))


def EC():
    G, hbar, c = 6.67430e-11, 1.054571817e-34, 2.99792458e8
    lP2 = G * hbar / c ** 3
    out = {}
    for label, rr, m1, m2 in [('1 m, 1 kg', 1.0, 1.0, 1.0), ('52 um torsion balance', 52e-6, 1e-3, 1e-3), ('Earth surface', 6.371e6, 5.972e24, 1.0)]:
        out[label] = dict(classical_PN=fl(3 * G * (m1 + m2) / (rr * c ** 2)), quantum=fl(41 / (10 * np.pi) * lP2 / rr ** 2))
    must(out['52 um torsion balance']['quantum'] < 1e-50, 'EC')
    R['EC'] = dict(claim='One-loop gravitational EFT correction V = -G m1 m2/r [1 + 3G(m1+m2)/(r c^2) + 41 G hbar/(10 pi r^2 c^3)] '
                         '(Bjerrum-Bohr, Donoghue, Holstein; imported): the quantum term is unique and parameter-free but of '
                         'relative size l_P^2/r^2', status='IMPORTED coefficient + computed magnitudes', relative_corrections=out)


def ED():
    from fractions import Fraction as F
    # one Standard-Model generation as left-handed Weyl fields: (multiplicity = colour x isospin, hypercharge, su3 rep dim, su2 rep dim)
    fields = {'Q': (6, F(1, 6), 3, 2), 'u^c': (3, F(-2, 3), 3, 1), 'd^c': (3, F(1, 3), 3, 1), 'L': (2, F(-1, 2), 1, 2), 'e^c': (1, F(1), 1, 1)}
    def anomalies(fs):
        grav = sum(m * y for m, y, _, _ in fs.values())                       # mixed gravitational: Tr Y
        y3 = sum(m * y ** 3 for m, y, _, _ in fs.values())                    # U(1)_Y^3
        su2 = sum((m // 2) * y for m, y, c, w in fs.values() if w == 2)       # SU(2)^2 U(1): doublets weighted by colour
        su3 = sum((m // 3) * y for m, y, c, w in fs.values() if c == 3)       # SU(3)^2 U(1): triplets weighted by isospin
        return dict(gravitational=str(grav), Y3=str(y3), SU2_Y=str(su2), SU3_Y=str(su3))
    full = anomalies(fields)
    canary = anomalies({k: v for k, v in fields.items() if k != 'e^c'})
    must(all(v == '0' for v in full.values()) and canary['gravitational'] != '0', 'ED')
    R['ED'] = dict(claim='The perturbative EFT requires anomaly-free matter. One Standard-Model generation has Tr Y = 0 (mixed '
                          'gravitational), Tr Y^3 = 0, and vanishing SU(2)^2 U(1) and SU(3)^2 U(1) anomalies, exactly. Removing the '
                          'right-handed electron breaks the gravitational anomaly (canary)', status='PROVED (exact fractions)',
                    anomalies=full, canary_without_e=canary)


# =============================================================================================  C-gate
def CA():
    X = np.array([[0, 1], [1, 0]], complex); Y = np.array([[0, -1j], [1j, 0]]); Z = np.diag([1., -1.]).astype(complex); I = np.eye(2)
    Cn = np.kron(Z, I) + np.kron(I, Z)
    loc = np.kron(X, I)
    rel = np.kron(X, X) + np.kron(Y, Y)
    c = lambda A, B: float(np.linalg.norm(A @ B - B @ A))
    must(c(rel, Cn) < 1e-14 and c(loc, Cn) > 1, 'CA')
    R['CA'] = dict(claim='Observables must commute with the constraint: the relational exchange X X + Y Y commutes with Z1 + Z2, the local X1 '
                         'does not. In closed vacuum GR no local gauge-invariant observables built from finitely many derivatives exist '
                         '(Torre, imported); RG records are coincidences (relational) by construction', status='CONSTRUCTED (toy) + imported',
                   relational_commutator=fl(c(rel, Cn)), local_commutator=fl(c(loc, Cn)))


# =============================================================================================  U-gate
def UA():
    E_Pl = 1.22089e19          # GeV (Planck energy)
    M_red = 2.435e18           # GeV (reduced Planck mass)
    probes = {'torsion balance 52 um': 3.8e-12, 'LHC 13.6 TeV': 1.36e4, 'UHECR 3e20 eV': 3e11}
    out = {}
    for k, E in probes.items():
        eps = (E / E_Pl) ** 2
        out[k] = dict(eps=fl(eps), samples_needed=fl(0.9 / eps))
    As, r_max = 2.1e-9, 0.036
    H = np.pi * np.sqrt(r_max * As / 2) * M_red
    eps_inf = (H / M_red) ** 2
    modes = sum(2 * l + 1 for l in range(2, 2501))
    out['inflation (r < 0.036)'] = dict(H_GeV=fl(H), eps=fl(eps_inf), samples_needed=fl(0.9 / eps_inf), CMB_modes_to_l2500=modes)
    # KL (Pinsker) version: TV(P^N,Q^N) <= sqrt(N kappa / 2); regular families have kappa = O(eps^2), so N >= 2(1-2delta)^2/kappa
    delta = 0.05
    kl = {}
    for e in [1e-3, 1e-6]:
        p0 = 0.5; P = np.array([p0, 1 - p0]); Qd = np.array([p0 + e, 1 - p0 - e])
        kap = float(np.sum(P * np.log(P / Qd)))
        kl[str(e)] = dict(kappa=fl(kap), kappa_over_eps2=fl(kap / e ** 2), N_KL=fl(2 * (1 - 2 * delta) ** 2 / kap), N_TV=fl((1 - 2 * delta) / e))
    # exact product TV for a small example: N eps bound holds and is nontrivial
    from itertools import product as _prod
    pP, pQ, Nn = 0.5, 0.52, 8
    tv = 0.5 * sum(abs(pP ** sum(b) * (1 - pP) ** (Nn - sum(b)) - pQ ** sum(b) * (1 - pQ) ** (Nn - sum(b))) for b in _prod([0, 1], repeat=Nn))
    ok = all(v['samples_needed'] > 1e9 for v in out.values()) and modes < out['inflation (r < 0.036)']['samples_needed'] \
        and all(abs(v['kappa_over_eps2'] - 2.0) < 0.01 for v in kl.values()) and 0 < tv <= Nn * 0.02
    must(ok, 'UA')
    R['UA'] = dict(claim='Finite-resource discrimination: TV(P^N, Q^N) <= N eps, so error <= delta needs N >= (1 - 2 delta)/eps; with a '
                         'relative-entropy bound kappa, N >= 2(1 - 2 delta)^2/kappa and regular families have kappa ~ 2 eps^2 (Bernoulli '
                         'check), i.e. the stronger eps^-2 scaling. Nominal (E/M)^2 suppressions give eps ~ 1e-61, 1e-30, 6e-16, 4e-10. '
                         'These are illustrative scales: converting an EFT suppression into a uniform law bound needs an observable, '
                         'coefficients, noise and control of all protocols. The conclusion is resource-relative, not exact nullity',
                   status='PROVED (inequalities) + illustrative scales', probes=out, kl_scaling=kl, exact_product_TV_N8=fl(tv))


def UB():
    v, r, M = s.symbols('v r M', positive=True)
    drdv_out = (1 - 2 * M / r) / 2
    inside = s.simplify(drdv_out.subs(r, M))
    horizon = s.simplify(drdv_out.subs(r, 2 * M))
    must(inside < 0 and horizon == 0, 'UB')
    R['UB'] = dict(claim='In ingoing Eddington-Finkelstein coordinates outgoing null rays obey dr/dv = (1 - 2M/r)/2, negative inside r = 2M '
                         'and zero on it: interior records never reach exterior protocols. The interior lies in the observation kernel '
                         'of the exterior (classically); its quantum completion is not decided here',
                   status='PROVED (symbolic)', drdv_at_r_M=str(inside))


def UC():
    x, m = s.symbols('x m', positive=True)
    P = 1 / (x * (1 + x / m ** 2))
    pf = s.apart(P, x)
    res0 = s.residue(P, x, 0); res1 = s.residue(P, x, -m ** 2)
    must(res0 == 1 and res1 == -1, 'UC')
    R['UC'] = dict(claim='Exact fourth-order propagator 1/(k^2(1 + k^2/m^2)) = 1/k^2 - 1/(k^2 + m^2): the second pole has negative residue '
                         '(Stelle ghost in R + Weyl^2); renormalizability bought this way costs unitarity. Treated as an EFT '
                         'expansion it introduces no pole within validity', status='PROVED (symbolic)', partial_fractions=str(pf))


# =============================================================================================  P-gate
def negativity(Rm):
    pt = Rm.reshape(2, 2, 2, 2).transpose(0, 3, 2, 1).reshape(4, 4)
    return float((np.sum(np.abs(np.linalg.eigvalsh(pt))) - 1) / 2)


def PA():
    G, hbar = 6.67430e-11, 1.054571817e-34
    m, d, dx, t = 1e-14, 450e-6, 250e-6, 2.5
    xa = [-dx / 2, dx / 2]; xb = [d - dx / 2, d + dx / 2]
    phi = np.array([[G * m * m * t / (hbar * abs(b - a)) for b in xb] for a in xa])
    Theta = phi[0, 0] + phi[1, 1] - phi[0, 1] - phi[1, 0]
    psi = np.array([np.exp(1j * phi[i, j]) for i in range(2) for j in range(2)]) / 2
    rho = np.outer(psi, psi.conj())
    neg = negativity(rho)
    conc = abs(np.sin(Theta / 2))
    # LOCC canary: mixtures of product unitaries on a product input stay separable
    mx = 0.0
    def ru():
        A = rng.normal(size=(2, 2)) + 1j * rng.normal(size=(2, 2)); Q, _ = np.linalg.qr(A); return Q
    plus = np.array([1, 1]) / np.sqrt(2); p0 = np.outer(np.kron(plus, plus), np.kron(plus, plus).conj())
    for _ in range(200):
        out = np.zeros((4, 4), complex)
        for w in rng.dirichlet(np.ones(4)):
            Uab = np.kron(ru(), ru()); out += w * Uab @ p0 @ Uab.conj().T
        mx = max(mx, negativity(out))
    ok = neg > 1e-3 and abs(neg - conc / 2) < 1e-12 and mx < 1e-12
    must(ok, 'PA')
    R['PA'] = dict(claim='Gravitationally induced entanglement with published parameters (m = 1e-14 kg, d = 450 um, dx = 250 um, t = 2.5 s): '
                         'entangling phase Theta = %.3f rad, negativity |sin(Theta/2)|/2 = %.4f. Mixtures of local operations on product '
                         'inputs never entangle (canary): observed entanglement under the stated locality assumptions witnesses a '
                         'non-classical mediator' % (Theta, neg), status='COMPUTED (assumes the quantum Newton interaction)',
                   Theta=fl(Theta), negativity=fl(neg), LOCC_max_negativity=fl(mx))


def PB():
    # canary: a reversible closed evolution induces irreversible reduced dynamics (CNOT on |+>|0>)
    plus = np.array([1, 1]) / np.sqrt(2)
    psi = np.kron(plus, [1, 0])
    CNOT = np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 0, 1], [0, 0, 1, 0]], complex)
    out = CNOT @ psi
    rho = np.outer(out, out.conj())
    red = np.trace(rho.reshape(2, 2, 2, 2), axis1=1, axis2=3)
    def S(Rm):
        e = np.linalg.eigvalsh(Rm); e = e[e > 1e-14]; return float(-np.sum(e * np.log2(e)))
    unitary = float(np.max(np.abs(CNOT.conj().T @ CNOT - np.eye(4))))
    must(unitary < 1e-15 and abs(S(rho)) < 1e-12 and abs(S(red) - 1) < 1e-12, 'PB')
    R['PB'] = dict(claim='Correction of the first edition: continuous reversibility of closed systems does not exclude decoherence of '
                         'subsystems. A CNOT on |+>|0> is unitary, the joint state stays pure (entropy 0), and the reduced state is I/2 '
                         '(1 bit). Classical-quantum hybrids are therefore not excluded by the reversibility premise alone; the '
                         'decoherence-diffusion trade-off (Oppenheim et al.) is a model-dependent empirical test',
                   status='CONSTRUCTED (canary)', joint_entropy=fl(S(rho)), reduced_entropy=fl(S(red)))


def LD():
    # controlled free Dirac limit on a momentum band: ||U_a(p)^N - exp(-i T H_D(p))|| <= T a P |M|
    Z = np.diag([1., -1.]).astype(complex); X = np.array([[0, 1], [1, 0]], complex)
    T, P, M = 1.0, 3.0, 2.0
    rows = []
    for a in [0.1, 0.05, 0.025, 0.0125]:
        Nst = int(round(T / a)); worst = 0.0
        for pp in np.linspace(-P, P, 61):
            Ua = expm(-1j * a * pp * Z) @ expm(-1j * a * M * X)
            err = np.linalg.norm(np.linalg.matrix_power(Ua, Nst) - expm(-1j * T * (pp * Z + M * X)), 2)
            worst = max(worst, err)
        rows.append(dict(a=a, sup_error=fl(worst), bound=fl(T * a * P * M)))
    # exact massive dispersion: omega^2 = alpha^2 + (alpha n / m) k^2 + O(k^4), alpha = arcsin m; group velocity identity
    k, m = s.symbols('k m', positive=True)
    n = s.sqrt(1 - m ** 2)
    w2 = s.series(s.acos(n * s.cos(k)) ** 2, k, 0, 4).removeO()
    alpha = s.asin(m)
    c0 = max(abs(float((w2.coeff(k, 0) - alpha ** 2).subs(m, mv))) for mv in [0.1, 0.3, 0.7, 0.95])
    c2 = s.simplify((w2.coeff(k, 2) - alpha * n / m).subs(m, s.Rational(3, 10)))
    om = s.acos(n * s.cos(k))
    vg2 = s.simplify(s.diff(om, k) ** 2 - n ** 2 * s.sin(k) ** 2 / (1 - n ** 2 * s.cos(k) ** 2))
    ok = all(r['sup_error'] <= r['bound'] * (1 + 1e-9) for r in rows) and c0 < 1e-12 and abs(float(c2)) < 1e-12 \
        and s.simplify(vg2.subs({m: s.Rational(3, 10), k: s.Rational(7, 10)})) == 0
    must(ok, 'LD')
    R['LD'] = dict(claim='Free Dirac limit on a fixed momentum band: sup_|p|<=P ||U_a(p)^N - exp(-i T (pZ + MX))|| <= T a P |M| (checked for '
                         'a = 0.1 ... 0.0125); exact dispersion omega^2 = alpha^2 + (alpha n/m) k^2 + O(k^4) with alpha = arcsin m and '
                         'omega\'^2 = n^2 sin^2 k/(1 - n^2 cos^2 k) <= 1', status='PROVED (Duhamel) + checked', rows=rows)


def LE():
    # graded locality: odd fields anticommute outside the cone; even bilinears commute outside the cone
    Nx, t_, m = 41, 6, 0.4
    n = np.sqrt(1 - m * m)
    coin = np.array([[n, -1j * m], [-1j * m, n]])
    I = np.eye(Nx)
    Sh = np.zeros((2 * Nx, 2 * Nx), complex)
    Sh[:Nx, :Nx] = np.roll(I, 1, axis=0); Sh[Nx:, Nx:] = np.roll(I, -1, axis=0)
    U = Sh @ np.kron(coin, I)
    Ut = np.linalg.matrix_power(U, t_)
    def Pn(x):
        P_ = np.zeros((2 * Nx, 2 * Nx)); P_[x, x] = 1; P_[Nx + x, Nx + x] = 1; return P_
    x0 = 20
    out_even, in_even, out_odd = 0.0, 0.0, 0.0
    for y in range(Nx):
        Mx = Ut.conj().T @ Pn(x0) @ Ut              # one-particle matrix of n_x(t)
        c = np.linalg.norm(Mx @ Pn(y) - Pn(y) @ Mx)
        odd = np.max(np.abs(Ut[np.ix_([y, Nx + y], [x0, Nx + x0])]))
        if abs(y - x0) > t_:
            out_even = max(out_even, c); out_odd = max(out_odd, odd)
        elif abs(y - x0) <= t_ - 1:
            in_even = max(in_even, c)
    must(out_even == 0 and out_odd == 0 and in_even > 1e-3, 'LE')
    R['LE'] = dict(claim='Graded locality: odd fields have {a_x(t), a_y^dag} = U^t(x,y) = 0 for |x-y| > t; even bilinears n_x(t), n_y '
                         'commute exactly outside the cone and not inside. The even net is the commuting observable net; the odd net is '
                         'graded-local; neither is yet a continuum Haag-Kastler theory', status='CONSTRUCTED (exact)',
                   max_even_commutator_outside=fl(out_even), max_odd_outside=fl(out_odd), max_even_commutator_inside=fl(in_even))


def FA():
    # improvement terms are conserved; equal mean sources need not have equal fluctuations; truncation defect
    t, x, y, z = s.symbols('t x y z'); X = [t, x, y, z]
    eta = s.diag(-1, 1, 1, 1); F = s.Function('F')(*X)
    box = sum(eta[i, i] * s.diff(F, X[i], 2) for i in range(4))
    I_ = s.Matrix(4, 4, lambda i, j: eta[i, j] * box - s.diff(F, X[i], X[j]))
    div = [s.simplify(sum(eta[i, i] * s.diff(I_[i, j], X[i]) for i in range(4))) for j in range(4)]
    H = np.diag([0., 1., 2.])
    r1, r2 = np.diag([0., 1., 0.]), np.diag([.5, 0., .5])
    mv = [(float(np.trace(r @ H)), float(np.trace(r @ H @ H) - np.trace(r @ H) ** 2)) for r in (r1, r2)]
    Nl = 6
    a = np.diag(np.sqrt(np.arange(1, Nl)), 1)
    defect = a @ a.T - a.T @ a - np.eye(Nl)
    ok = all(d == 0 for d in div) and mv[0][0] == mv[1][0] and mv[0][1] != mv[1][1] \
        and abs(defect[Nl - 1, Nl - 1] + Nl) < 1e-12 and np.count_nonzero(np.abs(defect) > 1e-12) == 1
    must(ok, 'FA')
    R['FA'] = dict(claim='(eta box - dd)F is identically conserved (an improvement the conservation law cannot fix); states with equal mean '
                         'energy 1 have variances 0 and 1 (mean-source equations drop fluctuations); the truncated oscillator has '
                         '[a_N, a_N^dag] = I - N|N-1><N-1|, a defect of norm N invisible on the lower block',
                   status='PROVED (exact)', means_variances=mv, defect_corner=fl(defect[Nl - 1, Nl - 1]))


def HA():
    # action quantum: universality from exchange balance. Resonant exchange of one quantum between sectors A and B,
    # both at phase frequency w: A loses hbar_A w, B gains hbar_B w.
    w = 2 * np.pi * 1e14
    rows = {}
    for hA, hB in [(1.0, 1.0), (1.0, 1.001), (1.0, 1.01)]:
        Hswap = np.array([[0, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0], [0, 0, 0, 0]], complex)
        U = expm(-1j * Hswap * np.pi / 2)
        psi0 = np.array([0, 0, 1, 0], complex)                  # |1_A 0_B>
        psi = U @ psi0
        pA = abs(psi[2]) ** 2; pB = abs(psi[1]) ** 2
        E0 = hA * w * 1.0
        E1 = hA * w * pA + hB * w * pB
        rows[f'{hA}_{hB}'] = fl((E1 - E0) / E0)
    must(rows['1.0_1.0'] == 0 and rows['1.0_1.01'] > 5 * rows['1.0_1.001'] > 0, 'HA')
    R['HA'] = dict(claim='The action quantum is the action-to-phase anchor of the complex realization, U = exp(-i H t / hbar); the '
                         'reconstruction fixes no value. If two sectors had hbar_A != hbar_B, a resonant exchange of one quantum at '
                         'common phase frequency would change the mechanical energy ledger by (hbar_B - hbar_A) w: relative drift 0, '
                         '1e-3, 1e-2 for ratios 1, 1.001, 1.01. Exchange balance forces one universal hbar, as one relabeling forces '
                         'one G', status='CONSTRUCTED (toy)', relative_energy_drift=rows)


def HB():
    import math
    from scipy.optimize import brentq
    from scipy.integrate import quad
    h, c, kB = 6.62607015e-34, 299792458.0, 1.380649e-23        # exact SI
    S = lambda n: 2 * math.pi ** (n / 2) / math.gamma(n / 2)
    tab = {}
    for n in [2, 3, 4, 5]:
        xnu = brentq(lambda x: x - n * (1 - math.exp(-x)), 0.5, 20)
        xla = brentq(lambda x: x - (n + 2) * (1 - math.exp(-x)), 0.5, 20)
        b = h * c / (xla * kB)
        pol = n - 1                                              # massless vector: D - 2 polarizations
        integral = quad(lambda x: x ** n / math.expm1(x), 0, 200)[0]
        tab[str(n)] = dict(x_nu=fl(xnu), x_lambda=fl(xla), wien_b=fl(b), photon_polarizations=pol,
                           mode_prefactor=fl(pol * S(n)), energy_scaling_exponent=n + 1, integral=fl(integral))
    # lattice mode counting in an n-dimensional box: number of modes with |k| <= K grows like K^n (density ~ nu^(n-1))
    count = {}
    for n in [2, 3, 4]:
        Ks = [20, 40]
        cnt = []
        for K in Ks:
            rng_ = np.arange(-K, K + 1)
            grids = np.meshgrid(*([rng_] * n), indexing='ij')
            r2 = sum(g_ ** 2 for g_ in grids)
            cnt.append(int(np.sum(r2 <= K * K)))
        count[str(n)] = fl(np.log(cnt[1] / cnt[0]) / np.log(2))
    # recover h from a measured Wien constant, and the frequency/wavelength peak mismatch
    b3 = tab['3']['wien_b']
    h_from_b = b3 * tab['3']['x_lambda'] * kB / c
    T = 2400.0
    mismatch = (c / (b3 / T)) / (tab['3']['x_nu'] * kB * T / h)
    # synthetic shape test (labelled synthetic): n = 3 Planck spectrum with 50 ppm-of-peak noise; best n = 4 form fails
    xs = np.linspace(0.5, 12, 200)
    def shape(n, xx, sc):
        return xx ** n / np.expm1(xx / sc)
    data = shape(3, xs, 1.0)
    noise = 50e-6 * data.max() * rng.normal(size=xs.size)
    data = data + noise
    best = {}
    for n in [3, 4]:
        best_r = np.inf
        for sc in np.linspace(0.5, 1.6, 2201):
            f_ = shape(n, xs, sc)
            A = float(f_ @ data / (f_ @ f_))
            r = np.sqrt(np.mean((data - A * f_) ** 2)) / data.max()
            best_r = min(best_r, r)
        best[str(n)] = fl(best_r)
    ok = abs(tab['3']['x_nu'] - 2.821439372) < 1e-8 and abs(tab['3']['x_lambda'] - 4.965114232) < 1e-8 \
        and abs(b3 - 2.897771955e-3) < 1e-12 and abs(tab['3']['mode_prefactor'] - 8 * math.pi) < 1e-9 \
        and abs(h_from_b - h) / h < 1e-9 and abs(count['3'] - 3) < 0.1 and abs(count['2'] - 2) < 0.1 and abs(count['4'] - 4) < 0.1 \
        and best['3'] < 1e-4 and best['4'] > 100 * best['3'] and abs(mismatch - 1.76) < 0.01
    must(ok, 'HB')
    R['HB'] = dict(claim='Thermal radiation of a massless vector in n space dimensions: u(nu,T) = (n-1) S_{n-1} h nu^n / c^n / (e^{h nu/kT} - 1); '
                         'the frequency peak solves x = n(1 - e^{-x}), the wavelength peak x = (n+2)(1 - e^{-x}); total energy ~ T^{n+1}; '
                         'lattice mode counts grow as K^n. For n = 3: prefactor 8 pi, x_nu = 2.821439, x_lambda = 4.965114, '
                         'b = 2.897771955e-3 m K from exact SI constants. The shape is a dimension witness: a synthetic n = 3 spectrum with '
                         '50 ppm-of-peak noise is fit to that level by the n = 3 form and rejected by the best n = 4 form. hbar is not '
                         'derived: a measured b determines h only given c and k_B, and c/lambda_peak is not the frequency peak (factor 1.76)',
                   status='PROVED (exact) + synthetic shape test (labelled)', table=tab, mode_count_exponents=count,
                   h_from_b_rel_err=fl(abs(h_from_b - h) / h), peak_mismatch=fl(mismatch), synthetic_rms_residual_over_peak=best)


if __name__ == '__main__':
    for f in [QA, QB, QC, LA, LB, LC, LD, LE, SA, SB, EA, EB, EC, ED, FA, CA, UA, UB, UC, PA, PB, HA, HB]:
        f(); print(f.__name__, flush=True)
    R['source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    R['helper_sha256'] = hashlib.sha256((HERE / 'rg_curv.py').read_bytes()).hexdigest()
    R['seed'] = SEED
    R['failures'] = FAILS
    (HERE / 'rg_quantum_gravity_results.json').write_text(json.dumps(R, indent=1, sort_keys=True, default=str) + '\n')
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
