#!/usr/bin/env python3
"""Mutation suite for the kernel (KA, KB) and interacting-limit (IA-IE) groups of rg_quantum_gravity.py.

Each mutation changes one line of the battery so that it asserts something false (a wrong phase, a wrong
linearization, an isotropic lattice correction, a 160 GeV scalar, ...). The battery must then report the
targeted group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory;
the shipped files are not modified. About five minutes.

    python3 -I rg_quantum_gravity_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('KA', 'signature phase with the wrong sign',
     "target = (2 * math.pi) ** ((pp + qq) / 2) / math.sqrt(np.prod(np.abs(lam))) * np.exp(1j * math.pi * (pp - qq) / 4)",
     "target = (2 * math.pi) ** ((pp + qq) / 2) / math.sqrt(np.prod(np.abs(lam))) * np.exp(1j * math.pi * (qq - pp) / 4)"),
    ('KA', 'level-shell growth halved', "log_law = 4 * dl * math.log(10)", "log_law = 2 * dl * math.log(10)"),
    ('KB', 'gauge term detuned', "return (0.5 * p2 * np.sum(hh * kk) - ph @ pk +", "return (0.5 * p2 * np.sum(hh * kk) - 0.9 * (ph @ pk) +"),
    ('KB', 'wrong conformal value', "predicted=fl(-0.5 * (D - 1) * (D - 2)),", "predicted=fl(-0.5 * (D - 1) * (D - 3)),"),
    ('IA', 'claim: no wall in four space dimensions', "abs(grow4d - 4 ** (1 / 3)) < 0.02", "abs(grow4d - 1) < 0.02"),
    ('IB', 'wrong linearization of the cubic force', "w, I_KAP * Lp(z) - mm * z + f,", "w, I_KAP * Lp(z) - (I_M2 + lam * q * q) * z + f,"),
    ('IB', 'continuum reference with a different coupling', "_I_CACHE['ref'] = _run3(32, spectral=True, predictor=True)",
     "_I_CACHE['ref'] = _run3(32, spectral=True, predictor=True, lam=2.9)"),
    ('IC', 'predictor coefficient doubled', "out += [ed, I_KAP * Lp(e) - mm * e + I_KAP * d4 / 12]",
     "out += [ed, I_KAP * Lp(e) - mm * e + I_KAP * d4 / 6]"),
    ('IC', 'claim: isotropic lattice correction', "float(np.sum(nv ** 4)))\n        # boundary canary", "1.0)\n        # boundary canary"),
    ('ID', 'claim: arithmetic mean across the layers', "and abs(Kz - 0.75) < 1e-9", "and abs(Kz - 1.0) < 1e-9"),
    ('ID', 'defect alternating along one axis only', "ii = np.indices((N, N, N)).sum(axis=0); sgn = (-1.0) ** ii",
     "ii = np.indices((N, N, N))[0]; sgn = (-1.0) ** ii"),
    ('IE', 'scalar mass 160 GeV', "mH, v = 125.20, 246.22", "mH, v = 160.0, 246.22"),
    ('IE', 'claim: zero-point motion grows like 1/a', "abs(r_q2 - 4) < 0.05", "abs(r_q2 - 2) < 0.05"),
]


def main():
    base = open(os.path.join(HERE, 'rg_quantum_gravity.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            shutil.copy(os.path.join(HERE, 'rg_curv.py'), tmp)
            open(os.path.join(tmp, 'rg_quantum_gravity.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_quantum_gravity.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_quantum_gravity_results.json')))['failures']
            except Exception:
                fails = [group] if run.returncode != 0 else []
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
