Resolution Geometry: Quantum Gravity

Files
- RG_Quantum_Gravity.tex: standalone derivation paper; compile with pdflatex twice.
- rg_quantum_gravity_derivation_checks.py: supplementary finite and symbolic verification.
- rg_quantum_gravity_derivation_checks.json: executed results, seed 20261110.
- RG_Quantum_Gravity_validation.json: source hash and compilation validation.

Run supplementary verification with Python, NumPy, SciPy, and SymPy.
The original curvature helper and finite-model scripts are not required to compile the paper.
The bibliography is embedded in the TeX source.
The conditional theorem, assumptions, obstruction statements, and open questions are integral to the paper.
