#!/usr/bin/env python3
"""Supplementary checks for the derivation paper. Constructed models, not data.
Requires numpy, scipy, sympy. Run directly; writes JSON beside this file.
"""
import json, hashlib
from pathlib import Path
import numpy as np
import sympy as s
from scipy.linalg import expm
from scipy.special import comb
rng=np.random.default_rng(20261110)
checks=[]
def check(name,ok,**evidence): checks.append(dict(name=name,passed=bool(ok),evidence=evidence))
I=np.eye(2,dtype=complex); X=np.array([[0,1],[1,0]],complex); Y=np.array([[0,-1j],[1j,0]],complex); Z=np.diag([1.,-1.])
# All-dimension composition identity.
a,b,k=s.symbols('a b k'); K=lambda d:d+k*d*(d-1)/2
res=s.factor(K(a*b)-K(a)*K(b))
check('all_dimension_composition',s.simplify(res+k*(k-2)*a*b*(a-1)*(b-1)/4)==0,factor=str(res))
# Exact dispersion derivative and group-velocity inequality.
m,q=s.symbols('m q',positive=True); n=s.sqrt(1-m*m)
v2=s.asin(m)*n/m
check('massive_dispersion_coefficient',s.simplify(s.series(v2,m,0,5).removeO()-(1-m*m/3-2*m**4/15))==0,series=str(s.series(v2,m,0,5)))
max_v=0.
for mm in [.01,.3,.8,.99]:
    qq=np.linspace(-np.pi,np.pi,10001); nn=np.sqrt(1-mm*mm)
    vv=nn*np.sin(qq)/np.sqrt(1-nn*nn*np.cos(qq)**2)
    max_v=max(max_v,float(np.max(np.abs(vv))))
check('analytic_group_velocity_canary',max_v<=1+1e-12,max_velocity=max_v,identity='1-v^2=m^2/(1-(1-m^2)cos^2 k)>=0')
# Finite-time Trotter bound on a fixed bandlimited momentum sector.
M=.7; T=1.; errors=[]; ratios=[]
for N in [20,40,80,160]:
    aa=T/N; worst=0.
    for p in np.linspace(-2,2,41):
        U=expm(-1j*aa*p*Z)@expm(-1j*aa*M*X)
        exact=expm(-1j*T*(p*Z+M*X))
        err=float(np.linalg.norm(np.linalg.matrix_power(U,N)-exact,2)); worst=max(worst,err)
    errors.append(worst); ratios.append(worst/(T*aa*2*abs(M)))
check('free_continuum_finite_time_bound',max(ratios)<=1+1e-10 and all(errors[i+1]<errors[i] for i in range(3)),errors=errors,bound_ratios=ratios)
# Current identity as an operator on the one-particle space, not only a state.
N=7; mm=.4; nn=np.sqrt(1-mm*mm); coin=np.array([[nn,-1j*mm],[-1j*mm,nn]])
C=np.kron(coin,np.eye(N)); S=np.zeros((2*N,2*N),complex)
S[:N,:N]=np.roll(np.eye(N),1,axis=0);S[N:,N:]=np.roll(np.eye(N),-1,axis=0);U=S@C
P=lambda i:np.diag(np.eye(2*N)[i])
num=lambda x:P(x)+P(N+x)
flux=lambda x:C.conj().T@(P(x)-P(N+(x+1)%N))@C
residual=max(float(np.max(np.abs(U.conj().T@num(x)@U-num(x)+flux(x)-flux((x-1)%N)))) for x in range(N))
check('discrete_current_operator_identity',residual<1e-12,max_residual=residual)
# CAR locality: odd fields anticommute; disjoint even observables commute.
ann=np.array([[0,1],[0,0]],complex); c0=np.kron(ann,I); c1=np.kron(Z,ann)
anti=c0@c1+c1@c0; oddcomm=c0@c1-c1@c0
n0=c0.conj().T@c0;n1=c1.conj().T@c1
check('graded_and_even_locality',np.linalg.norm(anti)<1e-12 and np.linalg.norm(oddcomm)>1 and np.linalg.norm(n0@n1-n1@n0)<1e-12,odd_commutator=float(np.linalg.norm(oddcomm)),even_commutator=float(np.linalg.norm(n0@n1-n1@n0)))
# Poisson volume estimator consistency and exact conformal scale relation.
d=4; Om=1.7; rho=1000.; V=2.; mean=rho*Om**d*V
samples=rng.poisson(mean,size=5000); Vhat=samples/rho
check('calibrated_volume_scale',abs(float(Vhat.mean())-Om**d*V)<5*np.sqrt(mean/len(samples))/rho,mean_volume=float(Vhat.mean()),true_volume=Om**d*V,relative_standard_deviation=float(np.sqrt(mean)/mean))
# Exact Bernoulli product TV: small nonzero differences are not exact kernels.
p=.4; eps=.01; N=20; js=np.arange(N+1)
P=comb(N,js)*p**js*(1-p)**(N-js);Q=comb(N,js)*(p+eps)**js*(1-p-eps)**(N-js)
tv=float(np.sum(np.abs(P-Q))/2);kl=float(p*np.log(p/(p+eps))+(1-p)*np.log((1-p)/(1-p-eps)))
check('finite_resolution_not_exact_null',0<tv<=N*eps and tv<=np.sqrt(N*kl/2),TV=tv,hybrid_bound=N*eps,Pinsker_bound=float(np.sqrt(N*kl/2)),KL=kl)
# Measurement of one member of a globally reversible system can be irreversible.
plus=np.ones(2)/np.sqrt(2);ket=np.kron(plus,np.array([1.,0.]));CNOT=np.eye(4);CNOT[2:,2:]=X.real
out=CNOT@ket;R=np.outer(out,out.conj());reduced=np.trace(R.reshape(2,2,2,2),axis1=1,axis2=3)
check('global_reversibility_does_not_forbid_reduced_dephasing',np.allclose(CNOT.T@CNOT,np.eye(4)) and np.allclose(reduced,I/2),global_unitary=True,reduced_purity=float(np.trace(reduced@reduced).real))
# Complete familiar SM-generation anomaly counts, with explicit chirality.
from fractions import Fraction as F
fields=[(6,F(1,6)),(3,F(-2,3)),(3,F(1,3)),(2,F(-1,2)),(1,F(1))]
trY=sum(mult*y for mult,y in fields);trY3=sum(mult*y**3 for mult,y in fields)
su3cubic=2-1-1;doublets=3+1
check('SM_additional_anomaly_controls',trY==0 and trY3==0 and su3cubic==0 and doublets%2==0,TrY=str(trY),TrY3=str(trY3),SU3_cubic=su3cubic,SU2_doublets=doublets)
# Conserved improvement and mean-source fluctuations.
eta=s.diag(-1,1,1,1);mom=s.Matrix([2,1,3,0]);mom2=(mom.T*eta*mom)[0]
imp=eta*mom2-mom*mom.T
check('source_improvement_identity',imp*eta*mom==s.zeros(4,1),nonzero=imp!=s.zeros(4))
H=np.diag([0.,1.,2.]);R1=np.diag([0.,1.,0.]);R2=np.diag([.5,0,.5]);means=[float(np.trace(R@H)) for R in [R1,R2]];variances=[float(np.trace(R@H@H)-means[i]**2) for i,R in enumerate([R1,R2])]
check('mean_source_not_complete',means[0]==means[1] and variances[0]!=variances[1],means=means,variances=variances)
# Fixed support graph cycles: rephasing leaves cycle product invariant.
R=np.eye(3,dtype=complex)/3;R[0,1]=R[1,2]=.05;R[2,0]=.05j;R=R+R.conj().T-np.diag(np.diag(R));D=np.diag(np.exp(1j*rng.normal(size=3)));S=D@R@D.conj().T
cycle=lambda A:A[0,1]*A[1,2]*A[2,0]
check('cycle_reference_invariance',abs(cycle(R)-cycle(S))<1e-12,error=float(abs(cycle(R)-cycle(S))))
# Tree operator symbol constraints at arbitrary symbolic momenta.
ks=s.Matrix(s.symbols('k0:4'));xi=s.Matrix(s.symbols('x0:4'));kl=eta*ks;k2=(ks.T*eta*ks)[0]
def E(h):
 v=h*kl;tr=s.trace(eta*h);div=(kl.T*h*kl)[0]
 return k2*h-ks*v.T-v*ks.T+ks*ks.T*tr+eta*(div-k2*tr)
gauge=E(ks*xi.T+xi*ks.T).applyfunc(s.expand)
check('linear_gauge_identity',gauge==s.zeros(4),symbolic_zero=True)
# Gaussian coherence damping threshold for the stated Newton example.
G=6.67430e-11;hb=1.054571817e-34;mass=1e-14;sep=450e-6;split=250e-6;t=2.5
posA=np.array([-split/2,split/2]);posB=sep+posA
phase=G*mass**2*t/hb/np.abs(posA[:,None]-posB[None,:]);v=np.exp(1j*phase).reshape(4)/2;R=np.outer(v,v.conj())
def neg(A):return float((np.abs(np.linalg.eigvalsh(A.reshape(2,2,2,2).transpose(0,3,2,1).reshape(4,4))).sum()-1)/2)
noise=[]
for lam in [1.,.9,.5,0.]:
 out=R.copy()
 for i in range(4):
  for j in range(4):out[i,j]*=lam**((i//2!=j//2)+(i%2!=j%2))
 noise.append(neg(out))
check('local_dephasing_entanglement_control',noise[0]>.07 and abs(noise[-1])<1e-12 and all(noise[i+1]<=noise[i]+1e-12 for i in range(3)),negativities=noise)
# A finite boundary can hide an algebra defect.
N=10;aa=np.diag(np.sqrt(np.arange(1,N)),1);defect=aa@aa.T-aa.T@aa-np.eye(N)
check('finite_truncation_warning',np.linalg.norm(defect[:-1,:-1])<1e-12 and abs(defect[-1,-1]+N)<1e-12,boundary_defect=float(defect[-1,-1]))
result=dict(seed=20261110,total=len(checks),passed=sum(c['passed'] for c in checks),failed=sum(not c['passed'] for c in checks),checks=checks,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
Path(__file__).with_name('rg_quantum_gravity_derivation_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['total','passed','failed']}))
for c in checks:print(('PASS ' if c['passed'] else 'FAIL ')+c['name'])
if result['failed']:raise SystemExit(1)
