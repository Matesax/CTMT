"""
RG - Signature Emergence battery
Verifies the surviving results of the "reactive Lorentz signature" falsification battery:
  (1) null-sector elimination -> memory kernel (Mori-Zwanzig / Schur-in-frequency) -> reactive form Q(w);
  (2) Q(w) inertia marches through a FULL staircase (r,0)->(r-1,1)->...->(0,r); Lorentzian = one band;
  (3) a genuine null cone appears once Q is indefinite (gauge-invariant, topological);
  (4) the signature structure is NOT a function of (J,Sigma) alone -- the memory kernel K is required data.
No physics is claimed; this is internal RG structure.  Pure numpy.
"""
import numpy as np
np.set_printoptions(precision=3, suppress=True)
rng = np.random.default_rng(0)

def inertia(A, tol=1e-9):
    w = np.linalg.eigvalsh((A + A.T) / 2)
    return int((w > tol).sum()), int((w < -tol).sum()), int((np.abs(w) <= tol).sum())

# ---------- resolved-sector data (SPD mass & stiffness) ----------
r = 4
Mr = rng.standard_normal((r, r)); Mr = Mr @ Mr.T + r*np.eye(r)
Kr = rng.standard_normal((r, r)); Kr = Kr @ Kr.T + r*np.eye(r)
res = np.sqrt(np.sort(np.linalg.eigvalsh(np.linalg.solve(Mr, Kr))))
print("resonance walls (where inertia jumps):", res)

# ---------- (1)-(2) signature staircase of the reactive form Q(w)=K - w^2 M ----------
print("\n(1-2) signature staircase of Q(w) = K - w^2 M:")
bands = [0.5*res[0], *(0.5*(res[i]+res[i+1]) for i in range(r-1)), res[-1]+1]
for w in bands:
    p, q, _ = inertia(Kr - w**2*Mr)
    tag = "Euclidean" if q == 0 else ("LORENTZIAN (one time)" if q == 1 else f"signature ({p},{q})")
    print(f"   w={w:5.3f}  (p,q)=({p},{q})  {tag}")
print("   -> Lorentzian is ONE band (between wall 1 and wall 2), not forced and not global.")

# ---------- (3) null cone appears once indefinite ----------
Q = Kr - (0.5*(res[0]+res[1]))**2 * Mr
w, V = np.linalg.eigh((Q + Q.T)/2)
ip, iq = np.where(w > 0)[0][0], np.where(w < 0)[0][0]
v = V[:, ip]/np.sqrt(w[ip]) + V[:, iq]/np.sqrt(-w[iq])
print(f"\n(3) null cone: Q(v,v) = {v @ Q @ v:.2e}  (genuine null direction once q>=1)")

# ---------- memory-kernel origin: eliminate a null sector N (Mori-Zwanzig) ----------
def reactive_from_kernel(An, Arn, Anr, w):
    Sig = Arn @ np.linalg.solve(1j*w*np.eye(An.shape[0]) - An, Anr)   # self-energy of eliminated N
    return Kr - w**2*Mr - np.real((Sig + Sig.conj().T)/2)

# ---------- (4) non-uniqueness: same static (J,Sigma), different kernels -> different signature structure ----------
print("\n(4) required data: same static resolved (J,Sigma), different null kernels K:")
Arn = rng.standard_normal((r, 2)); Anr = Arn.T.copy()
def walls(An):
    ws = np.linspace(0.01, 4, 4000); prev = None; W = []
    for w in ws:
        s = inertia(reactive_from_kernel(An, Arn, Anr, w))[:2]
        if prev is not None and s != prev: W.append((round(float(w), 2), prev, s))
        prev = s
    return W
print("   kernel A walls:", walls(-np.diag([1.0, 2.0])))
print("   kernel B walls:", walls(-np.diag([0.4, 5.0])))
print("   -> signature structure is NOT determined by (J,Sigma) alone; K is required:")
print("      reconstruction is (J, Sigma, K) -> [connection], not (J, Sigma) -> connection.")
