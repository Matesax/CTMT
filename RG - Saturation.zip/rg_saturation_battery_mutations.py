#!/usr/bin/env python3
"""Mutation suite for rg_saturation_battery.py.

Each mutation changes one line of the library (or of the battery's reference computation) so that a claim of the
saturation paper becomes false. It is caught only when the targeted group fails; the battery is run on that group
alone. A survivor is a defect of the battery; a crash is a defect of the suite, not a catch. Runs in temporary copies.

    python3 -I rg_saturation_battery_mutations.py [--jobs 2] [--only SA,SB]
"""
import argparse, json, os, shutil, subprocess, sys, tempfile
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
NAME = 'rg_saturation_battery'
LIB = 'rg_saturation.py'
CON = 'rg_construct.py'
BAT = NAME + '.py'
MUTATIONS = [  # (group, description, file, old, new)
    ('SA', 'null-side gauge generators omitted', LIB, 'cols.append(vec(sp.zeros(p, p), -C * B, B * SN - SN * B))', 'pass'),
    ('SB', 'top power sum of Sigma_R dropped', LIB, 'f = [sum(l ** k for l in L) for k in range(1, p + 1)]', 'f = [sum(l ** k for l in L) for k in range(1, p)]'),
    ('SB', 'floating-point rank with a vanishing tolerance', LIB, 'np.linalg.matrix_rank(J, 1e-6 * np.linalg.norm(J, 2))', 'np.linalg.matrix_rank(J, 1e-14 * np.linalg.norm(J, 2))'),
    ('SC', 'sign classes all positive', LIB, '            S[i, j] = v', '            S[i, j] = 1'),
    ('SC', 'cycle words reduced to degree 2', LIB, '@ mp(SR, c) @ C @ mp(SN, d) @ C.T))', '))'),
    ('SD', 'canonical correlations without whitening the null block', LIB, 'return np.linalg.svd(W(SR) @ C @ W(SN).T, compute_uv=False)', 'return np.linalg.svd(W(SR) @ C, compute_uv=False)'),
    ('SD', 'isotropic stratum without the null-side action', LIB, 'cols.append(list(-C * B))', 'pass'),
    ('SE', 'sum of squared correlations with Sigma_N for its inverse', BAT, 'np.trace(np.linalg.inv(SN) @ C.T @ np.linalg.inv(SR) @ C)', 'np.trace(SN @ C.T @ np.linalg.inv(SR) @ C)'),
    ('SF', 'exact fibre of x^2 taken as one branch', BAT, 'exact_width = float(2 * np.sqrt(x0 ** 2 + eps))', 'exact_width = float(np.sqrt(x0 ** 2 + eps) - np.sqrt(x0 ** 2 - eps))'),
    ('SG', 'declaration scaled on one side only', LIB, 'K.width(A, tau, eps, d, (1 + h) * bl, (1 + h) * bu)', 'K.width(A, tau, eps, d, bl, (1 + h) * bu)'),
    ('SH', 'declaration-only width counted on one side', LIB,
     'prior = float((bu * np.maximum(tau, 0) - bl * np.maximum(-tau, 0)).sum() + (bu * np.maximum(-tau, 0) - bl * np.maximum(tau, 0)).sum())',
     'prior = float((bu * np.maximum(tau, 0) - bl * np.maximum(-tau, 0)).sum())'),
    ('SH', 'no interior reference (slack forced to 0)', CON, 'bounds=[(None, None)] * n + [(None, 1.0)]', 'bounds=[(None, None)] * n + [(0.0, 0.0)]'),
    ('SI', 'asymmetric cases made symmetric', BAT, 'bl, bu, d = -rng.uniform(0.1, 2, n), rng.uniform(0.1, 2, n), rng.uniform(-0.04, 0.04, m)',
     'b2 = rng.uniform(0.1, 2, n); bl, bu, d = -b2, b2, np.zeros(m)'),
    ('SJ', 'added record compared at a tenfold bound', BAT, "l2 = K.load_split(np.vstack([A, a_new]), tau, 0.3,", "l2 = K.load_split(np.vstack([A, a_new]), tau, 3.0,"),
    ('SK', 'declaration that does not remove the hidden room', BAT, 'with_decl = np.sqrt(x0 ** 2 + eps) - np.sqrt(x0 ** 2 - eps)', 'with_decl = rec_only'),
    ('SE', 'separating words dropped from the records', BAT, 'fib = [k for k in range(len(cls)) if np.abs(W[k] - W[obs]).max() < 1e-12 and np.abs(I[k] - I[obs]).max() < 1e-12]',
     'fib = [k for k in range(len(cls)) if np.abs(I[k] - I[obs]).max() < 1e-12]'),
]



def run(mut):
    group, desc, rel, old, new = mut
    base = open(os.path.join(HERE, rel)).read()
    if base.count(old) != 1:
        return group, desc, 'anchor not found exactly once -> SUITE DEFECT', False
    with tempfile.TemporaryDirectory() as tmp:
        work = os.path.join(tmp, 'b')
        shutil.copytree(HERE, work, ignore=shutil.ignore_patterns('__pycache__', NAME + '_results.json', NAME + '_mutations.py',
                                                                  '*.log', 'paper', '*.zip', 'r[0-9]*.json', 'p[0-9]*.py', 'tmp_mut.py', 'RG_*bundle*'))
        open(os.path.join(work, rel), 'w').write(base.replace(old, new))
        env = dict(os.environ, RG_SAT_GROUPS=group)
        subprocess.run([sys.executable, '-I', NAME + '.py'], cwd=work, capture_output=True, text=True, env=env)
        try:
            fails = json.load(open(os.path.join(work, NAME + '_results.json')))['failures']
        except Exception:
            fails = ['CRASHED']
    ok = group in fails
    return group, desc, ('caught ' if ok else 'SURVIVED ') + str(fails), ok


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--jobs', type=int, default=2); ap.add_argument('--only', default='')
    a = ap.parse_args(); sel = [m for m in MUTATIONS if not a.only or m[0] in a.only.split(',')]
    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(run, sel))
    for g, d, msg, _ in res:
        print(f'{g}  {d}: {msg}', flush=True)
    caught = sum(r[3] for r in res)
    print(f'{caught} / {len(sel)} caught')
    return 0 if caught == len(sel) else 1


if __name__ == '__main__':
    sys.exit(main())
