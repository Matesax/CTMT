#!/usr/bin/env python3
"""Resolution Geometry - hostile battery for the saturation paper (rg_saturation.py, rg_construct.py).

Invariant saturation
  SA dimension audit, exact: the gauge orbit has dimension dim O(p) x O(q) and the quotient p + q + pq at a rational
     top-stratum point; the eigen-slice is transversal; (lambda, mu, rho) has p + q + min(p, q) entries, short by
     pq - min(p, q); sizes (1,1) (2,2) (2,3) (3,3) (4,4) (3,5)
  SB rank saturation, exact: I = (power sums, m_ab) has rank p + q + pq on the slice at every size; the same rank
     computed in floating point falls short at (4,4) and (3,5): the claim needs exact arithmetic
  SC rank saturation is not separation: m_ab = sum lambda_i^a mu_j^b C_ij^2 (Vandermonde), so I is blind to coupling
     signs; the 2^((p-1)(q-1)) sign classes of a dense coupling have identical I and are pairwise inequivalent; rho is
     not a function of I (it differs across the classes); rho and the degree-4 cycle words separate the classes in every
     tested instance
  SD where rho is complete and contract dependence: on the isotropic stratum the quotient has dimension 2 + min(p, q)
     and m_ab are functions of (a, b, rho); under GL(p) x GL(q) rho is invariant and lambda, mu, m_ab are not
Task saturation
  SE the four cells: records (lambda, mu, rho) with task m_11 not forced (hidden room); with task sum rho_i^2
     written as tr(S_N^-1 C^T S_R^-1 C) forced without identification; records I (rank-saturated) with task rho_1 not
     forced; records I plus cycle words with task rho_1 forced
  SF the lock ladder: rank DF = n, Q = 0 and a small Fisher variance at x = 0.7 for F = x^2, T = x, and rank
     saturation (SE cell 3) are each not a lock; a nonempty fibre with diam T <= 2 delta is
Provenance saturation
  SG the load split is Euler's identity for the homogeneous width: about a common reference point, the one-sided
     elasticities of the width under scaling the declaration lie in [D_min, D_max] (40 cases, symmetric and asymmetric)
  SH the endpoints are reference-free for an interior reference: D_min = 0 iff the width with records only equals the
     width; D_max = 1 iff the width with the declaration only equals it (400 cases, with realized offsets); with the
     reference on a face of the declaration a binding box gets zero cost (counterexample kept)
  SI intermediate shares are reference-relative: on centrally symmetric fibres three reference points agree to 1e-5;
     on asymmetric fibres the share moves by more than 0.3
  SJ provenance is not monotone in records: adding a record never widens the task but raised the declaration cost in
     some and the declaration share in more of 400 seeded cases
  SK a declaration that removes a hidden room carries the lock: F = x^2, T = x; with the declaration x > 0 the width
     falls from 1.4 to 1.4e-3, and the ablation ratio w / w_records_only is 1e-3

Deterministic seeds. Writes rg_saturation_battery_results.json.
Run:  python3 -I rg_saturation_battery.py       (numpy, scipy, sympy)
"""
import hashlib, json, os, sys
from fractions import Fraction as F
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rg_construct as K
import rg_saturation as S

R, FAILS = {}, []
SIZES = [(1, 1), (2, 2), (2, 3), (3, 3), (4, 4), (3, 5)]


def must(cond, tag):
    if not cond:
        if tag not in FAILS:
            FAILS.append(tag)
        print('FAILED', tag, flush=True)


def rational_point(p, q, seed):
    rng = np.random.default_rng(seed)
    lam = [F(k + 2, 1) for k in range(p)]; mu = [F(2 * k + 3, 2) for k in range(q)]
    Cq = [[F(int(x), 7) for x in rng.integers(1, 9, q)] for _ in range(p)]
    return lam, mu, Cq


# ------------------------------------------------------------------ SA, SB
def group_SA():
    rows = []
    for p, q in SIZES:
        lam, mu, Cq = rational_point(p, q, 1201 + 10 * p + q)
        npar, orb, quot, tr = S.gauge_rank_exact(lam, mu, Cq)
        rows.append(dict(p=p, q=q, parameters=npar, orbit=orb, quotient=quot, slice_transversal=tr,
                         lambda_mu_rho=p + q + min(p, q), gap=quot - (p + q + min(p, q))))
    ok = all(r['orbit'] == r['p'] * (r['p'] - 1) // 2 + r['q'] * (r['q'] - 1) // 2 and r['quotient'] == r['p'] + r['q'] + r['p'] * r['q']
             and r['slice_transversal'] and r['gap'] == r['p'] * r['q'] - min(r['p'], r['q']) for r in rows)
    must(ok, 'SA')
    R['SA'] = dict(claim='Exact: quotient dimension p + q + pq, slice transversal, (lambda, mu, rho) short by pq - min(p, q)',
                   seed=1201, sizes=rows)


def group_SB():
    rows = []
    for p, q in SIZES:
        lam, mu, Cq = rational_point(p, q, 1201 + 10 * p + q)
        rk, n = S.invariant_rank_exact(lam, mu, Cq)
        rows.append(dict(p=p, q=q, invariants=n, exact_rank=rk, float_rank=S.float_invariant_rank(p, q, seed=1202)))
    ok = all(r['exact_rank'] == r['invariants'] == r['p'] + r['q'] + r['p'] * r['q'] for r in rows) and \
        any(r['float_rank'] < r['exact_rank'] for r in rows)
    must(ok, 'SB')
    R['SB'] = dict(claim='I has exact rank p + q + pq on the slice at every size; floating-point rank falls short at large '
                         'sizes', seed=1202, sizes=rows)


# ------------------------------------------------------------------ SC
def _rand_triple(p, q, rng, iso=False):
    if iso:
        SR = rng.uniform(1, 3) * np.eye(p); SN = rng.uniform(1, 3) * np.eye(q)
    else:
        SR = np.diag(np.sort(rng.uniform(1, 4, p))[::-1]); SN = np.diag(np.sort(rng.uniform(1, 4, q))[::-1])
    return SR, SN


def group_SC():
    rng = np.random.default_rng(1203); out = []
    for p, q in [(2, 2), (2, 3), (3, 3), (3, 4)]:
        for trial in range(3):
            SR, SN = _rand_triple(p, q, rng); M = np.abs(rng.normal(size=(p, q))) * 0.15 + 0.03
            cls = S.sign_classes(M)
            I = np.array([S.invariants(SR, C, SN) for C in cls]); rho = np.array([S.canonical_corr(SR, C, SN) for C in cls])
            W = np.array([S.cycle_words(SR, C, SN) for C in cls])
            n = len(cls)
            dr = min(np.abs(rho[i] - rho[j]).max() for i in range(n) for j in range(i + 1, n)) if n > 1 else np.inf
            dw = min(np.abs(W[i] - W[j]).max() for i in range(n) for j in range(i + 1, n)) if n > 1 else np.inf
            # Vandermonde identity m_ab = sum lam_i^a mu_j^b C_ij^2
            lam, mu = np.diag(SR), np.diag(SN)
            mab = np.array([sum(lam[i] ** a * mu[j] ** b * cls[0][i, j] ** 2 for i in range(p) for j in range(q)) for a in range(p) for b in range(q)])
            out.append(dict(p=p, q=q, classes=n, expected=2 ** ((p - 1) * (q - 1)), I_spread=float(np.abs(I - I[0]).max()),
                            vandermonde_error=float(np.abs(mab - S.invariants(SR, cls[0], SN)[p + q:]).max()),
                            min_rho_separation=float(dr), min_word_separation=float(dw)))
    # inequivalence: on simple spectra the residual gauge is diagonal signs; classes are chosen modulo those signs, so
    # distinct classes differ in a cycle sign; check one pair by the separating word
    ok = all(o['classes'] == o['expected'] and o['I_spread'] < 1e-12 and o['vandermonde_error'] < 1e-12 and
             o['min_rho_separation'] > 1e-6 and o['min_word_separation'] > 1e-8 for o in out)
    must(ok, 'SC')
    R['SC'] = dict(claim='I is blind to cycle signs; rho is not a function of I; rho and cycle words separate the classes',
                   seed=1203, cases=out)


# ------------------------------------------------------------------ SD
def group_SD():
    rng = np.random.default_rng(1204); res = {}
    for p, q in [(2, 2), (3, 3), (4, 4), (2, 3)]:
        quot = S.isotropic_quotient_exact(p, q, [[F(int(x), 5) for x in rng.integers(1, 6, q)] for _ in range(p)])
        res[f'{p}{q}'] = dict(quotient=quot, expected=2 + min(p, q))
    # isotropic: two couplings with the same singular values give the same m_ab
    p, q = 3, 3; a, b = 2.0, 1.5; D = np.diag([0.5, 0.3, 0.1])
    Q1 = np.linalg.qr(rng.normal(size=(3, 3)))[0]; Q2 = np.linalg.qr(rng.normal(size=(3, 3)))[0]
    C1 = Q1 @ D @ Q2.T; Q3 = np.linalg.qr(rng.normal(size=(3, 3)))[0]; Q4 = np.linalg.qr(rng.normal(size=(3, 3)))[0]; C2 = Q3 @ D @ Q4.T
    iso = float(np.abs(S.invariants(a * np.eye(3), C1, b * np.eye(3)) - S.invariants(a * np.eye(3), C2, b * np.eye(3))).max())
    # GL contract
    SR, SN = _rand_triple(3, 3, rng); C = rng.normal(size=(3, 3)) * 0.2
    A = rng.normal(size=(3, 3)) + 2 * np.eye(3); B = rng.normal(size=(3, 3)) + 2 * np.eye(3)
    SR2, C2_, SN2 = A @ SR @ A.T, A @ C @ B.T, B @ SN @ B.T
    rho_change = float(np.abs(S.canonical_corr(SR, C, SN) - S.canonical_corr(SR2, C2_, SN2)).max())
    I_change = float(np.abs(S.invariants(SR, C, SN) - S.invariants(SR2, C2_, SN2)).max())
    ok = all(v['quotient'] == v['expected'] for v in res.values()) and iso < 1e-12 and rho_change < 1e-12 and I_change > 1e-2
    must(ok, 'SD')
    R['SD'] = dict(claim='Isotropic stratum: quotient 2 + min(p, q), m_ab functions of rho; GL contract: rho invariant, '
                         'I not', seed=1204, isotropic_quotients=res, isotropic_m_ab_difference=iso,
                   gl_rho_change=rho_change, gl_invariant_change=I_change)


# ------------------------------------------------------------------ SE, SF
def group_SE():
    rng = np.random.default_rng(1205)
    SR = np.diag([3.0, 1.0]); SN = np.diag([2.5, 0.7]); Dg = np.diag([0.8, 0.4])
    rot = lambda t: np.array([[np.cos(t), -np.sin(t)], [np.sin(t), np.cos(t)]])
    h = lambda S_: np.linalg.cholesky(S_)
    K1 = rot(0.3) @ Dg @ rot(-1.1).T; K2 = rot(1.2) @ Dg @ rot(0.4).T
    C1 = h(SR) @ K1 @ h(SN).T; C2 = h(SR) @ K2 @ h(SN).T
    lmr = lambda C: np.r_[np.diag(SR), np.diag(SN), S.canonical_corr(SR, C, SN)]
    m11 = lambda C: np.trace(SR @ C @ SN @ C.T)
    sum_rho2 = lambda C: np.trace(np.linalg.inv(SN) @ C.T @ np.linalg.inv(SR) @ C)
    cell1 = dict(records_equal=float(np.abs(lmr(C1) - lmr(C2)).max()), task=[m11(C1), m11(C2)])
    cell2 = dict(records_equal=cell1['records_equal'], task=[sum_rho2(C1), sum_rho2(C2)], rho_sq_sum=float((S.canonical_corr(SR, C1, SN) ** 2).sum()))
    SR3 = np.diag([3.0, 2.0, 1.0]); SN3 = np.diag([2.5, 1.6, 0.7]); M = np.abs(rng.normal(size=(3, 3))) * 0.2 + 0.05
    cls = S.sign_classes(M)
    I = np.array([S.invariants(SR3, C, SN3) for C in cls]); r1 = np.array([S.canonical_corr(SR3, C, SN3)[0] for C in cls])
    W = np.array([S.cycle_words(SR3, C, SN3) for C in cls])
    cell3 = dict(classes=len(cls), records_spread=float(np.abs(I - I[0]).max()), task_range=[float(r1.min()), float(r1.max())])
    # cell 4: records I + words: the fibre in the classes is the single class with the observed words
    obs = 5; fib = [k for k in range(len(cls)) if np.abs(W[k] - W[obs]).max() < 1e-12 and np.abs(I[k] - I[obs]).max() < 1e-12]
    cell4 = dict(fibre_classes=fib, task_range=[float(r1[fib].min()), float(r1[fib].max())])
    ok = cell1['records_equal'] < 1e-12 and abs(cell1['task'][0] - cell1['task'][1]) > 0.1 and \
        abs(cell2['task'][0] - cell2['task'][1]) < 1e-12 and abs(cell2['task'][0] - cell2['rho_sq_sum']) < 1e-12 and \
        cell3['records_spread'] < 1e-12 and cell3['task_range'][1] - cell3['task_range'][0] > 0.01 and \
        fib == [obs] and cell4['task_range'][0] == cell4['task_range'][1]
    must(ok, 'SE')
    R['SE'] = dict(claim='Four cells: hidden room; forced without identification; rank-saturated but not forced; '
                         'separated and forced', seed=1205, unsaturated_not_forced=cell1, unsaturated_forced=cell2,
                   saturated_not_forced=cell3, separated_forced=cell4)


def group_SF():
    x0, eps = 0.7, 1e-3
    loc = K.resolve(np.array([[2 * x0]]), np.array([1.0]), eps, tol=0.02)
    fisher_sd = float(eps / (2 * x0))
    exact_width = float(2 * np.sqrt(x0 ** 2 + eps))
    lock = dict(rank_DF=1, n=1, Q=loc['leakage'], fisher_sd=fisher_sd, first_order_status=loc['status'],
                exact_fibre_width=exact_width, exact_status='LOCKED' if exact_width <= 0.04 else 'CORRESPONDENCE')
    sat = R.get('SE', {}).get('saturated_not_forced')
    comp = K.compass_design(np.eye(3), [0, 0.5, 1.0])
    bl = np.r_[-1e-2 * np.ones(9), -1e-2 * np.ones(9), -1e-3 * np.ones(6)]
    real = K.resolve(comp[0], comp[1], 1e-6, bl=bl, bu=-bl, tol=1e-4)
    ok = lock['first_order_status'] == 'LOCKED-FIRST-ORDER' and lock['Q'] == 0.0 and lock['exact_status'] == 'CORRESPONDENCE' \
        and fisher_sd < 1e-3 and real['width'] <= 2e-4 and real['status'] == 'LOCKED-FIRST-ORDER'
    must(ok, 'SF')
    R['SF'] = dict(claim='Full rank, Q = 0 and small Fisher variance are not locks (x^2); a nonempty fibre with small task '
                         'diameter is (linear compass, where first order is exact)', x_squared=lock,
                   compass_linear_lock=dict(width=real['width'], status=real['status']),
                   rank_saturated_not_forced=sat is not None)


# ------------------------------------------------------------------ SG - SK
def _case(rng, sym):
    m, n = int(rng.integers(1, 4)), 3; A = rng.normal(size=(m, n)); eps = np.full(m, rng.uniform(0.05, 1))
    if sym:
        b = rng.uniform(0.1, 2, n); bl, bu, d = -b, b, np.zeros(m)
    else:
        bl, bu, d = -rng.uniform(0.1, 2, n), rng.uniform(0.1, 2, n), rng.uniform(-0.04, 0.04, m)
    return A, eps, bl, bu, d


def group_SG():
    rng = np.random.default_rng(1207); rows = []; worst = 0.0
    for k in range(40):
        A, eps, bl, bu, d = _case(rng, k % 2 == 0); tau = rng.normal(size=3)
        if np.any(np.abs(d) >= eps) or K.width(A, tau, eps, d, bl, bu) is None:
            continue
        ls = K.load_split(A, tau, eps, d, bl, bu)                  # Euler split about the reference point v = 0
        dn, up = S.elasticity(A, tau, eps, d, bl, bu)
        Dm, DM = ls['declaration_share']
        # one-sided elasticities lie in [D_min, D_max] (they are its endpoints)
        err = max(0.0, Dm - min(dn, up) - 1e-4, max(dn, up) - DM - 1e-4); worst = max(worst, err)
        rows.append([Dm, DM, dn, up])
    ok = len(rows) >= 20 and worst == 0.0
    must(ok, 'SG')
    R['SG'] = dict(claim='Load split = Euler split: one-sided elasticities of the width under scaling the declaration lie '
                         'in [D_min, D_max]', seed=1207, cases=len(rows), worst_violation=worst, sample=rows[:6])


def group_SH():
    rng = np.random.default_rng(1208); bad = 0; n0 = n1 = tested = 0
    for k in range(400):
        A, eps, bl, bu, d = _case(rng, False); kind = k % 3
        tau = A.T @ rng.normal(size=len(A)) if kind == 0 else (rng.normal(size=3) if kind == 1 else np.eye(3)[k % 3])
        r = K.resolve(A, tau, eps, d, bl, bu)
        if r['status'] != 'CORRESPONDENCE':
            continue
        if r['reference_slack'] <= 1e-9:
            continue
        tested += 1; w, wr, wp = S.ablation(A, tau, eps, d, bl, bu)
        Dm, DM = r['declaration_share']; tol = 1e-7 * max(w, 1e-12)
        c1 = (Dm < 1e-7) == (abs(w - wr) < tol); c2 = (DM > 1 - 1e-7) == (abs(w - wp) < tol)
        n0 += Dm < 1e-7; n1 += DM > 1 - 1e-7; bad += not (c1 and c2)
    # a reference on a face of the declaration: the binding box gets zero cost
    A1, e1, b_lo, b_hi = np.array([[1.0]]), np.array([1.0]), np.array([-0.5]), np.array([1.0]); v0 = np.array([-0.5])
    face = K.load_split(A1, np.array([1.0]), e1, -A1 @ v0, b_lo - v0, b_hi - v0)
    inner = K.resolve(A1, np.array([1.0]), e1, np.zeros(1), b_lo, b_hi)
    wF, wR, wP = S.ablation(A1, np.array([1.0]), e1, np.zeros(1), b_lo, b_hi)
    boundary = dict(width=wF, width_records_only=wR, share_at_face=face['declaration_share'], share_interior=inner['declaration_share'],
                    interior_slack=inner['reference_slack'])
    ok = bad == 0 and n0 > 20 and n1 > 20 and face['declaration_share'][0] < 1e-9 and wF < wR - 0.4 and inner['declaration_share'][0] > 0.1
    must(ok, 'SH')
    R['SH'] = dict(claim='D_min = 0 iff records alone give the width; D_max = 1 iff the declaration alone does', seed=1208,
                   tested=tested, endpoint_D0=n0, endpoint_D1=n1, mismatches=bad, reference_on_a_face=boundary)


def group_SI():
    from scipy.optimize import linprog
    rng = np.random.default_rng(1209); spreads = {True: 0.0, False: 0.0}; counts = {True: 0, False: 0}
    for k in range(300):
        sym = k % 2 == 0; A, eps, bl, bu, d = _case(rng, sym); tau = rng.normal(size=3)
        pts = []
        for j in range(3):
            c = rng.normal(size=3)
            res = linprog(c, A_ub=np.vstack([A, -A]), b_ub=np.r_[d + eps, eps - d], bounds=list(zip(bl, bu)), method='highs')
            if res.status != 0:
                break
            pts.append(res.x)
        if len(pts) < 3:
            continue
        c0 = np.mean(pts, axis=0)
        refs = [c0, 0.5 * c0 + 0.5 * pts[0], 0.5 * c0 + 0.5 * pts[1]] if not sym else [np.zeros(3), 0.5 * c0, 0.5 * c0 + 0.25 * pts[0]]
        Ds = [K.load_split(A, tau, eps, d - A @ v, bl - v, bu - v)['declaration_share'][0] for v in refs]
        if sym:
            Ds = [K.load_split(A, tau, eps, d, bl, bu)['declaration_share'][0]] + \
                 [K.load_split(A, tau, eps, d - A @ v, bl - v, bu - v)['declaration_share'][0] for v in refs[1:]]
        counts[sym] += 1; spreads[sym] = max(spreads[sym], max(Ds) - min(Ds))
    sym_only_origin = None
    ok = spreads[False] > 0.3 and counts[True] > 50 and counts[False] > 50
    must(ok, 'SI')
    R['SI'] = dict(claim='Intermediate shares depend on the reference point when the fibre is asymmetric', seed=1209,
                   asymmetric_largest_spread=spreads[False], symmetric_cases=counts[True], asymmetric_cases=counts[False],
                   symmetric_largest_spread=spreads[True], note=sym_only_origin)


def group_SJ():
    rng = np.random.default_rng(1210); inc_cost = inc_share = wider = 0; example = None
    for k in range(400):
        n = 4; A = rng.normal(size=(2, n)); a_new = rng.normal(size=(1, n)); tau = rng.normal(size=n); b = rng.uniform(0.2, 2, n)
        l1 = K.load_split(A, tau, 0.3, np.zeros(2), -b, b); l2 = K.load_split(np.vstack([A, a_new]), tau, 0.3, np.zeros(3), -b, b)
        wider += l2['width'] > l1['width'] + 1e-9
        if l2['declaration_cost'] > l1['declaration_cost'] + 1e-9:
            inc_cost += 1; example = example or dict(before=l1, after=l2)
        inc_share += l2['declaration_share'][0] > l1['declaration_share'][1] + 1e-9
    ok = wider == 0 and inc_cost > 0 and inc_share > inc_cost
    must(ok, 'SJ')
    R['SJ'] = dict(claim='A new record never widens the task, but can raise the declaration cost and share', seed=1210,
                   cases=400, widened=wider, declaration_cost_raised=inc_cost, declaration_share_raised=inc_share, example=example)


def group_SK():
    x0, eps = 0.7, 1e-3
    rec_only = 2 * np.sqrt(x0 ** 2 + eps)                                   # both branches
    with_decl = np.sqrt(x0 ** 2 + eps) - np.sqrt(x0 ** 2 - eps)           # declaration x > 0: one branch
    ratio = with_decl / rec_only
    ok = rec_only > 1.39 and with_decl < 1.5e-3 and ratio < 1.1e-3
    must(ok, 'SK')
    R['SK'] = dict(claim='Declaring x > 0 removes the hidden room x ~ -x and carries the lock: ablation ratio 1e-3',
                   width_records_only=float(rec_only), width_with_declaration=float(with_decl), ablation_ratio=float(ratio))


GROUPS = dict(SA=group_SA, SB=group_SB, SC=group_SC, SD=group_SD, SE=group_SE, SF=group_SF, SG=group_SG, SH=group_SH,
              SI=group_SI, SJ=group_SJ, SK=group_SK)


def main():
    want = os.environ.get('RG_SAT_GROUPS'); sel = want.split(',') if want else list(GROUPS)
    for g in sel:
        GROUPS[g]()                                               # a crash writes no results: never a pass, never a catch
        print(g, 'done', flush=True)
    R['failures'] = FAILS; R['groups_run'] = sel
    R['source_sha256'] = {f: hashlib.sha256((HERE / f).read_bytes()).hexdigest()
                          for f in ('rg_saturation.py', 'rg_construct.py', 'rg_saturation_battery.py')}
    (HERE / 'rg_saturation_battery_results.json').write_text(json.dumps(R, indent=1, sort_keys=True, default=float))
    print(json.dumps(R, indent=1, sort_keys=True, default=float)[:6000])
    return 1 if FAILS else 0


if __name__ == '__main__':
    sys.exit(main())
