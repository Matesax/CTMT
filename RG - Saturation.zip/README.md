# Saturation in Resolution Geometry: Invariant Saturation, Task Saturation and Provenance

Three questions separated and attacked with a seeded battery. Paper: `RG - Saturation.pdf` (source
`RG_Saturation.tex`). The programme's main print and README are in `Resolution Geometry.pdf` and `README.md`.

| File | What it is |
|---|---|
| `rg_saturation.py` | exact dimension audit and invariant rank (sympy), invariants, canonical correlations, sign classes, cycle words, elasticity, ablation |
| `rg_construct.py` | the forcing construction (width, load split about the interior reference, typed status) |
| `rg_saturation_battery.py` | groups SA–SK; writes `rg_saturation_battery_results.json` |
| `rg_saturation_battery_mutations.py` | sixteen one-line falsifications; each must fail its target group |

```
pip install -r requirements.txt            # numpy, scipy, sympy
python3 -I rg_saturation_battery.py         # about 30 s; byte-identical on rerun
python3 -I rg_saturation_battery_mutations.py --jobs 2
```

What it shows, briefly:
- Invariant saturation: power sums with m_ab have exact rank p+q+pq, but they see coupling magnitudes only; the
  2^((p-1)(q-1)) sign classes share every m_ab. Rank saturation is not separation.
- Task saturation is a separate axis: all four combinations are witnessed. A lock is a nonempty admissible set with
  task diameter at most 2 delta; full rank, Q = 0, small Fisher variance and rank saturation are not locks.
- Provenance: the record/declaration split is an Euler split (the share is an elasticity). Its endpoints are
  reference-free for an interior reference; intermediate values depend on the reference on asymmetric fibres.

Author: Matěj Rada, MatejRada@email.cz. License: CC BY-NC-ND 4.0.
