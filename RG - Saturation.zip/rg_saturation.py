#!/usr/bin/env python3
"""Resolution Geometry - saturation in three senses, as computation.

Invariant saturation (the description): second-order data (Sigma_R, C, Sigma_N) modulo O(p) x O(q).
  gauge_rank_exact      rank of the infinitesimal gauge action and of the slice, exact rational arithmetic
  invariants            I = (tr Sigma_R^k, tr Sigma_N^k, m_ab = tr(Sigma_R^a C Sigma_N^b C^T))
  invariant_rank_exact  rank of dI on the eigen-slice, exact rational arithmetic
  canonical_corr        rho = singular values of Sigma_R^-1/2 C Sigma_N^-1/2
  sign_classes          the coupling sign patterns, modulo row and column flips, with fixed magnitudes in eigenframes
  cycle_words           degree-4 traces tr(Sigma_R^a C Sigma_N^b C^T Sigma_R^c C Sigma_N^d C^T)

Task saturation (the conclusion): the width of a task over the admissible set; see rg_construct.resolve for the
linearized fibre and the typed status.

Provenance saturation (where the constraint came from): rg_construct.load_split gives the record / declaration split
of the width and its share interval [D_min, D_max]; here
  elasticity            one-sided d log w / d log s of the width when the declared box is scaled by s about the
                        reference point (equal to D_max / D_min: the split is Euler's identity for the homogeneous width)
  ablation              widths with records only and with the declaration only; for an interior reference point
                        D_min = 0 iff w = w_records_only and D_max = 1 iff w = w_declaration_only

numpy, scipy, sympy. Deterministic.
"""
import itertools
from fractions import Fraction
import numpy as np
import sympy as sp

import rg_construct as K


# ------------------------------------------------------------------ second-order data
def invariants(SR, C, SN):
    p, q = C.shape; mp = np.linalg.matrix_power
    out = [np.trace(mp(SR, k)) for k in range(1, p + 1)] + [np.trace(mp(SN, k)) for k in range(1, q + 1)]
    out += [np.trace(mp(SR, a) @ C @ mp(SN, b) @ C.T) for a in range(p) for b in range(q)]
    return np.array(out)


def canonical_corr(SR, C, SN):
    W = lambda S: np.linalg.inv(np.linalg.cholesky(S))
    return np.linalg.svd(W(SR) @ C @ W(SN).T, compute_uv=False)


def cycle_words(SR, C, SN, deg=1):
    mp = np.linalg.matrix_power; out = []
    for a, b, c, d in itertools.product(range(deg + 1), repeat=4):
        out.append(np.trace(mp(SR, a) @ C @ mp(SN, b) @ C.T @ mp(SR, c) @ C @ mp(SN, d) @ C.T))
    return np.array(out)


def sign_classes(M):
    """All coupling matrices with magnitudes |M| and signs, modulo row and column sign flips (first row and first
    column fixed positive): 2^((p-1)(q-1)) representatives for a dense M."""
    p, q = M.shape; free = [(i, j) for i in range(1, p) for j in range(1, q)]; out = []
    for s in itertools.product([1, -1], repeat=len(free)):
        S = np.ones((p, q))
        for (i, j), v in zip(free, s):
            S[i, j] = v
        out.append(np.abs(M) * S)
    return out


def _sym(n, name):
    return sp.Matrix(n, n, lambda i, j: sp.Symbol(f'{name}{min(i, j)}{max(i, j)}'))


def gauge_rank_exact(lam, mu, Cq):
    """At the slice point (diag(lam), C, diag(mu)) with rational entries: rank of the infinitesimal gauge action
    (A, B) -> ([A, S_R], A C - C B, [B, S_N]) and rank of [slice tangent | gauge directions] in the full parameter space.
    Returns (parameter count, gauge orbit dimension, quotient dimension, slice transversal?)."""
    p, q = len(lam), len(mu); SR = sp.diag(*[sp.Rational(x) for x in lam]); SN = sp.diag(*[sp.Rational(x) for x in mu])
    C = sp.Matrix(p, q, lambda i, j: sp.Rational(Cq[i][j]))
    iu_p = [(i, j) for i in range(p) for j in range(i, p)]; iu_q = [(i, j) for i in range(q) for j in range(i, q)]

    def vec(dR, dC, dN):
        return [dR[i, j] for i, j in iu_p] + list(dC) + [dN[i, j] for i, j in iu_q]
    cols = []
    for i, j in itertools.combinations(range(p), 2):
        A = sp.zeros(p, p); A[i, j] = 1; A[j, i] = -1; cols.append(vec(A * SR - SR * A, A * C, sp.zeros(q, q)))
    for i, j in itertools.combinations(range(q), 2):
        B = sp.zeros(q, q); B[i, j] = 1; B[j, i] = -1; cols.append(vec(sp.zeros(p, p), -C * B, B * SN - SN * B))
    G = sp.Matrix(cols).T; orbit = G.rank(); npar = len(iu_p) + p * q + len(iu_q)
    sl = []
    for i in range(p):
        dR = sp.zeros(p, p); dR[i, i] = 1; sl.append(vec(dR, sp.zeros(p, q), sp.zeros(q, q)))
    for k in range(p * q):
        dC = sp.zeros(p, q); dC[k // q, k % q] = 1; sl.append(vec(sp.zeros(p, p), dC, sp.zeros(q, q)))
    for j in range(q):
        dN = sp.zeros(q, q); dN[j, j] = 1; sl.append(vec(sp.zeros(p, p), sp.zeros(p, q), dN))
    full = sp.Matrix(cols + sl).T.rank()
    return npar, orbit, npar - orbit, full == npar


def isotropic_quotient_exact(p, q, Cq):
    """Dimension of the isotropic stratum quotient (S_R = a I, S_N = b I, C free): 2 + pq minus the exact rank of the
    infinitesimal action C -> A C - C B at a rational coupling."""
    C = sp.Matrix(p, q, lambda i, j: sp.Rational(Cq[i][j])); cols = []
    for i, j in itertools.combinations(range(p), 2):
        A = sp.zeros(p, p); A[i, j] = 1; A[j, i] = -1; cols.append(list(A * C))
    for i, j in itertools.combinations(range(q), 2):
        B = sp.zeros(q, q); B[i, j] = 1; B[j, i] = -1; cols.append(list(-C * B))
    orbit = sp.Matrix(cols).T.rank() if cols else 0
    return 2 + p * q - orbit


def invariant_rank_exact(lam, mu, Cq):
    """Exact rank of the differential of I on the eigen-slice (lambda, mu, C), at a rational point."""
    p, q = len(lam), len(mu)
    L = sp.symbols(f'l0:{p}'); M = sp.symbols(f'm0:{q}'); X = sp.symbols(f'c0:{p * q}')
    f = [sum(l ** k for l in L) for k in range(1, p + 1)] + [sum(m ** k for m in M) for k in range(1, q + 1)]
    f += [sum(L[i] ** a * M[j] ** b * X[i * q + j] ** 2 for i in range(p) for j in range(q)) for a in range(p) for b in range(q)]
    vars_ = list(L) + list(M) + list(X)
    J = sp.Matrix(f).jacobian(vars_)
    sub = {**{L[i]: sp.Rational(lam[i]) for i in range(p)}, **{M[j]: sp.Rational(mu[j]) for j in range(q)},
           **{X[k]: sp.Rational(Cq[k // q][k % q]) for k in range(p * q)}}
    return J.subs(sub).rank(), len(f)


def float_invariant_rank(p, q, seed=1):
    """The same rank by central differences in floating point over the full parameter space (to show why the claim
    needs exact arithmetic)."""
    rng = np.random.default_rng(seed)
    SR = np.diag(rng.uniform(1, 2, p)); SN = np.diag(rng.uniform(1, 2, q)); C = rng.normal(size=(p, q)) * 0.3
    iu_p, iu_q = np.triu_indices(p), np.triu_indices(q)
    x = np.r_[SR[iu_p], C.ravel(), SN[iu_q]]; a = len(iu_p[0])

    def unpack(x):
        R = np.zeros((p, p)); R[iu_p] = x[:a]; R = R + R.T - np.diag(np.diag(R))
        N = np.zeros((q, q)); N[iu_q] = x[a + p * q:]; N = N + N.T - np.diag(np.diag(N))
        return R, x[a:a + p * q].reshape(p, q), N
    h = 1e-5
    J = np.array([(invariants(*unpack(x + h * e)) - invariants(*unpack(x - h * e))) / (2 * h) for e in np.eye(len(x))]).T
    return int(np.linalg.matrix_rank(J, 1e-6 * np.linalg.norm(J, 2)))


# ------------------------------------------------------------------ provenance
def _w(r):
    return np.inf if r is None else r[1] - r[0]


def elasticity(A, tau, eps, d, bl, bu, h=1e-6):
    """One-sided elasticities of the width under scaling the declared box about the reference point v = 0."""
    w0 = _w(K.width(A, tau, eps, d, bl, bu))
    up = (np.log(_w(K.width(A, tau, eps, d, (1 + h) * bl, (1 + h) * bu))) - np.log(w0)) / h
    dn = (np.log(w0) - np.log(_w(K.width(A, tau, eps, d, (1 - h) * bl, (1 - h) * bu)))) / h
    return dn, up


def ablation(A, tau, eps, d, bl, bu):
    """Widths with records and declaration, with records only, with the declaration only."""
    tau = np.asarray(tau, float); bl = np.asarray(bl, float); bu = np.asarray(bu, float)
    full = _w(K.width(A, tau, eps, d, bl, bu)); rec = _w(K.width(A, tau, eps, d, None, None))
    prior = float((bu * np.maximum(tau, 0) - bl * np.maximum(-tau, 0)).sum() + (bu * np.maximum(-tau, 0) - bl * np.maximum(tau, 0)).sum())
    return full, rec, prior
