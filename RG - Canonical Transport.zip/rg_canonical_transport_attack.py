#!/usr/bin/env python3
"""
RG canonical transport (L58): locked battery TC01-TC07
=====================================================
  TC01 no-go: vertical shears are gauge and act transitively on horizontal complements -> no law-natural connection
  TC02 declared covariance P: H_P = im(P J^T) is a complement, the minimal P^-1-norm lift, the noiseless limit of
       the Bayesian (Kalman) update, and GL-equivariant; different P give different transport on identical laws
  TC03 curvature: for nonlinear laws the P-horizontal lift of a closed observed loop has latent holonomy ~ area;
       zero for linear laws; depends on P
  TC04 memory kernel: the canonical path lift equals the RTS (Kalman) smoother; ignoring memory changes it
  TC05 cross-wall: P-projections specialize, Pi_0 = Pi_0 o lim Pi_eps; the wall transport is determined given P
       and differs between two declared P on identical laws
  TC06 audit of the uploaded cross-wall checks A1-A4: invertible regular law makes inclusion and factorization
       vacuous (they pass for an unrelated wall)
  TC07 observable-loop holonomy vs latent holonomy: a clean observed loop with nonzero computed latent holonomy

Run:  python3 rg_canonical_transport_attack.py [--seed 20261002] [--out FILE] [--canary]
"""
import argparse, json, math, sys, time
import numpy as np

RESULTS, MUT = [], {}


def f_(x): return float(np.round(float(x), 12))


def _finite(o):
    if isinstance(o, dict): return all(_finite(v) for v in o.values())
    if isinstance(o, (list, tuple)): return all(_finite(v) for v in o)
    if isinstance(o, float): return math.isfinite(o)
    return True


def register(aid, naive, keep, passed, ev, verdict):
    if not _finite(ev): passed, verdict = False, "NONFINITE"
    RESULTS.append(dict(id=aid, naive_claim=naive, rg_claim=keep, passed=bool(passed), verdict=verdict, evidence=ev))
    print(f"[{'PASS' if passed else 'FAIL'}] {aid} {verdict:16s} {keep[:84]}")


def kernel(A, tol=1e-10):
    u, s, vt = np.linalg.svd(A); r = int(np.sum(s > tol*max(1, s[0]))); return vt[r:].T


def proj_dist(A, B):
    """distance between column spans (orthogonal projector difference, spectral norm)."""
    Qa, _ = np.linalg.qr(A); Qb, _ = np.linalg.qr(B)
    return float(np.linalg.norm(Qa@Qa.T-Qb@Qb.T, 2))


def spd(rng, n):
    L = rng.normal(size=(n, n)); return L@L.T+0.5*np.eye(n)


def lift(P, J):                               # P^-1-orthogonal (minimal-norm) lift matrix
    return P@J.T@np.linalg.inv(J@P@J.T)


# ======================================================================= checks
def TC01_gauge_transitivity(rng):
    worst_law, worst_map, n_cases = 0.0, 0.0, 200
    for _ in range(n_cases):
        m, n = 2, 5; J = rng.normal(size=(m, n)); K = kernel(J)
        B1 = np.linalg.pinv(J) + K@rng.normal(size=(K.shape[1], m))          # arbitrary lift matrices: J B = I
        B2 = np.linalg.pinv(J) + K@rng.normal(size=(K.shape[1], m))
        phi = np.eye(n) + (B2-B1)@J                                           # vertical shear
        worst_law = max(worst_law, float(np.linalg.norm(J@phi-J)))            # F o phi = F: gauge
        worst_map = max(worst_map, float(np.linalg.norm(phi@B1-B2)))          # phi maps H1 onto H2 (as lifts)
    passed = worst_law < 1e-10 and worst_map < 1e-10
    register("TC01", "A canonical connection can be built from the observation law (J, laws, natural modules).",
             "No: vertical shears phi = I + (B2-B1)J preserve the law and carry any horizontal complement to any other. "
             "Gau acts transitively on complements, so no law-natural (Gau-invariant) connection exists.",
             passed, dict(max_law_change=f_(worst_law), max_complement_mismatch=f_(worst_map), cases=n_cases), "FALSIFIED-naive")


def TC02_declared_covariance(rng):
    comp_ok, min_ok, kal, equi, dP = True, True, 0.0, 0.0, []
    for _ in range(200):
        m, n = 2, 5; J = rng.normal(size=(m, n)); P = spd(rng, n); Pi = np.linalg.inv(P); K = kernel(J)
        L = lift(P, J); HP = P@J.T
        comp_ok &= np.linalg.matrix_rank(np.c_[HP, K]) == n
        dy = rng.normal(size=m); x0 = L@dy; n0 = x0@Pi@x0
        for _ in range(10):
            x1 = x0 + K@rng.normal(size=K.shape[1]); min_ok &= (x1@Pi@x1) >= n0-1e-12
        R = 1e-10*np.eye(m); kal = max(kal, float(np.linalg.norm(P@J.T@np.linalg.inv(J@P@J.T+R)@dy - x0)/np.linalg.norm(x0)))
        g = rng.normal(size=(n, n)) + 3*np.eye(n)
        equi = max(equi, proj_dist((g@P@g.T)@(J@np.linalg.inv(g)).T, g@HP))
        P2 = spd(rng, n); dP.append(proj_dist(HP, P2@J.T))
    passed = comp_ok and min_ok and kal < 1e-6 and equi < 1e-8 and np.median(dP) > 0.1
    register("TC02", "Without further structure some lift is still 'the' natural one.",
             "Given declared latent covariance P, H_P = im(P J^T) is a complement, the minimal P^-1-norm lift, the "
             "noiseless limit of the Kalman update, and GL-equivariant. Two declared P give different transport on "
             "identical laws: P is genuinely additional structure.",
             passed, dict(complement=bool(comp_ok), minimal_norm=bool(min_ok), kalman_limit_rel_err=f_(kal),
                          equivariance_err=f_(equi), median_transport_gap_between_P=f_(np.median(dP))), "HOLDS")


def horizontal_holonomy(F, DF, P, side, x0, steps=400):
    """lift the observed square loop of the given side around y0 = F(x0); return latent endpoint gap."""
    y0 = F(x0); corners = [np.array([0, 0]), np.array([side, 0]), np.array([side, side]), np.array([0, side]), np.array([0, 0])]
    x = x0.copy()
    def vel(x, dy):
        D = DF(x); return P@D.T@np.linalg.solve(D@P@D.T, dy)
    for c0, c1 in zip(corners[:-1], corners[1:]):
        dy = (c1-c0)/steps
        for _ in range(steps):
            k1 = vel(x, dy); k2 = vel(x+k1/2, dy); k3 = vel(x+k2/2, dy); k4 = vel(x+k3, dy)
            x = x+(k1+2*k2+2*k3+k4)/6
    return float(np.linalg.norm(x-x0)), float(np.linalg.norm(F(x)-y0))


def TC03_curvature(rng):
    F = lambda x: np.array([x[0]+0.5*x[2]**2, x[1]+0.8*x[0]*x[2]])
    DF = lambda x: np.array([[1, 0, x[2]], [0.8*x[2], 1, 0.8*x[0]]])
    Fl = lambda x: np.array([x[0]+0.3*x[2], x[1]-0.2*x[2]]); DFl = lambda x: np.array([[1, 0, 0.3], [0, 1, -0.2]])
    x0 = np.array([0.2, -0.1, 0.4]); P1 = np.eye(3); P2 = np.diag([1.0, 2.0, 0.5])
    hol = [horizontal_holonomy(F, DF, P1, s, x0) for s in (0.02, 0.01, 0.005)]
    order = math.log(hol[0][0]/hol[2][0])/math.log(4)
    lin = horizontal_holonomy(Fl, DFl, P1, 0.02, x0)[0]
    hP2 = horizontal_holonomy(F, DF, P2, 0.02, x0)[0]
    closed = max(h[1] for h in hol)
    passed = abs(order-2) < 0.1 and lin < 1e-10 and abs(hP2-hol[0][0])/hol[0][0] > 0.05 and closed < 1e-8
    register("TC03", "Observed loops close, so the latent transport has no holonomy.",
             "The P-connection of a nonlinear law has latent holonomy (fibre displacement after a closed observed loop) "
             "scaling as area (order 2: curvature, O'Neill A-tensor); zero for linear laws; its value depends on the "
             "declared P.",
             passed, dict(holonomy_by_side=[f_(h[0]) for h in hol], scaling_order=f_(order), linear_law_holonomy=f_(lin),
                          holonomy_other_P=f_(hP2), observed_loop_closure=f_(closed)), "FALSIFIED-naive")


def TC04_memory(rng):
    """latent AR(1) x_t = Phi x_{t-1} + w_t (2D), observed y_t = J x_t (1D). Canonical path lift = conditional mean
    = P J^T (J P J^T)^-1 y on path space = RTS smoother (R -> 0). The memoryless lift (stationary covariance only)
    differs."""
    T, n = 40, 2; Phi = np.array([[0.9, 0.3], [-0.2, 0.7]]); Qw = np.diag([0.5, 0.2]); J = np.array([[1.0, 0.4]])
    # stationary covariance
    S = np.eye(n)
    for _ in range(2000): S = Phi@S@Phi.T+Qw
    # path covariance
    Pp = np.zeros((n*T, n*T))
    for i in range(T):
        for j in range(T):
            Pp[n*i:n*i+n, n*j:n*j+n] = np.linalg.matrix_power(Phi, i-j)@S if i >= j else S@np.linalg.matrix_power(Phi.T, j-i)
    Jp = np.kron(np.eye(T), J)
    x = np.zeros((T, n)); xp = rng.multivariate_normal(np.zeros(n), S)
    for t in range(T): xp = Phi@xp + rng.multivariate_normal(np.zeros(n), Qw) if t else xp; x[t] = xp
    y = (Jp@x.ravel())
    lift_path = (Pp@Jp.T@np.linalg.solve(Jp@Pp@Jp.T, y)).reshape(T, n)
    # RTS smoother with tiny R
    R = MUT.get("tc04_R", 1e-10); m, Pf, ms, Ps = np.zeros(n), S.copy(), [], []
    mp_list, Pp_list = [], []
    for t in range(T):
        if t: m, Pf = Phi@m, Phi@Pf@Phi.T+Qw
        mp_list.append(m.copy()); Pp_list.append(Pf.copy())
        Kg = Pf@J.T/(J@Pf@J.T+R); m = m+(Kg*(y[t]-J@m)).ravel(); Pf = Pf-Kg@J@Pf
        ms.append(m.copy()); Ps.append(Pf.copy())
    xs = [None]*T; xs[-1] = ms[-1]
    for t in range(T-2, -1, -1):
        G = Ps[t]@Phi.T@np.linalg.inv(Pp_list[t+1]); xs[t] = ms[t]+G@(xs[t+1]-mp_list[t+1])
    rts = np.array(xs)
    memless = np.array([lift(S, J)@np.atleast_1d(y[t]) for t in range(T)])
    e_rts = float(np.max(np.abs(rts-lift_path))/np.max(np.abs(lift_path)))
    gap = float(np.max(np.abs(memless-lift_path))/np.max(np.abs(lift_path)))
    passed = e_rts < 1e-5 and gap > 0.05
    register("TC04", "The memory kernel is irrelevant to the canonical transport.",
             "With a memory kernel the canonical lift lives on path space: it equals the RTS (Kalman) smoother; the "
             "memoryless instantaneous lift differs by a finite amount.",
             passed, dict(rts_vs_path_lift_rel_err=f_(e_rts), memoryless_gap=f_(gap), T=T), "HOLDS")


def P_proj(P, J, tol=1e-12):
    """P^-1-orthogonal projector onto im(P J^T) along ker J, built from an orthonormal basis of span(P^1/2 J^T)
    (stable near rank walls; the first version inverted J P J^T and was numerically singular at eps = 1e-7)."""
    w, U = np.linalg.eigh(P); Ph = (U*np.sqrt(w))@U.T; Pmh = (U/np.sqrt(w))@U.T
    u, s, vt = np.linalg.svd(Ph@J.T, full_matrices=False); Q = u[:, s > tol*max(1, s[0])]
    return Ph@Q@Q.T@Pmh


def contain_defect(Hsmall, Hbig):
    Qs, _ = np.linalg.qr(Hsmall); Qb, _ = np.linalg.qr(Hbig)
    return float(np.linalg.norm((np.eye(Qb.shape[0])-Qb@Qb.T)@Qs, 2))


def TC05_cross_wall(rng):
    """Coherence across a rank wall. For the P-connection H = (ker J)^{perp_P^-1} = im(P J^T); since limits of regular
    kernels lie in the wall kernel, the wall horizontal space H_0 lies in the limit of H_eps (defect -> 0 linearly).
    Controls: arbitrary complements (no declared metric) and a different P at the wall violate containment.
    (First registration tested Pi_0 = Pi_0 o lim Pi_eps, which holds for ANY projector along ker J_0: vacuous.)"""
    dP, decay, arb, mixed, gapP = [], [], [], [], []
    for _ in range(200):
        n = 4; U, _ = np.linalg.qr(rng.normal(size=(3, 3))); V, _ = np.linalg.qr(rng.normal(size=(n, n)))
        J0 = U@np.diag([1.2, 0.7, 0.0])@V[:, :3].T; B = rng.normal(size=(3, n)); P = spd(rng, n)
        Pw = spd(rng, n) if MUT.get("tc05_mixed_P") else P
        H0 = Pw@J0.T@np.linalg.svd(J0)[0][:, :2]                       # wall horizontal space (rank 2)
        d = [contain_defect(H0, P@(J0+e*B).T) for e in (1e-2, 1e-4)]
        dP.append(d[1]); decay.append(d[0]/max(d[1], 1e-300))
        K0 = kernel(J0)
        arb.append(contain_defect(np.linalg.pinv(J0)@np.linalg.svd(J0)[0][:, :2] + K0@rng.normal(size=(K0.shape[1], 2)),
                                  np.linalg.pinv(J0+1e-4*B) + kernel(J0+1e-4*B)@rng.normal(size=(kernel(J0+1e-4*B).shape[1], 3))))
        mixed.append(contain_defect(spd(rng, n)@J0.T@np.linalg.svd(J0)[0][:, :2], P@(J0+1e-4*B).T))
        gapP.append(proj_dist(H0, spd(rng, n)@J0.T@np.linalg.svd(J0)[0][:, :2]))
    passed = np.max(dP) < 1e-2 and np.median(decay) > 50 and np.median(arb) > 0.1 and np.median(mixed) > 0.1 and np.median(gapP) > 0.1
    register("TC05", "Cross-wall latent transport is underdetermined (uploaded verdict L58b).",
             "Only without declared data. With a declared P the connection specializes coherently: the wall horizontal "
             "space lies in the limit of the regular ones (defect linear in eps). Arbitrary complements, or a different "
             "P at the wall, violate this; two declared P give different wall transport on identical laws.",
             passed, dict(max_containment_defect_eps_1em4=f_(np.max(dP)), median_decay_100x=f_(np.median(decay)),
                          median_defect_arbitrary_complements=f_(np.median(arb)), median_defect_mixed_P=f_(np.median(mixed)),
                          median_gap_between_P=f_(np.median(gapP))), "FALSIFIED-naive")


def TC06_audit_uploaded(rng):
    """uploaded A1-A4: A = W + eps B with B spanning exactly ker W -> A invertible; then inclusion and factorization
    hold for ANY wall W' (they test nothing). Demonstrated with an unrelated random rank-2 wall."""
    passes = 0
    for _ in range(100):
        U, _ = np.linalg.qr(rng.normal(size=(4, 4))); V, _ = np.linalg.qr(rng.normal(size=(4, 4)))
        W = U@np.diag([1.3, .8, 0, 0])@V.T; B = U@np.diag([0, 0, .9, .6])@V.T; A = W+0.05*B
        Wp = rng.normal(size=(4, 2))@rng.normal(size=(2, 4))                           # unrelated wall
        S = Wp@np.linalg.pinv(A); fact = np.linalg.norm(Wp-S@A) < 1e-8
        incl = kernel(A).shape[1] == 0
        passes += fact and incl
    register("TC06", "The uploaded A1-A4 checks lock kernel inclusion and quotient factorization.",
             "They are vacuous: the regular law is invertible, so inclusion and factorization hold for an unrelated "
             "wall in 100/100 cases. Non-vacuous tests need nontrivial regular kernels (SP01, SP03).",
             passes == 100, dict(unrelated_wall_passes=f"{passes}/100"), "FALSIFIED-naive")


def TC07_observed_vs_latent(rng):
    """uploaded H1 used random normals as 'holonomy'. Computed instead: an observed loop that closes exactly in the
    quotient carries a nonzero latent holonomy for the P-connection of a nonlinear law, invisible in every law."""
    F = lambda x: np.array([x[0]+0.5*x[2]**2, x[1]+0.8*x[0]*x[2]])
    DF = lambda x: np.array([[1, 0, x[2]], [0.8*x[2], 1, 0.8*x[0]]])
    hol, closure = horizontal_holonomy(F, DF, np.eye(3), 0.05, np.array([0.2, -0.1, 0.4]))
    passed = closure < 1e-8 and hol > 1e-4
    register("TC07", "A clean observable loop certifies trivial latent holonomy.",
             "No: the observed loop closes to 1e-8 in the quotient while the declared-P latent transport returns "
             "displaced along the fibre. Latent holonomy is a property of declared data, invisible to the laws.",
             passed, dict(observed_closure=f_(closure), latent_holonomy=f_(hol)), "FALSIFIED-naive")


ATTACKS = [TC01_gauge_transitivity, TC02_declared_covariance, TC03_curvature, TC04_memory, TC05_cross_wall,
           TC06_audit_uploaded, TC07_observed_vs_latent]


def run_all(seed):
    for a in ATTACKS:
        rng = np.random.default_rng([seed, ATTACKS.index(a)])
        try: a(rng)
        except Exception as ex: register(a.__name__[:4], "?", f"EXCEPTION {ex!r}", False, {}, "ERROR")


def canary(seed):
    muts = [("TC04", {"tc04_R": 1.0}), ("TC05", {"tc05_mixed_P": True})]                # noisy smoother is not the noiseless path lift
    ok = True
    for tgt, m in muts:
        RESULTS.clear(); MUT.clear(); MUT.update(m); print(f"--- canary {tgt}: {m}")
        a = next(x for x in ATTACKS if x.__name__.startswith(tgt))
        try: a(np.random.default_rng([seed, ATTACKS.index(a)])); caught = not RESULTS[-1]["passed"]
        except Exception as ex: print(f"    exception {ex!r} (not a clean catch)"); caught = False
        ok &= caught; print(f"    {'CAUGHT' if caught else 'NOT CAUGHT'}")
    MUT.clear(); print("CANARY:", "all caught" if ok else "BATTERY TOO WEAK"); return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--seed", type=int, default=20261002)
    ap.add_argument("--out", default="rg_canonical_transport_results.json"); ap.add_argument("--canary", action="store_true")
    a = ap.parse_args()
    if a.canary: sys.exit(canary(a.seed))
    t0 = time.time(); print(f"RG canonical transport battery, seed {a.seed}\n"); run_all(a.seed)
    n = sum(r["passed"] for r in RESULTS)
    summ = dict(seed=a.seed, n_checks=len(RESULTS), n_pass=n, runtime_s=round(time.time()-t0, 1))
    json.dump(dict(summary=summ, results=RESULTS), open(a.out, "w"), indent=2,
              default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print(f"\n{n}/{len(RESULTS)} pass."); sys.exit(0 if n == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
