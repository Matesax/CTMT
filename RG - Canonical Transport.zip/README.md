# RG - Canonical Transport: battery TC01-TC07

    python3 rg_canonical_transport_attack.py            # seed 20261002
    python3 rg_canonical_transport_attack.py --canary   # TC04, TC05 sabotaged; each must fail

7/7 on seeds 20261002, 1, 42, 777, 2026; canary 2/2. No law-natural connection (gauge transitivity); canonical
connection under declared covariance (minimal norm, Kalman limit, equivariance, curvature = latent holonomy, RTS on
path space, coherence across walls); audit of the earlier cross-wall battery (TC06).
