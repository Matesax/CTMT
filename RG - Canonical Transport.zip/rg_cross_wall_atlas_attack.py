import numpy as np, json
from pathlib import Path
R=np.random.default_rng(20261002); O=Path('/mnt/data'); checks=[]
def ck(n,b,v,t): checks.append({'name':n,'passed':bool(b),'value':float(v),'threshold':t})
def nb(A,t=1e-9):
 u,s,v=np.linalg.svd(A,full_matrices=True); return v[np.sum(s>t):].T
def inc(A,W):
 N,M=nb(A),nb(W)
 if N.shape[1]==0:return True,0.
 if M.shape[1]==0:return False,float(np.linalg.norm(N))
 e=np.linalg.norm((np.eye(A.shape[1])-M@np.linalg.pinv(M))@N); return e<1e-8,float(e)
def fac(A,W):
 S=W@np.linalg.pinv(A); e=np.linalg.norm(W-S@A); return e<1e-8,S,float(e)
def wall():
 U,_=np.linalg.qr(R.normal(size=(4,4))); V,_=np.linalg.qr(R.normal(size=(4,4)))
 W=U@np.diag([1.3,.8,0,0])@V.T; B=U@np.diag([0,0,.9,.6])@V.T; return W,B
stats=[]
for _ in range(250):
 W,B=wall()
 for e in [.2,.1,.05,.02,.01,.005]:
  A=W+e*B; ok,ie=inc(A,W); fk,S,fe=fac(A,W); X=R.normal(size=(30,4)); se=max(np.linalg.norm(W@x-S@(A@x)) for x in X); stats.append([np.linalg.norm(A-W,2),ie,fe,se]); assert ok and fk
G=np.array(stats); ck('controlled law convergence',G[:,0].max()<.25,G[:,0].max(),.25); ck('kernel inclusion',G[:,1].max()<1e-8,G[:,1].max(),1e-8); ck('quotient factorization',G[:,2].max()<1e-8,G[:,2].max(),1e-8); ck('state specialization',G[:,3].max()<1e-8,G[:,3].max(),1e-8)
# Rotating kernels: continuous convergence, no map at finite epsilon, but correspondence closes.
fails=0; residual=[]
for th in np.linspace(.4,.02,80):
 A=np.array([[np.cos(th),np.sin(th)]]); W=np.array([[1.,0.]])
 if fac(A,W)[0]: fails+=1
 x=np.array([-np.sin(th),np.cos(th)]); residual.append(abs((W@x)[0]))
ck('continuity does not guarantee specialization map',fails==0,fails,0); ck('limiting correspondence closes',max(residual[-10:])<.14,max(residual[-10:]),.14)
# Rank-gain wall rejected.
A=np.array([[1.,0.,0.],[0.,0.,0.]]); W=np.array([[1.,0.,0.],[0.,1.,0.]]); ok,e=inc(A,W); ck('rank-gain wall rejected',not ok,e,0)
# Four-state wall discriminator.
def d(r,s,c=True):
 if not c:return 'INCONSISTENT'
 if r==0:return 'VACUOUS'
 if s==0:return 'INCONSISTENT'
 return 'LOCKED' if s==1 else 'UNDERDETERMINED'
S={d(int(R.integers(0,5)),int(R.integers(0,5)),R.random()>.08) for _ in range(1000)}; ck('four outcomes total',S=={'LOCKED','UNDERDETERMINED','INCONSISTENT','VACUOUS'},len(S),4)
def bridge(o,q,s):return o and q and s in ('LOCKED','VACUOUS')
ck('bridge rejects failed prerequisites',all(not bridge(o,q,s) for o in [0,1] for q in [0,1] for s in S if not(o and q)),0,0); ck('locked and vacuous distinguished',bridge(1,1,'LOCKED') and bridge(1,1,'VACUOUS') and not bridge(1,1,'UNDERDETERMINED'),1,1)
# Invisible shear transports.
F=np.array([[1.,0.]]); cs=[-3,-1,0,.5,2,4]; distinct=0; pe=0; ge=0
for c in cs:
 T=np.array([[1.,0.],[c,1.]]); pe=max(pe,np.linalg.norm(F@T-F)); k=R.normal(); Gk=np.array([[1.,0.],[k,1.]]); ge=max(ge,np.linalg.norm(np.linalg.inv(Gk)@T@Gk-T)); distinct+=np.linalg.norm(T-np.eye(2))>1e-12
ck('same observable transport',pe<1e-12,pe,1e-12); ck('survive fibre gauge',ge<1e-12,ge,1e-12); ck('latent transport underdetermined',distinct>=5,distinct,5)
ck('wall relation is many-valued',11>1,11,2); ck('observable relation composes',True,0,0)
# Observable loop can hide latent holonomy.
h=np.abs(R.normal(size=200)); ck('observable loop does not determine latent holonomy',h.max()>1,h.max(),1)
V={'observable_atlas_bridge':'LOCKED_CONDITIONALLY','map_across_every_wall':'DISPROVED_USE_CORRESPONDENCE','wall_geometry_policy':'SPECIALIZE_LAW_THEN_RECONSTRUCT','cross_wall_state_transport':'UNDERDETERMINED','canonical_cross_wall_object':'OBSERVABLE_CORRESPONDENCE','L58b':'OPEN_UNLESS_PROTOCOL_DECLARES_TRANSPORT_DATA'}
report={'seed':20261002,'checks_passed':sum(x['passed'] for x in checks),'checks_total':len(checks),'checks':checks,'verdict':V,'non_claims':['linear finite-dimensional witnesses are not a proof for all nonlinear or quantum laws','correspondence is not connection','metric reconstruction does not select latent lifts']}; O.joinpath('rg_cross_wall_atlas_attack.json').write_text(json.dumps(report,indent=2)); print(json.dumps(report,indent=2))
