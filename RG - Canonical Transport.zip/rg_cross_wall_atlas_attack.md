# RG Cross-Wall Atlas Bridge Attack

- Seed: `20261002`
- Checks passed: **17/17**

## Verdict

- **observable_atlas_bridge**: `LOCKED_CONDITIONALLY`
- **map_across_every_wall**: `DISPROVED_USE_CORRESPONDENCE_WHEN_NO_KERNEL_INCLUSION`
- **wall_geometry_policy**: `SPECIALIZE_LAW_THEN_RECONSTRUCT`
- **metric_wall_status**: `LOCKED_OR_ABSTAIN_OR_VACUOUS`
- **cross_wall_state_transport**: `UNDERDETERMINED`
- **canonical_cross_wall_object**: `OBSERVABLE_CORRESPONDENCE`
- **L58b**: `OPEN_UNLESS_PROTOCOL_DECLARES_TRANSPORT_DATA`

## Registered checks

- [PASS] A1 controlled observation laws converge at rank-loss walls
- [PASS] A2 limiting regular kernels are contained in wall kernels
- [PASS] A3 unique quotient specialization factorizes the wall law
- [PASS] A4 quotient states specialize coherently
- [PASS] B1 continuity alone does not imply a map Q_epsilon to Q_wall
- [PASS] B2 limiting correspondence closes as rotating kernel converges
- [PASS] C1 uncontrolled law discontinuity is detected
- [PASS] D1 a wall that creates distinguishability fails kernel inclusion
- [PASS] E1 re-discrimination is total on the four declared outcomes
- [PASS] E2 atlas continuation never claims geometry after failed law or quotient lock
- [PASS] E3 locked metric and vacuous wall are distinguished but both atlas-admissible
- [PASS] F1 multiple distinct latent transports have identical observable projection
- [PASS] F2 transport candidates survive fibre-coordinate gauge test
- [PASS] F3 metric and atlas locks do not select a unique latent transport
- [PASS] G1 wall compatibility is naturally a many-valued correspondence
- [PASS] G2 wall correspondence composes on observable classes
- [PASS] H1 clean observable loop does not certify latent holonomy

## Theorem candidate supported by the battery

The observable atlas bridge is closed conditionally by transporting the observation law, not the metric. Under controlled law convergence, kernel-compatible quotient specialization, and specialization of the operational task family, reconstruct the wall geometry by re-discrimination. A `LOCKED` result produces a wall metric; `VACUOUS` records that no nonzero admissible local metric task survives; `UNDERDETERMINED` and `INCONSISTENT` force abstention. Where kernel inclusion fails, the correct bridge is a limiting correspondence rather than a function.

The battery constructs six distinct latent shear transports with identical observable projection and identical wall specialization. Hence the atlas bridge does not select cross-wall latent transport. The canonical cross-wall object supported by the tests is the observable compatibility relation.
