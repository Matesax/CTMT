import numpy as np
files=['omni_5min2022_asc.txt','omni_5min2023_asc.txt','omni_5min2024_asc.txt']
raw=np.vstack([np.loadtxt('/mnt/user-data/uploads/'+f) for f in files])
print("total rows:",raw.shape,"  years:",np.unique(raw[:,0]).astype(int))
# 0-based column map
col=dict(year=0,day=1,hour=2,minute=3,B=13,Bx=14,ByGSM=17,BzGSM=18,
         V=21,N=25,T=26,P=27,E=28,beta=29,MachA=30,AE=37,AL=38,AU=39,SYMH=41,ASYH=43,PC=44)
def clean(x,thr):
    x=x.copy(); x[np.abs(x)>=thr]=np.nan; return x
data={}
thr=dict(B=9999,Bx=9999,ByGSM=9999,BzGSM=9999,V=99999,N=999,T=9999999,P=99,E=999,beta=999,
         MachA=999,AE=9999,AL=9999,AU=9999,SYMH=9999,ASYH=9999,PC=999)
for k,c in col.items():
    data[k]=raw[:,c] if k in('year','day','hour','minute') else clean(raw[:,c],thr[k])
n=raw.shape[0]
print("\ncompleteness (fraction non-fill):")
drivers=['B','Bx','ByGSM','BzGSM','V','N','T','P','E']
resp=['AE','AL','AU','SYMH','ASYH']
for k in drivers+resp:
    print("   %-6s %.3f"%(k,np.mean(np.isfinite(data[k]))))
# rows with ALL drivers+response present
M=np.column_stack([data[k] for k in drivers+resp])
ok=np.all(np.isfinite(M),axis=1)
print("\nrows with all drivers+response present: %d / %d (%.1f%%)"%(ok.sum(),n,100*ok.mean()))
# absolute time in days since 2022-01-01, and phases
# day-of-year is per-year; build continuous day index
yr=data['year']; doy=data['day']; hr=data['hour']; mn=data['minute']
days_before={2022:0,2023:365,2024:730}
t=np.array([days_before[int(y)] for y in yr])+(doy-1)+hr/24+mn/1440
print("time span (days):",t.min(),"to",t.max())
np.savez('/tmp/omni.npz',**{k:data[k] for k in col},t=t,ok=ok)
print("saved /tmp/omni.npz")
import numpy as np
np.set_printoptions(precision=4,suppress=True)
d=np.load('/tmp/omni.npz'); rng=np.random.default_rng(0)
drivers=['B','Bx','ByGSM','BzGSM','V','N','T','P','E']; resp=['AE','AL','AU','SYMH','ASYH']
def prep(k,x):
    x=x.copy()
    if k in ('N','T','P'): x=np.log10(np.clip(x,1e-3,None))
    return x
D=np.column_stack([prep(k,d[k]) for k in drivers])
R=np.column_stack([prep(k,d[k]) for k in resp])
def isqrt(A):
    w,V=np.linalg.eigh(A);w=np.clip(w,1e-9,None);return V@np.diag(w**-0.5)@V.T
def rstd(X):
    med=np.nanmedian(X,0); mad=np.nanmedian(np.abs(X-med),0)+1e-9
    return np.clip((X-med)/(1.4826*mad),-8,8)
print("PILLAR 1 (real OMNI): infer magnetosphere response from solar-wind drivers, with lag")
print("  drivers:",drivers,"\n  response:",resp,"\n")
for lag in [0,6,12]:   # 0, 30 min, 60 min (5-min cadence)
    n=len(D)
    Dl=D[:n-lag] if lag>0 else D
    Rl=R[lag:] if lag>0 else R
    ok=np.all(np.isfinite(Dl),1)&np.all(np.isfinite(Rl),1)
    Ds=rstd(Dl[ok]); Rs=rstd(Rl[ok])
    C=np.cov(np.hstack([Ds,Rs]).T); p=len(drivers)
    SR=C[:p,:p]; Cc=C[:p,p:]; SN=C[p:,p:]
    rho=np.sort(np.linalg.svd(isqrt(SR)@Cc@isqrt(SN),compute_uv=False))[::-1]
    Schur=SN-Cc.T@np.linalg.inv(SR)@Cc; info=1-np.trace(Schur)/np.trace(SN)
    # OOS ridge R^2
    m=len(Ds); idx=rng.permutation(m); tr,te=idx[:int(.7*m)],idx[int(.7*m):]
    A=np.hstack([Ds[tr],np.ones((len(tr),1))]); B=np.linalg.solve(A.T@A+1e-2*np.eye(A.shape[1]),A.T@Rs[tr])
    pred=np.hstack([Ds[te],np.ones((len(te),1))])@B
    r2=1-((Rs[te]-pred)**2).sum(0)/((Rs[te]-Rs[tr].mean(0))**2).sum(0)
    print("lag=%2d steps (%2d min): n=%d  canon corr=%s  info=%.0f%%"%(lag,lag*5,ok.sum(),np.round(rho,3),100*info))
    print("             OOS R^2 [AE,AL,AU,SYMH,ASYH]=%s"%np.round(r2,3))
import numpy as np
np.set_printoptions(precision=4,suppress=True)
d=np.load('/tmp/omni.npz')
drivers=['B','Bx','ByGSM','BzGSM','V','N','T','P','E']; resp=['AE','AL','AU','SYMH','ASYH']
def prep(k,x):
    x=x.copy()
    if k in ('N','T','P'): x=np.log10(np.clip(x,1e-3,None))
    return x
feats=drivers+resp; X=np.column_stack([prep(k,d[k]) for k in feats]); t=d['t']; yr=d['year']
lag=6; n=len(X); pD=len(drivers)
Xl=np.column_stack([X[:n-lag,:pD],X[lag:,pD:]]); tl=t[:n-lag]; yl=yr[:n-lag]
ok=np.all(np.isfinite(Xl),1); Xl=Xl[ok]; tl=tl[ok]; yl=yl[ok]
med=np.median(Xl,0); mad=np.median(np.abs(Xl-med),0)+1e-9
Xs=np.clip((Xl-med)/(1.4826*mad),-8,8)
phase=(tl%365.25)/365.25
def frames(Xs,phase,K,p):
    lab=np.clip((phase*K).astype(int),0,K-1); fr=[]
    for k in range(K):
        Xk=Xs[lab==k]; C=np.cov(Xk.T); w,V=np.linalg.eigh(C); fr.append(V[:,np.argsort(w)[::-1][:p]])
    return fr
def holo(fr):
    p=fr[0].shape[1]; W=np.eye(p)
    for i in range(len(fr)):
        M=fr[i].T@fr[(i+1)%len(fr)]; U,s,Vt=np.linalg.svd(M); W=(U@Vt)@W
    return np.sort(np.abs(np.angle(np.linalg.eigvals(W))))[::-1][0]
def adj(fr,K): return np.mean([np.linalg.svd(fr[i].T@fr[(i+1)%K],compute_uv=False).min() for i in range(K)])
# eigenvalue spectrum (mean across seasonal bins) to find robust gap
lab=np.clip((phase*12).astype(int),0,11)
sp=np.mean([np.sort(np.linalg.eigvalsh(np.cov(Xs[lab==k].T)))[::-1] for k in range(12)],0)
print("mean per-bin eigenvalue spectrum:",np.round(sp,3))
print("eigenvalue ratios (gap finder):",np.round(sp[:-1]/sp[1:],2)[:6])
print("\nadjacent overlap & holonomy vs p (seasonal, K=12):")
for p in [1,2,3,4,5]:
    fr=frames(Xs,phase,12,p)
    print("   p=%d: mean adj overlap=%.3f  holonomy=%.4f"%(p,adj(fr,12),holo(fr) if p>1 else 0))
print("\nStable-p cross-year replication (p=2), seasonal, K=12 & 24:")
for K in [12,24]:
    frA=frames(Xs,phase,K,2); Ha=holo(frA); aA=adj(frA,K)
    yrH=[]
    for Y in [2022,2023,2024]:
        m=yl==Y; frY=frames(Xs[m],phase[m],K,2); yrH.append(holo(frY))
    print("   K=%2d: all-years H=%.4f (adj=%.3f) | per-year H=%s | spread=%.3f"%(
        K,Ha,aA,np.round(yrH,3),np.std(yrH)))
import numpy as np
np.set_printoptions(precision=4,suppress=True)
d=np.load('/tmp/omni.npz'); rng=np.random.default_rng(2)
drivers=['B','Bx','ByGSM','BzGSM','V','N','T','P','E']; resp=['AE','AL','AU','SYMH','ASYH']
def prep(k,x):
    x=x.copy()
    if k in ('N','T','P'): x=np.log10(np.clip(x,1e-3,None))
    return x
feats=drivers+resp; X=np.column_stack([prep(k,d[k]) for k in feats]); t=d['t']; yr=d['year']
lag=6; n=len(X); pD=len(drivers)
Xl=np.column_stack([X[:n-lag,:pD],X[lag:,pD:]]); tl=t[:n-lag]; yl=yr[:n-lag]
ok=np.all(np.isfinite(Xl),1); Xl=Xl[ok]; tl=tl[ok]; yl=yl[ok]
med=np.median(Xl,0); mad=np.median(np.abs(Xl-med),0)+1e-9
Xs=np.clip((Xl-med)/(1.4826*mad),-8,8); pD=len(drivers)
def isqrt(A):
    w,V=np.linalg.eigh(A);w=np.clip(w,1e-9,None);return V@np.diag(w**-0.5)@V.T
def coupling_frame(Xk,p):    # top-p canonical DRIVER directions (most geoeffective combos)
    C=np.cov(Xk.T); SR=C[:pD,:pD]; Cc=C[:pD,pD:]; SN=C[pD:,pD:]
    U,s,Vt=np.linalg.svd(isqrt(SR)@Cc@isqrt(SN))
    A=isqrt(SR)@U[:,:p]                       # driver-space canonical directions
    Q,_=np.linalg.qr(A); return Q,s[:p]
def holo(fr):
    p=fr[0].shape[1]; W=np.eye(p)
    for i in range(len(fr)):
        M=fr[i].T@fr[(i+1)%len(fr)]; U,s,Vt=np.linalg.svd(M); W=(U@Vt)@W
    return np.sort(np.abs(np.angle(np.linalg.eigvals(W))))[::-1][0]
def run(mask,phase_all,K,p,tag):
    Xm=Xs[mask]; ph=phase_all[mask]
    lab=np.clip((ph*K).astype(int),0,K-1); fr=[]; rhos=[]
    for k in range(K):
        Q,s=coupling_frame(Xm[lab==k],p); fr.append(Q); rhos.append(s[0])
    adj=np.mean([np.linalg.svd(fr[i].T@fr[(i+1)%K],compute_uv=False).min() for i in range(K)])
    print("   %-22s H=%.4f adj-overlap=%.3f leadrho~%.2f"%(tag,holo(fr),adj,np.mean(rhos)))
    return fr
seas=(tl%365.25)/365.25
print("COUPLING-FRAME holonomy (top-2 geoeffective driver directions), seasonal K=12:")
run(np.ones(len(Xs),bool),seas,12,2,"all years 2022-24")
for Y in [2022,2023,2024]: run(yl==Y,seas,12,2,"year %d"%Y)
# exclude the extreme May 2024 storm window (doy 125-140, 2024) to test its influence
exc=~((yl==2024)&((tl-730)>=124)&((tl-730)<=141))
run(exc,seas,12,2,"excl. May2024 storm")
print("\nInterpretation check: leading canonical correlation gap (robustness of top coupling dir):")
C=np.cov(Xs.T);SR=C[:pD,:pD];Cc=C[:pD,pD:];SN=C[pD:,pD:]
print("   canonical correlations:",np.round(np.linalg.svd(isqrt(SR)@Cc@isqrt(SN),compute_uv=False),3))
import numpy as np, itertools
np.set_printoptions(precision=3,suppress=True)
d=np.load('/tmp/omni.npz'); rng=np.random.default_rng(6)
By=d['ByGSM']; Bz=d['BzGSM']; t=d['t']; yr=d['year']
def rstd(x):
    m=np.nanmedian(x); s=np.nanmedian(np.abs(x-m))+1e-9; return (x-m)/(1.4826*s)
Bys=rstd(By); Bzs=rstd(Bz); lag=6; n=len(By); r=rstd(d['AL'])
Byl,Bzl,rl,tl,yl=Bys[:n-lag],Bzs[:n-lag],r[lag:],t[:n-lag],yr[:n-lag]
ok=np.isfinite(Byl)&np.isfinite(Bzl)&np.isfinite(rl)
Byl,Bzl,rl,tl,yl=[a[ok] for a in (Byl,Bzl,rl,tl,yl)]
def profile(mask,K,seas_override=None):
    seas=(tl[mask]%365.25)/365.25 if seas_override is None else seas_override
    lab=np.clip((seas*K).astype(int),0,K-1); B=np.column_stack([Byl[mask],Bzl[mask]]); rr=rl[mask]
    beta=np.zeros((K,2))
    for k in range(K):
        m=lab==k; A=B[m]; G=A.T@A+1e-3*np.eye(2); beta[k]=np.linalg.solve(G,A.T@rr[m])
    return beta
K=12
profs={Y:profile(yl==Y,K) for Y in [2022,2023,2024]}
obs=np.mean([np.corrcoef(profs[a][:,0],profs[b][:,0])[0,1] for a,b in itertools.combinations([2022,2023,2024],2)])
# permutation: shuffle season labels within each year (break season->coupling link), recompute cross-year r
null=[]
for _ in range(2000):
    pf={}
    for Y in [2022,2023,2024]:
        m=yl==Y; so=rng.random(m.sum()); pf[Y]=profile(m,K,seas_override=so)[:,0]
    null.append(np.mean([np.corrcoef(pf[a],pf[b])[0,1] for a,b in itertools.combinations([2022,2023,2024],2)]))
null=np.array(null); p=(np.sum(null>=obs)+1)/(len(null)+1)
print("AL, K=12: cross-year replication of geoeffective By-coupling profile")
print("  observed mean pairwise r = %.3f"%obs)
print("  permutation null: mean=%.3f  95th=%.3f  99th=%.3f  ->  p-value=%.4f"%(null.mean(),np.percentile(null,95),np.percentile(null,99),p))
# seasonal rotation of the coupling DIRECTION (angle), amplitude and winding
allb=profile(np.ones(len(rl),bool),K)
ang=np.degrees(np.arctan2(allb[:,0],allb[:,1]))
ang_un=np.unwrap(np.radians(ang*2))/2  # unwrap for winding
wind=np.degrees(ang_un[-1]-ang_un[0])
print("  coupling-direction angle range: %.1f deg (peak-to-peak seasonal rotation)"%(ang.max()-ang.min()))
print("  net winding around the year: %.1f deg (near 0 => rotates-and-returns, not topological)"%wind)
print("  => the coupling FRAME rotates seasonally and reproducibly; net holonomy ~ 0 (a stable wobble, not a wind)")
