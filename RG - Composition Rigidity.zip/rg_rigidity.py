"""Protocol-Composition Rigidity battery (C1-C6), run against the hash-frozen C0 specification.
Run: python rg_rigidity.py   (numpy, scipy)
"""
import json, math, hashlib, itertools, pathlib
import numpy as np
from scipy.spatial import ConvexHull
rng = np.random.default_rng(20261108)
RES = {}
def must(c, m):
    if not c: raise AssertionError(m)
spec = pathlib.Path("rg_rigidity_C0.json").read_bytes()
frozen = pathlib.Path("rg_rigidity_C0.sha256").read_text().strip()
must(hashlib.sha256(spec).hexdigest() == frozen, "C0 specification changed after freezing")
RES["C0"] = dict(sha256=frozen, status="FROZEN (verified before any gate ran)")

def herm_basis(d, field):
    """real basis of the self-adjoint d x d matrices over R (symmetric) or C (Hermitian)"""
    B = []
    for i in range(d):
        E = np.zeros((d, d), complex); E[i, i] = 1; B.append(E)
    for i in range(d):
        for j in range(i + 1, d):
            E = np.zeros((d, d), complex); E[i, j] = E[j, i] = 1; B.append(E)
            if field == "C":
                F = np.zeros((d, d), complex); F[i, j] = -1j; F[j, i] = 1j; B.append(F)
    return B
def vecR(M): return np.concatenate([M.real.ravel(), M.imag.ravel()])

# ------------------------------------------------------------------ C1 composition descent
# two preparations of the same operational state (maximally mixed qubit) with different hidden decompositions
k0, k1 = np.array([1, 0], complex), np.array([0, 1], complex)
kp, km = (k0 + k1) / math.sqrt(2), (k0 - k1) / math.sqrt(2)
dec_A = [(0.5, k0), (0.5, k1)]; dec_B = [(0.5, kp), (0.5, km)]
rho = lambda dec: sum(p * np.outer(v, v.conj()) for p, v in dec)
same_state = np.allclose(rho(dec_A), rho(dec_B))
ancilla = np.array([[0.7, 0.2], [0.2, 0.3]], complex)
desc = np.allclose(np.kron(rho(dec_A), ancilla), np.kron(rho(dec_B), ancilla))          # operational composition
def flag_composition(dec):                                                               # NON-descending: records hidden label
    return sum(p * np.kron(np.outer(v, v.conj()), np.outer(np.eye(2)[i], np.eye(2)[i])) for i, (p, v) in enumerate(dec))
fA, fB = flag_composition(dec_A), flag_composition(dec_B)
eff = np.kron(np.outer(kp, kp.conj()), np.outer(np.eye(2)[0], np.eye(2)[0]))
pA, pB = float(np.trace(eff @ fA).real), float(np.trace(eff @ fB).real)
must(same_state and desc and abs(pA - pB) > 0.2, "C1")
RES["C1"] = dict(status="LOCKED: operational composition descends; a representative-dependent 'composition' is rejected",
                 descending_composition_equal=bool(desc), hidden_label_composition_probabilities=[pA, pB])

# ------------------------------------------------------------------ C2 extension-tomography equivalence
def span_rank(mats): return np.linalg.matrix_rank(np.array([vecR(M) for M in mats]), tol=1e-9)
out2 = {}
for field in ("R", "C"):
    Bl = herm_basis(2, field); Bc = herm_basis(4, field)
    prod = [np.kron(a, b) for a in Bl for b in Bl]
    out2[field] = dict(local_dim=len(Bl), composite_dim=span_rank(Bc), product_span=span_rank(prod))
# real QM: identity and transpose agree on every single-system state, differ on a composite state
sy = np.array([[0, -1j], [1j, 0]]); syy = np.kron(sy, sy).real.astype(complex)
eps = 0.2; rp = (np.eye(4) + eps * syy) / 4; rm = (np.eye(4) - eps * syy) / 4
def partial_T(R):
    R4 = R.reshape(2, 2, 2, 2); return R4.transpose(2, 1, 0, 3).reshape(4, 4)
local_equal = all(np.allclose(B.T, B) for B in herm_basis(2, "R"))
ext_diff = np.allclose(partial_T(rp), rm) and not np.allclose(rp, rm)
must(out2["R"]["product_span"] < out2["R"]["composite_dim"] and out2["C"]["product_span"] == out2["C"]["composite_dim"]
     and local_equal and ext_diff, "C2")
RES["C2"] = dict(status="LOCKED: the local quotient of transformations is extension-complete iff the composite is spanned by products",
                 dims=out2, real_identity_vs_transpose=dict(equal_on_all_local_states=local_equal,
                                                            differ_on_composite_state=bool(ext_diff)),
                 theorem="If span(products) = composite space, linear maps that agree locally agree after any extension; otherwise "
                         "a map acting on the complement (here: transpose on sigma_y x sigma_y) is locally invisible but "
                         "extension-visible.")

# ------------------------------------------------------------------ C3 / C4 composite reconstruction and iterated closure
K = {"classical": lambda d: d, "real QM": lambda d: d * (d + 1) // 2, "complex QM": lambda d: d * d,
     "quaternionic QM": lambda d: d * (2 * d - 1)}
def in_family(fam, Kval):
    for n in range(1, 400):
        if K[fam](n) == Kval: return n
    return None
closure = {}
for fam in K:
    rows = []
    for nsys in range(2, 7):
        Kprod = K[fam](2) ** nsys
        rows.append(dict(copies=nsys, K_product=Kprod, K_family_at_dim=K[fam](2 ** nsys), family_dim=in_family(fam, Kprod)))
    closure[fam] = dict(locally_tomographic=all(r["K_product"] == r["K_family_at_dim"] for r in rows),
                        closes=all(r["family_dim"] is not None for r in rows), rows=rows)
closure["boxworld (square bits)"] = dict(locally_tomographic=True, closes=True,
                                       note="maximal tensor product of square bits is a boxworld system by definition")
must(closure["complex QM"]["closes"] and closure["classical"]["closes"] and not closure["real QM"]["closes"]
     and not closure["quaternionic QM"]["closes"], "C3/C4")
RES["C3_C4"] = dict(status="LOCKED: local tomography + in-family closure keep classical, complex QM and boxworld; real and quaternionic fail at two copies",
                    closure=closure, real_kernel_witness="rho_pm = (I +- 0.2 sy x sy)/4: equal on all local product effects, different globally",
                    quaternionic_witness="two quaternionic qubits: K = 36 needs n(2n-1) = 36 -> n = 4.5, not a quaternionic system")

# ------------------------------------------------------------------ C5 transformations: complete admissibility and reversibility
bell = np.zeros(4, complex); bell[0] = bell[3] = 1 / math.sqrt(2); RB = np.outer(bell, bell.conj())
def bloch_map(O):
    """qubit map induced by O in O(3) acting on Bloch vectors: rho = (I + r.sigma)/2"""
    sig = [np.array([[0, 1], [1, 0]], complex), sy, np.array([[1, 0], [0, -1]], complex)]
    def apply(R):
        tr = np.trace(R); r = np.array([np.trace(R @ s).real for s in sig]); r2 = O @ r
        return (tr * np.eye(2) + sum(r2[i] * sig[i] for i in range(3))) / 2
    return apply, sig
def extend_min_eig(O):
    apply, sig = bloch_map(O)
    out = np.zeros((4, 4), complex)
    for i in range(2):
        for j in range(2):
            Eij = np.zeros((2, 2), complex); Eij[i, j] = 1
            # linear extension: apply to the operator basis (linear in matrix entries)
            M = apply_linear(O, Eij); out += np.kron(M, RB.reshape(2, 2, 2, 2)[i, :, j, :])
    return float(np.linalg.eigvalsh((out + out.conj().T) / 2).min())
def apply_linear(O, X):
    sig = [np.array([[0, 1], [1, 0]], complex), sy, np.array([[1, 0], [0, -1]], complex)]
    c0 = np.trace(X) / 2; c = np.array([np.trace(X @ s) / 2 for s in sig]); c2 = O @ c
    return c0 * np.eye(2) + sum(c2[i] * sig[i] for i in range(3))
proper, improper = [], []
for _ in range(200):
    q, r = np.linalg.qr(rng.normal(size=(3, 3))); q = q * np.sign(np.diag(r))
    (proper if np.linalg.det(q) > 0 else improper).append(extend_min_eig(q))
must(min(proper) > -1e-12 and max(improper) < -0.4, "C5 complete admissibility")
def polygon_automorphisms(V):
    """affine maps permuting the vertices of a convex polygon (cyclic order preserved or reversed)"""
    n = len(V); found = set()
    for shift in range(n):
        for refl in (1, -1):
            perm = tuple((shift + refl * i) % n for i in range(n))
            X = np.c_[V, np.ones(n)]; Y = V[list(perm)]
            M, *_ = np.linalg.lstsq(X, Y, rcond=None)
            if np.allclose(X @ M, Y, atol=1e-9): found.add(perm)
    return len(found)
reg = {n: polygon_automorphisms(np.array([[math.cos(2 * math.pi * k / n), math.sin(2 * math.pi * k / n)] for k in range(n)]))
       for n in (2, 4, 5, 6, 8)}
rand_orders = []
for _ in range(300):
    P = rng.normal(size=(int(rng.integers(5, 12)), 2)); H = ConvexHull(P); V = P[H.vertices]
    rand_orders.append(polygon_automorphisms(V))
def superellipse_rot_defect(p, ang=0.3, N=720):
    th = np.linspace(0, 2 * math.pi, N, endpoint=False)
    r = (np.abs(np.cos(th)) ** p + np.abs(np.sin(th)) ** p) ** (-1 / p); pts = np.c_[r * np.cos(th), r * np.sin(th)]
    R = np.array([[math.cos(ang), -math.sin(ang)], [math.sin(ang), math.cos(ang)]]); q = pts @ R.T
    return float(np.max(np.abs((np.abs(q[:, 0]) ** p + np.abs(q[:, 1]) ** p) ** (1 / p) - 1)))
sup = {p: superellipse_rot_defect(p) for p in (1.5, 2.0, 3.0, 4.0)}
must(max(rand_orders) <= 12 and all(v < 50 for v in reg.values()) and sup[2.0] < 1e-12 and min(sup[p] for p in (1.5, 3.0, 4.0)) > 1e-3, "C5 reversibility")
RES["C5"] = dict(status="LOCKED: (a) extension-stable reversible qubit maps are exactly the proper rotations SO(3) = PU(2); "
                        "improper ones (transpose type) fail under extension; (b) every polytope bit has a finite reversible group "
                        "(no continuous connection of pure states); among the tested smooth bits only the ellipse/ball is continuously symmetric",
                 extension_min_eigenvalue=dict(proper_min=min(proper), improper_max=max(improper)),
                 regular_polygon_group_orders={str(k): v for k, v in reg.items()},
                 random_polygons=dict(count=300, max_group_order=max(rand_orders), histogram={str(k): rand_orders.count(k) for k in sorted(set(rand_orders))}),
                 superellipse_rotation_defect={str(k): v for k, v in sup.items()},
                 generators="so(3) = su(2): 3 = d^2 - 1 real generators (traceless Hermitian, i.e. Hamiltonians); imported Wigner/Kadison for d > 2")

# ------------------------------------------------------------------ C6 correlations as comparators (after the gates)
classical = max(abs(a0 * b0 + a0 * b1 + a1 * b0 - a1 * b1) for a0, a1, b0, b1 in itertools.product((1, -1), repeat=4))
def chsh_q(t):
    A = [np.array([[1, 0], [0, -1]]), np.array([[0, 1], [1, 0]])]
    Bm = [math.cos(t) * A[0] + math.sin(t) * A[1], math.cos(t) * A[0] - math.sin(t) * A[1]]
    op = np.kron(A[0], Bm[0]) + np.kron(A[0], Bm[1]) + np.kron(A[1], Bm[0]) - np.kron(A[1], Bm[1])
    return float(np.linalg.eigvalsh(op).max())
quantum = max(chsh_q(t) for t in np.linspace(0, math.pi, 2001))
must(classical == 2 and abs(quantum - 2 * math.sqrt(2)) < 1e-5, "C6")
RES["C6"] = dict(status="COMPARATOR: classical 2, complex QM 2 sqrt 2 (Tsirelson), boxworld PR box 4",
                 classical=classical, complex_qm=quantum, boxworld=4)

# ------------------------------------------------------------------ rigidity chain and obstruction certificates
chain = [
    dict(stage="R0", survivors=["classical", "real QM", "complex QM", "quaternionic QM", "boxworld", "polygon bits", "random polygon bits", "superellipse bits"]),
    dict(stage="R1 = R0 | G1 descent", survivors=["classical", "real QM", "complex QM", "quaternionic QM", "boxworld", "polygon bits", "random polygon bits", "superellipse bits"],
         removed=["representative-dependent (hidden-label) compositions"]),
    dict(stage="R2 = R1 | G2+G3 extension completeness + closure", survivors=["classical", "complex QM", "boxworld", "polygon bits", "random polygon bits", "superellipse bits"],
         removed={"real QM": "two-copy kernel sigma_y x sigma_y; identity ~ transpose locally", "quaternionic QM": "no in-family composite (n = 4.5)"}),
    dict(stage="R3 = R2 | G4 continuous extension-stable reversibility", survivors=["complex QM"],
         removed={"classical": "reversible group S2 (finite)", "boxworld": "square group order 8", "polygon bits": "dihedral, finite",
                  "random polygon bits": f"group order <= {max(rand_orders)}", "superellipse bits": "rotation defect > 1e-3"}),
]
certs = {"real vs complex": "two-copy joint effect sigma_y x sigma_y (local tomography)",
         "quaternionic vs complex": "two-copy closure arithmetic",
         "classical vs complex": "continuous reversibility; CHSH 2 vs 2 sqrt 2",
         "boxworld vs complex": "continuous reversibility; CHSH 4 vs 2 sqrt 2",
         "polygon vs complex": "finite reversible group"}
RES["rigidity"] = dict(chain=chain, obstruction_certificates=certs, strict=True,
                       unrestricted_space="IMPORTED: Hardy 2001; Chiribella-D'Ariano-Perinotti 2011; Masanes-Mueller 2011 (with their subspace/measurement axioms)")
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_rigidity_results.json").write_text(json.dumps(RES, indent=1, default=float))
for k, v in RES.items():
    if isinstance(v, dict) and "status" in v: print(k, "|", v["status"][:150])
print("random polygon group orders:", RES["C5"]["random_polygons"]["histogram"], "regular:", reg)
print("ext:", RES["C5"]["extension_min_eigenvalue"], "CHSH:", classical, quantum)
