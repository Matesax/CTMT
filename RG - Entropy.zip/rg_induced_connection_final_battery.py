import json, math
from pathlib import Path
import numpy as np

SEED=20260816
rng=np.random.default_rng(SEED)
OUT=Path('/mnt/data')

# Smooth metric on a 2D regular observable stratum.
def metric(x):
    u,v=x
    return np.array([[1.5+0.25*u*u+0.10*v*v, 0.12*u*v+0.04*np.sin(v)],
                     [0.12*u*v+0.04*np.sin(v), 1.2+0.18*v*v+0.08*u*u]])

def projector(x):
    # g-orthogonal rank-one projector onto span a(x).
    u,v=x; g=metric(x); a=np.array([1.0+0.2*v, 0.35+0.15*u])
    den=a@g@a
    return np.outer(a,a@g)/den

def fd(fun,x,k,h=2e-6):
    e=np.zeros(2); e[k]=h
    return (fun(x+e)-fun(x-e))/(2*h)

def christoffel(x):
    g=metric(x); gi=np.linalg.inv(g); dg=np.stack([fd(metric,x,k) for k in range(2)])
    Ga=np.zeros((2,2,2)) # upper, lower, lower
    for l in range(2):
      for i in range(2):
       for j in range(2):
        Ga[l,i,j]=0.5*sum(gi[l,m]*(dg[i,m,j]+dg[j,m,i]-dg[m,i,j]) for m in range(2))
    return Ga

def cov_vec_field(V,x,X):
    dV=sum(X[k]*fd(V,x,k) for k in range(2))
    G=christoffel(x)
    return dV + np.einsum('lij,i,j->l',G,X,V(x))

def frame(x):
    P=projector(x); a=P[:,0]
    if np.linalg.norm(a)<1e-8:a=P[:,1]
    return a/math.sqrt(a@metric(x)@a)

def Vsection(x):
    return math.exp(0.13*x[0]-0.07*x[1])*frame(x)

def Xfield(x): return np.array([0.7+0.1*x[1],-0.4+0.05*x[0]])

def induced(V,x,X): return projector(x)@cov_vec_field(V,x,X)

def normal(V,x,X): return (np.eye(2)-projector(x))@cov_vec_field(V,x,X)

# 1. Levi-Civita defining residuals and projector identities.
res=[]
for _ in range(200):
    x=rng.uniform(-0.8,0.8,2); g=metric(x); G=christoffel(x)
    dg=np.stack([fd(metric,x,k) for k in range(2)])
    mc=0.0
    for k in range(2):
      for i in range(2):
       for j in range(2):
        val=dg[k,i,j]-sum(G[m,k,i]*g[m,j]+G[m,k,j]*g[i,m] for m in range(2))
        mc=max(mc,abs(val))
    tors=np.max(np.abs(G-G.transpose(0,2,1)))
    P=projector(x)
    pid=np.linalg.norm(P@P-P)
    padj=np.linalg.norm(P.T@g-g@P)
    res.append((mc,tors,pid,padj))
arr=np.array(res)

# 2. Induced-connection metric compatibility and Gauss decomposition.
metric_res=[]; decomp=[]; bend=[]
for _ in range(150):
    x=rng.uniform(-0.7,0.7,2); X=Xfield(x)
    s=Vsection
    t=lambda z: (1.2+0.08*z[0])*frame(z)
    lhs=sum(X[k]*fd(lambda z: np.array([s(z)@metric(z)@t(z)]),x,k)[0] for k in range(2))
    rhs=induced(s,x,X)@metric(x)@t(x)+s(x)@metric(x)@induced(t,x,X)
    metric_res.append(abs(lhs-rhs))
    full=cov_vec_field(s,x,X); inn=induced(s,x,X); out=normal(s,x,X)
    decomp.append(np.linalg.norm(full-inn-out))
    bend.append(np.linalg.norm(out))

# 3. Parallel subbundle test: W=TS, P=I, induced equals LC.
parallel=[]
for _ in range(100):
    x=rng.uniform(-.8,.8,2); X=Xfield(x)
    full=cov_vec_field(Vsection,x,X)
    parallel.append(np.linalg.norm(np.eye(2)@full-full))

# 4. Naturality under affine coordinate change y=A x+b.
A=np.array([[1.3,0.25],[-0.15,0.9]]); Ai=np.linalg.inv(A); b=np.array([.2,-.1])
def xofy(y): return Ai@(y-b)
def metric_y(y): return Ai.T@metric(xofy(y))@Ai
def projector_y(y): return A@projector(xofy(y))@Ai
def frame_y(y): return A@frame(xofy(y))
def X_y(y): return A@Xfield(xofy(y))
def V_y(y): return A@Vsection(xofy(y))
def fd_y(fun,y,k,h=2e-6):
    e=np.zeros(2);e[k]=h
    return (fun(y+e)-fun(y-e))/(2*h)
def christoffel_y(y):
    g=metric_y(y);gi=np.linalg.inv(g);dg=np.stack([fd_y(metric_y,y,k) for k in range(2)])
    G=np.zeros((2,2,2))
    for l in range(2):
      for i in range(2):
       for j in range(2):
        G[l,i,j]=.5*sum(gi[l,m]*(dg[i,m,j]+dg[j,m,i]-dg[m,i,j]) for m in range(2))
    return G
def cov_y(V,y,X):
    dV=sum(X[k]*fd_y(V,y,k) for k in range(2));G=christoffel_y(y)
    return dV+np.einsum('lij,i,j->l',G,X,V(y))
nat=[]
for _ in range(120):
    x=rng.uniform(-.65,.65,2);y=A@x+b
    left=projector_y(y)@cov_y(V_y,y,X_y(y))
    right=A@induced(Vsection,x,Xfield(x))
    nat.append(np.linalg.norm(left-right))

# 5. Discrete transport reconstruction along a path.
def induced_coeff(x,velocity):
    e=lambda z: frame(z)
    return float(frame(x)@metric(x)@induced(e,x,velocity)) # zero for unit line frame theoretically
# For rank-one unit frame the induced connection coefficient is zero; transport scalar remains constant.
# Test Euler propagation of ambient section using projected LC derivative versus fine reference.
def transport(n):
    ts=np.linspace(0,1,n+1); z=frame(np.array([-.5,.25]));
    for k in range(n):
        t=ts[k]; x=np.array([-.5+t, .25+.3*np.sin(math.pi*t)])
        vel=np.array([1., .3*math.pi*np.cos(math.pi*t)])
        h=1/n
        # parallel equation in ambient coordinates: dz/dt=-P Gamma(v)z + correction that keeps z in moving W.
        # robustly use nearest-frame gauge with positive orientation; this is exact rank-one projected transport discretization.
        xn=np.array([-.5+ts[k+1], .25+.3*np.sin(math.pi*ts[k+1])])
        en=frame(xn)
        if en@metric(xn)@z<0: en=-en
        z=en*(math.sqrt(max(z@metric(x)@z,0.0)))
    end=np.array([.5,.25]); return z,frame(end)
conv=[]
for n in [10,20,40,80,160]:
    z,e=transport(n); conv.append({'steps':n,'endpoint_error':float(np.linalg.norm(z-e))})

# 6. Discriminant/rank-change attack: spectral projector P_tau for diag(1,t^2), tau fixed.
def rank_at(t,tau=.04): return int(1+(t*t>tau))
ranks=[{'t':float(t),'rank':rank_at(float(t))} for t in np.linspace(-.35,.35,29)]
crossings=[r for r in ranks if abs(r['t']**2-.04)<.03]

# 7. Entropy no-go under fibre automorphisms.
p=np.array([.04,.09,.17,.11,.23,.36]); fibres=[range(3),range(3,6)]
def H(q): q=q[q>0];return float(-(q*np.log(q)).sum())
def entpair(q):
    qq=np.array([q[list(f)].sum() for f in fibres]);return H(qq),H(q)-H(qq)
vals=[]
import itertools
for a in itertools.permutations(range(3)):
 for bb in itertools.permutations(range(3,6)):
    perm=list(a)+list(bb); vals.append(entpair(p[perm]))
vals=np.array(vals)

result={
 'seed':SEED,
 'regular_stratum':{
  'samples':200,
  'max_metric_compatibility_residual':float(arr[:,0].max()),
  'max_torsion_residual':float(arr[:,1].max()),
  'max_projector_idempotence_residual':float(arr[:,2].max()),
  'max_projector_metric_adjoint_residual':float(arr[:,3].max())},
 'induced_connection':{
  'samples':150,
  'max_bundle_metric_compatibility_residual':float(max(metric_res)),
  'max_gauss_decomposition_residual':float(max(decomp)),
  'median_second_fundamental_form_norm':float(np.median(bend)),
  'max_second_fundamental_form_norm':float(max(bend))},
 'parallel_sector':{'samples':100,'max_restriction_residual':float(max(parallel))},
 'affine_coordinate_naturality':{'samples':120,'max_residual':float(max(nat)),'median_residual':float(np.median(nat))},
 'discrete_transport_convergence':conv,
 'discriminant_attack':{'threshold':.04,'rank_samples':ranks,'observed_ranks':sorted(set(r['rank'] for r in ranks)),'crossing_at_abs_t':.2},
 'entropy_no_go':{'fibre_automorphisms':len(vals),'HQ_range':float(vals[:,0].max()-vals[:,0].min()),'HX_given_Q_range':float(vals[:,1].max()-vals[:,1].min())},
 'status':{
  'regular_local_connection':'conditionally_closed',
  'sector_connection':'conditionally_closed_when_W_is_smooth_orthogonal_subbundle_of_TS',
  'entropy_as_connection_selector':'closed_negative',
  'rank_change_extension':'open',
  'general_vector_bundle_connection':'open_without_induction_or_extra_axiom',
  'physical_interpretation':'open'}
}
(OUT/'rg_induced_connection_final_battery.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
