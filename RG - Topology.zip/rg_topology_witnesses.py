"""Witnesses for 'RG Topology: the resolution interior'. Exact or deterministic; no random sampling.
T1 sufficiency: the uniform-confidence verifier for U = (0.3, 0.7) (Bernoulli) is sound at level alpha for every theta outside U,
   and its acceptance probability at theta = 0.5 tends to 1 (exact binomial sums)
T2 necessity: |P_x^n(acc) - P_y^n(acc)| <= n TV(P_x, P_y) for every test (exact check on the verifier)
T3 Kolmogorov quotient = observational quotient on a finite state space (exact)
T4 one-sided protocol: noise-free arrival detector gives the Sierpinski topology (T0, not T1); onset is lower semicontinuous
T5 the functor to topology is not faithful: Bernoulli(sin^2(theta/2)) and two iid Bernoulli(sin^2(theta/(2 sqrt 2))) give the same
   topology on (0, pi) but are not Blackwell equivalent (Hellinger affinities differ)
T6 the fold: the overlap protocol's T0 quotient identifies b and 2d - b; the signed protocol separates them
T7 reach: a finite non-Hausdorff T0 space is recovered exactly from one-sided protocols; the circle embeds via two Bernoulli coins
Run: python rg_topology_witnesses.py   (sympy, mpmath)
"""
import json, math, hashlib, pathlib, itertools
import sympy as sp
import mpmath as mp
RES = {}
def must(c, m):
    if not c: raise AssertionError(m)
mp.mp.dps = 40
alpha = mp.mpf("0.05")
def rho(n): return mp.sqrt(mp.log(2 / alpha) / (2 * n))           # Hoeffding uniform radius
def accept_prob(theta, n, lo=mp.mpf("0.3"), hi=mp.mpf("0.7")):
    r = rho(n); tot = mp.mpf(0)
    for k in range(n + 1):
        f = mp.mpf(k) / n
        if f - r > lo and f + r < hi:                              # the confidence ball around the empirical law lies inside U
            tot += mp.binomial(n, k) * mp.mpf(theta) ** k * (1 - mp.mpf(theta)) ** (n - k)
    return tot
rows = []
for n in (50, 200, 800, 3200):
    worst_out = max(accept_prob(th, n) for th in [mp.mpf(v) / 1000 for v in list(range(1, 301)) + list(range(700, 1000))][::7])
    rows.append(dict(n=n, worst_false_acceptance=float(worst_out), acceptance_at_0p5=float(accept_prob(mp.mpf("0.5"), n))))
must(all(r["worst_false_acceptance"] <= 0.05 for r in rows) and rows[-1]["acceptance_at_0p5"] > 0.999 and rows[0]["acceptance_at_0p5"] < rows[-1]["acceptance_at_0p5"], "T1")
RES["T1"] = dict(claim="Uniform-confidence verifier: sound at alpha = 0.05 outside U, acceptance -> 1 inside U", status="PROVED (Hoeffding) + exact binomial sums", rows=rows)
# T2 necessity bound
n = 50; x_, y_ = mp.mpf("0.5"), mp.mpf("0.52")
lhs = abs(accept_prob(x_, n) - accept_prob(y_, n)); rhs = n * abs(x_ - y_)
must(lhs <= rhs, "T2")
RES["T2"] = dict(claim="Acceptance probabilities with n records are n*TV-Lipschitz in the law: a set verifiable at x contains a law-neighbourhood of x",
                 status="PROVED (coupling) + exact instance", lhs=float(lhs), rhs=float(rhs))
# T3 finite state space: states with laws; topology = preimages of open sets of the (discrete, finite) law image
laws = {"s1": (0.2, 0.8), "s2": (0.2, 0.8), "s3": (0.5, 0.5), "s4": (0.9, 0.1)}
classes = {}
for s_, L in laws.items(): classes.setdefault(L, []).append(s_)
opens = set()
img = list(classes)
for r_ in range(len(img) + 1):
    for sub in itertools.combinations(img, r_):
        opens.add(frozenset(s for L in sub for s in classes[L]))
def indist(a, b): return all((a in U) == (b in U) for U in opens)
kq = {}
for s_ in laws: kq.setdefault(frozenset(t for t in laws if indist(s_, t)), None)
must(set(kq) == {frozenset(v) for v in classes.values()}, "T3")
RES["T3"] = dict(claim="The Kolmogorov (T0) quotient of the verifiability topology equals the observational quotient", status="PROVED + exact finite instance",
                 classes=[sorted(c) for c in kq])
# T4 Sierpinski: arrival detector, states 'arrived' / 'not', verifiable: {} , {arrived}, {both}
opens4 = [frozenset(), frozenset({"arrived"}), frozenset({"arrived", "not"})]
t0 = all(any((a in U) != (b in U) for U in opens4) for a, b in [("arrived", "not")])
t1 = any("not" in U and "arrived" not in U for U in opens4)
must(t0 and not t1, "T4")
RES["T4"] = dict(claim="A noise-free one-sided detector verifies 'arrived' but not 'not arrived': the Sierpinski space (T0, not T1); exact onset is lower semicontinuous",
                 status="PROVED (exact)", opens=[sorted(U) for U in opens4])
# T5 functor not faithful
d = sp.Integer(1)
aff1 = sp.cos(d / 2); aff2 = sp.cos(d / (2 * sp.sqrt(2))) ** 2
th = sp.Symbol("theta", positive=True)
inj1 = sp.diff(sp.sin(th / 2) ** 2, th); inj2 = sp.diff(sp.sin(th / (2 * sp.sqrt(2))) ** 2, th)
must(abs(float(aff1 - aff2)) > 1e-3 and sp.simplify(inj1) != 0, "T5")
RES["T5"] = dict(claim="Both experiments are injective homeomorphisms of (0, pi) onto their law images (same topology) but are not Blackwell equivalent",
                 status="PROVED", affinities=[float(aff1), float(aff2)])
# T6 fold
b, dd, w0 = sp.symbols("b d w0", positive=True)
o = sp.exp(-((b - dd) / w0) ** 2); s_ = sp.tanh((b - dd) / w0)
must(sp.simplify(o.subs(b, 2 * dd - b) - o) == 0 and sp.simplify(s_.subs(b, 2 * dd - b) + s_) == 0, "T6")
RES["T6"] = dict(claim="Overlap protocol: b and 2d - b are topologically indistinguishable (T0 quotient |b - d|); the signed protocol separates them",
                 status="PROVED (symbolic)")
# T7 reach: finite T0 space X = {a, b, c} with opens {}, {a}, {a, b}, X (a chain): one-sided detectors D1 = [x in {a}], D2 = [x in {a, b}]
X = ["a", "b", "c"]; target = {frozenset(), frozenset({"a"}), frozenset({"a", "b"}), frozenset(X)}
verif = [frozenset({"a"}), frozenset({"a", "b"})]
gen = {frozenset(), frozenset(X)}
for r_ in range(1, len(verif) + 1):
    for sub in itertools.combinations(verif, r_):
        inter = frozenset(X)
        for U in sub: inter &= U
        gen.add(inter)
closed = set(gen)
for r_ in range(1, len(gen) + 1):
    for sub in itertools.combinations(list(gen), r_):
        closed.add(frozenset().union(*sub))
must(closed == target, "T7 finite")
phi = sp.Symbol("phi", real=True)
emb = ((1 + sp.cos(phi)) / 2, (1 + sp.sin(phi)) / 2)
must(all(0 <= float(e.subs(phi, v)) <= 1 for e in emb for v in (0, 1, 2, 3, 4, 5, 6)), "T7 circle")
RES["T7"] = dict(claim="Reach: a finite T0 non-Hausdorff space is recovered from one-sided protocols; the circle is the verifiability topology of two Bernoulli coins "
                       "(cos, sin) - embeddings into Sierpinski^N and [0,1]^N give every second-countable T0 / separable metrizable space",
                 status="PROVED (classical embeddings) + exact instances", recovered_opens=sorted(sorted(U) for U in closed))
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_topology_witnesses_results.json").write_text(json.dumps(RES, indent=1, default=str))
for k_, v in RES.items():
    if isinstance(v, dict): print(k_, "|", v["status"])
print(rows)
