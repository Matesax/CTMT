"""Spacetime from a mesh of local systems (kinematic lock).
Inputs are ONLY local protocol data between neighbouring local systems: ruler lengths of shared edges and clock ratios
between neighbours. No ambient spacetime, no coordinates are used to compute the outputs.
M1  closed surface: curvature = deficit (holonomy) of glued flat triangles; total = 2 pi chi exactly; density -> 1/R^2.
M2  holonomy: frame transport around a loop of local systems rotates by the enclosed deficit (flat single system: 0).
M3  Schwarzschild spatial slice: deficit density -> K = -m/r^3 from ruler data alone.
M4  clock-ratio links along a radial chain: tidal Hessian of the lapse -> -2m/r^3 (electric part of Riemann).
M5  canaries: flat mesh has zero deficit everywhere; a cone concentrates its whole deficit at the apex.
Run: python rg_mesh_spacetime.py   (numpy, scipy)
"""
import json, math, hashlib, pathlib, itertools
import numpy as np
from scipy.integrate import quad
RES = {}
def must(c, m):
    if not c: raise AssertionError(m)
def tri_angles(a, b, c):
    """angles of a flat triangle from its three edge lengths (law of cosines): the local system's own geometry"""
    A = math.acos(max(-1, min(1, (b * b + c * c - a * a) / (2 * b * c))))
    B = math.acos(max(-1, min(1, (a * a + c * c - b * b) / (2 * a * c))))
    return A, B, math.pi - A - B
def tri_area(a, b, c):
    s = (a + b + c) / 2; return math.sqrt(max(s * (s - a) * (s - b) * (s - c), 0))
def deficits(n_vertices, faces, length):
    """vertex deficits 2 pi - sum of incident triangle angles, and barycentric dual areas"""
    ang = np.zeros(n_vertices); area = np.zeros(n_vertices)
    for (i, j, k) in faces:
        a, b, c = length(j, k), length(i, k), length(i, j)   # opposite i, j, k
        A, B, C = tri_angles(a, b, c); ar = tri_area(a, b, c)
        ang[i] += A; ang[j] += B; ang[k] += C
        for v in (i, j, k): area[v] += ar / 3
    return 2 * math.pi - ang, area

# ---------------- M1 sphere: icosphere, geodesic ruler lengths (local measurement), no embedding used downstream
def icosphere(level):
    t = (1 + 5 ** 0.5) / 2
    V = [(-1, t, 0), (1, t, 0), (-1, -t, 0), (1, -t, 0), (0, -1, t), (0, 1, t), (0, -1, -t), (0, 1, -t),
         (t, 0, -1), (t, 0, 1), (-t, 0, -1), (-t, 0, 1)]
    V = [np.array(v) / np.linalg.norm(v) for v in V]
    F = [(0, 11, 5), (0, 5, 1), (0, 1, 7), (0, 7, 10), (0, 10, 11), (1, 5, 9), (5, 11, 4), (11, 10, 2), (10, 7, 6), (7, 1, 8),
         (3, 9, 4), (3, 4, 2), (3, 2, 6), (3, 6, 8), (3, 8, 9), (4, 9, 5), (2, 4, 11), (6, 2, 10), (8, 6, 7), (9, 8, 1)]
    for _ in range(level):
        cache = {}; newF = []
        def mid(i, j):
            key = tuple(sorted((i, j)))
            if key not in cache:
                m = V[i] + V[j]; V.append(m / np.linalg.norm(m)); cache[key] = len(V) - 1
            return cache[key]
        for (a, b, c) in F:
            ab, bc, ca = mid(a, b), mid(b, c), mid(c, a)
            newF += [(a, ab, ca), (b, bc, ab), (c, ca, bc), (ab, bc, ca)]
        F = newF
    return V, F
Rs = 2.0; m1 = {}
for level in (1, 2, 3, 4):
    V, F = icosphere(level)
    geo = lambda i, j: Rs * math.acos(max(-1, min(1, float(V[i] @ V[j]))))     # ruler length along the surface
    d, A = deficits(len(V), F, geo)
    m1[level] = dict(vertices=len(V), total_deficit_over_4pi=float(d.sum() / (4 * math.pi)),
                     max_rel_err_K=float(np.max(np.abs(d / A * Rs * Rs - 1))))
    must(abs(d.sum() - 4 * math.pi) < 1e-9, "Gauss-Bonnet")
must(m1[4]["max_rel_err_K"] < m1[1]["max_rel_err_K"] and m1[4]["max_rel_err_K"] < 0.02, "convergence")
RES["M1"] = dict(claim="Curvature of a closed surface from glued flat local systems (ruler data only)",
                 status="LOCKED (exact Gauss-Bonnet; convergence to K = 1/R^2)", levels=m1)

# ---------------- M2 holonomy around a vertex = deficit (transport of a frame through the ring of local systems)
V, F = icosphere(2); geo = lambda i, j: Rs * math.acos(max(-1, min(1, float(V[i] @ V[j]))))
v0 = 0; ring = [f for f in F if v0 in f]
rot = sum(tri_angles(*[geo(*e) for e in [(f[1], f[2]), (f[0], f[2]), (f[0], f[1])]])[f.index(v0)] for f in ring)
hol = 2 * math.pi - rot
d, _ = deficits(len(V), F, geo)
must(abs(hol - d[v0]) < 1e-12 and hol > 0, "holonomy")
RES["M2"] = dict(claim="A frame carried through the ring of local systems around a vertex returns rotated by the deficit",
                 status="LOCKED", holonomy_rad=hol, flat_single_system=0.0)

# ---------------- M3 Schwarzschild equatorial spatial slice from ruler lengths
m = 1.0
def ruler(p, q):
    """proper length of the straight coordinate segment p->q in dl^2 = dr^2/(1-2m/r) + r^2 dphi^2 (the local measurement)"""
    (r1, f1), (r2, f2) = p, q
    def integrand(s):
        r = r1 + s * (r2 - r1); dr = r2 - r1; df = f2 - f1
        return math.sqrt(dr * dr / (1 - 2 * m / r) + r * r * df * df)
    return quad(integrand, 0, 1, epsabs=1e-13)[0]
def grid(nr, nf, r0=4.0, r1=12.0, fspan=0.6):
    rs = np.linspace(r0, r1, nr); fs = np.linspace(-fspan / 2, fspan / 2, nf)
    P = [(r, f) for r in rs for f in fs]; idx = lambda i, j: i * nf + j; F = []
    for i in range(nr - 1):
        for j in range(nf - 1):
            F += [(idx(i, j), idx(i + 1, j), idx(i + 1, j + 1)), (idx(i, j), idx(i + 1, j + 1), idx(i, j + 1))]
    return P, F, nr, nf
m3 = {}
for nr, nf in ((9, 9), (17, 17), (33, 33)):
    P, F, _, _ = grid(nr, nf); cache = {}
    def L(i, j):
        key = (min(i, j), max(i, j))
        if key not in cache: cache[key] = ruler(P[i], P[j])
        return cache[key]
    d, A = deficits(len(P), F, L)
    interior = [i * nf + j for i in range(1, nr - 1) for j in range(1, nf - 1)]
    errs = [abs(d[v] / A[v] - (-m / P[v][0] ** 3)) / (m / P[v][0] ** 3) for v in interior]
    m3[f"{nr}x{nf}"] = dict(median_rel_err=float(np.median(errs)), sample_r=P[interior[len(interior) // 2]][0],
                           K_mesh=float(d[interior[len(interior) // 2]] / A[interior[len(interior) // 2]]),
                           K_true=-m / P[interior[len(interior) // 2]][0] ** 3)
keys = list(m3)
must(m3[keys[-1]]["median_rel_err"] < m3[keys[0]]["median_rel_err"] and m3[keys[-1]]["median_rel_err"] < 0.1, "M3")
RES["M3"] = dict(claim="Spatial curvature of a Schwarzschild slice from ruler data between local systems",
                 status="LOCKED (convergent; interior vertices)", grids=m3)

# ---------------- M4 tidal field from clock-ratio links along a radial chain (static frame)
rs = np.linspace(4.0, 12.0, 4001)
ds = [quad(lambda r: 1 / math.sqrt(1 - 2 * m / r), a, b)[0] for a, b in zip(rs[:-1], rs[1:])]   # ruler links
ratios = [math.sqrt((1 - 2 * m / b) / (1 - 2 * m / a)) for a, b in zip(rs[:-1], rs[1:])]      # clock-ratio links
logN = np.concatenate([[0.0], np.cumsum(np.log(ratios))])                                    # lapse up to a constant
s = np.concatenate([[0.0], np.cumsum(ds)]); N = np.exp(logN)
dN = np.gradient(N, s); d2N = np.gradient(dN, s); tidal = d2N / N
probe = {r: (float(np.interp(r, rs, tidal)), -2 * m / r ** 3) for r in (5.0, 7.0, 10.0)}
must(all(abs(a - b) / abs(b) < 1e-3 for a, b in probe.values()), "M4")
RES["M4"] = dict(claim="Radial tidal component from clock-ratio and ruler links only (no coordinates, no metric)",
                 status="LOCKED (lapse fixed up to a constant, which drops out)", probes={str(k): dict(mesh=a, exact=b) for k, (a, b) in probe.items()})

# ---------------- M5 canaries
P, F, nr, nf = grid(9, 9)
flat = lambda i, j: math.dist((P[i][0] * math.cos(P[i][1]), P[i][0] * math.sin(P[i][1])), (P[j][0] * math.cos(P[j][1]), P[j][0] * math.sin(P[j][1])))
d0, _ = deficits(len(P), F, flat)
interior = [i * nf + j for i in range(1, nr - 1) for j in range(1, nf - 1)]
flat_max = float(max(abs(d0[v]) for v in interior))
# cone with total angle 2pi(1 - delta): fan of 6 triangles around an apex with edge lengths of a cone
delta = 0.2; apex_angle = 2 * math.pi * (1 - delta) / 6
cone_def = 2 * math.pi - 6 * tri_angles(2 * math.sin(apex_angle / 2), 1, 1)[0]
must(flat_max < 1e-9 and abs(cone_def - 2 * math.pi * delta) < 1e-12, "M5")
RES["M5"] = dict(claim="Canaries", status="LOCKED", flat_mesh_max_deficit=flat_max, cone_apex_deficit=cone_def,
                 cone_expected=2 * math.pi * delta)
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_mesh_spacetime_results.json").write_text(json.dumps(RES, indent=1, default=float))
for k, v in RES.items():
    if isinstance(v, dict): print(k, v["status"])
print(json.dumps(m1, indent=0)); print(json.dumps(m3, indent=0)); print(probe)
