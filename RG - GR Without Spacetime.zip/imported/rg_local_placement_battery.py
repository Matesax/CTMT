import numpy as np, pandas as pd
from scipy.linalg import expm
from scipy.optimize import least_squares
from pathlib import Path
O=Path('/mnt/data'); seed=20261027
C=np.array([[1,0,0,0],[0,0,1,0]],float)
true=np.array([1.,1.42,.18,.035,.055]); xtrue=np.array([1.,.25,-.55,.40])
def A(p):
 w1,w2,k,g1,g2=p; return np.array([[0,1,0,0],[-(w1*w1+k),-g1,k,0],[0,0,0,1],[k,0,-(w2*w2+k),-g2]])
def D(p,t): return np.vstack([C@expm(A(p)*q) for q in t])
def predict(p,x,t): return np.array([C@expm(A(p)*q)@x for q in t])
def fit(t,y,full=True):
 p0=np.array([.9,1.3,.12,.05,.05]) if full else np.array([.9,1.3,.05,.05])
 lo=np.array([.55,.8,0,.001,.001]) if full else np.array([.55,.8,.001,.001]); hi=np.array([1.5,2,.5,.2,.2]) if full else np.array([1.5,2,.2,.2])
 unpack=(lambda p:p) if full else (lambda p:np.array([p[0],p[1],0,p[2],p[3]]))
 def r(p):
  d=D(unpack(p),t); x=np.linalg.lstsq(d,y.ravel(),rcond=None)[0]; return d@x-y.ravel()
 s=least_squares(r,p0,bounds=(lo,hi),max_nfev=200); p=unpack(s.x); x=np.linalg.lstsq(D(p,t),y.ravel(),rcond=None)[0]; return p,x
T=np.arange(0,8.01,.08); clean=predict(true,xtrue,T); rows=[]
for noise in [0,.002,.01,.03]:
 for rep in range(10):
  y=clean+np.random.default_rng(seed+rep+int(noise*1e6)).normal(0,noise,clean.shape)
  for n in [8,18,38,54]:
   tr=T[:n]; te=T[(T>tr[-1])&(T<=tr[-1]+1.6)]; truth=clean[(T>tr[-1])&(T<=tr[-1]+1.6)]
   vals={}
   for name,full in [('placed',True),('wrong',False)]:
    p,x=fit(tr,y[:n],full); e=np.sqrt(np.mean((predict(p,x,te)-truth)**2)); vals[name]=e
    F=expm(A(p)*.08); Ob=np.vstack([C@np.linalg.matrix_power(F,j) for j in range(4)]); sv=np.linalg.svd(Ob,compute_uv=False)
    rows.append([noise,rep,n,tr[-1],name,e,np.linalg.matrix_rank(Ob),sv[0]/sv[-1],p[2]])
   m=5; kin=np.column_stack([np.polyval(np.polyfit(tr[-m:],y[:n][-m:,j],1),te) for j in range(2)]); e=np.sqrt(np.mean((kin-truth)**2)); rows.append([noise,rep,n,tr[-1],'kinematic',e,np.nan,np.nan,np.nan])
df=pd.DataFrame(rows,columns='noise rep n window model rmse rank cond coupling'.split()); df.to_csv(O/'rg_local_placement_raw.csv',index=False)
s=df.groupby(['noise','n','window','model'],as_index=False).agg(rmse_median=('rmse','median'),rmse_p90=('rmse',lambda x:np.quantile(x,.9)),rank_min=('rank','min'),cond_p90=('cond',lambda x:np.nanquantile(x,.9) if x.notna().any() else np.nan),coupling_median=('coupling','median'),coupling_iqr=('coupling',lambda x:np.nanquantile(x,.75)-np.nanquantile(x,.25) if x.notna().any() else np.nan)); s.to_csv(O/'rg_local_placement_summary.csv',index=False)
p=s[s.model=='placed'].copy(); w=s[s.model=='wrong'][['noise','n','rmse_median']].rename(columns={'rmse_median':'wrong'}); k=s[s.model=='kinematic'][['noise','n','rmse_median']].rename(columns={'rmse_median':'kinematic'}); L=p.merge(w,on=['noise','n']).merge(k,on=['noise','n']); L['gain']=L[['wrong','kinematic']].min(axis=1)/L.rmse_median; L['locked']=(L.rank_min==4)&(L.cond_p90<50)&(L.gain>1.5)&(L.coupling_iqr<.08); L.to_csv(O/'rg_local_placement_locks.csv',index=False)
import matplotlib.pyplot as plt
fig,ax=plt.subplots(1,2,figsize=(10,4));
for m in ['placed','wrong','kinematic']:
 z=s[(s.noise==.01)&(s.model==m)]; ax[0].plot(z.window,z.rmse_median,'o-',label=m)
ax[0].set_yscale('log'); ax[0].set_xlabel('observed neighbourhood length'); ax[0].set_ylabel('forecast RMSE'); ax[0].legend(); ax[0].set_title('Prediction reinforcement')
z=s[(s.noise==.01)&(s.model=='placed')]; ax[1].errorbar(z.window,z.coupling_median,yerr=z.coupling_iqr/2,fmt='o-'); ax[1].axhline(.18,ls='--',c='k'); ax[1].set_xlabel('observed neighbourhood length'); ax[1].set_ylabel('placed hidden coupling'); ax[1].set_title('Hidden-value lock')
fig.tight_layout(); fig.savefig(O/'rg_local_placement_battery.png',dpi=180)
print(L[['noise','n','window','rmse_median','wrong','kinematic','gain','coupling_median','coupling_iqr','locked']].to_string(index=False)); print('LOCKED',L.locked.sum(),'OF',len(L))
