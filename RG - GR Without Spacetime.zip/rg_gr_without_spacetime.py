"""GR does not need spacetime as an object: its predictions descend to the quotient of local data.
S1  FLRW dust in three lapse gauges: coordinate histories differ, the relational prediction a(tau) is identical.
S2  Schwarzschild infall in three charts (Schwarzschild, Painleve-Gullstrand, ingoing Eddington-Finkelstein): proper
    time between two invariantly defined events and the curvature read there agree; coordinate times differ.
S3  null versus relational: a coordinate component (g_tt at t = 1) differs across gauges, so it is not a GR prediction.
S4  degree-of-freedom typing (ADM, linearized): per wavevector 6 metric + 6 momenta, 4 constraints, 4 gauge -> 2
    physical (TT) hidden values; the TT projector has rank 2.
Run: python rg_gr_without_spacetime.py   (numpy, scipy)
"""
import json, math, hashlib, pathlib
import numpy as np
from scipy.integrate import solve_ivp, quad
RES = {}
def must(c, m):
    if not c: raise AssertionError(m)

# ---------------- S1 FLRW dust: (a'/(N a))^2 = C/a^3
Cc = 1.0; a0 = 0.1
gauges = {"proper time N=1": lambda t, a: 1.0, "conformal N=a": lambda t, a: a, "arbitrary N=1+0.5 sin 3t": lambda t, a: 1 + 0.5 * math.sin(3 * t)}
def flrw(Nf, T):
    def rhs(t, y):
        a, tau = y; N = Nf(t, a); return [N * a * math.sqrt(Cc / a ** 3), N]
    sol = solve_ivp(rhs, [0, T], [a0, 0.0], rtol=1e-12, atol=1e-14, dense_output=True); return sol
taus = np.linspace(0.05, 1.5, 30); rel = {}; coord = {}
tau0 = (2 / 3) * a0 ** 1.5 / math.sqrt(Cc)
exact = lambda tau: (1.5 * math.sqrt(Cc) * (tau + tau0)) ** (2 / 3)
for name, Nf in gauges.items():
    sol = flrw(Nf, 60.0); ts = np.linspace(0, 60, 200001); Y = sol.sol(ts)
    a_of_tau = np.interp(taus, Y[1], Y[0]); rel[name] = a_of_tau
    coord[name] = float(sol.sol(1.0)[0])                                    # a at coordinate time t = 1 (not relational)
dev = max(float(np.max(np.abs(rel[k] - np.array([exact(t) for t in taus])))) for k in rel)
coord_spread = max(coord.values()) - min(coord.values())
must(dev < 1e-6 and coord_spread > 0.1, "S1")
RES["S1"] = dict(claim="FLRW: relational prediction a(tau) is gauge-independent; coordinate history is not", status="LOCKED",
                 max_dev_from_exact=dev, a_at_coordinate_t1=coord)

# ---------------- S2 Schwarzschild infall from rest at r0 to r1 in three charts
m = 1.0; r0 = 10.0; r1 = 3.0
def infall(chart):
    """quadrature in r with r = r0 - u^2 (removes the turning-point singularity); returns (proper time, chart time)"""
    E = math.sqrt(1 - 2 * m / r0)
    def rates(r):
        f = 1 - 2 * m / r; rdot = -math.sqrt(max(E * E - f, 1e-300))
        if chart == "Schwarzschild": cdot = E / f
        elif chart == "Painleve-Gullstrand": cdot = (E + math.sqrt(2 * m / r) * rdot) / f
        else: cdot = (E + rdot) / f                                   # ingoing Eddington-Finkelstein v = t + r*
        return rdot, cdot
    umax = math.sqrt(r0 - r1)
    def dtau(u):
        r = r0 - u * u; rdot, _ = rates(r); return 2 * u / (-rdot)
    def dchart(u):
        r = r0 - u * u; rdot, cdot = rates(r); return 2 * u * cdot / (-rdot)
    return quad(dtau, 0, umax, epsabs=1e-13, epsrel=1e-13)[0], quad(dchart, 0, umax, epsabs=1e-13, epsrel=1e-13)[0]
eta = lambda r: math.acos(2 * r / r0 - 1)
tau_exact = math.sqrt(r0 ** 3 / (8 * m)) * ((eta(r1) + math.sin(eta(r1))) - 0)
out = {c: infall(c) for c in ("Schwarzschild", "Painleve-Gullstrand", "ingoing Eddington-Finkelstein")}
taus2 = [v[0] for v in out.values()]; coords2 = {k: v[1] for k, v in out.items()}
K_at_event = 48 * m * m / r1 ** 6
must(max(abs(t - tau_exact) for t in taus2) < 1e-5 and (max(coords2.values()) - min(coords2.values())) > 0.5, "S2")
RES["S2"] = dict(claim="Proper time between invariantly defined events and the curvature read there agree in every chart",
                 status="LOCKED", proper_time_exact=tau_exact, proper_times=dict(zip(out, taus2)),
                 coordinate_time_at_arrival=coords2, kretschmann_at_arrival=K_at_event)

# ---------------- S3 null versus relational
gtt = {k: -(1.0 if "proper" in k else (coord[k] ** 2 if "conformal" in k else (1 + 0.5 * math.sin(3.0)) ** 2)) for k in coord}
must(max(gtt.values()) - min(gtt.values()) > 0.1, "S3")
RES["S3"] = dict(claim="g_tt at coordinate time 1 is a representative component, not a prediction", status="LOCKED (differs across gauges)",
                 gtt_at_t1=gtt)

# ---------------- S4 degree-of-freedom typing: TT projector rank 2
k = np.array([0.3, -0.7, 0.4]); k /= np.linalg.norm(k); P = np.eye(3) - np.outer(k, k)
basis = []
for i in range(3):
    for j in range(i, 3):
        E_ = np.zeros((3, 3)); E_[i, j] = E_[j, i] = 1; basis.append(E_)
def tt(h):
    Ph = P @ h @ P; return Ph - 0.5 * P * np.trace(Ph)
M = np.array([tt(b).ravel() for b in basis]).T
rank = np.linalg.matrix_rank(M, tol=1e-10)
must(rank == 2, "S4")
RES["S4"] = dict(claim="Of 6 spatial metric components per wavevector, 2 are physical (TT); lapse, shift and constraints remove the rest",
                 status="LOCKED (linearized ADM counting: 12 - 4 constraints - 4 gauge = 4 = 2 x 2)", tt_rank=int(rank))
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_gr_without_spacetime_results.json").write_text(json.dumps(RES, indent=1, default=float))
for k_, v in RES.items():
    if isinstance(v, dict): print(k_, v["status"])
print(dev, coord, out, tau_exact)
