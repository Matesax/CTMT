"""Reproducible H1/L1 record-side audit and source-automation contract battery.
No simulated strain. Algebraic fixtures are explicitly labelled proof tests.
Usage: python rg_source_automation.py --input-dir . --out-dir .
"""
import argparse, hashlib, json, platform, itertools
from pathlib import Path
import numpy as np
import h5py

BANDS = [(20,80),(80,300),(300,1000),(1000,2048),(2048,4096),(4096,8192)]
NAMES = ['log_std','log_maxabs','log_Pearson_kurtosis']+[f'log_power_{a}_{b}' for a,b in BANDS]

def digest(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(2**20),b''): h.update(b)
    return h.hexdigest()

def text(v): return v.decode() if isinstance(v,bytes) else str(v)

def features(x,fs):
    # Physical strain is kept unchanged; scale only inside the kurtosis ratio.
    z=x-x.mean(); sd=np.sqrt(np.mean(z*z))
    if not np.isfinite(x).all() or not sd>0: return None
    kurt=np.mean((z/sd)**4)
    # Rectangular, mean-subtracted, full-window one-sided periodogram.
    fft=np.fft.rfft(z); ps=np.abs(fft)**2/(fs*len(z))
    ps[1:-1]*=2
    f=np.fft.rfftfreq(len(z),1/fs); df=fs/len(z)
    powers=[np.sum(ps[(f>=a)&((f<b) if b<fs/2 else (f<=b))])*df for a,b in BANDS]
    v=np.array([sd,np.max(np.abs(x)),kurt]+powers)
    return np.log(v) if np.isfinite(v).all() and np.all(v>0) else None

def spectrum(x):
    if len(x)<=x.shape[1] or not np.isfinite(x).all(): return None
    c=np.cov(x,rowvar=False,ddof=1)
    ev=np.linalg.eigvalsh(c)[::-1]; rel=ev/ev[0]
    return {'relative_eigenvalues':rel.tolist(),'rank_1e-3':int(sum(rel>1e-3)),
            'rank_1e-2':int(sum(rel>1e-2)), 'condition_covariance':float(ev[0]/ev[-1]) if ev[-1]>0 else None,
            'smallest_threshold_margin_1e-3':float(np.min(np.abs(rel-1e-3)))}

def ingest(p):
    with h5py.File(p,'r') as f:
        ds=f['strain/Strain']; a=ds.attrs
        fs=1/float(a['Xspacing']); start=int(a['Xstart']); n=len(ds)
        meta={k:text(f['meta/'+k][()]) for k in ['Detector','UTCstart','FrameType','StrainChannel']}
        meta.update(file=p.name,sha256=digest(p),magic_hex=p.open('rb').read(8).hex(),
                    gps_start=start, duration_seconds=float(n/fs),samples=n,fs=fs,
                    strain_dataset='strain/Strain',dtype=str(ds.dtype))
        assert int(f['meta/GPSstart'][()])==start
        assert float(f['meta/Duration'][()])==n/fs
        dq=f['quality/simple/DQmask'][()]; inj=f['quality/injections/Injmask'][()]
        dn=[text(v) for v in f['quality/simple/DQShortnames'][()]]
        ins=[text(v) for v in f['quality/injections/InjShortnames'][()]]
        meta['dq_bit_names']=dn; meta['injection_bit_names']=ins
        meta['dq_seconds_set']={s:int(np.sum((dq&(1<<i))!=0)) for i,s in enumerate(dn)}
        meta['injection_seconds_set']={s:int(np.sum((inj&(1<<i))!=0)) for i,s in enumerate(ins)}
        for d in [f['quality/simple/DQmask'],f['quality/injections/Injmask']]:
            assert int(d.attrs['Xstart'])==start and float(d.attrs['Xspacing'])==1 and len(d)==n/fs
        required_dq=sum(1<<dn.index(s) for s in ['DATA','CBC_CAT1'])
        required_inj=(1<<len(ins))-1
        rows=[]; accepted=[]; finite=[]; nwin=int(4*fs)
        for j in range(n//nwin):
            x=ds[j*nwin:(j+1)*nwin]
            v=features(x,fs)
            valid=v is not None
            good=np.all((dq[4*j:4*j+4]&required_dq)==required_dq) and np.all((inj[4*j:4*j+4]&required_inj)==required_inj)
            rows.append(v if valid else np.full(9,np.nan)); finite.append(valid); accepted.append(bool(valid and good))
        rows=np.array(rows); accepted=np.array(accepted); finite=np.array(finite)
        meta.update(windows=len(rows),finite_windows=int(sum(finite)),accepted_windows=int(sum(accepted)),
                    quality_policy='All 4 seconds: DATA + CBC_CAT1 + all five NO_*_HW_INJ bits; no claim this suffices for detection.')
        meta['spectrum_all_finite']=spectrum(rows[finite]) if sum(finite)>9 else None
        meta['spectrum_accepted']=spectrum(rows[accepted]) if sum(accepted)>9 else None
        return meta,rows,accepted

def dispatch(domain=True,consistent=True,task=True,vacuous=False,rank='pass',candidate='unique',scale='pass',escalation=False):
    if not domain:return 'OUTSIDE_DOMAIN'
    if not consistent:return 'INCONSISTENT'
    if not task:return 'OUTSIDE_DOMAIN'
    if vacuous:return 'VACUOUS'
    if rank!='pass':return 'ESCALATE' if escalation else 'STRUCTURAL_WALL'
    if candidate=='none':return 'INCONSISTENT'
    if candidate=='multiple':return 'CORRESPONDENCE'
    if scale!='pass':return 'ESCALATE' if escalation else 'STRUCTURAL_WALL'
    return 'LOCKED'

def finite_source_bridge(laws, targets):
    """Exact finite-law adapter. Caller supplies full rational law rows, not samples.
    Output is task-valued only when target is constant on each law fibre.
    This does not identify which law generated a single observed record.
    """
    from fractions import Fraction
    if len(laws)!=len(targets) or not laws:
        return {'status':'OUTSIDE_DOMAIN','reason':'missing or inconsistent finite model'}
    rows=[tuple(Fraction(v) for v in row) for row in laws]
    if len({len(r) for r in rows})!=1 or any(any(v<0 for v in r) or sum(r)!=1 for r in rows):
        return {'status':'INCONSISTENT','reason':'invalid probability rows'}
    fibres={}
    for i,r in enumerate(rows):fibres.setdefault(r,[]).append(i)
    blocks=list(fibres.values())
    identified=all(all(targets[i]==targets[b[0]] for i in b) for b in blocks)
    return {'status':'LOCKED' if identified else 'CORRESPONDENCE',
            'scope':'exact finite-law task descent only; no sample identification',
            'fibres':blocks,'task_values':[[targets[i] for i in b] for b in blocks]}

def battery(h,l,mask,metas):
    out=[]
    def add(name,passed,mutation,detail):
        out.append(dict(test=name,passed=bool(passed),mutation_detected=bool(mutation),detail=detail))
    add('B01 binary provenance',all(m['magic_hex']=='894844460d0a1a0a' for m in metas),
        b'plain text'[:8]!=bytes.fromhex('894844460d0a1a0a'),'Magic bytes, not extension or advertised MIME, establish HDF5 signature; h5py validates structure.')
    paired=metas[0]['gps_start']==metas[1]['gps_start'] and metas[0]['fs']==metas[1]['fs'] and metas[0]['samples']==metas[1]['samples']
    add('B02 GPS pairing',paired,metas[0]['gps_start']!=metas[1]['gps_start']+1,'Mutation shifts L1 metadata by one second.')
    dq=np.array([31,31,31,31],dtype=np.uint32)
    gate=lambda v:bool(np.all((v&3)==3))
    bad=dq.copy();bad[2]&=np.uint32(0xfffffffe)
    add('B03 quality bit gate (algebraic fixture)',gate(dq),not gate(bad),'Mutation clears DATA in one second; production gate is applied to actual masks.')
    # Exact finite-map theorem, exhaustively checked, not a simulated detector experiment.
    pairs=list(itertools.product(range(2),repeat=2)); joint=pairs
    kh={(i,j) for i in range(4) for j in range(4) if pairs[i][0]==pairs[j][0]}
    kl={(i,j) for i in range(4) for j in range(4) if pairs[i][1]==pairs[j][1]}
    kj={(i,j) for i in range(4) for j in range(4) if joint[i]==joint[j]}
    add('B04 joint kernel intersection (exact fixture)',kj==kh&kl,kj!=kh|kl,'Union mutation incorrectly joins detector-indistinguishable pairs.')
    # Two laws with identical marginals and distinct dependence, exact integer counts.
    law0=np.array([[1,0],[0,1]]);law1=np.array([[0,1],[1,0]])
    same_marginals=np.array_equal(law0.sum(0),law1.sum(0)) and np.array_equal(law0.sum(1),law1.sum(1))
    add('B05 marginals are not a coupled law (exact fixture)',same_marginals and not np.array_equal(law0,law1),
        not np.array_equal(law0,law1),'A marginal-only equality detector falsely merges these two laws.')
    # All finite maps F:X4->Y2 and targets T:X4->Z2.
    cases=0;equiv=True
    for F in itertools.product(range(2),repeat=4):
        for T in itertools.product(range(2),repeat=4):
            const=all(F[i]!=F[j] or T[i]==T[j] for i in range(4) for j in range(4))
            exists=any(all(g[F[i]]==T[i] for i in range(4)) for g in itertools.product(range(2),repeat=2))
            equiv &= const==exists; cases+=1
    add('B06 task descent (256 exact fixtures)',equiv,not all([0,0][i]==[0,1][i] for i in range(2)),
        f'{cases} finite-map cases; explicit nonconstant target on a constant observation defeats representative selection.')
    add('B07 tolerance relation is not a groupoid (exact fixture)',abs(0-.75)<=1 and abs(.75-1.5)<=1 and abs(0-1.5)>1,
        abs(0-1.5)>1,'Chaining tolerance arrows would violate transitivity; retain correspondences or certified partitions.')
    diagnostic=np.isfinite(h).all(1)&np.isfinite(l).all(1)
    x=h[diagnostic]; y=l[diagnostic]; z=np.column_stack([x,y])
    # Invertible feature-chart permutation preserves covariance spectrum, but is not a source symmetry claim.
    rel=np.array(spectrum(z)['relative_eigenvalues']); perm=np.arange(18)[::-1]
    err=float(np.max(np.abs(rel-np.array(spectrum(z[:,perm])['relative_eigenvalues']))))
    duplicate=np.column_stack([z,z[:,0]])
    small=float(abs(np.linalg.eigvalsh(np.cov(duplicate,rowvar=False))[0]))
    add('B08 chart relabel and duplicate on real features',err<1e-12,small<1e-12,
        {'permutation_spectrum_error':err,'duplicate_smallest_abs_eigenvalue':small,'note':'Duplicate mutation detected by eigenvalue; no nonlinear-rank claim.'})
    # A deterministic post-map proxy, not energy or source inversion.
    weights=np.array([(2*np.pi*np.sqrt(a*b))**2 for a,b in BANDS])
    p=np.exp(x[:,3:]); proxy=p@weights
    recon=np.exp(np.log(p))@weights
    err=float(np.max(np.abs(recon-proxy)/proxy))
    wrong=p@(weights*1.01)
    mut=float(np.max(np.abs(wrong-proxy)/proxy))
    add('B09 post-map reconstruction on real features',err<1e-12,mut>1e-3,{'relative_error':err,'mutated_error':mut})
    # Exhaustive decision contract, including gate precedence and failed-gate lock exclusion.
    states=[]; good=True
    for d,c,t,v,r,k,s,e in itertools.product([False,True],[False,True],[False,True],[False,True],['pass','unknown'],['unique','multiple','none'],['pass','unknown'],[False,True]):
        status=dispatch(d,c,t,v,r,k,s,e); states.append(status)
        truth=d and c and t and not v and r=='pass' and k=='unique' and s=='pass'
        good &= (status=='LOCKED')==truth
    add('B10 fail-closed dispatcher',good and len(set(states))==7,dispatch(candidate='multiple')!='LOCKED',
        {'combinations':len(states),'statuses':sorted(set(states)),'mutation':'Force LOCKED for multiple candidates; forbidden by conjunction oracle.'})
    # Linear observation law example: gauge shear leaves observation fixed but changes latent lift.
    J=np.array([[1.,0.]]); P1=np.eye(2);P2=np.array([[1.,.5],[.5,1.]])
    lift=lambda P:P@J.T@np.linalg.inv(J@P@J.T)
    b1,b2=lift(P1),lift(P2)
    add('B11 latent lift is declared (exact matrix fixture)',np.allclose(J@b1,1) and np.allclose(J@b2,1),
        not np.allclose(b1,b2),'Same observable increment has different P-dependent latent lifts; no law-natural lift asserted.')
    # Empirical feature covariance is not source Fisher: task needs source law and response certificate.
    add('B12 source lock rejection',dispatch(rank='unknown',escalation=False)=='STRUCTURAL_WALL',
        dispatch(candidate='multiple')!='LOCKED','Empirical covariance rank cannot be substituted for a source Jacobian or a fibre-completeness certificate.')
    strict=lambda m: (m & 31)==31
    relaxed=lambda m: (m & 23)==23
    add('B13 injection-policy canary on actual mask',not strict(23),relaxed(23)!=strict(23),
        'Actual mask 23 fails all-five-injection-veto policy. Mutation omits NO_CW_HW_INJ and incorrectly accepts.')
    # Directly exercise the exact-law adapter and a representative-picking mutation.
    laws=[['1','0'],['1','0'],['0','1']]
    bridge=finite_source_bridge(laws,[0,1,2])
    invariant=finite_source_bridge(laws,[7,7,9])
    mutant={'status':'LOCKED','fibres':bridge['fibres']}
    add('B14 exact finite-law source bridge',bridge['status']=='CORRESPONDENCE' and invariant['status']=='LOCKED',
        mutant['status']!=bridge['status'],{'ambiguous':bridge,'identified_task':invariant,
        'mutation':'Pick the first source representative and report LOCKED.'})
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input-dir',default='.');ap.add_argument('--out-dir',default='.')
    a=ap.parse_args();inp=Path(a.input_dir);out=Path(a.out_dir);out.mkdir(parents=True,exist_ok=True)
    ms=[];xs=[];qs=[]
    for det in ['H1','L1']:
        paths=sorted(inp.glob(f'*{det}_GWOSC_O4a_16KHZ_R1-1368993792-4096.hdf5*'))
        if len(paths)!=1:raise ValueError(f'Expected exactly one {det} binary HDF5 file, got {len(paths)}')
        m,x,q=ingest(paths[0]);ms.append(m);xs.append(x);qs.append(q)
        np.savetxt(out/f'rg_{det}_features.csv',np.column_stack([m['gps_start']+4*np.arange(len(x)),q.astype(int),x]),delimiter=',',header=','.join(['gps_start','accepted']+NAMES),comments='')
    paired=ms[0]['gps_start']==ms[1]['gps_start'] and ms[0]['fs']==ms[1]['fs'] and ms[0]['samples']==ms[1]['samples']
    if not paired:raise ValueError('No implicit index pairing allowed')
    mask=qs[0]&qs[1]
    diagnostic=np.isfinite(xs[0]).all(1)&np.isfinite(xs[1]).all(1)
    z=np.column_stack([xs[0][diagnostic],xs[1][diagnostic]])
    # Descriptive dependence diagnostic; no iid p-value, no astrophysical interpretation.
    cross=np.corrcoef(xs[0][diagnostic].T,xs[1][diagnostic].T)[:9,9:]
    tests=battery(xs[0],xs[1],mask,ms)
    results=dict(schema='rg-source-automation-v1',environment=dict(python=platform.python_version(),numpy=np.__version__,h5py=h5py.__version__),
                 estimator=dict(window_seconds=4,overlap=0,centering='per-window mean for std, kurtosis and FFT; maxabs uses raw window',
                                std_ddof=0,kurtosis='Pearson, population moments',spectral_window='rectangular',spectral_method='one-sided full-window periodogram',
                                bands_hz=BANDS,band_endpoints='left closed, right open; Nyquist included in final band',log='natural; no floors or clipping',
                                covariance='centered log features; sample covariance ddof=1; no standardization',features=NAMES),
                 inputs=ms,paired_gps=True,paired_accepted_windows=int(sum(mask)),descriptive_paired_finite_windows=int(sum(diagnostic)),joint_feature_covariance_all_finite_NOT_QUALITY_ACCEPTED=spectrum(z),
                 same_coordinate_cross_detector_correlations=np.diag(cross).tolist(),
                 battery=tests,battery_passed=all(t['passed'] and t['mutation_detected'] for t in tests),
                 verdict=dict(record_ingestion='PASS',gps_pairing='PASS',strict_injection_gate='REJECTED_NO_CW_HW_INJ_UNSET',empirical_feature_diagnostics='COMPUTED_NOT_SOURCE_CERTIFICATE',
                              source_model='NOT_SUPPLIED',source_identification='OUTSIDE_DOMAIN',
                              conditional_source_bridge='THEOREM_CONDITIONAL; returns correspondence unless task descends and all accuracy gates pass',
                              physical_transport='NOT_CERTIFIED'))
    results['script_sha256']=digest(Path(__file__))
    (out/'rg_source_results.json').write_text(json.dumps(results,indent=2))
    print(json.dumps({k:results[k] for k in ['paired_accepted_windows','joint_feature_covariance_all_finite_NOT_QUALITY_ACCEPTED','same_coordinate_cross_detector_correlations','battery_passed','verdict']},indent=2))
    for m in ms: print(m['Detector'],m['accepted_windows'],m['spectrum_accepted'],m['sha256'])
    assert results['battery_passed'], 'Battery failed or a mutation was not detected'

if __name__=='__main__':main()
