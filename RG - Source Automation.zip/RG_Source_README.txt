RG SOURCE AUTOMATION: FINAL CONDITIONAL CONTRACT AND REAL-DATA AUDIT

Read RG_Source_Automation.pdf first. The physical source reconstruction is NOT locked.
The exact-law task-descent theorem and finite-law adapter are conditional on supplied laws.
No source response/noise law or calibrated source confidence procedure was supplied.

Actual binary HDF5 inputs: same GPS start 1368993792, duration 4096 s, 16384 Hz.
Both masks equal 23: NO_CW_HW_INJ is unset. Our explicitly declared conservative
all-five-injection-veto policy accepts zero windows. This is not a universal veto
for every possible scientific task. Descriptive CSVs retain all finite windows.

Run with the two original binary HDF5 attachments in the working directory:
python rg_source_automation.py --input-dir . --out-dir .
python rg_source_plot.py
pdflatex RG_Source_Automation.tex
pdflatex RG_Source_Automation.tex

Dependencies: Python, numpy, h5py; matplotlib for figure; LaTeX for paper.
Exact execution versions and input/script SHA-256 digests are in rg_source_results.json.
Original ~1 GB input binaries are NOT duplicated in this archive.

Fourteen modules pass their recorded checks and sensitivity conditions.
These include exact fixtures, numerical regressions and dispatcher checks, not a
validated physical inverse solver or statistical false-lock calibration.
Dispatcher enumeration: 384 combinations, seven statuses.
Independent SVD recheck: H1 rank 8, L1 rank 7, paired rank 15 at relative 1e-3.

All CSV acceptance flags are zero. Never treat these as quality-accepted source samples.
No synthetic strain was used. Exact finite mathematical fixtures are labelled in code.
The final PDF and LaTeX preserve non-claims, estimator choices and failed gates.
