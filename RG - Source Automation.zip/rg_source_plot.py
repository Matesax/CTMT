import json
from pathlib import Path
import matplotlib.pyplot as plt
r=json.loads(Path("rg_source_results.json").read_text())
fig,ax=plt.subplots(figsize=(7,4))
for m in r["inputs"]:
 e=m["spectrum_all_finite"]["relative_eigenvalues"];ax.semilogy(range(1,len(e)+1),e,"o-",label=m["Detector"])
e=r["joint_feature_covariance_all_finite_NOT_QUALITY_ACCEPTED"]["relative_eigenvalues"]
ax.semilogy(range(1,19),e,"o-",label="Paired 18-feature map")
ax.axhline(.001,linestyle="--",label="Relative threshold 0.001")
ax.set_xlabel("Eigenvalue index");ax.set_ylabel("Eigenvalue / largest eigenvalue")
ax.set_title("Descriptive covariance only: strict injection gate rejected")
ax.legend();fig.tight_layout();fig.savefig("rg_source_spectra.png",dpi=160)
