import numpy as np
from fractions import Fraction as Fr
np.set_printoptions(precision=4, suppress=True)
rng = np.random.default_rng(0)

print("CLAIM UNDER ATTACK: sensor, precision, representation are one resolution poset,")
print("and persistent ignorance = intersection of ker dF over ALL of them.\n")

print("="*72)
print("ATTACK 1  Precision null is NOT in ker dF. It is an EVALUATION-layer artifact.")
print("="*72)
# True observation map F(theta)=J theta.  dF = J is EXACT and precision-independent.
# Build J with a direction of tiny-but-nonzero sensitivity (1e-10), exact rational.
J = np.array([[Fr(1),Fr(0),Fr(0)],
              [Fr(0),Fr(1,10**10),Fr(0)]], dtype=object)   # 2nd row: sensitivity 1e-10
v = np.array([Fr(0),Fr(1),Fr(0)])                          # the "precision-null" direction
Jv = J@v
print("   exact dF . v =", [str(x) for x in Jv], " -> nonzero, so v is NOT in ker dF")
print("   (float64 would compute JtJ eigenvalue 1e-20 ~ 0 and wrongly call v null)")
print("   => precision-null lives in the gap TRUE dF vs COMPUTED dF, not in ker dF.")
print("      Intersecting ker dF over 'precision resolutions' adds nothing: dF is precision-invariant.")

print("\n"+"="*72)
print("ATTACK 2  Representation null is NOT in ker dF. It lives in a DOWNSTREAM map A.")
print("="*72)
n=2000; x=rng.normal(size=n); y=x**2+0.01*rng.normal(size=n)
F=np.column_stack([x,y])                       # the observation map's OUTPUT contains x and y=x^2
# dF is full rank: F separates latent (x) points; nothing null at the map layer
print("   rank of observed data columns [x, y] =", np.linalg.matrix_rank(F-F.mean(0)), "(full: info is present in Im F)")
# the 'null' only appears in a downstream linear analysis A(features)=fit y~x
b=np.polyfit(x,y,1); r2_lin=1-np.var(y-(b[0]*x+b[1]))/np.var(y)
print("   downstream LINEAR analysis A: R^2 = %.4f (A discards the x^2 info that IS in Im F)"%r2_lin)
print("   => representation-null is ker of the downstream construction A on Im F, not ker dF.")

print("\n"+"="*72)
print("ATTACK 3  Directedness fails under complementarity: no common refinement, no product map.")
print("="*72)
# qubit: measuring sigma_z and sigma_x cannot be jointly refined (no common eigenbasis)
sz=np.array([[1,0],[0,-1]]); sx=np.array([[0,1],[1,0]])
comm=sz@sx-sx@sz
print("   [sigma_z, sigma_x] =\n",comm)
print("   nonzero commutator -> no simultaneous eigenbasis -> the 'product map' F_z x F_x is")
print("   not operationally realizable; the directed family (any two have a common refinement) FAILS.")
print("   => F_infinity = prod F_rho presumes joint measurability; complementary sensors have none.")

print("\n"+"="*72)
print("WHAT SURVIVES  The sensor-persistent kernel is well-defined & attained finitely (finite dim).")
print("="*72)
d=6; Jbase=rng.normal(size=(2,d)); ker_dim=[]
Js=Jbase.copy()
for add in range(0,6):
    if add: Js=np.vstack([Js, rng.normal(size=(1,d))])
    ker_dim.append(d-np.linalg.matrix_rank(Js))
print("   dim ker dF as sensors are added:", ker_dim, "(non-increasing, stabilizes = intersection attained)")
# wall: a persistent-null direction is invariant under ANY downstream A
Jmax=np.vstack([Jbase, rng.normal(size=(2,d))])            # a compatible (jointly-performed) suite
h=np.linalg.svd(Jmax)[2][np.linalg.matrix_rank(Jmax):]    # persistent null directions
x0=rng.normal(size=d); x1=x0+h.T@rng.normal(size=h.shape[0])
A=lambda z: np.concatenate([z,z**2,np.sin(z),np.tanh(z)])  # arbitrary downstream construction
print("   ||A(F x0) - A(F x1)|| for persistent-null difference = %.2e (invariant under every A)"%
      np.linalg.norm(A(Jmax@x0)-A(Jmax@x1)))
print("   => the ONLY defensible object is ker dF_infinity over a COMPATIBLE sensor family;")
print("      it is established (inverse-limit kernel), attained finitely, and is the true wall.")
