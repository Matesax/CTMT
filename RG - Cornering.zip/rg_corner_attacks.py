"""RG cornering battery: the floating box, protocolism vs realism, Einstein, Newton, luck and God.
Every arena claim gets a computed witness; canaries are false claims rejected by computed criteria.
Run: python rg_corner_attacks.py --out DIR      (numpy, sympy, mpmath)
"""
import argparse, hashlib, itertools, json, math, pathlib, platform, sys, time
import numpy as np, sympy as sp, mpmath as mp

MASTER_SEED = 20261026
RES, CAN = [], []
G_SI, C_SI = 6.67430e-11, 299792458.0
GM_SUN, R_SUN, GM_EARTH = 1.32712440018e20, 6.957e8, 3.986004418e14
RAD2AS = 180 / math.pi * 3600


def must(c, m):
    if not c:
        raise AssertionError(m)


def rec(i, arena, claim, status, witness, details=None):
    RES.append(dict(id=i, arena=arena, claim=claim, status=status, witness=witness, details=details or {}))


def can(statement, rejected, witness):
    must(bool(rejected), "canary accepted: " + statement)
    CAN.append(dict(statement=statement, accepted=False, witness=witness))


def lin_riemann(h, X):
    """Linearized Riemann R_abcd = 1/2(h_ad,bc + h_bc,ad - h_ac,bd - h_bd,ac)."""
    n = len(X)
    return {(a, b, c, d): sp.simplify(sp.Rational(1, 2) * (sp.diff(h[a, d], X[b], X[c]) + sp.diff(h[b, c], X[a], X[d])
                                                        - sp.diff(h[a, c], X[b], X[d]) - sp.diff(h[b, d], X[a], X[c])))
            for a in range(n) for b in range(n) for c in range(n) for d in range(n)}


# ============================================================ F01 the floating box: EP is a resolution statement
def F01():
    x, y, z = sp.symbols("x y z", real=True); GM = sp.symbols("GM", positive=True)
    r = sp.sqrt(x * x + y * y + z * z); Phi = -GM / r
    Rr = sp.Symbol("R", positive=True)
    Hs = sp.simplify(sp.hessian(Phi, (x, y, z)).subs({x: 0, y: 0}).subs(z, Rr))
    ev = sorted([sp.simplify(e) for e in Hs.eigenvals().keys()], key=lambda e: float(e.subs({GM: 1, Rr: 1})))
    must(sp.simplify(ev[0] + 2 * GM / Rr ** 3) == 0 and sp.simplify(ev[-1] - GM / Rr ** 3) == 0
         and sp.simplify(Hs.trace()) == 0, "tidal tensor")
    r_leo = 6.371e6 + 4e5
    grad = GM_EARTH / r_leo ** 3                                  # s^-2
    eotvos = grad / 1e-9
    gradiometer = 1e-12                                            # milli-Eotvos class
    snr = 2 * grad / gradiometer
    L, dt = 1.0, 100.0
    drift = 2 * grad * L * dt ** 2 / 2
    rec("F01", "Floating box", "Einstein's freely falling box cannot detect gravity (equivalence principle)",
        "CORNERED (window)", f"Tidal tensor diag(-2,1,1)GM/r^3, traceless (sympy): the connection is removable at a point, "
        f"curvature is not. In low Earth orbit GM/r^3 = {grad:.3e} s^-2 = {eotvos:.0f} E; gradiometry at the "
        f"milli-Eotvos level resolves it at SNR of order 1e5-1e6 (here {snr:.1e}). Two masses 1 m apart drift {drift * 1e3:.1f} mm in 100 s. The box is a "
        f"CORRESPONDENCE only below the declared resolution: |R| L < delta_a and |R| L T^2 < delta_x.",
        dict(gradient=grad, eotvos=eotvos, snr=snr, drift_m=drift))
    can("the equivalence principle is exact for a finite box", snr > 1e3,
        f"tidal signal / gradiometer noise ~ {snr:.0e} in orbit")


# ============================================================ F02 the box sees energy, not structure
def F02():
    t, x, y, z, g = sp.symbols("t x y z gamma", real=True)
    Phi = sp.Function("Phi")(x, y, z)
    X = (t, x, y, z)
    h = sp.diag(-2 * Phi, -2 * g * Phi, -2 * g * Phi, -2 * g * Phi)      # g = eta + h, eta = diag(-1,1,1,1)
    Rm = lin_riemann(h, X)
    E = sp.Matrix(3, 3, lambda i, j: Rm[(0, i + 1, 0, j + 1)])
    Eg = all(sp.diff(e, g) == 0 for e in E)
    Sij = Rm[(1, 2, 1, 2)]
    struct = sp.simplify(sp.diff(Sij, g)) != 0
    must(Eg and struct, "electric part gamma-free, spatial part proportional to gamma")
    soldner = 2 * GM_SUN / (C_SI ** 2 * R_SUN) * RAD2AS
    einstein = 2 * soldner
    rec("F02", "Floating box", "The box (slow masses, clocks, accelerometers) determines gravity", "CORNERED",
        "Linearized PPN metric: the tidal (electric) part R_0i0j = d_i d_j Phi carries no gamma; the spatial part "
        "R_ijkl is proportional to gamma (sympy). Slow probes in the box read the ENERGY footprint (N, tidal E_ij); "
        f"STRUCTURE (h) needs light. Einstein 1911 (box only) predicts {soldner:.3f}\" at the solar limb; GR 1915 "
        f"(structure added) {einstein:.3f}\". The box is blind to half of light bending.",
        dict(soldner_arcsec=soldner, gr_arcsec=einstein))
    can("the equivalence principle fixes light bending", abs(einstein - soldner) > 0.5, f"{soldner:.3f}\" vs {einstein:.3f}\"")


# ============================================================ F03 Newton's bucket vs absolute velocity
def F03():
    v, L, c = sp.symbols("v L c", positive=True)
    gam = 1 / sp.sqrt(1 - v ** 2 / c ** 2)
    t_par = (L / gam) / (c - v) + (L / gam) / (c + v)               # lab-frame round trip, arm along motion
    t_perp = 2 * (L / sp.sqrt(c ** 2 - v ** 2))
    proper_par = sp.simplify(t_par / gam); proper_perp = sp.simplify(t_perp / gam)
    must(sp.simplify(proper_par - 2 * L / c) == 0 and sp.simplify(proper_perp - 2 * L / c) == 0, "velocity in kernel")
    A, Om = math.pi * 1.0 ** 2, 7.2921e-5
    sagnac = 4 * A * Om / C_SI ** 2
    rec("F03", "Newton", "Absolute space and absolute rotation are equally real", "SPLIT",
        "Uniform velocity is in the kernel: both light-clock arms give proper round trip 2L/c for every v (sympy). "
        f"Rotation is in the quotient: Sagnac time 4A Omega/c^2 = {sagnac:.2e} s for a 1 m ring at the Earth's rate "
        "(L105; ring lasers detect it). Newton wins the bucket; Leibniz wins absolute position and velocity.",
        dict(sagnac_s=sagnac))
    can("absolute velocity is detectable by light clocks", sp.simplify(proper_par - proper_perp) == 0,
        "proper round trips are equal for every v")


# ============================================================ F04 hole argument: points are latent
def F04():
    t, rho, m, eps = sp.symbols("t rho m epsilon", positive=True)
    phi = sp.exp(-(rho - 10) ** 2)                                  # smooth bump: the "hole"
    r = rho + eps * phi
    A = 1 - 2 * m / r
    grr = sp.diff(r, rho) ** 2 / A
    R_areal = r                                                     # sqrt(g_thth) is the invariant areal radius
    # Kretschmann of Schwarzschild in any radial coordinate is 48 m^2 / R_areal^6
    K_new_rho = 48 * m ** 2 / R_areal ** 6
    K_old_at_rho = 48 * m ** 2 / rho ** 6
    differs = sp.simplify((K_new_rho - K_old_at_rho).subs({m: 1, eps: sp.Rational(1, 10), rho: 10})) != 0
    relation = sp.simplify(K_new_rho - 48 * m ** 2 / R_areal ** 6) == 0
    comp = sp.simplify((grr - 1 / (1 - 2 * m / rho)).subs({m: 1, eps: sp.Rational(1, 10), rho: 10})) != 0
    must(differs and relation and comp, "hole")
    rec("F04", "Einstein", "Spacetime points carry physical identity (manifold substantivalism)", "CORNERED",
        "Hole diffeomorphism r = rho + eps*bump: the metric components at a coordinate point change, and so does the "
        "curvature attributed to that point; the invariant relation K = 48 m^2/R_areal^6 is identical. Points are "
        "latent (gauge, Gau); point coincidences are observable. This is Einstein's own resolution, formalized as RG's "
        "Gau -> Stab -> Gamma.")


# ============================================================ F05 interiors and global topology are remainders
def F05():
    Mass = 1.0
    interiors = {"constant density R=10": 10.0, "polytrope R=10.047": 10.0473500683}
    ext = {k: [1 - 2 * Mass / r for r in (20.0, 50.0)] for k in interiors}
    same = max(abs(a - b) for a, b in zip(*ext.values())) == 0
    L = 7.0
    echoes = [k * L for k in range(1, 4)]
    must(same, "exterior")
    rec("F05", "Einstein", "Spacetime is fully determined by observation (interiors, beyond horizons, topology)",
        "CORNERED (imported Birkhoff)", "Birkhoff (imported; the numeric witness is by construction): two interiors of equal mass (constant density, Gamma=2 polytrope) give identical exterior "
        "lapse at r = 20, 50 m: the interior is a CORRESPONDENCE for exterior protocols. A black-hole interior is in the "
        "kernel of every exterior protocol. A flat torus and the flat plane share every local invariant; only global "
        f"light paths (echoes at {echoes} for circumference {L}) detect the topology - the RG global remainder (L119).")


# ============================================================ F06 field equation is selected, not forced (imported)
def F06():
    alpha_gr = 4.0 / 30.0; alpha_nord = 0.0
    rec("F06", "Einstein", "Observation of matter forces Einstein's equation", "CORNERED (imported no-go)",
        "Physical Path P12: Minkowski and Schwarzschild share T = 0; Nordstrom and Einstein vacua share T = 0 and "
        f"differ in light bending (weak field {alpha_gr:.4f} vs {alpha_nord} at b = 30 m). The field equation is a "
        "selection (Lovelock) or a measurement, never a consequence of the source remainder.")


# ============================================================ F07 units: God's metre
def F07():
    t, r, m, lam = sp.symbols("t r m lambda", positive=True)
    ds2 = lambda T, R, M: [-(1 - 2 * M / R), 1 / (1 - 2 * M / R)]
    a, b = ds2(t, r, m), ds2(lam * t, lam * r, lam * m)
    must(all(sp.simplify(x - y) == 0 for x, y in zip(a, b)), "scaling")
    Gs, Ms, k, aa = sp.symbols("G M k a", positive=True)
    T2 = 4 * sp.pi ** 2 * aa ** 3 / (Gs * Ms)
    must(sp.simplify(T2 - T2.subs({Gs: Gs / k, Ms: k * Ms}, simultaneous=True)) == 0, "Kepler")
    rec("F07", "God", "Complete knowledge of the laws fixes the units of nature", "CORNERED",
        "Schwarzschild is invariant under (t, r, m) -> lambda (t, r, m) (sympy): geometry knows only GM/c^2. Kepler "
        "periods are invariant under (G, M) -> (G/k, kM). No internal unit (L94): a metre needs a counted channel and a "
        "convention (L95, L102), even for an omniscient observer of the laws.")


# ============================================================ F08 Laplace's demon: precision is information
def F08():
    mp.mp.dps = 80
    out = {}
    for B in (10, 20, 30, 40, 50):
        x = mp.mpf("0.3141592653589793238462643383279502884197"); y = x + mp.mpf(2) ** (-B)
        n = 0
        while abs(x - y) < mp.mpf("0.1") and n < 500:
            x, y = 4 * x * (1 - x), 4 * y * (1 - y); n += 1
        out[B] = n
    slope = (out[50] - out[10]) / 40
    must(all(abs(out[B] - B) <= 6 for B in out) and abs(slope - 1) < 0.1, "horizon")
    rec("F08", "God", "Laplace's demon: complete laws + present state = complete future", "CORNERED",
        f"Logistic r=4 (lambda = ln 2): an initial uncertainty of 2^-B bits reaches 0.1 after n steps = {out}; slope "
        f"{slope:.2f} step/bit (L90-L92). A finite demon has a finite horizon; an infinite one needs an infinite "
        "protocol, which is a declaration, not an observation.", dict(horizon=out))
    can("a demon with finite bits forecasts forever", max(out.values()) < 200, f"horizon {out[50]} steps at 50 bits")


# ============================================================ F09 omniscience must be contextual (Kochen-Specker)
def F09():
    rows = [(1, 1, 1), (1, 1, 1), (1, 1, 1)]
    count = 0
    for vals in itertools.product((1, -1), repeat=9):
        M = np.array(vals).reshape(3, 3)
        ok = all(np.prod(M[i]) == 1 for i in range(3)) and np.prod(M[:, 0]) == 1 and np.prod(M[:, 1]) == 1 \
            and np.prod(M[:, 2]) == -1
        count += ok
    must(count == 0, "Peres-Mermin")
    rec("F09", "God", "An omniscient observer holds predetermined values for every observable", "CORNERED",
        "Peres-Mermin square: 0 of 512 noncontextual value assignments satisfy the quantum product constraints (rows +1, "
        "columns +1,+1,-1). Any 'God's-eye' value table in a quantum world must be contextual (Kochen-Specker; L43).")
    can("a noncontextual omniscient assignment exists", count == 0, "0/512")


# ============================================================ F10 Bell does not certify luck
def F10():
    rng = np.random.default_rng(MASTER_SEED + 10)
    N = 400000
    l1, l2 = rng.random(N), rng.random(N)
    def run(ta, tb):
        A = np.where(l1 < 0.5, 1, -1)
        ab = math.cos(ta - tb)
        B = np.where(l2 < (1 + ab) / 2, -A, A)
        return A, B
    E = lambda ta, tb: float(np.mean(np.prod(run(ta, tb), axis=0)))
    a0, a1, b0, b1 = 0, math.pi / 2, math.pi / 4, -math.pi / 4
    S = E(a0, b0) + E(a0, b1) + E(a1, b0) - E(a1, b1)
    marg = [float(np.mean(run(ta, 0.3)[1])) for ta in (0.0, 1.2, 2.5)]        # Bob at b=0.3, Alice varies
    lhv = max(abs(Aa0 * Bb0 + Aa0 * Bb1 + Aa1 * Bb0 - Aa1 * Bb1)
              for Aa0, Aa1, Bb0, Bb1 in itertools.product((1, -1), repeat=4))
    must(abs(abs(S) - 2 * math.sqrt(2)) < 0.02 and lhv == 2 and max(abs(m) for m in marg) < 0.01, "Bell")
    rec("F10", "Luck", "Bell violations prove that nature is genuinely random", "CORNERED",
        f"Exhaustive local deterministic strategies: max |CHSH| = {lhv}. A DETERMINISTIC model (outcomes fixed by hidden "
        f"lambda) with nonlocal dependence reproduces the singlet: |S| = {abs(S):.4f} (2 sqrt 2 = {2 * math.sqrt(2):.4f}); "
        f"Bob's marginal {marg} does not depend on Alice's setting (no signalling). Bell excludes LOCAL determinism, "
        "not determinism: 'luck' and nonlocal determinism are one fibre (seed %d)." % (MASTER_SEED + 10),
        dict(S=S, lhv=lhv, bob_marginals=marg))
    can("Bell violation proves indeterminism", abs(S) > 2.7, f"deterministic nonlocal model gives |S| = {abs(S):.3f}")


# ============================================================ F11 finite records do not certify luck; kernel luck persists
def F11():
    n = 20000
    s = math.isqrt(2 * 4 ** n)                                     # binary digits of sqrt(2): deterministic
    bits_det = np.array([int(b) for b in bin(s)[3:3 + n]])
    rng = np.random.default_rng(MASTER_SEED + 11)
    bits_coin = rng.integers(0, 2, n)
    def chi2_blocks(bits, k):
        m = len(bits) // k
        blocks = bits[:m * k].reshape(m, k) @ (2 ** np.arange(k))
        cnt = np.bincount(blocks, minlength=2 ** k)
        exp = m / 2 ** k
        return float(np.sum((cnt - exp) ** 2 / exp)), 2 ** k - 1
    from scipy.stats import chi2
    pv = {lab: [float(chi2.sf(*chi2_blocks(b, k))) for k in (1, 2, 3, 4)] for lab, b in
          (("sqrt2 digits (deterministic)", bits_det), ("seeded coin", bits_coin))}
    must(min(pv["sqrt2 digits (deterministic)"]) > 0.01 and min(pv["seeded coin"]) > 0.01, "both pass")
    # kernel luck: observe theta1 + noise only
    sig = 1.0
    diffs = []
    for nn in (1, 10, 100, 1000):
        p1 = [(m0 + nn * 0.5) / (1 + nn) for m0 in (0.0, 2.0)]    # data mean 0.5, unit noise
        p2 = [0.0, 1.0]                                            # priors on unobserved theta2: never updated
        diffs.append((nn, abs(p1[0] - p1[1]), abs(p2[0] - p2[1])))
    must(diffs[-1][1] < 0.003 and all(d[2] == 1.0 for d in diffs), "kernel luck")
    rec("F11", "Luck", "Luck (chance) is an observable property of records", "CORNERED",
        f"Block-frequency tests (k = 1..4) on 20 000 bits: binary digits of sqrt 2 (fully deterministic) p-values "
        f"{[round(p, 3) for p in pv['sqrt2 digits (deterministic)']]}; seeded coin {[round(p, 3) for p in pv['seeded coin']]}. "
        "Both pass: a finite record does not separate determinism from chance (L52-L56). Kernel luck is permanent: two "
        f"priors on an unobserved parameter stay {diffs[-1][2]} apart at every n, while on the observed one they merge "
        f"as 1/n ({[round(d[1], 4) for d in diffs]}) (L49).", dict(pvalues=pv, prior_gaps=diffs))
    can("finite records certify randomness", min(pv["sqrt2 digits (deterministic)"]) > 0.01,
        "deterministic digits pass the same tests as the coin")


# ============================================================ F12 interpretations of quantum mechanics are one fibre
def F12():
    rho = np.array([[0.5, 0.5], [0.5, 0.5]])
    projs = {"Z": [np.diag([1, 0]), np.diag([0, 1])], "X": [0.5 * np.array([[1, 1], [1, 1]]), 0.5 * np.array([[1, -1], [-1, 1]])]}
    laws = {k: [float(np.trace(rho @ P).real) for P in v] for k, v in projs.items()}
    interp = {"Copenhagen": laws, "Bohm (deterministic, contextual)": laws, "Many-worlds (branch weights)": laws}
    same = len({json.dumps(v) for v in interp.values()}) == 1
    must(same, "fibre")
    rec("F12", "Realism", "One interpretation of quantum mechanics is observably correct", "CORRESPONDENCE (definitional)",
        "Empirically equivalent interpretations produce one observation law (Born rule, L42), so they lie in one fibre. "
        "Choosing among them is not a protocol task; realism about the latent mechanism is unrefuted but idle.",
        dict(laws=laws))


# ============================================================ F13 operationalism is not self-founding
def F13():
    import itertools as it
    # two protocols on a 4-point latent set, two tasks: the minimal sufficient panel depends on the task
    X = range(4); P = {"p1": [0, 0, 1, 1], "p2": [0, 1, 0, 1]}
    tasks = {"T_a": [0, 0, 1, 1], "T_b": [0, 1, 0, 1]}
    def suff(panel, T):
        key = lambda x: tuple(P[p][x] for p in panel)
        return all(T[x] == T[y] for x in X for y in X if key(x) == key(y))
    minimal = {k: [pn for r in (1, 2) for pn in it.combinations(P, r) if suff(pn, T)][0] for k, T in tasks.items()}
    must(minimal["T_a"] != minimal["T_b"], "task-relative")
    rec("F13", "Protocolism", "Protocols alone, without declarations, determine what to measure", "CORNERED",
        f"Same instruments, two tasks: minimal sufficient panels {minimal}. The selection is task-relative and no "
        "task-free equivariant selector exists (L13). Operationalism needs a declared task: it is not self-founding.")


# ============================================================ F14 Newton vs Einstein: the exact failure point (imported duality)
def F14():
    g = 1.0
    shares = {v: g * v * v for v in (0.0001, 0.01, 0.3, 1.0)}          # structural/energy share of deflection
    eps_crit_light_slow = g / (2 + g)
    must(abs(eps_crit_light_slow - 1 / 3) < 1e-12, "eps_crit")
    rec("F14", "Newton", "Newton's single potential is right in weak fields and wrong in strong ones", "CORNERED (imported)",
        "Gravity Duality: Newton is EXACT for flat structure at any field strength (Phi_kin = (c^2/2)(1 - N^-2)) and fails "
        "exactly when structure is resolved. Structure's share of a deflection is gamma v^2/c^2: "
        f"{ {k: round(v, 6) for k, v in shares.items()} } for v/c = 1e-4 (planets), 0.01, 0.3, light. Two-speed panels refute "
        f"Newton iff relative precision < eps_crit; slow probe + light: eps_crit = {eps_crit_light_slow:.4f}. Newton fails "
        "for light in ARBITRARILY weak fields; slow probes protect him.")


def main(outdir):
    out = pathlib.Path(outdir); out.mkdir(parents=True, exist_ok=True)
    src = pathlib.Path(__file__).read_bytes()
    man = dict(master_seed=MASTER_SEED, blind=False, data="analytic / synthetic; constants CODATA/IAU nominal",
               source_sha256=hashlib.sha256(src).hexdigest(), written_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
    mt = json.dumps(man, indent=2); (out / "rg_corner_manifest.json").write_text(mt)
    t0 = time.time()
    for f in (F01, F02, F03, F04, F05, F06, F07, F08, F09, F10, F11, F12, F13, F14):
        f(); print(RES[-1]["id"], RES[-1]["status"], flush=True)
    res = dict(manifest_sha256=hashlib.sha256(mt.encode()).hexdigest(), python=sys.version.split()[0],
               numpy=np.__version__, sympy=sp.__version__, runtime_s=round(time.time() - t0, 1),
               attacks=RES, canaries=CAN, summary=dict(total=len(RES), canaries_rejected=len(CAN)))
    (out / "rg_corner_results.json").write_text(json.dumps(res, indent=2, default=str))
    print(json.dumps(res["summary"]))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default="."); main(ap.parse_args().out)
