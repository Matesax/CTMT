# RG cornering: report

**Method.** RG cannot derive GR. It corners a claim instead, by proving three things:
1. where the claim is decided (LOCK or refutation);
2. where it is observationally idle (CORRESPONDENCE);
3. which declarations it needs.

| Arena | Result | Upper hand |
|---|---|---|
| Floating box | Equivalence principle = resolution window. Tidal diag(−2,1,1)GM/r³; LEO 1284 E, SNR 1e5–1e6 | resolution decides |
| Floating box | Box reads energy only: R_0i0j is γ-free, R_ijkl ∝ γ; 0.876″ (1911) vs 1.751″ (1915) | RG (box blind to structure) |
| Protocolism vs realism | Realism beyond the quotient is idle; protocolism needs a declared task, units, a class | knowledge: protocolism; existence: none |
| RG vs Einstein, physics | GR wins every test RG can run | Einstein |
| RG vs Einstein, ontology | Field equation selected; points gauge; interiors and topology are remainders; only GM; distance protocol-relative | RG |
| RG vs Einstein, QM | Local realism refuted (0/512, CHSH ≤ 2); determinism survives nonlocally (\|S\| = 2.829) | split |
| RG vs Newton, space | Absolute velocity in the kernel; rotation (bucket, Sagnac) in the quotient | Leibniz / Newton |
| RG vs Newton, gravity | Exact for flat structure; fails where structure is resolved; ε_crit = 1/3 for slow probe + light | Newton (slow), Einstein (light) |
| Luck | √2 digits pass the same tests as a coin; kernel luck permanent; Bell ≠ indeterminism | typed, undecided |
| God | Dilemma. As a protocol: contextual, ~1 bit per chaotic step, unit-conventional, task-declaring. As a non-protocol: outside the quotient | undecided |

**Overall.**
- RG is the referee, not a player, except in the box, where it scores.
- On what observation decides: RG.
- On what the physics is: GR.
- On what exists: nobody, by observation.

**Battery.**
- 14 arenas; 7 canaries rejected by computed criteria. Master seed 20261026.
- Reruns are identical.
- Imported witnesses: F05, F06, F14. Definitional: F12.

**Limits.**
- Not blind.
- Gradiometer figures are order-of-magnitude.
- No experimental data are reanalysed.
