# RG cornering: report (v2, luck arena updated)

**Method.** RG cannot derive GR. It corners a claim instead, by proving three things:
1. where the claim is decided (LOCK or refutation);
2. where it is observationally idle (CORRESPONDENCE);
3. which declarations it needs.

| Arena | Result | Upper hand |
|---|---|---|
| Floating box | Equivalence principle = resolution window. Tidal diag(−2,1,1)GM/r³; LEO 1284 E | resolution decides |
| Floating box | Box reads energy only (R_0i0j γ-free, R_ijkl ∝ γ); 0.876″ vs 1.751″ | RG |
| Protocolism vs realism | Realism beyond the quotient is idle; protocolism needs declarations | knowledge: protocolism |
| RG vs Einstein, physics | GR wins every test RG can run | Einstein |
| RG vs Einstein, ontology | Field equation selected; points gauge; interiors and topology are remainders | RG |
| RG vs Einstein, QM | Local realism refuted; determinism survives nonlocally | split |
| RG vs Newton | Absolute velocity in the kernel; rotation in the quotient; gravity's exact failure point | Leibniz / Newton / Einstein |
| **Luck (updated)** | **Relative luck lockable** (37.7 Mbit; finite-state lucky, oracle +725 767). **Physical luck**: Bell + 8 gates; certificate NOT ISSUED, 0 bits. **Ontological luck**: not definable | gates decide |
| God | Dilemma: protocol (contextual, information-limited, unit-conventional) or outside the quotient | undecided |

**What changed in v2**
- **Arena IV rewritten.** It now has three statuses: relative luck, physical luck behind 8 gates, and
  ontological luck.
- **New witnesses.**
  - F16: an independent 24-vertex no-signalling LP. Guessing probability is 3/2 − S/4 to 1e-9.
  - F17: Bell gate countermodels. A test-flag leak (generation bits constant), biased settings (pooled win
    0.990, stratified S = 2.000) and bit-identical transcripts.
  - F15 and F18 import your final luck battery (code sha256 808f17dd…, certificate checked field by field).
- **Erratum.** The earlier "expansion 3.5×" figure was a projection and is retracted.
- **Canaries.** 10 rejected, up from 7.

**Battery.**
- 18 witnesses; seed 20261026.
- Reruns are identical.
- Requires `luck_final_import/` next to the script.

**Limits.**
- Not blind.
- Gradiometer figures are order-of-magnitude.
- The luck data are synthetic. The full 46.7 MB raw package is referenced by hash, not shipped.
