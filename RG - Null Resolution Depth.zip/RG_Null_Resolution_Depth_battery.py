import numpy as np
from fractions import Fraction
import mpmath as mp
mp.mp.dps = 60
np.set_printoptions(precision=4, suppress=True)
rng = np.random.default_rng(0)

print("="*74)
print("THE NULL IS NOT BINARY. It grades by RESOLUTION DEPTH -- three causes:")
print("  (1) STRUCTURAL  : zero information at every precision & model  -> depth infinity (physical)")
print("  (2) PRECISION   : nonzero information, below current arithmetic -> finite depth (fix: precision/data)")
print("  (3) REPRESENTATION: zero in this model class, nonzero in a richer one -> finite depth (fix: symbol)")
print("="*74)

# ---------- (1) vs (2): distinguish EXACT zero from BELOW-THRESHOLD nonzero via arithmetic depth
print("\n[1 vs 2]  A Fisher spectrum with one exact-zero and one tiny (1e-20) eigenvalue.")
# Build J^T Sigma^-1 J = diag(1.0, 1e-20, 0) in an orthonormal frame (rational so 'exact' is meaningful)
lam_true = [mp.mpf(1), mp.mpf(10)**-20, mp.mpf(0)]
# float64 view
lam_float = np.array([float(x) for x in lam_true])
print("   float64 eigenvalues:      ", lam_float, " <- the 1e-20 and the 0 both read as ~0 to the eye/eps")
eps = np.finfo(float).eps
print("   float64 machine eps = %.2e ; naive threshold collapses BOTH small values to 'null'." % eps)
# high-precision view keeps them separate
print("   60-digit eigenvalues:      [%s, %s, %s]" % (mp.nstr(lam_true[0],3), mp.nstr(lam_true[1],3), mp.nstr(lam_true[2],3)))
def depth(lam):
    if lam == 0: return "infinity (STRUCTURAL: physical blind spot)"
    return "%.0f digits (PRECISION: resolvable with arithmetic/data)" % float(-mp.log10(lam))
for i,l in enumerate(lam_true):
    print("   direction %d resolution-depth = %s" % (i, depth(l)))
print("   -> exact arithmetic (a 'deeper number symbol') separates depth-infinity from finite depth.")

# ---------- (3): representation null -- present in data, invisible to the current symbol class
print("\n[3]  Representation null: y depends on x^2, but a LINEAR model is blind to it.")
n=4000
x = rng.normal(size=n); y = x**2 + 0.01*rng.normal(size=n)     # dependence is real, purely quadratic
def fisher_param(features):
    F = features.T@features / n                                 # Fisher (Gaussian, unit noise) for the coeffs
    # information the model has about y along each feature = corr with y
    beta,_,_,_ = np.linalg.lstsq(features, y, rcond=None)
    r2 = 1 - np.sum((y-features@beta)**2)/np.sum((y-y.mean())**2)
    return r2
r2_lin  = fisher_param(np.column_stack([x, np.ones(n)]))        # symbol depth 1
r2_quad = fisher_param(np.column_stack([x**2, x, np.ones(n)]))  # symbol depth 2
print("   linear model  (symbols {x,1}):     R^2 = %.4f  -> looks NULL (x carries ~no linear info about y)" % r2_lin)
print("   quadratic model (symbols {x^2,x,1}): R^2 = %.4f  -> RESOLVED by a richer symbol (x^2)" % r2_quad)
print("   -> the 'null' was representation depth, not a physical blind spot. Symbol depth 2 recovers it.")

# ---------- THE WALL: physical null is not recoverable by ANY precision or symbol
print("\n[WALL]  A genuinely physical null: a latent coordinate the data never encode.")
d=6; J = rng.normal(size=(4,d))                                 # 4 sensors on 6 latent dims
h = np.linalg.svd(J)[2][4:]                                     # 2 directions no sensor sees
x0 = rng.normal(size=d); x1 = x0 + h.T@rng.normal(size=2)
# try to recover the difference with ANY nonlinear feature map of the data J@x
def feats(z): return np.concatenate([z, z**2, z**3, np.sin(z), np.exp(z)])
print("   latent difference ||x0-x1|| = %.3f ; any nonlinear feature map of the DATA:" % np.linalg.norm(x0-x1))
print("   ||feats(Jx0)-feats(Jx1)|| = %.2e  (identical -- no symbol depth crosses the physical wall)"
      % np.linalg.norm(feats(J@x0)-feats(J@x1)))
print("   -> depth-infinity null is provably beyond every precision and every symbol. That is the bound.")
