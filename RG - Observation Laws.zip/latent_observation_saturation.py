#!/usr/bin/env python3
"""Compute the saturated observable quotient/sector of a latent observation law.

Rows of P are latent states; columns are observable outcomes.  Two latent states
are observationally equivalent exactly when their complete row laws agree.

Canonical outputs
-----------------
classes:
    Equality-of-law equivalence classes.
B:
    Membership matrix, B[i, q] = 1 iff latent state i belongs to class q.
Pi:
    Orthogonal projector onto the full experiment-internal sector
        W_obs = {f in R^n : f_i = f_j whenever P_i = P_j} = im(B).
Q:
    One representative probability law per observable class.
D:
    Centered span of quotient laws in outcome space.  This is a useful
    distinguishability contrast sector, but it is not the quotient itself.

The default is exact equality (up to floating representation after row
normalization). Approximate grouping is deliberately explicit because tolerance
relations need not be transitive. Complete-linkage grouping is used so every
pair inside an approximate class is within tolerance.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Optional, Sequence

import numpy as np


@dataclass
class SaturationResult:
    law: np.ndarray
    labels: List[str]
    classes: List[List[int]]
    class_labels: List[List[str]]
    quotient_law: np.ndarray
    membership: np.ndarray
    projector: np.ndarray
    observable_basis: np.ndarray
    observable_rank: int
    null_basis: np.ndarray
    null_rank: int
    contrast_basis: np.ndarray
    contrast_projector: np.ndarray
    contrast_rank: int
    tolerance: float

    def to_jsonable(self) -> dict:
        return {
            "labels": self.labels,
            "classes": self.classes,
            "class_labels": self.class_labels,
            "quotient_law": self.quotient_law.tolist(),
            "membership": self.membership.tolist(),
            "projector": self.projector.tolist(),
            "observable_basis": self.observable_basis.tolist(),
            "observable_rank": self.observable_rank,
            "null_basis": self.null_basis.tolist(),
            "null_rank": self.null_rank,
            "contrast_basis": self.contrast_basis.tolist(),
            "contrast_projector": self.contrast_projector.tolist(),
            "contrast_rank": self.contrast_rank,
            "tolerance": self.tolerance,
        }


def _validate_and_normalize(P: np.ndarray, atol: float = 1e-12) -> np.ndarray:
    P = np.asarray(P, dtype=float)
    if P.ndim != 2 or P.shape[0] == 0 or P.shape[1] == 0:
        raise ValueError("P must be a non-empty 2D array (latent states x outcomes).")
    if not np.all(np.isfinite(P)):
        raise ValueError("P contains NaN or infinite values.")
    if np.min(P) < -atol:
        raise ValueError("Observation-law probabilities must be non-negative.")
    P = np.maximum(P, 0.0)
    sums = P.sum(axis=1)
    if np.any(sums <= atol):
        raise ValueError("Every latent state must have positive total probability.")
    return P / sums[:, None]


def total_variation(p: np.ndarray, q: np.ndarray) -> float:
    return float(0.5 * np.abs(p - q).sum())


def exact_classes(P: np.ndarray, decimals: int = 14) -> List[List[int]]:
    """Deterministic equality classes after normalized floating-point rounding."""
    buckets: dict[tuple, List[int]] = {}
    for i, row in enumerate(P):
        key = tuple(np.round(row, decimals=decimals).tolist())
        buckets.setdefault(key, []).append(i)
    return list(buckets.values())


def complete_linkage_classes(P: np.ndarray, tolerance: float) -> List[List[int]]:
    """Greedy deterministic complete-linkage classes in total variation distance.

    Every pair in a returned class is within tolerance. Ordering affects which
    valid partition is chosen when tolerance balls overlap; this is an explicit
    approximate protocol choice, not an exact quotient theorem.
    """
    if tolerance < 0:
        raise ValueError("tolerance must be non-negative")
    classes: List[List[int]] = []
    for i in range(P.shape[0]):
        placed = False
        for cls in classes:
            if all(total_variation(P[i], P[j]) <= tolerance for j in cls):
                cls.append(i)
                placed = True
                break
        if not placed:
            classes.append([i])
    return classes


def orthonormal_basis(A: np.ndarray, tol: float = 1e-12) -> np.ndarray:
    """Columns form an orthonormal basis for col(A)."""
    A = np.asarray(A, dtype=float)
    if A.size == 0:
        return np.zeros((A.shape[0], 0))
    U, s, _ = np.linalg.svd(A, full_matrices=False)
    if s.size == 0:
        return np.zeros((A.shape[0], 0))
    threshold = tol * max(A.shape) * max(float(s[0]), 1.0)
    r = int(np.sum(s > threshold))
    return U[:, :r]


def compute_saturation(
    P: np.ndarray,
    labels: Optional[Sequence[str]] = None,
    tolerance: float = 0.0,
    exact_decimals: int = 14,
) -> SaturationResult:
    P = _validate_and_normalize(P)
    n, m = P.shape
    labels = list(labels) if labels is not None else [f"theta_{i}" for i in range(n)]
    if len(labels) != n:
        raise ValueError("labels length must equal number of latent states")

    classes = (exact_classes(P, exact_decimals) if tolerance == 0
               else complete_linkage_classes(P, tolerance))
    k = len(classes)

    # B maps quotient-valued functions to latent class-constant functions.
    B = np.zeros((n, k), dtype=float)
    for q, cls in enumerate(classes):
        B[cls, q] = 1.0

    # Full saturated experiment-internal sector in latent function space.
    basis_obs = B / np.sqrt(B.sum(axis=0, keepdims=True))
    Pi = basis_obs @ basis_obs.T

    # Null/fibre-fluctuation sector: ker(B^T), orthogonal complement of W_obs.
    basis_null = orthonormal_basis(np.eye(n) - Pi)

    # Quotient law. Exact classes have identical rows. In approximate mode the
    # class centroid is part of the declared approximation protocol.
    Q = np.vstack([P[cls].mean(axis=0) for cls in classes])

    # Distinguishability contrasts in outcome-law space.
    centered = Q - Q.mean(axis=0, keepdims=True)
    basis_contrast = orthonormal_basis(centered.T)
    contrast_projector = basis_contrast @ basis_contrast.T

    return SaturationResult(
        law=P,
        labels=labels,
        classes=classes,
        class_labels=[[labels[i] for i in cls] for cls in classes],
        quotient_law=Q,
        membership=B,
        projector=Pi,
        observable_basis=basis_obs,
        observable_rank=k,
        null_basis=basis_null,
        null_rank=n-k,
        contrast_basis=basis_contrast,
        contrast_projector=contrast_projector,
        contrast_rank=basis_contrast.shape[1],
        tolerance=tolerance,
    )


def partitions_equal(a: Iterable[Iterable[int]], b: Iterable[Iterable[int]]) -> bool:
    norm = lambda x: {frozenset(c) for c in x}
    return norm(a) == norm(b)


def run_attack_battery(seed: int = 20260818) -> dict:
    """Deterministic attacks on exact quotient saturation and sector identities."""
    rng = np.random.default_rng(seed)

    # Four distinct laws represented by seven latent states.
    Q = np.array([
        [0.70, 0.20, 0.10, 0.00],
        [0.10, 0.70, 0.10, 0.10],
        [0.25, 0.25, 0.25, 0.25],
        [0.00, 0.20, 0.30, 0.50],
    ])
    owner = np.array([0, 0, 1, 2, 2, 2, 3])
    P = Q[owner]
    base = compute_saturation(P)

    checks = {}
    checks["class_count"] = (base.observable_rank == 4)
    checks["rank_nullity"] = (base.observable_rank + base.null_rank == P.shape[0])
    checks["projector_idempotent"] = np.allclose(base.projector @ base.projector, base.projector)
    checks["projector_symmetric"] = np.allclose(base.projector.T, base.projector)
    checks["law_factorization"] = np.allclose(P, base.membership @ base.quotient_law)
    checks["fibre_annihilation"] = np.allclose(base.projector @ base.null_basis, 0.0, atol=1e-10)

    # Hidden extension/state splitting: duplicate arbitrary representatives.
    split_indices = np.array([0, 1, 1, 2, 3, 4, 4, 5, 6, 6])
    ext = compute_saturation(P[split_indices])
    checks["hidden_extension_class_count_invariant"] = (ext.observable_rank == base.observable_rank)
    checks["hidden_extension_quotient_law_invariant"] = (
        {tuple(x) for x in np.round(ext.quotient_law, 14)} ==
        {tuple(x) for x in np.round(base.quotient_law, 14)}
    )

    # Reparameterization/permutation invariance.
    perm = rng.permutation(P.shape[0])
    inv = np.argsort(perm)
    per = compute_saturation(P[perm])
    checks["reparameterization_projector_covariance"] = np.allclose(
        per.projector[np.ix_(inv, inv)], base.projector
    )

    # Observable refinement attack: split an exact class. A class indicator for
    # the artificial split must fail extensionality and lie outside im(Pi).
    artificial = np.zeros(P.shape[0]); artificial[0] = 1.0
    residual = artificial - base.projector @ artificial
    checks["strict_refinement_not_observable"] = (np.linalg.norm(residual) > 1e-8)

    # Complete coarsening attack: merge two distinct quotient classes. It must
    # identify rows with positive TV distance and therefore lose law completeness.
    i, j = base.classes[0][0], base.classes[1][0]
    checks["strict_coarsening_loses_law"] = total_variation(P[i], P[j]) > 0.0

    # Every random class-constant function factors through B; random arbitrary
    # vectors generally leave a fibre residual.
    z = rng.normal(size=base.observable_rank)
    f = base.membership @ z
    checks["random_observable_factors"] = np.allclose(base.projector @ f, f)
    g = rng.normal(size=P.shape[0])
    checks["generic_latent_function_rejected"] = np.linalg.norm(g - base.projector @ g) > 1e-8

    # Contrast sector cannot exceed k-1 and must reconstruct centered quotient laws.
    centered = base.quotient_law - base.quotient_law.mean(axis=0, keepdims=True)
    checks["contrast_rank_bound"] = base.contrast_rank <= base.observable_rank - 1
    checks["contrast_reconstruction"] = np.allclose(
        centered @ base.contrast_projector, centered, atol=1e-10
    )

    # Approximate boundary witness: non-transitive tolerance relation.
    chain = np.array([[0.50, 0.50], [0.55, 0.45], [0.60, 0.40]])
    d01 = total_variation(chain[0], chain[1])
    d12 = total_variation(chain[1], chain[2])
    d02 = total_variation(chain[0], chain[2])
    checks["approximate_relation_nontransitive_witness"] = d01 <= .051 and d12 <= .051 and d02 > .051

    passed = sum(bool(v) for v in checks.values())
    return {
        "seed": seed,
        "checks": {k: bool(v) for k, v in checks.items()},
        "passed": passed,
        "total": len(checks),
        "all_passed": passed == len(checks),
        "base_classes": base.classes,
        "base_quotient_law": base.quotient_law.tolist(),
        "observable_rank": base.observable_rank,
        "null_rank": base.null_rank,
        "contrast_rank": base.contrast_rank,
    }


def load_law(path: Path) -> tuple[np.ndarray, Optional[List[str]]]:
    if path.suffix.lower() == ".npy":
        return np.load(path), None
    if path.suffix.lower() == ".json":
        obj = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(obj, dict):
            return np.asarray(obj["law"], dtype=float), obj.get("labels")
        return np.asarray(obj, dtype=float), None
    # CSV: numeric-only by default; first column may be labels if parsing fails.
    try:
        return np.loadtxt(path, delimiter=","), None
    except ValueError:
        raw = np.genfromtxt(path, delimiter=",", dtype=str)
        return raw[:, 1:].astype(float), raw[:, 0].tolist()


def demo_law() -> tuple[np.ndarray, List[str]]:
    P = np.array([
        [0.70, 0.20, 0.10, 0.00],
        [0.70, 0.20, 0.10, 0.00],
        [0.10, 0.70, 0.10, 0.10],
        [0.25, 0.25, 0.25, 0.25],
        [0.25, 0.25, 0.25, 0.25],
        [0.00, 0.20, 0.30, 0.50],
    ])
    return P, ["a1", "a2", "b", "c1", "c2", "d"]


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("input", nargs="?", type=Path, help="CSV, JSON, or NPY law matrix")
    ap.add_argument("--tolerance", type=float, default=0.0,
                    help="TV tolerance for explicit approximate complete-linkage classes")
    ap.add_argument("--output", type=Path, help="Write saturation result as JSON")
    ap.add_argument("--battery", action="store_true", help="Run deterministic attack battery")
    ap.add_argument("--seed", type=int, default=20260818)
    args = ap.parse_args()

    if args.battery:
        report = run_attack_battery(args.seed)
        print(json.dumps(report, indent=2))
        if not report["all_passed"]:
            raise SystemExit(1)
        return

    P, labels = load_law(args.input) if args.input else demo_law()
    result = compute_saturation(P, labels=labels, tolerance=args.tolerance)
    payload = result.to_jsonable()
    text = json.dumps(payload, indent=2)
    if args.output:
        args.output.write_text(text + "\n", encoding="utf-8")
    print(f"latent states: {P.shape[0]}")
    print(f"outcomes: {P.shape[1]}")
    print(f"observable quotient classes: {result.observable_rank}")
    print(f"latent fibre/null rank: {result.null_rank}")
    print(f"outcome contrast rank: {result.contrast_rank}")
    for q, names in enumerate(result.class_labels):
        print(f"  q{q}: {names}; law={result.quotient_law[q].tolist()}")
    if args.output:
        print(f"wrote: {args.output}")


if __name__ == "__main__":
    main()
