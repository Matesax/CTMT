"""Attacks on the Distance and Angle Laws, kernel-groupoid descent, walls, R14, and the d = Theta*gamma*M1 reduction."""
from __future__ import annotations

import math

import numpy as np
from scipy.special import polygamma

from common import attack, node, result


def sigm(z):
    return 1 / (1 + np.exp(-z))


def fisher_discrete(pfun, theta, h=1e-6):
    p = pfun(theta); k = len(theta); J = np.zeros((len(p), k))
    for i in range(k):
        e = np.zeros(k); e[i] = h
        J[:, i] = (pfun(theta + e) - pfun(theta - e)) / (2 * h)
    return J.T @ (J / p[:, None])


def families(rng, leak=0.0):
    """Four regular families with an appended coordinate h (index 2) omitted from the law (unless leak > 0)."""
    A = rng.normal(size=(4, 2))
    def bern(t):
        p = sigm(A @ t[:2] + leak * t[2]); return np.concatenate([p, 1 - p])
    W = rng.normal(size=(5, 2))
    def cat(t):
        z = W @ t[:2] + leak * t[2]; e = np.exp(z - z.max()); return e / e.sum()
    def pois_fisher(t):
        lam = np.exp(A @ t[:2]); g = (A * lam[:, None]).T @ A
        out = np.zeros((3, 3)); out[:2, :2] = g; return out
    def gamma_fisher(t):
        k, s = math.exp(t[0]), math.exp(t[1])
        g = np.array([[k * k * polygamma(1, k), k], [k, k]])
        out = np.zeros((3, 3)); out[:2, :2] = g; return out
    return bern, cat, pois_fisher, gamma_fisher, A, W


@attack("G01", "Thm 3.1 (kernel-groupoid descent), Prop 8.2", "Fisher is basic: the silent fibre coordinate is annihilated and representative-independent in four families", "holds")
def g01(seed):
    rng = np.random.default_rng(seed)
    bern, cat, pois, gam, _, _ = families(rng)
    th = np.array([0.3, -0.4, 0.0]); th2 = th.copy(); th2[2] = 2.7
    gs = {"bernoulli": fisher_discrete(bern, th), "categorical": fisher_discrete(cat, th), "poisson": pois(th), "gamma": gam(th)}
    gs2 = {"bernoulli": fisher_discrete(bern, th2), "categorical": fisher_discrete(cat, th2), "poisson": pois(th2), "gamma": gam(th2)}
    vert = max(float(np.abs(g[2]).max()) for g in gs.values())
    rep = max(float(np.abs(gs[k] - gs2[k]).max()) for k in gs)
    bern_l, _, _, _, _, _ = families(np.random.default_rng(seed), leak=1e-3)
    leak_vert = float(np.abs(fisher_discrete(bern_l, th)[2]).max())
    return result("holds" if vert < 1e-12 and rep < 1e-9 else "counterexample", {"max_vertical_entry": vert, "max_representative_change": rep},
                  "mutation: letting h leak into the law at 1e-3 must create a vertical entry", leak_vert > 1e-9)


@attack("G02", "Thm 7.1 (garbling contraction), Prop 8.3", "Markov garbling contracts Fisher information; Poisson thinning ratio is exactly the retention", "holds")
def g02(seed):
    rng = np.random.default_rng(seed)
    bern, cat, pois, _, A, W = families(rng)
    th = rng.normal(size=3) * 0.5
    eps = float(rng.uniform(0.05, 0.3))
    bsc = lambda t: (lambda p: np.concatenate([eps + (1 - 2 * eps) * p[:4], 1 - (eps + (1 - 2 * eps) * p[:4])]))(bern(t))
    merge = lambda t: (lambda p: np.concatenate([[p[0] + p[1]], p[2:]]))(cat(t))
    def gen_max(gg, g):
        g2, gg2 = g[:2, :2], gg[:2, :2]
        L = np.linalg.cholesky(g2); Li = np.linalg.inv(L)
        return float(np.linalg.eigvalsh(Li @ gg2 @ Li.T).max())
    r_bsc = gen_max(fisher_discrete(bsc, th), fisher_discrete(bern, th))
    r_merge = gen_max(fisher_discrete(merge, th), fisher_discrete(cat, th))
    alpha = float(rng.uniform(0.1, 0.9))
    lam = np.exp(A @ th[:2]); gp = (A * lam[:, None]).T @ A; gt = (A * (alpha * lam)[:, None]).T @ A
    r_thin = gen_max(np.pad(gt, ((0, 1), (0, 1))), np.pad(gp, ((0, 1), (0, 1))))
    ok = r_bsc <= 1 + 1e-6 and r_merge <= 1 + 1e-6 and abs(r_thin - alpha) < 1e-9
    # mutation: adding an independent informative channel is not a garbling and must exceed 1
    g_more = fisher_discrete(bern, th)[:2, :2] + fisher_discrete(lambda t: np.array([sigm(t[0] - t[1]), 1 - sigm(t[0] - t[1])]), th)[:2, :2]
    r_anti = gen_max(np.pad(g_more, ((0, 1), (0, 1))), fisher_discrete(bern, th))
    return result("holds" if ok else "counterexample", {"bsc_eps": eps, "ratio_bsc": r_bsc, "ratio_merge": r_merge, "alpha": alpha, "ratio_thinning": r_thin},
                  "mutation: adding an informative channel must give a ratio > 1", r_anti > 1 + 1e-6)


@attack("G03", "Prop 8.3 (reparameterization covariance)", "g' = S^-T g S^-1 and Fisher lengths are chart-invariant", "holds")
def g03(seed):
    rng = np.random.default_rng(seed)
    bern, _, _, _, _, _ = families(rng)
    S = rng.normal(size=(2, 2)) + 2 * np.eye(2)
    th = np.array([0.2, 0.1])
    f2 = lambda t: bern(np.array([t[0], t[1], 0.0]))
    g = fisher_discrete(f2, th)
    gp = fisher_discrete(lambda tp: f2(np.linalg.solve(S, tp)), S @ th)
    pred = np.linalg.inv(S).T @ g @ np.linalg.inv(S)
    u = rng.normal(size=2)
    err = float(np.abs(gp - pred).max() / np.abs(pred).max())
    len_err = abs(u @ g @ u - (S @ u) @ gp @ (S @ u)) / (u @ g @ u)
    # mutation: transporting the tensor covariantly (S g S^T) instead must fail
    bad = float(np.abs(gp - S @ g @ S.T).max() / np.abs(pred).max())
    return result("holds" if err < 1e-6 and len_err < 1e-6 else "counterexample", {"tensor_rel_err": err, "length_rel_err": float(len_err)},
                  "mutation: the wrong transformation law must disagree", bad > 1e-3)


@attack("G04", "No-Go 4.4, Thm 6.1 (site engine)", "rank-one strata get length but no angle; constant isotropic metrics give scaled Euclidean geometry", "holds", needs_node=True)
def g04(seed):
    rng = np.random.default_rng(seed)
    lam = float(rng.uniform(0.5, 3)); q1 = rng.normal(size=2); u, v = rng.normal(size=2), rng.normal(size=2)
    B = rng.normal(size=(2, 2)); G = B @ B.T + 0.1 * np.eye(2)
    calls = [{"lib": "labs", "fn": "distanceAngle", "args": [[[1, 0], [0, 0]], [0, 0], q1.tolist(), u.tolist(), v.tolist()]},
             {"lib": "labs", "fn": "distanceAngle", "args": [[[lam ** 2, 0], [0, lam ** 2]], [0, 0], q1.tolist(), u.tolist(), v.tolist()]},
             {"lib": "labs", "fn": "distanceAngle", "args": [G.tolist(), [0, 0], q1.tolist(), u.tolist(), v.tolist()]},
             {"lib": "labs", "fn": "distanceAngle", "args": [[[1, 0], [0, -1]], [0, 0], q1.tolist(), u.tolist(), v.tolist()]}]
    r1, iso, gen, indef = node(calls)
    euc_cos = u @ v / np.linalg.norm(u) / np.linalg.norm(v)
    ok = ("angleError" in r1 and "cos" not in r1 and abs(r1["distance"] - abs(q1[0])) < 1e-12
          and abs(iso["distance"] - lam * np.linalg.norm(q1)) < 1e-9 and abs(iso["cos"] - euc_cos) < 1e-9
          and abs(gen["cos"] - (u @ G @ v) / math.sqrt((u @ G @ u) * (v @ G @ v))) < 1e-9 and "error" in indef)
    # mutation: the naive cosine on a rank-one form returns +-1 for independent directions (a fake angle of 0 or 180 deg)
    naive = (u[0] * v[0]) / math.sqrt(u[0] ** 2 * v[0] ** 2)
    return result("holds" if ok else "counterexample", {"rank1": r1.get("angleError"), "iso_distance": iso["distance"], "lambda": lam,
                                                        "generic_cos_js": gen["cos"]},
                  "mutation: a naive cosine on the rank-one form must produce the fake value +-1", abs(abs(naive) - 1) < 1e-12)


@attack("G05", "Prop 9.1 (structural vs protocol wall)", "lambda_min = eps^2 (log-log slope 2); a tolerance tau creates a protocol wall at eps^2 <= tau before eps = 0", "holds")
def g05(seed):
    rng = np.random.default_rng(seed)
    eps = np.logspace(-4, -0.5, 12) * rng.uniform(0.8, 1.2)
    lmin = [np.linalg.eigvalsh(np.diag([1, e ** 2]))[0] for e in eps]
    slope = np.polyfit(np.log(eps), np.log(lmin), 1)[0]
    tau = 1e-4
    protocol_wall = [e for e in eps if e ** 2 <= tau]
    rank_tau = [int(np.sum(np.linalg.eigvalsh(np.diag([1, e ** 2])) > tau)) for e in eps]
    ok = abs(slope - 2) < 1e-9 and min(rank_tau) == 1 and max(rank_tau) == 2 and all(e > 0 for e in protocol_wall)
    return result("holds" if ok else "counterexample", {"slope": slope, "rank_at_tau": rank_tau},
                  "mutation: a linear-closing family diag(1, eps) must give slope 1", abs(np.polyfit(np.log(eps), np.log(eps), 1)[0] - 1) < 1e-9)


@attack("G06", "Prop 9.2, Thm 9.3, No-Go 9.4", "at the Z2 wall the ordinary tangent misses the quadratic direction; the jet-rescaled cone is R x R>=0; slice metric is dr^2/(4r)", "holds")
def g06(seed):
    rng = np.random.default_rng(seed)
    pi = lambda u, v: np.array([u, v * v])
    Dpi = np.array([[1, 0], [0, 0]])
    misses = np.allclose(Dpi @ np.array([0, 1]), 0)
    viol, err = 0, 0.0
    for _ in range(5000):
        a, b = rng.normal(size=2); h = 10 ** rng.uniform(-6, -1)
        d = pi(h * a, h * b) - pi(0, 0)
        viol += d[1] < 0
        err = max(err, abs(d[0] / h - a), abs(d[1] / h ** 2 - b * b))
    r = rng.uniform(0.01, 2, 50); v = np.sqrt(r); dv = 1e-7
    slice_err = float(np.max(np.abs(((np.sqrt(r + dv) - v) / dv) ** 2 - 1 / (4 * r)) * 4 * r))
    ok = misses and viol == 0 and err < 1e-9 and slice_err < 1e-5
    # mutation: rescaling the second component by h (first order) must not converge for b != 0
    h = 1e-6; first_order = abs((h * 1.0) ** 2 / h)
    return result("holds" if ok else "counterexample", {"ordinary_tangent_misses_r": misses, "half_space_violations": viol, "cone_recovery_err": err,
                                                        "slice_metric_rel_err": slice_err},
                  "mutation: first-order rescaling sends the r-component to 0 (misses the cone direction)", first_order < 1e-5)


@attack("G07", "Prop 9.5 (projector wall)", "threshold projectors jump by sqrt(2) in Frobenius norm at the exchange and are stable off the wall", "holds")
def g07(seed):
    rng = np.random.default_rng(seed)
    proj = lambda L, tau=1.0: (lambda w, V: V[:, w > tau] @ V[:, w > tau].T)(*np.linalg.eigh(L))
    Pp, Pm = proj(np.diag([1 + 1e-9, 1 - 1e-9, 0.2])), proj(np.diag([1 - 1e-9, 1 + 1e-9, 0.2]))
    jump = float(np.linalg.norm(Pp - Pm))
    fails = 0
    for _ in range(1000):
        t = rng.uniform(0.05, 0.5) * rng.choice([-1, 1]); L = np.diag([1 + t, 1 - t, 0.2])
        margin = abs(t); E = rng.normal(size=(3, 3)); E = (E + E.T) / 2; E *= 0.25 * margin / np.linalg.norm(E, 2)
        fails += not np.allclose(proj(L), proj(L + E), atol=0.2)
    ok = abs(jump - math.sqrt(2)) < 1e-12 and fails == 0
    # mutation: perturbations larger than the margin must sometimes flip the projector
    flips = 0
    for _ in range(200):
        t = 0.05; L = np.diag([1 + t, 1 - t, 0.2]); E = np.diag([-3 * t, 3 * t, 0])
        flips += not np.allclose(proj(L), proj(L + E), atol=0.2)
    return result("holds" if ok else "counterexample", {"jump": jump, "off_wall_failures": fails}, "mutation: a super-margin perturbation must flip the projector", flips > 0)


@attack("G08", "Def 4.1 (RG length) site engine", "relaxed geodesic of the Gaussian Fisher metric reproduces the closed-form Fisher-Rao distance", "holds", needs_node=True)
def g08(seed):
    rng = np.random.default_rng(seed)
    cases = []
    for _ in range(4):
        m1, m2 = rng.uniform(-2, 2, 2); s1, s2 = rng.uniform(0.5, 2.5, 2)
        cases.append((m1, s1, m2, s2))
    outs = node([{"lib": "geodesic_normal", "q0": [c[0], c[1]], "q1": [c[2], c[3]], "K": 48, "iters": 3000} for c in cases])
    def fr(m1, s1, m2, s2):
        a = (m1 - m2) ** 2 + 2 * (s1 - s2) ** 2; b = (m1 - m2) ** 2 + 2 * (s1 + s2) ** 2
        return 2 * math.sqrt(2) * math.atanh(math.sqrt(a / b))
    errs = [abs(o["relaxed"] - fr(*c)) / fr(*c) for o, c in zip(outs, cases)]
    upper = all(o["straight"] >= o["relaxed"] - 1e-9 for o in outs)
    naive = [abs(math.hypot(c[2] - c[0], c[3] - c[1]) - fr(*c)) / fr(*c) for c in cases]
    return result("holds" if max(errs) < 2e-3 and upper else "counterexample", {"rel_errors": errs, "straight_is_upper_bound": upper},
                  "mutation: Euclidean distance in (mu, sigma) must be wrong by > 5%", max(naive) > 0.05)


@attack("G09", "Thm 5.1 / Cor 5.2 / Remark 5.3 (d = Theta*gamma*M1)", "the rank-one reduction is a length under the CTMT readings of Theta, gamma, M1", "open", needs_node=True)
def g09(seed):
    rng = np.random.default_rng(seed)
    # (a) heterogeneous Theta*gamma biases the global product
    a = float(rng.uniform(0.1, 0.5))
    tg = lambda M: 1 + a * np.sin(3 * M)
    M1 = 2.0; Ms = np.linspace(0, M1, 20001); integral = float(np.trapezoid(tg(Ms), Ms))
    product_end, product_mid = float(tg(M1) * M1), float(tg(M1 / 2) * M1)
    bias = abs(product_end - integral) / integral
    # (b) mechanical unit check with the site engine
    src = ("input Θ = 4.30e14 ± 0.05e14 [Hz]\ninput γ = 1.00e13 ± 0.05e13 [Hz]\ninput M1 = 0.380 ± 0.005 [m]\n"
           "print Θ*γ*M1\nprint M1*Θ/γ")
    out = node([{"lib": "calc", "src": src}])[0]
    dims_rg, dims_old = out[0]["parts"][0]["dims"], out[1]["parts"][0]["dims"]
    # control: if M carries the declared unit [Theta*gamma]^-1 m, the reduction is a length
    src2 = "input k = 2.5 ± 0.1 [m]\ninput M1 = 0.38 ± 0.005\nprint k*M1"
    ctrl = node([{"lib": "calc", "src": src2}])[0][0]["parts"][0]["dims"]
    observed = "open" if dims_rg != "m" and dims_old == "m" and bias > 0.01 else "holds"
    return result(observed, {"heterogeneous_amplitude": a, "integral": integral, "product_at_M1": product_end, "product_at_midpoint": product_mid,
                             "relative_bias_endpoint_product": bias, "units_Theta_gamma_M1": dims_rg, "units_M1_Theta_over_gamma": dims_old,
                             "statement": "d = int Theta*gamma dM is a length only if [Theta*gamma] = m / [M]. With Theta, gamma in s^-1 and M1 in m it is m s^-2. The corpus must declare the unit of M (Remark 5.3 anticipates this but the ladder does not fix it). The legacy D_kernel = M1*Theta/gamma is a length under those readings but is not the corpus reduction."},
                  "control: declaring [Theta*gamma] = m per unit M makes the reduction a length", ctrl == "m")


@attack("G10", "R14 (kernel-pair order != Blackwell order)", "two experiments with the same identifiability kernel pair can be Blackwell-incomparable", "holds")
def g10(seed):
    rng = np.random.default_rng(seed)
    th = np.sort(rng.uniform(0.2, 1.5, 200))
    I1, I2 = np.ones_like(th), 9 * th ** 4          # Y = theta + N(0,1)  vs  Y = theta^3 + N(0,1): both injective
    crosses = bool(np.any(I1 > I2) and np.any(I2 > I1))
    I3 = np.ones_like(th) / 4                        # mutation: Y = theta + N(0,4) is a garbling of E1
    ordered = bool(np.all(I3 <= I1))
    return result("holds" if crosses else "counterexample", {"fisher_crossing_at": float(1 / math.sqrt(3)), "crosses": crosses},
                  "mutation: a genuine garbling must be Fisher-ordered everywhere", ordered)
