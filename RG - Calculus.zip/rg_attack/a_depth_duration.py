"""Attacks on Null Resolution Depth, the Observation Limit, and Operational Duration."""
from __future__ import annotations

import math
from fractions import Fraction as Fr

import numpy as np

from common import attack, node, result


def rat_rotation():
    q = Fr
    Rz = [[q(3, 5), q(-4, 5), q(0)], [q(4, 5), q(3, 5), q(0)], [q(0), q(0), q(1)]]
    Rx = [[q(1), q(0), q(0)], [q(0), q(5, 13), q(-12, 13)], [q(0), q(12, 13), q(5, 13)]]
    return [[sum(Rz[i][k] * Rx[k][j] for k in range(3)) for j in range(3)] for i in range(3)]


@attack("N01", "Null Resolution Depth, Thm 3.1 + Remark", "float64 'reports 1, 0, 0' for the spectrum {1, 1e-20, 0}; exact arithmetic separates precision from structural nulls", "sharpened", seeded=False, needs_node=True)
def n01(seed):
    R = rat_rotation()
    orth = all(sum(R[k][i] * R[k][j] for k in range(3)) == (1 if i == j else 0) for i in range(3) for j in range(3))
    rows = {}
    sharpened = True
    for k in (8, 12, 16, 20, 30):
        eps = Fr(1, 10 ** k); D = [Fr(1), eps, Fr(0)]
        F = [[sum(R[i][t] * D[t] * R[j][t] for t in range(3)) for j in range(3)] for i in range(3)]
        Ff = np.array([[float(x) for x in r] for r in F])
        dirs = [[R[i][t] for i in range(3)] for t in range(3)]
        exact = [sum(v[i] * F[i][j] * v[j] for i in range(3) for j in range(3)) for v in dirs]
        flo = [float(np.array([float(x) for x in v]) @ Ff @ np.array([float(x) for x in v])) for v in dirs]
        eig = sorted(np.linalg.eigvalsh(Ff), reverse=True)
        bound = 3 * 3 * np.finfo(float).eps * np.abs(Ff).max()      # a priori rounding bound for a 3x3 symmetric evaluation
        decidable = [abs(e) > bound for e in eig]
        rows[k] = {"exact": [str(e) if e == 0 else f"1e-{k}" if e == eps else str(float(e)) for e in exact],
                   "float_quadratic_forms": flo, "float_eigs": [float(e) for e in eig], "float_error_bound": float(bound),
                   "float_decides_middle": bool(decidable[1]), "float_prints_exact_zero_for_true_zero": eig[2] == 0.0}
        if exact[1] != eps or exact[2] != 0:
            sharpened = False
    # sharpened statement: float64 does not report zero; it returns values below its own error bound, so it cannot decide
    undecided_20 = not rows[20]["float_decides_middle"]
    decided_8 = rows[8]["float_decides_middle"]
    js = node([{"lib": "labs", "fn": "nullDepthLab", "args": [20]}])[0]
    js_ok = js["exact"][1]["str"] == "1/" + "1" + "0" * 20 and js["exact"][2]["zero"] is True
    observed = "sharpened" if sharpened and orth and undecided_20 and js_ok else "holds"
    return result(observed, {"rotation_exactly_orthogonal": orth, "per_k": rows,
                             "statement": "the right test is the a-priori error bound: at k=20 float64 returns nonzero values for both small directions, both inside the bound, so float64 is undecided, not 'reporting 0'. Exact arithmetic decides: depth 20 vs depth infinity."},
                  "mutation: at k = 8 the middle eigenvalue is above the float bound and float64 decides it", decided_8)


@attack("N02", "Null Resolution Depth, Thm 3.3", "a representation null (quadratic dependence) is invisible to a linear class and recovered by a quadratic class", "holds", needs_node=True)
def n02(seed):
    rng = np.random.default_rng(seed)
    x = rng.uniform(-1, 1, 4000); y = x ** 2 + 0.01 * rng.normal(size=4000)
    r2 = lambda X: 1 - np.sum((y - X @ np.linalg.lstsq(X, y, rcond=None)[0]) ** 2) / np.sum((y - y.mean()) ** 2)
    lin, quad = r2(np.c_[np.ones_like(x), x]), r2(np.c_[np.ones_like(x), x, x ** 2])
    js = node([{"lib": "labs", "fn": "representationLab", "args": [4000, 0.01, seed % 2**31]}])[0]
    ok = lin < 0.02 and quad > 0.99 and js["linear"] < 0.02 and js["quadratic"] > 0.99
    y2 = x + 0.01 * rng.normal(size=4000)
    lin2 = 1 - np.sum((y2 - np.c_[np.ones_like(x), x] @ np.linalg.lstsq(np.c_[np.ones_like(x), x], y2, rcond=None)[0]) ** 2) / np.sum((y2 - y2.mean()) ** 2)
    return result("holds" if ok else "counterexample", {"R2_linear": float(lin), "R2_quadratic": float(quad), "js": js},
                  "mutation: a linear dependence must be visible to the linear class", lin2 > 0.99)


@attack("N03", "Observation Limit Thm 4.2 / Null Depth Thm 3.4", "a structural null is invariant under every downstream construction and precision", "holds")
def n03(seed):
    rng = np.random.default_rng(seed)
    J = rng.normal(size=(3, 5)); _, _, Vt = np.linalg.svd(J); v = Vt[-1] * 1.32 / np.linalg.norm(Vt[-1])
    x = rng.normal(size=5)
    feats = [lambda z: z, lambda z: z ** 2, lambda z: z ** 3, np.sin, np.exp]
    worst = max(float(np.max(np.abs(f(J @ x) - f(J @ (x + v))))) for f in feats)
    w = rng.normal(size=5); w -= Vt[-1] * (Vt[-1] @ w); w *= 1e-3
    seen = max(float(np.max(np.abs(f(J @ x) - f(J @ (x + w))))) for f in feats)
    return result("holds" if worst < 1e-12 else "counterexample", {"max_feature_difference_along_kernel": worst},
                  "mutation: a 1e-3 displacement off the kernel must be seen", seen > 1e-6)


@attack("D01", "Operational Duration Thm 3.1", "affine cross-clock maps that pass held-out prediction also satisfy cocycle closure; a non-affine clock breaks it", "holds")
def d01(seed):
    rng = np.random.default_rng(seed)
    t = np.sort(rng.uniform(0, 100, 400)); cal, held = t[:200], t[200:]
    noise = 1e-3
    QA = lambda s: s + noise * rng.normal(size=s.size)
    QB = lambda s: 1.7 * s + 3.0 + noise * rng.normal(size=s.size)
    QC = lambda s: 0.4 * s - 1.2 + noise * rng.normal(size=s.size)
    QCbad = lambda s: 0.4 * s - 1.2 + 2e-5 * s ** 2 + noise * rng.normal(size=s.size)
    fit = lambda X, Y: np.polyfit(X, Y, 1)
    def check(QCf):
        a_ab = fit(QA(cal), QB(cal)); a_bc = fit(QB(cal), QCf(cal)); a_ac = fit(QA(cal), QCf(cal))
        pred = np.polyval(a_ac, QA(held)); rmse = float(np.sqrt(np.mean((pred - QCf(held)) ** 2)))
        defect = (a_ac[0] - a_bc[0] * a_ab[0], a_ac[1] - (a_bc[0] * a_ab[1] + a_bc[1]))
        return rmse, defect
    rmse, defect = check(QC); rmse_bad, defect_bad = check(QCbad)
    ok = rmse < 5 * noise and abs(defect[0]) < 1e-4 and abs(defect[1]) < 1e-2
    return result("holds" if ok else "counterexample", {"heldout_rmse": rmse, "cocycle_defect": defect},
                  "mutation: a quadratic-drift clock must fail held-out prediction", rmse_bad > 10 * noise)


@attack("D02", "Operational Duration Prop 5.1", "the sign of the elapsed contrast is invariant under positive affine gauge; orientation reversal is not a gauge", "holds")
def d02(seed):
    rng = np.random.default_rng(seed)
    ok = True
    for _ in range(1000):
        dA, dB, aAB = rng.uniform(1, 10), rng.uniform(1, 10), rng.uniform(0.5, 2)
        k, c = rng.uniform(0.1, 5), rng.normal()
        D0 = dA - dB / aAB; D1 = (k * dA) - (k * dB) / aAB          # offsets c cancel in elapsed differences
        ok &= np.sign(D0) == np.sign(D1)
    D0 = 3.0 - 2.0; Drev = -3.0 + 2.0
    return result("holds" if ok else "counterexample", {"trials": 1000}, "mutation: k < 0 (orientation reversal) must flip the sign", np.sign(D0) != np.sign(Drev))


@attack("D03", "Operational Duration Non-claim 7.1", "path-dependent clock readings do not exclude a global coordinate (dT/dt = r(v, U))", "holds")
def d03(seed):
    rng = np.random.default_rng(seed)
    T = 50.0; ts = np.linspace(0, T, 20001)
    vA = 0.3 * np.sin(2 * np.pi * ts / T) ** 2 * rng.uniform(0.8, 1.2)
    vB = 0.6 * np.sin(np.pi * ts / T) ** 4
    U = 0.02
    rate = lambda v: 41 * np.sqrt(1 - v ** 2) * (1 + U)
    TA, TB = float(np.trapezoid(rate(vA), ts)), float(np.trapezoid(rate(vB), ts))
    return result("holds" if abs(TA - TB) > 0.1 else "counterexample", {"T_A": TA, "T_B": TB, "shared_coordinate_interval": T},
                  "mutation: under the path-independent law H_PI (rate independent of v) the two readings must coincide",
                  abs(float(np.trapezoid(41 * (1 + U) + 0 * vA, ts)) - float(np.trapezoid(41 * (1 + U) + 0 * vB, ts))) < 1e-9)
