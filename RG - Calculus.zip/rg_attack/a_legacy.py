"""Attacks on the retired CTMT native-calculus constructs (the HTML section supplied with the request).

Every claim of that page is treated as a registered prediction. A counterexample is accepted only if a
corrected construct (the control) does NOT trip the same detector.
"""
from __future__ import annotations

import math

import numpy as np

from common import attack, node, result


# ------------------------------------------------------------------ the old JS evaluator, re-implemented 1:1
def old_eval(expr, env):
    """Old CTMT evaluator rules: every binary operation treats its operands as independent."""
    t = expr[0]
    if t == "num":
        return (expr[1], 0.0)
    if t == "var":
        return env[expr[1]]
    l, r = old_eval(expr[1], env), old_eval(expr[2], env)
    op = t
    if op in "+-":
        return (l[0] + r[0] if op == "+" else l[0] - r[0], math.hypot(l[1], r[1]))
    if op == "*":
        return (l[0] * r[0], math.hypot(r[0] * l[1], l[0] * r[1]))
    if op == "/":
        return (l[0] / r[0], math.hypot(l[1] / r[0], l[0] * r[1] / r[0] ** 2))
    if op == "^":
        m = l[0] ** r[0]
        return (m, math.hypot(r[0] * l[0] ** (r[0] - 1) * l[1], (m * math.log(abs(l[0])) if l[0] else 0) * r[1]))
    raise ValueError(op)


@attack("L01", "legacy calculator", "old evaluator: algebraically equal expressions carry equal uncertainty", "counterexample", seeded=False, needs_node=True)
def l01(seed):
    env = {"x": (2.0, 0.1)}
    X = ("var", "x")
    pairs = {
        "x-x vs 0": (("-", X, X), ("num", 0.0)),
        "x*x vs x^2": (("*", X, X), ("^", X, ("num", 2.0))),
        "x/x vs 1": (("/", X, X), ("num", 1.0)),
        "x+x vs 2*x": (("+", X, X), ("*", ("num", 2.0), X)),
    }
    old = {k: (old_eval(a, env)[1], old_eval(b, env)[1]) for k, (a, b) in pairs.items()}
    broken = {k: v for k, v in old.items() if abs(v[0] - v[1]) > 1e-12}
    # control: the new engine (the site's JS) must give identical sigmas for every pair
    src = "input x = 2 ± 0.1\nprint x-x, 0\nprint x*x, x^2\nprint x/x, 1\nprint x+x, 2*x"
    out = node([{"lib": "calc", "src": src}])[0]
    new = [(p["parts"][0]["sigma"], p["parts"][1]["sigma"]) for p in out]
    new_ok = all(abs(a - b) < 1e-15 for a, b in new)
    return result("counterexample" if len(broken) == 4 else "holds",
                  {"old_sigmas": old, "new_sigmas": new, "x-x old sigma": old["x-x vs 0"][0]},
                  "control: RG engine (forward-mode gradient) must give equal sigmas for all four pairs", new_ok)


# ------------------------------------------------------------------ worked examples 1.6 / 1.7
CLAIMS = {1: {"surv": 390, "O": 0.072}, 2: {"surv": 168, "O": 0.018}}


def worked_example(seed, amp, S, N=3000):
    r = np.random.default_rng(seed)
    x, xp = r.normal(size=N), r.normal(size=N)
    Xi = np.exp(-(x ** 2 + xp ** 2))
    Phi = amp * (np.sin(x) - np.cos(xp))
    m = np.abs(Phi) < 0.3
    K = Xi * np.exp(1j * Phi / S)
    return {"surv": int(m.sum()), "O_text": float(np.sum(Xi * K.imag * m) / N), "O_code": float(np.mean(K.imag[m])),
            "O_textlike_code": float(np.sum(K.imag * m) / N)}


@attack("L02", "legacy worked examples 1.6/1.7", "reported survivors 390 (13%) / 168 (5.6%) and O = +0.072 / +0.018 are reproducible", "counterexample")
def l02(seed):
    rows = {}
    broken = True
    for amp in (1, 2):
        for S in (0.9, 1.0):
            w = worked_example(seed, amp, S)
            rows[f"amp{amp}_S{S}"] = w
            p = w["surv"] / 3000
            z_surv = (CLAIMS[amp]["surv"] - w["surv"]) / math.sqrt(3000 * p * (1 - p))
            sign_ok = any(np.sign(w[k]) == np.sign(CLAIMS[amp]["O"]) for k in ("O_text", "O_code", "O_textlike_code"))
            rows[f"amp{amp}_S{S}"]["z_survivors_vs_claim"] = z_surv
            if abs(z_surv) < 6 or sign_ok:
                broken = False
    # analytic reason for the sign: E[Phi] = -E[cos x'] = -exp(-1/2) < 0 shifts the |Phi|<0.3 window to negative phases
    # control: the detector must accept a claim equal to the reproduced values
    w = worked_example(seed, 1, 1.0)
    control_claim = w["surv"]
    p = control_claim / 3000
    control_accepts = abs((control_claim - w["surv"]) / math.sqrt(3000 * p * (1 - p))) < 6
    # internal arithmetic of the page, from its own printed numbers
    J, C = np.array([0.58, 0.41]), np.array([[0.12, -0.03], [-0.03, 0.98]])
    sig_16 = math.sqrt(J @ C @ J / 390)
    J2, C2 = np.array([0.31, 0.62]), np.array([[0.11, -0.02], [-0.02, 1.87]])
    sig_17 = math.sqrt(J2 @ C2 @ J2 / 168)
    xi1 = math.exp(-1.8)
    im_k1 = xi1 * math.sin((math.sin(0.6) - math.cos(-1.2)) / 0.9)
    rows["own_arithmetic"] = {"sigma_O_1.6_from_printed_J_Cov": sig_16, "claimed": 0.015,
                              "sigma_O_1.7_from_printed_J_Cov": sig_17, "claimed_1.7": 0.035,
                              "first_member_Im_K1": im_k1, "first_member_Xi1_times_ImK1": xi1 * im_k1,
                              "claimed_contribution": 0.0366, "E_Phi_analytic": -math.exp(-0.5)}
    return result("counterexample" if broken else "holds", rows,
                  "control: the same z-test must accept a claim equal to the reproduced survivor count", control_accepts)


@attack("L03", "legacy trigonometry", "|R_tau(exp(i Phi/S))|^2 = 1 (rupture-normalized unit modulation)", "counterexample")
def l03(seed):
    r = np.random.default_rng(seed)
    Phi = np.sin(r.normal(size=3000)) - np.cos(r.normal(size=3000))
    filt = lambda tau: np.exp(1j * Phi) * (np.abs(Phi) < tau)
    mod2 = np.abs(filt(0.3)) ** 2
    frac_zero = float(np.mean(mod2 == 0))
    control = float(np.max(np.abs(np.abs(filt(np.inf)) ** 2 - 1)))
    return result("counterexample" if frac_zero > 0.5 else "holds",
                  {"fraction_with_modulus_0_at_tau_0.3": frac_zero, "control_max_dev_tau_inf": control},
                  "control: without filtering (tau=inf) the identity holds to 1e-15", control < 1e-12)


@attack("L04", "legacy uncertainty", "einsum('ij,ji->', J.T, Cov @ J) is the variance of the observable", "counterexample")
def l04(seed):
    r = np.random.default_rng(seed)

    def old_sigma2(N):
        x, xp = r.normal(size=N), r.normal(size=N)
        Xi, Phi = np.exp(-(x ** 2 + xp ** 2)), np.sin(x) - np.cos(xp)
        J = np.vstack([np.imag(np.exp(1j * Phi)), np.imag(1j * Xi * np.exp(1j * Phi))])
        Cov = np.cov(np.vstack([Xi, Phi]))
        return float(np.einsum("ij,ji->", J.T, Cov @ J)), Xi * np.sin(Phi)
    s1, f1 = old_sigma2(3000)
    s2, f2 = old_sigma2(6000)
    ratio = s2 / s1
    # control: the standard error of a mean scales as 1/N
    se_ratio = (np.var(f2) / 6000) / (np.var(f1) / 3000)
    return result("counterexample" if abs(ratio - 2) < 0.2 else "holds",
                  {"old_sigma2_N3000": s1, "old_sigma2_N6000": s2, "ratio": ratio, "control_se2_ratio": float(se_ratio)},
                  "control: variance of the mean must scale as 1/N (ratio ~ 0.5)", abs(se_ratio - 0.5) < 0.1)


@attack("L05", "legacy uncertainty", "np.gradient over random samples is an ensemble Jacobian", "counterexample")
def l05(seed):
    r = np.random.default_rng(seed)
    N = 3000
    x, xp = r.normal(size=N), r.normal(size=N)
    Xi, Phi = np.exp(-(x ** 2 + xp ** 2)), np.sin(x) - np.cos(xp)
    obs = lambda Xi, Phi: np.real(Xi * np.exp(1j * Phi))
    g1 = np.gradient(obs(Xi, Phi))
    perm = r.permutation(N)
    g2 = np.gradient(obs(Xi[perm], Phi[perm]))
    dep = float(abs(np.mean(g1 ** 2) - np.mean(g2 ** 2)) / np.mean(g1 ** 2))
    # control: analytic partials d/dXi = cos(Phi), d/dPhi = -Xi sin(Phi) are permutation-covariant
    a1 = np.mean(np.cos(Phi) ** 2 + (Xi * np.sin(Phi)) ** 2)
    a2 = np.mean(np.cos(Phi[perm]) ** 2 + (Xi[perm] * np.sin(Phi[perm])) ** 2)
    return result("counterexample" if dep > 0.01 else "holds",
                  {"relative_change_under_reordering": dep, "control_relative_change": float(abs(a1 - a2) / a1)},
                  "control: analytic Jacobian must be invariant under sample reordering", abs(a1 - a2) / a1 < 1e-12)


@attack("L06", "legacy rupture filter", "one rupture filter R_tau is used consistently (sections 1.2-1.7 vs 4.1-4.2)", "counterexample")
def l06(seed):
    r = np.random.default_rng(seed)
    x, xp = r.normal(size=3000), r.normal(size=3000)
    Xi, Phi = np.exp(-(x ** 2 + xp ** 2)), np.sin(x) - np.cos(xp)
    terms = Xi * np.exp(1j * Phi)
    a, b = np.abs(Phi) < 0.3, np.abs(terms) > 0.3
    jac = float((a & b).sum() / max((a | b).sum(), 1))
    ctrl = float(((a & a).sum()) / max((a | a).sum(), 1))
    return result("counterexample" if jac < 0.5 else "holds",
                  {"phase_filter_kept": int(a.sum()), "amplitude_filter_kept": int(b.sum()), "jaccard": jac},
                  "control: a filter compared with itself has Jaccard 1", ctrl == 1.0)


@attack("L07", "legacy dimensional closure", "multiplying by C_phys validates dimensions", "counterexample", seeded=False, needs_node=True)
def l07(seed):
    # C_phys = 1 multiplies an ill-typed sum without complaint; the RG engine must reject it and accept a well-typed one
    old_value = 1.0 * (5.0 + 2.0)       # L [m] + t [s]
    out = node([{"lib": "calc", "src": "input L = 5 ± 0.01 [m]\ninput t = 2 ± 0.1 [s]\ny = L + t"},
                {"lib": "calc", "src": "input L = 5 ± 0.01 [m]\ninput t = 2 ± 0.1 [s]\ny = L / t\nprint y"}])
    rejected = out[0][-1]["kind"] == "error" and "dimension mismatch" in out[0][-1]["msg"]
    accepted = out[1][-1]["kind"] == "print" and out[1][-1]["parts"][0]["dims"] == "m s^-1"
    return result("counterexample" if rejected else "holds",
                  {"old_C_phys_result": old_value, "rg_engine_ill_typed": out[0][-1], "rg_engine_well_typed": out[1][-1]["parts"][0]},
                  "control: the RG engine must accept L/t and type it m s^-1", accepted)


@attack("L08", "legacy divergence", "D_KL(p||q) = E[p(x_i) log(p(x_i)/q(x_i))] with x_i ~ p", "counterexample")
def l08(seed):
    r = np.random.default_rng(seed)
    x = r.normal(0, 1, 200000)
    logp = -0.5 * x ** 2 - 0.5 * math.log(2 * math.pi)
    logq = -0.5 * ((x - 1) / 2) ** 2 - math.log(2) - 0.5 * math.log(2 * math.pi)
    exact = math.log(2) + (1 + 1) / (2 * 4) - 0.5        # KL(N(0,1) || N(1,4))
    old = float(np.mean(np.exp(logp) * (logp - logq)))
    new = float(np.mean(logp - logq))
    return result("counterexample" if abs(old - exact) > 0.1 else "holds",
                  {"exact": exact, "old_estimator": old, "correct_estimator": new},
                  "control: E_p[log p/q] must match the exact value to 0.01", abs(new - exact) < 0.01)


@attack("L09", "legacy complexity table", "ensemble expectation replaces integrals at O(n) where legacy needs O(n^3) (blanket claim)", "counterexample")
def l09(seed):
    r = np.random.default_rng(seed)
    exact = math.sqrt(math.pi) * math.erf(3)
    f = lambda x: np.exp(-x ** 2)
    xs = np.linspace(-3, 3, 51)
    simpson = (6 / 50 / 3) * (f(xs[0]) + f(xs[-1]) + 4 * f(xs[1:-1:2]).sum() + 2 * f(xs[2:-1:2]).sum())
    mc = 6 * float(np.mean(f(r.uniform(-3, 3, 1_000_000))))
    err_s, err_mc = abs(simpson - exact), abs(mc - exact)
    # control (boundary): in dimension 8, a tensor Simpson grid of 3^8 nodes loses to Monte Carlo with the same budget
    d = 8
    exact8 = (math.sqrt(math.pi) * math.erf(1)) ** d
    g = np.array([-1.0, 0.0, 1.0]); w = np.array([1, 4, 1]) / 3
    grid = (w[:, None] * f(g)[:, None]).sum() ** d     # separable, so the grid value factorizes
    mc8 = 2 ** d * float(np.mean(np.exp(-(r.uniform(-1, 1, (3 ** d, d)) ** 2).sum(1))))
    mc_wins_high_d = abs(mc8 - exact8) < abs(grid - exact8)
    return result("counterexample" if err_s < err_mc / 100 else "holds",
                  {"1D_simpson_51_nodes_error": err_s, "1D_monte_carlo_1e6_error": err_mc,
                   "8D_grid_6561_error": abs(grid - exact8), "8D_mc_6561_error": abs(mc8 - exact8)},
                  "control/boundary: Monte Carlo must win in 8 dimensions at equal budget", mc_wins_high_d)


@attack("L10", "legacy vector calculus", "np.gradient(Fx)[0] + np.gradient(Fy)[0] is a divergence field", "counterexample", seeded=False)
def l10(seed):
    Fx, Fy = np.sin(np.linspace(0, 3, 50)), np.cos(np.linspace(0, 3, 50))
    old = np.gradient(Fx)[0] + np.gradient(Fy)[0]
    gx = np.gradient(Fx)
    return result("counterexample" if np.ndim(old) == 0 else "holds", {"old_output_shape": list(np.shape(old)), "old_value": float(old)},
                  "control: np.gradient(Fx) itself is a field of length 50", gx.shape == (50,))
