"""Attacks on Uncertainty Geometry (UG03, UG04/R45, UG08, UG10)."""
from __future__ import annotations

import math

import numpy as np

from common import attack, jnum, node, result

Z = 1.959963984540054


def fold_sim(b, sigma, reps, rng):
    y = b * b + sigma * rng.normal(size=reps)
    lo, hi = y - Z * sigma, y + Z * sigma
    obs_cov = (b * b >= lo) & (b * b <= hi)
    bh = np.sqrt(np.maximum(y, 0))
    with np.errstate(divide="ignore"):
        se = np.where(bh > 0, sigma / (2 * bh), np.inf)
    lin = np.abs(b - bh) <= Z * se
    a, c = np.sqrt(np.maximum(lo, 0)), np.sqrt(np.maximum(hi, 0))
    rg = (hi >= 0) & (abs(b) >= a) & (abs(b) <= c)
    return obs_cov, lin, rg


@attack("U01", "R45 / UG04", "at a fold the full preimage keeps observation coverage identically; the linearized interval selects one branch", "holds")
def u01(seed):
    rng = np.random.default_rng(seed)
    ev, identity = {}, True
    for b in (1.0, -1.0, 0.0, 0.2):
        obs, lin, rg = fold_sim(b, 0.1, 20000, rng)
        identity &= bool(np.all(obs == rg))
        ev[f"b={b}"] = {"observation": float(obs.mean()), "linearized": float(lin.mean()), "rg_preimage": float(rg.mean())}
    js = node([{"lib": "labs", "fn": "foldCoverage", "args": [-1.0, 0.1, 20000, seed % 2**31]}])[0]
    ev["js_negative_branch"] = js
    branch_failure = ev["b=-1.0"]["linearized"] < 0.01 and abs(ev["b=1.0"]["linearized"] - 0.95) < 0.01
    ok = identity and branch_failure and js["linear"] < 0.01 and abs(js["rgSet"] - js["observation"]) < 1e-12
    # mutation: use the linearized interval as the "RG set" -> identity must break on the negative branch
    obs, lin, _ = fold_sim(-1.0, 0.1, 5000, rng)
    return result("holds" if ok else "counterexample", ev,
                  "mutation: replacing the preimage by the linearized interval must break the identity", not np.all(obs == lin))


def posterior(m0, V0, n, s, q_true, full_rank=False):
    a = np.array([1.0, 1.0])
    P = np.linalg.inv(V0) + n / s ** 2 * np.outer(a, a)
    b = np.linalg.inv(V0) @ m0 + n / s ** 2 * a * q_true
    if full_rank:
        c = np.array([1.0, -1.0]); P = P + n / s ** 2 * np.outer(c, c); b = b + n / s ** 2 * c * 0.3
    V = np.linalg.inv(P); m = V @ b
    return m @ a, a @ V @ a, np.array([1, -1]) @ V @ np.array([1, -1])


@attack("U02", "UG03 (Theorem 3.2)", "the quotient forgets the prior at rate 1/n; the kernel coordinate never forgets", "holds")
def u02(seed):
    rng = np.random.default_rng(seed)
    A = (np.zeros(2), np.eye(2))
    L = rng.normal(size=(2, 2)); VB = L @ L.T + 0.2 * np.eye(2)          # random second prior per seed
    B = (rng.normal(size=2), VB)
    ns = [10, 100, 1000, 10000, 100000]
    qd, kd = [], []
    for n in ns:
        qa, _, ka = posterior(*A, n, 1.0, 2.0); qb, _, kb = posterior(*B, n, 1.0, 2.0)
        qd.append(abs(qa - qb)); kd.append(abs(ka - kb))
    slope = np.polyfit(np.log(ns), np.log(qd), 1)[0]
    # exact limit of the kernel variance: prior conditional variance of x1-x2 given x1+x2
    def cond_var(V):
        a, c = np.array([1, 1]), np.array([1, -1])
        return c @ V @ c - (c @ V @ a) ** 2 / (a @ V @ a)
    limit = abs(cond_var(A[1]) - cond_var(VB))
    ok = abs(slope + 1) < 0.05 and abs(kd[-1] - limit) < 1e-4 * max(limit, 1e-9) + 1e-9
    js = node([{"lib": "labs", "fn": "priorLab", "args": [[10, 1000, 100000], False]}])[0]
    _, _, kmut_a = posterior(*A, 100000, 1.0, 2.0, True); _, _, kmut_b = posterior(*B, 100000, 1.0, 2.0, True)
    return result("holds" if ok else "counterexample",
                  {"identifiable_diff": qd, "log_slope": slope, "kernel_var_diff": kd, "kernel_limit_exact": limit, "js_priorLab": js},
                  "mutation: a full-rank law (second channel on x1-x2) must make the kernel difference vanish",
                  abs(kmut_a - kmut_b) < 1e-4 * max(limit, 1e-9))


def moments_x_cx3(c, law):
    m = {"normal": (3, 15), "uniform": (1.8, 27 / 7), "laplace": (6, 90), "twopoint": (1, 1)}[law]
    return math.sqrt(1 + 2 * c * m[0] + c * c * m[1])


@attack("U03", "UG08/UG10 vs R31/R36", "FORCED over a declared admissible family makes Monte Carlo objective (UG10)", "sharpened", needs_node=True)
def u03(seed):
    """A finite list can certify FORCED while an unlisted law with the same declared mean and variance breaks it.
    Exact moments for y = x + c x^3, x standardized: Var y = 1 + 2c m4 + c^2 m6."""
    c = 0.07
    sd = {law: moments_x_cx3(c, law) for law in ("normal", "uniform", "laplace", "twopoint")}
    spread_list = abs(sd["normal"] - sd["uniform"]) / sd["normal"]
    spread_full = max(abs(sd["normal"] - sd["twopoint"]), abs(sd["normal"] - sd["uniform"])) / sd["normal"]
    src = lambda fam: f"input x = 0 ± 1\nfamily {fam}\nsamples 200000\nseed {seed}\ncertify x + {c}*x^3"
    a, b = node([{"lib": "calc", "src": src("normal, uniform")}, {"lib": "calc", "src": src("normal, uniform, twopoint")}])
    v_list = a[-1]["statements"][0]["verdict"]; v_full = b[-1]["statements"][0]["verdict"]
    observed = "sharpened" if (spread_list <= 0.1 < spread_full and v_list == "FORCED" and v_full == "CONDITIONAL") else "holds"
    # mutation: for a LINEAR output, every law with the declared variance gives the same sigma (FORCED over the class)
    lin = node([{"lib": "calc", "src": f"input x = 0 ± 1\nfamily normal, uniform, laplace, twopoint\nsamples 200000\nseed {seed}\ncertify 3*x"}])[0]
    return result(observed, {"exact_sd": sd, "exact_spread_list": spread_list, "exact_spread_with_twopoint": spread_full,
                             "engine_list_verdict": v_list, "engine_with_twopoint_verdict": v_full,
                             "statement": "FORCED is a statement about the declared list; it is a class statement only when the output is linear (it then depends on the first two moments alone)"},
                  "mutation: a linear output must stay FORCED when the two-point law is added", lin[-1]["statements"][0]["verdict"] == "FORCED")


@attack("U04", "UG04 / LAN", "linear propagation and Monte Carlo agree on regular strata and disagree at walls", "holds")
def u04(seed):
    rng = np.random.default_rng(seed)
    out = {}
    for name, f, df, x0, s in [("exp regular", np.exp, np.exp, 1.0, 0.01), ("square regular", np.square, lambda x: 2 * x, 1.0, 0.01),
                               ("square fold", np.square, lambda x: 2 * x, 0.0, 0.1)]:
        xs = x0 + s * rng.normal(size=200000)
        out[name] = {"linear_sd": abs(df(x0)) * s, "mc_sd": float(np.std(f(xs)))}
    reg = all(abs(out[k]["mc_sd"] / out[k]["linear_sd"] - 1) < 0.05 for k in ("exp regular", "square regular"))
    wall = out["square fold"]["linear_sd"] == 0 and out["square fold"]["mc_sd"] > 0.01
    return result("holds" if reg else "counterexample", out, "mutation: the fold must disagree", wall)
