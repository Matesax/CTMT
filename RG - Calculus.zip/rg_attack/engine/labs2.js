/* RG labs, part 2: routing, the CHI channel estimator, wind turbines, road-vehicle fuel.
 * Pure functions, no DOM; attacked by the Python battery through the Node harness. */
(function (root) {
  "use strict";
  const rng = (seed) => root.RGCalc.mulberry32(seed);
  const draw = (law, r) => root.RGCalc.stdDraw(law, r);

  // =============================================================== special functions
  function lnGamma(x) {
    const g = 7, c = [0.99999999999980993, 676.5203681218851, -1259.1392167224028, 771.32342877765313, -176.61502916214059,
      12.507343278686905, -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7];
    if (x < 0.5) return Math.log(Math.PI / Math.abs(Math.sin(Math.PI * x))) - lnGamma(1 - x);
    x -= 1; let a = c[0]; const t = x + g + 0.5;
    for (let i = 1; i < 9; i++) a += c[i] / (x + i);
    return 0.5 * Math.log(2 * Math.PI) + (x + 0.5) * Math.log(t) - t + Math.log(a);
  }
  const gammaFn = (x) => Math.exp(lnGamma(x));
  function gammaQ(a, x) { // regularized upper incomplete gamma
    if (x <= 0) return 1;
    if (x < a + 1) { let s = 1 / a, t = s; for (let n = 1; n < 500; n++) { t *= x / (a + n); s += t; if (Math.abs(t) < 1e-15 * s) break; }
      return 1 - s * Math.exp(-x + a * Math.log(x) - lnGamma(a)); }
    let b = x + 1 - a, c = 1e300, d = 1 / b, h = d;
    for (let i = 1; i < 500; i++) { const an = -i * (i - a); b += 2; d = an * d + b; if (Math.abs(d) < 1e-300) d = 1e-300; c = b + an / c; if (Math.abs(c) < 1e-300) c = 1e-300; d = 1 / d; const del = d * c; h *= del; if (Math.abs(del - 1) < 1e-15) break; }
    return Math.exp(-x + a * Math.log(x) - lnGamma(a)) * h;
  }
  const chi2Sf = (x, k) => gammaQ(k / 2, x / 2);
  function simpson(f, a, b, n) { if (n % 2) n++; const h = (b - a) / n; let s = f(a) + f(b); for (let i = 1; i < n; i++) s += (i % 2 ? 4 : 2) * f(a + i * h); return s * h / 3; }
  function quantile(sorted, p) { if (!sorted.length) return NaN; const h = (sorted.length - 1) * p, lo = Math.floor(h), hi = Math.ceil(h); return sorted[lo] + (sorted[hi] - sorted[lo]) * (h - lo); }
  const meanSd = (a) => { const m = a.reduce((s, v) => s + v, 0) / a.length; return [m, Math.sqrt(a.reduce((s, v) => s + (v - m) ** 2, 0) / Math.max(a.length - 1, 1))]; };

  // =============================================================== ROUTING
  // TSPLIB GEO distance (Reinelt 1991, TSPLIB documentation): exact integer metric of the library
  function tsplibGeo(coords) {
    const PI = 3.141592, RRR = 6378.388;
    const rad = (v) => { const d = Math.trunc(v), m = v - d; return PI * (d + 5 * m / 3) / 180; };
    const g = coords.map(([x, y]) => [rad(x), rad(y)]), n = g.length, D = [];
    for (let i = 0; i < n; i++) { D.push(new Array(n).fill(0)); for (let j = 0; j < n; j++) if (i !== j) {
      const q1 = Math.cos(g[i][1] - g[j][1]), q2 = Math.cos(g[i][0] - g[j][0]), q3 = Math.cos(g[i][0] + g[j][0]);
      D[i][j] = Math.trunc(RRR * Math.acos(0.5 * ((1 + q1) * q2 - (1 - q1) * q3)) + 1); } }
    return D;
  }
  function haversine(coords, R) {
    R = R || 6371.0088; const n = coords.length, D = [];
    for (let i = 0; i < n; i++) { D.push(new Array(n).fill(0)); for (let j = 0; j < n; j++) if (i !== j) {
      const [p1, l1] = coords[i].map((v) => v * Math.PI / 180), [p2, l2] = coords[j].map((v) => v * Math.PI / 180);
      const h = Math.sin((p2 - p1) / 2) ** 2 + Math.cos(p1) * Math.cos(p2) * Math.sin((l2 - l1) / 2) ** 2;
      D[i][j] = 2 * R * Math.asin(Math.min(1, Math.sqrt(h))); } }
    return D;
  }
  function euclid(coords) { const n = coords.length, D = []; for (let i = 0; i < n; i++) { D.push(new Array(n).fill(0));
    for (let j = 0; j < n; j++) D[i][j] = Math.hypot(coords[i][0] - coords[j][0], coords[i][1] - coords[j][1]); } return D; }
  const tourCost = (D, t) => { let s = 0; for (let i = 0; i < t.length; i++) s += D[t[i]][t[(i + 1) % t.length]]; return s; };
  function canon(t) { const i = t.indexOf(0), r = t.slice(i).concat(t.slice(0, i)); if (r.length > 2 && r[1] > r[r.length - 1]) { const s = [0].concat(r.slice(1).reverse()); return s.join(","); } return r.join(","); }

  // Held–Karp dynamic programme: exact optimum, n <= 17
  function heldKarp(D) {
    const n = D.length;
    if (n <= 3) { const t = [...Array(n).keys()]; return { cost: tourCost(D, t), tour: t }; }
    if (n > 17) throw new Error("exact solver limited to 17 stops; use the heuristic with the lower bound");
    const m = n - 1, full = 1 << m, dp = new Float64Array(full * m).fill(Infinity), par = new Int8Array(full * m).fill(-1);
    for (let j = 0; j < m; j++) dp[(1 << j) * m + j] = D[0][j + 1];
    for (let S = 1; S < full; S++) for (let j = 0; j < m; j++) {
      const v = dp[S * m + j]; if (v === Infinity || !((S >> j) & 1)) continue;
      const row = D[j + 1];
      for (let k = 0; k < m; k++) { if ((S >> k) & 1) continue; const T = S | (1 << k), w = v + row[k + 1];
        if (w < dp[T * m + k]) { dp[T * m + k] = w; par[T * m + k] = j; } }
    }
    let best = Infinity, last = -1;
    for (let j = 0; j < m; j++) { const w = dp[(full - 1) * m + j] + D[j + 1][0]; if (w < best) { best = w; last = j; } }
    const tour = []; let S = full - 1, j = last;
    while (j >= 0) { tour.push(j + 1); const p = par[S * m + j]; S &= ~(1 << j); j = p; }
    tour.push(0); tour.reverse();
    return { cost: best, tour };
  }

  function twoOpt(D, t) {
    const n = t.length; let improved = true;
    while (improved) { improved = false;
      for (let i = 0; i < n - 1; i++) for (let k = i + 2; k < n; k++) {
        if (i === 0 && k === n - 1) continue;
        const a = t[i], b = t[i + 1], c = t[k], d = t[(k + 1) % n];
        if (D[a][c] + D[b][d] - D[a][b] - D[c][d] < -1e-10) { for (let x = i + 1, y = k; x < y; x++, y--) [t[x], t[y]] = [t[y], t[x]]; improved = true; }
      } }
    return t;
  }
  function orOpt(D, t) {
    const n = t.length; let improved = true;
    while (improved) { improved = false;
      for (let len = 1; len <= 3 && !improved; len++) for (let i = 0; i + len <= n && !improved; i++) {
        const seg = t.slice(i, i + len), prev = t[(i - 1 + n) % n], next = t[(i + len) % n];
        if (seg.includes(prev) || seg.includes(next)) continue;
        const rem = D[prev][seg[0]] + D[seg[len - 1]][next] - D[prev][next];
        const rest = t.slice(0, i).concat(t.slice(i + len));
        for (let j = 0; j < rest.length && !improved; j++) {
          const a = rest[j], b = rest[(j + 1) % rest.length];
          for (const s of [seg, seg.slice().reverse()]) {
            const add = D[a][s[0]] + D[s[s.length - 1]][b] - D[a][b];
            if (add - rem < -1e-10) { const nt = rest.slice(0, j + 1).concat(s, rest.slice(j + 1)); for (let q = 0; q < n; q++) t[q] = nt[q]; improved = true; break; }
          }
        }
      } }
    return t;
  }
  function localSearch(D, t) { let c = tourCost(D, t), last; do { last = c; twoOpt(D, t); orOpt(D, t); c = tourCost(D, t); } while (c < last - 1e-10); return t; }
  function heuristic(D, restarts, seed, kicks) {
    const n = D.length, r = rng(seed || 1); restarts = restarts || 8; kicks = kicks === undefined ? 30 : kicks;
    if (n <= 3) { const t = [...Array(n).keys()]; return { cost: tourCost(D, t), tour: t }; }
    let best = null;
    for (let s = 0; s < restarts; s++) {
      const start = s === 0 ? 0 : Math.floor(r() * n), used = new Uint8Array(n), t = [start]; used[start] = 1;
      for (let k = 1; k < n; k++) { const last = t[t.length - 1]; let bj = -1, bd = Infinity;
        for (let j = 0; j < n; j++) if (!used[j] && D[last][j] < bd) { bd = D[last][j]; bj = j; } t.push(bj); used[bj] = 1; }
      localSearch(D, t); let c = tourCost(D, t);
      for (let q = 0; q < kicks && n >= 8; q++) { // double-bridge kick (iterated local search)
        const p = [1, 2, 3].map(() => 1 + Math.floor(r() * (n - 1))).sort((a, b) => a - b);
        if (p[0] === p[1] || p[1] === p[2]) continue;
        const nt = t.slice(0, p[0]).concat(t.slice(p[2]), t.slice(p[1], p[2]), t.slice(p[0], p[1]));
        localSearch(D, nt); const nc = tourCost(D, nt); if (nc < c - 1e-10) { c = nc; for (let i = 0; i < n; i++) t[i] = nt[i]; }
      }
      if (!best || c < best.cost) best = { cost: c, tour: t.slice() };
    }
    return best;
  }
  // Held–Karp 1-tree lower bound with subgradient optimisation (Held & Karp 1970/71): valid for every penalty vector
  function oneTree(D, pi, twoLargest) {
    const n = D.length, inT = new Uint8Array(n), key = new Float64Array(n).fill(Infinity), par = new Int32Array(n).fill(-1), deg = new Int32Array(n);
    key[1] = 0; let total = 0;
    for (let it = 1; it < n; it++) {
      let u = -1, b = Infinity; for (let v = 1; v < n; v++) if (!inT[v] && key[v] < b) { b = key[v]; u = v; }
      inT[u] = 1; total += b; if (par[u] >= 0) { deg[u]++; deg[par[u]]++; }
      for (let v = 1; v < n; v++) if (!inT[v]) { const w = D[u][v] + pi[u] + pi[v]; if (w < key[v]) { key[v] = w; par[v] = u; } }
    }
    const e = []; for (let v = 1; v < n; v++) e.push([D[0][v] + pi[0] + pi[v], v]); e.sort((a, b) => a[0] - b[0]);
    const pick = twoLargest ? [e[e.length - 1], e[e.length - 2]] : [e[0], e[1]];
    for (const [w, v] of pick) { total += w; deg[0]++; deg[v]++; }
    let sp = 0; for (let i = 0; i < n; i++) sp += pi[i];
    return { bound: total - 2 * sp, deg };
  }
  function hkBound(D, ub, iters, mutateTwoLargest) {
    const n = D.length; if (n < 4) return ub;
    const pi = new Float64Array(n); let best = -Infinity, lam = 2, stall = 0; iters = iters || 400;
    for (let it = 0; it < iters; it++) {
      const { bound, deg } = oneTree(D, pi, mutateTwoLargest);
      if (bound > best + 1e-9) { best = bound; stall = 0; } else if (++stall > 20) { lam /= 2; stall = 0; }
      let norm = 0; for (let i = 0; i < n; i++) norm += (deg[i] - 2) ** 2;
      if (norm === 0) { best = Math.max(best, bound); break; }
      const t = lam * (ub - bound) / norm; for (let i = 0; i < n; i++) pi[i] += t * (deg[i] - 2);
      if (lam < 1e-6) break;
    }
    return best;
  }
  function solve(D, opts) {
    opts = opts || {}; const n = D.length, t0 = Date.now();
    let res, method;
    if (n <= (opts.exactMax || 16)) { res = heldKarp(D); method = "exact (Held–Karp dynamic programme)"; }
    else { res = heuristic(D, opts.restarts || 10, opts.seed || 1, opts.kicks); method = "heuristic (nearest neighbour, 2-opt, Or-opt, double-bridge kicks)"; }
    const lb = method.startsWith("exact") ? res.cost : hkBound(D, res.cost, opts.iters || 600);
    return { ...res, method, lowerBound: lb, gap: res.cost > 0 ? (res.cost - lb) / res.cost : 0, ms: Date.now() - t0 };
  }
  // RG uncertainty on routing: the optimal value is a minimum over tours, hence concave with kinks at ties (a wall)
  function routeUncertainty(D, opts) {
    const n = D.length, r = rng(opts.seed || 1), N = opts.samples || 200, rel = opts.rel === undefined ? 0.1 : opts.rel, law = opts.law || "normal";
    const exact = n <= (opts.exactMax || 12);
    const nom = exact ? heldKarp(D) : heuristic(D, 8, 7);
    const nomKey = canon(nom.tour);
    let varLin = 0; for (let i = 0; i < n; i++) { const a = nom.tour[i], b = nom.tour[(i + 1) % n]; varLin += (rel * D[a][b]) ** 2; }
    const opt = [], nomCost = [], regret = [], keys = {};
    let stays = 0;
    for (let s = 0; s < N; s++) {
      const P = D.map((row) => row.slice());
      for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) { const f = Math.max(0.05, 1 + rel * draw(law, r)); P[i][j] = D[i][j] * f; P[j][i] = D[j][i] * f; }
      const o = exact ? heldKarp(P) : heuristic(P, 3, s + 11, 10), nc = tourCost(P, nom.tour);
      opt.push(o.cost); nomCost.push(nc); regret.push(nc - o.cost);
      const k = canon(o.tour); keys[k] = (keys[k] || 0) + 1; if (nc - o.cost <= 1e-9 * o.cost) stays++;
    }
    const so = opt.slice().sort((a, b) => a - b), sr = regret.slice().sort((a, b) => a - b), [mo, sdo] = meanSd(opt), [mn] = meanSd(nomCost), [mr] = meanSd(regret);
    return { exact, nominal: nom.cost, nominalTour: nom.tour, sigmaLin: Math.sqrt(varLin), optMean: mo, optSd: sdo, opt05: quantile(so, 0.05), opt95: quantile(so, 0.95),
      nominalTourMeanCost: mn, jensenGap: nom.cost - mo, pNominalOptimal: stays / N, distinctOptima: Object.keys(keys).length,
      topTours: Object.entries(keys).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([k, c]) => ({ tour: k, share: c / N, isNominal: k === nomKey })),
      regretMean: mr, regret95: quantile(sr, 0.95), samples: N, law, rel };
  }
  // the retired CTMT "kernel rhythm" cost: Phi_i = d_i / L_K, S_ij = exp(-|Phi_i - Phi_j| g / dPhi), cost = d / (1 + mu S)
  function kernelRhythmCost(D, depot, LK, mu, dphi, g) {
    const n = D.length, Phi = D[depot].map((d) => d / LK), C = []; let maxRel = 0, minS = Infinity, maxS = 0;
    for (let i = 0; i < n; i++) { C.push(new Array(n).fill(0)); for (let j = 0; j < n; j++) if (i !== j) {
      const S = Math.exp(-Math.abs(Phi[i] - Phi[j]) / dphi * g); C[i][j] = D[i][j] / (1 + mu * S);
      maxRel = Math.max(maxRel, Math.abs(C[i][j] - D[i][j]) / D[i][j]); minS = Math.min(minS, S); maxS = Math.max(maxS, S); } }
    return { C, Phi, maxRelChange: maxRel, minS, maxS };
  }
  const INSTANCES = {
    burma14: { metric: "geo", optimum: 3323, source: "TSPLIB burma14 (Reinelt), published optimum 3323",
      coords: [[16.47, 96.10], [16.47, 94.44], [20.09, 92.54], [22.39, 93.37], [25.23, 97.24], [22.00, 96.05], [20.47, 97.02], [17.20, 96.29], [16.30, 97.38], [14.05, 98.12], [16.53, 97.38], [21.52, 95.59], [19.41, 97.13], [20.09, 94.55]] },
    ulysses16: { metric: "geo", optimum: 6859, source: "TSPLIB ulysses16 (Grötschel & Padberg), published optimum 6859",
      coords: [[38.24, 20.42], [39.57, 26.15], [40.56, 25.32], [36.26, 23.12], [33.48, 10.54], [37.56, 12.19], [38.42, 13.11], [37.52, 20.44], [41.23, 9.10], [41.17, 13.05], [36.08, -5.21], [38.47, 15.13], [38.15, 15.35], [37.51, 15.17], [35.49, 14.32], [39.36, 19.56]] },
    centralEurope: { metric: "haversine", optimum: null, source: "Brno depot with Prague, Vienna, Bratislava, Budapest (city-centre coordinates, great-circle km)",
      names: ["Brno", "Prague", "Vienna", "Bratislava", "Budapest"],
      coords: [[49.1951, 16.6068], [50.0755, 14.4378], [48.2082, 16.3738], [48.1486, 17.1077], [47.4979, 19.0402]] },
  };

  // =============================================================== CHI: a one-parameter Buckingham channel
  const G0 = 9.80665;
  const chiValue = (M, v, Phi, g, h, rho) => (M * v * v) / (Phi * g * h * rho);
  // established reference laws (declared parameters; these are physics laws, not measured data)
  function carFuelRate(v, p) { // L/s, road load + Willans-line engine
    const F = p.m * G0 * p.crr + 0.5 * p.rho * p.cda * v * v + p.m * G0 * Math.sin(Math.atan(p.grade || 0));
    const Pb = Math.max(F * v, 0) / p.etaDt + (p.paux || 0);
    return (p.P0 + Pb / p.e) / (p.lhv * 1e6);
  }
  const windPower = (v, p) => 0.5 * p.rho * p.A * v ** 3 * p.cp;
  function pumpPower(Q, p) { // stratum "affinity": speed change, H = H0 (Q/Q0)^2 ; stratum "throttle": fixed head H0
    const H = p.stratum === "affinity" ? p.H0 * (Q / p.Q0) ** 2 : p.H0;
    return 1000 * G0 * Q * H / p.eta;
  }
  const CHI_PRESETS = {
    car: { label: "Road car fuel rate", xName: "speed v [m/s]", yName: "fuel rate [L/s]", unitY: "L/s",
      params: { m: 1500, crr: 0.010, cda: 0.65, rho: 1.2, etaDt: 0.90, e: 0.30, P0: 4000, paux: 300, lhv: 32.0, Phi: 1.3, h: 1.5 },
      truth: (x, p) => carFuelRate(x, p), chi: (x, p) => chiValue(p.m, x, p.Phi, G0, p.h, p.rho), anchors: [20], predict: [10, 15, 25, 30, 40], range: [5, 45] },
    wind: { label: "Wind turbine power", xName: "wind speed v [m/s]", yName: "power [W]", unitY: "W",
      params: { A: 10, cp: 0.40, rho: 1.225, Phi: 1.0 },
      truth: (x, p) => windPower(x, p), chi: (x, p) => chiValue(p.rho * p.A * x, x, p.Phi, G0, Math.sqrt(p.A / Math.PI), p.rho), anchors: [10], predict: [4, 6, 8, 12], range: [3, 14] },
    pumpAffinity: { label: "Pump, speed change (affinity stratum)", xName: "flow Q [m³/s]", yName: "shaft power [W]", unitY: "W",
      params: { Q0: 0.01, H0: 10, eta: 0.7, D: 0.1, Phi: 1.2, h: 10, stratum: "affinity" },
      truth: (x, p) => pumpPower(x, p), chi: (x, p) => { const A = Math.PI * (p.D / 2) ** 2; return chiValue(1000 * x, x / A, p.Phi, G0, p.h, 1000); }, anchors: [0.01], predict: [0.005, 0.015, 0.02], range: [0.003, 0.025] },
    pumpThrottle: { label: "Pump, fixed head (throttled stratum)", xName: "flow Q [m³/s]", yName: "shaft power [W]", unitY: "W",
      params: { Q0: 0.01, H0: 10, eta: 0.7, D: 0.1, Phi: 1.2, h: 10, stratum: "throttle" },
      truth: (x, p) => pumpPower(x, p), chi: (x, p) => { const A = Math.PI * (p.D / 2) ** 2; return chiValue(1000 * x, x / A, p.Phi, G0, p.h, 1000); }, anchors: [0.01], predict: [0.005, 0.015, 0.02], range: [0.003, 0.025] },
  };
  // calibrate y = k chi on anchors (weighted, through the origin); test the law; fit a free exponent; rank hazard
  function chiChannel(preset, opts) {
    const P = CHI_PRESETS[preset]; if (!P) throw new Error("unknown preset " + preset);
    const p = Object.assign({}, P.params, opts.params || {}), r = rng(opts.seed || 1), noise = opts.noise === undefined ? 0.01 : opts.noise;
    const xs = opts.anchors || P.anchors, truthFn = opts.truthIsChi ? (x) => P.chi(x, p) * (P.truth(xs[0], p) / P.chi(xs[0], p)) : (x) => P.truth(x, p);
    const ys = xs.map((x) => truthFn(x) * (1 + noise * draw("normal", r))), sy = ys.map((y) => Math.abs(y) * Math.max(noise, 1e-9)) /* a 0% declaration is exact to 1e-9, never infinite weight */, cs = xs.map((x) => P.chi(x, p));
    let a = 0, b = 0; for (let i = 0; i < xs.length; i++) { a += ys[i] * cs[i] / sy[i] ** 2; b += cs[i] ** 2 / sy[i] ** 2; }
    const k = a / b, sk = Math.sqrt(1 / b);
    let chi2 = 0; for (let i = 0; i < xs.length; i++) chi2 += ((ys[i] - k * cs[i]) / sy[i]) ** 2;
    const dof = xs.length - 1, pval = dof > 0 ? chi2Sf(chi2, dof) : null;
    // free exponent in log space: log y = log k + q log chi
    let fit = null, hazard = 0;
    if (xs.length >= 2) {
      const lx = cs.map(Math.log), ly = ys.map(Math.log), w = sy.map((s, i) => (ys[i] / s) ** 2);
      let S0 = 0, S1 = 0, S2 = 0, T0 = 0, T1 = 0; for (let i = 0; i < xs.length; i++) { S0 += w[i]; S1 += w[i] * lx[i]; S2 += w[i] * lx[i] ** 2; T0 += w[i] * ly[i]; T1 += w[i] * lx[i] * ly[i]; }
      const det = S0 * S2 - S1 * S1;
      if (det > 1e-12 * S0 * S2) { const q = (S0 * T1 - S1 * T0) / det; fit = { q, sq: Math.sqrt(S0 / det) }; }
      const tr = S0 + S2, disc = Math.sqrt(Math.max(tr * tr / 4 - det, 0)); hazard = (tr / 2 - disc) / (tr / 2 + disc);
    }
    const pred = (opts.predict || P.predict).map((x) => { const t = P.truth(x, p), c = k * P.chi(x, p); return { x, truth: t, chi: c, err: (c - t) / t }; });
    const lo = Math.min(...xs), hi = Math.max(...xs);
    let verdict, why;
    if (xs.length === 1) { verdict = "CONDITIONAL"; why = "one anchor identifies k (Fisher rank 1) and nothing else: the transport to other operating points is declared, not tested (UG09, Buckingham L70)"; }
    else if (hazard < 1e-6) { verdict = "WALL"; why = `the anchors are too close together to test anything: rank hazard λmin/λmax = ${hazard.toExponential(1)} (rank-wall indicator of the CHI audit). Spread the anchors`; }
    else if (pval < 0.01) { verdict = "REJECTED"; why = `the χ law fails on its own anchors: χ² = ${chi2.toFixed(1)} on ${dof} dof, p = ${pval.toExponential(2)}`; }
    else { verdict = "NOT REJECTED"; why = `consistent on [${lo}, ${hi}] (p = ${pval.toFixed(3)}); outside that range the transport is still a declaration`; }
    // elasticity in density: the channel's prediction versus the reference law
    const el = (fn) => { const h = 1e-4, pp = Object.assign({}, p, { rho: p.rho * (1 + h) }), pm = Object.assign({}, p, { rho: p.rho * (1 - h) });
      return (Math.log(fn(pp)) - Math.log(fn(pm))) / (Math.log(1 + h) - Math.log(1 - h)); };
    const x0 = xs[0];
    const rhoElastTruth = "rho" in p && preset !== "pumpAffinity" && preset !== "pumpThrottle" ? el((pp) => P.truth(x0, pp)) : null;
    const rhoElastChi = "rho" in p && preset !== "pumpAffinity" && preset !== "pumpThrottle" ? el((pp) => P.chi(x0, pp)) : null;
    return { preset, label: P.label, k, sk, chi2, dof, pval, fit, hazard, anchors: xs.map((x, i) => ({ x, y: ys[i], sy: sy[i], chi: cs[i] })), predictions: pred,
      verdict, why, rhoElastTruth, rhoElastChi, params: p,
      curve: (() => { const out = []; const [a0, a1] = P.range; for (let i = 0; i <= 80; i++) { const x = a0 + (a1 - a0) * i / 80; out.push({ x, truth: P.truth(x, p), chi: k * P.chi(x, p) }); } return out; })() };
  }
  // the "bottleneck" claim of the early CHI paper, as an executable statement
  function bottleneck(values) { const h = values.length / values.reduce((s, v) => s + 1 / v, 0), mn = Math.min(...values), m = values.reduce((s, v) => s + v, 0) / values.length;
    return { harmonic: h, min: mn, mean: m, claimHolds: h <= mn * (1 + 1e-12), betweenMinAndMean: h >= mn * (1 - 1e-12) && h <= m * (1 + 1e-12) }; }

  // =============================================================== WIND TURBINE
  const BETZ = 16 / 27;
  function isaDensity(alt) { const T = 288.15 - 0.0065 * alt, p = 101325 * Math.pow(1 - 2.25577e-5 * alt, 5.25588); return p / (287.05 * T); }
  function turbinePower(v, t) { if (v < t.cutIn || v >= t.cutOut) return 0; return Math.min(t.rated, 0.5 * t.rho * Math.PI * (t.D / 2) ** 2 * v ** 3 * t.cp * t.eta); }
  const weibullPdf = (v, k, c) => (v <= 0 ? 0 : (k / c) * Math.pow(v / c, k - 1) * Math.exp(-Math.pow(v / c, k)));
  function meanPower(t, vmean, k) { const c = vmean / gammaFn(1 + 1 / k); return simpson((v) => turbinePower(v, t) * weibullPdf(v, k, c), 0, Math.max(40, t.cutOut + 1), 800); }
  function ratedSpeed(t) { return Math.pow(2 * t.rated / (t.rho * Math.PI * (t.D / 2) ** 2 * t.cp * t.eta), 1 / 3); }
  function patternFactor(k) { const c = 1 / gammaFn(1 + 1 / k); return { exact: gammaFn(1 + 3 / k) / Math.pow(gammaFn(1 + 1 / k), 3),
    numeric: simpson((v) => v ** 3 * weibullPdf(v, k, c), 0, 30, 6000) }; }
  function turbineReport(t, site) {
    if (t.cp > BETZ) return { error: `Cp = ${t.cp} exceeds the Betz limit 16/27 = ${BETZ.toFixed(4)}: no actuator-disc rotor can extract that fraction` };
    const P = meanPower(t, site.vmean, site.k), H = 8766;
    return { meanPower: P, aep: P * H, cf: P / t.rated, powerAtMean: turbinePower(site.vmean, t), jensenRatio: P / Math.max(turbinePower(site.vmean, t), 1e-300),
      vRated: ratedSpeed(t), curve: Array.from({ length: 141 }, (_, i) => { const v = i * 0.25; return { v, P: turbinePower(v, t) }; }) };
  }
  function turbineMC(t, site, unc, families, N, seed) {
    return families.map((law, fi) => {
      const r = rng(seed + 7919 * fi), aep = [];
      for (let s = 0; s < N; s++) {
        const tt = Object.assign({}, t, { cp: Math.min(BETZ, t.cp * (1 + unc.cp * draw(law, r))), rho: t.rho * (1 + unc.rho * draw(law, r)) });
        const vm = site.vmean * (1 + unc.vmean * draw(law, r)), kk = Math.max(1.05, site.k * (1 + unc.k * draw(law, r)));
        aep.push(meanPower(tt, vm, kk) * 8766);
      }
      aep.sort((a, b) => a - b); const [m, sd] = meanSd(aep);
      return { law, mean: m, sd, p50: quantile(aep, 0.5), p90: quantile(aep, 0.10), p99: quantile(aep, 0.01) };
    });
  }
  const TURBINES = {
    nrel5mw: { label: "NREL 5-MW reference turbine (Jonkman et al. 2009)", D: 126, rated: 5e6, cutIn: 3, cutOut: 25, cp: 0.482, eta: 0.944, rho: 1.225, publishedRated: 11.4 },
    small: { label: "Small turbine, 10 m² swept area (the retired CHI example)", D: 2 * Math.sqrt(10 / Math.PI), rated: 3000, cutIn: 3, cutOut: 20, cp: 0.40, eta: 1.0, rho: 1.225, publishedRated: null },
  };

  // =============================================================== ROAD VEHICLE FUEL
  const LBF = 4.4482216152605, MPH = 0.44704;
  function roadLoad(v, p) {
    let F = p.mode === "epa" ? (p.A + p.B * (v / MPH) + p.C * (v / MPH) ** 2) * LBF : p.m * G0 * p.crr + 0.5 * p.rho * p.cda * v * v;
    F += p.m * G0 * Math.sin(Math.atan(p.grade || 0));
    return F;
  }
  function fuelPer100(v, p) { const Pb = Math.max(roadLoad(v, p) * v, 0) / p.etaDt + p.paux, rate = (p.P0 + Pb / p.e) / (p.lhv * 1e6); return rate * 1e5 / v; }
  function fuelReport(p, kmh) {
    const v = kmh / 3.6, aero = p.mode === "epa" ? null : 0.5 * p.rho * p.cda * v ** 3, roll = p.mode === "epa" ? null : p.m * G0 * p.crr * v;
    const speeds = []; for (let s = 20; s <= 160; s += 2) speeds.push(s);
    const curve = speeds.map((s) => ({ kmh: s, L: fuelPer100(s / 3.6, p) }));
    const best = curve.reduce((a, b) => (b.L < a.L ? b : a));
    return { at: fuelPer100(v, p), aeroPower: aero, rollPower: roll, wheelPower: roadLoad(v, p) * v, curve, best,
      basePowerShare: p.P0 / (p.P0 + (roadLoad(v, p) * v / p.etaDt + p.paux) / p.e) };
  }
  function fuelMC(p, unc, families, kmhList, N, seed) {
    return families.map((law, fi) => {
      const r = rng(seed + 104729 * fi), per = kmhList.map(() => []);
      for (let s = 0; s < N; s++) {
        const q = Object.assign({}, p);
        const f = (x) => 1 + x * draw(law, r);
        if (p.mode === "epa") { q.A = p.A * f(unc.load); q.B = p.B * f(unc.load); q.C = p.C * f(unc.load); }
        else { q.cda = p.cda * f(unc.cda); q.crr = p.crr * f(unc.crr); }
        q.e = p.e * f(unc.e); q.P0 = p.P0 * f(unc.P0);
        kmhList.forEach((k, i) => per[i].push(fuelPer100(k / 3.6, q)));
      }
      return { law, rows: per.map((a, i) => { a.sort((x, y) => x - y); const [m, sd] = meanSd(a); return { kmh: kmhList[i], mean: m, sd, q05: quantile(a, 0.05), q95: quantile(a, 0.95) }; }) };
    });
  }

  const api = { lnGamma, gammaFn, gammaQ, chi2Sf, tsplibGeo, haversine, euclid, tourCost, canon, heldKarp, twoOpt, orOpt, heuristic, oneTree, hkBound, solve, routeUncertainty,
    kernelRhythmCost, INSTANCES, chiValue, carFuelRate, windPower, pumpPower, CHI_PRESETS, chiChannel, bottleneck, BETZ, isaDensity, turbinePower, weibullPdf, meanPower,
    ratedSpeed, patternFactor, turbineReport, turbineMC, TURBINES, roadLoad, fuelPer100, fuelReport, fuelMC };
  root.RGLabs2 = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
