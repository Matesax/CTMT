/* RG labs, part 3: the second-order remainder ("the hidden room") and the closure dispatcher.
 * Statement of record: Resolution Geometry (Oct 2026), Sections 16-18, rungs L112-L128.
 * Exact rational arithmetic (BigInt) wherever a claim is about equality. */
(function (root) {
  "use strict";

  // ============================================================ exact rationals
  const babs = (a) => (a < 0n ? -a : a);
  const gcd = (a, b) => { a = babs(a); b = babs(b); while (b) [a, b] = [b, a % b]; return a; };
  class Q {
    constructor(n, d) { d = d === undefined ? 1n : d; if (d === 0n) throw new Error("division by zero"); if (d < 0n) { n = -n; d = -d; } const g = gcd(n, d) || 1n; this.n = n / g; this.d = d / g; }
    static of(x) { if (x instanceof Q) return x; if (typeof x === "bigint") return new Q(x); return Q.parse(String(x)); }
    static parse(s) {
      s = String(s).trim(); if (!s) throw new Error("empty number");
      if (s.includes("/")) { const [a, b] = s.split("/"); return Q.parse(a).div(Q.parse(b)); }
      const m = s.match(/^([+-]?)(\d*)(?:\.(\d*))?(?:[eE]([+-]?\d+))?$/); if (!m || (!m[2] && !m[3])) throw new Error(`not a number: ${s}`);
      let num = BigInt((m[2] || "0") + (m[3] || "")), den = 10n ** BigInt((m[3] || "").length); const e = m[4] ? parseInt(m[4], 10) : 0;
      if (e > 0) num *= 10n ** BigInt(e); else if (e < 0) den *= 10n ** BigInt(-e);
      return new Q(m[1] === "-" ? -num : num, den);
    }
    add(o) { return new Q(this.n * o.d + o.n * this.d, this.d * o.d); } sub(o) { return new Q(this.n * o.d - o.n * this.d, this.d * o.d); }
    mul(o) { return new Q(this.n * o.n, this.d * o.d); } div(o) { return new Q(this.n * o.d, this.d * o.n); } neg() { return new Q(-this.n, this.d); }
    isZero() { return this.n === 0n; } eq(o) { return this.n === o.n && this.d === o.d; } sign() { return this.n > 0n ? 1 : this.n < 0n ? -1 : 0; }
    toNumber() { return Number(this.n) / Number(this.d); }
    toString() { return this.d === 1n ? this.n.toString() : `${this.n}/${this.d}`; }
  }
  const Z = new Q(0n), ONE = new Q(1n);
  const qzeros = (n, m) => Array.from({ length: n }, () => Array.from({ length: m === undefined ? n : m }, () => Z));
  const qeye = (n) => Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => (i === j ? ONE : Z)));
  function qmul(A, B) { const n = A.length, m = B[0].length, k = B.length, C = qzeros(n, m);
    for (let i = 0; i < n; i++) for (let t = 0; t < k; t++) { const a = A[i][t]; if (a.isZero()) continue; for (let j = 0; j < m; j++) if (!B[t][j].isZero()) C[i][j] = C[i][j].add(a.mul(B[t][j])); } return C; }
  const qtr = (A) => A.reduce((s, r, i) => s.add(r[i]), Z);
  const qT = (A) => A[0].map((_, j) => A.map((r) => r[j]));
  function qinv(A) { const n = A.length, M = A.map((r, i) => r.concat(qeye(n)[i]));
    for (let c = 0; c < n; c++) { let p = c; while (p < n && M[p][c].isZero()) p++; if (p === n) throw new Error("singular matrix"); [M[c], M[p]] = [M[p], M[c]];
      const inv = ONE.div(M[c][c]); M[c] = M[c].map((x) => x.mul(inv));
      for (let r = 0; r < n; r++) if (r !== c && !M[r][c].isZero()) { const f = M[r][c]; M[r] = M[r].map((x, j) => x.sub(f.mul(M[c][j]))); } }
    return M.map((r) => r.slice(n)); }
  const toF = (A) => A.map((r) => r.map((x) => x.toNumber()));

  // ============================================================ float helpers
  function fmul(A, B) { const n = A.length, m = B[0].length, k = B.length, C = Array.from({ length: n }, () => new Float64Array(m));
    for (let i = 0; i < n; i++) for (let t = 0; t < k; t++) { const a = A[i][t]; if (a === 0) continue; for (let j = 0; j < m; j++) C[i][j] += a * B[t][j]; } return C; }
  const ftr = (A) => { let s = 0; for (let i = 0; i < A.length; i++) s += A[i][i]; return s; };
  const symEig = (A) => root.RGLabs.symEig(A.map((r) => Array.from(r)));
  const ftrans = (M) => Array.from({ length: M[0].length }, (_, j) => Array.from({ length: M.length }, (_, i) => M[i][j]));
  function singularValues(M) { const MMt = fmul(M, ftrans(M)); return symEig(MMt).values.map((x) => Math.sqrt(Math.max(x, 0))).sort((a, b) => b - a); }

  // ============================================================ the associated tuple (Definition 18.1)
  function tuple(R, N, C) { // R: p x p, N: q x q, C: p x q, all Q matrices
    const p = R.length, q = N.length, n = p + q, P = qzeros(n), D = qzeros(n), S = qzeros(n);
    for (let i = 0; i < p; i++) P[i][i] = ONE;
    for (let i = 0; i < p; i++) for (let j = 0; j < p; j++) D[i][j] = R[i][j];
    for (let i = 0; i < q; i++) for (let j = 0; j < q; j++) D[p + i][p + j] = N[i][j];
    for (let i = 0; i < p; i++) for (let j = 0; j < q; j++) { S[i][p + j] = C[i][j]; S[p + j][i] = C[i][j]; }
    return { P, D, S, p, q, n, F: { P: toF(P), D: toF(D), S: toF(S) } };
  }
  function wordTraceExact(word, T) { if (!word.length) return new Q(BigInt(T.n)); let M = T[word[0]]; for (let i = 1; i < word.length; i++) M = qmul(M, T[word[i]]); return qtr(M); }
  function wordTraceFloat(word, T) { if (!word.length) return T.n; let M = T.F[word[0]]; for (let i = 1; i < word.length; i++) M = fmul(M, T.F[word[i]]); return ftr(M); }
  // shortest separating word: float prefix-tree search, exact confirmation of the candidate
  function shortestSeparating(TA, TB, maxLen) {
    maxLen = maxLen || 8; let level = [{ w: "", A: null, B: null }];
    const scale = Math.max(1, ...["D", "S"].map((c) => Math.max(...TA.F[c].map((r) => Math.max(...Array.from(r).map(Math.abs))))));
    for (let L = 1; L <= maxLen; L++) {
      const next = [];
      for (const node of level) for (const c of "PDS") {
        const A = node.A ? fmul(node.A, TA.F[c]) : TA.F[c], B = node.B ? fmul(node.B, TB.F[c]) : TB.F[c], w = node.w + c;
        const da = ftr(A), db = ftr(B);
        if (Math.abs(da - db) > 1e-11 * Math.pow(scale, L) * TA.n) {
          const ea = wordTraceExact(w, TA), eb = wordTraceExact(w, TB);
          if (!ea.eq(eb)) return { word: w, traceA: ea.toString(), traceB: eb.toString(), gap: ea.sub(eb).toString(), gapNum: ea.sub(eb).toNumber(), searched: L };
        }
        next.push({ w, A, B });
      }
      level = next;
    }
    return { word: null, searched: maxLen };
  }
  // complete decision (Imported Theorem 18.2): close the paired word algebra, compare traces on a basis
  function pairedClosure(TA, TB) {
    const n = TA.n, dimMax = 2 * n * n, basis = [], words = [], vecs = [];
    const flat = (X, Y) => { const v = new Float64Array(2 * n * n); let k = 0; for (const M of [X, Y]) for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) v[k++] = M[i][j]; return v; };
    const I = Array.from({ length: n }, (_, i) => { const r = new Float64Array(n); r[i] = 1; return r; });
    const queue = [{ w: "", X: I, Y: I }];
    let scale = 1; for (const c of "DS") for (const r of TA.F[c]) for (const x of r) scale = Math.max(scale, Math.abs(x));
    while (queue.length && basis.length < dimMax) {
      const { w, X, Y } = queue.shift(); const v = flat(X, Y), r = Float64Array.from(v);
      const nv = Math.hypot(...v); if (nv === 0) continue;
      for (const b of vecs) { let d = 0; for (let k = 0; k < r.length; k++) d += r[k] * b[k]; for (let k = 0; k < r.length; k++) r[k] -= d * b[k]; }
      const nr = Math.hypot(...r); if (nr < 1e-9 * nv) continue;
      for (let k = 0; k < r.length; k++) r[k] /= nr; vecs.push(r); basis.push({ w, X, Y }); words.push(w);
      for (const c of "PDS") { const g = TA.F[c], h = TB.F[c]; queue.push({ w: w + c, X: fmul(X, g), Y: fmul(Y, h) }); }
    }
    let violation = null;
    for (const b of basis) { const a = ftr(b.X), c = ftr(b.Y); if (Math.abs(a - c) > 1e-9 * Math.max(1, Math.abs(a), Math.abs(c)) * Math.pow(scale, Math.max(1, b.w.length))) { violation = { word: b.w, a, b: c }; break; } }
    return { dim: basis.length, dimMax, equivalent: violation === null, violation, maxWordLength: Math.max(...words.map((w) => w.length)) };
  }

  // ============================================================ cycle signs: H1(G; F2) of the support graph (Prop 18.3)
  function cycleSigns(C, tol) { // C in an eigenbasis (simple spectra); Q matrix, or float matrix with tolerance
    const p = C.length, q = C[0].length, V = p + q, adj = Array.from({ length: V }, () => []), edges = [];
    const isQ = C[0][0] instanceof Q, sc = isQ ? 1 : Math.max(1e-300, ...C.map((r) => Math.max(...Array.from(r).map(Math.abs))));
    const nz = (x) => (isQ ? !x.isZero() : Math.abs(x) > (tol || 1e-9) * sc), sg = (x) => (isQ ? x.sign() : Math.sign(x));
    for (let i = 0; i < p; i++) for (let j = 0; j < q; j++) if (nz(C[i][j])) { edges.push([i, p + j, sg(C[i][j])]); adj[i].push(p + j); adj[p + j].push(i); }
    const par = new Array(V).fill(-1), seen = new Array(V).fill(false), comp = new Array(V).fill(-1); let c = 0; const tree = new Set();
    for (let s = 0; s < V; s++) { if (seen[s]) continue; const st = [s]; seen[s] = true; comp[s] = c;
      while (st.length) { const u = st.shift(); for (const w of adj[u]) if (!seen[w]) { seen[w] = true; par[w] = u; comp[w] = c; st.push(w); tree.add(`${Math.min(u, w)}-${Math.max(u, w)}`); } } c++; }
    const sgn = (a, b) => { const i = Math.min(a, b), j = Math.max(a, b); return sg(C[i][j - p]); };
    const pathToRoot = (u) => { const out = [u]; while (par[u] >= 0) { u = par[u]; out.push(u); } return out; };
    const cycles = [];
    for (const [a, b, s] of edges) {
      if (tree.has(`${a}-${b}`)) continue;
      const pa = pathToRoot(a), pb = pathToRoot(b), setB = new Set(pb); let lca = pa.find((x) => setB.has(x));
      const left = pa.slice(0, pa.indexOf(lca) + 1), right = pb.slice(0, pb.indexOf(lca)).reverse();
      const loop = left.concat(right); let prod = s;
      for (let k = 0; k + 1 < loop.length; k++) prod *= sgn(loop[k], loop[k + 1]);
      cycles.push({ chord: [a, b], loop: loop.concat([a]), sign: prod });
    }
    return { E: edges.length, V, components: c, bits: edges.length - V + c, rooms: 2 ** (edges.length - V + c), cycles, signature: cycles.map((x) => (x.sign > 0 ? 0 : 1)).join("") || "(none)" };
  }
  const flipRow = (C, i) => C.map((r, k) => (k === i ? r.map((x) => x.neg()) : r.slice()));
  const flipCol = (C, j) => C.map((r) => r.map((x, k) => (k === j ? x.neg() : x)));
  // a rational orthogonal matrix from a rational skew matrix (Cayley transform): exact gauge element of O(n)
  function cayley(K) { const n = K.length, I = qeye(n), A = I.map((r, i) => r.map((x, j) => x.sub(K[i][j]))), B = I.map((r, i) => r.map((x, j) => x.add(K[i][j]))); return qmul(A, qinv(B)); }
  function randomSkew(n, r) { const K = qzeros(n); for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) { const v = new Q(BigInt(Math.floor(r() * 7) - 3), BigInt(1 + Math.floor(r() * 4))); K[i][j] = v; K[j][i] = v.neg(); } return K; }
  function scramble(R, N, C, seed) { const r = root.RGCalc.mulberry32(seed || 1), U = cayley(randomSkew(R.length, r)), V = cayley(randomSkew(N.length, r));
    return { R: qmul(qmul(U, R), qT(U)), N: qmul(qmul(V, N), qT(V)), C: qmul(qmul(U, C), qT(V)), U, V }; }
  // descriptors ("doors"): what a shorter protocol reports
  // the coupling read in eigenbases of R and N (ordered by eigenvalue); entries are defined up to row/column signs
  function eigenCoupling(R, N, C) {
    const eR = symEig(toF(R)), eN = symEig(toF(N)), oR = eR.values.map((v, i) => [v, i]).sort((a, b) => a[0] - b[0]).map((x) => x[1]), oN = eN.values.map((v, i) => [v, i]).sort((a, b) => a[0] - b[0]).map((x) => x[1]);
    const UR = toF(R).map((_, i) => oR.map((k) => eR.vectors[i][k])), UN = toF(N).map((_, i) => oN.map((k) => eN.vectors[i][k]));
    const Cf = toF(C), UtC = fmul(ftrans(UR), Cf), Ce = fmul(UtC, UN).map((r) => Array.from(r));
    const gapR = Math.min(...eR.values.slice().sort((a, b) => a - b).slice(1).map((v, i, a) => v - eR.values.slice().sort((x, y) => x - y)[i])), gapN = Math.min(...eN.values.slice().sort((a, b) => a - b).slice(1).map((v, i) => v - eN.values.slice().sort((x, y) => x - y)[i]));
    return { C: Ce, simple: !(gapR < 1e-9) && !(gapN < 1e-9) };
  }
  function descriptors(R, N, C) {
    const Rf = toF(R), Nf = toF(N), Cf = toF(C), p = R.length, q = N.length, ec = eigenCoupling(R, N, C);
    const specR = symEig(Rf).values.sort((a, b) => a - b), specN = symEig(Nf).values.sort((a, b) => a - b);
    const mags = ec.C.map((r) => r.map(Math.abs));
    const mixed = []; let Ra = Rf.map((r, i) => r.map((_, j) => (i === j ? 1 : 0)));
    for (let a = 0; a <= 2; a++) { let Nb = Nf.map((r, i) => r.map((_, j) => (i === j ? 1 : 0)));
      for (let b = 0; b <= 2; b++) { mixed.push(ftr(fmul(fmul(fmul(Ra, Cf), Nb), ftrans(Cf)))); Nb = fmul(Nb, Nf); } Ra = fmul(Ra, Rf); }
    const sv = singularValues(Cf);
    let cc = null;
    if (specR[0] > 0 && specN[0] > 0) { const eR = symEig(Rf), eN = symEig(Nf);
      const isq = (e, n) => { const M = Array.from({ length: n }, () => new Float64Array(n)); for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) { let s = 0; for (let k = 0; k < n; k++) s += e.vectors[i][k] * e.vectors[j][k] / Math.sqrt(e.values[k]); M[i][j] = s; } return M; };
      cc = singularValues(fmul(fmul(isq(eR, p), Cf), isq(eN, q))); }
    return { spectraR: specR, spectraN: specN, magnitudes: mags, mixedTraces: mixed, couplingSV: sv, canonicalCorrelations: cc, eigenCoupling: ec.C, simpleSpectra: ec.simple };
  }
  const near = (a, b, tol) => { if (a === null || b === null) return a === b; const fa = [].concat(...[a].flat(2)), fb = [].concat(...[b].flat(2)); if (fa.length !== fb.length) return false;
    return fa.every((x, i) => Math.abs(x - fb[i]) <= (tol || 1e-10) * Math.max(1, Math.abs(x), Math.abs(fb[i]))); };
  function compareRoom(sysA, sysB) {
    const TA = tuple(sysA.R, sysA.N, sysA.C), TB = tuple(sysB.R, sysB.N, sysB.C), dA = descriptors(sysA.R, sysA.N, sysA.C), dB = descriptors(sysB.R, sysB.N, sysB.C);
    const doors = {
      spectra: near([dA.spectraR, dA.spectraN], [dB.spectraR, dB.spectraN]),
      magnitudes: near(dA.magnitudes, dB.magnitudes),
      mixedTraces: near(dA.mixedTraces, dB.mixedTraces),
      couplingSV: near(dA.couplingSV, dB.couplingSV),
      canonicalCorrelations: near(dA.canonicalCorrelations, dB.canonicalCorrelations),
    };
    let cyc = null;
    if (dA.simpleSpectra && dB.simpleSpectra) { const ca = cycleSigns(dA.eigenCoupling), cb = cycleSigns(dB.eigenCoupling); cyc = { A: ca, B: cb, same: ca.signature === cb.signature && near(dA.magnitudes, dB.magnitudes) }; }
    const sep = shortestSeparating(TA, TB, 8), closure = pairedClosure(TA, TB);
    return { doors, cycles: cyc, separating: sep, closure, descA: dA, descB: dB };
  }
  // the "same datum?" request through a chosen descriptor (Corollary 18.5), dispatched to one status
  function descriptorRequest(cmp, chosen) {
    const keys = chosen.filter((k) => k !== "wordTraces" && k !== "cycleSigns");
    let differs = keys.some((k) => cmp.doors[k] === false);
    if (chosen.includes("cycleSigns") && cmp.cycles && !cmp.cycles.same) differs = true;
    if (chosen.includes("wordTraces")) return cmp.closure.equivalent ? { status: "LOCKED", answer: "same orbit", why: "word traces are complete (Imported Theorem 18.2): the paired word algebra closed and every trace agreed" }
      : { status: "LOCKED", answer: "different orbits", why: `word traces are complete; the word ${cmp.separating.word || cmp.closure.violation.word} separates` };
    if (differs) return { status: "LOCKED", answer: "different orbits", why: "the chosen descriptor already differs, and any invariant that differs separates orbits" };
    const room = !cmp.closure.equivalent;
    return { status: "CORRESPONDENCE", answer: room ? "{A's orbit, B's orbit}: the descriptor's fibre holds both" : "the descriptor cannot exclude other orbits in its fibre",
      why: room ? "the chosen descriptor agrees, yet the complete classifier separates the systems: the fibre of the descriptor contains several orbits, so RG returns the set of compatible values instead of choosing (Corollary 18.5, Theorem 16.6)" : "agreement of an incomplete descriptor does not lock equality; add word traces to decide" };
  }

  // ============================================================ rooms over loops: Möbius line (Cor 17.8(3)) and wall monodromy (Prop 17.10)
  function mobius(k, steps) { steps = steps || 200; const out = []; for (let s = 0; s <= steps; s++) { const t = 2 * Math.PI * s / steps; out.push({ t, v: [Math.cos(k * t / 2), Math.sin(k * t / 2)] }); }
    const end = out[out.length - 1].v, start = out[0].v; return { path: out, returnSign: Math.sign(end[0] * start[0] + end[1] * start[1]), w1: ((k % 2) + 2) % 2 }; }
  // canonical-correlation collision: C(a,b) = [[s+a, b],[b, s-a]] (s > radius keeps both correlations positive). Wall at a=b=0.
  function wallLoop(cx, cy, rad, s, steps) {
    steps = steps || 360; const frames = []; let v1 = null, v2 = null, minGap = Infinity;
    for (let k = 0; k <= steps; k++) {
      const th = 2 * Math.PI * k / steps, a = cx + rad * Math.cos(th), b = cy + rad * Math.sin(th), e = symEig([[s + a, b], [b, s - a]]);
      const idx = e.values[0] >= e.values[1] ? [0, 1] : [1, 0]; let u1 = [e.vectors[0][idx[0]], e.vectors[1][idx[0]]], u2 = [e.vectors[0][idx[1]], e.vectors[1][idx[1]]];
      if (v1) { if (u1[0] * v1[0] + u1[1] * v1[1] < 0) u1 = u1.map((x) => -x); if (u2[0] * v2[0] + u2[1] * v2[1] < 0) u2 = u2.map((x) => -x); }
      v1 = u1; v2 = u2; minGap = Math.min(minGap, Math.abs(e.values[0] - e.values[1]));
      frames.push({ a, b, sigma: [Math.max(...e.values), Math.min(...e.values)], u1, u2 });
    }
    const f0 = frames[0], fN = frames[frames.length - 1];
    const ret1 = Math.sign(f0.u1[0] * fN.u1[0] + f0.u1[1] * fN.u1[1]), ret2 = Math.sign(f0.u2[0] * fN.u2[0] + f0.u2[1] * fN.u2[1]);
    return { frames, w1: [ret1 < 0 ? 1 : 0, ret2 < 0 ? 1 : 0], sumW1: (ret1 * ret2) < 0 ? 1 : 0, links: Math.hypot(cx, cy) < rad, minGap };
  }

  // ============================================================ complement relativity (Prop 17.4)
  function complementAction(R, N, C, K) { // float, p x p, q x q, p x q, K p x q
    const p = R.length, q = N.length, n = p + q, S = Array.from({ length: n }, () => new Array(n).fill(0));
    for (let i = 0; i < p; i++) for (let j = 0; j < p; j++) S[i][j] = R[i][j];
    for (let i = 0; i < q; i++) for (let j = 0; j < q; j++) S[p + i][p + j] = N[i][j];
    for (let i = 0; i < p; i++) for (let j = 0; j < q; j++) { S[i][p + j] = C[i][j]; S[p + j][i] = C[i][j]; }
    const T = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => (i === j ? 1 : (i < p && j >= p ? K[i][j - p] : 0))));
    const S2 = fmul(fmul(T, S), ftrans(T));
    const fisher = (M) => { const Mi = root.RGLabs.pinvSym(M.map((r) => Array.from(r)), 1e-14); return Mi.slice(0, p).map((r) => r.slice(0, p)); };
    const blk = (M) => ({ R: M.slice(0, p).map((r) => Array.from(r).slice(0, p)), C: M.slice(0, p).map((r) => Array.from(r).slice(p)), N: M.slice(p).map((r) => Array.from(r).slice(p)) });
    return { before: { ...blk(S), G: fisher(S) }, after: { ...blk(S2), G: fisher(S2) } };
  }

  // ============================================================ coupling stabilizer and global classes (Thm 17.5, No-Go 17.6, Cor 17.8)
  function stabilizer(p, q, corr, tol) {
    tol = tol || 1e-9; const vals = corr.filter((x) => x > tol).sort((a, b) => b - a);
    if (vals.length > Math.min(p, q)) throw new Error(`at most min(p, q) = ${Math.min(p, q)} nonzero canonical correlations`);
    if (vals.some((x) => x >= 1)) throw new Error("canonical correlations lie in (0, 1)");
    const mults = []; for (const v of vals) { if (mults.length && Math.abs(mults[mults.length - 1].sigma - v) <= tol) mults[mults.length - 1].m++; else mults.push({ sigma: v, m: 1 }); }
    const r = vals.length, factors = mults.map((x) => ({ group: `O(${x.m})`, m: x.m, label: `σ = ${x.sigma}` })).concat([{ group: `O(${p - r})`, m: p - r, label: "resolved kernel K_R" }, { group: `O(${q - r})`, m: q - r, label: "null kernel K_N" }]);
    const dim = factors.reduce((s, f) => s + f.m * (f.m - 1) / 2, 0), kappa = factors.filter((f) => f.m > 0).length;
    return { r, factors, dim, kappa, components: 2 ** kappa, classesOverCircle: 2 ** kappa };
  }

  // ============================================================ observers (No-Go 18.6) and the Schwarzschild control
  function planeWave(A, boost) { const f = Math.exp(2 * boost) / 2; return { tidal: [[-A * f, 0], [0, A * f]], kretschmann: 0, ricci: 0, uu: Math.exp(boost) / Math.SQRT2, magnitude: Math.abs(A) * f }; }
  function schwarzschild(M, r) { const e = M / r ** 3, E = [-2 * e, e, e], tr2 = E.reduce((s, x) => s + x * x, 0), tr3 = E.reduce((s, x) => s + x ** 3, 0);
    return { tidal: E, trE2: tr2, trE3: tr3, recoveredM: tr2 === 0 ? 0 : -(r ** 3) * tr3 / tr2 }; }

  // ============================================================ closure dispatcher (Definition 16.1, Theorems 16.2-16.6)
  const GATES = [
    { key: "domain", label: "domain", options: [["admitted", "pass"], ["not admitted", "OUTSIDE DOMAIN"]] },
    { key: "consistency", label: "consistency", options: [["consistent", "pass"], ["contradicted", "INCONSISTENT"]] },
    { key: "task", label: "task", options: [["descends", "pass"], ["residual is a set", "CORRESPONDENCE"]] },
    { key: "vacuity", label: "vacuity", options: [["a nonzero task survives", "pass"], ["no task survives", "VACUOUS"]] },
    { key: "rank", label: "rank", options: [["certified", "pass"], ["undecided, escalation left", "ESCALATE"], ["undecided, budget spent", "STRUCTURAL WALL"]] },
    { key: "candidate", label: "candidate", options: [["unique", "pass"], ["several indistinguishable", "CORRESPONDENCE"]] },
    { key: "scale", label: "scale", options: [["anchored", "pass"], ["anchor available", "ESCALATE"], ["no anchor (dilation fibre)", "CORRESPONDENCE"]] },
  ];
  function dispatch(choice) { // choice: {gateKey: optionIndex}
    for (const g of GATES) { const o = g.options[choice[g.key] || 0]; if (!o) throw new Error("bad option for " + g.key); if (o[1] !== "pass") return { status: o[1], gate: g.key, outcome: o[0] }; }
    return { status: "LOCKED", gate: null, outcome: "every gate certified" };
  }
  function dispatchAll() { const out = []; const rec = (i, ch) => { if (i === GATES.length) { out.push({ choice: { ...ch }, ...dispatch(ch) }); return; } for (let k = 0; k < GATES[i].options.length; k++) { ch[GATES[i].key] = k; rec(i + 1, ch); } }; rec(0, {}); return out; }
  // composite soundness (Theorem 16.3): gates with false-pass probabilities alpha_g
  function soundnessSim(alphas, pTrue, trials, seed) {
    const r = root.RGCalc.mulberry32(seed || 1); let falseLock = 0, lockable = 0, locked = 0;
    for (let t = 0; t < trials; t++) { let allTrue = true, allPass = true;
      for (const a of alphas) { const ok = r() < pTrue; if (!ok) allTrue = false; const pass = ok ? true : r() < a; if (!pass) allPass = false; }
      if (allTrue) lockable++; if (allPass) { locked++; if (!allTrue) falseLock++; } }
    return { falseLockRate: falseLock / trials, bound: alphas.reduce((s, a) => s + a, 0), lockable, locked, trials };
  }

  const api = { eigenCoupling, Q, qmul, qtr, qinv, qeye, qT, cayley, tuple, wordTraceExact, wordTraceFloat, shortestSeparating, pairedClosure, cycleSigns, flipRow, flipCol, scramble,
    descriptors, compareRoom, descriptorRequest, mobius, wallLoop, complementAction, stabilizer, planeWave, schwarzschild, GATES, dispatch, dispatchAll, soundnessSim };
  root.RGLabs3 = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
