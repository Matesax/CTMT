/* RG-calc evaluator.
 * Typing discipline (from the Theorem Ladder and Uncertainty Geometry):
 *  - linear propagation is the LAN limit; it is only trusted where a Monte Carlo check agrees;
 *  - Monte Carlo is the integration engine, not the lock;
 *  - an uncertainty statement is FORCED iff its spread over the declared admissible family is at
 *    most tol x its own scale and the sample size resolves that tolerance; otherwise CONDITIONAL;
 *  - a single-member family cannot certify anything (canary of UG08).
 */
(function (root) {
  "use strict";

  // ---------------------------------------------------------------- units
  const DIM_NAMES = ["m", "kg", "s", "A", "K", "mol", "cd"];
  const Z = () => [0, 0, 0, 0, 0, 0, 0];
  const D = (o) => { const d = Z(); for (const k in o) d[DIM_NAMES.indexOf(k)] = o[k]; return d; };
  const UNITS = {
    "1": [1, Z()], m: [1, D({ m: 1 })], kg: [1, D({ kg: 1 })], g: [1e-3, D({ kg: 1 })], s: [1, D({ s: 1 })],
    A: [1, D({ A: 1 })], K: [1, D({ K: 1 })], mol: [1, D({ mol: 1 })], cd: [1, D({ cd: 1 })],
    rad: [1, Z()], sr: [1, Z()], deg: [Math.PI / 180, Z()], "°": [Math.PI / 180, Z()],
    N: [1, D({ kg: 1, m: 1, s: -2 })], J: [1, D({ kg: 1, m: 2, s: -2 })], W: [1, D({ kg: 1, m: 2, s: -3 })],
    Pa: [1, D({ kg: 1, m: -1, s: -2 })], Hz: [1, D({ s: -1 })], C: [1, D({ A: 1, s: 1 })],
    V: [1, D({ kg: 1, m: 2, s: -3, A: -1 })], eV: [1.602176634e-19, D({ kg: 1, m: 2, s: -2 })],
    L: [1e-3, D({ m: 3 })], min: [60, D({ s: 1 })], h: [3600, D({ s: 1 })],
    au: [1.495978707e11, D({ m: 1 })], ly: [9.4607304725808e15, D({ m: 1 })],
  };
  const PREFIXABLE = new Set(["m", "s", "g", "N", "J", "W", "Pa", "Hz", "eV", "V", "A", "C", "L", "K", "mol"]);
  const PREFIX = { T: 1e12, G: 1e9, M: 1e6, k: 1e3, h: 1e2, c: 1e-2, m: 1e-3, u: 1e-6, "µ": 1e-6, n: 1e-9, p: 1e-12, f: 1e-15 };

  function unitLookup(sym) {
    if (UNITS[sym]) return UNITS[sym];
    const p = sym[0], rest = sym.slice(1);
    if (PREFIX[p] && PREFIXABLE.has(rest)) return [PREFIX[p] * UNITS[rest][0], UNITS[rest][1]];
    throw new RGError(`unknown unit "${sym}"`);
  }
  function unitOf(spec) { // [[sym, power], ...] -> [scale, dims]
    let scale = 1; const dims = Z();
    for (const [sym, p] of spec) {
      const [s, d] = unitLookup(sym);
      scale *= Math.pow(s, p);
      for (let i = 0; i < 7; i++) dims[i] += d[i] * p;
    }
    return [scale, dims];
  }
  const dimsEq = (a, b) => a.every((x, i) => Math.abs(x - b[i]) < 1e-9);
  const dimless = (d) => d.every((x) => Math.abs(x) < 1e-9);
  function fmtDims(d) {
    const parts = [];
    for (let i = 0; i < 7; i++) {
      const p = +d[i].toFixed(6);
      if (p === 0) continue;
      parts.push(p === 1 ? DIM_NAMES[i] : `${DIM_NAMES[i]}^${p}`);
    }
    return parts.join(" ");
  }

  class RGError extends Error { constructor(msg, line) { super(msg); this.line = line; } }

  // ---------------------------------------------------------------- RNG (seeded, reproducible)
  function mulberry32(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function stdDraw(law, rnd) { // zero mean, unit variance
    if (law === "twopoint") return rnd() < 0.5 ? -1 : 1;
    if (law === "uniform") return (rnd() - 0.5) * Math.sqrt(12);
    if (law === "laplace") {
      let u = rnd() - 0.5; if (u === -0.5) u = -0.4999999999;
      return -Math.sign(u) * Math.log(1 - 2 * Math.abs(u)) / Math.SQRT2;
    }
    let u = 0, v = 0; while (u === 0) u = rnd(); v = rnd();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }
  function cholesky(A) {
    const n = A.length, L = A.map(() => new Array(n).fill(0));
    for (let i = 0; i < n; i++) for (let j = 0; j <= i; j++) {
      let s = A[i][j];
      for (let k = 0; k < j; k++) s -= L[i][k] * L[j][k];
      if (i === j) { if (s <= 1e-12) return null; L[i][i] = Math.sqrt(s); }
      else L[i][j] = s / L[j][j];
    }
    return L;
  }

  // ---------------------------------------------------------------- functions
  // each: [value(x...), gradient factors(x...) -> array of partials, dims rule]
  const FN = {
    sin: [Math.sin, (x) => [Math.cos(x)], "dimless"],
    cos: [Math.cos, (x) => [-Math.sin(x)], "dimless"],
    tan: [Math.tan, (x) => [1 / Math.cos(x) ** 2], "dimless"],
    asin: [Math.asin, (x) => [1 / Math.sqrt(1 - x * x)], "dimless"],
    acos: [Math.acos, (x) => [-1 / Math.sqrt(1 - x * x)], "dimless"],
    atan: [Math.atan, (x) => [1 / (1 + x * x)], "dimless"],
    sinh: [Math.sinh, (x) => [Math.cosh(x)], "dimless"],
    cosh: [Math.cosh, (x) => [Math.sinh(x)], "dimless"],
    tanh: [Math.tanh, (x) => [1 - Math.tanh(x) ** 2], "dimless"],
    exp: [Math.exp, (x) => [Math.exp(x)], "dimless"],
    log: [Math.log, (x) => [1 / x], "dimless"],
    log10: [Math.log10, (x) => [1 / (x * Math.LN10)], "dimless"],
    sqrt: [Math.sqrt, (x) => [0.5 / Math.sqrt(x)], "half"],
    abs: [Math.abs, (x) => [Math.sign(x)], "same"],
    atan2: [Math.atan2, (y, x) => [x / (x * x + y * y), -y / (x * x + y * y)], "same2dimless"],
    hypot: [Math.hypot, (a, b) => [a / Math.hypot(a, b), b / Math.hypot(a, b)], "same2"],
    min: [Math.min, (a, b) => (a < b ? [1, 0] : [0, 1]), "same2"],
    max: [Math.max, (a, b) => (a > b ? [1, 0] : [0, 1]), "same2"],
  };
  const KINKS = { abs: (x) => x === 0, min: (a, b) => a === b, max: (a, b) => a === b };

  // ---------------------------------------------------------------- program
  function run(src, opts) {
    opts = opts || {};
    const parser = opts.parser || root.RGParser;
    let ast;
    try { ast = parser.parse(src); }
    catch (e) {
      const line = e.location ? e.location.start.line : null;
      return { out: [{ kind: "error", line, msg: "syntax: " + e.message }], ok: false };
    }
    const st = {
      inputs: [], idx: {}, vars: {}, families: ["normal"], familyDeclared: false,
      corr: {}, samples: 20000, seed: 20261011, tol: 0.1, out: [], ok: true, declaredAfterOutput: false,
      outputSeen: false,
    };
    for (const s of ast) {
      try { exec(s, st); }
      catch (e) {
        if (!(e instanceof RGError)) throw e;
        st.out.push({ kind: "error", line: e.line || s.line, msg: e.message }); st.ok = false;
        break;
      }
    }
    return { out: st.out, ok: st.ok, state: st };
  }

  function define(st, name, rec, line) {
    if (st.vars[name]) throw new RGError(`"${name}" is already defined on line ${st.vars[name].line}; RG-calc is single-assignment`, line);
    rec.line = line; st.vars[name] = rec;
  }

  function exec(s, st) {
    const declaring = ["input", "family", "correlate", "option"].includes(s.type);
    if (declaring && st.outputSeen) {
      st.out.push({ kind: "warn", line: s.line, msg: "declaration after an output was printed: H-adm requires declarations before outputs are seen; later certificates are reported as CONDITIONAL on this ordering" });
      st.declaredAfterOutput = true;
    }
    switch (s.type) {
      case "input": {
        let scale = 1, dims = Z();
        if (s.unit) [scale, dims] = unitOf(s.unit);
        if (s.sigma < 0) throw new RGError("uncertainty must be non-negative", s.line);
        const i = st.inputs.length;
        st.inputs.push({ name: s.name, mean: s.mean * scale, sigma: s.sigma * scale, dims, law: s.law });
        define(st, s.name, { kind: "input", i, dims }, s.line);
        st.idx[s.name] = i;
        return;
      }
      case "const": {
        const v = lin(s.expr, st);
        if (v.g.some((x) => x !== 0)) throw new RGError(`const "${s.name}" depends on an uncertain input; use an assignment`, s.line);
        let scale = 1, dims = v.d;
        if (s.unit) { const [sc, dd] = unitOf(s.unit); if (!dimless(v.d)) throw new RGError("const already carries units; do not attach a second unit", s.line); scale = sc; dims = dd; }
        define(st, s.name, { kind: "const", value: v.v * scale, dims }, s.line);
        return;
      }
      case "assign": {
        lin(s.expr, st); // type-check and dimension-check now
        define(st, s.name, { kind: "derived", ast: s.expr }, s.line);
        return;
      }
      case "family": {
        const uniq = [...new Set(s.laws)];
        st.families = uniq; st.familyDeclared = true; return;
      }
      case "correlate": {
        if (!(s.a in st.idx) || !(s.b in st.idx)) throw new RGError("correlate needs two declared inputs", s.line);
        if (s.a === s.b) throw new RGError("an input is perfectly correlated with itself", s.line);
        if (Math.abs(s.rho) > 1) throw new RGError("|correlation| must be ≤ 1", s.line);
        st.corr[[s.a, s.b].sort().join("|")] = s.rho; return;
      }
      case "option": {
        if (s.key === "samples") { if (s.value < 100 || s.value > 400000) throw new RGError("samples must be in [100, 400000]", s.line); st.samples = Math.round(s.value); }
        if (s.key === "seed") st.seed = Math.round(s.value);
        if (s.key === "tol") { if (!(s.value > 0 && s.value < 1)) throw new RGError("tol must be in (0,1)", s.line); st.tol = s.value; }
        return;
      }
      case "print": {
        const parts = s.args.map((a) => {
          if (a.str !== undefined) return { str: a.str };
          const v = lin(a.expr, st);
          return { value: v.v, sigma: linSigma(v, st), dims: fmtDims(v.d), flags: v.flags };
        });
        st.out.push({ kind: "print", line: s.line, parts });
        st.outputSeen = true;
        return;
      }
      case "certify": {
        st.out.push(certify(s, st));
        st.outputSeen = true;
        return;
      }
    }
  }

  // ------------------------------------------- linear (forward-mode) evaluation at the declared point
  function lin(e, st) {
    const n = st.inputs.length;
    const zero = () => new Float64Array(n);
    const mk = (v, g, d, flags) => ({ v, g, d, flags: flags || [] });
    const merge = (...xs) => [...new Set([].concat(...xs.map((x) => x.flags)))];
    const L = (e) => {
      switch (e.type) {
        case "num": {
          if (e.unit) { const [sc, d] = unitOf(e.unit); return mk(e.value * sc, zero(), d); }
          return mk(e.value, zero(), Z());
        }
        case "var": {
          const r = st.vars[e.name];
          if (!r) {
            if (e.name === "pi" || e.name === "π") return mk(Math.PI, zero(), Z());
            if (e.name === "e") return mk(Math.E, zero(), Z());
            throw new RGError(`undefined name "${e.name}"`);
          }
          if (r.kind === "input") { const g = zero(); g[r.i] = 1; return mk(st.inputs[r.i].mean, g, r.dims.slice()); }
          if (r.kind === "const") return mk(r.value, zero(), r.dims.slice());
          return L(r.ast);
        }
        case "neg": { const a = L(e.a); return mk(-a.v, a.g.map((x) => -x), a.d, a.flags); }
        case "bin": {
          const a = L(e.l), b = L(e.r), g = zero();
          switch (e.op) {
            case "+": case "-": {
              if (!dimsEq(a.d, b.d)) throw new RGError(`dimension mismatch: cannot ${e.op === "+" ? "add" : "subtract"} [${fmtDims(a.d) || "1"}] and [${fmtDims(b.d) || "1"}]`);
              const s = e.op === "+" ? 1 : -1;
              for (let i = 0; i < n; i++) g[i] = a.g[i] + s * b.g[i];
              return mk(a.v + s * b.v, g, a.d, merge(a, b));
            }
            case "*": for (let i = 0; i < n; i++) g[i] = a.g[i] * b.v + b.g[i] * a.v;
              return mk(a.v * b.v, g, a.d.map((x, i) => x + b.d[i]), merge(a, b));
            case "/": {
              const fl = merge(a, b); if (b.v === 0) fl.push("division by zero at the declared point");
              for (let i = 0; i < n; i++) g[i] = a.g[i] / b.v - b.g[i] * a.v / (b.v * b.v);
              return mk(a.v / b.v, g, a.d.map((x, i) => x - b.d[i]), fl);
            }
            case "^": {
              if (!dimless(b.d)) throw new RGError("exponent must be dimensionless");
              const bConst = b.g.every((x) => x === 0);
              if (!dimless(a.d) && !bConst) throw new RGError("a dimensional base needs an exact exponent (an uncertain exponent would make the unit uncertain)");
              const v = Math.pow(a.v, b.v), fl = merge(a, b);
              if (bConst) {
                const k = b.v * Math.pow(a.v, b.v - 1);
                if (!isFinite(k) && a.g.some((x) => x !== 0)) fl.push("infinite derivative (power wall)");
                for (let i = 0; i < n; i++) g[i] = a.g[i] === 0 ? 0 : k * a.g[i];
              } else {
                if (a.v <= 0) fl.push("uncertain exponent with non-positive base (domain wall)");
                for (let i = 0; i < n; i++) g[i] = v * (b.g[i] * Math.log(a.v) + (a.g[i] === 0 ? 0 : b.v * a.g[i] / a.v));
              }
              return mk(v, g, a.d.map((x) => x * b.v), fl);
            }
          }
          break;
        }
        case "call": {
          const f = FN[e.name];
          if (!f) throw new RGError(`unknown function "${e.name}"`);
          const args = e.args.map(L);
          if (args.length !== f[0].length) throw new RGError(`${e.name} takes ${f[0].length} argument(s)`);
          let d;
          if (f[2] === "dimless") { if (!dimless(args[0].d)) throw new RGError(`${e.name}() needs a dimensionless argument, got [${fmtDims(args[0].d)}]`); d = Z(); }
          else if (f[2] === "half") d = args[0].d.map((x) => x / 2);
          else if (f[2] === "same") d = args[0].d.slice();
          else { if (!dimsEq(args[0].d, args[1].d)) throw new RGError(`${e.name}() needs arguments of equal dimension`); d = f[2] === "same2dimless" ? Z() : args[0].d.slice(); }
          const xs = args.map((a) => a.v), v = f[0](...xs), parts = f[1](...xs), g = zero(), fl = merge(...args);
          if (isNaN(v)) fl.push(`${e.name}() undefined at the declared point (domain wall)`);
          if (KINKS[e.name] && KINKS[e.name](...xs)) fl.push(`${e.name}() has a kink at the declared point`);
          for (let i = 0; i < n; i++) { let s = 0; args.forEach((a, k) => { if (a.g[i] !== 0) s += parts[k] * a.g[i]; }); g[i] = s; }
          if (g.some((x) => !isFinite(x))) fl.push(`${e.name}() has an infinite derivative at the declared point`);
          return mk(v, g, d, fl);
        }
      }
      throw new RGError("internal: unknown node " + e.type);
    };
    return L(e);
  }

  function covMatrix(st) {
    const n = st.inputs.length, C = [];
    for (let i = 0; i < n; i++) { C.push([]); for (let j = 0; j < n; j++) {
      const r = i === j ? 1 : (st.corr[[st.inputs[i].name, st.inputs[j].name].sort().join("|")] || 0);
      C[i].push(r * st.inputs[i].sigma * st.inputs[j].sigma);
    } }
    return C;
  }
  function linSigma(v, st) {
    const C = covMatrix(st), n = st.inputs.length; let s = 0;
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) s += v.g[i] * C[i][j] * v.g[j];
    return Math.sqrt(Math.max(s, 0));
  }

  // ------------------------------------------- numeric compilation for sampling
  function compile(e, st) {
    const memo = {};
    const C = (e) => {
      switch (e.type) {
        case "num": { const k = e.unit ? e.value * unitOf(e.unit)[0] : e.value; return () => k; }
        case "var": {
          const r = st.vars[e.name];
          if (!r) { const k = e.name === "e" ? Math.E : Math.PI; return () => k; }
          if (r.kind === "input") { const i = r.i; return (x) => x[i]; }
          if (r.kind === "const") { const k = r.value; return () => k; }
          if (!memo[e.name]) memo[e.name] = C(r.ast);
          return memo[e.name];
        }
        case "neg": { const a = C(e.a); return (x) => -a(x); }
        case "bin": {
          const a = C(e.l), b = C(e.r);
          switch (e.op) {
            case "+": return (x) => a(x) + b(x);
            case "-": return (x) => a(x) - b(x);
            case "*": return (x) => a(x) * b(x);
            case "/": return (x) => a(x) / b(x);
            case "^": return (x) => Math.pow(a(x), b(x));
          }
          break;
        }
        case "call": { const f = FN[e.name][0], as = e.args.map(C);
          return as.length === 1 ? (x) => f(as[0](x)) : (x) => f(as[0](x), as[1](x)); }
      }
    };
    return C(e);
  }

  function quantile(sorted, p) {
    const h = (sorted.length - 1) * p, lo = Math.floor(h), hi = Math.ceil(h);
    return sorted[lo] + (sorted[hi] - sorted[lo]) * (h - lo);
  }

  function sampleFamily(st, f, law, N, seed) {
    const n = st.inputs.length, rnd = mulberry32(seed);
    const R = []; for (let i = 0; i < n; i++) { R.push([]); for (let j = 0; j < n; j++)
      R[i].push(i === j ? 1 : (st.corr[[st.inputs[i].name, st.inputs[j].name].sort().join("|")] || 0)); }
    const Lc = n ? cholesky(R) : [];
    if (n && !Lc) throw new RGError("declared correlation matrix is not positive definite");
    const x = new Float64Array(n), eps = new Float64Array(n), vals = [];
    let nan = 0;
    for (let s = 0; s < N; s++) {
      for (let i = 0; i < n; i++) eps[i] = stdDraw(st.inputs[i].law || law, rnd);
      for (let i = 0; i < n; i++) { let z = 0; for (let k = 0; k <= i; k++) z += Lc[i][k] * eps[k];
        x[i] = st.inputs[i].mean + st.inputs[i].sigma * z; }
      const y = f(x);
      if (isFinite(y)) vals.push(y); else nan++;
    }
    vals.sort((a, b) => a - b);
    const m = vals.reduce((a, b) => a + b, 0) / Math.max(vals.length, 1);
    const sd = Math.sqrt(vals.reduce((a, b) => a + (b - m) ** 2, 0) / Math.max(vals.length - 1, 1));
    const qs = []; if (vals.length) for (let k = 0; k <= 100; k++) qs.push(quantile(vals, 0.005 + 0.99 * k / 100));
    return { law, n: vals.length, nanFrac: nan / N, mean: m, sd, quantiles: qs,
      q025: vals.length ? quantile(vals, 0.025) : NaN, q975: vals.length ? quantile(vals, 0.975) : NaN };
  }

  function certify(s, st) {
    const v = lin(s.expr, st), sigLin = linSigma(v, st), res = {
      kind: "certify", line: s.line, label: s.label, value: v.v, dims: fmtDims(v.d), sigmaLin: sigLin,
      flags: v.flags.slice(), mc: [], statements: [], status: "", reasons: [], tol: st.tol, samples: st.samples, seed: st.seed,
      families: st.families.slice(),
    };
    const reaches = st.inputs.some((inp, i) => inp.sigma > 0 && v.g[i] !== 0);
    const anySigma = st.inputs.some((inp) => inp.sigma > 0);
    const f = compile(s.expr, st);
    if (!anySigma) { res.status = "EXACT"; res.reasons.push("no declared uncertainty exists in this program"); return res; }
    // the sample is drawn even when the gradient vanishes: a vanishing gradient is a wall candidate, not exactness
    res.mc = st.families.map((law, k) => sampleFamily(st, f, law, st.samples, st.seed + 7919 * k));
    const ref = res.mc[0];
    if (!reaches && ref.sd === 0) { res.status = "EXACT"; res.reasons.push("no declared uncertainty reaches this output"); return res; }

    // LAN regularity: linear vs Monte Carlo under the first declared law
    const lanSd = sigLin > 0 ? ref.sd / sigLin : Infinity;
    const meanShift = ref.sd > 0 ? Math.abs(ref.mean - v.v) / ref.sd : 0;
    res.lan = { sdRatio: lanSd, meanShift };
    let regular = lanSd > 0.9 && lanSd < 1.1 && meanShift < 0.1 && ref.nanFrac === 0 && v.flags.length === 0;
    if (ref.nanFrac > 0) res.reasons.push(`${(100 * ref.nanFrac).toFixed(2)}% of samples leave the domain (domain wall inside the declared spread)`);
    if (sigLin < 0.1 * ref.sd) res.reasons.push("the linear σ nearly vanishes while the sampled spread does not: rank wall / fold (UG04): linearization selects nothing");
    else if (!(lanSd > 0.9 && lanSd < 1.1)) res.reasons.push(`linear σ and sampled σ differ by a factor ${lanSd.toFixed(3)}: outside the LAN regime`);
    if (meanShift >= 0.1 && sigLin >= 0.1 * ref.sd) res.reasons.push(`sampled mean is shifted by ${meanShift.toFixed(2)}σ from f(mean): curvature is not negligible`);
    for (const fl of v.flags) res.reasons.push(fl);
    res.regular = regular;

    // statements and the non-circularity certificate
    const N = st.samples, tol = st.tol;
    const needMoments = Math.ceil(18 / (tol * tol)), needQuant = Math.ceil((11.3 / tol) ** 2);
    const scale = ref.sd;
    const stmt = (name, spread, need) => {
      const out = { name, spread: scale > 0 ? spread / scale : 0, need };
      const lost = Math.max(...res.mc.map((m) => m.nanFrac));
      if (lost > 0) { out.verdict = "CONDITIONAL"; out.why = `${(100 * lost).toFixed(2)}% of the declared input mass gives no value (domain wall); a statement about survivors conditions on the domain, which is a declaration`; }
      else if (st.families.length < 2) { out.verdict = "UNCERTIFIED"; out.why = "the admissible family has one member; a certificate computed from one input law cannot detect smuggling (UG08 canary)"; }
      else if (N < need) { out.verdict = "UNRESOLVED"; out.why = `samples=${N} cannot resolve tol=${tol}; need ≥ ${need} (effective-sample-size gate, UG10)`; }
      else if (out.spread <= tol) { out.verdict = st.declaredAfterOutput ? "CONDITIONAL" : "FORCED"; out.why = st.declaredAfterOutput ? "declarations were changed after outputs were seen" : `spread over the declared list {${st.families.join(", ")}} is ${out.spread.toFixed(3)}σ ≤ ${tol}σ. A list is not a class (R31, R36): an unlisted admissible law can still break this`; }
      else { out.verdict = "CONDITIONAL"; out.why = `spread over {${st.families.join(", ")}} is ${out.spread.toFixed(3)}σ > ${tol}σ: the answer depends on the declared law`; }
      return out;
    };
    let sm = 0, sq = 0;
    for (const m of res.mc) {
      sm = Math.max(sm, Math.abs(m.mean - ref.mean), Math.abs(m.sd - ref.sd));
      sq = Math.max(sq, Math.abs(m.q025 - ref.q025), Math.abs(m.q975 - ref.q975));
    }
    res.statements.push(stmt("mean ± σ", sm, needMoments));
    res.statements.push(stmt("95% interval", sq, needQuant));
    res.status = regular ? "REGULAR" : "WALL";
    return res;
  }

  // compile a standalone expression over named scalar variables (used by the metric-field tools)
  function compileExpr(text, names, opts) {
    const parser = (opts && opts.parser) || root.RGParser;
    let ast;
    try { ast = parser.parse("print " + text); } catch (e) { throw new RGError("expression: " + e.message); }
    if (ast.length !== 1 || ast[0].args.length !== 1 || !ast[0].args[0].expr) throw new RGError("expected one expression");
    const st = { inputs: names.map((n) => ({ name: n, mean: 1, sigma: 0, dims: Z() })), vars: {}, corr: {} };
    names.forEach((n, i) => { st.vars[n] = { kind: "input", i, dims: Z() }; });
    lin(ast[0].args[0].expr, st);               // name and dimension check
    const f = compile(ast[0].args[0].expr, st), x = new Float64Array(names.length);
    return (...v) => { for (let i = 0; i < v.length; i++) x[i] = v[i]; return f(x); };
  }

  const api = { run, compileExpr, unitOf, fmtDims, mulberry32, stdDraw, cholesky, RGError, version: "rgcalc-1.0.0" };
  root.RGCalc = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
