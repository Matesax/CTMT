/* RG labs: pure functions, no DOM. The site and the Node cross-check harness run this same file. */
(function (root) {
  "use strict";
  const rng = (seed) => root.RGCalc.mulberry32(seed);
  const gauss = (r) => { let u = 0; while (u === 0) u = r(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * r()); };

  // ============================================================ R36/R38: tent transfer operator
  // densities piecewise constant on 2^L dyadic cells; P f(x) = (f(x/2) + f(1 - x/2)) / 2 is closed on that space
  function tentP(f) {
    const n = f.length, out = new Float64Array(n);
    for (let j = 0; j < n; j++) out[j] = 0.5 * (f[j >> 1] + f[(2 * n - j - 1) >> 1]);
    return out;
  }
  const tv = (f, g) => { let s = 0; for (let j = 0; j < f.length; j++) s += Math.abs(f[j] - g[j]); return 0.5 * s / f.length; };
  const variation = (h) => { let s = 0; for (let j = 1; j < h.length; j++) s += Math.abs(h[j] - h[j - 1]); return s; };
  function normalize(f) { let s = 0; for (const x of f) s += x; s /= f.length; return f.map((x) => x / s); }
  function declaration(name, L, param, seed) {
    const n = 1 << L, f = new Float64Array(n);
    for (let j = 0; j < n; j++) {
      const x = (j + 0.5) / n;
      switch (name) {
        case "uniform": f[j] = 1; break;
        case "spike": { const k = Math.min(param | 0, L); f[j] = j < (n >> k) ? 2 ** k : 0; break; }
        case "witness": { const m = Math.min(param | 0, L - 1); f[j] = j < (n >> (m + 1)) ? 2 ** (m + 1) : 0; break; }
        case "step": f[j] = x < 0.5 ? 1.5 : 0.5; break;
        case "ramp": f[j] = 2 * x; break;
        case "oscillating": f[j] = 1 + 0.9 * Math.cos(2 * Math.PI * (param || 6) * x); break;
        case "bimodal": f[j] = Math.exp(-(((x - 0.2) / 0.05) ** 2)) + Math.exp(-(((x - 0.75) / 0.08) ** 2)) + 1e-3; break;
        case "random": f[j] = 0; break;
        default: throw new Error("unknown declaration " + name);
      }
    }
    if (name === "random") { const r = rng(seed || 1); for (let j = 0; j < n; j++) f[j] = r() ** 3; }
    return normalize(f);
  }
  function tentLab(fName, gName, L, nmax, pf, pg, seed) {
    let f = declaration(fName, L, pf, seed), g = declaration(gName, L, pg, (seed || 1) + 1);
    const V = variation(f.map((x, i) => x - g[i])), rows = [];
    for (let n = 0; n <= nmax; n++) {
      rows.push({ n, tv: tv(f, g), bound: Math.min(1, 2 ** -(n + 2) * V) });
      f = tentP(f); g = tentP(g);
    }
    return { V, rows, violations: rows.filter((r) => r.tv > r.bound * (1 + 1e-12) + 1e-15).length };
  }
  const frontier = (V, tau) => Math.max(0, Math.ceil(Math.log2(V / tau)) - 2);

  // ============================================================ R33/R34/R35: cat map on an N x N lattice
  function catLab(N, block, nmax, mutate) {
    const map = mutate ? (x, y) => [(2 * x) % N, (2 * y) % N]           // non-injective mutation
                       : (x, y) => [(2 * x + y) % N, (x + y) % N];       // Arnold cat map, a bijection
    // two declarations: uniform on two different blocks of the observation partition
    let mu = new Float64Array(N * N), nu = new Float64Array(N * N);
    const b = block, w = 1 / (b * b);
    for (let x = 0; x < b; x++) for (let y = 0; y < b; y++) { mu[x * N + y] = w; nu[(x + b) * N + y] = w; }
    const obs = (m) => { const K = N / b, o = new Float64Array(K * K);
      for (let x = 0; x < N; x++) for (let y = 0; y < N; y++) o[Math.floor(x / b) * K + Math.floor(y / b)] += m[x * N + y]; return o; };
    const TV = (p, q) => { let s = 0; for (let i = 0; i < p.length; i++) s += Math.abs(p[i] - q[i]); return 0.5 * s; };
    const rows = []; let period = null;
    const mu0 = mu.slice(), nu0 = nu.slice();
    for (let n = 0; n <= nmax; n++) {
      rows.push({ n, full: TV(mu, nu), observed: TV(obs(mu), obs(nu)) });
      const m2 = new Float64Array(N * N), n2 = new Float64Array(N * N);
      for (let x = 0; x < N; x++) for (let y = 0; y < N; y++) { const [X, Y] = map(x, y); m2[X * N + Y] += mu[x * N + y]; n2[X * N + Y] += nu[x * N + y]; }
      mu = m2; nu = n2;
      if (period === null && !mutate && mu.every((v, i) => v === mu0[i]) && nu.every((v, i) => v === nu0[i])) period = n + 1;
    }
    return { rows, period };
  }

  // ============================================================ R47/A07: floats are atomic
  // form "abs":    T(x) = 1 - |2x - 1|      (rounds below 1/4 off the 2^-54 lattice)
  // form "branch": T(x) = x < 1/2 ? 2x : 2 - 2x (exact on every double)
  // declaration: uniform with `bits` random binary digits, scaled into [0, scale]
  function floatTent(nSamples, steps, seed, bits, form, scale) {
    const r = rng(seed), x = new Float64Array(nSamples);
    bits = bits || 53; form = form || "abs"; scale = scale || 1;
    for (let i = 0; i < nSamples; i++) {
      let u;
      if (bits <= 32) u = Math.floor(r() * 2 ** bits) / 2 ** bits;
      else { const hi = Math.floor(r() * 2 ** 32), lo = Math.floor(r() * 2 ** (bits - 32)); u = (hi * 2 ** (bits - 32) + lo) / 2 ** bits; }
      x[i] = u * scale;
    }
    const T = form === "branch" ? (v) => (v < 0.5 ? 2 * v : 2 - 2 * v) : (v) => 1 - Math.abs(2 * v - 1);
    const zeroFrac = [];
    for (let n = 0; n <= steps; n++) {
      let z = 0; for (let i = 0; i < nSamples; i++) if (x[i] === 0) z++;
      zeroFrac.push(z / nSamples);
      for (let i = 0; i < nSamples; i++) x[i] = T(x[i]);
    }
    return zeroFrac;
  }

  // ============================================================ R40: Dobrushin coefficient
  function matmul(A, B) { const n = A.length, m = B[0].length, k = B.length, C = [];
    for (let i = 0; i < n; i++) { C.push(new Array(m).fill(0)); for (let t = 0; t < k; t++) { const a = A[i][t]; if (a) for (let j = 0; j < m; j++) C[i][j] += a * B[t][j]; } } return C; }
  function dobrushin(K) { let d = 0; for (let i = 0; i < K.length; i++) for (let j = i + 1; j < K.length; j++) {
      let s = 0; for (let k = 0; k < K.length; k++) s += Math.abs(K[i][k] - K[j][k]); d = Math.max(d, s / 2); } return d; }
  function rotationNoise(M, shift, width) {
    const K = []; for (let i = 0; i < M; i++) { const row = new Array(M).fill(0);
      for (let w = -width; w <= width; w++) row[((i + shift + w) % M + M) % M] += 1 / (2 * width + 1); K.push(row); } return K;
  }
  function dobrushinLab(M, shift, width, mmax) {
    const K = rotationNoise(M, shift, width), out = []; let P = K;
    for (let m = 1; m <= mmax; m++) { out.push({ m, delta: dobrushin(P) }); P = matmul(P, K); }
    return out;
  }

  // ============================================================ UG04/R45: fold y = b^2 + noise
  function foldCoverage(bTrue, sigma, reps, seed) {
    const r = rng(seed), z = 1.959963984540054; let cLin = 0, cRG = 0, cY = 0;
    for (let t = 0; t < reps; t++) {
      const y = bTrue * bTrue + sigma * gauss(r), lo = y - z * sigma, hi = y + z * sigma;
      if (bTrue * bTrue >= lo && bTrue * bTrue <= hi) cY++;
      const bh = Math.sqrt(Math.max(y, 0)), se = bh > 0 ? sigma / (2 * bh) : Infinity;   // positive-root branch selection
      if (Math.abs(bTrue - bh) <= z * se) cLin++;
      if (hi >= 0) { const a = Math.sqrt(Math.max(lo, 0)), c = Math.sqrt(hi);         // full preimage: +[a,c] and -[a,c]
        const ab = Math.abs(bTrue); if (ab >= a && ab <= c) cRG++; }
    }
    return { linear: cLin / reps, rgSet: cRG / reps, observation: cY / reps };
  }

  // ============================================================ UG03: quotient forgets the prior, kernel never does
  // y_k = x1 + x2 + e,  e ~ N(0, s^2). Identifiable q = x1 + x2, kernel k = x1 - x2. Data held at the truth (population limit).
  function inv2(A) { const d = A[0][0] * A[1][1] - A[0][1] * A[1][0]; return [[A[1][1] / d, -A[0][1] / d], [-A[1][0] / d, A[0][0] / d]]; }
  function posterior(m0, V0, n, s, qTrue, fullRank) {
    const P0 = inv2(V0), w = n / (s * s);
    const P = [[P0[0][0] + w, P0[0][1] + w], [P0[1][0] + w, P0[1][1] + w]];
    let b = [P0[0][0] * m0[0] + P0[0][1] * m0[1] + w * qTrue, P0[1][0] * m0[0] + P0[1][1] * m0[1] + w * qTrue];
    if (fullRank) { // mutation: a second channel observes x1 - x2 = 0.3 with the same precision
      P[0][0] += w; P[1][1] += w; P[0][1] -= w; P[1][0] -= w; b = [b[0] + w * 0.3, b[1] - w * 0.3];
    }
    const V = inv2(P), m = [V[0][0] * b[0] + V[0][1] * b[1], V[1][0] * b[0] + V[1][1] * b[1]];
    return { qMean: m[0] + m[1], qVar: V[0][0] + V[1][1] + 2 * V[0][1], kVar: V[0][0] + V[1][1] - 2 * V[0][1], kMean: m[0] - m[1] };
  }
  function priorLab(ns, fullRank) {
    const A = { m: [0, 0], V: [[1, 0], [0, 1]] }, B = { m: [1.0, -0.4], V: [[4, 0.6], [0.6, 0.5]] };
    return ns.map((n) => { const a = posterior(A.m, A.V, n, 1, 2.0, fullRank), b = posterior(B.m, B.V, n, 1, 2.0, fullRank);
      return { n, qDiff: Math.abs(a.qMean - b.qMean), kVarA: a.kVar, kVarB: b.kVar, kVarDiff: Math.abs(a.kVar - b.kVar), kMeanDiff: Math.abs(a.kMean - b.kMean) }; });
  }

  // ============================================================ Distance and angle (finite regular classical module)
  function symEig(A) { // Jacobi, small symmetric
    const n = A.length, a = A.map((r) => r.slice()), V = A.map((_, i) => A.map((_, j) => (i === j ? 1 : 0)));
    for (let sweep = 0; sweep < 100; sweep++) {
      let off = 0; for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) off += a[i][j] ** 2;
      if (off < 1e-30) break;
      for (let p = 0; p < n; p++) for (let q = p + 1; q < n; q++) {
        if (Math.abs(a[p][q]) < 1e-300) continue;
        const th = (a[q][q] - a[p][p]) / (2 * a[p][q]), t = Math.sign(th || 1) / (Math.abs(th) + Math.sqrt(th * th + 1)), c = 1 / Math.sqrt(t * t + 1), s = t * c;
        for (let k = 0; k < n; k++) { const akp = a[k][p], akq = a[k][q]; a[k][p] = c * akp - s * akq; a[k][q] = s * akp + c * akq; }
        for (let k = 0; k < n; k++) { const apk = a[p][k], aqk = a[q][k]; a[p][k] = c * apk - s * aqk; a[q][k] = s * apk + c * aqk; }
        for (let k = 0; k < n; k++) { const vkp = V[k][p], vkq = V[k][q]; V[k][p] = c * vkp - s * vkq; V[k][q] = s * vkp + c * vkq; }
      }
    }
    return { values: a.map((r, i) => r[i]), vectors: V };
  }
  function pinvSym(A, rtol) { const { values, vectors } = symEig(A), n = A.length, mx = Math.max(...values.map(Math.abs), 0), P = [];
    for (let i = 0; i < n; i++) { P.push(new Array(n).fill(0)); for (let j = 0; j < n; j++) for (let k = 0; k < n; k++)
      if (Math.abs(values[k]) > rtol * mx) P[i][j] += vectors[i][k] * vectors[j][k] / values[k]; } return P; }
  function fisher(J, Sigma) { // J: m x p, Sigma: m x m (SPD)
    const Si = pinvSym(Sigma, 1e-14), p = J[0].length, m = J.length, F = [];
    for (let a = 0; a < p; a++) { F.push(new Array(p).fill(0)); for (let b = 0; b < p; b++) { let s = 0;
      for (let i = 0; i < m; i++) for (let j = 0; j < m; j++) s += J[i][a] * Si[i][j] * J[j][b]; F[a][b] = s; } } return F;
  }
  function schur(I, target, nuisance) { // efficient information on target after nuisance is profiled out
    const sub = (r, c) => r.map((i) => c.map((j) => I[i][j]));
    const Iqq = sub(target, target); if (!nuisance.length) return Iqq;
    const Iqn = sub(target, nuisance), Inn = sub(nuisance, nuisance), Inq = sub(nuisance, target), Ip = pinvSym(Inn, 1e-12);
    const T = matmul(matmul(Iqn, Ip), Inq); return Iqq.map((r, i) => r.map((x, j) => x - T[i][j]));
  }
  function quad(g, u, v) { let s = 0; for (let i = 0; i < u.length; i++) for (let j = 0; j < v.length; j++) s += u[i] * g[i][j] * v[j]; return s; }
  function distanceAngle(g, q0, q1, u, v, rtol) {
    rtol = rtol || 1e-10;
    const { values, vectors } = symEig(g), mx = Math.max(...values.map(Math.abs));
    const rank = values.filter((x) => x > rtol * mx).length, neg = values.some((x) => x < -rtol * mx);
    const dq = q1.map((x, i) => x - q0[i]);
    const out = { eig: values, rank, dim: g.length, indefinite: neg };
    if (neg) { out.error = "the declared tensor is indefinite: it is not a distinguishability metric"; return out; }
    out.distance = Math.sqrt(Math.max(quad(g, dq, dq), 0));
    // vertical part of the displacement (component in the radical) is invisible
    out.radical = vectors[0].map((_, k) => k).filter((k) => values[k] <= rtol * mx).map((k) => vectors.map((r) => r[k]));
    const uu = quad(g, u, u), vv = quad(g, v, v), uv = quad(g, u, v);
    if (rank < 2) out.angleError = "rank-one (or zero) stratum: length exists along the resolved direction, but no intrinsic angle between two directions (No-Go 4.4)";
    else if (uu <= rtol * mx * 1e-6 || vv <= rtol * mx * 1e-6) out.angleError = "one of the directions lies in the radical: zero length, angle undefined";
    else { out.cos = Math.max(-1, Math.min(1, uv / Math.sqrt(uu * vv))); out.angleDeg = Math.acos(out.cos) * 180 / Math.PI; }
    const euclid = Math.hypot(...dq);
    out.euclid = euclid;
    const isotropic = rank === g.length && Math.max(...values) / Math.min(...values) < 1 + 1e-9 && g.every((r, i) => r.every((x, j) => i === j || Math.abs(x) < 1e-12 * mx));
    out.isotropic = isotropic; if (isotropic) out.lambda = Math.sqrt(values[0]);
    return out;
  }

  // metric field geodesic relaxation (numerical, not a certificate): returns length of relaxed path and of the straight path
  function pathLength(gf, pts) { let L = 0; for (let i = 1; i < pts.length; i++) { const m = [(pts[i][0] + pts[i - 1][0]) / 2, (pts[i][1] + pts[i - 1][1]) / 2],
      d = [pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]], g = gf(m[0], m[1]); L += Math.sqrt(Math.max(quad(g, d, d), 0)); } return L; }
  function geodesic(gf, q0, q1, K, iters) {
    K = K || 48; iters = iters || 4000;
    let pts = []; for (let i = 0; i <= K; i++) pts.push([q0[0] + (q1[0] - q0[0]) * i / K, q0[1] + (q1[1] - q0[1]) * i / K]);
    const straight = pathLength(gf, pts);
    const energy = (P) => { let E = 0; for (let i = 1; i < P.length; i++) { const m = [(P[i][0] + P[i - 1][0]) / 2, (P[i][1] + P[i - 1][1]) / 2],
      d = [P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1]]; E += quad(gf(m[0], m[1]), d, d); } return E * K; };
    let step = 0.02 * Math.hypot(q1[0] - q0[0], q1[1] - q0[1]) / K, E = energy(pts);
    for (let it = 0; it < iters; it++) {
      let improved = false;
      for (let i = 1; i < K; i++) for (let c = 0; c < 2; c++) {
        const h = 1e-6 * (1 + Math.abs(pts[i][c]));
        const local = (P) => { let e = 0; for (const j of [i, i + 1]) { const m = [(P[j][0] + P[j - 1][0]) / 2, (P[j][1] + P[j - 1][1]) / 2],
          d = [P[j][0] - P[j - 1][0], P[j][1] - P[j - 1][1]]; e += quad(gf(m[0], m[1]), d, d); } return e; };
        const e0 = local(pts); pts[i][c] += h; const e1 = local(pts); pts[i][c] -= h;
        const gr = (e1 - e0) / h, old = pts[i][c]; pts[i][c] = old - step * Math.sign(gr) * Math.min(1, Math.abs(gr) / (Math.abs(gr) + 1e-12));
        if (local(pts) < e0) improved = true; else pts[i][c] = old;
      }
      if (!improved) { step *= 0.5; if (step < 1e-12) break; }
    }
    E = energy(pts);
    return { straight, relaxed: pathLength(gf, pts), energyBound: Math.sqrt(E), path: pts };
  }
  // closed-form Fisher–Rao distance between N(mu1, s1^2) and N(mu2, s2^2): an independent check for the relaxer
  function normalFisherRao(m1, s1, m2, s2) {
    const a = (m1 - m2) ** 2 + 2 * (s1 - s2) ** 2, b = (m1 - m2) ** 2 + 2 * (s1 + s2) ** 2;
    return 2 * Math.SQRT2 * Math.atanh(Math.sqrt(a / b));
  }
  function simpson(f, a, b, n) { n = n || 400; if (n % 2) n++; const h = (b - a) / n; let s = f(a) + f(b);
    for (let i = 1; i < n; i++) s += (i % 2 ? 4 : 2) * f(a + i * h); return s * h / 3; }

  // ============================================================ Null resolution depth: exact rationals vs float64
  const gcd = (a, b) => { a = a < 0n ? -a : a; b = b < 0n ? -b : b; while (b) [a, b] = [b, a % b]; return a; };
  class Q { constructor(n, d) { d = d === undefined ? 1n : d; if (d < 0n) { n = -n; d = -d; } const g = gcd(n, d) || 1n; this.n = n / g; this.d = d / g; }
    add(o) { return new Q(this.n * o.d + o.n * this.d, this.d * o.d); } sub(o) { return new Q(this.n * o.d - o.n * this.d, this.d * o.d); }
    mul(o) { return new Q(this.n * o.n, this.d * o.d); } isZero() { return this.n === 0n; } toNumber() { return Number(this.n) / Number(this.d); }
    log10() { if (this.n === 0n) return -Infinity; return (this.n.toString().length - this.d.toString().length) + Math.log10(Number("0." + this.n.toString().slice(0, 15)) / Number("0." + this.d.toString().slice(0, 15))); } }
  function rationalRotation() { // Rz(3/5,4/5) * Rx(5/13,12/13): exactly orthogonal, rational
    const q = (a, b) => new Q(BigInt(a), BigInt(b));
    const Rz = [[q(3, 5), q(-4, 5), q(0, 1)], [q(4, 5), q(3, 5), q(0, 1)], [q(0, 1), q(0, 1), q(1, 1)]];
    const Rx = [[q(1, 1), q(0, 1), q(0, 1)], [q(0, 1), q(5, 13), q(-12, 13)], [q(0, 1), q(12, 13), q(5, 13)]];
    return [0, 1, 2].map((i) => [0, 1, 2].map((j) => [0, 1, 2].reduce((s, k) => s.add(Rz[i][k].mul(Rx[k][j])), new Q(0n))));
  }
  function nullDepthLab(k) { // spectrum {1, 10^-k, 0} hidden behind a rational rotation
    const R = rationalRotation(), eps = new Q(1n, 10n ** BigInt(k)), Dg = [new Q(1n), eps, new Q(0n)];
    const F = [0, 1, 2].map((i) => [0, 1, 2].map((j) => [0, 1, 2].reduce((s, t) => s.add(R[i][t].mul(Dg[t]).mul(R[j][t])), new Q(0n))));
    const Ff = F.map((r) => r.map((x) => x.toNumber()));
    const dirs = [0, 1, 2].map((t) => [0, 1, 2].map((i) => R[i][t]));
    const exact = dirs.map((v) => [0, 1, 2].reduce((s, i) => s.add([0, 1, 2].reduce((u, j) => u.add(v[i].mul(F[i][j]).mul(v[j])), new Q(0n))), new Q(0n)));
    const flo = dirs.map((v) => { const vf = v.map((x) => x.toNumber()); return quad(Ff, vf, vf); });
    const floatEig = symEig(Ff).values.sort((a, b) => b - a);
    return { exact: exact.map((x) => ({ zero: x.isZero(), log10: x.log10(), str: x.isZero() ? "0" : (x.n === 1n ? `1/${x.d}` : `${x.n}/${x.d}`) })),
      float: flo, floatEig, depth: exact.map((x) => (x.isZero() ? Infinity : Math.max(0, -Math.round(x.log10())))) };
  }
  function representationLab(n, noise, seed) {
    const r = rng(seed), x = [], y = [];
    for (let i = 0; i < n; i++) { const xi = 2 * r() - 1; x.push(xi); y.push(xi * xi + noise * gauss(r)); }
    const fit = (cols) => { // least squares via normal equations (small)
      const p = cols.length, A = [], b = new Array(p).fill(0);
      for (let a = 0; a < p; a++) { A.push(new Array(p).fill(0)); for (let c = 0; c < p; c++) for (let i = 0; i < n; i++) A[a][c] += cols[a][i] * cols[c][i];
        for (let i = 0; i < n; i++) b[a] += cols[a][i] * y[i]; }
      const Ai = pinvSym(A, 1e-14), beta = Ai.map((row) => row.reduce((s, v, j) => s + v * b[j], 0));
      const my = y.reduce((s, v) => s + v, 0) / n; let ss = 0, sr = 0;
      for (let i = 0; i < n; i++) { const yh = cols.reduce((s, col, a) => s + beta[a] * col[i], 0); sr += (y[i] - yh) ** 2; ss += (y[i] - my) ** 2; }
      return 1 - sr / ss; };
    const one = x.map(() => 1);
    return { linear: fit([one, x]), quadratic: fit([one, x, x.map((v) => v * v)]) };
  }

  // ============================================================ Operational duration
  function cocycle(ab, bc, ac) { // Q_B = a_ba Q_A + b_ba etc. Provide [a,b] for A->B, B->C, A->C
    const aPred = bc[0] * ab[0], bPred = bc[0] * ab[1] + bc[1];
    return { aDefect: ac[0] - aPred, bDefect: ac[1] - bPred, aPred, bPred };
  }
  function contrast(dTA, dTB, aAB, gauge) { // gauge: [k, c] T -> kT + c acts on both clocks' readings; elapsed differences ignore c
    const D0 = dTA - dTB / aAB, D1 = gauge[0] * dTA - gauge[0] * dTB / aAB;
    return { D0, D1, signPreserved: Math.sign(D0) === Math.sign(D1), ratio: D0 !== 0 ? D1 / D0 : NaN };
  }
  function loophole(T, U, vA, vB, rate0) { // dT/dt = rate0 * sqrt(1 - v^2) (1 + U); one shared coordinate interval T
    const r = (v) => rate0 * Math.sqrt(1 - v * v) * (1 + U);
    return { TA: simpson((t) => r(vA(t, T)), 0, T, 2000), TB: simpson((t) => r(vB(t, T)), 0, T, 2000) };
  }

  // ============================================================ Chaos frontier: protocols move intercepts, dynamics sets slopes
  function frontierLab(r, sigmas, tau, nEns, nmax, seed) {
    const R = rng(seed), f = (x) => r * x * (1 - x), out = [];
    for (const s0 of sigmas) {
      const x0 = 0.3 + 0.1 * R(); const xs = new Float64Array(nEns);
      for (let i = 0; i < nEns; i++) { let v = x0 + s0 * gauss(R); xs[i] = Math.min(1 - 1e-15, Math.max(1e-15, v)); }
      let nstar = null;
      for (let n = 0; n <= nmax; n++) {
        let m = 0; for (const v of xs) m += v; m /= nEns; let sd = 0; for (const v of xs) sd += (v - m) ** 2; sd = Math.sqrt(sd / (nEns - 1));
        if (sd > tau) { nstar = n; break; }
        for (let i = 0; i < nEns; i++) xs[i] = f(xs[i]);
      }
      out.push({ sigma0: s0, nstar });
    }
    const pts = out.filter((o) => o.nstar !== null).map((o) => [Math.log(1 / o.sigma0), o.nstar]);
    let slope = null;
    if (pts.length >= 3) { const mx = pts.reduce((s, p) => s + p[0], 0) / pts.length, my = pts.reduce((s, p) => s + p[1], 0) / pts.length;
      slope = pts.reduce((s, p) => s + (p[0] - mx) * (p[1] - my), 0) / pts.reduce((s, p) => s + (p[0] - mx) ** 2, 0); }
    return { rows: out, slope, predicted: r === 4 ? 1 / Math.LN2 : null };
  }

  // ============================================================ Threshold projector wall (Prop. 9.5)
  function projectorJump(t, tau) {
    const L = [1 + t, 1 - t, 0.2]; return L.map((x) => (x > tau ? 1 : 0));
  }

  const api = { tentP, tv, variation, declaration, tentLab, frontier, catLab, floatTent, dobrushin, rotationNoise, dobrushinLab,
    foldCoverage, priorLab, posterior, symEig, pinvSym, fisher, schur, quad, distanceAngle, geodesic, pathLength, normalFisherRao, simpson,
    nullDepthLab, representationLab, rationalRotation, Q, cocycle, contrast, loophole, frontierLab, projectorJump, matmul };
  root.RGLabs = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
