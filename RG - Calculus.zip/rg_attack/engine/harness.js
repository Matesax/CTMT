// Node harness: executes the exact engine files the site inlines, on a JSON job list from stdin.
"use strict";
const fs = require("fs"), path = require("path");
(new Function(fs.readFileSync(path.join(__dirname, "parser.js"), "utf8").replace("})(this);", "})(globalThis);")))();
const RGCalc = require("./rgcalc.js"), RGLabs = require("./labs.js"), RGLabs2 = require("./labs2.js"), RGLabs3 = require("./labs3.js");
const QM = (M) => M.map((r) => r.map((x) => RGLabs3.Q.parse(String(x))));
const L3X = {
  pairedClosureQ: (R, N, C, R2, N2, C2) => { const c = RGLabs3.pairedClosure(RGLabs3.tuple(QM(R), QM(N), QM(C)), RGLabs3.tuple(QM(R2), QM(N2), QM(C2))); return { dim: c.dim, equivalent: c.equivalent }; },
  compareRoomQ: (R, N, C, R2, N2, C2) => { const c = RGLabs3.compareRoom({ R: QM(R), N: QM(N), C: QM(C) }, { R: QM(R2), N: QM(N2), C: QM(C2) }); return { doors: c.doors, separating: c.separating, closure: { equivalent: c.closure.equivalent, dim: c.closure.dim } }; },
  cycleSignsGauge: (C, flips) => { let M = QM(C); const before = RGLabs3.cycleSigns(M).signature; for (const [kind, k] of flips) M = kind === 0 ? RGLabs3.flipRow(M, Math.min(k, M.length - 1)) : RGLabs3.flipCol(M, k); return { before, after: RGLabs3.cycleSigns(M).signature }; },
};
const clean = (x) => JSON.parse(JSON.stringify(x, (k, v) => {
  if (typeof v === "number" && !isFinite(v)) return isNaN(v) ? "NaN" : (v > 0 ? "Infinity" : "-Infinity");
  if (typeof v === "bigint") return v.toString();
  if (ArrayBuffer.isView(v)) return Array.from(v);
  return v;
}));
const job = JSON.parse(fs.readFileSync(0, "utf8"));
const out = job.calls.map((c) => {
  try {
    if (c.lib === "calc") return clean(RGCalc.run(c.src)).out;
    if (c.lib === "geodesic_normal") { const r = RGLabs.geodesic((m, s) => [[1 / (s * s), 0], [0, 2 / (s * s)]], c.q0, c.q1, c.K || 48, c.iters || 3000); return { straight: r.straight, relaxed: r.relaxed }; }
    if (c.lib === "labs2") return clean(RGLabs2[c.fn](...c.args));
    if (c.lib === "labs3") return clean((L3X[c.fn] || RGLabs3[c.fn])(...c.args));
    return clean(RGLabs[c.fn](...c.args));
  } catch (e) { return { __error: String(e && e.message || e) }; }
});
process.stdout.write(JSON.stringify(out));
