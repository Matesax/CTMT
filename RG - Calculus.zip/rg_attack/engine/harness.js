// Node harness: executes the exact engine files the site inlines, on a JSON job list from stdin.
"use strict";
const fs = require("fs"), path = require("path");
(new Function(fs.readFileSync(path.join(__dirname, "parser.js"), "utf8").replace("})(this);", "})(globalThis);")))();
const RGCalc = require("./rgcalc.js"), RGLabs = require("./labs.js"), RGLabs2 = require("./labs2.js");
const clean = (x) => JSON.parse(JSON.stringify(x, (k, v) => {
  if (typeof v === "number" && !isFinite(v)) return isNaN(v) ? "NaN" : (v > 0 ? "Infinity" : "-Infinity");
  if (typeof v === "bigint") return v.toString();
  if (ArrayBuffer.isView(v)) return Array.from(v);
  return v;
}));
const job = JSON.parse(fs.readFileSync(0, "utf8"));
const out = job.calls.map((c) => {
  try {
    if (c.lib === "calc") return clean(RGCalc.run(c.src)).out;
    if (c.lib === "geodesic_normal") { const r = RGLabs.geodesic((m, s) => [[1 / (s * s), 0], [0, 2 / (s * s)]], c.q0, c.q1, c.K || 48, c.iters || 3000); return { straight: r.straight, relaxed: r.relaxed }; }
    if (c.lib === "labs2") return clean(RGLabs2[c.fn](...c.args));
    return clean(RGLabs[c.fn](...c.args));
  } catch (e) { return { __error: String(e && e.message || e) }; }
});
process.stdout.write(JSON.stringify(out));
