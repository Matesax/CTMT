"""Attacks on routing (T), the CHI channel (C), the wind-turbine (W) and fuel (V) calculators, and `compare` (E07).

Reference values are established results only: TSPLIB published optima, the Betz limit, the Weibull/Rayleigh
energy pattern factor, NREL 5-MW published specifications, Colebrook-White, IAU/CODATA constants, Vincenty.
Reference *laws* used to generate anchors (road load, actuator disc, pump affinity) are declared as such.
"""
from __future__ import annotations

import itertools
import math

import numpy as np

from common import attack, jnum, node, result

PI_T, RRR = 3.141592, 6378.388
BURMA14 = [(16.47, 96.10), (16.47, 94.44), (20.09, 92.54), (22.39, 93.37), (25.23, 97.24), (22.00, 96.05), (20.47, 97.02),
           (17.20, 96.29), (16.30, 97.38), (14.05, 98.12), (16.53, 97.38), (21.52, 95.59), (19.41, 97.13), (20.09, 94.55)]
ULYSSES16 = [(38.24, 20.42), (39.57, 26.15), (40.56, 25.32), (36.26, 23.12), (33.48, 10.54), (37.56, 12.19), (38.42, 13.11), (37.52, 20.44),
             (41.23, 9.10), (41.17, 13.05), (36.08, -5.21), (38.47, 15.13), (38.15, 15.35), (37.51, 15.17), (35.49, 14.32), (39.36, 19.56)]
CITIES = {"Brno": (49.1951, 16.6068), "Prague": (50.0755, 14.4378), "Vienna": (48.2082, 16.3738), "Bratislava": (48.1486, 17.1077), "Budapest": (47.4979, 19.0402)}


def geo_matrix(c):
    def rad(v):
        d = int(v); return PI_T * (d + 5 * (v - d) / 3) / 180
    g = [(rad(x), rad(y)) for x, y in c]
    n = len(g); D = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            if i != j:
                q1 = math.cos(g[i][1] - g[j][1]); q2 = math.cos(g[i][0] - g[j][0]); q3 = math.cos(g[i][0] + g[j][0])
                D[i][j] = int(RRR * math.acos(0.5 * ((1 + q1) * q2 - (1 - q1) * q3)) + 1)
    return D


def held_karp(D):
    n = len(D); m = n - 1; INF = float("inf"); full = 1 << m
    dp = [[INF] * m for _ in range(full)]
    for j in range(m): dp[1 << j][j] = D[0][j + 1]
    for S in range(1, full):
        row = dp[S]
        for j in range(m):
            v = row[j]
            if v == INF or not (S >> j) & 1: continue
            Dj = D[j + 1]
            for k in range(m):
                if (S >> k) & 1: continue
                T = S | (1 << k); w = v + Dj[k + 1]
                if w < dp[T][k]: dp[T][k] = w
    return min(dp[full - 1][j] + D[j + 1][0] for j in range(m))


def brute(D):
    n = len(D)
    return min(sum(D[t[i]][t[(i + 1) % n]] for i in range(n)) for p in itertools.permutations(range(1, n)) for t in [(0,) + p])


def hav(a, b, R=6371.0088):
    p1, l1, p2, l2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    h = math.sin((p2 - p1) / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin((l2 - l1) / 2) ** 2
    return 2 * R * math.asin(math.sqrt(h))


@attack("T01", "routing: exact solver", "the site's exact solver reproduces published TSPLIB optima (burma14 = 3323, ulysses16 = 6859)", "holds", seeded=False, needs_node=True)
def t01(seed):
    py = {"burma14": held_karp(geo_matrix(BURMA14)), "ulysses16": held_karp(geo_matrix(ULYSSES16))}
    js = node([{"lib": "labs2", "fn": "heldKarp", "args": [geo_matrix(BURMA14)]}, {"lib": "labs2", "fn": "heldKarp", "args": [geo_matrix(ULYSSES16)]}])
    js_cost = {"burma14": js[0]["cost"], "ulysses16": js[1]["cost"]}
    tour_ok = all(abs(sum(geo_matrix(c)[t[i]][t[(i + 1) % len(t)]] for i in range(len(t))) - js_cost[k]) < 1e-9 and sorted(t) == list(range(len(c)))
                  for (k, c), t in zip([("burma14", BURMA14), ("ulysses16", ULYSSES16)], [js[0]["tour"], js[1]["tour"]]))
    ok = py == {"burma14": 3323, "ulysses16": 6859} and js_cost == py and tour_ok
    # mutation: moving one stop by 0.5 degrees must change the optimum
    moved = list(BURMA14); moved[4] = (moved[4][0] - 0.5, moved[4][1])
    return result("holds" if ok else "counterexample", {"python": py, "js": js_cost, "returned_tours_valid": tour_ok},
                  "mutation: moving one stop must change the optimum", held_karp(geo_matrix(moved)) != 3323)


@attack("T02", "routing: heuristic and Held-Karp bound", "heuristic >= exact optimum >= 1-tree lower bound on random instances; exact equals brute force", "holds", needs_node=True)
def t02(seed):
    rng = np.random.default_rng(seed)
    calls, insts = [], []
    for n in (7, 8, 9, 10, 11, 12):
        pts = rng.random((n, 2)) * 100
        D = [[float(math.hypot(*(pts[i] - pts[j]))) for j in range(n)] for i in range(n)]
        insts.append(D)
        calls += [{"lib": "labs2", "fn": "heldKarp", "args": [D]}, {"lib": "labs2", "fn": "heuristic", "args": [D, 6, int(seed % 2**31), 20]},
                  {"lib": "labs2", "fn": "hkBound", "args": [D, 1e9, 600]}, {"lib": "labs2", "fn": "hkBound", "args": [D, 1e9, 600, True]}]
    out = node(calls)
    viol, gaps, mut = 0, [], False
    for i, D in enumerate(insts):
        ex, he, lb, bad = out[4 * i]["cost"], out[4 * i + 1]["cost"], jnum(out[4 * i + 2]), jnum(out[4 * i + 3])
        ref = brute(D) if len(D) <= 9 else held_karp(D)
        viol += abs(ex - ref) > 1e-7 or he < ref - 1e-7 or lb > ref + 1e-7
        gaps.append((he - ref) / ref)
        mut |= bad > ref + 1e-7
    return result("holds" if viol == 0 else "counterexample", {"violations": viol, "heuristic_gaps": gaps},
                  "mutation: a 1-tree using the two LARGEST edges at the root is not a bound and must exceed the optimum somewhere", mut)


@attack("T03", "retired kernel-rhythm routing", "kernel rhythm routing with L_K = 250 m yields different routes, 645 vs 662 km, less time and fuel", "counterexample", seeded=False, needs_node=True)
def t03(seed):
    names = list(CITIES); n = 5
    D = [[hav(CITIES[a], CITIES[b]) if a != b else 0.0 for b in names] for a in names]
    LK = 0.25                                          # v_sync / gamma = 3e8 / 1.2e6 m = 250 m
    Phi = [D[0][i] / LK for i in range(n)]
    S = [[math.exp(-abs(Phi[i] - Phi[j])) for j in range(n)] for i in range(n)]
    maxS = max(S[i][j] for i in range(n) for j in range(n) if i != j)
    C = [[D[i][j] / (1 + 2.0 * S[i][j]) if i != j else 0 for j in range(n)] for i in range(n)]
    max_rel = max(abs(C[i][j] - D[i][j]) / D[i][j] for i in range(n) for j in range(n) if i != j)
    closed = brute(D)
    open_path = min(sum(D[p[i]][p[i + 1]] for i in range(4)) for p in itertools.permutations(range(5)))
    js = node([{"lib": "labs2", "fn": "kernelRhythmCost", "args": [D, 0, LK, 2.0, 1.0, 1.0]}])[0]
    same_js = js["maxRelChange"] < 1e-15
    # control: with L_K = 100 km the similarity is no longer negligible, so the detector is not trivially "unchanged"
    Phi2 = [D[0][i] / 100 for i in range(n)]
    C2_rel = max(abs(1 / (1 + 2 * math.exp(-abs(Phi2[i] - Phi2[j]))) - 1) for i in range(n) for j in range(n) if i != j)
    broken = max_rel < 1e-15 and same_js and closed > 645
    return result("counterexample" if broken else "holds",
                  {"phases": Phi, "max_similarity": maxS, "max_relative_cost_change": max_rel, "closed_tour_geodesic_km": closed,
                   "open_path_geodesic_km": open_path, "statement": "S underflows (max ~1e-19), so the kernel cost matrix equals the distance matrix and the kernel tour is the TSP tour. A closed tour cannot be 645 km (geodesic floor 912 km); an open route can. The table values are not computable from the stated parameters."},
                  "control: with L_K = 100 km the kernel cost must differ from distance", C2_rel > 0.1)


@attack("T04", "routing under uncertain costs (RG wall)", "the optimal length is a concave minimum: E[optimum] <= nominal optimum (Jensen), and near-ties make the optimal tour non-identifiable", "holds", needs_node=True)
def t04(seed):
    D = geo_matrix(BURMA14)
    D12 = [row[:12] for row in D[:12]]
    out = node([{"lib": "labs2", "fn": "routeUncertainty", "args": [D12, {"rel": 0.1, "samples": 150, "seed": int(seed % 2**31), "law": "normal"}]},
                {"lib": "labs2", "fn": "routeUncertainty", "args": [D12, {"rel": 0.0, "samples": 20, "seed": 1}]}])
    r, z = out
    ok = r["jensenGap"] > 0 and r["optMean"] <= r["nominal"] and r["pNominalOptimal"] < 1 and r["distinctOptima"] > 1 and r["nominal"] == held_karp(D12)
    return result("holds" if ok else "counterexample", {"nominal": r["nominal"], "E_opt": r["optMean"], "jensen_gap": r["jensenGap"],
                                                        "p_nominal_optimal": r["pNominalOptimal"], "distinct_optima": r["distinctOptima"], "sigma_lin": r["sigmaLin"]},
                  "mutation: with zero cost noise the nominal tour must stay optimal with no regret", z["pNominalOptimal"] == 1 and abs(z["jensenGap"]) < 1e-9)


# ---------------------------------------------------------------- CHI
def chi(M, v, Phi, g, h, rho):
    return M * v * v / (Phi * g * h * rho)


@attack("C01", "retired CHI: 'derived invariant'", "with one anchor, the choices of Phi, h, rho, g shape the prediction (chi is a derived invariant, not a fitted parameter)", "counterexample")
def c01(seed):
    rng = np.random.default_rng(seed)
    worst = 0.0
    for _ in range(200):
        M, v0, v1 = rng.uniform(500, 3000), rng.uniform(5, 30), rng.uniform(5, 40)
        y0 = rng.uniform(1e-4, 1e-2)
        preds = []
        for _ in range(5):
            Phi, h, rho, g = rng.uniform(0.5, 3), rng.uniform(0.5, 3), rng.uniform(0.8, 1.4), rng.uniform(9.7, 9.9)
            k = y0 / chi(M, v0, Phi, g, h, rho); preds.append(k * chi(M, v1, Phi, g, h, rho))
        worst = max(worst, (max(preds) - min(preds)) / min(preds))
    # control: if Phi differs between anchor and prediction, the prediction changes
    k = 1 / chi(1500, 20, 1.3, 9.81, 1.5, 1.2)
    ctrl = abs(k * chi(1500, 30, 1.0, 9.81, 1.5, 1.2) - k * chi(1500, 30, 1.3, 9.81, 1.5, 1.2)) > 1e-12
    return result("counterexample" if worst < 1e-12 else "holds", {"max_relative_spread_of_predictions": worst,
                  "statement": "k = y0/chi0 absorbs Phi, h, rho, g: the single-anchor prediction is y0 * (M1 v1^2)/(M0 v0^2). chi is a one-parameter fit."},
                  "control: changing Phi between anchor and prediction must change the prediction", ctrl)


@attack("C02", "retired CHI arithmetic", "the worked examples' numbers are internally consistent", "counterexample", seeded=False)
def c02(seed):
    chi0 = chi(1500, 20, 1.3, 9.81, 1.5, 1.2)
    p_fixed_head = 1000 * 9.81 * 0.02 * 10 / 0.7
    k = 1400 / chi(10, 0.01 / (math.pi * 0.05 ** 2), 1.2, 9.81, 10, 1000)
    p_chi = k * chi(20, 0.02 / (math.pi * 0.05 ** 2), 1.2, 9.81, 10, 1000)
    water = chi(0.02, 1.5, 1, 9.81, 0.1, 1000)
    issues = {"car_chi0_computed": chi0, "car_chi0_used_in_k": 5.22e4, "car_inconsistent": abs(chi0 - 5.22e4) / chi0 > 0.5,
              "pump_fixed_head_power_correct_W": p_fixed_head, "pump_fixed_head_claimed_W": 5600, "pump_claim_wrong": abs(p_fixed_head - 5600) > 100,
              "pump_chi_prediction_W": p_chi, "true_overshoot_factor": p_chi / p_fixed_head, "claimed_overshoot": 2.0,
              "water_column_chi_mL": water * 1e6, "water_column_claim_mL": 46}
    broken = issues["car_inconsistent"] and issues["pump_claim_wrong"]
    return result("counterexample" if broken else "holds", issues,
                  "control: the water-column arithmetic (46 mL) is correct and must not be flagged", abs(water * 1e6 - 46) < 0.5)


def car_rate(v, p):
    F = p["m"] * 9.80665 * p["crr"] + 0.5 * p["rho"] * p["cda"] * v * v
    return (p["P0"] + (F * v / p["etaDt"] + p["paux"]) / p["e"]) / (p["lhv"] * 1e6)


CAR = dict(m=1500, crr=0.010, cda=0.65, rho=1.2, etaDt=0.90, e=0.30, P0=4000, paux=300, lhv=32.0)


@attack("C03", "UG09: v^2 law misses rolling-plus-drag fuel power", "a chi channel calibrated at 20 m/s misses the road-load law by more than 10% at 10 and 40 m/s", "holds", needs_node=True)
def c03(seed):
    rng = np.random.default_rng(seed)
    p = dict(CAR); p["cda"] *= rng.uniform(0.9, 1.1); p["crr"] *= rng.uniform(0.9, 1.1); p["P0"] *= rng.uniform(0.8, 1.2)
    y20 = car_rate(20, p)
    err = {v: (y20 * (v / 20) ** 2 - car_rate(v, p)) / car_rate(v, p) for v in (10, 15, 25, 30, 40)}
    js = node([{"lib": "labs2", "fn": "chiChannel", "args": ["car", {"params": p, "anchors": [20], "predict": [10, 40], "noise": 0.0, "seed": 1}]}])[0]
    js_err = {q["x"]: q["err"] for q in js["predictions"]}
    ok = abs(err[10]) > 0.10 and abs(err[40]) > 0.05 and all(abs(js_err[v] - err[v]) < 1e-9 for v in (10, 40))
    # mutation: if the true fuel rate were pure v^2, the channel would transport exactly
    pure = {v: (y20 * (v / 20) ** 2 - y20 * (v / 20) ** 2) for v in (10, 40)}
    return result("holds" if ok else "counterexample", {"relative_errors": err, "js_errors": js_err, "declared_params": p,
                  "note": "UG09 reports 18% at 10 m/s and 22% at 40 m/s for its parameters; the size depends on the declared base power and drag, the failure does not"},
                  "mutation: a pure v^2 truth must be transported without error", all(abs(x) < 1e-15 for x in pure.values()))


@attack("C04", "UG09: density cancels", "with M = rho A v the chi channel is blind to air density while turbine power is proportional to it (36% at rho = 0.9)", "holds", needs_node=True)
def c04(seed):
    A, v, Phi = 10, 10, 1.0; R = math.sqrt(A / math.pi)
    def chi_w(rho): return chi(rho * A * v, v, Phi, 9.81, R, rho)
    el_chi = (math.log(chi_w(1.225 * 1.001)) - math.log(chi_w(1.225 * 0.999))) / (math.log(1.001) - math.log(0.999))
    over = 1.225 / 0.9 - 1
    js = node([{"lib": "labs2", "fn": "chiChannel", "args": ["wind", {"seed": 1}]}, {"lib": "labs2", "fn": "chiChannel", "args": ["car", {"seed": 1}]}])
    ok = abs(el_chi) < 1e-9 and abs(over - 0.3611) < 1e-3 and abs(js[0]["rhoElastChi"]) < 1e-9 and abs(js[0]["rhoElastTruth"] - 1) < 1e-6
    # mutation: a channel with M = fixed mass keeps the 1/rho dependence (elasticity -1), so the detector sees a nonzero value
    el_fixed = (math.log(chi(122.5, v, Phi, 9.81, R, 1.225 * 1.001)) - math.log(chi(122.5, v, Phi, 9.81, R, 1.225 * 0.999))) / (math.log(1.001) - math.log(0.999))
    return result("holds" if ok else "counterexample", {"chi_density_elasticity_wind": el_chi, "overprediction_at_0.9": over,
                                                        "car_chi_elasticity": js[1]["rhoElastChi"], "car_truth_elasticity": js[1]["rhoElastTruth"],
                                                        "note": "for the car the channel even has the wrong sign: chi divides by rho, drag multiplies by it"},
                  "mutation: with a fixed mass in place of rho A v the density dependence must reappear", abs(el_fixed + 1) < 1e-6)


@attack("C05", "UG09: bottleneck theorem reversed", "the series combination of chi values satisfies chi_eff <= chi_min", "counterexample", needs_node=True)
def c05(seed):
    rng = np.random.default_rng(seed)
    between, below = 0, 0
    for _ in range(1000):
        x = rng.uniform(0.1, 10, rng.integers(2, 8)); h = len(x) / np.sum(1 / x)
        between += x.min() - 1e-12 <= h <= x.mean() + 1e-12; below += h <= x.min() * (1 + 1e-12)
    js = node([{"lib": "labs2", "fn": "bottleneck", "args": [[4.2, 1.3, 7.7, 2.9]]}])[0]
    return result("counterexample" if below == 0 and between == 1000 and not js["claimHolds"] else "holds",
                  {"between_min_and_mean": between, "at_or_below_min": below, "js": js},
                  "control: equal values must satisfy the claim with equality", node([{"lib": "labs2", "fn": "bottleneck", "args": [[2.0, 2.0, 2.0]]}])[0]["claimHolds"])


@attack("C06", "RG CHI estimator certificate", "with several anchors the estimator rejects a misspecified chi law, accepts data from the chi law itself, and flags clustered anchors as a rank wall", "holds", needs_node=True)
def c06(seed):
    s = int(seed % 2**31)
    out = node([{"lib": "labs2", "fn": "chiChannel", "args": ["car", {"anchors": [10, 20, 30, 40], "noise": 0.01, "seed": s}]},
                {"lib": "labs2", "fn": "chiChannel", "args": ["car", {"anchors": [10, 20, 30, 40], "noise": 0.01, "seed": s, "truthIsChi": True}]},
                {"lib": "labs2", "fn": "chiChannel", "args": ["car", {"anchors": [19.99, 20, 20.01], "noise": 0.01, "seed": s}]},
                {"lib": "labs2", "fn": "chiChannel", "args": ["car", {"anchors": [20], "seed": s}]},
                {"lib": "labs2", "fn": "chiChannel", "args": ["pumpThrottle", {"anchors": [0.005, 0.01, 0.02], "noise": 0.01, "seed": s}]}])
    v = [o["verdict"] for o in out]
    ok = v[0] == "REJECTED" and v[2] == "WALL" and v[3] == "CONDITIONAL" and v[4] == "REJECTED"
    return result("holds" if ok else "counterexample", {"verdicts[misspecified, chi-truth, clustered, single, throttled pump]": v,
                                                        "free_exponent_car": out[0]["fit"], "free_exponent_chi_truth": out[1]["fit"]},
                  "control: anchors generated from the chi law itself must not be rejected", v[1] == "NOT REJECTED")


# ---------------------------------------------------------------- WIND
def weibull_pdf(v, k, c):
    return np.where(v > 0, (k / c) * (v / c) ** (k - 1) * np.exp(-(v / c) ** k), 0.0)


@attack("W01", "wind: established results", "Rayleigh energy pattern factor = 6/pi, Weibull Gamma-ratio identity, Betz limit refusal, NREL 5-MW rated speed consistent with 11.4 m/s", "holds", seeded=False, needs_node=True)
def w01(seed):
    out = node([{"lib": "labs2", "fn": "patternFactor", "args": [2]}, {"lib": "labs2", "fn": "patternFactor", "args": [1.6]},
                {"lib": "labs2", "fn": "turbineReport", "args": [{"D": 126, "rated": 5e6, "cutIn": 3, "cutOut": 25, "cp": 0.62, "eta": 0.944, "rho": 1.225}, {"vmean": 7, "k": 2}]},
                {"lib": "labs2", "fn": "ratedSpeed", "args": [{"D": 126, "rated": 5e6, "cp": 0.482, "eta": 0.944, "rho": 1.225}]}])
    k16 = math.gamma(1 + 3 / 1.6) / math.gamma(1 + 1 / 1.6) ** 3
    vr = out[3]; sig = vr * 0.02 / 0.482 / 3
    z = (vr - 11.4) / math.hypot(sig, 0.1)
    ok = abs(out[0]["exact"] - 6 / math.pi) < 1e-9 and abs(out[0]["numeric"] - 6 / math.pi) < 1e-6 and abs(out[1]["exact"] - k16) < 1e-9 and "error" in out[2] and abs(z) < 2
    # mutation: a turbine at exactly the Betz limit must be accepted (bound, not strict violation)
    at = node([{"lib": "labs2", "fn": "turbineReport", "args": [{"D": 10, "rated": 1e9, "cutIn": 0, "cutOut": 50, "cp": 16 / 27, "eta": 1, "rho": 1.225}, {"vmean": 7, "k": 2}]}])[0]
    return result("holds" if ok else "counterexample", {"rayleigh": out[0], "k1.6": out[1], "betz_refusal": out[2].get("error"), "nrel_rated": vr, "z_vs_published": z},
                  "mutation: Cp exactly at the Betz limit must be accepted", "error" not in at)


@attack("W02", "wind: Jensen and site engine", "mean power exceeds power at the mean wind below rated, and the site's annual energy matches an independent integration", "holds", needs_node=True)
def w02(seed):
    rng = np.random.default_rng(seed)
    t = {"D": 126, "rated": 5e6, "cutIn": 3, "cutOut": 25, "cp": 0.482, "eta": 0.944, "rho": 1.225}
    vm, k = float(rng.uniform(5, 9)), float(rng.uniform(1.6, 2.6))
    js = node([{"lib": "labs2", "fn": "turbineReport", "args": [t, {"vmean": vm, "k": k}]}])[0]
    A = math.pi * 63 ** 2; c = vm / math.gamma(1 + 1 / k)
    v = np.linspace(0, 40, 400001)
    P = np.where((v >= 3) & (v < 25), np.minimum(5e6, 0.5 * 1.225 * A * v ** 3 * 0.482 * 0.944), 0)
    mp = float(np.trapezoid(P * weibull_pdf(v, k, c), v))
    ok = abs(js["meanPower"] - mp) / mp < 1e-3 and js["jensenRatio"] > 1
    # mutation: a linear power curve (no cubic) shows no Jensen gain beyond cut-in effects; detector must see the ratio change
    lin = float(np.trapezoid(np.where(v > 0, v, 0) * weibull_pdf(v, k, c), v)) / vm
    return result("holds" if ok else "counterexample", {"vmean": vm, "k": k, "js_mean_power": js["meanPower"], "python_mean_power": mp, "jensen_ratio": js["jensenRatio"]},
                  "mutation: for a linear response E[v]/v_mean must be 1", abs(lin - 1) < 1e-3)


@attack("W03", "wind: tail statements", "P90 of annual energy depends on the declared shape of the input uncertainty while the mean does not, at equal variances", "holds", needs_node=True)
def w03(seed):
    t = {"D": 126, "rated": 5e6, "cutIn": 3, "cutOut": 25, "cp": 0.482, "eta": 0.944, "rho": 1.225}
    mc = node([{"lib": "labs2", "fn": "turbineMC", "args": [t, {"vmean": 7.5, "k": 2}, {"vmean": 0.08, "k": 0.0, "cp": 0.0, "rho": 0.0}, ["normal", "twopoint"], 3000, int(seed % 2**31)]}])[0]
    n, tp = mc
    mean_spread = abs(n["mean"] - tp["mean"]) / n["sd"]; p90_spread = abs(n["p90"] - tp["p90"]) / n["sd"]
    ok = p90_spread > 0.1 and p90_spread > 3 * mean_spread
    return result("holds" if ok else "counterexample", {"mean_spread_sigma": mean_spread, "p90_spread_sigma": p90_spread},
                  "mutation: with zero declared uncertainty both laws must give the same P90",
                  (lambda z: abs(z[0]["p90"] - z[1]["p90"]) < 1e-6)(node([{"lib": "labs2", "fn": "turbineMC", "args": [t, {"vmean": 7.5, "k": 2}, {"vmean": 0, "k": 0, "cp": 0, "rho": 0}, ["normal", "twopoint"], 50, 1]}])[0]))


# ---------------------------------------------------------------- FUEL
@attack("V01", "fuel: road-load engine", "the site's fuel model matches an independent implementation, EPA coast-down units convert exactly, and consumption has an interior minimum", "holds", needs_node=True)
def v01(seed):
    rng = np.random.default_rng(seed)
    p = {"mode": "phys", "m": float(rng.uniform(1000, 2500)), "crr": float(rng.uniform(0.007, 0.014)), "cda": float(rng.uniform(0.5, 0.9)), "rho": 1.2,
         "etaDt": 0.9, "e": float(rng.uniform(0.28, 0.36)), "P0": float(rng.uniform(2500, 6000)), "paux": 300, "lhv": 32.0, "grade": 0}
    epa = {"mode": "epa", "A": 30.0, "B": 0.2, "C": 0.02, "m": 1500, "etaDt": 0.9, "e": 0.3, "P0": 4000, "paux": 300, "lhv": 32.0, "grade": 0, "rho": 1.2}
    out = node([{"lib": "labs2", "fn": "fuelPer100", "args": [v, p]} for v in (15.0, 25.0, 35.0)] + [{"lib": "labs2", "fn": "roadLoad", "args": [60 * 0.44704, epa]},
                {"lib": "labs2", "fn": "fuelReport", "args": [p, 90]}])
    py = [(p["P0"] + ((p["m"] * 9.80665 * p["crr"] + 0.5 * p["rho"] * p["cda"] * v * v) * v / p["etaDt"] + p["paux"]) / p["e"]) / (p["lhv"] * 1e6) * 1e5 / v for v in (15.0, 25.0, 35.0)]
    epa_N = (30 + 0.2 * 60 + 0.02 * 3600) * 4.4482216152605
    best = out[4]["best"]["kmh"]
    ok = all(abs(a - b) < 1e-12 * b for a, b in zip(out[:3], py)) and abs(out[3] - epa_N) < 1e-9 and 20 < best < 160
    # mutation: with zero base power and zero rolling resistance, L/100 km grows monotonically from the lowest speed
    p2 = dict(p, P0=0.0, paux=0.0, crr=0.0)
    mono = node([{"lib": "labs2", "fn": "fuelReport", "args": [p2, 90]}])[0]["best"]["kmh"] == 20
    return result("holds" if ok else "counterexample", {"js": out[:3], "python": py, "epa_force_N": out[3], "best_speed_kmh": best},
                  "mutation: without base power and rolling resistance the optimum must move to the lowest speed", mono)


@attack("V02", "fuel: retired CHI prediction 6 -> 9 L/100 km", "a single anchor reproduces consumption at another speed (72 -> 108 km/h)", "sharpened", needs_node=True)
def v02(seed):
    rng = np.random.default_rng(seed)
    errs = []
    for _ in range(50):
        p = dict(CAR); p["cda"] *= rng.uniform(0.8, 1.2); p["crr"] *= rng.uniform(0.8, 1.2); p["P0"] *= rng.uniform(0.6, 1.4); p["e"] *= rng.uniform(0.9, 1.1)
        L = lambda v: car_rate(v, p) * 1e5 / v
        chi_pred = L(20) * 30 / 20
        errs.append((chi_pred - L(30)) / L(30))
    errs = np.array(errs)
    # at 72 -> 108 km/h the channel is often close; at 36 -> 144 km/h it is not
    far = []
    for _ in range(50):
        p = dict(CAR); p["cda"] *= rng.uniform(0.8, 1.2); p["P0"] *= rng.uniform(0.6, 1.4)
        L = lambda v: car_rate(v, p) * 1e5 / v
        far.append((L(20) * 10 / 20 - L(10)) / L(10))
    far = np.array(far)
    observed = "sharpened" if np.median(np.abs(errs)) < 0.1 and np.median(np.abs(far)) > 0.3 else "holds"
    js = node([{"lib": "labs2", "fn": "chiChannel", "args": ["car", {"anchors": [20], "predict": [30], "noise": 0, "seed": 1}]}])[0]
    return result(observed, {"median_abs_error_72_to_108": float(np.median(np.abs(errs))), "max_abs_error_72_to_108": float(np.max(np.abs(errs))),
                             "median_abs_error_72_to_36": float(np.median(np.abs(far))), "js_error_72_to_108_default": js["predictions"][0]["err"],
                             "statement": "the 6 -> 9 L/100 km agreement is a near-anchor interpolation that holds for many declared vehicles; it does not transport to low speed, density, or grade"},
                  "control: with anchor equal to the prediction point the error must be 0", abs(L(20) * 20 / 20 - L(20)) < 1e-15)


# ---------------------------------------------------------------- compare statement
@attack("E07", "RG-calc compare", "compare reports z against published values, refuses unit mismatches, and treats exact references exactly", "holds", seeded=False, needs_node=True)
def e07(seed):
    progs = [
        "input T = 293.15 ± 0.3 [K]\nconst R = 8.314462618 [J/K/mol]\nconst Mm = 0.0289647 [kg/mol]\nc = sqrt(1.4*R*T/Mm)\ncompare c with 343.2 ± 0.2 [m/s]",
        "input a = 1.00000261 ± 0.00001 [au]\ninput P = 365.256363004 ± 0.000001 [d]\nGM = 4*pi^2*a^3/P^2\ncompare GM with 1.3271284e20 ± 1e14 [m^3/s^2]",
        "input lat1 = 50.0755 ± 0.0001 [deg]\ninput lon1 = 14.4378 ± 0.0001 [deg]\ninput lat2 = 49.1951 ± 0.0001 [deg]\ninput lon2 = 16.6068 ± 0.0001 [deg]\nconst R = 6371.0088 [km]\nh = sin((lat2-lat1)/2)^2 + cos(lat1)*cos(lat2)*sin((lon2-lon1)/2)^2\ncompare 2*R*asin(sqrt(h)) with 184.7515 ± 0.001 [km]",
        "input x = 2 ± 0.1 [m]\ncompare x with 2 [s]",
        "const a = 3 [m]\ncompare a with 300 [cm]",
    ]
    o = [r[-1] for r in node([{"lib": "calc", "src": s} for s in progs])]
    # independent reference for the sphere-vs-ellipsoid case
    hv = hav(CITIES["Prague"], CITIES["Brno"])
    ok = (o[0]["verdict"] == "CONSISTENT" and o[1]["verdict"] == "CONSISTENT" and o[2]["verdict"] == "INCONSISTENT"
          and abs(o[2]["value"] / 1000 - hv) < 1e-6 and o[3]["kind"] == "error" and o[4]["verdict"] == "CONSISTENT")
    return result("holds" if ok else "counterexample", {"verdicts": [x.get("verdict", x.get("msg")) for x in o], "sphere_km": o[2]["value"] / 1000, "z_sphere": o[2]["z"]},
                  "mutation: 3 m against 301 cm with no declared uncertainty must be inconsistent",
                  node([{"lib": "calc", "src": "const a = 3 [m]\ncompare a with 301 [cm]"}])[0][-1]["verdict"] == "INCONSISTENT")
