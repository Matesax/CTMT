"""RG hostile battery runner.

python run_all.py                 # all modules, all seeds
python run_all.py --only F01 U03  # selected modules
python run_all.py --seeds 1 42    # override seeds

Writes results/rg_attack_results.json (every witness, seed, mutation result, environment, source SHA-256)
and results/ladder_placement.md (the holding structure placed on the Theorem Ladder).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import sys
import time
import traceback

import numpy as np

import common
from common import REGISTRY, SEEDS, node_available
import a_legacy, a_engine, a_uncertainty, a_forgetting, a_geometry, a_depth_duration  # noqa: F401  (registration)

HERE = os.path.dirname(os.path.abspath(__file__))


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--seeds", nargs="*", type=int)
    args = ap.parse_args()
    seeds = args.seeds or SEEDS
    have_node = node_available()
    records, t0 = [], time.time()
    for a in REGISTRY:
        if args.only and a.id not in args.only:
            continue
        rec = {"id": a.id, "rung": a.rung, "target": a.target, "expect": a.expect, "runs": []}
        if a.needs_node and not have_node:
            rec["status"] = "SKIPPED (node not found; install Node.js >= 18 to attack the site engine)"
            records.append(rec); print(f"{a.id:4s} SKIPPED  {a.target[:80]}"); continue
        ok = True
        for s in (seeds if a.seeded else [None]):
            try:
                r = a.fn(s)
            except Exception as e:  # an exception is a failed attack, never a pass
                r = {"observed": "error", "evidence": {"exception": repr(e), "trace": traceback.format_exc()[-1500:]},
                     "mutation": "", "mutation_detected": False}
            r["seed"] = s
            r["registered_outcome_seen"] = r["observed"] == a.expect
            ok &= r["registered_outcome_seen"] and r["mutation_detected"]
            rec["runs"].append(r)
        rec["status"] = "PASS" if ok else "FAIL"
        records.append(rec)
        print(f"{a.id:4s} {rec['status']:4s}  [{a.expect:14s}] {a.rung[:38]:38s} {a.target[:70]}")
    files = [os.path.join(HERE, f) for f in sorted(os.listdir(HERE)) if f.endswith(".py")]
    files += [os.path.join(HERE, "engine", f) for f in sorted(os.listdir(os.path.join(HERE, "engine")))]
    env = {"python": sys.version, "numpy": np.__version__, "platform": platform.platform(), "node": have_node,
           "seeds": seeds, "seconds": round(time.time() - t0, 1),
           "sha256": {os.path.relpath(f, HERE): sha(f) for f in files}}
    os.makedirs(os.path.join(HERE, "results"), exist_ok=True)
    out = os.path.join(HERE, "results", "rg_attack_results.json")
    json.dump({"environment": env, "modules": records}, open(out, "w"), indent=1, default=str)
    n_pass = sum(r["status"] == "PASS" for r in records)
    print(f"\n{n_pass}/{len(records)} modules registered-and-mutation-detected on seeds {seeds}  ({env['seconds']} s)")
    by = {}
    for r in records:
        by.setdefault(r["expect"], []).append(r["id"])
    for k, v in by.items():
        print(f"  {k:14s} {', '.join(v)}")
    return 0 if n_pass == len(records) else 1


if __name__ == "__main__":
    sys.exit(main())
