"""Common machinery for the RG hostile battery.

Rules (inherited from the Forgetting Ladder battery and tightened):
  * every module registers a TARGET and the OUTCOME it expects before it runs:
      holds          the claim survives the attack
      counterexample the claim is broken by an explicit witness
      sharpened      the claim survives only with an added, stated boundary
      open           the attack shows the rung cannot be closed with what is declared
  * every module must also run a MUTATION (or control) that a working test is required to detect;
    a test that cannot fail does not count;
  * a module PASSES only if the registered outcome is observed on every seed AND the mutation is detected;
  * seeds are fixed and recorded; exact arithmetic (fractions.Fraction, Python ints) is used wherever the
    operator allows it.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from dataclasses import dataclass, field
from typing import Any, Callable

SEEDS = [20261011, 1, 42, 777, 2026]
HERE = os.path.dirname(os.path.abspath(__file__))
HARNESS = os.path.join(HERE, "engine", "harness.js")


@dataclass
class Attack:
    id: str
    rung: str
    target: str
    expect: str            # holds | counterexample | sharpened | open
    fn: Callable[[int], dict]
    seeded: bool = True
    needs_node: bool = False


REGISTRY: list[Attack] = []


def attack(id: str, rung: str, target: str, expect: str, seeded: bool = True, needs_node: bool = False):
    assert expect in {"holds", "counterexample", "sharpened", "open"}, expect

    def deco(fn):
        REGISTRY.append(Attack(id, rung, target, expect, fn, seeded, needs_node))
        return fn
    return deco


def result(observed: str, evidence: dict[str, Any], mutation: str, detected: bool) -> dict:
    """observed: the outcome actually found on this seed."""
    return {"observed": observed, "evidence": evidence, "mutation": mutation, "mutation_detected": bool(detected)}


def node_available() -> bool:
    return shutil.which("node") is not None


def node(calls: list[dict]) -> list:
    """Run the site's own JS engine on a list of calls."""
    proc = subprocess.run(["node", HARNESS], input=json.dumps({"calls": calls}), capture_output=True, text=True, timeout=600)
    if proc.returncode != 0:
        raise RuntimeError("node harness failed: " + proc.stderr[-2000:])
    return json.loads(proc.stdout)


def jnum(x):
    """Decode harness numbers (Infinity / NaN arrive as strings)."""
    if isinstance(x, str):
        return {"Infinity": float("inf"), "-Infinity": float("-inf"), "NaN": float("nan")}[x]
    return x
