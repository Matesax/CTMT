"""Attacks on the site's own RG-calc engine (the JS that the page runs, executed through node)."""
from __future__ import annotations

import math
import random

import numpy as np

from common import attack, jnum, node, result

FUNCS = ["sin", "cos", "exp", "atan", "tanh", "sqrt_pos", "log_pos"]


def rand_expr(rng: random.Random, depth: int, names):
    if depth == 0 or rng.random() < 0.25:
        return rng.choice(names) if rng.random() < 0.8 else f"{rng.uniform(0.5, 2):.3f}"
    k = rng.random()
    if k < 0.55:
        op = rng.choice(["+", "-", "*", "/"])
        a, b = rand_expr(rng, depth - 1, names), rand_expr(rng, depth - 1, names)
        if op == "/":
            b = f"(2.5 + ({b})^2)"
        return f"({a} {op} {b})"
    if k < 0.7:
        return f"({rand_expr(rng, depth - 1, names)})^2"
    f = rng.choice(FUNCS)
    a = rand_expr(rng, depth - 1, names)
    if f == "sqrt_pos":
        return f"sqrt(1 + ({a})^2)"
    if f == "log_pos":
        return f"log(1 + ({a})^2)"
    if f == "exp":
        return f"exp(0.3*({a}))"
    return f"{f}({a})"


def py_eval(expr: str, env: dict, mp=False):
    e = expr.replace("^", "**")
    if mp:
        import mpmath
        ns = {"sin": mpmath.sin, "cos": mpmath.cos, "exp": mpmath.exp, "atan": mpmath.atan, "tanh": mpmath.tanh,
              "sqrt": mpmath.sqrt, "log": mpmath.log, "mpf": mpmath.mpf}
        e = __import__("re").sub(r"(?<![\w.])(\d+\.\d+)", r"mpf('\1')", e)
    else:
        ns = {"sin": math.sin, "cos": math.cos, "exp": math.exp, "atan": math.atan, "tanh": math.tanh,
              "sqrt": math.sqrt, "log": math.log}
    ns.update(env)
    return eval(e, {"__builtins__": {}}, ns)


def mp_grad(expr, means, names):
    """Reference gradient by 40-digit central differences (independent of the engine's forward mode)."""
    import mpmath
    mpmath.mp.dps = 40
    base = {n: mpmath.mpf(repr(means[n])) for n in names}
    g = []
    for n in names:
        h = mpmath.mpf("1e-15")
        ep, em = dict(base), dict(base); ep[n] += h; em[n] -= h
        g.append(float((py_eval(expr, ep, True) - py_eval(expr, em, True)) / (2 * h)))
    return np.array(g)


@attack("E01", "RG-calc engine", "linear sigma equals sqrt(g^T Sigma g) for random expressions with correlated inputs", "holds", needs_node=True)
def e01(seed):
    rng = random.Random(seed)
    names = ["x", "y", "z"]
    means = {n: rng.uniform(-1.5, 1.5) for n in names}
    sig = {n: rng.uniform(0.01, 0.2) for n in names}
    rho_xy, rho_yz = rng.uniform(-0.7, 0.7), rng.uniform(-0.5, 0.5)
    exprs = [rand_expr(rng, 4, names) for _ in range(40)]
    head = "".join(f"input {n} = {means[n]!r} ± {sig[n]!r}\n" for n in names)
    head += f"correlate x, y = {rho_xy!r}\ncorrelate y, z = {rho_yz!r}\n"
    src = head + "".join(f"print {e}\n" for e in exprs)
    out = node([{"lib": "calc", "src": src}])[0]
    C = np.diag([sig[n] ** 2 for n in names])
    C[0, 1] = C[1, 0] = rho_xy * sig["x"] * sig["y"]
    C[1, 2] = C[2, 1] = rho_yz * sig["y"] * sig["z"]
    worst, worst_mut = 0.0, 0.0
    for e, o in zip(exprs, out):
        js_val, js_sig = jnum(o["parts"][0]["value"]), jnum(o["parts"][0]["sigma"])
        g = mp_grad(e, means, names)
        ref = math.sqrt(max(g @ C @ g, 0))
        mut = math.sqrt(max(g @ np.diag(np.diag(C)) @ g, 0))    # mutation: correlations dropped
        val_err = abs(js_val - py_eval(e, means)) / max(1, abs(js_val))
        worst = max(worst, val_err, abs(js_sig - ref) / max(ref, 1e-300))
        if ref > 1e-6:
            worst_mut = max(worst_mut, abs(js_sig - mut) / ref)
    return result("holds" if worst < 1e-9 else "counterexample",
                  {"n_expressions": len(exprs), "worst_relative_error": worst, "rho_xy": rho_xy, "rho_yz": rho_yz},
                  "mutation: a reference that drops the declared correlations must disagree", worst_mut > 1e-3)


@attack("E02", "RG-calc engine", "dimension algebra rejects ill-typed programs and types well-typed ones", "holds", seeded=False, needs_node=True)
def e02(seed):
    bad = ["input L = 1 ± 0 [m]\ninput t = 1 ± 0 [s]\ny = L + t",
           "input L = 1 ± 0.1 [m]\ny = sin(L)",
           "input t = 1 ± 0.1 [s]\ny = exp(t)",
           "input L = 2 ± 0.1 [m]\ninput k = 2 ± 0.1\ny = L^k",
           "input L = 1 ± 0.1 [m]\ninput t = 1 ± 0.1 [s]\ny = atan2(L, t)",
           "input x = 1 ± 0.1 [furlong]"]
    good = {"input L = 3 ± 0.1 [m]\ny = sqrt(L^2)\nprint y": "m",
            "input L = 3 ± 0.1 [m]\ninput H = 4 ± 0.1 [m]\nprint atan2(L, H)": "",
            "input v = 3e4 ± 100 [m/s]\ninput a = 1.496e11 ± 1e9 [m]\nconst G = 6.6743e-11 [m^3 kg^-1 s^-2]\nprint v^2*a/G": "kg",
            "input T = 293.15 ± 0.1 [K]\nconst kB = 1.380649e-23 [J/K]\nconst m = 4.8e-26 [kg]\nprint sqrt(1.4*kB*T/m)": "m s^-1",
            "input d = 10 ± 0.1 [km]\ninput t = 2 ± 0.01 [min]\nprint d/t": "m s^-1"}
    outs = node([{"lib": "calc", "src": s} for s in bad] + [{"lib": "calc", "src": s} for s in good])
    rejected = [o[-1]["kind"] == "error" for o in outs[:len(bad)]]
    typed = [o[-1].get("parts", [{}])[0].get("dims") == d for o, d in zip(outs[len(bad):], good.values())]
    # mutation: unit scaling must be applied (10 km / 2 min = 83.33 m/s), otherwise dims-only checking would pass
    kmmin = outs[-1][-1]["parts"][0]["value"]
    return result("holds" if all(rejected) and all(typed) else "counterexample",
                  {"rejected": rejected, "typed": typed, "messages": [o[-1].get("msg") for o in outs[:len(bad)]], "10km/2min": kmmin},
                  "mutation: prefix scaling must be applied (10 km / 2 min = 83.333 m/s)", abs(kmmin - 83.3333333) < 1e-5)


@attack("E03", "RG-calc certificates", "certificate canaries: single family, unresolved sample size, late declaration, domain loss", "holds", seeded=False, needs_node=True)
def e03(seed):
    progs = {
        "single_family": "input x = 1 ± 0.1\ncertify 3*x",
        "unresolved": "input x = 1 ± 0.1\nfamily normal, uniform\nsamples 500\ncertify 3*x",
        "late_declaration": "input x = 1 ± 0.1\nprint x\nfamily normal, uniform\ncertify 3*x",
        "domain_loss": "input u = 0.5 ± 0.4\nfamily normal, uniform\ncertify sqrt(u)",
        "linear_forced": "input x = 1 ± 0.1\ninput y = 2 ± 0.3\nfamily normal, uniform, laplace\nsamples 40000\ncertify 3*x - y",
    }
    outs = dict(zip(progs, node([{"lib": "calc", "src": s} for s in progs.values()])))
    v = lambda k, i=0: [o for o in outs[k] if o["kind"] == "certify"][-1]["statements"][i]["verdict"]
    got = {k: v(k) for k in progs}
    want = {"single_family": "UNCERTIFIED", "unresolved": "UNRESOLVED", "late_declaration": "CONDITIONAL",
            "domain_loss": "CONDITIONAL", "linear_forced": "FORCED"}
    # mutation: the same linear output's 95% interval must NOT be forced (tails differ across laws)
    interval = v("linear_forced", 1)
    return result("holds" if got == want else "counterexample", {"verdicts": got, "linear_95_interval": interval},
                  "mutation: the 95% interval of the same output must not be FORCED", interval != "FORCED")


@attack("E04", "RG-calc walls", "linearization is flagged at a fold (b^2 at b=0) and trusted on a regular stratum", "holds", seeded=False, needs_node=True)
def e04(seed):
    outs = node([{"lib": "calc", "src": "input b = 0 ± 0.1\nfamily normal, uniform\ncertify b^2"},
                 {"lib": "calc", "src": "input b = 1 ± 0.01\nfamily normal, uniform\ncertify b^2"}])
    wall, reg = outs[0][-1]["status"], outs[1][-1]["status"]
    return result("holds" if wall == "WALL" else "counterexample", {"b=0": wall, "b=1": reg, "reasons_b0": outs[0][-1]["reasons"]},
                  "mutation: the regular point must not be flagged", reg == "REGULAR")


@attack("E05", "RG-calc Monte Carlo", "seeded sampling is reproducible and seed-sensitive", "holds", needs_node=True)
def e05(seed):
    s = f"input x = 1 ± 0.2\nfamily normal, laplace\nseed {seed}\ncertify exp(x)"
    s2 = f"input x = 1 ± 0.2\nfamily normal, laplace\nseed {seed + 1}\ncertify exp(x)"
    a, b, c = node([{"lib": "calc", "src": s}, {"lib": "calc", "src": s}, {"lib": "calc", "src": s2}])
    same = a[-1]["mc"] == b[-1]["mc"]
    differ = a[-1]["mc"] != c[-1]["mc"]
    return result("holds" if same else "counterexample", {"mean_seed": a[-1]["mc"][0]["mean"], "mean_seed+1": c[-1]["mc"][0]["mean"]},
                  "mutation: a different seed must change the sample", differ)


@attack("E06", "RG-calc correlations", "a non-positive-definite correlation declaration is refused", "holds", seeded=False, needs_node=True)
def e06(seed):
    bad = "input a = 0 ± 1\ninput b = 0 ± 1\ninput c = 0 ± 1\ncorrelate a, b = 0.9\ncorrelate b, c = 0.9\ncorrelate a, c = -0.9\nfamily normal, uniform\ncertify a+b+c"
    good = bad.replace("a, c = -0.9", "a, c = 0.8")
    o1, o2 = node([{"lib": "calc", "src": bad}, {"lib": "calc", "src": good}])
    refused = o1[-1]["kind"] == "error" and "positive definite" in o1[-1]["msg"]
    return result("holds" if refused else "counterexample", {"bad": o1[-1], "good_status": o2[-1].get("status")},
                  "mutation: a positive-definite declaration must run", o2[-1]["kind"] == "certify")
