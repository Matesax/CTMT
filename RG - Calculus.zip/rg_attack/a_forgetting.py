"""Attacks on the Forgetting Ladder (R33-R43, R47) and the chaos frontier law."""
from __future__ import annotations

import math
from fractions import Fraction as Fr

import numpy as np

from common import attack, node, result


# ------------------------------------------------------------------ exact tent transfer operator
def P(f):
    n = len(f)
    return [(f[j >> 1] + f[(2 * n - j - 1) >> 1]) / 2 for j in range(n)]


def P_identity(f):           # mutation: a non-expanding "dynamics"
    return list(f)


def tv(f, g):
    return sum(abs(a - b) for a, b in zip(f, g)) / (2 * len(f))


def var(h):
    return sum(abs(h[j + 1] - h[j]) for j in range(len(h) - 1))


def normalize(f):
    s = sum(f) / len(f)
    return [x / s for x in f]


def decl(kind, L, rng):
    n = 1 << L
    if kind == "random":
        return normalize([Fr(int(rng.integers(0, 1000)) + 1, 1) for _ in range(n)])
    if kind == "spiky":
        f = [Fr(1, 1000)] * n
        for j in rng.choice(n, 5, replace=False):
            f[int(j)] = Fr(int(rng.integers(50, 500)), 1)
        return normalize(f)
    if kind == "sparse":
        k = int(rng.integers(1, L)); w = n >> k; s = int(rng.integers(0, n - w))
        return normalize([Fr(1) if s <= j < s + w else Fr(0) for j in range(n)])
    if kind == "monotone":
        return normalize([Fr(j + 1) for j in range(n)])
    if kind == "oscillating":
        p = int(rng.integers(2, 40))
        return normalize([Fr(3 + (1 if (j * p // n) % 2 else -1), 1) for j in range(n)])
    raise ValueError(kind)


def run_pair(f, g, nmax, op=P):
    V = var([a - b for a, b in zip(f, g)])
    worst = Fr(0)
    for n in range(nmax + 1):
        bound = Fr(V, 2 ** (n + 2))
        t = tv(f, g)
        if bound > 0:
            worst = max(worst, t / bound)
        f, g = op(f), op(g)
    return worst


@attack("F01", "R38 (BV lock, sharp)", "TV(T^n f, T^n g) <= 2^-(n+2) Var(f-g) for all BV declarations, equality attained", "holds")
def f01(seed):
    rng = np.random.default_rng(seed)
    L, nmax = 9, 12
    kinds = ["random", "spiky", "sparse", "monotone", "oscillating"]
    worst = Fr(0)
    for a in kinds:
        for b in kinds:
            worst = max(worst, run_pair(decl(a, L, rng), decl(b, L, rng), nmax))
    # adversarial hill-climb in floats, re-verified exactly
    fz = rng.random(1 << 7) + 0.01
    best = 0.0
    def ratio_float(f):
        f = f / f.mean(); g = np.ones_like(f); V = np.abs(np.diff(f - g)).sum(); r = 0
        for n in range(8):
            if V > 0: r = max(r, 0.5 * np.abs(f - g).mean() / (V * 2.0 ** -(n + 2)))
            f = 0.5 * (f[np.arange(len(f)) >> 1] + f[(2 * len(f) - np.arange(len(f)) - 1) >> 1]); g = g
        return r
    for _ in range(300):
        cand = np.abs(fz + 0.3 * rng.normal(size=fz.size) * (rng.random(fz.size) < 0.1)) + 1e-3
        rc = ratio_float(cand)
        if rc > best: best, fz = rc, cand
    exact_adv = run_pair(normalize([Fr(float(x)) for x in fz]), [Fr(1)] * fz.size, 8)
    worst = max(worst, exact_adv)
    # equality witnesses f = 2^(m+1) 1[0, 2^-(m+1)] at n = m
    eq = []
    for m in range(0, 8):
        n_cells = 1 << 10
        f = [Fr(2 ** (m + 1)) if j < (n_cells >> (m + 1)) else Fr(0) for j in range(n_cells)]
        g = [Fr(1)] * n_cells
        V = var([a - b for a, b in zip(f, g)])
        for _ in range(m): f = P(f)
        eq.append(tv(f, g) == Fr(V, 2 ** (m + 2)))
    # the overclaim 2^-(n+3) is refuted by the witness
    overclaim_refuted = all(eq)
    ok = worst <= 1 and all(eq)
    # mutation: identity "dynamics" must violate the bound
    rng2 = np.random.default_rng(seed + 1)
    mut = run_pair(decl("sparse", 8, rng2), [Fr(1)] * 256, 10, op=P_identity) > 1
    return result("holds" if ok else "counterexample",
                  {"worst_ratio_exact": float(worst), "adversarial_ratio_exact": float(exact_adv), "equality_witnesses_exact": eq,
                   "overclaim_2^-(n+3)_refuted": overclaim_refuted},
                  "mutation: identity dynamics must violate the bound", mut)


@attack("F02", "R36 (no uniform forgetting) + Cor. 1 (exact frontier)", "spike family keeps TV = 1 - 2^(n-k); frontier n* = ceil(log2(V/tau)) - 2 is exact for V = 2^k, tau = 1/2", "holds", seeded=False)
def f02(seed):
    L = 14
    ok_closed, ok_frontier = True, True
    for k in range(1, 15):
        n_cells = 1 << L
        f = [Fr(2 ** k) if j < (n_cells >> k) else Fr(0) for j in range(n_cells)]
        g = [Fr(1)] * n_cells
        V = var([a - b for a, b in zip(f, g)])
        hist = []
        for n in range(0, k + 1):
            hist.append(tv(f, g))
            if n <= k and hist[-1] != 1 - Fr(2 ** n, 2 ** k):
                ok_closed = False
            f = P(f)
        if k >= 2:
            nstar = math.ceil(math.log2(V / Fr(1, 2))) - 2
            # witness of variation 2^k is spike k: TV at n*-1 must exceed 1/2 and the bound at n* must be <= 1/2
            ok_frontier &= (nstar - 1 < 0 or hist[nstar - 1] > Fr(1, 2)) and Fr(V, 2 ** (nstar + 2)) <= Fr(1, 2)
    # mutation: claiming a uniform frontier over the unbounded family; sup_k TV_n must be ~1 at fixed n
    sup_tv_n3 = max(1 - Fr(2 ** 3, 2 ** k) for k in range(4, 30))
    return result("holds" if ok_closed and ok_frontier else "counterexample",
                  {"closed_form_exact": ok_closed, "frontier_exact": ok_frontier, "sup_k_TV_at_n=3": float(sup_tv_n3)},
                  "mutation: a uniform frontier over the unbounded spike family must fail (sup TV at n=3 near 1)", sup_tv_n3 > 0.99)


@attack("F03", "R38 site engine", "the site's float tent lab agrees with exact rationals", "holds", seeded=False, needs_node=True)
def f03(seed):
    js = node([{"lib": "labs", "fn": "tentLab", "args": ["spike", "uniform", 10, 12, 7]},
               {"lib": "labs", "fn": "tentLab", "args": ["witness", "uniform", 10, 10, 5]}])
    worst, worst_shift = 0.0, 0.0
    for res, (k, kind) in zip(js, [(7, "spike"), (5, "witness")]):
        n_cells = 1 << 10
        w = 2 ** k if kind == "spike" else 2 ** (k + 1)
        cut = n_cells >> k if kind == "spike" else n_cells >> (k + 1)
        f = [Fr(w) if j < cut else Fr(0) for j in range(n_cells)]; g = [Fr(1)] * n_cells
        exact = []
        for _ in res["rows"]:
            exact.append(float(tv(f, g))); f = P(f)
        for i, row in enumerate(res["rows"]):
            worst = max(worst, abs(row["tv"] - exact[i]))
            if i + 1 < len(exact):
                worst_shift = max(worst_shift, abs(row["tv"] - exact[i + 1]))
    return result("holds" if worst < 1e-12 else "counterexample", {"max_abs_diff": worst, "max_abs_diff_shifted_reference": worst_shift},
                  "mutation: the reference shifted by one step must disagree", worst_shift > 1e-3)


# ------------------------------------------------------------------ cat map lattice (exact integers)
def cat_run(N, b, blocks, nmax, mutate=False):
    def mp(x, y):
        return ((2 * x) % N, (2 * y) % N) if mutate else ((2 * x + y) % N, (x + y) % N)
    (bx1, by1), (bx2, by2) = blocks
    mu = {(bx1 * b + i, by1 * b + j): 1 for i in range(b) for j in range(b)}
    nu = {(bx2 * b + i, by2 * b + j): 1 for i in range(b) for j in range(b)}
    tot = b * b; K = N // b
    full, obs, period = [], [], None
    mu0, nu0 = dict(mu), dict(nu)
    for n in range(nmax + 1):
        keys = set(mu) | set(nu)
        full.append(Fr(sum(abs(mu.get(k, 0) - nu.get(k, 0)) for k in keys), 2 * tot))
        om, on = {}, {}
        for (x, y), w in mu.items(): om[(x // b, y // b)] = om.get((x // b, y // b), 0) + w
        for (x, y), w in nu.items(): on[(x // b, y // b)] = on.get((x // b, y // b), 0) + w
        ks = set(om) | set(on)
        obs.append(Fr(sum(abs(om.get(k, 0) - on.get(k, 0)) for k in ks), 2 * tot))
        m2, n2 = {}, {}
        for k, w in mu.items(): kk = mp(*k); m2[kk] = m2.get(kk, 0) + w
        for k, w in nu.items(): kk = mp(*k); n2[kk] = n2.get(kk, 0) + w
        mu, nu = m2, n2
        if period is None and not mutate and mu == mu0 and nu == nu0:
            period = n + 1
    return full, obs, period


@attack("F04", "R33/R34/R35", "bijections keep full-state TV; observed TV migrates through fibres, is non-monotone, and recurs at the period", "holds", needs_node=True)
def f04(seed):
    rng = np.random.default_rng(seed)
    N, b = 64, 8
    i1, i2 = rng.choice(64, 2, replace=False)
    blocks = [(int(i1) // 8, int(i1) % 8), (int(i2) // 8, int(i2) % 8)]
    full, obs, period = cat_run(N, b, blocks, 100)
    rigid = all(t == 1 for t in full)
    nonmono = any(obs[i + 1] > obs[i] for i in range(len(obs) - 1))
    recur = period is not None and obs[period] == obs[0]
    fullm, _, _ = cat_run(N, b, blocks, 10, mutate=True)
    js = node([{"lib": "labs", "fn": "catLab", "args": [64, 8, 50, False]}])[0]
    jsfull, _, _ = cat_run(N, b, [(0, 0), (1, 0)], 50)
    _, jsobs, _ = cat_run(N, b, [(0, 0), (1, 0)], 50)
    js_agree = all(abs(r["observed"] - float(o)) < 1e-12 for r, o in zip(js["rows"], jsobs))
    return result("holds" if rigid and nonmono and recur and js_agree else "counterexample",
                  {"blocks": blocks, "period": period, "observed_min": float(min(obs)), "first_zero_observed": next((i for i, o in enumerate(obs) if o == 0), None),
                   "js_period": js["period"], "js_agrees_exactly": js_agree},
                  "mutation: a non-injective map (2x, 2y) must lose full-state TV", any(t < 1 for t in fullm))


# ------------------------------------------------------------------ float atomicity
@attack("F05", "R35/R47 (A07 wording)", "the float tent map is exact arithmetic, not rounding", "sharpened", needs_node=True)
def f05(seed):
    rng = np.random.default_rng(seed)
    mism_abs, mism_branch, tested = 0, 0, 0
    for e in range(1, 90):
        for x in rng.random(60) * 2.0 ** -e:
            x = float(x); exact = 2 * Fr(x) if Fr(x) < Fr(1, 2) else 2 - 2 * Fr(x)
            mism_abs += Fr(1 - abs(2 * x - 1)) != exact
            mism_branch += Fr(2 * x if x < 0.5 else 2 - 2 * x) != exact
            tested += 1
    # exactness boundary of the abs form: exact iff x in 2^-54 Z for x < 1/2
    lattice_ok = all(Fr(1 - abs(2 * x - 1)) == 2 * Fr(x) for x in (k * 2.0 ** -54 for k in rng.integers(1, 2 ** 52, 200)))
    off_fail = all(Fr(1 - abs(2 * x - 1)) != 2 * Fr(x) for x in ((2 * k + 1) * 2.0 ** -60 for k in rng.integers(1, 2 ** 20, 200)))
    js = node([{"lib": "labs", "fn": "floatTent", "args": [50000, 120, seed % 2**31, 53, f, s]} for f, s in
               [("abs", 1), ("branch", 1), ("abs", 2 ** -10), ("branch", 2 ** -10)]])
    collapse = [next((i for i, v in enumerate(z) if v == 1), None) for z in js]
    # accuracy gate R47: the empirical declaration diameter is 0 while both laws are far from the true pushforward
    observed = "sharpened" if (mism_abs > 0 and mism_branch == 0 and lattice_ok and off_fail) else "holds"
    # mutation: exact rational orbits of odd-denominator inputs never reach 0
    never_zero = True
    for q in rng.integers(3, 1000, 50):
        x = Fr(1, int(q) | 1)
        for _ in range(200):
            x = 2 * x if x < Fr(1, 2) else 2 - 2 * x
            if x == 0: never_zero = False; break
    return result(observed, {"tested_doubles": tested, "abs_form_mismatches": mism_abs, "branch_form_mismatches": mism_branch,
                             "abs_form_exact_on_2^-54_lattice": lattice_ok, "abs_form_rounds_off_lattice": off_fail,
                             "collapse_step[abs,branch,abs*2^-10,branch*2^-10]": collapse,
                             "statement": "exact for the branch form on all doubles; for 1-|2x-1| exact only on 2^-54 Z. Collapse step = dyadic depth of the declaration (capped at 55 for the abs form)"},
                  "mutation: exact rational orbits with odd denominators must never collapse", never_zero)


# ------------------------------------------------------------------ Dobrushin
@attack("F06", "R40 (Dobrushin block lock)", "rotation + local noise has one-step coefficient exactly 1; a block power contracts", "holds", needs_node=True)
def f06(seed):
    rng = np.random.default_rng(seed)
    M, shift, w = 60, int(rng.integers(1, 30)), int(rng.integers(1, 4))
    K = np.zeros((M, M))
    for i in range(M):
        for d in range(-w, w + 1): K[i, (i + shift + d) % M] += 1 / (2 * w + 1)
    dob = lambda A: max(0.5 * np.abs(A[i] - A[j]).sum() for i in range(M) for j in range(i + 1, M))
    one = dob(K); Pm, m_first = K.copy(), None; deltas = []
    for m in range(1, 200):
        d = dob(Pm); deltas.append(d)
        if m_first is None and d < 1 - 1e-12: m_first = m
        Pm = Pm @ K
    mono = all(deltas[i + 1] <= deltas[i] + 1e-12 for i in range(len(deltas) - 1))
    js = node([{"lib": "labs", "fn": "dobrushinLab", "args": [M, shift, w, 3]}])[0]
    # mutation: global mixing (epsilon-uniform) contracts in one step
    Kg = 0.9 * K + 0.1 / M
    return result("holds" if abs(one - 1) < 1e-12 and m_first is not None and mono and abs(js[0]["delta"] - 1) < 1e-12 else "counterexample",
                  {"shift": shift, "width": w, "delta_1": one, "first_contracting_block": m_first, "delta_at_first": deltas[m_first - 1] if m_first else None, "monotone": mono},
                  "mutation: an epsilon-uniform kernel must contract at m = 1", dob(Kg) < 1)


@attack("F07", "R41 (functional type)", "time averages forget every declaration at explicit rates; fixed-time laws of the same maps never forget", "holds")
def f07(seed):
    rng = np.random.default_rng(seed)
    xs = rng.random(5000)
    worst_inv = 0.0
    for n in (1, 2, 5, 11, 100, 1001):
        traj = np.array([xs if k % 2 == 0 else 1 - xs for k in range(n)]).mean(0)
        worst_inv = max(worst_inv, float(np.max(np.abs(traj - 0.5)) * 2 * n))
    eq = abs(Fr(sum(0 if k % 2 == 0 else 1 for k in range(7)), 7) - Fr(1, 2)) == Fr(1, 14)
    alpha = math.sqrt(2) - 1
    worst_rot = 0.0
    for n in (10, 100, 1000):
        avg = np.mean([np.cos(2 * np.pi * ((xs + k * alpha) % 1)) for k in range(n)], 0)
        worst_rot = max(worst_rot, float(np.max(np.abs(avg)) * n * abs(math.sin(math.pi * alpha))))
    # fixed-time law of the involution: Dirac declarations at 0.2 and 0.8 stay at TV 1 for every n
    a, b, fixed = 0.2, 0.8, True
    for n in range(100):
        fixed &= a != b
        a, b = 1 - a, 1 - b
    # chaos is not uniquely ergodic: the logistic Dirac at 3/4 has time average 3/4
    x, s_ = 0.75, 0.0
    for _ in range(1000): s_ += x; x = 4 * x * (1 - x)
    # mutation: a bound tighter by 2 (1/(4n)) must be violated at x=0, n odd
    tight_violated = abs(Fr(3, 7) - Fr(1, 2)) > Fr(1, 28)
    return result("holds" if worst_inv <= 1 + 1e-12 and eq and worst_rot <= 1 + 1e-9 and fixed and abs(s_ / 1000 - 0.75) < 1e-9 else "counterexample",
                  {"involution_ratio_max": worst_inv, "equality_at_x=0_n=7": eq, "rotation_ratio_max": worst_rot,
                   "fixed_time_TV_stays_1": fixed, "logistic_dirac_3/4_time_average": s_ / 1000},
                  "mutation: the halved bound 1/(4n) must be violated by the equality witness", tight_violated)


@attack("F08", "Chaos frontier law", "frontier slope in log(1/sigma0) is 1/lambda (logistic r=4: 1/ln 2); periodic dynamics has no frontier", "holds", needs_node=True)
def f08(seed):
    rng = np.random.default_rng(seed)
    sig = [10.0 ** -k for k in range(3, 12)]
    def frontier(r, observe_each_step=False):
        ns = []
        for s0 in sig:
            x0 = 0.3 + 0.1 * rng.random()
            x = np.clip(x0 + s0 * rng.normal(size=600), 1e-15, 1 - 1e-15)
            truth = x0
            nstar = None
            for n in range(300):
                if x.std() > 0.1: nstar = n; break
                x = r * x * (1 - x); truth = r * truth * (1 - truth)
                if observe_each_step: x = truth + s0 * rng.normal(size=x.size)     # task substitution: re-observe
            ns.append(nstar)
        return ns
    ns = frontier(4.0)
    slope = np.polyfit(np.log(1 / np.array(sig)), ns, 1)[0]
    periodic = frontier(3.5)
    js = node([{"lib": "labs", "fn": "frontierLab", "args": [4, sig, 0.1, 600, 200, seed % 2**31]}])[0]
    ok = abs(slope * math.log(2) - 1) < 0.08 and all(p is None for p in periodic) and abs(js["slope"] * math.log(2) - 1) < 0.08
    sub = frontier(4.0, observe_each_step=True)
    return result("holds" if ok else "counterexample",
                  {"slope": slope, "predicted": 1 / math.log(2), "js_slope": js["slope"], "periodic_frontier": periodic[:3]},
                  "mutation (task substitution): re-observing the state each step must remove the frontier", all(p is None for p in sub))


@attack("F09", "R43(b) (samples refute, operators lock)", "no finite-sample test certifies TV < 1/2 without a regularity class", "holds")
def f09(seed):
    rng = np.random.default_rng(seed)
    def power(M, m, trials=400):
        # collision test: Q_S (uniform on a random half) has twice the collision rate of P (uniform on M)
        def collisions(draws): return len(draws) - len(set(draws.tolist()))
        thr_samples = [collisions(rng.integers(0, M, m)) for _ in range(trials)]
        thr = np.quantile(thr_samples, 0.95)
        rej = 0
        for _ in range(trials):
            salt = int(rng.integers(0, 2 ** 31))
            half = rng.integers(0, M // 2, m) * 2 + ((salt >> 3) & 1)     # a random half (one parity class, randomized)
            rej += collisions(half) > thr
        return rej / trials
    p_big, p_small = power(2 ** 40, 500), power(64, 500)
    bound = 0.05 + 1.5 * 500 ** 2 / 2 ** 40
    return result("holds" if p_big <= bound + 0.04 else "counterexample", {"power_M=2^40": p_big, "bound": bound, "power_M=64": p_small},
                  "mutation: at M = 64 the same test must have high power", p_small > 0.9)
