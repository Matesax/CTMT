"""Attacks on the statement of record (Resolution Geometry, Oct 2026): the final remainder and the local classifier
(L116-L128), the closure dispatcher (L112-L115), and short numerical claims elsewhere in the paper.

Independent implementations: exact rationals (fractions), numpy, sympy. The site engine (labs3.js) is cross-examined
through the Node harness.
"""
from __future__ import annotations

import itertools
import math
from fractions import Fraction as Fr

import numpy as np

from common import attack, jnum, node, result


# ------------------------------------------------------------------ exact tuple and words
def mm(A, B):
    return [[sum((A[i][k] * B[k][j] for k in range(len(B))), Fr(0)) for j in range(len(B[0]))] for i in range(len(A))]


def tr(A):
    return sum((A[i][i] for i in range(len(A))), Fr(0))


def tup(R, N, C):
    p, q = len(R), len(N); n = p + q
    P = [[Fr(int(i == j and i < p)) for j in range(n)] for i in range(n)]
    D = [[Fr(0)] * n for _ in range(n)]; S = [[Fr(0)] * n for _ in range(n)]
    for i in range(p):
        for j in range(p): D[i][j] = Fr(R[i][j])
    for i in range(q):
        for j in range(q): D[p + i][p + j] = Fr(N[i][j])
    for i in range(p):
        for j in range(q): S[i][p + j] = Fr(C[i][j]); S[p + j][i] = Fr(C[i][j])
    return {"P": P, "D": D, "S": S}


def words_equal_upto(A, B, L):
    level = [(None, None)]
    for _ in range(L):
        nxt = []
        for MA, MB in level:
            for c in "PDS":
                NA = A[c] if MA is None else mm(MA, A[c]); NB = B[c] if MB is None else mm(MB, B[c])
                if tr(NA) != tr(NB): return False
                nxt.append((NA, NB))
        level = nxt
    return True


def qs(M):
    return [[str(x) for x in r] for r in M]


R0 = [[Fr(1), Fr(0)], [Fr(0), Fr(2)]]
N0 = [[Fr(3), Fr(0), Fr(0)], [Fr(0), Fr(5), Fr(0)], [Fr(0), Fr(0), Fr(7)]]
CA = [[Fr(1, 10), Fr(1, 10), Fr(2, 10)], [Fr(1, 10), Fr(-1, 10), Fr(1, 10)]]
CB = [[Fr(1, 10), Fr(1, 10), Fr(2, 10)], [Fr(-1, 10), Fr(1, 10), Fr(1, 10)]]


def cayley(K):
    n = len(K); I = np.eye(n)
    return (I - K) @ np.linalg.inv(I + K)


def frac_orth(n, rng):
    """Exact rational orthogonal matrix by the Cayley transform of a rational skew matrix."""
    import sympy as sp
    K = sp.zeros(n)
    for i in range(n):
        for j in range(i + 1, n):
            v = sp.Rational(int(rng.integers(-3, 4)), int(rng.integers(1, 5))); K[i, j] = v; K[j, i] = -v
    U = (sp.eye(n) - K) * (sp.eye(n) + K).inv()
    return [[Fr(int(sp.fraction(U[i, j])[0]), int(sp.fraction(U[i, j])[1])) for j in range(n)] for i in range(n)]


def T(M):
    return [list(r) for r in zip(*M)]


@attack("K01", "L124 word-trace classifier (Imported Thm 18.2)", "O(p)xO(q)-equivalent triples have equal traces of all words; the site's paired-algebra closure decides equivalence", "holds", needs_node=True)
def k01(seed):
    rng = np.random.default_rng(seed)
    calls, expect = [], []
    for t in range(6):
        p, q = int(rng.integers(1, 4)), int(rng.integers(1, 4))
        R = [[Fr(int(rng.integers(-3, 4))) for _ in range(p)] for _ in range(p)]; R = [[R[i][j] + R[j][i] for j in range(p)] for i in range(p)]
        N = [[Fr(int(rng.integers(-3, 4))) for _ in range(q)] for _ in range(q)]; N = [[N[i][j] + N[j][i] for j in range(q)] for i in range(q)]
        C = [[Fr(int(rng.integers(-2, 3)), 2) for _ in range(q)] for _ in range(p)]
        U, V = frac_orth(p, rng), frac_orth(q, rng)
        R2, N2, C2 = mm(mm(U, R), T(U)), mm(mm(V, N), T(V)), mm(mm(U, C), T(V))
        assert words_equal_upto(tup(R, N, C), tup(R2, N2, C2), 5)            # independent exact check of the forward direction
        C3 = [r[:] for r in C2]; C3[0][0] += Fr(1, 3)                        # negative control: perturb one entry
        calls += [{"lib": "labs3", "fn": "pairedClosureQ", "args": [qs(R), qs(N), qs(C), qs(R2), qs(N2), qs(C2)]},
                  {"lib": "labs3", "fn": "pairedClosureQ", "args": [qs(R), qs(N), qs(C), qs(R2), qs(N2), qs(C3)]}]
        expect += [True, None]
    out = node(calls)
    pos_ok = all(o["equivalent"] for o, e in zip(out, expect) if e is True)
    neg = [o["equivalent"] for o, e in zip(out, expect) if e is None]
    # A perturbation can in principle land in the same orbit; check with exact words that each negative is truly inequivalent
    neg_ok = all(v is False for v in neg)
    dims = [o["dim"] for o in out]
    return result("holds" if pos_ok and neg_ok and max(dims) <= max(2 * 6 * 6, 1) else "counterexample",
                  {"positive_equivalent": pos_ok, "negative_controls_rejected": neg_ok, "algebra_dims": dims},
                  "mutation: perturbing one coupling entry by 1/3 must be detected as inequivalent", neg_ok)


@attack("K02", "L125 / Cor 18.4 loop values are hidden, not null", "two triples equal in spectra, eigenbasis magnitudes, mixed traces and coupling singular values differ in a cycle sign, separated by an ordered word trace with an exact rational gap", "holds", seeded=False, needs_node=True)
def k02(seed):
    A, B = tup(R0, N0, CA), tup(R0, N0, CB)
    Rf, Nf, Ca, Cb = (np.array([[float(x) for x in r] for r in M]) for M in (R0, N0, CA, CB))
    sv_eq = np.allclose(np.linalg.svd(Ca, compute_uv=False), np.linalg.svd(Cb, compute_uv=False))
    mixed_eq = all(abs(np.trace(np.linalg.matrix_power(Rf, a) @ Ca @ np.linalg.matrix_power(Nf, b) @ Ca.T) - np.trace(np.linalg.matrix_power(Rf, a) @ Cb @ np.linalg.matrix_power(Nf, b) @ Cb.T)) < 1e-15 for a in range(5) for b in range(5))
    mags_eq = np.allclose(np.abs(Ca), np.abs(Cb))
    # shortest separating word by exact prefix search
    level, found = [("", None, None)], None
    for L in range(1, 8):
        nxt = []
        for w, MA, MB in level:
            for c in "PDS":
                NA = A[c] if MA is None else mm(MA, A[c]); NB = B[c] if MB is None else mm(MB, B[c])
                if tr(NA) != tr(NB) and found is None: found = (w + c, tr(NA) - tr(NB))
                nxt.append((w + c, NA, NB))
        level = nxt
        if found: break
    js = node([{"lib": "labs3", "fn": "compareRoomQ", "args": [qs(R0), qs(N0), qs(CA), qs(R0), qs(N0), qs(CB)]}])[0]
    ok = sv_eq and mixed_eq and mags_eq and found == ("DSSSS", Fr(-1, 625)) and js["separating"]["word"] == "DSSSS" and js["separating"]["gap"] == "-1/625" and not js["closure"]["equivalent"]
    # mutation: a gauge-equivalent B (row 2 and column 3 flipped) must not be separated by any word
    Bg = [[-x if (i == 1) != (j == 2) else x for j, x in enumerate(r)] for i, r in enumerate(CB)]
    gauge_same = words_equal_upto(tup(R0, N0, CB), tup(R0, N0, Bg), 6)
    return result("holds" if ok else "counterexample", {"shortest_separating_word": found[0], "exact_gap": str(found[1]), "coupling_sv_equal": sv_eq, "mixed_traces_equal": mixed_eq,
                                                        "magnitudes_equal": mags_eq, "canonical_correlations_differ": not js["doors"]["canonicalCorrelations"],
                                                        "note": "the paper's own witness (gap -1/25 000 000, word P D^2 S D S^3) uses a triple not given in the paper; this is an independent witness"},
                  "mutation: a gauge-flipped copy must agree on every word up to length 6", gauge_same)


def sign_orbits(p, q, support):
    edges = [(i, j) for i in range(p) for j in range(q) if support[i][j]]
    seen, orbits = set(), 0
    for signs in itertools.product([1, -1], repeat=len(edges)):
        if signs in seen: continue
        orbits += 1
        for rf in itertools.product([1, -1], repeat=p):
            for cf in itertools.product([1, -1], repeat=q):
                seen.add(tuple(s * rf[i] * cf[j] for s, (i, j) in zip(signs, edges)))
    return orbits, len(edges)


def components(p, q, support):
    par = list(range(p + q))
    def f(x):
        while par[x] != x: par[x] = par[par[x]]; x = par[x]
        return x
    for i in range(p):
        for j in range(q):
            if support[i][j]: par[f(i)] = f(p + j)
    return len({f(x) for x in range(p + q)})


@attack("K03", "L125 sign chart H1(G; F2)", "row/column sign flips preserve every cycle sign; the number of sign classes is 2^(E-V+c), (p-1)(q-1) bits when dense", "holds", needs_node=True)
def k03(seed):
    rng = np.random.default_rng(seed)
    ok, rows = True, []
    for _ in range(5):
        p, q = int(rng.integers(1, 4)), int(rng.integers(1, 4))
        sup = (rng.random((p, q)) < 0.75).astype(int)
        orbits, E = sign_orbits(p, q, sup)
        c = components(p, q, sup); pred = 2 ** (E - (p + q) + c)
        rows.append({"p": p, "q": q, "E": E, "c": c, "orbits": orbits, "formula": pred}); ok &= orbits == pred
    dense = [sign_orbits(p, q, np.ones((p, q), int))[0] == 2 ** ((p - 1) * (q - 1)) for p in (2, 3) for q in (2, 3)]
    # site: random gauge flips keep the signature
    C = [[Fr(int(rng.integers(1, 5)) * int(rng.choice([-1, 1])), 7) for _ in range(3)] for _ in range(3)]
    flips = [(int(rng.integers(0, 2)), int(rng.integers(0, 3))) for _ in range(6)]
    out = node([{"lib": "labs3", "fn": "cycleSignsGauge", "args": [qs(C), flips]}])[0]
    ok = ok and all(dense) and out["before"] == out["after"]
    # mutation: the formula without the component count fails on a disconnected support
    sup = np.array([[1, 1, 0], [1, 1, 0], [0, 0, 1]])
    o, E = sign_orbits(3, 3, sup)
    return result("holds" if ok else "counterexample", {"cases": rows, "dense_ok": dense, "site_signature_before_after": [out["before"], out["after"]]},
                  "mutation: 2^(E-V+1) (ignoring components) must fail on a disconnected support", o != 2 ** (E - 6 + 1))


def lie_dim(p, q, sig):
    """Independent: dimension of {(a, b) in o(p) x o(q) : a K = K b} for whitened K = diag(sig)."""
    K = np.zeros((p, q)); K[range(len(sig)), range(len(sig))] = sig
    basis_a = [(i, j) for i in range(p) for j in range(i + 1, p)]; basis_b = [(i, j) for i in range(q) for j in range(i + 1, q)]
    cols = []
    for (i, j) in basis_a:
        a = np.zeros((p, p)); a[i, j], a[j, i] = 1, -1; cols.append((a @ K).ravel())
    for (i, j) in basis_b:
        b = np.zeros((q, q)); b[i, j], b[j, i] = 1, -1; cols.append(-(K @ b).ravel())
    if not cols: return 0
    M = np.array(cols).T
    return M.shape[1] - np.linalg.matrix_rank(M, tol=1e-10)


@attack("K04", "L118 / L120 coupling stabilizer, No-Go 17.6, Cor 17.8(2)", "classes over S^1 for p = q = 3 are 4, 8, 16, 8 (C = 0, distinct correlations of rank 1, 2, 3) and 2 for C = I/2; rank does not control symmetry", "holds", seeded=False, needs_node=True)
def k04(seed):
    cases = {"C=0": [], "rank1": [0.5], "rank2": [0.5, 0.3], "rank3": [0.5, 0.3, 0.1], "I/2": [0.5, 0.5, 0.5]}
    js = node([{"lib": "labs3", "fn": "stabilizer", "args": [3, 3, v]} for v in cases.values()])
    classes = [o["classesOverCircle"] for o in js]; dims = [o["dim"] for o in js]
    indep = [lie_dim(3, 3, v) for v in cases.values()]
    ok = classes == [4, 8, 16, 8, 2] and dims == indep and dims[4] == 3 and dims[1] == 2
    # random sweep: repeated correlations have measure zero
    rng = np.random.default_rng(1); hits = 0
    for _ in range(5000):
        s = np.linalg.svd(rng.normal(size=(3, 3)), compute_uv=False); hits += np.min(np.diff(np.sort(s))) < 1e-9
    return result("holds" if ok else "counterexample", {"classes": classes, "dims_site": dims, "dims_independent_lie_algebra": indep, "random_sweep_hits": int(hits)},
                  "mutation: counting 2^rank instead of 2^kappa must disagree with the paper's list", [2 ** len(v) for v in cases.values()] != [4, 8, 16, 8, 2])


@attack("K05", "L120 / Cor 17.8(3) local invariants are not complete", "a family over S^1 with constant spectrum and stabilizer has a Möbius resolved bundle (odd winding), and a trivial one for even winding", "holds", seeded=False, needs_node=True)
def k05(seed):
    out = {}
    for k in (1, 2, 3):
        ts = np.linspace(0, 2 * np.pi, 721)
        vs = np.array([[np.cos(k * t / 2), np.sin(k * t / 2)] for t in ts])
        projs = np.einsum("ti,tj->tij", vs, vs)
        const_spec = np.allclose([np.linalg.eigvalsh(P) for P in projs], [[0, 1]] * len(ts))
        periodic = np.allclose(projs[0], projs[-1])
        out[k] = {"constant_spectrum": const_spec, "projector_periodic": periodic, "frame_returns": float(np.sign(vs[0] @ vs[-1]))}
    js = node([{"lib": "labs3", "fn": "mobius", "args": [k, 200]} for k in (1, 2, 3)])
    ok = all(v["constant_spectrum"] and v["projector_periodic"] for v in out.values()) and out[1]["frame_returns"] == -1 and out[3]["frame_returns"] == -1 and [o["returnSign"] for o in js] == [-1, 1, -1]
    return result("holds" if ok else "counterexample", out, "mutation: even winding must return the frame unchanged", out[2]["frame_returns"] == 1)


@attack("K06", "L122 / Prop 17.10 forced wall monodromy and isotropy jump", "on loops linking a transversal collision of two canonical correlations each singular line has w1 = 1 while their sum is trivial; diag(t, 0) has dim Aut 2 at t = 0 and 0 otherwise", "holds", needs_node=True)
def k06(seed):
    rng = np.random.default_rng(seed)
    def track(cx, cy, rad, s=1.0, n=720):
        v1 = v2 = None; f0 = None
        for k in range(n + 1):
            th = 2 * np.pi * k / n; a, b = cx + rad * np.cos(th), cy + rad * np.sin(th)
            w, V = np.linalg.eigh(np.array([[s + a, b], [b, s - a]])); u1, u2 = V[:, 1], V[:, 0]
            if v1 is not None:
                if u1 @ v1 < 0: u1 = -u1
                if u2 @ v2 < 0: u2 = -u2
            else: f0 = (u1, u2)
            v1, v2 = u1, u2
        return [int(f0[0] @ v1 < 0), int(f0[1] @ v2 < 0)], int(np.sign(np.linalg.det(np.c_[f0]) * np.linalg.det(np.c_[v1, v2])) < 0)
    ok = True; rows = []
    for _ in range(4):
        rad = float(rng.uniform(0.1, 0.4)); cx, cy = rng.uniform(-0.3, 0.3, 2)
        w, sumw = track(cx, cy, rad); links = math.hypot(cx, cy) < rad
        rows.append({"links": links, "w1": w, "sum_w1": sumw}); ok &= (w == [1, 1]) == links and sumw == 0
    js = node([{"lib": "labs3", "fn": "wallLoop", "args": [0, 0, 0.3, 1, 360]}, {"lib": "labs3", "fn": "wallLoop", "args": [0.5, 0, 0.3, 1, 360]}])
    ok = ok and js[0]["w1"] == [1, 1] and js[1]["w1"] == [0, 0] and js[0]["sumW1"] == 0
    dims = node([{"lib": "labs3", "fn": "stabilizer", "args": [2, 2, [0.0]]}, {"lib": "labs3", "fn": "stabilizer", "args": [2, 2, [0.3]]}])
    jump = dims[0]["dim"] == 2 and dims[1]["dim"] == 0
    return result("holds" if ok and jump else "counterexample", {"loops": rows, "isotropy_dims": [dims[0]["dim"], dims[1]["dim"]]},
                  "mutation: a loop that does not link the wall must have w1 = 0 for both lines", js[1]["w1"] == [0, 0])


@attack("K07", "L117 / Prop 17.4 the coupling is complement-relative", "Sigma -> T Sigma T^T with TJ = J leaves the Fisher tensor and the null block invariant, sends C to C + K D, and reaches C = 0", "holds", needs_node=True)
def k07(seed):
    rng = np.random.default_rng(seed)
    p, q = 2, 3
    A = rng.normal(size=(p + q, p + q)); S = A @ A.T + 0.5 * np.eye(p + q)
    R, C, N = S[:p, :p], S[:p, p:], S[p:, p:]
    K = rng.normal(size=(p, q))
    js = node([{"lib": "labs3", "fn": "complementAction", "args": [R.tolist(), N.tolist(), C.tolist(), K.tolist()]},
               {"lib": "labs3", "fn": "complementAction", "args": [R.tolist(), N.tolist(), C.tolist(), (-C @ np.linalg.inv(N)).tolist()]}])
    G0, G1 = np.array(js[0]["before"]["G"]), np.array(js[0]["after"]["G"])
    ok = np.allclose(G0, G1, atol=1e-10) and np.allclose(js[0]["after"]["C"], C + K @ N) and np.allclose(js[0]["after"]["N"], N) and np.allclose(js[1]["after"]["C"], 0, atol=1e-12)
    Gpy = np.linalg.inv(S)[:p, :p]
    ok = ok and np.allclose(G0, Gpy)
    return result("holds" if ok else "counterexample", {"fisher_change": float(np.abs(G0 - G1).max()), "C_after_K=-CD^-1": float(np.abs(np.array(js[1]["after"]["C"])).max())},
                  "mutation: a T that moves the resolved block (T J != J) must change the Fisher tensor",
                  not np.allclose(np.linalg.inv(np.diag([2.0] * (p + q)) @ S @ np.diag([2.0] * (p + q)))[:p, :p], Gpy))


@attack("K08", "L127 / No-Go 18.6 Lorentzian scalars do not classify; Schwarzschild control", "the vacuum plane wave has zero Ricci and Kretschmann but a nonzero, observer-dependent tidal tensor; tr E^2 cannot tell M from -M, the cubic recovers M", "holds", seeded=False, needs_node=True)
def k08(seed):
    import sympy as sp
    u, v, x, y, A, a = sp.symbols("u v x y A a", real=True)
    co = [u, v, x, y]; H = A * (x ** 2 - y ** 2)
    g = sp.Matrix([[H, 1, 0, 0], [1, 0, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]); gi = g.inv()
    Gam = [[[sp.simplify(sum(gi[i, d] * (sp.diff(g[d, b], co[c]) + sp.diff(g[d, c], co[b]) - sp.diff(g[b, c], co[d])) for d in range(4)) / 2) for c in range(4)] for b in range(4)] for i in range(4)]
    def Rm(i, b, c, d):
        return sp.simplify(sp.diff(Gam[i][b][d], co[c]) - sp.diff(Gam[i][b][c], co[d]) + sum(Gam[i][c][e] * Gam[e][b][d] - Gam[i][d][e] * Gam[e][b][c] for e in range(4)))
    Rup = [[[[Rm(i, b, c, d) for d in range(4)] for c in range(4)] for b in range(4)] for i in range(4)]
    Ric = sp.Matrix(4, 4, lambda b, d: sum(Rup[i][b][i][d] for i in range(4)))
    Rl = [[[[sum(g[i, e] * Rup[e][b][c][d] for e in range(4)) for d in range(4)] for c in range(4)] for b in range(4)] for i in range(4)]
    Ruu = [[[[sp.simplify(sum(gi[b, f] * gi[c, h] * gi[d, k] * Rup[i][f][h][k] for f in range(4) for h in range(4) for k in range(4))) for d in range(4)] for c in range(4)] for b in range(4)] for i in range(4)]
    Kr = sp.simplify(sum(Rl[i][b][c][d] * Ruu[i][b][c][d] for i in range(4) for b in range(4) for c in range(4) for d in range(4)))
    U = [sp.exp(a) / sp.sqrt(2), -sp.exp(-a) / sp.sqrt(2), 0, 0]
    E = sp.Matrix(2, 2, lambda i, j: sp.simplify(sum(Rl[2 + i][m][2 + j][n] * U[m] * U[n] for m in range(4) for n in range(4)).subs({x: 0, y: 0})))
    nonzero = any(sp.simplify(Rl[i][b][c][d]) != 0 for i in range(4) for b in range(4) for c in range(4) for d in range(4))
    js = node([{"lib": "labs3", "fn": "planeWave", "args": [1.3, 0.7]}, {"lib": "labs3", "fn": "schwarzschild", "args": [2, 10]}, {"lib": "labs3", "fn": "schwarzschild", "args": [-2, 10]}])
    Ev = E.subs({A: 1.3, a: 0.7})
    js_ok = np.allclose(np.array(js[0]["tidal"], float), np.array(Ev.tolist(), dtype=float))
    schw = abs(js[1]["trE2"] - js[2]["trE2"]) < 1e-18 and abs(js[1]["recoveredM"] - 2) < 1e-12 and abs(js[2]["recoveredM"] + 2) < 1e-12
    ok = Ric == sp.zeros(4, 4) and Kr == 0 and nonzero and js_ok and schw and sp.simplify(E[0, 0] + A * sp.exp(2 * a) / 2) == 0
    return result("holds" if ok else "counterexample", {"ricci_zero": Ric == sp.zeros(4, 4), "kretschmann": str(Kr), "riemann_nonzero": nonzero, "tidal": str(E), "site_tidal_matches": js_ok, "schwarzschild_ok": schw},
                  "mutation: the tidal magnitude must change with the observer's boost", sp.simplify(E.subs(a, 0)[0, 0] - E.subs(a, 1)[0, 0]) != 0)


@attack("K09", "L112-L115 dispatcher: totality, determinism, composite soundness, monotone thresholds", "every gate combination returns exactly one status, LOCKED iff all gates pass, all seven statuses are reachable, and false LOCKED <= sum of gate errors", "holds", needs_node=True)
def k09(seed):
    out = node([{"lib": "labs3", "fn": "dispatchAll", "args": []}, {"lib": "labs3", "fn": "soundnessSim", "args": [[0.01, 0.02, 0.005, 0.01, 0.03], 0.7, 100000, int(seed % 2**31)]}])
    combos, sim = out
    statuses = {c["status"] for c in combos}
    locked_iff = all((c["status"] == "LOCKED") == all(v == 0 for v in c["choice"].values()) for c in combos)
    ok = len(combos) == 2 * 2 * 2 * 2 * 3 * 2 * 3 and statuses == {"LOCKED", "ESCALATE", "CORRESPONDENCE", "VACUOUS", "INCONSISTENT", "STRUCTURAL WALL", "OUTSIDE DOMAIN"} and locked_iff
    sound = sim["falseLockRate"] <= sim["bound"]
    # monotone filtration (Prop 16.5): gate statistics fixed, thresholds raised -> LOCKED set can only shrink
    rng = np.random.default_rng(seed); viol = 0
    for _ in range(200):
        stats = rng.random(5)
        for _ in range(20):
            t1 = rng.random(5); t2 = t1 + rng.random(5) * 0.3
            viol += bool(np.all(stats >= t2)) and not bool(np.all(stats >= t1))
    # mutation: a dispatcher that ignores the candidate gate locks on several indistinguishable candidates
    bad = sum(1 for c in combos if c["choice"].get("candidate") == 1 and all(v == 0 for k, v in c["choice"].items() if k != "candidate"))
    return result("holds" if ok and sound and viol == 0 else "counterexample",
                  {"combinations": len(combos), "statuses": sorted(statuses), "false_lock_rate": sim["falseLockRate"], "bound": sim["bound"], "filtration_violations": viol,
                   "note": "the paper's dispatcher has 384 combinations; this site's gate design has 288 and is its own declaration"},
                  "mutation: ignoring the candidate gate would turn a CORRESPONDENCE leaf into LOCKED", bad == 1)


# ------------------------------------------------------------------ short claims of the statement of record
@attack("P01", "H-mono (Hyp 7.4)", "merging two outcomes enlarges the kernel yet can increase Euclidean distance by sqrt(8/6)", "holds")
def p01(seed):
    rng = np.random.default_rng(seed); best = 0
    for _ in range(20000):
        d = rng.normal(size=2); d = np.r_[d, -d.sum()]
        best = max(best, np.hypot(d[0] + d[1], d[2]) / np.linalg.norm(d))
    t = 1.0; d = np.array([t, t, -2 * t]); exact = np.hypot(d[0] + d[1], d[2]) / np.linalg.norm(d)
    return result("holds" if abs(exact - math.sqrt(8 / 6)) < 1e-12 and best <= math.sqrt(8 / 6) + 1e-9 else "counterexample",
                  {"sup_found": best, "sqrt(8/6)": math.sqrt(8 / 6), "witness": exact},
                  "mutation: the Fisher-Rao (Bhattacharyya) angle must never increase under the same merge", p01_fisher_mut(rng))


def p01_fisher_mut(rng):
    worst = -1.0
    for _ in range(5000):
        p, q = rng.dirichlet(np.ones(3)), rng.dirichlet(np.ones(3))
        ang = lambda a, b: math.acos(min(1.0, float(np.sum(np.sqrt(a * b)))))
        worst = max(worst, ang(np.r_[p[0] + p[1], p[2]], np.r_[q[0] + q[1], q[2]]) - ang(p, q))
    return worst <= 1e-12


@attack("P02", "No-Go 7.18 weak convergence is not enough", "for y observed as N(eps y, eps^2): Fisher stays 1, Hellinger(0.3, 1.1) stays 0.277, testing error stays 0.309", "holds", seeded=False)
def p02(seed):
    from scipy.stats import norm
    vals = []
    for eps in (1.0, 0.1, 1e-3):
        H = math.sqrt(1 - math.exp(-((eps * 0.8) / eps) ** 2 / 8))
        err = (1 - (2 * norm.cdf(eps * 1 / (2 * eps)) - 1)) / 2
        vals.append((H, err))
    ok = all(abs(h - 0.277) < 5e-4 and abs(e - 0.309) < 5e-4 for h, e in vals)
    return result("holds" if ok else "counterexample", {"hellinger_and_error_per_eps": vals},
                  "mutation: with noise variance eps (not eps^2) the distance must vanish as eps -> 0",
                  math.sqrt(1 - math.exp(-((1e-3 * 0.8) / math.sqrt(1e-3)) ** 2 / 8)) < 0.05)


@attack("P03", "L34 / Prop 7.13 nuisance wall", "the efficient metric tends to a(1 - rho^2) as eps -> 0+ but equals a at eps = 0 (the site's Schur complement)", "holds", needs_node=True)
def p03(seed):
    rng = np.random.default_rng(seed); a, rho = float(rng.uniform(0.5, 3)), float(rng.uniform(0.2, 0.9))
    I = lambda e: [[a, rho * math.sqrt(a * e)], [rho * math.sqrt(a * e), e]]
    js = node([{"lib": "labs", "fn": "schur", "args": [I(1e-6), [0], [1]]}, {"lib": "labs", "fn": "schur", "args": [I(0.0), [0], [1]]}])
    lim, at0 = js[0][0][0], js[1][0][0]
    return result("holds" if abs(lim - a * (1 - rho ** 2)) < 1e-6 and abs(at0 - a) < 1e-12 else "counterexample", {"a": a, "rho": rho, "eps->0+": lim, "eps=0": at0},
                  "mutation: with rho = 0 there is no jump", abs(node([{"lib": "labs", "fn": "schur", "args": [[[a, 0], [0, 1e-6]], [0], [1]]}])[0][0][0] - a) < 1e-12)


@attack("P04", "L7 / No-Go 5.3 non-splitting", "for X = Z4, F = x mod 2 and Z4 rotations, gauge = {0, 2}, image Z2, and no order-2 subgroup maps onto the image", "holds", seeded=False)
def p04(seed):
    F = lambda x: x % 2
    gauge = [g for g in range(4) if all(F((x + g) % 4) == F(x) for x in range(4))]
    image = {tuple(F((x + g) % 4) for x in range(4)) for g in range(4)}
    order2 = [g for g in range(4) if g != 0 and (2 * g) % 4 == 0]
    splits = any(g not in gauge for g in order2)
    return result("holds" if gauge == [0, 2] and len(image) == 2 and not splits else "counterexample", {"gauge": gauge, "image_size": len(image), "order2_elements": order2},
                  "mutation: with Z2 x Z2 in place of Z4 the sequence splits", p04_mut())


def p04_mut():
    X = [(a, b) for a in range(2) for b in range(2)]; F = lambda x: x[0]
    G = X; add = lambda g, x: ((g[0] + x[0]) % 2, (g[1] + x[1]) % 2)
    gauge = [g for g in G if all(F(add(g, x)) == F(x) for x in X)]
    return any(g not in gauge for g in G)       # every element of Z2 x Z2 has order <= 2, so a complement exists


@attack("P05", "L101 / Imported Thm 14.9 unit-distance rigidity fails for n = 1", "x -> x + 0.1 sin(2 pi x) is a bijection preserving distance one but not one half", "holds")
def p05(seed):
    rng = np.random.default_rng(seed); xs = rng.uniform(-5, 5, 10000)
    f = lambda x: x + 0.1 * np.sin(2 * np.pi * x)
    one = np.max(np.abs(np.abs(f(xs + 1) - f(xs)) - 1)); half = np.max(np.abs(np.abs(f(xs + 0.5) - f(xs)) - 0.5))
    mono = np.min(1 + 0.2 * np.pi * np.cos(2 * np.pi * xs)) > 0
    return result("holds" if one < 1e-12 and half > 0.1 and mono else "counterexample", {"dev_at_1": float(one), "dev_at_half": float(half), "strictly_increasing": bool(mono)},
                  "mutation: an isometry x -> x + 0.3 must preserve both distances",
                  float(np.max(np.abs(np.abs((xs + 0.5 + 0.3) - (xs + 0.3)) - 0.5))) < 1e-12)


@attack("P06", "L86 / L91 kernel-count entropy and quotient growth", "for the logistic map at r = 4 the observable quotient of n-step histories (lap number) is 2^n: slope ln 2", "holds", seeded=False)
def p06(seed):
    # grid uniform in theta with x = sin^2(pi theta / 2): it resolves the narrow laps near 0 and 1 (a uniform x grid misses them at n = 11)
    xs = np.sin(np.pi * np.linspace(0, 1, 2 ** 18 + 1) / 2) ** 2
    laps = []
    y = xs.copy()
    for n in range(1, 12):
        y = 4 * y * (1 - y)
        d = np.diff(y); s = np.sign(d[np.abs(d) > 0]); laps.append(int(1 + np.sum(s[1:] != s[:-1])))
    slope = np.polyfit(range(1, 12), np.log(laps), 1)[0]
    ok = laps == [2 ** n for n in range(1, 12)] and abs(slope - math.log(2)) < 1e-12
    y = xs.copy(); laps39 = []
    for n in range(1, 12):
        y = 3.9 * y * (1 - y); d = np.diff(y); s = np.sign(d[np.abs(d) > 0]); laps39.append(int(1 + np.sum(s[1:] != s[:-1])))
    s39 = np.polyfit(range(5, 12), np.log(laps39[4:]), 1)[0]
    return result("holds" if ok else "counterexample", {"laps_r4": laps, "slope_r4": slope, "slope_r3.9": s39},
                  "mutation: r = 3.9 has lower topological entropy than ln 2", s39 < math.log(2) - 0.01)
