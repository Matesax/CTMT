"""Build the self-contained RG calculus page.

Inlines the Peggy-generated parser, the evaluator, the lab engine, the ladder data and the summarized
battery results into one HTML file (no external scripts; only Google Fonts with system fallbacks).
"""
import json
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ENG = os.path.join(ROOT, "rg_attack", "engine")
BUNDLE = os.path.join(ROOT, "rg_attack")

LADDER = [
    {"stratum": "Stratum 0: the exact root (the only forced layer)"},
    {"id": "R0", "s": "Observation map F: X → Y declared", "t": "input", "a": []},
    {"id": "R1", "s": "Kernel pair R_F = X ×_Y X is an equivalence relation (exact ignorance)", "t": "forced", "a": ["N03"]},
    {"id": "R2", "s": "Quotient Q_F ≅ Im F; every fibre-constant map factors uniquely through Q_F", "t": "forced", "a": ["N03", "U01"]},
    {"id": "R3", "s": "Saturation: observable invariants are exactly R_F-invariant functions", "t": "forced", "a": ["U01", "N03"]},
    {"stratum": "Stratum 1: assembly"},
    {"id": "R4", "s": "Kernel groupoid K_obs = X ×_Q X", "t": "forced", "a": ["G01"]},
    {"id": "R5", "s": "Sound declared groupoid A ↪ K_obs gives a surjection X/A → Q_F", "t": "gated", "a": []},
    {"id": "R6", "s": "X/A ≅ Q_F iff A is gauge-complete", "t": "gated", "a": []},
    {"stratum": "Stratum 2: second-order shadow"},
    {"id": "R7", "s": "Regular reconstruction: (R, N, Σ) is a gauge-equivariant function of (J, Σ, g)", "t": "imported", "a": []},
    {"id": "R8", "s": "Fisher = JᵀΣ⁻¹J = inverse Schur = second-order tangent shadow", "t": "imported", "a": ["G01", "G02", "G03", "E01"]},
    {"id": "R9", "s": "Fisher insufficiency: blind to the null block at C_RN = 0", "t": "nogo", "a": []},
    {"id": "R10", "s": "ker dF = fibre tangent only on regular strata; higher contact is jets of F", "t": "gated", "a": ["G06"]},
    {"stratum": "Stratum 3: ignorance and the observation limit"},
    {"id": "R11", "s": "On regular models rad g^F = ker dF", "t": "gated", "a": ["N01"]},
    {"id": "R12", "s": "Persistent null ker dF_∞ over a compatible sensor family, attained finitely", "t": "gated", "a": ["N03"]},
    {"id": "R13", "s": "Sensor wall versus removable precision and representation nulls", "t": "forced", "a": ["N01", "N02", "N03"]},
    {"id": "R14", "s": "Kernel-pair order ≠ Blackwell order", "t": "nogo", "a": ["G10"]},
    {"stratum": "Stratum 4: declared structure on the quotient"},
    {"id": "R15", "s": "Fibre-compatible reachability descends to a preorder on Q_F", "t": "declared", "a": []},
    {"id": "R16", "s": "A cone boundary needs a supplied compatible topology", "t": "gated", "a": []},
    {"id": "R17", "s": "Projective-cone invariance: classify the zero set, not the defining function", "t": "nogo", "a": []},
    {"id": "R18", "s": "Quadratic-cone gate gives a conformal ray [g_obs]", "t": "imported+gated", "a": []},
    {"id": "R19", "s": "Lorentz–Finsler realization gate", "t": "gated", "a": []},
    {"id": "R20", "s": "Multicone gate", "t": "gated", "a": []},
    {"id": "R21", "s": "Stratified-realization gate; residual characteristic geometry", "t": "gated+open", "a": []},
    {"id": "R22", "s": "Scale 𝒯 = −log C additive on the zero-memory stratum", "t": "gated", "a": []},
    {"id": "R23", "s": "Metric representative iff local scale data glue as an exact cocycle", "t": "gated", "a": []},
    {"id": "R24", "s": "Cross-stratum remote null test; ratio-only identifiability", "t": "gated", "a": []},
    {"stratum": "Stratum 5: transport"},
    {"id": "R25", "s": "∇^W = P∇^LC on a regular metric stratum", "t": "imported+gated", "a": []},
    {"id": "R26", "s": "Entropy cannot select a connection", "t": "nogo", "a": []},
    {"id": "R27", "s": "Canonical connection from (J, Σ, K)", "t": "open", "a": []},
    {"stratum": "Stratum 6: duration algebra"},
    {"id": "R28", "s": "𝒯 = −log C; memory = BCH defect; additive iff commuting", "t": "imported", "a": []},
    {"id": "R29", "s": "Scalar clocks are trace characters, unique up to unit", "t": "imported", "a": []},
    {"stratum": "Stratum 7: forgetting (Forgetting Ladder)"},
    {"id": "R30", "s": "Experiment E = (X, Φ, O, T, A, d, τ) declared, including functional type and admissible class", "t": "declared", "a": ["E03"]},
    {"id": "R31", "s": "Declaration diameter D_t(A) is a supremum over the class, not a sample of it", "t": "forced", "a": ["U03"]},
    {"id": "R32", "s": "Observation monotonicity (TV under kernels, W1 under Lipschitz maps)", "t": "imported", "a": ["F04"]},
    {"id": "R33", "s": "TV rigidity under bijections", "t": "nogo", "a": ["F04"]},
    {"id": "R34", "s": "Forgetting is fibre migration; observed D_t need not be monotone", "t": "forced", "a": ["F04"]},
    {"id": "R35", "s": "Finite-state recurrence and collapse", "t": "nogo", "a": ["F04", "F05"]},
    {"id": "R36", "s": "No uniform forgetting without a declared regularity class", "t": "nogo", "a": ["F02"]},
    {"id": "R37", "s": "Exactness + L¹-compact class ⇒ uniform forgetting", "t": "gated", "a": []},
    {"id": "R38", "s": "BV lock TVₙ ≤ 2^−(n+2) Var(f − g), sharp; logistic by conjugacy", "t": "gated", "a": ["F01", "F02", "F03"]},
    {"id": "R39", "s": "Galerkin NS W1 contraction lock below G_N < 1", "t": "gated", "a": []},
    {"id": "R40", "s": "Dobrushin block lock; deterministic δ = 1", "t": "gated+imported", "a": ["F06"]},
    {"id": "R41", "s": "Functional type: time averages versus fixed-time laws", "t": "forced", "a": ["F07"]},
    {"id": "R42", "s": "Cat-map weak forgetting with a scale-bound frontier", "t": "gated", "a": []},
    {"id": "R43", "s": "Samples refute, operators lock; TV is not sample-certifiable", "t": "imported+nogo", "a": ["F09"]},
    {"id": "R44", "s": "Monte Carlo is the integration engine, not the lock", "t": "imported", "a": ["U03", "U04"]},
    {"id": "R45", "s": "Wall correspondence = fibre saturation", "t": "forced", "a": ["U01"]},
    {"id": "R46", "s": "Forced deterministic turbulent forgetting", "t": "open", "a": []},
    {"id": "R47", "s": "Accuracy gate: a small declaration diameter does not certify the target", "t": "gated+nogo", "a": ["F05"]},
]
EXTRA = [
    {"id": "UG03", "s": "Quotient forgets the prior at rate 1/n; the kernel never does", "t": "gated", "a": ["U02"]},
    {"id": "UG04", "s": "Linearized propagation is the LAN limit; it fails at walls", "t": "imported+gated", "a": ["U01", "U04", "E04"]},
    {"id": "UG08/10", "s": "Non-circularity certificate; Monte Carlo objective on FORCED outputs", "t": "declared+gated", "a": ["U03", "E03"]},
    {"id": "D&A 3.1", "s": "Kernel-groupoid metric descent; four likelihood families", "t": "gated", "a": ["G01"]},
    {"id": "D&A 7.1", "s": "Garbling contraction; Poisson thinning ratio = retention", "t": "imported", "a": ["G02"]},
    {"id": "D&A 8.3", "s": "Reparameterization covariance of the tensor and of lengths", "t": "imported", "a": ["G03"]},
    {"id": "D&A 4.4, 6.1", "s": "Rank-one angle no-go; Euclidean limit of a constant isotropic metric", "t": "nogo+gated", "a": ["G04"]},
    {"id": "D&A 4.1", "s": "RG length as an infimum over paths", "t": "declared", "a": ["G08"]},
    {"id": "D&A 9.1–9.5", "s": "Rank wall slope 2; slice and tangent cone; projector jump √2", "t": "gated+nogo", "a": ["G05", "G06", "G07"]},
    {"id": "D&A 5.1", "s": "Rank-one reduction d = ∫ Θγ dM and d = ΘγM₁", "t": "gated+open", "a": ["G09"]},
    {"id": "NRD", "s": "Null trichotomy: structural, precision, representation", "t": "forced", "a": ["N01", "N02", "N03"]},
    {"id": "OD", "s": "Affine clock object, gauge-invariant contrast, coordinate loophole", "t": "gated", "a": ["D01", "D02", "D03"]},
    {"id": "Chaos", "s": "Frontier law: slope 1/λ, protocols move intercepts", "t": "gated", "a": ["F08"]},
    {"id": "Site", "s": "This page's engine: gradients, units, sampling, certificates, correlations, comparisons", "t": "declared", "a": ["E01", "E02", "E03", "E04", "E05", "E06", "E07"]},
    {"id": "Routing", "s": "Exact Held–Karp optimum, heuristic with certified 1-tree bound, TSPLIB optima", "t": "imported", "a": ["T01", "T02"]},
    {"id": "Routing RG", "s": "Optimal length under uncertain costs is a concave minimum: Jensen gap, non-identifiable tours at ties", "t": "gated", "a": ["T04"]},
    {"id": "UG09 (CHI)", "s": "χ = Mv²/(Φghρ) is a one-parameter channel: misses road load, blind to density, bottleneck reversed", "t": "gated+nogo", "a": ["C03", "C04", "C05", "C06"]},
    {"id": "Wind", "s": "Betz bound, Weibull energy pattern factor, NREL 5-MW rated speed, tail statements", "t": "imported", "a": ["W01", "W02", "W03"]},
    {"id": "Fuel", "s": "Road-load and Willans-line fuel model; EPA coast-down units", "t": "imported", "a": ["V01", "V02"]},
]
FINDINGS = [
    {"kind": "sharpened", "title": "A list of laws is not a class",
     "body": "The Uncertainty Geometry certificate calls a statement FORCED when it varies by at most 0.1σ over the declared admissible family, and UG10 concludes that Monte Carlo is then objective. With a finite list this fails. For y = x + 0.07x³ the σ of the output differs by 0.078σ between the normal and uniform laws (FORCED over that list), while a two-point law with the same mean and variance moves it by 0.124σ. The Forgetting Ladder already states the fix (R31: the object is the supremum over a class). The certificate is therefore a list statement; it becomes a class statement only for outputs that depend on the first two moments alone, such as linear outputs. The calculator now says so and accepts <code>twopoint</code> so anyone can try it.",
     "where": "Uncertainty Geometry §7, Corollary UG10; battery U03"},
    {"kind": "sharpened", "title": "The float tent map is exact only when written as a branch",
     "body": "A07 states that the float tent map is exact arithmetic, not rounding. That holds for x &lt; ½ ? 2x : 2 − 2x on every double. It fails for 1 − |2x − 1|: that form is exact only on 2⁻⁵⁴ℤ, and for example x = 2⁻⁶⁰ maps to 0 instead of 2⁻⁵⁹ (192 491 mismatches out of 200 000 doubles across binades, checked in exact rationals). The collapse step equals the dyadic depth of the declaration: 54 for 53-bit uniforms, about 64 for declarations on [0, 2⁻¹⁰] in the branch form, and at most 55 for the abs form whatever the input. The reported 63–66 is a property of the declaration and formula used, which the paper should state. R35 and R47 are unaffected.",
     "where": "Forgetting Ladder, R47 and attack A07; battery F05"},
    {"kind": "sharpened", "title": "float64 does not report zero; it cannot decide",
     "body": "The Null Resolution Depth verification says float64 reports the spectrum {1, 10⁻²⁰, 0} as 1, 0, 0. Behind an exactly orthogonal rational rotation, float64 returns about 8.5×10⁻²¹ and −3.3×10⁻¹⁷ for the two small directions. Both lie inside its own rounding bound (about 2×10⁻¹⁵), so it cannot tell which is zero. The correct test for precision depth is the a-priori error bound, not whether a solver prints 0. Exact arithmetic still decides: depth 20 against depth ∞. The trichotomy stands.",
     "where": "Null Resolution Depth, verification remark to Thm 3.1; battery N01"},
    {"kind": "open", "title": "The unit of M in d = ∫ Θγ dM is undeclared",
     "body": "The rank-one reduction is a length only if [Θγ] = length/[M]. Under the readings carried over from CTMT (Θ and γ as rates in s⁻¹, M₁ as a hop length in m) Θ·γ·M₁ has unit m s⁻², and the site's unit checker says so. The retired D_kernel = M₁Θ/γ is a length under those readings but is not the corpus formula. Remark 5.3 anticipates a naming problem; the ladder does not yet fix the unit. Until it does, the reduction can be used for ratios and for metric coefficients declared directly, not for physical distances computed from CTMT-style Θ, γ, M₁.",
     "where": "Distance and Angle Laws Thm 5.1, Remark 5.3; battery G09"},
    {"kind": "sharpened", "title": "One anchor reproduces 6 → 9 L/100 km, and that is all it shows",
     "body": "Across 50 declared vehicles (drag, rolling resistance, base power and engine efficiency varied), a χ channel calibrated at 72 km/h predicts 108 km/h with a median error under 10%: the retired example's agreement is real but it is near-anchor interpolation. The same channel predicting 36 km/h has median error above 30%, has the wrong sign for air density, and ignores grade. The fuel calculator now uses the road-load law directly and draws the χ channel only for comparison.",
     "where": "Retired CHI page, Example A; Uncertainty Geometry UG09; battery C03, V02"},
    {"kind": "open", "title": "Not attacked in this bundle",
     "body": "The cone realization branch (R15–R21), scale and integrability (R22–R24), transport and the canonical connection (R25–R27), the Navier–Stokes contraction gate (R39), cat-map weak forgetting (R42) and forced turbulence (R46) are not re-attacked here. Their status is the corpus's own, shown on the ladder without a chip.",
     "where": "Theorem Ladder; Forgetting Ladder"},
]
AUDIT = [
    ["Uncertainty in the old in-browser calculator (every operation treats operands as independent)", "x − x returned √2·σ instead of 0; x·x and x² returned different σ. Correlation through shared inputs was invisible.", "L01", "Exact forward-mode gradients over declared inputs with the full declared covariance, then checked against sampling."],
    ["Worked examples 1.6 and 1.7 (390 survivors, O = +0.072; 168 survivors, O = +0.018)", "Not reproducible on any seed or reading of text and code: about 25% and 14% survive, and O is negative because E[Φ] = −e^{−1/2}. The printed J̄ and covariance give σ_O ≈ 0.022 and 0.066, not 0.015 and 0.035. Member 1 contributes 0.0061 under the page's own formula, not 0.0366. The text uses S* = 0.9 and Ξ·Im K; the code uses 1.0 and Im K.", "L02", "Seeded certificates that state sample size, seed and law."],
    ["sin²_R + cos²_R = |R_τ(e^{iΦ/S*})|² = 1", "False for every filtered member (modulus 0). Holds only without filtering.", "L03", "Ordinary trigonometry. Filtering is a protocol threshold, not a trigonometric identity."],
    ["σ_O² = einsum('ij,ji->', Jᵀ, Cov·J)", "Grows linearly with the number of samples (ratio ≈ 2 when N doubles).", "L04", "σ from the gradient and declared covariance; sampling error ∝ N^{−1/2} with a sample-size gate."],
    ["Ensemble Jacobian by np.gradient over random samples", "Changes when the samples are reordered.", "L05", "Exact derivatives."],
    ["Rupture filter R_τ", "Two incompatible definitions (|Φ| < τ and |terms| > τ) select different members.", "L06", "Thresholds as declared protocol walls with one-sided strata (Distance and Angles Prop 9.1, 9.5)."],
    ["C_phys as dimensional validator", "Multiplying by a constant cannot reject m + s.", "L07", "Unit algebra in the grammar; ill-typed programs are refused."],
    ["D_KL = E[p(xᵢ) log(p/q)] with xᵢ ∼ p", "Weights by p twice; wrong value.", "L08", "E_p[log p/q]."],
    ["Complexity table (ensemble O(n), legacy O(n³))", "For a smooth 1-D integral 51-node Simpson beats 10⁶ samples by orders of magnitude; sampling wins only in high dimension.", "L09", "Monte Carlo as the integration engine for a locked target (R44), not as the lock."],
    ["Divergence and curl via np.gradient(F)[0]", "Returns a single number, not a field.", "L10", "Not needed by RG."],
    ["D_kernel = M₁Θ/γ", "Not the RG reduction. RG has d = ∫ Θγ dM, whose unit of M is still undeclared.", "G09", "Distance and Angle Laws Thm 5.1, with the open unit question."],
    ["Kernel-rhythm routing (Φᵢ = dᵢ/L_K with L_K = 250 m)", "Between Brno and the other cities the phases are 444 to 1043, so S ≈ e^(−300) underflows and the kernel cost matrix equals the distance matrix: kernel routing is classical TSP. The table (645 versus 662 km, 7 h 20 versus 6 h 55, 12.8 versus 12.1 L) is not computable from the stated parameters. A closed round through the five cities is at least 912 km in straight lines, so 645 km is impossible if the route returns.", "T03", "Exact TSP with certified bounds, and RG uncertainty on travel costs (Routing view)."],
    ["Hydraulic rhythm cost h/(1 + μS)", "The arithmetic is right (4.10 and 7.30), but dividing a Darcy–Weisbach head loss by 1 + μS removes energy by declaration: no mechanism, and μ is tuned. It is a reweighting, not a loss.", "none", "Darcy–Weisbach with Swamee–Jain, checked against Colebrook (calculator example)."],
    ["CHI as a derived invariant (car, wind, pump)", "With one anchor the prediction is y₀·(M₁v₁²)/(M₀v₀²): Φ, h, ρ, g cancel, so χ is a one-parameter fit. The car example computes χ₀ = 2.61×10⁴ m³ and then uses 5.22×10⁴ in k. The pump's fixed-head reference is 2803 W, not 5600 W, so the overshoot is 4×, not 2×. Wind agrees with Betz only because the cubic law is restated.", "C01, C02", "CHI channel estimator: one anchor is CONDITIONAL; several anchors test the law; clustered anchors are a rank wall."],
    ["CHI bottleneck: χ_eff ≤ χ_min", "False: the series (harmonic) combination lies between the minimum and the mean in every case.", "C05", "Retained as an executable check on the CHI view."],
    ["\"Coherence class closure O ∈ C^(r)\"", "A type error: O is a number and C^(r) is a set of sample indices. The statement certifies nothing.", "none", "Typed verdicts: FORCED or CONDITIONAL over a declared list, REGULAR or WALL for the stratum."],
]


def main():
    res_path = os.path.join(BUNDLE, "results", "rg_attack_results.json")
    res = json.load(open(res_path))
    summary = {"environment": {k: res["environment"][k] for k in ("python", "numpy", "seeds", "seconds")},
               "modules": [{k: m[k] for k in ("id", "rung", "target", "expect", "status")} for m in res["modules"]]}
    parser = open(os.path.join(ENG, "parser.js")).read()
    engine = "\n".join([parser, open(os.path.join(ENG, "rgcalc.js")).read(), open(os.path.join(ENG, "labs.js")).read(), open(os.path.join(ENG, "labs2.js")).read()])
    data = ("window.RG_LADDER = " + json.dumps(LADDER, ensure_ascii=False) + ";\n"
            "window.RG_EXTRA = " + json.dumps(EXTRA, ensure_ascii=False) + ";\n"
            "window.RG_FINDINGS = " + json.dumps(FINDINGS, ensure_ascii=False) + ";\n"
            "window.RG_AUDIT = " + json.dumps(AUDIT, ensure_ascii=False) + ";\n"
            "window.RG_RESULTS = " + json.dumps(summary, ensure_ascii=False) + ";\n"
            "window.RG_GRAMMAR = " + json.dumps(open(os.path.join(ENG, "rgcalc.peggy")).read(), ensure_ascii=False) + ";\n")
    html = open(os.path.join(ROOT, "site", "template.html")).read()
    assert "</script" not in engine.lower() and "</script" not in data.lower()
    html = html.replace("/*__ENGINE__*/", engine + "\n" + data).replace("/*__UI2__*/", open(os.path.join(ROOT, "site", "ui2.js")).read()).replace("/*__UI__*/", open(os.path.join(ROOT, "site", "ui.js")).read())
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "site", "index.html")
    open(out, "w").write(html)
    print("wrote", out, len(html), "bytes")


if __name__ == "__main__":
    main()
