"""Build the self-contained RG calculus page.

Inlines the Peggy-generated parser, the evaluator, the lab engine, the ladder data and the summarized
battery results into one HTML file (no external scripts; only Google Fonts with system fallbacks).
"""
import json
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ENG = os.path.join(ROOT, "rg_attack", "engine")
BUNDLE = os.path.join(ROOT, "rg_attack")

S = lambda name: {"stratum": name}
def R(i, s, t, a=()): return {"id": f"L{i}", "s": s, "t": t, "a": list(a)}
F,I,H,G,N,O,IN = "forced","imported","gated","declared","nogo","open","input"
LADDER = [
 S("Exact layer"),
 R(0,"Observation system, joint law, relabeling group",IN),
 R(1,"Kernel groupoid; Q ≅ im F",F,["N03"]),
 R(2,"Universal factorization; invariants are functions on Q",F,["N03","U01"]),
 R(3,"Joint kernel is the intersection; Q ↪ ∏Qᵢ not onto",F),
 R(4,"Garbling enlarges the kernel",F,["G02","P01"]),
 R(5,"Exact layer determines no higher structure",N),
 S("Symmetry layer"),
 R(6,"1 → Gau → Stab → Γ → 1; liftable Γ faithful on Q; Γ ≤ Γ_obs",F),
 R(7,"The sequence need not split",N,["P04"]),
 R(8,"Count rigidity",F),
 R(9,"Orbit–quotient comparison (H-sound, H-compl)",H),
 R(10,"Rank, separation, completeness, reconstruction are distinct",N),
 R(11,"Coherent completeness (H-coh)",H),
 S("Observable sector"),
 R(12,"Complete minimal-panel selector; ties retained",F),
 R(13,"No task-free isotropic selector",N),
 R(14,"More protocols intersect kernels; more models close their union; common decoder",F),
 R(15,"Coupled law refines its marginals; pairing is not coupling",F),
 R(16,"Confidence-set bridge; point answers need a radius",F),
 R(17,"Tolerance is not a groupoid",N),
 S("Differential layer"),
 R(18,"Tangent sequence; infinitesimal completeness defect (H-reg)",H),
 R(19,"Natural descent: basic, Γ-invariant; radical = V if nondegenerate on the image tangent",F,["G01"]),
 R(20,"Descent of law-defined structures is automatic",F,["G01"]),
 R(21,"Singular strata: slices and tangent cones",I),
 R(22,"First-order tangent misses one-sided directions at walls",F,["G06"]),
 R(23,"Kernel upper semicontinuity; pointwise convergence and sampling insufficient (H-unif)",H),
 R(24,"Specialization map iff kernel inclusion; correspondence otherwise",F),
 R(25,"Symmetry descent through the normalizer of K₀",F),
 R(26,"Tangent upper semicontinuity; rank lower semicontinuity; finite tame strata",F+"+"+I,["G05"]),
 R(27,"Stratified quotient category; holonomy within strata (H-unif)",H),
 S("Second-order layer"),
 R(28,"Fisher is natural; rad g_F = V; Gaussian form",F,["G01","E01"]),
 R(29,"Naturality does not select the metric; Fisher under H-mono (Čencov)",N+"+"+H,["P01"]),
 R(30,"Regular reconstruction of (R, N, Σ)",I),
 R(31,"Fisher does not determine the covariance",N),
 R(32,"Second-order quotient has dimension p + q + pq",F),
 R(33,"Second-order shadow is not the law",N),
 R(34,"Efficient metric: conventions and nuisance wall (H-nuis)",H,["P03"]),
 R(35,"Data processing contracts Fisher",I,["G02"]),
 R(36,"Kernel order is not Blackwell order",N,["G10"]),
 R(37,"Distinguishability specializes under Hellinger convergence; weak is not enough",H,["P02"]),
 R(38,"Quantum metrics: Petz family gate; commuting collapse",I),
 R(39,"Quantum task lock: SLD, BKM, WY (H-task)",H),
 R(40,"Nonparametric identification of the Petz function; bands, not panels",F),
 R(41,"Quantum wall specialization iff f(0) > 0; re-discrimination",F),
 R(42,"Trace rule (Gleason, Busch)",I),
 R(43,"Contextual protocols: no hidden values; product law over contexts (Fine)",I+"+"+F),
 S("Ignorance"),
 R(44,"Persistent null; finite attainment (H-sens)",H,["N03"]),
 R(45,"Sensor, precision and representation nulls",F,["N01","N02","N03"]),
 R(46,"Finite-sample boundary reconstruction",I),
 R(47,"Rank walls are never certified from finite data",F),
 R(48,"Exact law equality is not uniformly certifiable from finite samples",N),
 S("Uncertainty, probability and forgetting"),
 R(49,"Uncertainty splits along the quotient; kernel prior never forgotten",F+"+"+I,["U02"]),
 R(50,"Probability from exchangeability (de Finetti)",H),
 R(51,"Gaussian propagation is the LAN limit; branch selection at folds",I+"+"+F,["U01","U04","E04"]),
 R(52,"TV rigidity under bijections; fibre migration",N,["F04"]),
 R(53,"No uniform forgetting without a declared class",N,["F02","U03"]),
 R(54,"Mixing locks: compactness; sharp BV bound; logistic by conjugacy (H-adm)",H,["F01","F02","F03"]),
 R(55,"Contraction gate G_N < 1; Dobrushin blocks; functional type (H-adm)",H,["F06","F07"]),
 R(56,"Samples refute, operators lock; accuracy gate",I+"+"+N,["F09","F05"]),
 R(57,"Non-circularity certificate; Monte Carlo placement (H-adm)",H,["U03","E03"]),
 R(58,"Non-dominated and infinite-dimensional strata (Feldman–Hájek)",I+"+"+F),
 S("Statistical distance"),
 R(59,"RG distance: representative- and chart-free, Γ-invariant, dimensionless",H,["G08","G03"]),
 R(60,"Garbling does not increase RG length",F,["G02"]),
 R(61,"No angle on rank-one strata",N,["G04"]),
 R(62,"Finite divergences are not additive",N),
 R(63,"RG distance is experiment-relative",N),
 S("Order and cone"),
 R(64,"Fibre-compatible reachability descends",F),
 R(65,"Projective typing of the cone",N),
 R(66,"Realization branches (H-top)",H),
 R(67,"Quadratic cone determines a conformal ray",I),
 R(68,"Lorentz isotropy forces the light cone (n ≥ 2)",G),
 R(69,"Tame reduction: finite types, sheets, integer dimension",I+"+"+F),
 R(70,"No finite linear classification",N),
 R(71,"Smoothness and strict convexity are dual",I),
 R(72,"Hyperbolic lock; residual symbol implies ill-posedness",I+"+"+F),
 R(73,"Wild class: resolution invariants, window certificates only",N),
 S("Scale and transport"),
 R(74,"Scale representative iff exact cocycle; holonomy (H-int)",H),
 R(75,"Strict transport fixes the conformal factor",F),
 R(76,"Induced connection on regular strata",I),
 R(77,"Entropy does not select a connection",N),
 R(78,"Law-defined transport descends; latent transport iff projectable",F+"+"+H),
 R(79,"No law-natural connection: vertical shears act transitively",N),
 R(80,"Canonical connection under declared covariance; physical under H-resp",H),
 S("Duration"),
 R(81,"Clock transition groupoid",F,["D01"]),
 R(82,"Affine clocks under a stabilizer time flow",G,["D01","D02"]),
 R(83,"Path independence as kernel inclusion; no orientation",F,["D02","D03"]),
 R(84,"Coherence duration and BCH memory",I),
 R(85,"Finite-history noiseless experiments are stratified-regular",F),
 R(86,"Topological entropy from kernel counts",I,["P06"]),
 R(87,"Ruelle, Pesin and variational locks",I),
 R(88,"Typed dynamical certificates; no zero-entropy certificate",F),
 R(89,"Cone fields of chaos: global only under uniform hyperbolicity",I),
 S("Chaos frontier"),
 R(90,"Frontier law: slope 1/λ; protocols move intercepts",I+"+"+F,["F08"]),
 R(91,"Duality 2λ; quotient growth h",F,["P06"]),
 R(92,"Information cost λ/ln 2 bits per certified step",I),
 R(93,"Clock distortion classes: offset, rate, warp",F),
 S("Physical distance"),
 R(94,"No internal unit",N,["G09"]),
 R(95,"Counted channel removes dilation",F),
 R(96,"Multiplicative count loss reopens the dilation fibre",N),
 R(97,"Ratio scale",I),
 R(98,"Two-point invariant",G),
 R(99,"Metric proportionality ḡ = λ²h",G,["G04"]),
 R(100,"Anchor budget dim(Sym²V*)^K",G),
 R(101,"Unit-distance rigidity (n ≥ 2)",I,["P05"]),
 R(102,"Radar distance; factor 1/2 (H-SI)",H),
 R(103,"Radar equals rod distance iff no exchanged-frequency shift",G),
 R(104,"Stationary slices: Landau–Lifshitz radar metric",I),
 R(105,"Synchronization holonomy (Sagnac); zero iff static",F),
 R(106,"Non-stationary slices: no time-independent radar metric",N),
 R(107,"Media: dilation fibre and invisible slowness (H-med)",H),
 R(108,"Ergodic transfer of the metre across outages (H-stat)",H),
 R(109,"Physical distance (H-reg, H-nuis, H-SI, H-med, H-val; Γ)",H+"+"+G),
 S("Assembly"),
 R(110,"Kernel–stabilizer theorem; compatibility equations",G),
 S("Global transport and closure"),
 R(111,"Global transport: observable atlas closed; latent transport canonical under declared data (H-cov)",H),
 R(112,"Statuses; totality and determinism of the dispatcher",F,["K09"]),
 R(113,"Composite soundness: false LOCK ≤ Σ α_g",F,["K09"]),
 R(114,"Walls are window-indexed; thresholds form a monotone filtration",F,["K09"]),
 R(115,"Maximal closure over a declared domain",F,["K09"]),
 S("Final remainder"),
 R(116,"Task residual; terminal sufficient refinement; exact correspondence with joint witnesses",F,["K02"]),
 R(117,"Coupling is complement-relative (L ↦ L + K); two second-order contracts",N,["K07"]),
 R(118,"Coupling stabilizer ∏O(m_j) × O(p − r) × O(q − r); rank does not control symmetry",I+"+"+N,["K04"]),
 R(119,"Global structure: stack, twisted forms Ȟ¹, block-bundle equivalence, classifying space (H-split, H-type)",H),
 R(120,"Contractible strata trivial; 2^κ classes over S¹; local invariants incomplete; Fisher remainder [K_N]",F,["K04","K05"]),
 R(121,"Gluing class in Ȟ²(abelian band); holonomy up to conjugacy; Leray covers",I+"+"+H),
 R(122,"Isotropy jump; forced wall monodromy at transversal collisions",N+"+"+F,["K06"]),
 R(123,"No new primitive on constant-type strata (H-split, H-type)",F),
 S("Local classification"),
 R(124,"Complete local classifier: (R, N, C) modulo O(p) × O(q) by word traces of (P, D, S), every stratum",I,["K01"]),
 R(125,"Simple-spectrum chart: spectra, magnitudes, cycle signs in H¹(G; F₂); loop values hidden, not null",F,["K02","K03"]),
 R(126,"Shorter descriptors lose orbits; relative tasks need joint classification",F,["K02","K08"]),
 R(127,"Lorentzian scalar invariants do not separate curvature; observer-relative classification",N,["K08"]),
 R(128,"Classification selects no dynamics",N),
 S("Open"),
 R(129,"Enumeration of tame characteristic types (Hilbert's sixteenth problem; external)",O),
 R(130,"Uniform forgetting for forced deterministic turbulence above the gate",O),
 R(131,"Classification of the second-order remainder across walls",O,["K06"]),
]

EXTRA = [
    {"id": "UG03 → L49", "s": "Quotient forgets the prior at rate 1/n; the kernel never does (Uncertainty Geometry)", "t": "gated", "a": ["U02"]},
    {"id": "UG04", "s": "Linearized propagation is the LAN limit; it fails at walls", "t": "imported+gated", "a": ["U01", "U04", "E04"]},
    {"id": "UG08/10", "s": "Non-circularity certificate; Monte Carlo objective on FORCED outputs", "t": "declared+gated", "a": ["U03", "E03"]},
    {"id": "D&A 3.1", "s": "Kernel-groupoid metric descent; four likelihood families", "t": "gated", "a": ["G01"]},
    {"id": "D&A 7.1", "s": "Garbling contraction; Poisson thinning ratio = retention", "t": "imported", "a": ["G02"]},
    {"id": "D&A 8.3", "s": "Reparameterization covariance of the tensor and of lengths", "t": "imported", "a": ["G03"]},
    {"id": "D&A 4.4, 6.1", "s": "Rank-one angle no-go; Euclidean limit of a constant isotropic metric", "t": "nogo+gated", "a": ["G04"]},
    {"id": "D&A 4.1", "s": "RG length as an infimum over paths", "t": "declared", "a": ["G08"]},
    {"id": "D&A 9.1–9.5", "s": "Rank wall slope 2; slice and tangent cone; projector jump √2", "t": "gated+nogo", "a": ["G05", "G06", "G07"]},
    {"id": "D&A 5.1", "s": "Rank-one reduction d = ∫ Θγ dM and d = ΘγM₁", "t": "gated+open", "a": ["G09"]},
    {"id": "NRD", "s": "Null trichotomy: structural, precision, representation", "t": "forced", "a": ["N01", "N02", "N03"]},
    {"id": "OD", "s": "Affine clock object, gauge-invariant contrast, coordinate loophole", "t": "gated", "a": ["D01", "D02", "D03"]},
    {"id": "Chaos", "s": "Frontier law: slope 1/λ, protocols move intercepts", "t": "gated", "a": ["F08"]},
    {"id": "Site", "s": "This page's engine: gradients, units, sampling, certificates, correlations, comparisons", "t": "declared", "a": ["E01", "E02", "E03", "E04", "E05", "E06", "E07"]},
    {"id": "Routing", "s": "Exact Held–Karp optimum, heuristic with certified 1-tree bound, TSPLIB optima", "t": "imported", "a": ["T01", "T02"]},
    {"id": "Routing RG", "s": "Optimal length under uncertain costs is a concave minimum: Jensen gap, non-identifiable tours at ties", "t": "gated", "a": ["T04"]},
    {"id": "UG09 (CHI)", "s": "χ = Mv²/(Φghρ) is a one-parameter channel: misses road load, blind to density, bottleneck reversed", "t": "gated+nogo", "a": ["C03", "C04", "C05", "C06"]},
    {"id": "Wind", "s": "Betz bound, Weibull energy pattern factor, NREL 5-MW rated speed, tail statements", "t": "imported", "a": ["W01", "W02", "W03"]},
    {"id": "Fuel", "s": "Road-load and Willans-line fuel model; EPA coast-down units", "t": "imported", "a": ["V01", "V02"]},
]
FINDINGS = [
    {"kind": "holds", "title": "The hidden room is real, and you can enter it",
     "body": "An independent exact witness for Corollary 18.4: R = diag(1, 2), N = diag(3, 5, 7) and two couplings that differ in one cycle sign. They agree in spectra, eigenbasis magnitudes, every mixed trace tr(Rᵃ C Nᵇ Cᵀ) and the singular values of C. The ordered word tr(D S⁴) separates them with exact rational gap −1/625, and the paired word algebra closes at dimension 50 ≤ 2n² with that word as witness. Gauge moves (eigenvector sign flips, and exact rational rotations in O(p) × O(q)) never change a word trace. Canonical correlations also separate this pair, so for this room they are a second door. The Hidden room view lets anyone repeat this.",
     "where": "Imported Theorem 18.2, Proposition 18.3, Corollary 18.4; battery K01–K03"},
    {"kind": "open", "title": "Four witnesses in the record cannot be reproduced from its text",
     "body": "The paper states numbers whose inputs it does not give: the gap −1/25 000 000 for tr(P D² S D S³) in Corollary 18.4 (the triple is not listed), the algebra dimensions 16, 16 and 8 in Remark 18.8, the largest random ratio 0.0099 in Theorem 9.9 (the random family is not specified), and the 384 dispatcher combinations in Theorem 16.2 (the gate outcome sets are not listed). Each is plausible and each structural claim behind it holds here on independent inputs, but a reader cannot check these specific numbers. Printing the triples, the random family and the gate table would close this.",
     "where": "Statement of record, Corollary 18.4, Remark 18.8, Theorem 9.9, Theorem 16.2; compare K02, K01, F01, K09"},
    {"kind": "resolved", "title": "A list of laws is not a class: now in the record",
     "body": "The earlier finding that a certificate over a finite list of laws is not a certificate over a class (U03) is stated by the record itself: No-Go 9.7 says finite lists cannot stand in for a class, and Theorem 9.12 defines FORCED through the supremum over the declared class with an operator inequality. The site's calculator still certifies over the list you declare, and says so in every FORCED verdict.",
     "where": "No-Go 9.7, Theorem 9.12 (L53, L57); battery U03"},
    {"kind": "resolved", "title": "d = ΘγM₁ is not part of the record",
     "body": "The open unit question about the rank-one reduction (G09) concerns the companion Distance and Angle Laws. The statement of record reaches physical distance only through a counted two-way timing channel with SI anchors (H-SI, L102) and the conditions of L109; RG distance itself is dimensionless (L59) and there is no internal unit (L94). The companion should either declare the unit of M or drop the CTMT reading.",
     "where": "Sections 10 and 14 of the record; companion Distance and Angle Laws; battery G09"},
    {"kind": "sharpened", "title": "Companion-level sharpenings that the record leaves untouched",
     "body": "Two earlier sharpenings live in companions and are consistent with the record's wording. The float tent map is exact only in its branch form (F05); the record says only that floating-point orbits are atomic (No-Go 9.11). float64 does not report a precision null as zero but returns values inside its own error bound (N01); the record's Proposition 8.3 states the three null layers without the float example. And a one-anchor χ channel transports only near its anchor (V02).",
     "where": "No-Go 9.11, Proposition 8.3; companions Forgetting Ladder, Null Resolution Depth, CHI audit"},
    {"kind": "open", "title": "Not attacked in this bundle",
     "body": "The quantum layer (L38–L43), the cone and characteristic branch (L64–L73), scale and transport (L74–L80), most of the physical-distance chain (L95–L109 beyond L99 and L101), the stack and gluing statements (L119, L121, L123), L128 and the open problems L129–L131 (K06 checks only the forced monodromy that any answer to L131 must carry). Their status on the ladder is the record's own, shown without a chip.",
     "where": "Statement of record, Section 20"},
]
AUDIT = [
    ["Uncertainty in the old in-browser calculator (every operation treats operands as independent)", "x − x returned √2·σ instead of 0; x·x and x² returned different σ. Correlation through shared inputs was invisible.", "L01", "Exact forward-mode gradients over declared inputs with the full declared covariance, then checked against sampling."],
    ["Worked examples 1.6 and 1.7 (390 survivors, O = +0.072; 168 survivors, O = +0.018)", "Not reproducible on any seed or reading of text and code: about 25% and 14% survive, and O is negative because E[Φ] = −e^{−1/2}. The printed J̄ and covariance give σ_O ≈ 0.022 and 0.066, not 0.015 and 0.035. Member 1 contributes 0.0061 under the page's own formula, not 0.0366. The text uses S* = 0.9 and Ξ·Im K; the code uses 1.0 and Im K.", "L02", "Seeded certificates that state sample size, seed and law."],
    ["sin²_R + cos²_R = |R_τ(e^{iΦ/S*})|² = 1", "False for every filtered member (modulus 0). Holds only without filtering.", "L03", "Ordinary trigonometry. Filtering is a protocol threshold, not a trigonometric identity."],
    ["σ_O² = einsum('ij,ji->', Jᵀ, Cov·J)", "Grows linearly with the number of samples (ratio ≈ 2 when N doubles).", "L04", "σ from the gradient and declared covariance; sampling error ∝ N^{−1/2} with a sample-size gate."],
    ["Ensemble Jacobian by np.gradient over random samples", "Changes when the samples are reordered.", "L05", "Exact derivatives."],
    ["Rupture filter R_τ", "Two incompatible definitions (|Φ| < τ and |terms| > τ) select different members.", "L06", "Thresholds as declared protocol walls with one-sided strata (Distance and Angles Prop 9.1, 9.5)."],
    ["C_phys as dimensional validator", "Multiplying by a constant cannot reject m + s.", "L07", "Unit algebra in the grammar; ill-typed programs are refused."],
    ["D_KL = E[p(xᵢ) log(p/q)] with xᵢ ∼ p", "Weights by p twice; wrong value.", "L08", "E_p[log p/q]."],
    ["Complexity table (ensemble O(n), legacy O(n³))", "For a smooth 1-D integral 51-node Simpson beats 10⁶ samples by orders of magnitude; sampling wins only in high dimension.", "L09", "Monte Carlo as the integration engine for a locked target (R44), not as the lock."],
    ["Divergence and curl via np.gradient(F)[0]", "Returns a single number, not a field.", "L10", "Not needed by RG."],
    ["D_kernel = M₁Θ/γ", "Not the RG reduction. RG has d = ∫ Θγ dM, whose unit of M is still undeclared.", "G09", "Distance and Angle Laws Thm 5.1, with the open unit question."],
    ["Kernel-rhythm routing (Φᵢ = dᵢ/L_K with L_K = 250 m)", "Between Brno and the other cities the phases are 444 to 1043, so S ≈ e^(−300) underflows and the kernel cost matrix equals the distance matrix: kernel routing is classical TSP. The table (645 versus 662 km, 7 h 20 versus 6 h 55, 12.8 versus 12.1 L) is not computable from the stated parameters. A closed round through the five cities is at least 912 km in straight lines, so 645 km is impossible if the route returns.", "T03", "Exact TSP with certified bounds, and RG uncertainty on travel costs (Routing view)."],
    ["Hydraulic rhythm cost h/(1 + μS)", "The arithmetic is right (4.10 and 7.30), but dividing a Darcy–Weisbach head loss by 1 + μS removes energy by declaration: no mechanism, and μ is tuned. It is a reweighting, not a loss.", "none", "Darcy–Weisbach with Swamee–Jain, checked against Colebrook (calculator example)."],
    ["CHI as a derived invariant (car, wind, pump)", "With one anchor the prediction is y₀·(M₁v₁²)/(M₀v₀²): Φ, h, ρ, g cancel, so χ is a one-parameter fit. The car example computes χ₀ = 2.61×10⁴ m³ and then uses 5.22×10⁴ in k. The pump's fixed-head reference is 2803 W, not 5600 W, so the overshoot is 4×, not 2×. Wind agrees with Betz only because the cubic law is restated.", "C01, C02", "CHI channel estimator: one anchor is CONDITIONAL; several anchors test the law; clustered anchors are a rank wall."],
    ["CHI bottleneck: χ_eff ≤ χ_min", "False: the series (harmonic) combination lies between the minimum and the mean in every case.", "C05", "Retained as an executable check on the CHI view."],
    ["\"Coherence class closure O ∈ C^(r)\"", "A type error: O is a number and C^(r) is a set of sample indices. The statement certifies nothing.", "none", "Typed verdicts: FORCED or CONDITIONAL over a declared list, REGULAR or WALL for the stratum."],
]


def main():
    res_path = os.path.join(BUNDLE, "results", "rg_attack_results.json")
    res = json.load(open(res_path))
    summary = {"environment": {k: res["environment"][k] for k in ("python", "numpy", "seeds", "seconds")},
               "modules": [{k: m[k] for k in ("id", "rung", "target", "expect", "status")} for m in res["modules"]]}
    parser = open(os.path.join(ENG, "parser.js")).read()
    engine = "\n".join([parser, open(os.path.join(ENG, "rgcalc.js")).read(), open(os.path.join(ENG, "labs.js")).read(), open(os.path.join(ENG, "labs2.js")).read(), open(os.path.join(ENG, "labs3.js")).read()])
    data = ("window.RG_LADDER = " + json.dumps(LADDER, ensure_ascii=False) + ";\n"
            "window.RG_EXTRA = " + json.dumps(EXTRA, ensure_ascii=False) + ";\n"
            "window.RG_FINDINGS = " + json.dumps(FINDINGS, ensure_ascii=False) + ";\n"
            "window.RG_AUDIT = " + json.dumps(AUDIT, ensure_ascii=False) + ";\n"
            "window.RG_RESULTS = " + json.dumps(summary, ensure_ascii=False) + ";\n"
            "window.RG_GRAMMAR = " + json.dumps(open(os.path.join(ENG, "rgcalc.peggy")).read(), ensure_ascii=False) + ";\n")
    html = open(os.path.join(ROOT, "site", "template.html")).read()
    assert "</script" not in engine.lower() and "</script" not in data.lower()
    html = html.replace("/*__ENGINE__*/", engine + "\n" + data).replace("/*__UI2__*/", open(os.path.join(ROOT, "site", "ui2.js")).read()).replace("/*__UI3__*/", open(os.path.join(ROOT, "site", "ui3.js")).read()).replace("/*__UI__*/", open(os.path.join(ROOT, "site", "ui.js")).read())
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "site", "index.html")
    open(out, "w").write(html)
    print("wrote", out, len(html), "bytes")


if __name__ == "__main__":
    main()
