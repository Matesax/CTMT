(function () {
  "use strict";
  const L3 = window.RGLabs3, Q = L3.Q;
  const U = () => window.RGUI;
  const el = (id) => document.getElementById(id);
  const val = (id) => el(id).value;
  const qm = (rows) => rows.map((r) => r.map((x) => Q.parse(String(x))));
  const diagQ = (spec) => spec.map((x, i) => spec.map((_, j) => (i === j ? Q.parse(String(x)) : new Q(0n))));
  const SUPS = { "-": "⁻", 0: "⁰", 1: "¹", 2: "²", 3: "³", 4: "⁴", 5: "⁵", 6: "⁶", 7: "⁷", 8: "⁸", 9: "⁹" };
  const wordHTML = (w) => ((w || "").match(/(.)\1*/g) || []).map((m) => m[0] + (m.length > 1 ? String(m.length).split("").map((c) => SUPS[c]).join("") : "")).join(" ");

  // ================================================================ THE HIDDEN ROOM
  const PRESETS = {
    witness: { label: "2 × 3 twins: every simple descriptor agrees", R: ["1", "2"], N: ["3", "5", "7"], A: [["1/10", "1/10", "2/10"], ["1/10", "-1/10", "1/10"]], B: [["1/10", "1/10", "2/10"], ["-1/10", "1/10", "1/10"]] },
    square: { label: "2 × 2: one loop, singular values already see it", R: ["1", "2"], N: ["3", "5"], A: [["1/10", "2/10"], ["3/10", "1/10"]], B: [["1/10", "2/10"], ["3/10", "-1/10"]] },
    dense: { label: "3 × 3 dense: four sign bits", R: ["1", "2", "4"], N: ["3", "5", "6"], A: [["1/10", "1/10", "1/10"], ["1/10", "2/10", "1/10"], ["1/10", "1/10", "3/10"]], B: [["1/10", "1/10", "1/10"], ["1/10", "2/10", "-1/10"], ["1/10", "1/10", "3/10"]] },
    tree: { label: "Tree support: no loop, no room", R: ["1", "2"], N: ["3", "5", "7"], A: [["1/10", "2/10", "0"], ["0", "0", "1/10"]], B: [["-1/10", "2/10", "0"], ["0", "0", "-1/10"]] },
  };
  const room = { R: null, N: null, A: null, B: null, scrambled: null, msg: "" };
  function loadPreset(k) { const P = PRESETS[k]; room.R = P.R.slice(); room.N = P.N.slice(); room.A = qm(P.A); room.B = qm(P.B); room.scrambled = null; room.msg = ""; el("rmR").value = P.R.join(", "); el("rmN").value = P.N.join(", "); renderRoom(); }
  function sysOf(which) {
    if (which === "B" && room.scrambled) return { R: room.scrambled.R, N: room.scrambled.N, C: room.scrambled.C };
    return { R: diagQ(room.R), N: diagQ(room.N), C: room[which] };
  }
  function drawGraph(which, cyc) {
    const C = room[which], p = C.length, q = C[0].length, H = 40 + 56 * Math.max(p, q), W = 330;
    const yL = (i) => 30 + (H - 60) * (p === 1 ? 0.5 : i / (p - 1)), yR = (j) => 30 + (H - 60) * (q === 1 ? 0.5 : j / (q - 1));
    let mx = 0; C.forEach((r) => r.forEach((x) => { mx = Math.max(mx, Math.abs(x.toNumber())); }));
    let g = "";
    for (let i = 0; i < p; i++) for (let j = 0; j < q; j++) {
      const x = C[i][j]; if (x.isZero()) { g += `<line x1="70" y1="${yL(i)}" x2="260" y2="${yR(j)}" stroke="var(--rule)" stroke-dasharray="2 5" stroke-width="1"/>`; continue; }
      const col = x.sign() > 0 ? "var(--t-forced)" : "var(--t-nogo)", w = 1.5 + 5 * Math.abs(x.toNumber()) / (mx || 1);
      g += `<line x1="70" y1="${yL(i)}" x2="260" y2="${yR(j)}" stroke="${col}" stroke-width="${w}" ${x.sign() < 0 ? 'stroke-dasharray="7 4"' : ""}/>`;
      g += `<line class="hit" data-edge="${i},${j}" x1="70" y1="${yL(i)}" x2="260" y2="${yR(j)}" stroke="transparent" stroke-width="14" style="cursor:pointer"><title>edge r${i + 1}–n${j + 1}: ${x.toString()}. Click to flip its sign (changes the system)</title></line>`;
    }
    for (let i = 0; i < p; i++) g += `<g data-node="r${i}" style="cursor:pointer"><circle cx="70" cy="${yL(i)}" r="15" fill="var(--panel)" stroke="var(--ink)" stroke-width="1.5"/><text x="70" y="${yL(i) + 4}" text-anchor="middle" style="fill:var(--ink);font:600 11px var(--mono)">r${i + 1}</text><text x="44" y="${yL(i) + 4}" text-anchor="end" style="fill:var(--muted);font:11px var(--mono)">${room.R[i]}</text><title>row ${i + 1} (eigenvalue ${room.R[i]} of R). Click: gauge flip of this eigenvector</title></g>`;
    for (let j = 0; j < q; j++) g += `<g data-node="n${j}" style="cursor:pointer"><circle cx="260" cy="${yR(j)}" r="15" fill="var(--panel)" stroke="var(--ink)" stroke-width="1.5"/><text x="260" y="${yR(j) + 4}" text-anchor="middle" style="fill:var(--ink);font:600 11px var(--mono)">n${j + 1}</text><text x="286" y="${yR(j) + 4}" style="fill:var(--muted);font:11px var(--mono)">${room.N[j]}</text><title>column ${j + 1} (eigenvalue ${room.N[j]} of N). Click: gauge flip of this eigenvector</title></g>`;
    const svg = `<svg class="plot" viewBox="0 0 ${W} ${H}" role="img" aria-label="coupling graph of system ${which}">${g}</svg>`;
    const lab = (v) => (v < p ? `r${v + 1}` : `n${v - p + 1}`);
    const cycles = cyc ? cyc.cycles.map((c) => `<div class="stmt" style="grid-template-columns:5.5em 1fr"><div>${U().badge(c.sign > 0 ? "+1" : "−1", c.sign > 0 ? "b-forced" : "b-nogo")}</div><div class="mono">${c.loop.map(lab).join(" → ")}</div></div>`).join("") : "";
    return `${svg}<div class="note" style="margin-top:4px">Loop values (cycle signs) of ${which}: ${cyc ? (cyc.cycles.length ? "" : "none: the support graph is a forest") : "not defined (degenerate spectrum)"}</div>${cycles}
      ${cyc ? `<div class="note" style="margin-top:4px">room address in H¹(G; F₂): <b class="mono">${cyc.signature}</b> of ${cyc.rooms} rooms (E − V + c = ${cyc.E} − ${cyc.V} + ${cyc.components} = ${cyc.bits} bits)</div>` : ""}`;
  }
  const short = (arr, k) => "(" + arr.map((x) => U().fmt(x, k || 4)).join(", ") + ")";
  function renderRoom() {
    const { fmt, esc, badge } = U();
    let cmp;
    try { cmp = L3.compareRoom(sysOf("A"), sysOf("B")); } catch (e) { el("rmDoors").innerHTML = `<div class="err">${esc(e.message)}</div>`; return; }
    room.cmp = cmp;
    const cycA = cmp.cycles ? cmp.cycles.A : null, cycB = cmp.cycles ? cmp.cycles.B : null;
    el("rmGraphA").innerHTML = drawGraph("A", cycA);
    el("rmGraphB").innerHTML = room.scrambled ? `<div class="warn">System B is shown in scrambled coordinates (an exact rational rotation in O(p) × O(q)). Its matrices changed; its orbit did not. Reset the gauge to edit it again.</div><pre class="src" style="max-height:220px">R = ${esc(JSON.stringify(room.scrambled.R.map((r) => r.map(String))))}\nN = ${esc(JSON.stringify(room.scrambled.N.map((r) => r.map(String))))}\nC = ${esc(JSON.stringify(room.scrambled.C.map((r) => r.map(String))))}</pre>${cycB ? `<div class="note">room address read in its eigenbasis: <b class="mono">${cycB.signature}</b></div>` : ""}` : drawGraph("B", cycB);
    el("rmMsg").innerHTML = room.msg ? `<div class="ok">${room.msg}</div>` : "";
    const dA = cmp.descA, dB = cmp.descB, sep = cmp.separating;
    const rows = [
      ["spectra", "spectra of R and N", `${short(dA.spectraR, 3)} ${short(dA.spectraN, 3)}`, `${short(dB.spectraR, 3)} ${short(dB.spectraN, 3)}`, cmp.doors.spectra],
      ["magnitudes", "coupling magnitudes |C_ij| in eigenbases", short(dA.magnitudes.flat(), 3), short(dB.magnitudes.flat(), 3), cmp.doors.magnitudes],
      ["mixedTraces", "mixed traces tr(Rᵃ C Nᵇ Cᵀ), a, b ≤ 2", short(dA.mixedTraces.slice(0, 4), 4) + "…", short(dB.mixedTraces.slice(0, 4), 4) + "…", cmp.doors.mixedTraces],
      ["couplingSV", "singular values of C", short(dA.couplingSV, 5), short(dB.couplingSV, 5), cmp.doors.couplingSV],
      ["canonicalCorrelations", "canonical correlations", dA.canonicalCorrelations ? short(dA.canonicalCorrelations, 5) : "R or N not positive", dB.canonicalCorrelations ? short(dB.canonicalCorrelations, 5) : "—", cmp.doors.canonicalCorrelations],
      ["cycleSigns", "loop values (cycle signs)", cycA ? cycA.signature : "—", cycB ? cycB.signature : "—", cmp.cycles ? cmp.cycles.same : null],
      ["wordTraces", "ordered word traces (complete)", sep.word ? `tr(${wordHTML(sep.word)}) = ${sep.traceA}` : "all agree", sep.word ? `${sep.traceB}` : `algebra dim ${cmp.closure.dim}`, cmp.closure.equivalent],
    ];
    const chosen = Array.from(document.querySelectorAll("#rmDoors input[type=checkbox]:checked")).map((x) => x.dataset.k);
    const prevChosen = chosen.length ? chosen : ["spectra", "magnitudes", "mixedTraces", "couplingSV"];
    let h = `<div class="scroll"><table><tr><th>measure</th><th>door</th><th>system A</th><th>system B</th><th>result</th></tr>`;
    for (const [k, name, a, b, same] of rows) h += `<tr><td><input type="checkbox" data-k="${k}" ${prevChosen.includes(k) ? "checked" : ""} aria-label="measure ${esc(name)}"></td><td>${esc(name)}</td><td class="mono" style="font-size:.78rem">${esc(a)}</td><td class="mono" style="font-size:.78rem">${esc(b)}</td><td>${same === null ? badge("n/a", "b-open") : same ? badge("agree", "b-open") : badge("separates", "b-imported")}</td></tr>`;
    h += `</table></div>`;
    el("rmDoors").innerHTML = h;
    el("rmDoors").querySelectorAll("input").forEach((x) => x.addEventListener("change", renderVerdict));
    renderVerdict();
    el("rmWordOut").innerHTML = sep.word ? `<div class="ok">Shortest separating word: <b>tr(${wordHTML(sep.word)})</b>, exact values ${sep.traceA} and ${sep.traceB}, gap <b>${sep.gap}</b> (searched to length ${sep.searched}). The complete decision closes the paired word algebra at dimension ${cmp.closure.dim} ≤ 2n² = ${cmp.closure.dimMax}.</div>`
      : `<div class="note">No word up to length ${sep.searched} separates the systems, and the paired word algebra closes at dimension ${cmp.closure.dim} with all traces equal: A and B are the same orbit (Imported Theorem 18.2). They live in the same room.</div>`;
    runWord();
  }
  function renderVerdict() {
    const chosen = Array.from(document.querySelectorAll("#rmDoors input[type=checkbox]:checked")).map((x) => x.dataset.k);
    const r = chosen.length ? L3.descriptorRequest(room.cmp, chosen) : { status: "VACUOUS", answer: "no protocol is measured", why: "with no descriptor no task survives" };
    const cls = { LOCKED: "b-forced", CORRESPONDENCE: "b-gated", VACUOUS: "b-open" }[r.status];
    el("rmVerdict").innerHTML = `<div class="cert"><div class="cert-head"><b>Request: are A and B the same second-order datum?</b>${U().badge(r.status, cls)}</div><p style="margin:6px 0 2px"><b>${U().esc(r.answer)}</b></p><p class="note" style="margin:0">${U().esc(r.why)}</p></div>`;
  }
  function runWord() {
    const w = val("rmWord").toUpperCase().replace(/[^PDS]/g, "");
    if (!w) { el("rmWordEval").innerHTML = ""; return; }
    if (w.length > 24) { el("rmWordEval").innerHTML = `<div class="err">Keep words to 24 letters.</div>`; return; }
    const TA = L3.tuple(sysOf("A").R, sysOf("A").N, sysOf("A").C), TB = L3.tuple(sysOf("B").R, sysOf("B").N, sysOf("B").C);
    const a = L3.wordTraceExact(w, TA), b = L3.wordTraceExact(w, TB), d = a.sub(b);
    el("rmWordEval").innerHTML = `<dl class="kv"><dt>tr(${wordHTML(w)}) for A</dt><dd>${a.toString()}</dd><dt>for B</dt><dd>${b.toString()}</dd><dt>exact gap</dt><dd>${d.toString()}</dd></dl><p class="note">${d.isZero() ? "This word does not see the difference." : "This word opens the room: the gap is an exact rational, not a rounding effect."}</p>`;
  }
  function onGraphClick(which, ev) {
    if (which === "B" && room.scrambled) return;
    const e = ev.target.closest("[data-edge]"), n = ev.target.closest("[data-node]");
    const before = L3.cycleSigns(room[which]).signature;
    if (n) { const k = n.dataset.node, i = +k.slice(1); room[which] = k[0] === "r" ? L3.flipRow(room[which], i) : L3.flipCol(room[which], i);
      room.msg = `Gauge move on ${which}: the sign of eigenvector ${k} was flipped, so every edge at ${k} changed sign. Loop values ${before} → ${L3.cycleSigns(room[which]).signature}: unchanged, as are all word traces. You cannot leave a room by gauge moves.`; }
    else if (e) { const [i, j] = e.dataset.edge.split(",").map(Number); room[which] = room[which].map((r, a) => r.map((x, b) => (a === i && b === j ? x.neg() : x)));
      const after = L3.cycleSigns(room[which]).signature; room.msg = `Changed system ${which}: edge r${i + 1}–n${j + 1} flipped. Loop values ${before} → ${after}. ${before === after ? "This edge is a bridge: it lies on no cycle, so a gauge move can undo its flip and the room did not change." : "You walked through a wall into another room: spectra and magnitudes are unchanged."}`; }
    else return;
    renderRoom();
  }
  function applyRoomInputs() {
    try {
      const R = val("rmR").split(/[,\s]+/).filter(Boolean), N = val("rmN").split(/[,\s]+/).filter(Boolean);
      R.concat(N).forEach((x) => Q.parse(x));
      if (R.length !== room.A.length || N.length !== room.A[0].length) throw new Error(`keep ${room.A.length} values for R and ${room.A[0].length} for N, or pick another preset`);
      room.R = R; room.N = N; room.scrambled = null; room.msg = ""; renderRoom();
    } catch (e) { el("rmDoors").innerHTML = `<div class="err">${U().esc(e.message)}</div>`; }
  }
  function initRoom() {
    const sel = el("rmPreset"); Object.entries(PRESETS).forEach(([k, P]) => sel.insertAdjacentHTML("beforeend", `<option value="${k}">${U().esc(P.label)}</option>`));
    sel.addEventListener("change", () => loadPreset(sel.value));
    el("rmGraphA").addEventListener("click", (ev) => onGraphClick("A", ev)); el("rmGraphB").addEventListener("click", (ev) => onGraphClick("B", ev));
    el("rmApply").addEventListener("click", applyRoomInputs);
    el("rmScramble").addEventListener("click", () => { const s = L3.scramble(diagQ(room.R), diagQ(room.N), room.B, Math.floor(Math.random() * 1e6) + 1); room.scrambled = s; room.msg = "System B re-expressed in a random exact rational frame (Cayley transforms in O(p) and O(q)). Every door below reads the same as before."; renderRoom(); });
    el("rmUnscramble").addEventListener("click", () => { room.scrambled = null; room.msg = ""; renderRoom(); });
    el("rmCopy").addEventListener("click", () => { room.B = room.A.map((r) => r.slice()); room.scrambled = null; room.msg = "B := A. Same room by construction; now flip edges of B to find a room next door."; renderRoom(); });
    el("rmWord").addEventListener("input", runWord);
    loadPreset("witness");
  }

  // ================================================================ ROOMS OVER LOOPS
  let mobT = 0, mobAnim = null;
  function drawMobius() {
    const cv = el("mbCanvas"), ctx = cv.getContext("2d"), k = +val("mbK"), W = cv.width, H = cv.height, cs = getComputedStyle(document.documentElement);
    const col = (n) => cs.getPropertyValue(n).trim() || "#888";
    ctx.clearRect(0, 0, W, H);
    const tilt = 0.95, proj = (x, y, z) => [W / 2 + 150 * x, H / 2 + 150 * (y * Math.cos(tilt) - z * Math.sin(tilt)) * 0.9 + 0];
    const pt = (t, s) => { const rad = [Math.cos(t), Math.sin(t), 0], v = [Math.cos(k * t / 2) * rad[0], Math.cos(k * t / 2) * rad[1], Math.sin(k * t / 2)]; return proj(rad[0] + s * 0.32 * v[0], rad[1] + s * 0.32 * v[1], s * 0.32 * v[2]); };
    const n = 160;
    for (let i = 0; i < n; i++) {
      const t0 = 2 * Math.PI * i / n, t1 = 2 * Math.PI * (i + 1) / n, a = pt(t0, -1), b = pt(t0, 1), c = pt(t1, 1), d = pt(t1, -1);
      ctx.beginPath(); ctx.moveTo(...a); ctx.lineTo(...b); ctx.lineTo(...c); ctx.lineTo(...d); ctx.closePath();
      ctx.fillStyle = col("--t-declared-bg"); ctx.fill(); ctx.strokeStyle = col("--t-declared"); ctx.globalAlpha = 0.35; ctx.stroke(); ctx.globalAlpha = 1;
    }
    // transported frame along [0, mobT]
    ctx.lineWidth = 2.5;
    const steps = 24;
    for (let s = 0; s <= steps; s++) { const t = mobT * s / steps; const base = pt(t, 0), tip = pt(t, 1); ctx.strokeStyle = s === steps ? col("--t-nogo") : col("--t-forced"); ctx.globalAlpha = s === steps ? 1 : 0.35;
      ctx.beginPath(); ctx.moveTo(...base); ctx.lineTo(...tip); ctx.stroke(); ctx.beginPath(); ctx.arc(tip[0], tip[1], s === steps ? 4 : 2, 0, 2 * Math.PI); ctx.fillStyle = ctx.strokeStyle; ctx.fill(); }
    ctx.globalAlpha = 1; ctx.lineWidth = 1;
    const st = pt(0, 1), b0 = pt(0, 0); ctx.strokeStyle = col("--t-imported"); ctx.setLineDash([4, 3]); ctx.beginPath(); ctx.moveTo(...b0); ctx.lineTo(...st); ctx.stroke(); ctx.setLineDash([]);
    const m = L3.mobius(k, 400), fin = mobT >= 2 * Math.PI - 1e-9, { badge, fmt } = U();
    el("mbOut").innerHTML = `<dl class="kv"><dt>loop parameter t</dt><dd>${fmt(mobT / Math.PI, 3)} π</dd><dt>spectrum of the resolved projector</dt><dd>(0, 1), constant</dd><dt>canonical correlation, stabilizer</dt><dd>constant along the loop</dd>
      <dt>frame after a full loop</dt><dd>${m.returnSign < 0 ? "returns reversed" : "returns unchanged"}</dd><dt>w₁ of the resolved bundle</dt><dd>${m.w1}</dd></dl>
      ${m.w1 ? `<div class="ok">${badge("TWISTED", "b-gated")} Every local reading is the same as for the trivial family, yet the frame comes back reversed: the resolved line is a Möbius bundle. Local invariants are not complete (Corollary 17.8(3)); the global class is a real piece of the remainder.</div>` : `<div class="note" style="margin-top:6px">Even winding: the frame returns unchanged and the bundle is trivial. Local readings are identical to the odd case; only the loop tells them apart.</div>`}
      ${fin ? "" : `<p class="note">Drag the slider to t = 2π to complete the loop.</p>`}`;
  }
  function drawWall() {
    const { plot, fmt, badge } = U(), cx = +val("wlCx"), cy = +val("wlCy"), rad = +val("wlR");
    el("wlCxv").textContent = fmt(cx, 3); el("wlCyv").textContent = fmt(cy, 3); el("wlRv").textContent = fmt(rad, 3);
    const r = L3.wallLoop(cx, cy, rad, 1.0, 240), W = 340, H = 340, S = (v) => 170 + 150 * v, T = (v) => 170 - 150 * v;
    let g = `<line x1="20" y1="170" x2="320" y2="170" class="ax"/><line x1="170" y1="20" x2="170" y2="320" class="ax"/><text x="316" y="164" text-anchor="end">a</text><text x="176" y="30">b</text>`;
    g += `<circle cx="${S(0)}" cy="${T(0)}" r="6" fill="var(--t-nogo)"><title>wall: the two canonical correlations collide</title></circle>`;
    g += `<circle cx="${S(cx)}" cy="${T(cy)}" r="${150 * rad}" fill="none" stroke="var(--t-forced)" stroke-width="2"/>`;
    r.frames.filter((_, i) => i % 12 === 0).forEach((f, i) => { const x = S(f.a), y = T(f.b), L = 16; g += `<line x1="${x - L * f.u1[0]}" y1="${y + L * f.u1[1]}" x2="${x + L * f.u1[0]}" y2="${y - L * f.u1[1]}" stroke="var(--t-imported)" stroke-width="2"/><circle cx="${x + L * f.u1[0]}" cy="${y - L * f.u1[1]}" r="2.5" fill="var(--t-imported)"/>`; });
    const f0 = r.frames[0]; g += `<circle cx="${S(f0.a)}" cy="${T(f0.b)}" r="4" fill="var(--t-gated)"><title>start of the loop</title></circle>`;
    el("wlPlane").innerHTML = `<svg class="plot" viewBox="0 0 ${W} ${H}" role="img" aria-label="parameter plane">${g}</svg><div class="legend"><span><i style="background:var(--t-nogo)"></i>wall (collision)</span><span><i style="background:var(--t-forced)"></i>your loop</span><span><i style="background:var(--t-imported)"></i>first singular direction, carried continuously</span></div>`;
    const th = r.frames.map((_, i) => 360 * i / (r.frames.length - 1));
    plot(el("wlSig"), { series: [{ x: th, y: r.frames.map((f) => f.sigma[0]), color: "t-forced", label: "σ₁" }, { x: th, y: r.frames.map((f) => f.sigma[1]), color: "t-gated", label: "σ₂" }], xlabel: "position on the loop (degrees)", ylabel: "canonical correlations", height: 200, aria: "correlations along loop" });
    el("wlOut").innerHTML = `<dl class="kv"><dt>loop links the wall</dt><dd>${r.links ? "yes" : "no"}</dd><dt>w₁ of the σ₁ line, σ₂ line</dt><dd>${r.w1.join(", ")}</dd><dt>w₁ of their sum</dt><dd>${r.sumW1}</dd><dt>smallest gap σ₁ − σ₂ on the loop</dt><dd>${fmt(r.minGap, 4)}</dd></dl>
      ${r.links ? `<div class="ok">${badge("FORCED MONODROMY", "b-nogo")} Both singular lines come back reversed, while their sum (the whole plane) is trivial. The wall forces holonomy on the regular stratum around it (Proposition 17.10(2)). This is why the remainder across walls is still open (L131): any classification must carry it.</div>` : `<div class="note" style="margin-top:6px">The loop does not link the collision: both lines return unchanged. Move the loop over the red point.</div>`}`;
  }
  function initLoops() {
    el("mbK").addEventListener("change", drawMobius); el("mbT").addEventListener("input", () => { mobT = 2 * Math.PI * (+val("mbT")) / 1000; drawMobius(); });
    el("mbPlay").addEventListener("click", () => { if (mobAnim) { cancelAnimationFrame(mobAnim); mobAnim = null; return; } const t0 = performance.now();
      const step = (now) => { mobT = Math.min(2 * Math.PI, ((now - t0) / 4000) * 2 * Math.PI); el("mbT").value = Math.round(1000 * mobT / (2 * Math.PI)); drawMobius(); if (mobT < 2 * Math.PI) mobAnim = requestAnimationFrame(step); else mobAnim = null; };
      mobAnim = requestAnimationFrame(step); });
    ["wlCx", "wlCy", "wlR"].forEach((id) => el(id).addEventListener("input", drawWall));
    mobT = 2 * Math.PI; el("mbT").value = 1000; drawMobius(); drawWall();
  }

  // ================================================================ DOORS AND GATES
  function runComplement() {
    const { fmt, vec, mat, esc } = U();
    try {
      const R = mat(val("cpR")), N = mat(val("cpN")), C = mat(val("cpC")), K = mat(val("cpK"));
      const r = L3.complementAction(R, N, C, K), M = (A) => `<table style="width:auto">${A.map((row) => `<tr>${row.map((x) => `<td class="num">${fmt(x, 5)}</td>`).join("")}</tr>`).join("")}</table>`;
      const dG = Math.max(...r.before.G.flat().map((x, i) => Math.abs(x - r.after.G.flat()[i])));
      el("cpOut").innerHTML = `<div class="grid2"><div><h3>coupling C</h3>${M(r.before.C)}<p class="note">after T: C + K D</p>${M(r.after.C)}</div><div><h3>Fisher tensor G</h3>${M(r.before.G)}<p class="note">after T</p>${M(r.after.G)}<p class="note">largest change ${fmt(dG, 2)}</p></div></div>
        <div class="ok">The Fisher tensor and the null block do not move; the coupling does. "C = 0" is therefore not a property of the experiment but of the declared complement N (Proposition 17.4). Statements such as "blind to the null block at C_RN = 0" are relative to that declaration.</div>`;
    } catch (e) { el("cpOut").innerHTML = `<div class="err">${esc(e.message)}</div>`; }
  }
  function runStab() {
    const { esc, badge, vec } = U();
    try {
      const p = +val("stP"), q = +val("stQ"), corr = vec(val("stC")), s = L3.stabilizer(p, q, corr);
      el("stOut").innerHTML = `<dl class="kv"><dt>Aut</dt><dd>${s.factors.map((f) => f.group).join(" × ")}</dd><dt>dimension</dt><dd>${s.dim}</dd><dt>components π₀</dt><dd>Z₂^${s.kappa} (κ = ${s.kappa})</dd><dt>twisted classes over a loop</dt><dd>${s.classesOverCircle}</dd><dt>coupling rank</dt><dd>${s.r}</dd></dl>
        <div class="scroll"><table>${s.factors.map((f) => `<tr><td class="mono">${f.group}</td><td>${esc(f.label)}</td><td>${f.m > 0 ? badge("positive rank", "b-imported") : badge("empty", "b-open")}</td></tr>`).join("")}</table></div>`;
      const cases = [["C = 0", []], ["rank 1, distinct", [0.5]], ["rank 2, distinct", [0.5, 0.3]], ["rank 3, distinct", [0.5, 0.3, 0.1]], ["C = I/2", [0.5, 0.5, 0.5]]];
      el("stTable").innerHTML = `<table><tr><th>p = q = 3</th><th class="num">rank</th><th class="num">dim Aut</th><th class="num">classes over S¹</th></tr>${cases.map(([n, c]) => { const t = L3.stabilizer(3, 3, c); return `<tr><td>${n}</td><td class="num">${t.r}</td><td class="num">${t.dim}</td><td class="num">${t.classesOverCircle}</td></tr>`; }).join("")}</table>
        <p class="note">Paper: 4, 8, 16, 8 and 2 (Corollary 17.8(2)); rank 3 at C = I/2 has dimension 3, more than rank 1 (No-Go 17.6). Symmetry follows multiplicities, not rank.</p>`;
    } catch (e) { el("stOut").innerHTML = `<div class="err">${esc(e.message)}</div>`; }
  }
  function drawObserver() {
    const { fmt, badge } = U(), A = +val("obA"), a = +val("obBoost");
    el("obAv").textContent = fmt(A, 3); el("obBv").textContent = fmt(a, 3);
    const pw = L3.planeWave(A, a), E = pw.tidal, eps = 0.18 / Math.max(1, Math.abs(A) * Math.exp(2 * 1.5) / 2);
    let g = `<circle cx="160" cy="160" r="110" fill="none" stroke="var(--rule)" stroke-dasharray="4 4"/>`;
    for (let k = 0; k < 48; k++) { const th = 2 * Math.PI * k / 48, x = Math.cos(th), y = Math.sin(th), X = x * (1 - eps * E[0][0]), Y = y * (1 - eps * E[1][1]);
      g += `<circle cx="${160 + 110 * X}" cy="${160 - 110 * Y}" r="3.4" fill="var(--t-forced)"/>`; }
    g += `<text x="160" y="304" text-anchor="middle">transverse ring of test particles, as this observer measures it</text>`;
    el("obRing").innerHTML = `<svg class="plot" viewBox="0 0 320 320" role="img" aria-label="tidal deformation">${g}</svg>`;
    el("obOut").innerHTML = `<dl class="kv"><dt>Ricci tensor</dt><dd>0 (vacuum)</dd><dt>Kretschmann R_abcd R^abcd</dt><dd>0</dd><dt>every scalar curvature invariant</dt><dd>0</dd><dt>observer's u^u</dt><dd>${fmt(pw.uu, 4)}</dd><dt>tidal tensor eigenvalues</dt><dd>${fmt(E[0][0], 4)}, ${fmt(E[1][1], 4)}</dd></dl>
      <div class="ok">${badge("OBSERVER-RELATIVE", "b-gated")} Every scalar says "flat", yet the ring is squeezed, and how strongly depends on who looks (|E| = |A| e^{2a}/2). Scalar invariants do not classify Lorentzian curvature; a declared observer turns the curvature into a symmetric tuple under O(3), which the word-trace classifier handles (No-Go 18.6).</div>`;
    const M = +val("obM"), r = +val("obRr"), s1 = L3.schwarzschild(M, r), s2 = L3.schwarzschild(-M, r);
    el("obSchw").innerHTML = `<dl class="kv"><dt>tr E² for +M and −M</dt><dd>${fmt(s1.trE2, 5)} and ${fmt(s2.trE2, 5)}</dd><dt>M recovered by −r³ tr E³ / tr E²</dt><dd>${fmt(s1.recoveredM, 6)} and ${fmt(s2.recoveredM, 6)}</dd></dl><p class="note">The quadratic invariant cannot tell M from −M; the cubic word restores the sign. Shorter descriptors lose orbits (Corollary 18.5).</p>`;
  }
  function renderDispatcher() {
    const { badge, esc } = U(), ch = {};
    L3.GATES.forEach((g) => { ch[g.key] = +val("dg_" + g.key); });
    const r = L3.dispatch(ch), cls = { LOCKED: "b-forced", ESCALATE: "b-open", CORRESPONDENCE: "b-gated", VACUOUS: "b-open", INCONSISTENT: "b-nogo", "STRUCTURAL WALL": "b-nogo", "OUTSIDE DOMAIN": "b-input" }[r.status];
    el("dgOut").innerHTML = `<div class="cert"><div class="cert-head"><b>status</b>${badge(r.status, cls)}</div><p class="note" style="margin:6px 0 0">${r.gate ? `First gate not certified, in dependency order: <b>${esc(r.gate)}</b> (${esc(r.outcome)}).` : "Every gate is certified."} The dispatcher returns exactly one status for every combination and LOCKED only when every gate passes (Theorem 16.2).</p></div>`;
    const all = L3.dispatchAll(), cnt = {}; all.forEach((x) => { cnt[x.status] = (cnt[x.status] || 0) + 1; });
    el("dgAll").innerHTML = `<table><tr><th>status</th><th class="num">combinations</th></tr>${Object.entries(cnt).map(([k, v]) => `<tr><td>${esc(k)}</td><td class="num">${v}</td></tr>`).join("")}<tr><td><b>total</b></td><td class="num"><b>${all.length}</b></td></tr></table><p class="note">This site's gate design has ${all.length} combinations; the paper's has 384. The gate outcomes are this page's declaration; the properties checked are the theorem's.</p>`;
  }
  function runSound() {
    const { fmt, vec } = U(), al = vec(val("dgAlpha")), s = L3.soundnessSim(al, +val("dgP"), 100000, 7);
    el("dgSound").innerHTML = `<dl class="kv"><dt>false LOCKED rate</dt><dd>${fmt(s.falseLockRate, 4)}</dd><dt>bound Σ α_g</dt><dd>${fmt(s.bound, 4)}</dd><dt>locked / truly lockable</dt><dd>${s.locked} / ${s.lockable} of ${s.trials}</dd></dl><p class="note">Closure is exactly as sound as its weakest certificate (Theorem 16.3).</p>`;
  }
  function initGates() {
    ["cpR", "cpN", "cpC", "cpK"].forEach((id) => el(id).addEventListener("input", runComplement));
    el("cpZero").addEventListener("click", () => { const { mat } = U(); const C = mat(val("cpC")), N = mat(val("cpN"));
      const Ni = window.RGLabs.pinvSym(N, 1e-14), K = window.RGLabs.matmul(C, Ni).map((r) => r.map((x) => -x)); el("cpK").value = K.map((r) => r.map((x) => +x.toPrecision(15)).join(" ")).join("\n"); runComplement(); });
    ["stP", "stQ", "stC"].forEach((id) => el(id).addEventListener("input", runStab));
    ["obA", "obBoost", "obM", "obRr"].forEach((id) => el(id).addEventListener("input", drawObserver));
    const host = el("dgGates");
    host.innerHTML = L3.GATES.map((g, i) => `<label class="f">${i + 1}. ${g.label}<select id="dg_${g.key}">${g.options.map((o, k) => `<option value="${k}">${o[0]}</option>`).join("")}</select></label>`).join("");
    L3.GATES.forEach((g) => el("dg_" + g.key).addEventListener("change", renderDispatcher));
    el("dgRun").addEventListener("click", runSound);
    runComplement(); runStab(); drawObserver(); renderDispatcher(); runSound();
  }

  window.RG_VIEWS_EXTRA = Object.assign(window.RG_VIEWS_EXTRA || {}, { room: initRoom, loops: initLoops, gates: initGates });
})();
