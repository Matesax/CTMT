(function () {
  "use strict";
  const L2 = window.RGLabs2;
  const U = () => window.RGUI;
  const num = (id) => +document.getElementById(id).value;
  const val = (id) => document.getElementById(id).value;
  const el = (id) => document.getElementById(id);
  const VB = { CONDITIONAL: "b-gated", REJECTED: "b-nogo", "NOT REJECTED": "b-imported", WALL: "b-nogo", FORCED: "b-forced", CONSISTENT: "b-imported", TENSION: "b-gated", INCONSISTENT: "b-nogo" };

  // ================================================================ ROUTING
  let route = null;
  function readInstance() {
    const which = val("rtInst");
    if (which === "random") {
      const r = window.RGCalc.mulberry32(num("rtSeed")), n = Math.max(4, Math.min(200, num("rtN")));
      const coords = [...Array(n)].map(() => [r() * 100, r() * 100]);
      return { coords, D: L2.euclid(coords), metric: "euclid", optimum: null, source: `${n} uniform random points in a 100 × 100 square, seed ${num("rtSeed")}` };
    }
    if (which === "custom") {
      const coords = val("rtCustom").trim().split(/\n+/).map((l) => l.trim().split(/[\s,;]+/).map(Number)).filter((p) => p.length >= 2 && p.every(isFinite)).map((p) => [p[0], p[1]]);
      if (coords.length < 3) throw new Error("enter at least three stops, one 'a b' pair per line");
      if (coords.length > 200) throw new Error("at most 200 stops");
      const m = val("rtMetric"), D = m === "geo" ? L2.tsplibGeo(coords) : m === "haversine" ? L2.haversine(coords) : L2.euclid(coords);
      return { coords, D, metric: m, optimum: null, source: "your stops" };
    }
    const I = L2.INSTANCES[which], D = I.metric === "geo" ? L2.tsplibGeo(I.coords) : L2.haversine(I.coords);
    return { coords: I.coords, D, metric: I.metric, optimum: I.optimum, source: I.source, names: I.names };
  }
  function drawTour(coords, tour, metric, extra) {
    const pts = tour.concat([tour[0]]).map((i) => coords[i]), geo = metric !== "euclid";
    const xs = pts.map((p) => (geo ? p[1] : p[0])), ys = pts.map((p) => (geo ? p[0] : p[1]));
    const series = [{ x: xs, y: ys, color: "t-forced", label: "tour", points: true }];
    if (extra) series.push(extra);
    U().plot(el("rtPlot"), { series, xlabel: geo ? "longitude (°)" : "x", ylabel: geo ? "latitude (°)" : "y", height: 330, aria: "tour map" });
  }
  function runRouting() {
    const out = el("rtOut"), { fmt, esc, badge } = U();
    try {
      const inst = readInstance(), n = inst.D.length;
      if (n > 17 && n > 120) out.innerHTML = `<p class="note">Solving ${n} stops…</p>`;
      const s = L2.solve(inst.D, { exactMax: 16, restarts: n > 80 ? 4 : 10, kicks: n > 80 ? 15 : 30, seed: 1 });
      route = { inst, s };
      const unitName = inst.metric === "haversine" ? " km" : inst.metric === "geo" ? " (TSPLIB GEO units, km)" : "";
      let h = `<dl class="kv"><dt>stops</dt><dd>${n}</dd><dt>method</dt><dd style="font-family:var(--sans)">${esc(s.method)}</dd><dt>tour length</dt><dd>${fmt(s.cost, 7)}${unitName}</dd>`;
      h += `<dt>certified lower bound</dt><dd>${fmt(s.lowerBound, 7)}</dd><dt>optimality gap</dt><dd>${s.method.startsWith("exact") ? "0 (exact)" : fmt(100 * s.gap, 3) + "%"}</dd><dt>time</dt><dd>${s.ms} ms</dd></dl>`;
      if (inst.optimum !== null) h += Math.abs(s.cost - inst.optimum) < 1e-9 ? `<div class="ok">${badge("CONSISTENT", "b-imported")} Reproduces the published optimum ${inst.optimum} of ${esc(inst.source)} exactly.</div>` : `<div class="err">${badge("INCONSISTENT", "b-nogo")} Published optimum ${inst.optimum}, computed ${s.cost}.</div>`;
      else h += `<p class="note" style="margin-top:8px">${esc(inst.source)}. ${s.method.startsWith("exact") ? "The tour is optimal." : "The Held–Karp 1-tree bound is valid for every penalty vector, so the true optimum lies between the bound and the tour length."}</p>`;
      if (inst.names) h += `<p class="note">Order: ${s.tour.map((i) => esc(inst.names[i])).join(" → ")} → ${esc(inst.names[s.tour[0]])}</p>`;
      out.innerHTML = h;
      drawTour(inst.coords, s.tour, inst.metric);
      el("rtKernelWrap").style.display = val("rtInst") === "centralEurope" ? "" : "none";
      el("rtUncOut").innerHTML = `<p class="note">Run the uncertainty analysis for the current instance.</p>`;
      if (val("rtInst") === "centralEurope") runKernel();
    } catch (e) { out.innerHTML = `<div class="err">${esc(e.message)}</div>`; }
  }
  function runRouteUnc() {
    const { fmt, esc } = U(), out = el("rtUncOut");
    if (!route) return;
    const n = route.inst.D.length;
    if (n > 40) { out.innerHTML = `<div class="warn">Uncertainty analysis re-solves the route for every sample; keep it to 40 stops or fewer here.</div>`; return; }
    const r = L2.routeUncertainty(route.inst.D, { rel: num("rtRel") / 100, law: val("rtLaw"), samples: Math.min(400, num("rtS")), seed: num("rtUSeed"), exactMax: 12 });
    out.innerHTML = `<dl class="kv"><dt>nominal optimum</dt><dd>${fmt(r.nominal, 6)}</dd><dt>linearized σ of that tour's length</dt><dd>${fmt(r.sigmaLin, 4)}</dd>
      <dt>sampled optimum (mean ± σ)</dt><dd>${fmt(r.optMean, 6)} ± ${fmt(r.optSd, 4)}</dd><dt>90% range of the optimum</dt><dd>${fmt(r.opt05, 6)} to ${fmt(r.opt95, 6)}</dd>
      <dt>Jensen gap (nominal − E[optimum])</dt><dd>${fmt(r.jensenGap, 4)}</dd><dt>probability the nominal tour stays optimal</dt><dd>${fmt(100 * r.pNominalOptimal, 3)}%</dd>
      <dt>distinct optimal tours seen</dt><dd>${r.distinctOptima} in ${r.samples} samples</dd><dt>regret of keeping the nominal tour</dt><dd>mean ${fmt(r.regretMean, 4)}, 95% ${fmt(r.regret95, 4)}</dd></dl>
      <div class="scroll" style="margin-top:8px"><table><tr><th>most frequent optimal tours</th><th class="num">share</th></tr>${r.topTours.map((t) => `<tr><td class="mono">${esc(t.tour)}${t.isNominal ? " (nominal)" : ""}</td><td class="num">${fmt(100 * t.share, 3)}%</td></tr>`).join("")}</table></div>
      <p class="note" style="margin-top:8px">${r.exact ? "Each sample solved exactly." : "Each sample solved by the heuristic (upper bounds), because n > 12."} The optimal length is a minimum over tours: concave, with kinks where tours tie. Linearizing it around the nominal tour assumes that tour stays optimal; the Jensen gap and the share of other tours show by how much that fails. This is the routing form of a wall (UG04).</p>`;
  }
  function runKernel() {
    const { fmt, esc } = U(), inst = readInstance();
    const LK = num("rtLK"), k = L2.kernelRhythmCost(inst.D, 0, LK, num("rtMu"), num("rtDphi"), num("rtG")), sk = L2.solve(k.C), sd = L2.solve(inst.D);
    const same = L2.canon(sk.tour) === L2.canon(sd.tour), kLen = L2.tourCost(inst.D, sk.tour);
    let best = Infinity; const names = inst.names;
    const perm = (a, l = 0) => { if (l === a.length) { let c = 0; for (let i = 0; i + 1 < a.length; i++) c += inst.D[a[i]][a[i + 1]]; best = Math.min(best, c); return; } for (let i = l; i < a.length; i++) { [a[l], a[i]] = [a[i], a[l]]; perm(a, l + 1); [a[l], a[i]] = [a[i], a[l]]; } };
    perm([0, 1, 2, 3, 4]);
    el("rtKernelOut").innerHTML = `<dl class="kv"><dt>phases Φᵢ = dᵢ / L_K</dt><dd>${k.Phi.map((x) => fmt(x, 4)).join(", ")}</dd><dt>largest similarity S</dt><dd>${fmt(k.maxS, 3)}</dd>
      <dt>largest relative change of any edge cost</dt><dd>${fmt(k.maxRelChange, 3)}</dd><dt>kernel tour</dt><dd style="font-family:var(--sans)">${sk.tour.map((i) => esc(names[i])).join(" → ")}</dd><dt>its real length</dt><dd>${fmt(kLen, 6)} km</dd><dt>same tour as classical TSP</dt><dd>${same ? "yes" : "no"}</dd></dl>
      ${LK < 1 ? `<div class="warn">With the retired page's L_K = 250 m the phases are in the hundreds, S underflows to about e^(−300), and the kernel cost matrix is the distance matrix. Kernel routing cannot differ from classical TSP, so its table (645 versus 662 km, 7 h 20 versus 6 h 55) cannot come from the stated parameters. Raise L_K to tens of kilometres and the costs change, but then the tour is chosen by a rescaled cost, not by distance: any real saving must be shown with measured travel times.</div>` : `<div class="note" style="margin-top:6px">${same ? "Same tour as distance-optimal routing." : "A different tour, chosen by the rescaled cost; its real length is longer than the distance optimum. Whether it saves time or fuel is an empirical claim about the road network, not something the cost matrix can show."}</div>`}
      <div class="warn">Geometric floor: the shortest closed tour through these five city centres is ${fmt(sd.cost, 5)} km in straight lines, and the shortest open path is ${fmt(best, 5)} km. A closed postal round of 645 km is impossible on real roads; an open route of 645 road-km is possible. The retired text does not say which it meant.</div>`;
  }
  function initRouting() {
    el("rtRun").addEventListener("click", runRouting);
    el("rtUncRun").addEventListener("click", runRouteUnc);
    el("rtKRun").addEventListener("click", runKernel);
    el("rtInst").addEventListener("change", () => { el("rtCustomWrap").style.display = val("rtInst") === "custom" ? "" : "none"; el("rtRandWrap").style.display = val("rtInst") === "random" ? "" : "none"; runRouting(); });
    runRouting();
  }

  // ================================================================ CHI channel
  function parseParams(text) { const o = {}; text.split(/\n+/).forEach((l) => { const m = l.match(/^\s*([A-Za-z0-9_]+)\s*=\s*([^#]+)/); if (m) { const v = m[2].trim(); o[m[1]] = isFinite(+v) ? +v : v; } }); return o; }
  function fillChiParams() { const P = L2.CHI_PRESETS[val("chiPreset")]; el("chiParams").value = Object.entries(P.params).map(([k, v]) => `${k} = ${v}`).join("\n"); el("chiAnchors").value = P.anchors.join(" "); el("chiPredict").value = P.predict.join(" "); }
  function runChi() {
    const { fmt, esc, badge, plot, vec } = U(), out = el("chiOut");
    try {
      const preset = val("chiPreset"), P = L2.CHI_PRESETS[preset];
      const r = L2.chiChannel(preset, { params: parseParams(val("chiParams")), anchors: vec(val("chiAnchors")), predict: vec(val("chiPredict")), noise: num("chiNoise") / 100, seed: num("chiSeed"), truthIsChi: el("chiControl").checked });
      let h = `<div class="cert-head"><b>${esc(r.label)}</b>${badge(r.verdict, VB[r.verdict])}</div><p class="note" style="margin:4px 0 8px">${esc(r.why)}</p>`;
      h += `<dl class="kv"><dt>calibrated k</dt><dd>${fmt(r.k, 5)} ± ${fmt(r.sk, 3)}</dd>${r.fit ? `<dt>free exponent q in y ∝ χ^q</dt><dd>${fmt(r.fit.q, 4)} ± ${fmt(r.fit.sq, 3)} (the χ law asserts q = 1)</dd>` : ""}<dt>rank hazard λmin/λmax</dt><dd>${r.anchors.length > 1 ? fmt(r.hazard, 3) : "0 (one anchor: rank 1)"}</dd>`;
      if (r.rhoElastTruth !== null) h += `<dt>∂log y / ∂log ρ, reference law</dt><dd>${fmt(r.rhoElastTruth, 4)}</dd><dt>∂log y / ∂log ρ, χ channel</dt><dd>${fmt(r.rhoElastChi, 4)}</dd>`;
      h += `</dl>`;
      if (r.rhoElastTruth !== null && Math.abs(r.rhoElastTruth - r.rhoElastChi) > 0.2) h += `<div class="warn">The χ channel responds to air density ${r.rhoElastChi === 0 || Math.abs(r.rhoElastChi) < 1e-9 ? "not at all" : "with the wrong sign or size"}: ${preset === "wind" ? "with M = ρAv the density cancels, while turbine power is proportional to ρ (36% overprediction at ρ = 0.9)" : "χ divides by ρ, so denser air lowers predicted fuel, while aerodynamic drag raises it"}. Moving to another altitude or temperature is a transport the channel gets wrong.</div>`;
      h += `<div class="scroll" style="margin-top:8px"><table><tr><th class="num">${esc(P.xName)}</th><th class="num">reference law</th><th class="num">χ channel</th><th class="num">error</th></tr>${r.predictions.map((q) => `<tr><td class="num">${fmt(q.x, 4)}</td><td class="num">${fmt(q.truth, 5)}</td><td class="num">${fmt(q.chi, 5)}</td><td class="num">${fmt(100 * q.err, 3)}%</td></tr>`).join("")}</table></div>`;
      h += `<p class="note" style="margin-top:8px">Anchors are generated from the reference law (${el("chiControl").checked ? "here replaced by the χ law itself, as a control" : "an established engineering law with declared parameters, not measured data"}) with ${num("chiNoise")}% measurement noise. With one anchor and unchanged Φ, h, ρ, g the prediction does not depend on Φ, h, ρ or g at all: they cancel in k·χ.</p>`;
      out.innerHTML = h;
      const c = r.curve;
      plot(el("chiPlot"), { series: [{ x: c.map((q) => q.x), y: c.map((q) => q.truth), color: "t-imported", label: "reference law" }, { x: c.map((q) => q.x), y: c.map((q) => q.chi), color: "t-nogo", dash: true, label: "χ channel, calibrated" },
        { x: r.anchors.map((a) => a.x), y: r.anchors.map((a) => a.y), color: "t-forced", pointsOnly: true, label: "anchors" }], xlabel: P.xName, ylabel: P.yName, height: 300, aria: "chi channel" });
    } catch (e) { out.innerHTML = `<div class="err">${esc(e.message)}</div>`; }
  }
  function runBottleneck() {
    const { fmt, vec } = U(), b = L2.bottleneck(vec(val("bnVals")).filter((x) => x > 0));
    el("bnOut").innerHTML = `<dl class="kv"><dt>harmonic (series) combination</dt><dd>${fmt(b.harmonic, 5)}</dd><dt>minimum</dt><dd>${fmt(b.min, 5)}</dd><dt>mean</dt><dd>${fmt(b.mean, 5)}</dd></dl>
      <div class="${b.claimHolds ? "ok" : "warn"}">${b.claimHolds ? "Here χ_eff ≤ χ_min holds, which happens only when all values are equal." : "χ_eff > χ_min: the early bottleneck claim χ_eff ≤ χ_min is false. The harmonic mean always lies between the minimum and the mean (UG09)."}</div>`;
  }
  function initChi() {
    el("chiPreset").addEventListener("change", () => { fillChiParams(); runChi(); });
    el("chiRun").addEventListener("click", runChi); el("chiControl").addEventListener("change", runChi); el("bnRun").addEventListener("click", runBottleneck);
    fillChiParams(); runChi(); runBottleneck();
  }

  // ================================================================ WIND
  function fillTurbine() { const t = L2.TURBINES[val("wtPreset")]; ["D", "rated", "cutIn", "cutOut", "cp", "eta"].forEach((k) => { el("wt_" + k).value = +t[k].toPrecision(6); }); }
  function runWind() {
    const { fmt, esc, badge, plot } = U(), out = el("wtOut");
    try {
      const alt = num("wtAlt"), rho = val("wtRhoMode") === "isa" ? L2.isaDensity(alt) : num("wtRho");
      const t = { D: num("wt_D"), rated: num("wt_rated"), cutIn: num("wt_cutIn"), cutOut: num("wt_cutOut"), cp: num("wt_cp"), eta: num("wt_eta"), rho };
      const site = { vmean: num("wtV"), k: num("wtK") };
      if (!(t.D > 0 && t.rated > 0 && t.cutOut > t.cutIn && site.vmean > 0 && site.k > 1)) throw new Error("check the inputs: positive sizes, cut-out above cut-in, Weibull k above 1");
      const r = L2.turbineReport(t, site);
      if (r.error) { out.innerHTML = `<div class="err">${esc(r.error)}</div>`; el("wtPlot").innerHTML = ""; return; }
      const pf = L2.patternFactor(site.k), pub = L2.TURBINES[val("wtPreset")].publishedRated;
      let h = `<dl class="kv"><dt>air density</dt><dd>${fmt(rho, 5)} kg/m³${val("wtRhoMode") === "isa" ? ` (ISA at ${alt} m)` : ""}</dd><dt>rated wind speed (actuator disc)</dt><dd>${fmt(r.vRated, 5)} m/s</dd>
        <dt>mean power</dt><dd>${fmt(r.meanPower / 1e3, 5)} kW</dd><dt>annual energy (8766 h)</dt><dd>${fmt(r.aep / 1e6, 5)} MWh</dd><dt>capacity factor</dt><dd>${fmt(100 * r.cf, 4)}%</dd>
        <dt>power at the mean wind speed</dt><dd>${fmt(r.powerAtMean / 1e3, 5)} kW</dd><dt>mean power / power at mean wind</dt><dd>${fmt(r.jensenRatio, 4)}</dd></dl>`;
      if (pub) { const z = (r.vRated - pub) / Math.sqrt((0.04 / 3 * r.vRated) ** 2 + 0.1 ** 2); h += `<div class="${Math.abs(z) < 2 ? "ok" : "warn"}">${badge(Math.abs(z) < 2 ? "CONSISTENT" : "TENSION", Math.abs(z) < 2 ? "b-imported" : "b-gated")} Published rated speed ${pub} m/s (Jonkman et al. 2009); computed ${fmt(r.vRated, 4)} m/s, z = ${fmt(z, 3)} with Cp ± 0.02 declared and ± 0.1 m/s on the reference. The actuator-disc value uses peak Cp; the real controller reaches rated at lower Cp, so the small shortfall has the expected sign.</div>`; }
      h += `<div class="ok">Energy pattern factor E[v³]/v̄³ for Weibull k = ${site.k}: exact Γ(1 + 3/k)/Γ(1 + 1/k)³ = ${fmt(pf.exact, 7)}, numerical ${fmt(pf.numeric, 7)}${Math.abs(site.k - 2) < 1e-9 ? " (Rayleigh: 6/π = 1.909859)" : ""}. Using the mean wind speed in P ∝ v³ underestimates the energy by this factor below rated; the rated cap and cut-out reduce the ratio to the ${fmt(r.jensenRatio, 4)} shown.</div>`;
      out.innerHTML = h;
      const c = r.curve, cc = site.vmean / L2.gammaFn(1 + 1 / site.k), pmax = Math.max(...c.map((q) => q.P));
      plot(el("wtPlot"), { series: [{ x: c.map((q) => q.v), y: c.map((q) => q.P / 1e3), color: "t-forced", label: "power curve (kW)" },
        { x: c.map((q) => q.v), y: c.map((q) => L2.weibullPdf(q.v, site.k, cc) * pmax / 1e3 / 0.15), color: "t-gated", dash: true, label: "wind-speed density (scaled)" }], xlabel: "wind speed (m/s)", ylabel: "kW", height: 280, aria: "power curve" });
      el("wtMcOut").innerHTML = `<p class="note">Run the uncertainty analysis to see P50 and P90.</p>`;
      el("wtMcRun").onclick = () => {
        const fams = val("wtFam").split(/[\s,]+/).filter(Boolean), N = Math.min(20000, num("wtN")), unc = { vmean: num("wtUv") / 100, k: num("wtUk") / 100, cp: num("wtUcp") / 100, rho: num("wtUrho") / 100 };
        const mc = L2.turbineMC(t, site, unc, fams, N, num("wtSeed")), ref = mc[0], tol = 0.1;
        const spread = (key) => Math.max(...mc.map((m) => Math.abs(m[key] - ref[key]))) / ref.sd;
        const st = (name, key) => { const s = spread(key), need = key === "mean" ? 1800 : 12800; const v = fams.length < 2 ? "UNCERTIFIED" : N < need ? "UNRESOLVED" : s <= tol ? "FORCED" : "CONDITIONAL";
          return `<div class="stmt"><div>${badge(v, v === "FORCED" ? "b-forced" : v === "CONDITIONAL" ? "b-gated" : "b-open")}</div><div><b>${name}</b>: spread ${fmt(s, 3)}σ over {${fams.join(", ")}}${N < need ? `; needs ≥ ${need} samples per law` : ""}</div></div>`; };
        el("wtMcOut").innerHTML = `<div class="scroll"><table><tr><th>declared law</th><th class="num">mean AEP</th><th class="num">σ</th><th class="num">P50</th><th class="num">P90</th><th class="num">P99</th></tr>${mc.map((m) => `<tr><td>${esc(m.law)}</td><td class="num">${fmt(m.mean / 1e6, 5)}</td><td class="num">${fmt(m.sd / 1e6, 4)}</td><td class="num">${fmt(m.p50 / 1e6, 5)}</td><td class="num">${fmt(m.p90 / 1e6, 5)}</td><td class="num">${fmt(m.p99 / 1e6, 5)}</td></tr>`).join("")}</table></div><p class="note">MWh per year. P90 is the value exceeded with 90% probability, the figure lenders use.</p>${st("mean AEP", "mean")}${st("P90", "p90")}${st("P99", "p99")}<p class="note" style="margin-top:6px">Tail statements such as P90 and P99 depend on the declared shape of the input uncertainty, not only on its size.</p>`;
      };
    } catch (e) { out.innerHTML = `<div class="err">${esc(e.message)}</div>`; }
  }
  function initWind() {
    el("wtPreset").addEventListener("change", () => { fillTurbine(); runWind(); });
    document.querySelectorAll("#v-wind .row input, #v-wind .row select").forEach((x) => { if (!x.id.startsWith("wtU") && !["wtFam", "wtN", "wtSeed", "wtPreset"].includes(x.id)) x.addEventListener("change", runWind); });
    fillTurbine(); runWind();
  }

  // ================================================================ FUEL
  function fuelParams() {
    const alt = num("fcAlt"), rho = 101325 * Math.pow(1 - 2.25577e-5 * alt, 5.25588) / (287.05 * (num("fcT") + 273.15));
    return { mode: val("fcMode"), m: num("fc_m"), crr: num("fc_crr"), cda: num("fc_cda"), A: num("fc_A"), B: num("fc_B"), C: num("fc_C"), rho, etaDt: num("fc_eta"), e: num("fc_e"), P0: num("fc_P0") * 1000, paux: num("fc_aux") * 1000,
      lhv: val("fcFuel") === "diesel" ? 35.8 : 32.0, grade: num("fcGrade") / 100 };
  }
  function runFuel() {
    const { fmt, esc, badge, plot } = U(), out = el("fcOut");
    try {
      el("fcPhys").style.display = val("fcMode") === "epa" ? "none" : ""; el("fcEpa").style.display = val("fcMode") === "epa" ? "" : "none";
      const p = fuelParams(), kmh = num("fcV"), r = L2.fuelReport(p, kmh), anchor = num("fcAnchor");
      const chiAt = (k) => L2.fuelPer100(anchor / 3.6, p) * (k / anchor);   // χ ∝ v² fuel rate  ⇒  L/100 km ∝ v
      let h = `<dl class="kv"><dt>air density</dt><dd>${fmt(p.rho, 5)} kg/m³</dd><dt>fuel at ${kmh} km/h</dt><dd>${fmt(r.at, 4)} L/100 km</dd><dt>road-load power at the wheels</dt><dd>${fmt(r.wheelPower / 1e3, 4)} kW</dd>`;
      if (r.aeroPower !== null) h += `<dt>aerodynamic share of wheel power</dt><dd>${fmt(100 * r.aeroPower / (r.aeroPower + r.rollPower), 3)}%</dd>`;
      h += `<dt>share of fuel power that is base (idle, friction)</dt><dd>${fmt(100 * r.basePowerShare, 3)}%</dd><dt>lowest consumption in this model</dt><dd>${fmt(r.best.L, 4)} L/100 km at ${r.best.kmh} km/h</dd>
        <dt>χ channel calibrated at ${anchor} km/h, predicting ${kmh} km/h</dt><dd>${fmt(chiAt(kmh), 4)} L/100 km (${fmt(100 * (chiAt(kmh) - r.at) / r.at, 3)}%)</dd></dl>
        <p class="note" style="margin-top:8px">Reference law: road load (rolling resistance + ½ρ C_dA v², or EPA coast-down A + Bv + Cv²) through drivetrain efficiency into a Willans-line engine (base fuel power + brake power / marginal efficiency). All parameters are declarations; the EPA mode lets you enter the coast-down coefficients published for a specific vehicle (EPA test car list, lbf, lbf/mph, lbf/mph²). No gear model: the low-speed optimum is a property of the declared engine line, not of a real gearbox.</p>`;
      out.innerHTML = h;
      const fams = val("fcFam").split(/[\s,]+/).filter(Boolean), N = Math.min(20000, num("fcN")), unc = { cda: num("fcUcda") / 100, crr: num("fcUcrr") / 100, load: num("fcUcda") / 100, e: num("fcUe") / 100, P0: num("fcUP0") / 100 };
      const ks = r.curve.map((c) => c.kmh), mc = L2.fuelMC(p, unc, fams, ks, N, num("fcSeed"));
      const band = mc[0].rows;
      plot(el("fcPlot"), { series: [{ x: ks, y: r.curve.map((c) => c.L), color: "t-forced", label: "reference law" }, { x: ks, y: band.map((b) => b.q05), color: "t-open", dash: true, label: `5–95% (${fams[0]})` }, { x: ks, y: band.map((b) => b.q95), color: "t-open", dash: true },
        { x: ks, y: ks.map(chiAt), color: "t-nogo", dash: true, label: `χ channel, one anchor at ${anchor} km/h` }], xlabel: "speed (km/h)", ylabel: "L/100 km", height: 300, aria: "fuel curve" });
      const idx = ks.reduce((bi, k, i) => (Math.abs(k - kmh) < Math.abs(ks[bi] - kmh) ? i : bi), 0), ref = mc[0].rows[idx], tol = 0.1;
      const spread = (key) => Math.max(...mc.map((m) => Math.abs(m.rows[idx][key] - ref[key]))) / ref.sd;
      const st = (name, keys, need) => { const s = Math.max(...keys.map(spread)); const v = fams.length < 2 ? "UNCERTIFIED" : N < need ? "UNRESOLVED" : s <= tol ? "FORCED" : "CONDITIONAL";
        return `<div class="stmt"><div>${badge(v, v === "FORCED" ? "b-forced" : v === "CONDITIONAL" ? "b-gated" : "b-open")}</div><div><b>${name}</b> at ${ks[idx]} km/h: spread ${fmt(s, 3)}σ over {${fams.join(", ")}}${N < need ? `; needs ≥ ${need} samples per law` : ""}</div></div>`; };
      el("fcMcOut").innerHTML = `<div class="scroll"><table><tr><th>declared law</th><th class="num">mean</th><th class="num">σ</th><th class="num">5%</th><th class="num">95%</th></tr>${mc.map((m) => `<tr><td>${esc(m.law)}</td><td class="num">${fmt(m.rows[idx].mean, 5)}</td><td class="num">${fmt(m.rows[idx].sd, 3)}</td><td class="num">${fmt(m.rows[idx].q05, 5)}</td><td class="num">${fmt(m.rows[idx].q95, 5)}</td></tr>`).join("")}</table></div>${st("mean ± σ", ["mean", "sd"], 1800)}${st("90% band", ["q05", "q95"], 12800)}`;
    } catch (e) { out.innerHTML = `<div class="err">${esc(e.message)}</div>`; }
  }
  function initFuel() { document.querySelectorAll("#v-fuel input, #v-fuel select").forEach((x) => x.addEventListener("change", runFuel)); runFuel(); }

  window.RG_VIEWS_EXTRA = { routing: initRouting, chi: initChi, wind: initWind, fuel: initFuel };
})();
