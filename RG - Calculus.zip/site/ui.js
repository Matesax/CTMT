(function () {
  "use strict";
  const C = window.RGCalc, L = window.RGLabs;
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const SUP = { "-": "⁻", 0: "⁰", 1: "¹", 2: "²", 3: "³", 4: "⁴", 5: "⁵", 6: "⁶", 7: "⁷", 8: "⁸", 9: "⁹" };
  function fmt(x, p) {
    p = p || 6;
    if (x === null || x === undefined || Number.isNaN(x)) return "undefined";
    if (!isFinite(x)) return x > 0 ? "∞" : "−∞";
    if (x === 0) return "0";
    const a = Math.abs(x);
    if (a >= 1e5 || a < 1e-3) {
      const [m, e] = x.toExponential(p - 1).split("e");
      return `${(+m).toString()}×10${String(+e).split("").map((c) => SUP[c]).join("")}`;
    }
    return (+x.toPrecision(p)).toString();
  }
  const unitTxt = (d) => (d ? ` ${d.replace(/\^(-?[\d.]+)/g, (_, e) => e.split("").map((c) => SUP[c] || c).join(""))}` : "");
  const VERDICT = { FORCED: "b-forced", CONDITIONAL: "b-gated", UNCERTIFIED: "b-open", UNRESOLVED: "b-open", REGULAR: "b-imported", WALL: "b-nogo", EXACT: "b-input" };
  const badge = (v, cls) => `<span class="badge ${cls || VERDICT[v] || "b-open"}">${esc(v)}</span>`;
  const vec = (s) => s.trim().split(/[\s,]+/).filter(Boolean).map(Number);
  const mat = (s) => s.trim().split(/\n+/).map(vec).filter((r) => r.length);

  // ------------------------------------------------------------------ SVG plotting
  function plot(el, o) {
    const W = o.width || 560, H = o.height || 300, m = { l: 56, r: 14, t: 12, b: 40 };
    const ser = o.series.filter((s) => s.x.length);
    const tf = (v) => (o.logy ? Math.log10(Math.max(v, o.floor || 1e-16)) : v);
    let xs = [], ys = [];
    ser.forEach((s) => { s.x.forEach((v, i) => { if (isFinite(v) && isFinite(s.y[i])) { xs.push(v); ys.push(tf(s.y[i])); } }); });
    if (!xs.length) { el.innerHTML = '<p class="note">Nothing to plot.</p>'; return; }
    let x0 = o.xmin ?? Math.min(...xs), x1 = o.xmax ?? Math.max(...xs), y0 = o.ymin !== undefined ? tf(o.ymin) : Math.min(...ys), y1 = o.ymax !== undefined ? tf(o.ymax) : Math.max(...ys);
    if (x1 === x0) { x0 -= 1; x1 += 1; } if (y1 === y0) { y0 -= 1; y1 += 1; }
    if (!o.logy && o.ymin === undefined) { const pad = 0.06 * (y1 - y0); y0 -= pad; y1 += pad; }
    const X = (v) => m.l + (v - x0) / (x1 - x0) * (W - m.l - m.r), Y = (v) => H - m.b - (tf(v) - y0) / (y1 - y0) * (H - m.t - m.b);
    const Yr = (t) => H - m.b - (t - y0) / (y1 - y0) * (H - m.t - m.b);
    let g = "";
    const ticks = (a, b, n) => { const st = Math.pow(10, Math.floor(Math.log10((b - a) / n))), k = [1, 2, 5, 10].find((q) => (b - a) / (q * st) <= n) * st, out = []; for (let v = Math.ceil(a / k) * k; v <= b + 1e-12; v += k) out.push(+v.toPrecision(10)); return out; };
    for (const t of ticks(x0, x1, 6)) g += `<line class="grid" x1="${X(t)}" x2="${X(t)}" y1="${m.t}" y2="${H - m.b}"/><text x="${X(t)}" y="${H - m.b + 15}" text-anchor="middle">${fmt(t, 3)}</text>`;
    const yt = o.logy ? (() => { const out = []; for (let e = Math.ceil(y0); e <= Math.floor(y1); e += Math.max(1, Math.ceil((y1 - y0) / 6))) out.push(e); return out; })() : ticks(y0, y1, 5);
    for (const t of yt) g += `<line class="grid" x1="${m.l}" x2="${W - m.r}" y1="${Yr(t)}" y2="${Yr(t)}"/><text x="${m.l - 6}" y="${Yr(t) + 4}" text-anchor="end">${o.logy ? "10" + String(t).split("").map((c) => SUP[c]).join("") : fmt(t, 3)}</text>`;
    g += `<line class="ax" x1="${m.l}" x2="${W - m.r}" y1="${H - m.b}" y2="${H - m.b}"/><line class="ax" x1="${m.l}" x2="${m.l}" y1="${m.t}" y2="${H - m.b}"/>`;
    if (o.xlabel) g += `<text x="${(m.l + W - m.r) / 2}" y="${H - 6}" text-anchor="middle">${esc(o.xlabel)}</text>`;
    if (o.ylabel) g += `<text transform="translate(13 ${(m.t + H - m.b) / 2}) rotate(-90)" text-anchor="middle">${esc(o.ylabel)}</text>`;
    for (const s of ser) {
      const pts = s.x.map((v, i) => [v, s.y[i]]).filter(([a, b]) => isFinite(a) && isFinite(b) && (!o.logy || b > 0 || o.floor));
      const col = `var(--${s.color || "t-forced"})`;
      if (s.step) { let d = ""; pts.forEach(([a, b], i) => { d += i ? `H${X(a)}V${Y(b)}` : `M${X(a)},${Y(b)}`; }); g += `<path d="${d}" fill="none" stroke="${col}" stroke-width="2" ${s.dash ? 'stroke-dasharray="5 4"' : ""}/>`; }
      else if (!s.pointsOnly) g += `<polyline fill="none" stroke="${col}" stroke-width="${s.width || 2}" ${s.dash ? 'stroke-dasharray="5 4"' : ""} points="${pts.map(([a, b]) => `${X(a)},${Y(b)}`).join(" ")}"/>`;
      if (s.points || s.pointsOnly) g += pts.map(([a, b]) => `<circle cx="${X(a)}" cy="${Y(b)}" r="2.8" fill="${col}"/>`).join("");
    }
    const leg = ser.filter((s) => s.label).map((s) => `<span><i style="background:var(--${s.color || "t-forced"});${s.dash ? "opacity:.6" : ""}"></i>${esc(s.label)}</span>`).join("");
    el.innerHTML = `<svg class="plot" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(o.aria || "plot")}">${g}</svg>${leg ? `<div class="legend">${leg}</div>` : ""}`;
  }
  const COLORS = ["t-forced", "t-nogo", "t-imported", "t-gated", "t-declared", "t-open"];

  // ------------------------------------------------------------------ calculator
  const EXAMPLES = {
    "Triangulation: distance from a baseline and two angles": `# Distance to a target from a measured baseline and two bearing angles (law of sines).
# Push beta toward 180 - alpha: the triangle degenerates and the verdict changes.
input base  = 120 ± 0.05 [m]
input alpha = 62 ± 0.2 [deg]
input beta  = 71 ± 0.2 [deg]
family normal, uniform, laplace
samples 40000

gamma = pi - alpha - beta          # angle at the target, in radians
d = base * sin(beta) / sin(gamma)
print "angle at the target", gamma
certify d as "distance to target"`,
    "Wall-tap: distance needs an anchor": `# The origin experiment of RG. Delays alone fix only ratios (x/L, L/c).
# A thermometer plus a counted clock anchors the speed of sound, and only then a length.
input T     = 293.15 ± 0.3 [K]      # thermometry anchor
input t_dir = 4.37 ± 0.025 [ms]     # direct delay, 25 us jitter
const gam   = 1.4
const kB    = 1.380649e-23 [J/K]
const m_air = 4.8096e-26 [kg]       # mean molecular mass of dry air
family normal, uniform, laplace
samples 40000

c = sqrt(gam * kB * T / m_air)
x = c * t_dir
print "speed of sound", c
certify x as "source distance"`,
    "Fold: reading b from b²": `# y = b^2 is a fold. At b = 0 the gradient vanishes:
# linear propagation reports zero spread while the sampled spread is not zero.
input b = 0 ± 0.1
family normal, uniform
certify b^2 as "observation at the fold"
certify (b + 1)^2 as "same map at a regular point"`,
    "Correlation is part of the declaration": `# Two voltmeters share a calibration, so their errors are correlated.
# Delete the correlate line and watch the spread of the difference grow.
input a = 10.00 ± 0.05 [V]
input b = 9.80 ± 0.05 [V]
correlate a, b = 0.9
family normal, uniform
print "difference", a - b
print "sum", a + b
certify a - b as "difference"`,
    "A list of laws is not a class": `# Two declared laws agree on mean ± σ of a mildly nonlinear output: FORCED over the list.
# Add twopoint to the family. A law with the same mean and variance breaks the verdict.
input x = 0 ± 1
family normal, uniform
samples 200000
certify x + 0.07*x^3 as "mildly nonlinear output"
certify 3*x as "linear output (two moments decide it)"`,
    "Domain wall": `# Part of the declared input mass lies where sqrt is undefined.
# A statement about the survivors conditions on the domain, which is a declaration.
input u = 0.5 ± 0.4
family normal, uniform
certify sqrt(u) as "square root near its domain edge"`,
    "Kepler mass: what a certificate does not certify": `# The certificate types the uncertainty of an output. It does not certify the law.
input v = 29.78e3 ± 30 [m/s]
input a = 1.496e11 ± 1e8 [m]
const G = 6.67430e-11 [m^3 kg^-1 s^-2]
family normal, uniform, laplace
samples 40000
M = v^2 * a / G
certify M as "central mass, circular-orbit law"
# A model factor such as (1 + lambda*R) would be a declaration, not data.
# It moves the output, and no certificate here can detect a wrong law (CHI audit, UG09).`,
    "Units are checked": `input L = 5 ± 0.01 [m]
input t = 2 ± 0.1 [s]
v = L / t
print "speed", v
y = L + t          # ill-typed: the engine stops here`,
  };

  function renderCertify(o) {
    const unit = unitTxt(o.dims);
    let h = `<div class="cert"><div class="cert-head"><span class="cert-title"><span class="ln">line ${o.line}</span>${esc(o.label)}</span>${badge(o.status)}</div>`;
    h += `<div class="big">${fmt(o.value)} ± ${fmt(o.sigmaLin, 3)}${esc(unit)} <span class="note" style="font-family:var(--sans)">linearized</span></div>`;
    if (o.mc && o.mc.length) {
      h += `<div class="scroll"><table><tr><th>declared law</th><th class="num">mean</th><th class="num">σ</th><th class="num">2.5%</th><th class="num">97.5%</th><th class="num">no value</th></tr>`;
      for (const m of o.mc) h += `<tr><td>${esc(m.law)}</td><td class="num">${fmt(m.mean)}</td><td class="num">${fmt(m.sd, 4)}</td><td class="num">${fmt(m.q025, 5)}</td><td class="num">${fmt(m.q975, 5)}</td><td class="num">${(100 * m.nanFrac).toFixed(2)}%</td></tr>`;
      h += `</table></div>`;
    }
    for (const s of o.statements || []) h += `<div class="stmt"><div>${badge(s.verdict)}</div><div><b>${esc(s.name)}</b>: ${esc(s.why)}</div></div>`;
    if (o.reasons && o.reasons.length) h += `<ul class="reasons">${o.reasons.map((r) => `<li>${esc(r)}</li>`).join("")}</ul>`;
    if (o.mc && o.mc.length && o.mc[0].quantiles && o.mc[0].quantiles.length) h += `<div class="cdf" data-cdf></div>`;
    h += `<div class="note" style="margin-top:6px">samples ${o.samples} per law, seed ${o.seed}, tol ${o.tol}</div></div>`;
    const wrap = document.createElement("div"); wrap.innerHTML = h;
    const cd = wrap.querySelector("[data-cdf]");
    if (cd) {
      const series = o.mc.map((m, i) => ({ x: m.quantiles, y: m.quantiles.map((_, k) => 0.005 + 0.99 * k / 100), color: COLORS[i % 6], label: m.law }));
      if (o.sigmaLin > 0) {
        const xs = [], ys = []; const lo = Math.min(...o.mc.map((m) => m.quantiles[0])), hi = Math.max(...o.mc.map((m) => m.quantiles[100]));
        for (let k = 0; k <= 120; k++) { const x = lo + (hi - lo) * k / 120; xs.push(x); ys.push(0.5 * (1 + erf((x - o.value) / (o.sigmaLin * Math.SQRT2)))); }
        series.push({ x: xs, y: ys, color: "t-open", dash: true, label: "linearized Gaussian" });
      }
      plot(cd, { series, width: 560, height: 220, ymin: 0, ymax: 1, xlabel: `output${unit}`, ylabel: "cumulative probability", aria: "cumulative distributions by declared law" });
    }
    return wrap.firstChild;
  }
  function erf(x) { const t = 1 / (1 + 0.3275911 * Math.abs(x)), y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x); return x >= 0 ? y : -y; }

  function runCalc() {
    const out = $("calcOut"); out.innerHTML = "";
    const t0 = performance.now();
    let r;
    try { r = C.run($("code").value); } catch (e) { out.innerHTML = `<div class="err">Internal error: ${esc(e.message)}</div>`; return; }
    for (const o of r.out) {
      if (o.kind === "error") out.insertAdjacentHTML("beforeend", `<div class="err"><span class="ln">line ${o.line ?? "?"}</span>${esc(o.msg)}</div>`);
      else if (o.kind === "warn") out.insertAdjacentHTML("beforeend", `<div class="warn"><span class="ln">line ${o.line}</span>${esc(o.msg)}</div>`);
      else if (o.kind === "print") {
        const txt = o.parts.map((p) => (p.str !== undefined ? esc(p.str) : `<span class="val">${fmt(p.value)}${p.sigma > 0 ? " ± " + fmt(p.sigma, 3) : ""}${esc(unitTxt(p.dims))}</span>${p.flags.length ? ` <span class="badge b-nogo">${esc(p.flags[0])}</span>` : ""}`)).join(" ");
        out.insertAdjacentHTML("beforeend", `<div class="line"><span class="ln">line ${o.line}</span>${txt}</div>`);
      } else if (o.kind === "certify") out.appendChild(renderCertify(o));
    }
    if (!r.out.length) out.innerHTML = `<div class="line note">The program produced no output. Add <code>print</code> or <code>certify</code>.</div>`;
    out.insertAdjacentHTML("beforeend", `<div class="note">${(performance.now() - t0).toFixed(0)} ms</div>`);
  }
  function initCalc() {
    const sel = $("example");
    Object.keys(EXAMPLES).forEach((k) => sel.insertAdjacentHTML("beforeend", `<option>${esc(k)}</option>`));
    const m = location.hash.match(/^#calc=(.+)$/);
    let src = null;
    if (m) { try { src = decodeURIComponent(escape(atob(m[1].replace(/-/g, "+").replace(/_/g, "/")))); } catch (e) { src = null; } }
    $("code").value = src || EXAMPLES[Object.keys(EXAMPLES)[0]];
    sel.addEventListener("change", () => { $("code").value = EXAMPLES[sel.value]; runCalc(); });
    $("runBtn").addEventListener("click", runCalc);
    $("code").addEventListener("keydown", (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "Enter") { e.preventDefault(); runCalc(); }
      if (e.key === "Tab" && !e.shiftKey) { e.preventDefault(); const t = e.target, s = t.selectionStart; t.setRangeText("  ", s, t.selectionEnd, "end"); }
    });
    $("shareBtn").addEventListener("click", () => {
      const b64 = btoa(unescape(encodeURIComponent($("code").value))).replace(/\+/g, "-").replace(/\//g, "_");
      history.replaceState(null, "", "#calc=" + b64); $("shareBtn").textContent = "Kept in address";
      setTimeout(() => { $("shareBtn").textContent = "Keep in address"; }, 1600);
    });
    runCalc();
  }

  // ------------------------------------------------------------------ distance and angle
  function matHTML(M) { return `<table style="width:auto">${M.map((r) => `<tr>${r.map((x) => `<td class="num">${fmt(x, 4)}</td>`).join("")}</tr>`).join("")}</table>`; }
  function runDistance() {
    const out = $("dOut");
    try {
      const J = mat($("dJ").value), S = mat($("dS").value), T = vec($("dT").value), N = $("dN").value.trim() ? vec($("dN").value) : [];
      const q0 = vec($("dq0").value), q1 = vec($("dq1").value), u = vec($("du").value), v = vec($("dv").value);
      const p = J[0].length;
      if (J.some((r) => r.length !== p)) throw new Error("every row of J needs the same number of entries");
      if (S.length !== J.length || S.some((r) => r.length !== J.length)) throw new Error(`Σ must be ${J.length} × ${J.length} (one row and column per channel)`);
      if ([...T, ...N].some((i) => !(i >= 0 && i < p))) throw new Error(`parameter indices run from 0 to ${p - 1}`);
      if (T.some((i) => N.includes(i))) throw new Error("a parameter cannot be both target and nuisance");
      if ([q0, q1, u, v].some((x) => x.length !== T.length)) throw new Error(`q0, q1, u, v need ${T.length} entries (one per target parameter)`);
      const se = L.symEig(S).values; if (Math.min(...se) <= 0) throw new Error("Σ must be positive definite");
      const I = L.fisher(J, S), g = L.schur(I, T, N), r = L.distanceAngle(g, q0, q1, u, v);
      const Iqq = T.map((i) => T.map((j) => I[i][j]));
      const full = L.symEig(I).values, fullRank = full.filter((x) => x > 1e-10 * Math.max(...full)).length;
      let h = `<div class="grid2"><div><h3>Full Fisher information</h3>${matHTML(I)}<p class="note">rank ${fullRank} of ${p}</p></div><div><h3>Efficient metric on the target</h3>${matHTML(g)}<p class="note">eigenvalues ${r.eig.map((x) => fmt(x, 4)).join(", ")}; rank ${r.rank} of ${r.dim}</p></div></div>`;
      if (r.error) { out.innerHTML = h + `<div class="err">${esc(r.error)}</div>`; return; }
      h += `<dl class="kv" style="margin-top:10px"><dt>RG distance q0 → q1</dt><dd>${fmt(r.distance, 6)}</dd><dt>Euclidean coordinate distance</dt><dd>${fmt(r.euclid, 6)}</dd>`;
      h += `<dt>angle between u and v</dt><dd>${r.angleError ? "undefined" : fmt(r.angleDeg, 5) + "°  (cos " + fmt(r.cos, 5) + ")"}</dd>`;
      const lost = L.symEig(Iqq).values, kept = r.eig;
      h += `<dt>information kept after nuisance</dt><dd>${kept.map((k, i) => fmt(k / Math.max(...lost), 3)).join(", ")} of the largest raw eigenvalue</dd></dl>`;
      if (r.angleError) h += `<div class="warn">${esc(r.angleError)}</div>`;
      if (r.radical.length) h += `<div class="warn">Radical directions (zero length, the observational kernel on this stratum): ${r.radical.map((x) => "(" + x.map((y) => fmt(y, 3)).join(", ") + ")").join(", ")}. Displacements along them have RG length 0.</div>`;
      if (r.isotropic) h += `<div class="ok">Constant isotropic metric g = λ²I with λ = ${fmt(r.lambda, 5)}: RG distance is λ times Euclidean distance and angles are Euclidean (Thm 6.1). It is physical length only after an independent scale calibration sets λ.</div>`;
      else if (r.rank === r.dim) h += `<div class="note" style="margin-top:8px">Anisotropic metric: RG angles differ from coordinate angles, and Euclidean identification fails (No-Go 6.3).</div>`;
      out.innerHTML = h;
    } catch (e) { out.innerHTML = `<div class="err">${esc(e.message)}</div>`; }
  }
  const PRESETS = { normal: ["1/q2^2", "0", "2/q2^2", "0 1", "3 2"], poincare: ["1/q2^2", "0", "1/q2^2", "-1 1", "2 0.5"], aniso: ["1 + q1^2", "0.3", "1", "-1.5 0", "1.5 0.5"] };
  function runGeodesic() {
    const out = $("gOut");
    try {
      const names = ["q1", "q2"], f11 = C.compileExpr($("g11").value, names), f12 = C.compileExpr($("g12").value, names), f22 = C.compileExpr($("g22").value, names);
      const gf = (a, b) => { const c = f12(a, b); return [[f11(a, b), c], [c, f22(a, b)]]; };
      const q0 = vec($("gq0").value), q1 = vec($("gq1").value);
      if (q0.length !== 2 || q1.length !== 2) throw new Error("endpoints need two coordinates");
      for (const q of [q0, q1]) { const g = gf(...q); if (!(g[0][0] > 0 && g[0][0] * g[1][1] - g[0][1] ** 2 > 0)) throw new Error(`the metric is not positive definite at (${q.join(", ")})`); }
      const r = L.geodesic(gf, q0, q1, 40, 2500);
      let ref = null, refName = "";
      const pre = $("gPreset").value;
      if (pre === "normal") { ref = L.normalFisherRao(q0[0], q0[1], q1[0], q1[1]); refName = "closed-form Fisher–Rao distance"; }
      if (pre === "poincare") { ref = Math.acosh(1 + ((q1[0] - q0[0]) ** 2 + (q1[1] - q0[1]) ** 2) / (2 * q0[1] * q1[1])); refName = "closed-form hyperbolic distance"; }
      let h = `<dl class="kv"><dt>straight-path length (upper bound)</dt><dd>${fmt(r.straight, 6)}</dd><dt>relaxed-path length</dt><dd>${fmt(r.relaxed, 6)}</dd>`;
      if (ref !== null) h += `<dt>${refName}</dt><dd>${fmt(ref, 6)}</dd><dt>relative error of relaxer</dt><dd>${fmt(Math.abs(r.relaxed - ref) / ref, 2)}</dd>`;
      h += `</dl>`;
      if (ref !== null) h += Math.abs(r.relaxed - ref) / ref < 3e-3 ? `<div class="ok">The relaxer reproduces the closed form. This is the falsification check that licenses using it on custom metrics.</div>` : `<div class="warn">The relaxer misses the closed form by more than 0.3%: treat custom results with care.</div>`;
      else h += `<p class="note">No closed form for this metric. The relaxed length is an upper bound on the infimum, not a certificate.</p>`;
      out.innerHTML = h;
      const p = r.path; plot($("gPlot"), { series: [{ x: [q0[0], q1[0]], y: [q0[1], q1[1]], color: "t-open", dash: true, label: "straight path" }, { x: p.map((a) => a[0]), y: p.map((a) => a[1]), color: "t-forced", label: "relaxed path" }], xlabel: "q1", ylabel: "q2", height: 280, aria: "geodesic paths" });
    } catch (e) { out.innerHTML = `<div class="err">${esc(e.message)}</div>`; $("gPlot").innerHTML = ""; }
  }
  function runReduction() {
    const out = $("rOut");
    try {
      const f = C.compileExpr($("rTG").value, ["M"]), M0 = +$("rM0").value, M1 = +$("rM1").value;
      if (!(M1 > M0)) throw new Error("need M₁ > M₀");
      const I = L.simpson(f, M0, M1, 2000), pEnd = f(M1) * (M1 - M0), pMid = f((M0 + M1) / 2) * (M1 - M0), pStart = f(M0) * (M1 - M0);
      let mn = Infinity, mx = -Infinity; for (let k = 0; k <= 400; k++) { const v = f(M0 + (M1 - M0) * k / 400); mn = Math.min(mn, v); mx = Math.max(mx, v); }
      if (mn <= 0) throw new Error("Θγ must be positive on the channel for the metric (Θγ)² dM² to be nondegenerate");
      const constant = mx - mn < 1e-12 * Math.abs(mx);
      out.innerHTML = `<dl class="kv"><dt>d = ∫ Θγ dM</dt><dd>${fmt(I, 7)}</dd><dt>product with Θγ(M₀)</dt><dd>${fmt(pStart, 7)} (${fmt(100 * (pStart - I) / I, 3)}%)</dd><dt>product with Θγ at midpoint</dt><dd>${fmt(pMid, 7)} (${fmt(100 * (pMid - I) / I, 3)}%)</dd><dt>product with Θγ(M₁)</dt><dd>${fmt(pEnd, 7)} (${fmt(100 * (pEnd - I) / I, 3)}%)</dd></dl>` +
        (constant ? `<div class="ok">Θγ is constant: the product is exact (Thm 5.1).</div>` : `<div class="warn">Θγ varies, so any single global product is biased (Cor 5.2).</div>`) +
        `<div class="warn"><b>Open rung (battery G09).</b> d is a length only if [Θγ] = length / [M]. Read the CTMT way (Θ and γ in s⁻¹, M₁ in m), Θ·γ·M₁ has unit m s⁻², not m; the retired D_kernel = M₁Θ/γ is a length under that reading but is a different formula. The corpus must declare the unit of M before this reduction can be used with physical numbers. Try it in the calculator: <code>print Θ*γ*M1</code> with those units.</div>`;
    } catch (e) { out.innerHTML = `<div class="err">${esc(e.message)}</div>`; }
  }
  function initDistance() {
    $("dRun").addEventListener("click", runDistance);
    $("gRun").addEventListener("click", runGeodesic);
    $("rRun").addEventListener("click", runReduction);
    $("gPreset").addEventListener("change", () => { const p = PRESETS[$("gPreset").value]; if (p) { ["g11", "g12", "g22", "gq0", "gq1"].forEach((id, i) => { $(id).value = p[i]; }); runGeodesic(); } });
    runDistance(); runGeodesic(); runReduction();
  }

  // ------------------------------------------------------------------ walls
  function runWalls() {
    const b = +$("wB").value, s = +$("wS").value, reps = +$("wR").value, seed = +$("wSeed").value;
    $("wBv").textContent = b.toFixed(2); $("wSv").textContent = s.toFixed(2);
    const r = L.foldCoverage(b, s, reps, seed);
    const bs = [], lin = [], rg = [];
    for (let k = 0; k <= 40; k++) { const bb = -1.5 + 3 * k / 40; const c = L.foldCoverage(bb, s, 3000, seed + k); bs.push(bb); lin.push(c.linear); rg.push(c.rgSet); }
    const bar = (lab, v, col) => `<div style="margin:6px 0"><div class="note">${lab}</div><div style="display:flex;align-items:center;gap:10px"><div style="flex:1;background:var(--soft);border-radius:4px;height:14px"><div style="width:${(100 * v).toFixed(1)}%;height:14px;border-radius:4px;background:var(--${col})"></div></div><span class="mono">${(100 * v).toFixed(2)}%</span></div></div>`;
    $("wOut").innerHTML = `<div class="grid2"><div id="wPlot"></div><div>${bar("observation interval covers b²", r.observation, "t-open")}${bar("RG set: full preimage {b : b² in the interval}", r.rgSet, "t-imported")}${bar("linearized interval around the positive root", r.linear, "t-nogo")}
      <p class="note" style="margin-top:10px">${b < -0.3 ? "b is on the negative branch: the linearized interval selects the wrong branch and never covers it." : Math.abs(b) <= 0.3 ? "b is near the fold b = 0: the linearization degenerates and loses coverage." : "b is on the regular positive branch: linearization and the RG set agree."} The RG set's coverage equals the observation's on every replication, by fibre saturation (R2–R3).</p></div></div>`;
    plot($("wPlot"), { series: [{ x: bs, y: rg, color: "t-imported", label: "RG preimage set" }, { x: bs, y: lin, color: "t-nogo", label: "linearized interval" }], ymin: 0, ymax: 1, xlabel: "true b", ylabel: "coverage", height: 260, aria: "coverage against b" });
  }
  function initWalls() { ["wB", "wS", "wR", "wSeed"].forEach((id) => $(id).addEventListener("input", runWalls)); runWalls(); }

  // ------------------------------------------------------------------ quotient
  function runQuotient() {
    const ns = [1, 3, 10, 30, 100, 300, 1000, 3000, 1e4, 3e4, 1e5], rows = L.priorLab(ns, $("qFull").checked);
    plot($("qPlot"), { series: [{ x: ns.map(Math.log10), y: rows.map((r) => r.qDiff), color: "t-forced", label: "disagreement about x₁ + x₂", points: true }, { x: ns.map(Math.log10), y: rows.map((r) => r.kVarDiff), color: "t-nogo", label: "disagreement about var(x₁ − x₂)", points: true }], logy: true, floor: 1e-12, xlabel: "log₁₀ n", ylabel: "difference between the two priors", height: 280, aria: "prior forgetting" });
    const sl = Math.log(rows[10].qDiff / rows[6].qDiff) / Math.log(1e5 / 1000);
    $("qOut").innerHTML = `<div class="scroll"><table><tr><th class="num">n</th><th class="num">|Δ mean(x₁+x₂)|</th><th class="num">var(x₁−x₂) prior A</th><th class="num">prior B</th></tr>${rows.filter((_, i) => i % 2 === 0).map((r) => `<tr><td class="num">${fmt(r.n)}</td><td class="num">${fmt(r.qDiff, 3)}</td><td class="num">${fmt(r.kVarA, 4)}</td><td class="num">${fmt(r.kVarB, 4)}</td></tr>`).join("")}</table></div>
      <p class="note" style="margin-top:8px">Log-log slope of the identifiable disagreement: ${fmt(sl, 4)} (theory: −1). ${$("qFull").checked ? "With the second channel the kernel is gone and both disagreements vanish." : "The kernel variance tends to each prior's conditional variance on the fibre: what was declared is what is returned."}</p>
      <p class="note">Prior A: N(0, I). Prior B: mean (1, −0.4), covariance [[4, 0.6], [0.6, 0.5]]. Data held at the truth x₁ + x₂ = 2, noise σ = 1.</p>`;
  }
  function initQuotient() { $("qFull").addEventListener("change", runQuotient); runQuotient(); }

  // ------------------------------------------------------------------ depth
  function runDepth() {
    const k = +$("nk").value; $("nkv").textContent = k;
    const r = L.nullDepthLab(k), bound = 9 * 2.220446049250313e-16;
    const names = ["resolved", "small", "blind"];
    let h = `<div class="scroll"><table><tr><th>direction</th><th>exact rational value</th><th class="num">float64 quadratic form</th><th class="num">float64 eigenvalue</th><th>float64 decides?</th><th>depth</th></tr>`;
    r.exact.forEach((e, i) => {
      const fl = r.float[i], ev = r.floatEig[i], dec = Math.abs(fl) > bound;
      h += `<tr><td>${names[i]}</td><td class="mono">${e.zero ? "0" : (e.str.length > 26 ? "10⁻" + String(-Math.round(e.log10)).split("").map((c) => SUP[c]).join("") : esc(e.str))}</td><td class="num">${fmt(fl, 3)}</td><td class="num">${fmt(ev, 3)}</td><td>${dec ? badge("decided", "b-imported") : badge("below error bound", "b-open")}</td><td>${e.zero ? badge("∞ structural", "b-nogo") : badge(r.depth[i] === 0 ? "0" : String(r.depth[i]) + " precision", r.depth[i] === 0 ? "b-input" : "b-gated")}</td></tr>`;
    });
    h += `</table></div><p class="note" style="margin-top:8px">float64 error bound ≈ ${fmt(bound, 2)}. ${k >= 16 ? "Below the bound float64 does not report zero; it returns numbers it cannot vouch for, so it cannot tell the small direction from the blind one. Exact arithmetic can (battery N01, sharpened)." : "Here the small direction is above the float bound and float64 already decides it."}</p>`;
    $("nOut").innerHTML = h;
  }
  function runRepr() {
    const n = +$("rpN").value; $("rpNv").textContent = n.toFixed(3);
    const r = L.representationLab(3000, n, +$("rpSeed").value);
    $("rpOut").innerHTML = `<dl class="kv"><dt>R² with the class {1, x}</dt><dd>${fmt(r.linear, 4)}</dd><dt>R² with the class {1, x, x²}</dt><dd>${fmt(r.quadratic, 4)}</dd></dl><p class="note" style="margin-top:8px">One added symbol dissolves the null. No added symbol can dissolve a structural one: every function of the data is constant along a direction the sensors never see (Observation Limit Thm 4.2).</p>`;
  }
  function initDepth() { $("nk").addEventListener("input", runDepth); ["rpN", "rpSeed"].forEach((id) => $(id).addEventListener("input", runRepr)); runDepth(); runRepr(); }

  // ------------------------------------------------------------------ forgetting
  function runBV() {
    const f = $("bF").value, g = $("bG").value, Lv = +$("bL").value, p = +$("bPF").value, tau = +$("bTau").value;
    const r = L.tentLab(f, g, Lv, 24, p, p, 3);
    const n = r.rows.map((x) => x.n);
    plot($("bPlot"), { series: [{ x: n, y: r.rows.map((x) => Math.max(x.tv, 1e-12)), color: "t-forced", label: "TVₙ between propagated declarations", points: true }, { x: n, y: r.rows.map((x) => x.bound), color: "t-nogo", dash: true, label: "2⁻⁽ⁿ⁺²⁾ Var(f − g)" }], logy: true, floor: 1e-12, ymin: 1e-9, ymax: 1, xlabel: "step n", ylabel: "total variation", height: 280, aria: "BV lock" });
    const nstar = r.V > 0 ? L.frontier(r.V, tau) : 0;
    const tvAt = (k) => (k >= 0 && k < r.rows.length ? r.rows[k].tv : null);
    const ratio = Math.max(...r.rows.filter((x) => x.bound > 0 && x.bound < 1).map((x) => x.tv / x.bound), 0);
    $("bOut").innerHTML = `<dl class="kv"><dt>Var(f − g)</dt><dd>${fmt(r.V, 6)}</dd><dt>certified frontier n* for τ = ${tau}</dt><dd>${nstar}</dd><dt>TV at n*</dt><dd>${fmt(tvAt(nstar), 4)}</dd><dt>TV at n* − 1</dt><dd>${nstar > 0 ? fmt(tvAt(nstar - 1), 4) : "n/a"}</dd><dt>largest TV / bound (bound &lt; 1)</dt><dd>${fmt(ratio, 4)}</dd><dt>violations</dt><dd>${r.violations}</dd></dl>
      <p class="note" style="margin-top:8px">${f === "witness" ? `The witness 2^(m+1)·1[0, 2^−(m+1)] meets the bound with equality at n = m: the constant 2^−(n+2) cannot be improved.` : f === "spike" ? `A spike of height 2^k has TVₙ = 1 − 2^(n−k). Raise k: the frontier moves out without limit. Over all spikes there is no uniform frontier (R36), which is why a declared class with bounded variation is required.` : `The frontier comes from the operator inequality on the declared class, not from samples.`} Computed in float64 on exact dyadic step densities; the Python battery repeats it in exact rationals (F01–F03).</p>`;
  }
  function initBV() { ["bF", "bG", "bL", "bPF", "bTau"].forEach((id) => $(id).addEventListener("input", runBV)); runBV(); }

  function runCat() {
    const mut = $("cMut").checked, r = L.catLab(64, 8, 100, mut), n = r.rows.map((x) => x.n);
    plot($("cPlot"), { series: [{ x: n, y: r.rows.map((x) => x.full), color: "t-nogo", label: "full-state TV", step: true }, { x: n, y: r.rows.map((x) => x.observed), color: "t-forced", label: "TV through the 8 × 8 block observation", step: true }], ymin: 0, ymax: 1.05, xlabel: "step n", ylabel: "total variation", height: 260, aria: "cat map" });
    const z = r.rows.findIndex((x) => x.observed === 0);
    $("cOut").innerHTML = mut ? `<div class="warn">The non-injective map merges mass, so full-state TV can fall. That is exactly what a bijection cannot do (R33).</div>` :
      `<dl class="kv"><dt>full-state TV</dt><dd>${[...new Set(r.rows.map((x) => x.full))].map((x) => fmt(x)).join(", ")} at every step</dd><dt>observed TV first reaches 0</dt><dd>${z >= 0 ? "n = " + z : "never"}</dd><dt>period of the map on this lattice</dt><dd>${r.period}</dd><dt>observed TV at the period</dt><dd>${fmt(r.rows[r.period] ? r.rows[r.period].observed : NaN)}</dd></dl><p class="note" style="margin-top:8px">Observed forgetting is the declaration difference lying inside the fibres of the observation pulled back by the dynamics. It is not monotone, and an initially matched observable can acquire the difference again (R34).</p>`;
  }
  function initCat() { $("cMut").addEventListener("change", runCat); runCat(); }

  function runFloat() {
    const form = $("flForm").value, bits = +$("flBits").value, scale = +$("flScale").value, N = +$("flN").value;
    const z = L.floatTent(N, 120, 20261011, bits, form, scale), n = z.map((_, i) => i), all = z.findIndex((v) => v === 1);
    plot($("flPlot"), { series: [{ x: n, y: z, color: "t-nogo", label: "fraction of the ensemble at exactly 0", step: true }], ymin: 0, ymax: 1, xlabel: "step n", ylabel: "fraction at 0", height: 240, aria: "float collapse" });
    $("flOut").innerHTML = `<dl class="kv"><dt>every sample is 0 from step</dt><dd>${all >= 0 ? all : "> 120"}</dd><dt>empirical distance between any two such ensembles</dt><dd>0 from that step on</dd><dt>distance of each to the true invariant law</dt><dd>1 (all mass on a point)</dd></dl>
      <div class="${form === "abs" ? "warn" : "ok"}" style="margin-top:8px">${form === "abs" ? "<b>1 − |2x − 1|</b> rounds: it is exact only for x in 2⁻⁵⁴ℤ. Inputs below 1/4 with finer bits are rounded onto that lattice in the first step, so collapse happens by step 55 whatever the declaration. The corpus sentence \"the float tent map is exact arithmetic, not rounding\" holds only for the branch form (battery F05, sharpened)." : "<b>x &lt; ½ ? 2x : 2 − 2x</b> is exact on every double, so the collapse step equals the dyadic depth of the declaration: a declaration on [0, 2⁻¹⁰] with 53-bit mantissas collapses at about step 64."}</div>`;
  }
  function initFloat() { ["flForm", "flBits", "flScale", "flN"].forEach((id) => $(id).addEventListener("change", runFloat)); runFloat(); }

  function runNoise() {
    const M = +$("dbM").value, s = +$("dbS").value, w = +$("dbW").value, mm = +$("dbMax").value;
    if (M > 120 || mm > 200 || M < 2) { $("dbOut").innerHTML = `<div class="err">Keep M ≤ 120 and the largest block ≤ 200.</div>`; return; }
    const r = L.dobrushinLab(M, s, w, mm), first = r.find((x) => x.delta < 1 - 1e-12);
    plot($("dbPlot"), { series: [{ x: r.map((x) => x.m), y: r.map((x) => x.delta), color: "t-forced", label: "δ(Kᵐ)" }], ymin: 0, ymax: 1.02, xlabel: "block length m", ylabel: "Dobrushin coefficient", height: 240, aria: "Dobrushin" });
    $("dbOut").innerHTML = `<dl class="kv"><dt>one-step coefficient δ(K)</dt><dd>${fmt(r[0].delta, 6)}</dd><dt>first contracting block</dt><dd>${first ? "m = " + first.m + ", δ = " + fmt(first.delta, 6) : "none up to m = " + mm}</dd><dt>δ at the largest block</dt><dd>${fmt(r[r.length - 1].delta, 6)}</dd></dl><p class="note" style="margin-top:8px">TV(μKⁿ, νKⁿ) ≤ δ(Kᵐ)^⌊n/m⌋ TV(μ, ν). ${w === 0 ? "With no noise the kernel is deterministic and δ = 1 forever." : "Contraction appears only once the noise has spread far enough for rows to overlap."}</p>`;
  }
  function initNoise() { $("dbRun").addEventListener("click", runNoise); runNoise(); }

  function runChaos() {
    const r = +$("chR").value, tau = +$("chTau").value, N = Math.min(4000, +$("chN").value), seed = +$("chSeed").value;
    const sig = []; for (let k = 2; k <= 12; k++) sig.push(10 ** -k);
    const res = L.frontierLab(r, sig, tau, N, 400, seed), pts = res.rows.filter((x) => x.nstar !== null);
    const xs = pts.map((x) => Math.log(1 / x.sigma0)), series = [{ x: xs, y: pts.map((x) => x.nstar), color: "t-forced", label: "measured frontier n*", pointsOnly: true }];
    if (res.slope !== null) { const mx = xs.reduce((a, b) => a + b, 0) / xs.length, my = pts.reduce((a, b) => a + b.nstar, 0) / pts.length; series.push({ x: [Math.min(...xs), Math.max(...xs)], y: [my + res.slope * (Math.min(...xs) - mx), my + res.slope * (Math.max(...xs) - mx)], color: "t-gated", dash: true, label: "least-squares line" }); }
    plot($("chPlot"), { series, xlabel: "ln(1/σ₀)", ylabel: "steps until spread exceeds tolerance", height: 260, aria: "chaos frontier" });
    $("chOut").innerHTML = pts.length < 3 ? `<div class="ok">No frontier within 400 steps at any precision: the periodic regime forgets nothing and loses nothing.</div>` :
      `<dl class="kv"><dt>measured slope</dt><dd>${fmt(res.slope, 4)} steps per e-fold of precision</dd>${res.predicted ? `<dt>predicted 1/λ = 1/ln 2</dt><dd>${fmt(res.predicted, 4)}</dd><dt>relative difference</dt><dd>${fmt(100 * Math.abs(res.slope - res.predicted) / res.predicted, 3)}%</dd>` : `<dt>implied λ</dt><dd>${fmt(1 / res.slope, 4)}</dd>`}</dl><p class="note" style="margin-top:8px">Change the tolerance or the ensemble size: the intercept moves, the slope does not. Ten times better precision buys ${fmt(Math.log(10) * res.slope, 3)} more steps, never a different rate.</p>`;
  }
  function initChaos() { $("chRun").addEventListener("click", runChaos); $("chR").addEventListener("change", runChaos); runChaos(); }

  // ------------------------------------------------------------------ duration
  function runDuration() {
    const c = L.cocycle([+$("ca1").value, +$("cb1").value], [+$("ca2").value, +$("cb2").value], [+$("ca3").value, +$("cb3").value]);
    const okC = Math.abs(c.aDefect) < 1e-4 && Math.abs(c.bDefect) < 1e-4;
    $("ccOut").innerHTML = `<dl class="kv"><dt>predicted a(A→C) = a(B→C)·a(A→B)</dt><dd>${fmt(c.aPred, 7)}</dd><dt>predicted b(A→C) = a(B→C)·b(A→B) + b(B→C)</dt><dd>${fmt(c.bPred, 7)}</dd><dt>defects</dt><dd>${fmt(c.aDefect, 3)}, ${fmt(c.bDefect, 3)}</dd></dl>` +
      (okC ? `<div class="ok">The cocycle closes: the three clocks are charts of one affine duration object, unique up to T → aT + b, a &gt; 0.</div>` : `<div class="warn">The cocycle does not close: these are pairwise regressions, not representations of one duration object. Pairwise agreement is not enough; the third clock is the anti-circularity check.</div>`);
    const k = +$("ctK").value, ct = L.contrast(+$("ctA").value, +$("ctB").value, +$("ctAB").value, [k, 0]);
    $("ctOut").innerHTML = `<dl class="kv"><dt>D_AB = ΔT_A − ΔT_B / a_AB</dt><dd>${fmt(ct.D0, 6)}</dd><dt>after T → ${k}T + c</dt><dd>${fmt(ct.D1, 6)}</dd></dl>` + (k > 0 ? `<div class="ok">Positive affine gauge: the sign ${ct.signPreserved ? "is preserved" : "changed (unexpected)"} and the offset c cancels in elapsed differences.</div>` : `<div class="warn">k ≤ 0 reverses orientation. That is not a gauge of the duration object, and the sign flips: unsigned elapsed duration does not fix time orientation.</div>`);
    const T = +$("lpT").value, U = +$("lpU").value, pa = +$("lpA").value, pb = +$("lpB").value;
    if (!(pa < 1 && pb < 1 && pa >= 0 && pb >= 0)) { $("lpOut").innerHTML = `<div class="err">Speeds must lie in [0, 1).</div>`; return; }
    const r = L.loophole(T, U, (t, TT) => pa * Math.sin(2 * Math.PI * t / TT) ** 2, (t, TT) => pb * Math.sin(Math.PI * t / TT) ** 4, 41);
    $("lpOut").innerHTML = `<dl class="kv"><dt>shared coordinate interval</dt><dd>${fmt(T)}</dd><dt>reading of clock A</dt><dd>${fmt(r.TA, 6)}</dd><dt>reading of clock B</dt><dd>${fmt(r.TB, 6)}</dd></dl><p class="note" style="margin-top:8px">One global coordinate, unequal reunited readings. Rejecting path-independent accumulation rejects universal duration, not the existence of a coordinate: a coordinate labels events, a duration accumulates along a history.</p>`;
  }
  function initDuration() { ["ca1", "cb1", "ca2", "cb2", "ca3", "cb3", "ctA", "ctB", "ctAB", "ctK", "lpT", "lpU", "lpA", "lpB"].forEach((id) => $(id).addEventListener("input", runDuration)); runDuration(); }

  // ------------------------------------------------------------------ ladder and audit
  const T = { forced: "b-forced", imported: "b-imported", gated: "b-gated", declared: "b-declared", nogo: "b-nogo", open: "b-open", input: "b-input" };
  const LADDER = window.RG_LADDER;
  function initLadder() {
    const res = window.RG_RESULTS, mods = {}; res.modules.forEach((m) => { mods[m.id] = m; });
    const cls = { counterexample: "ce", sharpened: "sh", open: "op", holds: "ho" };
    const chip = (id) => { const m = mods[id]; if (!m) return ""; return `<span class="attack-chip ${cls[m.expect]}" title="${esc(m.target)}">${id} ${m.expect}${m.status === "PASS" ? "" : " (failed)"}</span>`; };
    const tally = {}; res.modules.forEach((m) => { tally[m.expect] = (tally[m.expect] || 0) + 1; });
    const pass = res.modules.filter((m) => m.status === "PASS").length;
    $("tally").innerHTML = `<div><b>${pass}/${res.modules.length}</b>modules, every seed, mutation detected</div><div><b>${tally.holds || 0}</b>claims held</div><div><b>${tally.sharpened || 0}</b>held only with a new boundary</div><div><b>${tally.open || 0}</b>shown open</div><div><b>${tally.counterexample || 0}</b>counterexamples (retired CTMT)</div>`;
    let h = `<tr><th>Rung</th><th>Statement</th><th>Type</th><th>Attacked by</th></tr>`;
    for (const r of LADDER) {
      if (r.stratum) { h += `<tr class="stratum-row"><td colspan="4">${esc(r.stratum)}</td></tr>`; continue; }
      h += `<tr><td>${r.id}</td><td>${esc(r.s)}</td><td>${r.t.split("+").map((t) => `<span class="badge ${T[t]}">${t === "nogo" ? "no-go" : t}</span>`).join(" ")}</td><td>${r.a.length ? r.a.map(chip).join("") : `<span class="note">not attacked in this bundle</span>`}</td></tr>`;
    }
    h += `<tr class="stratum-row"><td colspan="4">Corpus results outside the numbered rungs</td></tr>`;
    for (const r of window.RG_EXTRA) h += `<tr><td>${esc(r.id)}</td><td>${esc(r.s)}</td><td>${r.t.split("+").map((t) => `<span class="badge ${T[t]}">${t === "nogo" ? "no-go" : t}</span>`).join(" ")}</td><td>${r.a.map(chip).join("")}</td></tr>`;
    $("ladderTable").innerHTML = h;
    $("findings").innerHTML = window.RG_FINDINGS.map((f) => `<div class="panel"><h3>${badge(f.kind, f.kind === "open" ? "b-open" : f.kind === "sharpened" ? "b-gated" : "b-nogo")} ${esc(f.title)}</h3><p>${f.body}</p><p class="note">${esc(f.where)}</p></div>`).join("");
    const env = res.environment;
    $("findings").insertAdjacentHTML("beforeend", `<p class="note" style="margin-top:14px">Battery run: seeds ${env.seeds.join(", ")}; ${env.seconds} s; Python ${esc(env.python.split(" ")[0])}, NumPy ${esc(env.numpy)}; the site engine was attacked through Node.</p>`);
  }
  function initAudit() {
    let h = `<tr><th>Retired construct</th><th>What the attack found</th><th>Module</th><th>What replaces it</th></tr>`;
    for (const r of window.RG_AUDIT) h += `<tr><td>${r[0]}</td><td>${r[1]}</td><td class="mono">${r[2]}</td><td>${r[3]}</td></tr>`;
    $("auditTable").innerHTML = h;
  }
  function initGrammar() { $("grammarSrc").textContent = window.RG_GRAMMAR; }

  // ------------------------------------------------------------------ router and theme
  const INIT = { calc: initCalc, distance: initDistance, walls: initWalls, quotient: initQuotient, depth: initDepth, "forget-bv": initBV, "forget-bij": initCat,
    "forget-float": initFloat, "forget-noise": initNoise, "forget-chaos": initChaos, duration: initDuration, ladder: initLadder, audit: initAudit, grammar: initGrammar };
  const done = {};
  function route() {
    let id = (location.hash.slice(1) || "calc").split("=")[0];
    if (!INIT[id]) id = "calc";
    document.querySelectorAll(".view").forEach((v) => v.classList.toggle("on", v.id === "v-" + id));
    document.querySelectorAll("a.nav").forEach((a) => a.setAttribute("aria-current", a.getAttribute("href") === "#" + id ? "page" : "false"));
    if (!done[id]) { done[id] = true; try { INIT[id](); } catch (e) { document.getElementById("v-" + id).insertAdjacentHTML("beforeend", `<div class="err">${esc(e.message)}</div>`); } }
    if (window.innerWidth > 820) window.scrollTo(0, 0);
  }
  window.addEventListener("hashchange", route);
  const themes = ["system", "light", "dark"];
  let theme = "system"; try { theme = localStorage.getItem("rg-theme") || "system"; } catch (e) { /* storage unavailable */ }
  const applyTheme = () => { if (theme === "system") document.documentElement.removeAttribute("data-theme"); else document.documentElement.setAttribute("data-theme", theme); $("themeBtn").textContent = "Theme: " + theme; };
  $("themeBtn").addEventListener("click", () => { theme = themes[(themes.indexOf(theme) + 1) % 3]; try { localStorage.setItem("rg-theme", theme); } catch (e) { /* ignore */ } applyTheme(); });
  applyTheme();
  route();
})();
