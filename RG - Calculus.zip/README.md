# RG hostile battery and RG calculus site

This bundle does two things. It attacks Resolution Geometry (RG) claims and the retired CTMT
native-calculus constructs with registered, seeded, mutation-checked Python modules. It also ships
the RG calculus site, whose engine is attacked by the same battery through Node.

The battery is not there to prove the theory. Each module registers in advance what it expects to
find, and a module counts only if that outcome appears on every seed **and** a deliberate mutation is
detected. A test that cannot fail does not count.

## Layout

```
rg_attack/
  run_all.py              runner; writes results/rg_attack_results.json
  common.py               registry, run rules, Node bridge
  a_legacy.py             L01–L10  retired CTMT constructs
  a_engine.py             E01–E06  the site's own engine (via Node)
  a_uncertainty.py        U01–U04  Uncertainty Geometry
  a_forgetting.py         F01–F09  Forgetting Ladder, chaos frontier
  a_geometry.py           G01–G10  Distance and Angle Laws, R14, rank-one reduction
  a_depth_duration.py     N01–N03, D01–D03  null depth, observation limit, operational duration
  a_routing_chi.py        T01–T04, C01–C06, W01–W03, V01–V02, E07  routing, CHI channel, wind, fuel, compare
  engine/                 rgcalc.peggy (grammar), parser.js (Peggy 3.0.2 output), rgcalc.js, labs.js, labs2.js, harness.js
  results/                rg_attack_results.json from the registered run
site/
  index.html              the built, self-contained page
  template.html, ui.js, ui2.js   page source
  build.py                rebuilds index.html from rg_attack/engine and the results (byte-identical)
```

## Running

```
cd rg_attack
python run_all.py                    # all modules, seeds 20261011 1 42 777 2026
python run_all.py --only U03 F05     # selected modules
python run_all.py --seeds 3 4 5      # other seeds
```

Requirements: Python 3.10+, NumPy, SciPy, mpmath. Node.js 18+ is needed for the 34 modules that attack
the site engine; without Node they are reported as SKIPPED, never as passed. Registered run: 61/61 on all
five seeds, about 45 s on one core. To regenerate the parser from the grammar:
`npx peggy@3.0.2 --format globals --export-var RGParser -o engine/parser.js engine/rgcalc.peggy`.

## Outcome types

| type | meaning |
|---|---|
| holds | the claim survived the attack |
| counterexample | the claim is broken by an explicit witness |
| sharpened | the claim survives only with an added, stated boundary |
| open | the attack shows the rung cannot be closed with what is currently declared |

## Ledger (registered run)

| id | target | outcome |
|---|---|---|
| L01 | old calculator: equal expressions carry equal uncertainty | counterexample: x − x gives √2·σ; x·x and x² differ |
| L02 | worked examples 1.6 / 1.7 reproducible | counterexample: ~25% and ~14% survive (claimed 13%, 5.6%); O is negative on every seed and reading |
| L03 | \|R_τ(e^{iΦ/S})\|² = 1 | counterexample: modulus 0 for every filtered member |
| L04 | einsum variance formula | counterexample: grows linearly with N |
| L05 | np.gradient as ensemble Jacobian | counterexample: depends on sample order |
| L06 | one consistent rupture filter | counterexample: two definitions select different members |
| L07 | C_phys validates dimensions | counterexample: cannot reject m + s |
| L08 | KL estimator E[p log p/q] | counterexample: double weighting |
| L09 | blanket O(n) versus O(n³) cost claim | counterexample in 1-D; sampling wins only in high dimension (control) |
| L10 | np.gradient(F)[0] as divergence | counterexample: returns a scalar |
| E01–E06 | site engine: gradients with correlations (40-digit reference), units, certificate canaries, fold detection, seeded reproducibility, positive-definiteness gate | holds |
| U01 | R45 / UG04 fold: preimage keeps coverage identically | holds |
| U02 | UG03: quotient forgets prior at 1/n, kernel never | holds |
| U03 | UG08/UG10: FORCED over the declared family makes Monte Carlo objective | **sharpened** |
| U04 | linearization agrees with sampling on regular strata, not at walls | holds |
| F01–F03 | R36, R38, Cor. 1: sharp BV lock, equality witnesses, exact frontier, site lab against exact rationals | holds |
| F04 | R33–R35: TV rigidity, fibre migration, recurrence at period 48 | holds |
| F05 | A07 wording: "the float tent map is exact arithmetic, not rounding" | **sharpened** |
| F06 | R40: one-step Dobrushin δ = 1, block contraction | holds |
| F07 | R41: time averages versus fixed-time laws | holds |
| F08 | chaos frontier slope 1/λ; periodic has no frontier | holds |
| F09 | R43(b): no finite-sample TV certificate without a class | holds |
| G01–G08, G10 | descent, garbling, covariance, rank-one angle no-go, walls, slice/cone, projector jump, geodesic, R14 | holds |
| G09 | d = ∫Θγ dM is a length under CTMT readings | **open** |
| N01 | float64 "reports 1, 0, 0" | **sharpened** |
| T01 | exact solver reproduces TSPLIB burma14 = 3323, ulysses16 = 6859 | holds |
| T02 | heuristic ≥ optimum ≥ Held–Karp 1-tree bound; exact = brute force | holds |
| T03 | retired kernel-rhythm routing (L_K = 250 m) changes routes; 645 vs 662 km | counterexample: S ≈ e⁻³⁰⁰, cost matrix = distance matrix; closed tour ≥ 912 km |
| T04 | optimal length under cost noise is a concave minimum (Jensen gap, non-identifiable tours) | holds |
| C01 | retired CHI is a derived invariant; Φ, h, ρ, g shape the prediction | counterexample: they cancel exactly with one anchor |
| C02 | retired CHI arithmetic consistent | counterexample: χ₀ 2.61×10⁴ used as 5.22×10⁴; pump reference 2803 W, not 5600 W (overshoot 4×) |
| C03 | χ channel misses the road-load law away from its anchor | holds |
| C04 | density cancels for wind (36% at ρ = 0.9); wrong sign for the car | holds |
| C05 | bottleneck χ_eff ≤ χ_min | counterexample: harmonic mean lies between min and mean |
| C06 | RG CHI estimator rejects misspecified laws, accepts χ-law data, flags clustered anchors | holds |
| W01 | Rayleigh pattern factor 6/π, Betz refusal, NREL 5-MW rated speed vs 11.4 m/s | holds |
| W02 | mean power vs power at mean wind; site AEP vs independent integration | holds |
| W03 | P90 depends on the shape of declared uncertainty, the mean does not | holds |
| V01 | fuel model vs independent implementation; EPA coast-down units | holds |
| V02 | retired 6 → 9 L/100 km single-anchor prediction | **sharpened**: near-anchor interpolation only |
| E07 | `compare` z-tests, unit refusal, exact references | holds |
| N02, N03 | representation null; structural null invariance | holds |
| D01–D03 | cocycle closure, gauge-invariant contrast, coordinate loophole | holds |

Per-seed witnesses, mutation results, the environment and the SHA-256 of every source file are in
`results/rg_attack_results.json`.

## What the battery changed

**U03: a list of laws is not a class.** For y = x + 0.07x³ (x standardized), exact moments give an
output σ differing by 0.078σ between the normal and uniform laws, so the output is FORCED at tol 0.1 over that
list. A two-point law with the same mean and variance moves it by 0.124σ. UG10 therefore holds as a
statement about the declared list only. It becomes a class statement for outputs that depend on the first
two moments alone (linear outputs; the mutation check confirms they stay FORCED). R31 already states the
correct object: the supremum over the class.

**F05: the float tent map is exact only in branch form.** `x < 1/2 ? 2x : 2 − 2x` is exact on every
double. `1 − |2x − 1|` is exact only on 2⁻⁵⁴ℤ (x = 2⁻⁶⁰ maps to 0 rather than 2⁻⁵⁹). The collapse step equals
the dyadic depth of the declaration: 54 for 53-bit uniforms, about 64 on [0, 2⁻¹⁰] in branch form, at most
55 in abs form. The reported 63–66 needs its formula and declaration stated. R35 and R47 stand.

**N01: float64 cannot decide; it does not report zero.** Behind an exactly orthogonal rational rotation,
float64 returns about 8.5×10⁻²¹ and −3.3×10⁻¹⁷ for the 10⁻²⁰ and zero directions. Both lie inside its
a-priori error bound, so it cannot tell which is blind. The precision-depth test should be that bound.
Exact arithmetic decides (depth 20 against ∞); the trichotomy stands.

**G09: the unit of M is undeclared.** The rank-one reduction d = ∫Θγ dM is a length only if
[Θγ] = length/[M]. With Θ and γ in s⁻¹ and M₁ in m, Θ·γ·M₁ is m s⁻² (checked mechanically by the site engine).
The retired D_kernel = M₁Θ/γ is a length under those readings but is a different formula. Until the corpus
declares the unit of M, the reduction serves ratios and directly declared metric coefficients only.

**V02: one anchor reproduces 6 → 9 L/100 km, and that is all it shows.** Over 50 declared vehicles, a χ
channel calibrated at 72 km/h predicts 108 km/h with median error under 10%, but 36 km/h with median error above
30%; it has the wrong sign for air density and ignores grade.

**Bugs the battery found in this bundle's own new code (fixed before the registered run).** The routing lab turned
a requested cost noise of 0 into 0.1 (`rel || 0.1`), caught by T04's mutation; the CHI estimator returned NaN for
anchors declared with 0% noise, caught by C03.

## Reference values used

TSPLIB optima burma14 = 3323 and ulysses16 = 6859 (reproduced exactly); IAU 2015 nominal GM_sun; CODATA 2018 R and G;
WGS 84 meridian circumference 40 007.863 km; Prague–Brno WGS 84 geodesic 184.7515 km (Vincenty, implementation checked
against Vincenty's published Flinders Peak–Buninyong line, 54 972.271 m); Colebrook–White f = 0.01851 at Re = 10⁵,
ε/D = 10⁻⁴; NREL 5-MW turbine (Jonkman et al. 2009: D = 126 m, 5 MW, Cp,max 0.482, η = 94.4%, rated 11.4 m/s);
Betz limit 16/27; Rayleigh energy pattern factor 6/π; speed of sound in dry air at 20 °C, 343.2 m/s. Reference laws
used to generate CHI anchors (road load with a Willans-line engine, actuator disc, pump affinity and hydraulic power)
are established laws with declared parameters, not measured data, and the site labels them so.

## Placement on the Theorem Ladder

| rung | type | attacked by | result |
|---|---|---|---|
| R1–R3 | forced | N03, U01 | holds |
| R4 | forced | G01 | holds |
| R8 | imported | G01, G02, G03, E01 | holds |
| R10 | gated | G06 | holds |
| R11 | gated | N01 | sharpened (decision test is the error bound) |
| R12, R13 | gated, forced typing | N01–N03 | holds |
| R14 | no-go | G10 | holds |
| R30 | declared | E03 | holds |
| R31 | forced | U03 | holds; it is the fix for UG10 |
| R32–R35 | imported, no-go, forced | F04, F05 | holds; A07 wording sharpened |
| R36, R38 | no-go, gated | F01–F03 | holds, sharp |
| R40, R41, R43, R44, R45, R47 | | F06, F07, F09, U03, U04, U01, F05 | holds |
| Distance and Angles 5.1 | gated | G09 | open (unit of M) |

Not attacked here: R5–R7, R9, R15–R29, R37, R39, R42, R46. Their status is the corpus's own.

## Non-claims

The numerical modules test theorems; they do not replace proofs. Four likelihood families and five seeds
do not cover every experiment. "Holds" means the attack failed, not that the claim is proven beyond the
attack. The site's FORCED verdict is a statement about the declared list, and the page says so. The
geodesic relaxer is a numerical approximation checked against two closed forms, not a certificate. The
CTMT counterexamples concern the specific page supplied; they say nothing about the RG corpus.
