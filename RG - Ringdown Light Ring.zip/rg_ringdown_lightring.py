#!/usr/bin/env python3
"""RG - Light-Ring Kinematics from Ringdown Harmonics: estimators on exact Kerr modes, a first application, a forecast.

Kerr quasinormal modes are computed with the qnm package (Leaver's continued fraction, spectral angular solver). The
prograde equatorial light ring (orbital frequency Omega+, instability exponent lambda+) is computed from null geodesics.
Units G = c = M = 1 unless stated. Each group carries a canary.

  KA light ring: Omega+ and lambda+ from geodesics; Schwarzschild limit 1/(3 sqrt 3); canary: retrograde orbit differs
  KB structure: for l = m modes, Re w - Omega+ L tends to a constant c0 that vanishes only without spin (the effective
     inclination is m/L), and -Im w - lambda+/2 decays essentially like 1/L^2; canary: static (a = 0) has c0 = 0
  KC estimators: lambda+ from two harmonics by the 1/L ladder, Omega+ from three harmonics by Richardson in 1/L; accuracy
     for spins 0 to 0.9; canaries: single-mode readings, and two-mode estimates of Omega+, are biased
  KD first application, GW250114: published (2,2,0) and (4,4,0) frequencies and damping times (pSEOBNR, 90 per cent);
     lambda from the two harmonics against the Kerr light ring of the remnant inferred from (2,2,0) alone; Monte Carlo
  KE forecast: Fisher errors of a damped sinusoid in white noise; the (4,4,0) signal-to-noise ratio needed for a
     5 and 1 per cent test of lambda+, against the 3.6 of GW250114
  KF what the fundamental mode determines: a two-parameter reference family fitted to the l = 2 mode of other static
     geometries (regular holes, a non-vacuum deformation) returns their light ring to sub-per-cent accuracy and misses
     their horizon; canary: a one-parameter family misses lambda

Deterministic. Seed 20261126. Writes rg_ringdown_lightring_results.json.
Run:  python3 -I rg_ringdown_lightring.py      (needs numpy, scipy, qnm 0.4.4)
"""
import hashlib, json, math, os, sys, warnings
import numpy as np
from scipy.optimize import fsolve, brentq

warnings.filterwarnings('ignore')
import qnm

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 20261126
R, FAILS = {}, []
SPINS = (0.0, 0.3, 0.5, 0.68, 0.8, 0.9)
_cache = {}


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.7g}')


def mode(l, a, m=None, n=0):
    m = l if m is None else m; key = (l, m, n, round(a, 6))
    if key not in _cache:
        _cache[key] = complex(qnm.modes_cache(s=-2, l=l, m=m, n=n)(a=a)[0])
    return _cache[key]


def light_ring(a, prograde=True):
    s = 1.0 if prograde else -1.0
    def conds(v):
        r, b = v; P = r * r + a * a - a * b
        return [P * P - (r * r - 2 * r + a * a) * (b - a) ** 2, 4 * r * P - (2 * r - 2) * (b - a) ** 2]
    r0 = 2 * (1 + math.cos(2 / 3 * math.acos(-s * a)))
    b0 = s * 3 * math.sqrt(3) * (1 - 0.5 * s * a) + 1e-3 * s
    r, b = fsolve(conds, [r0, b0], xtol=1e-13)
    P = r * r + a * a - a * b; D = r * r - 2 * r + a * a; Rpp = 4 * P + 8 * r * r - 2 * (b - a) ** 2
    tdot = -a * (a - b) + (r * r + a * a) * P / D; pdot = -(a - b) + a * P / D
    return float(r), float(pdot / tdot), float(math.sqrt(Rpp / 2) / tdot)


def lam_ladder(w1, L1, w2, L2):
    """-Im w = lambda/2 + d2/L^2 + ... : two harmonics cancel d2."""
    return 2 * (L2 ** 2 * (-w2.imag) - L1 ** 2 * (-w1.imag)) / (L2 ** 2 - L1 ** 2)


def lam_ladder_inv(w1, L1, w2, L2):
    """Alternative form assuming a 1/L correction; used only to bound the systematic error."""
    return 2 * (L2 * (-w2.imag) - L1 * (-w1.imag)) / (L2 - L1)


def om_richardson(ws, Ls):
    """Re w = Omega L + c0 + c1/L: three harmonics."""
    A = np.array([[L, 1.0, 1 / L] for L in Ls]); return float(np.linalg.solve(A, np.array([w.real for w in ws]))[0])


def KA():
    out = {}
    for a in SPINS:
        r, Om, lam = light_ring(a); out[a] = dict(r=r, Omega=Om, lam=lam)
    schw = abs(out[0.0]['Omega'] - 1 / (3 * math.sqrt(3))) + abs(out[0.0]['lam'] - 1 / (3 * math.sqrt(3)))
    r_ret, Om_ret, lam_ret = light_ring(0.68, prograde=False)
    ok = schw < 1e-10 and abs(out[0.9]['r'] - 2 * (1 + math.cos(2 / 3 * math.acos(-0.9)))) < 1e-9 and Om_ret < 0 and abs(abs(Om_ret) - out[0.68]['Omega']) > 0.05
    must(ok, 'KA')
    R['KA'] = dict(claim='Prograde equatorial light ring of Kerr from null geodesics: radius 2M[1 + cos(2/3 arccos(-a))], orbital frequency '
                         'Omega+ and instability exponent lambda+ (per unit coordinate time). At a = 0 both equal 1/(3 sqrt 3) to 1e-10. '
                         'Canary: the retrograde orbit has a different frequency.',
                   status='computed', light_ring={str(a): {k: fl(v) for k, v in d.items()} for a, d in out.items()}, retrograde_0_68=[fl(r_ret), fl(Om_ret), fl(lam_ret)])
    return out


def KB(lr):
    ls = (2, 3, 4, 5, 6, 7, 8); c0, d1 = {}, {}
    for a in SPINS:
        Om, lam = lr[a]['Omega'], lr[a]['lam']; L = np.array([l + .5 for l in ls]); W = [mode(l, a) for l in ls]
        off = np.array([w.real - Om * Lx for w, Lx in zip(W, L)])
        # c0 + c1/L + c2/L^2 fit on l = 4..8 gives the constant
        A = np.array([[1, 1 / Lx, 1 / Lx ** 2] for Lx in L[2:]]); c = np.linalg.lstsq(A, off[2:], rcond=None)[0]
        imoff = np.array([(-w.imag) - lam / 2 for w in W]); B = np.array([[1 / Lx, 1 / Lx ** 2] for Lx in L[2:]]); d = np.linalg.lstsq(B, imoff[2:], rcond=None)[0]
        c0[a] = float(c[0]); d1[a] = float(d[0])
    ok = abs(c0[0.0]) < 2e-3 and all(abs(c0[a]) > 0.01 for a in SPINS if a >= 0.3) and all(c0[SPINS[i]] > c0[SPINS[i + 1]] for i in range(len(SPINS) - 1))
    must(ok, 'KB')
    R['KB'] = dict(claim='Structure of the l = m spectrum. Re w_l - Omega+ L tends to a constant c0 (fit on l = 4 to 8 with 1/L and 1/L^2 '
                         'terms): c0 vanishes for a = 0 (below 2e-3) and is of order 0.01 to 0.1 for spinning holes. The reason is that '
                         'the l = m mode follows an orbit of effective inclination m/L, not the equatorial one (Dolan 2010), so its '
                         'frequency carries a shift of order one in L, growing with spin (-0.015 at a = 0.3, -0.11 at a = 0.9). -Im w - lambda+/2 has a 1/L '
                         'coefficient below 0.0032 and decays essentially like 1/L^2. Consequence: the static '
                         'two-mode ladder, built for a 1/L correction to Re w, is not valid for spinning remnants. Canary: c0 = 0 '
                         'without spin.',
                   status='computed; structure IDENTIFIED (Dolan 2010)', c0={str(a): fl(v) for a, v in c0.items()}, d1={str(a): fl(v) for a, v in d1.items()})
    return c0


def KC(lr):
    out = {}
    for a in SPINS:
        Om, lam = lr[a]['Omega'], lr[a]['lam']; w2, w3, w4 = mode(2, a), mode(3, a), mode(4, a)
        L2, L3, L4 = 2.5, 3.5, 4.5
        w6, w8 = mode(6, a), mode(8, a)
        out[a] = dict(lam_23=lam_ladder(w2, L2, w3, L3) / lam - 1, lam_24=lam_ladder(w2, L2, w4, L4) / lam - 1, lam_single_220=2 * (-w2.imag) / lam - 1,
                      lam_68=lam_ladder(w6, 6.5, w8, 8.5) / lam - 1, lam_24_inverse_form=lam_ladder_inv(w2, L2, w4, L4) / lam - 1,
                      Om_234=om_richardson([w2, w3, w4], [L2, L3, L4]) / Om - 1,
                      Om_static_ladder_24=((L4 * w4.real - L2 * w2.real) / (L4 ** 2 - L2 ** 2)) / Om - 1,
                      Om_spacing_24=((w4.real - w2.real) / (L4 - L2)) / Om - 1, Om_single_220=w2.real / L2 / Om - 1)
    lam_ok = all(abs(v['lam_24']) < 0.02 and abs(v['lam_23']) < 0.03 and abs(v['lam_68']) < 0.0025 for v in out.values()) \
        and all(abs(v['lam_single_220']) > 2 * abs(v['lam_24']) for v in out.values())
    om_ok = all(abs(v['Om_234']) < 0.016 for v in out.values()) and all(abs(v['Om_single_220']) > 0.2 for v in out.values()) \
        and all(abs(v['Om_static_ladder_24']) > 3 * abs(v['Om_234']) for a, v in out.items() if a >= 0.5)
    ok = lam_ok and om_ok
    must(ok, 'KC')
    worst = dict(lam_24=max(abs(v['lam_24']) for v in out.values()), lam_23=max(abs(v['lam_23']) for v in out.values()),
                 lam_68=max(abs(v['lam_68']) for v in out.values()), lam_single_220=max(abs(v['lam_single_220']) for v in out.values()),
                 lam_24_inverse_form=max(abs(v['lam_24_inverse_form']) for v in out.values()), Om_234=max(abs(v['Om_234']) for v in out.values()),
                 Om_spacing_24=max(abs(v['Om_spacing_24']) for v in out.values()), Om_static_ladder_24=max(abs(v['Om_static_ladder_24']) for a, v in out.items() if a > 0))
    R['KC'] = dict(claim='Estimators on exact Kerr modes, spins 0 to 0.9. The instability exponent from two harmonics, '
                         'lambda = 2(L2^2|Im w2| - L1^2|Im w1|)/(L2^2 - L1^2), is within 2.0 per cent for (2,2,0) with (4,4,0), within '
                         '2.9 per cent for (2,2,0) with (3,3,0), and within 0.2 per cent for (6,6,0) with (8,8,0), so it converges; '
                         'the single (2,2,0) reading 2|Im w| is off by up to 8.0 per cent. A ladder assuming a 1/L correction is off by '
                         'up to 4.6 per cent and does not converge (1 per cent at l = 6, 8); the difference between the two forms at '
                         '(2,4) bounds the systematic error of the low-l estimate. The orbital frequency needs three harmonics: Richardson in 1/L '
                         'on l = 2, 3, 4 is within 1.5 per cent. With two harmonics it is biased: plain spacing by up to 13 per cent, '
                         'and the static ladder, which ignores c0, by up to 5.2 per cent. The single (2,2,0) reading Re w/L misses '
                         'Omega+ by more than 20 per cent (canary).',
                   status='computed', by_spin={str(a): {k: fl(v) for k, v in d.items()} for a, d in out.items()}, worst={k: fl(v) for k, v in worst.items()})
    return out


def KD():
    rng = np.random.default_rng(SEED)
    Tsun = 4.925490947641e-6                                      # G M_sun / c^3 in seconds
    # published pSEOBNR reconstructions, 90 per cent intervals: (f [Hz], +, -), (tau [ms], +, -)
    f2, t2 = (251.7, 5.1, 5.0), (4.09, 0.42, 0.38)
    f4, t4 = (503.0, 130.0, 185.0), (4.7, 2.1, 2.7)
    z = 1.6448536269514722
    def draw(c, n):
        s_lo, s_hi = c[2] / z, c[1] / z; u = rng.standard_normal(n)
        return c[0] + np.where(u < 0, u * s_lo, u * s_hi)          # split normal matching the quoted interval
    N = 20000; F2, T2, F4, T4 = draw(f2, N), draw(t2, N), draw(f4, N), draw(t4, N)
    keep = (T2 > 0.5) & (T4 > 0.3) & (F4 > 50)
    F2, T2, F4, T4 = F2[keep], T2[keep], F4[keep], T4[keep]
    lam_hat = 2 * (4.5 ** 2 / T4 - 2.5 ** 2 / T2) / (4.5 ** 2 - 2.5 ** 2) * 1e3        # 1/s
    # Kerr remnant from (2,2,0) alone: quality factor -> spin, frequency -> mass (exact Kerr modes on a grid)
    grid = np.round(np.arange(0.40, 0.951, 0.005), 3); w22 = np.array([mode(2, a) for a in grid])
    Qg = w22.real / (2 * -w22.imag)
    def invert(f, tau):
        Q = math.pi * f * tau * 1e-3
        if not (Qg[0] < Q < Qg[-1]):
            return None
        a = float(np.interp(Q, Qg, grid)); wr = float(np.interp(a, grid, w22.real))
        M = wr / (2 * math.pi * f)                                  # seconds
        return a, M
    pred = []
    for f, t in zip(F2[:4000], T2[:4000]):
        r = invert(f, t)
        if r is None:
            continue
        a, M = r; _, Om, lam = light_ring(a); pred.append(lam / M)
    pred = np.array(pred); a0, M0 = invert(251.7, 4.09); lam0 = light_ring(a0)[2] / M0; Om_hz = light_ring(a0)[1] / M0 / (2 * math.pi)
    q = lambda x: [fl(np.percentile(x, 5)), fl(np.median(x)), fl(np.percentile(x, 95))]
    # consistency: fraction of the two-harmonic distribution below / above the Kerr median
    frac_below = float(np.mean(lam_hat < np.median(pred)))
    # the Kerr expectation of the ladder itself (exact modes at the central remnant): bias of 2 to 5 per cent
    w2c, w4c = mode(2, a0), mode(4, a0); lam_ladder_kerr = lam_ladder(w2c, 2.5, w4c, 4.5) / M0
    consistent = 0.05 < frac_below < 0.95
    ok = consistent and 0.6 < a0 < 0.75 and 55 < M0 / Tsun < 75 and np.percentile(lam_hat, 95) - np.percentile(lam_hat, 5) > 0.5 * lam0
    must(ok, 'KD')
    R['KD'] = dict(claim='First application. From the published GW250114 reconstructions of (2,2,0) and (4,4,0), the two-harmonic '
                         'exponent has the 90 per cent interval below, in 1/s. The Kerr light ring of the remnant inferred from (2,2,0) '
                         'alone (spin and mass from its quality factor and frequency, exact Kerr modes) gives the interval below. The '
                         'two agree: the Kerr median lies inside the two-harmonic distribution. The test has little power today: the '
                         '(4,4,0) damping time is known to about 50 per cent, so the interval is wider than the value. Inputs are '
                         'parametrized-Kerr reconstructions, treated as split normals.',
                   status='computed from published values (LVK, arXiv:2509.08099); not re-analysed',
                   remnant_from_220=dict(spin=fl(a0), mass_solar=fl(M0 / Tsun), light_ring_orbital_frequency_hz=fl(Om_hz)), lambda_two_harmonics_per_s=q(lam_hat), lambda_kerr_from_220_per_s=q(pred),
                   ladder_on_exact_kerr_per_s=fl(lam_ladder_kerr), fraction_of_two_harmonic_values_below_kerr_median=fl(frac_below), samples=int(len(lam_hat)))
    return dict(a0=a0, M0=M0, lam0=lam0)


def fisher_errors(Q, f=1.0, rho=1.0):
    """Relative errors of frequency and damping time for h = e^{-t/tau} cos(2 pi f t + phi) in white noise, at SNR rho."""
    tau = Q / (math.pi * f); t = np.linspace(0, 12 * tau, 60001); dt = t[1] - t[0]
    def h(p):
        A, ff, tt, ph = p; return A * np.exp(-t / tt) * np.cos(2 * math.pi * ff * t + ph)
    p0 = np.array([1.0, f, tau, 0.3]); s0 = h(p0); norm = np.sum(s0 * s0) * dt
    J = []
    for i in range(4):
        e = np.zeros(4); e[i] = 1e-6 * max(abs(p0[i]), 1e-3); J.append((h(p0 + e) - h(p0 - e)) / (2 * e[i]))
    J = np.array(J); F = (J @ J.T) * dt / norm * rho ** 2
    C = np.linalg.inv(F); return math.sqrt(C[1, 1]) / f, math.sqrt(C[2, 2]) / tau


def KE(rem):
    a0, M0 = rem['a0'], rem['M0']; w2, w4 = mode(2, a0), mode(4, a0)
    Q2, Q4 = w2.real / (2 * -w2.imag), w4.real / (2 * -w4.imag)
    sf2, st2 = fisher_errors(Q2); sf4, st4 = fisher_errors(Q4)          # at rho = 1; errors scale as 1/rho
    lam = lam_ladder(w2, 2.5, w4, 4.5)
    D = 4.5 ** 2 - 2.5 ** 2; A4 = 2 * 4.5 ** 2 * (-w4.imag) / (D * lam); A2 = 2 * 2.5 ** 2 * (-w2.imag) / (D * lam)    # |d ln lambda / d ln tau_k|
    # signal-to-noise ratios: (2,2,0) taken 10 times louder than (4,4,0), as in GW250114 (about 30 to 40 versus 3.6)
    def rel_err(rho4, ratio=10.0):
        return math.hypot(A4 * st4 / rho4, A2 * st2 / (ratio * rho4))
    need = {p: brentq(lambda r: rel_err(r) - p, 1e-3, 1e8) for p in (0.05, 0.01)}
    now = rel_err(3.6)
    # canary: the Fisher error of a damped sinusoid falls as 1/rho
    s_a = fisher_errors(Q4, rho=10.0)[1]; s_b = fisher_errors(Q4, rho=40.0)[1]
    ok = abs(s_a / s_b - 4) < 1e-6 and need[0.01] > need[0.05] > 3.6 and now > 0.3
    must(ok, 'KE')
    R['KE'] = dict(claim='Forecast. For a damped sinusoid in white noise the Fisher errors at signal-to-noise ratio rho are '
                         'sigma_f/f and sigma_tau/tau times 1/rho, with the coefficients below for the quality factors of (2,2,0) '
                         'and (4,4,0) at the GW250114 remnant. The exponent from two harmonics responds to the damping times with '
                         'weights A4 and A2. With (2,2,0) ten times louder than (4,4,0), as in GW250114, a 5 per cent test of '
                         'lambda+ needs a (4,4,0) signal-to-noise ratio of about the first value below, and a 1 per cent test the '
                         'second; GW250114 had 3.6, which gives the error below. The orbital frequency needs a third harmonic. '
                         'Canary: errors scale exactly as 1/rho.',
                   status='computed (Fisher, white noise, single mode; a lower bound on real errors)',
                   quality_factors=[fl(Q2), fl(Q4)], fisher_at_rho_1=dict(f220=fl(sf2), tau220=fl(st2), f440=fl(sf4), tau440=fl(st4)),
                   weights=dict(A4=fl(A4), A2=fl(A2)), rho440_needed={str(k): fl(v) for k, v in need.items()}, error_at_rho440_3_6=fl(now))


# ---------------------------------------------------------------------------------- KF: what the fundamental mode sees
def _lr_static(f, fp, fpp):
    rc = brentq(lambda r: r * fp(r) - 2 * f(r), 1.2, 10.0)
    return rc, math.sqrt(f(rc)) / rc, math.sqrt(f(rc) * (2 * f(rc) - rc * rc * fpp(rc)) / (2 * rc * rc))


def _horizon(f):
    rs = np.linspace(10.0, 0.3, 20000); v = f(rs); i = int(np.argmax(v < 0)); return brentq(f, rs[i], rs[i - 1])


def _evolve(f, fp, rc, l, T=240.0, h=0.1, xobs=30.0):
    """Scalar test wave psi_tt = psi_xx - V psi in the tortoise coordinate (x = 0 at the light ring); signal at xobs."""
    xmax = T / 2 + xobs + 40; n_pos = int(round(xmax / h)); n_neg = int(round((T / 2 + 40) / h))
    def rk(n, sgn):
        out = np.empty(n + 1); out[0] = r_ = rc; hh = sgn * h
        for i in range(n):
            k1 = f(r_); k2 = f(r_ + 0.5 * hh * k1); k3 = f(r_ + 0.5 * hh * k2); k4 = f(r_ + hh * k3); r_ = r_ + hh * (k1 + 2 * k2 + 2 * k3 + k4) / 6; out[i + 1] = r_
        return out
    r = np.concatenate([rk(n_neg, -1)[::-1], rk(n_pos, 1)[1:]]); x = (np.arange(len(r)) - n_neg) * h
    V = f(r) * (l * (l + 1) / r ** 2 + fp(r) / r)
    dt = h / 2; pulse = lambda y: np.where(np.abs(y - 20.0) < 12.0, np.cos(np.pi * (y - 20.0) / 24.0) ** 4, 0.0)
    p0, p1 = pulse(x - dt), pulse(x); io = int(round(xobs / h)) + n_neg; nst = int(round(T / dt)); sig = np.empty(nst); c2 = (dt / h) ** 2
    for n in range(nst):
        p2 = np.zeros_like(p1); p2[1:-1] = 2 * p1[1:-1] - p0[1:-1] + c2 * (p1[2:] - 2 * p1[1:-1] + p1[:-2]) - dt * dt * V[1:-1] * p1[1:-1]
        p0, p1 = p1, p2; sig[n] = p1[io]
    return np.arange(1, nst + 1) * dt, sig


def _dominant(t, y, t0=80, t1=170, order=6, stride=8):
    """Dominant damped oscillation by linear prediction, selected by fitted amplitude, not by a target."""
    m = (t >= t0) & (t <= t1); tt = t[m][::stride]; yy = y[m][::stride]; d = tt[1] - tt[0]; N = len(yy)
    A = np.stack([yy[order - 1 - k:N - 1 - k] for k in range(order)], 1); c = np.linalg.lstsq(A, yy[order:], rcond=None)[0]
    w = 1j * np.log(np.roots(np.concatenate([[1], -c]))) / d
    amp = np.linalg.lstsq(np.exp(-1j * np.outer(tt - tt[0], w)), yy.astype(complex), rcond=None)[0]
    k = int(np.argmax(np.abs(amp) * (np.abs(w.real) > 0.05))); return complex(abs(w[k].real), w[k].imag)


def _rn(Q):
    q2 = Q * Q; return (lambda r: 1 - 2 / r + q2 / r ** 2, lambda r: 2 / r ** 2 - 2 * q2 / r ** 3, lambda r: -4 / r ** 3 + 6 * q2 / r ** 4)


def _bardeen(g):
    return (lambda r: 1 - 2 * r * r / (r * r + g * g) ** 1.5, lambda r: -4 * r / (r * r + g * g) ** 1.5 + 6 * r ** 3 / (r * r + g * g) ** 2.5,
            lambda r: -4 / (r * r + g * g) ** 1.5 + 30 * r * r / (r * r + g * g) ** 2.5 - 30 * r ** 4 / (r * r + g * g) ** 3.5)


def _hairy(al):
    return (lambda r: 1 - 2 / r + al / r ** 3, lambda r: 2 / r ** 2 - 3 * al / r ** 4, lambda r: -4 / r ** 3 + 12 * al / r ** 5)


def KF():
    """A two-parameter reference family (Reissner-Nordstrom) is fitted to the fundamental l = 2 mode of other geometries."""
    grid = np.linspace(0.0, 0.95, 20); tab = []
    for Q in grid:
        F = _rn(Q); rc, Om, lam = _lr_static(*F); t, y = _evolve(F[0], F[1], rc, 2); tab.append((Om, lam, _dominant(t, y), _horizon(F[0])))
    qf = np.array([w.real / (2 * -w.imag) for _, _, w, _ in tab]); wr = np.array([w.real for _, _, w, _ in tab])
    col = lambda i: np.array([x[i] for x in tab])
    objects = {'Bardeen g=0.5': _bardeen(0.5), 'Bardeen g=0.7': _bardeen(0.7), 'hairy alpha=0.6': _hairy(0.6), 'RN Q=0.5 (control)': _rn(0.5)}
    out = {}
    for name, F in objects.items():
        rc, Om, lam = _lr_static(*F); t, y = _evolve(F[0], F[1], rc, 2); w = _dominant(t, y); q = w.real / (2 * -w.imag)
        if not (qf[0] <= q <= qf[-1]):
            out[name] = dict(outside_family=True); continue
        Qi = float(np.interp(q, qf, grid)); M = float(np.interp(Qi, grid, wr)) / w.real           # mass scale of the fitted member
        lam_f = float(np.interp(Qi, grid, col(1))) / M; Om_f = float(np.interp(Qi, grid, col(0))) / M; rh_f = float(np.interp(Qi, grid, col(3))) * M
        # one-parameter family (Schwarzschild, mass from the frequency): canary
        M1 = wr[0] / w.real; lam_1 = 1 / (3 * math.sqrt(3) * M1)
        rh = _horizon(F[0]); rs = np.linspace(max(rh, rh_f) * 1.02, 12, 400); Ff = _rn(Qi)
        dmetric = float(np.max(np.abs(F[0](rs) - Ff[0](rs / M))))
        out[name] = dict(fitted_Q=Qi, fitted_mass=M, Omega_rel_err=Om_f / Om - 1, lambda_rel_err=lam_f / lam - 1,
                         horizon_rel_err=rh_f / rh - 1, max_metric_diff=dmetric, schwarzschild_lambda_rel_err=lam_1 / lam - 1)
    lr_ok = all(abs(v['Omega_rel_err']) < 5e-3 and abs(v['lambda_rel_err']) < 5e-3 for v in out.values() if 'fitted_Q' in v)
    ctl = out['RN Q=0.5 (control)']; ctl_ok = abs(ctl['fitted_Q'] - 0.5) < 1e-3 and abs(ctl['fitted_mass'] - 1) < 1e-3
    hz = max(abs(v['horizon_rel_err']) for k, v in out.items() if 'fitted_Q' in v and 'control' not in k)
    lre = max(max(abs(v['Omega_rel_err']), abs(v['lambda_rel_err'])) for k, v in out.items() if 'fitted_Q' in v and 'control' not in k)
    md = min(v['max_metric_diff'] for k, v in out.items() if 'fitted_Q' in v and 'control' not in k)
    canary = max(abs(v['schwarzschild_lambda_rel_err']) for k, v in out.items() if 'fitted_Q' in v and 'control' not in k)
    ok = lr_ok and ctl_ok and md > 5 * lre and canary > 0.02 and sum('fitted_Q' in v for v in out.values()) >= 3
    must(ok, 'KF')
    R['KF'] = dict(claim='What the fundamental mode determines. A two-parameter reference family (Reissner-Nordstrom, mass and charge) '
                         'is fitted to the fundamental l = 2 mode of a scalar test wave on other geometries: two regular (Bardeen) '
                         'holes and a 1/r^3 deformation. The fitted member reproduces the light ring of the true geometry, Omega and '
                         'lambda, to 0.12 per cent, while its metric function differs from the true one by up to 1.4 per cent '
                         '(at least 5 times the light-ring error). The horizon radius is reproduced to 0.9 per cent, so these '
                         'families are too close to separate the horizon from the light ring; that separation needs horizonless '
                         'objects and is not tested here. '
                         'Control: an RN object is fitted back to its own charge and mass. Canary: a one-parameter family '
                         '(Schwarzschild, mass from the frequency) misses lambda, because the mode carries two numbers.',
                   status='computed (static, scalar test field); IDENTIFIED as the light-ring reading of ringdown (Cardoso et al. 2009, 2016)',
                   objects={k: {a: fl(b) if not isinstance(b, bool) else b for a, b in v.items()} for k, v in out.items()},
                   worst_light_ring_err=fl(max(max(abs(v['Omega_rel_err']), abs(v['lambda_rel_err'])) for v in out.values() if 'fitted_Q' in v)),
                   worst_horizon_err=fl(hz), smallest_metric_diff=fl(md), worst_one_parameter_lambda_err=fl(canary))


if __name__ == '__main__':
    lr = KA(); print('KA', flush=True)
    KB(lr); print('KB', flush=True)
    KC(lr); print('KC', flush=True)
    rem = KD(); print('KD', flush=True)
    KE(rem); print('KE', flush=True)
    KF(); print('KF', flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED; out['qnm_version'] = qnm.__version__
    out['source_sha256'] = hashlib.sha256(open(os.path.abspath(__file__), 'rb').read()).hexdigest()
    json.dump(out, open(os.path.join(HERE, 'rg_ringdown_lightring_results.json'), 'w'), indent=1, sort_keys=True)
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
