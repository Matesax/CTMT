# RG: Classification of information loss — report

**Verdict: locks within a declared contract.** The contract consists of:
- a tame (o-minimal) site;
- continuous definable families;
- a compact Lie gauge acting definably;
- an observation that separates orbits pointwise;
- set-valued tasks;
- through-wall gauges.

Everything outside that contract is listed explicitly.

**Main theorem.**
1. **Pointwise:** a task descends iff all residuals are singletons. Composite residuals are unions, and postprocessing never cancels loss (I1).
2. **Composition:** loss objects compose by the transported Grothendieck construction and commute with germs (I1, S).
3. **Framing:** unframed classes are framed rooms modulo link automorphisms (S).
4. **Stars (new, general compact gauge):** Room ≅ K_v \ ∏ K_v / S_i^∞, where S_i^∞ is the **limit stabilizer** of the arm germ, not the stabilizer of the limit value.
5. **Isolated singular points (new):** two lifts are equivalent iff the transporter has a uniform constant limit on the link. Ray-wise limits are insufficient.
6. **Global:** the obstruction tower (L131), with its germ steps decided by 4 and 5 wherever they apply.

**New battery (`rg_room_general.py`).**
- **R1, SO(3) stars:** 60 contracts. Prediction by limit cosets is exact. Explicit gauges reach residual < 1e-12. The chirality canary shows that Gram matrices alone merge mirror configurations.
- **R2:** limit stabilizer versus value stabilizer.
- **R3:** with a nonzero centre, variable gauges absorb first-order data, while constant gauges leave residual 0.27.
- **R4:** specializations: 18 versus 9 for S3, and the U(1) torus.
- **R5:** the ray-limit no-go (the gauge equals i on the curve x = y²).
- Reruns are identical.

**Imported unchanged:** I1, L2, S.

**Not classified:**
- noncompact gauges;
- non-tame families;
- groupoid- or bundle-valued tasks and higher stacks;
- general stratified links (the reduction is stated, not proved computable);
- statistics;
- general decidability.

**Print reconciliation:** L129–L131 are consistent with this contract. A short erratum declaring the contract is recommended but not applied.

**Withdrawn from the earlier programme draft:**
- the blanket Brown-algorithm claim;
- "nonabelian π₁ ⇒ undecidable".
