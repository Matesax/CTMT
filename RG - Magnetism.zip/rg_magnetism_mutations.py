#!/usr/bin/env python3
"""Mutation suite for rg_magnetism.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. About two minutes.

    python3 -I rg_magnetism_mutations.py
"""
import json, os, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('MA', 'coboundary without alternating signs', "sg = (-1) ** pos", "sg = 1"),
    ('MB', 'Euclidean metric in place of the Lorentzian one', "eta = np.diag([-1.0, 1, 1, 1]); gens_l, gens_r, gens_e = [], [], []", "eta = np.diag([1.0, 1, 1, 1]); gens_l, gens_r, gens_e = [], [], []"),
    ('MB', 'permeability not tied to the cone speed', "eps, mu = lam / Kc, 1 / (lam * Kc)", "eps, mu = lam / Kc, 1 / lam"),
    ('MC', 'claim: a massive kernel records the count at a distance', "gauss0 = [flux(r, 0.0) for r in (0.5, 2.0, 8.0)]", "gauss0 = [flux(r, 0.1) for r in (0.5, 2.0, 8.0)]"),
    ('MC', 'form detuned from the gauge-invariant one', "Q = (pv @ pv) * np.eye(D) - np.outer(pv, pv); ev", "Q = (pv @ pv) * np.eye(D) - 0.9 * np.outer(pv, pv); ev"),
    ('MD', 'screened (massive) lattice kernel', "np.fft.ifftn(np.fft.fftn(j[i]) / k2).real", "np.fft.ifftn(np.fft.fftn(j[i]) / (k2 + 0.01)).real"),
    ('MD', 'half the periodic-image term', "lorentz = -(2 / 3) * l_ ** 2", "lorentz = -(1 / 3) * l_ ** 2"),
    ('ME', 'kernel exponent 3.02', "d[:, :, None] ** (3 + q)", "d[:, :, None] ** (3.02 + q)"),
    ('MF', 'wrong sign in the mutual-inductance formula', "(2 / k - k) * ellipk(m) - (2 / k) * ellipe(m)", "(2 / k - k) * ellipk(m) + (2 / k) * ellipe(m)"),
    ('MG', 'coupling without the frontier factor', "mu0 = 1 / (eps0 * K ** 2); I = g * lam0 * v", "mu0 = 1 / eps0; I = g * lam0 * v"),
    ('MG', 'Galilean boost', "Lb = np.eye(4); Lb[0, 0] = Lb[3, 3] = g;", "Lb = np.eye(4); Lb[0, 0] = Lb[3, 3] = 1.0;"),
    ('MH', 'step off the cone', "Bz[:-1] -= (Ey[1:] - Ey[:-1])", "Bz[:-1] -= 0.9 * (Ey[1:] - Ey[:-1])"),
    ('MI', 'static determination 200 km/s higher', "rosa = (299788.0 - c / 1e3) / 30.0", "rosa = (299988.0 - c / 1e3) / 30.0"),
    ('MI', 'impedance in units of the resistance quantum without the factor 2', "alpha_from_Z = Z0 / (2 * RK)", "alpha_from_Z = Z0 / RK"),
]


def main():
    base = open(os.path.join(HERE, 'rg_magnetism.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_magnetism.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_magnetism.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_magnetism_results.json')))['failures']
            except Exception:
                fails = [group] if run.returncode != 0 else []
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
