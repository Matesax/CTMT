#!/usr/bin/env python3
"""
Wall-tap: the whole theorem ladder on its origin experiment. Battery WT01-WT16.
================================================================================
Latent theta = (x, r, b): source position, reflection contrast, inter-tap rhythm.
Nuisance: gain g, sound speed c, room length L. Environment: wall contrast eps, wind w, noise family.
Protocols (cumulative):  P0 direct delay | P1 + echo delay | P2 + echo amplitude | P3 + rhythm overlap
                         P4 + signed lead/lag channel (breaks the overlap fold)
Anchors: A_c (sound speed from thermometry, c = sqrt(gamma k_B T / m), with a counted clock),
         A_L (room length as a rod), A_g (reference reflector for the gain), A_w (reciprocity channel for wind).

  WT01 under-determination -> saturation: rank of the joint law grows by kernel intersection across protocols
  WT02 exact layer: the overlap channel identifies b and 2d-b (exact Z2 fibre, 56% of K); P4 separates it
  WT03 the fold b = d(x) is an isotropy wall INSIDE the regular stratum; jet-rescaled tangent cone recovers it
  WT04 matched wall: kernel upper semicontinuity, K_eps <= K_0, specialization map [x,r,b] -> [x]
  WT05 H-hell: sup_K Hellinger -> 0 linearly; shrinking-covariance canary keeps it constant
  WT06 Fisher wall: rank 3 -> 1, eigenvalues O(eps^2), CRB O(eps^-2) on exactly span(dr, db)
  WT07 Bayes risk of r=0.3 vs r=0.8 tends to 1/2 at the wall; not under the shrinking-covariance family
  WT08 gain nuisance: (r, g) product fibre; efficient metric for r vanishes unless a reference reflector anchors g
  WT09 dilation: delays fix only x/L and L/c; anchors: rod (L) or thermometry+clock (c); {k_B T, m} alone fix no length
  WT10 media: a temperature gradient c(x) gives the same delay for different profiles (blind sector)
  WT11 wind: echo ('radar') distance = rod / (1 - w^2/c^2) (acoustic Landau-Lifshitz); reciprocity measures w
  WT12 natural descent: chart invariance and cocycle of the Fisher tensor; RG distance experiment-relative,
       ratios invariant (translation covariance of the delay channels)
  WT13 cone: acoustic symbol (tau + w xi)^2 - c^2 xi^2 is hyperbolic; an anti-damped symbol is not (Hadamard)
  WT14 clocks: sample clock and metronome form an affine transition groupoid; a temperature-sensitive clock has
       a different kernel and no transition map
  WT15 latent room: no law-natural connection (shear in the gain-contrast fibre); canonical under declared P
  WT16 CLOSURE AT SCALE: 3000 random requests over protocols, walls, folds, anchors, wind and noise families,
       dispatched with REAL certificates; false LOCKED = 0; five sabotages each produce false LOCKs

Run:  python3 rg_wall_tap_attack.py [--seed 20261004] [--out FILE] [--canary]
"""
import argparse, json, math, sys, time
import numpy as np

RESULTS, MUT = [], {}
L0, C0 = 5.0, 343.2
SIG = dict(t=2.5e-5, t2=4.0e-5, a=0.035, o=0.025, s=0.025, ref=0.01)
K = dict(x=(0.7, 4.3), r=(0.25, 1.0), b=(0.004, 0.028))
W0 = 0.0035


def f_(x): return float(np.round(float(x), 12))


def _finite(o):
    if isinstance(o, dict): return all(_finite(v) for v in o.values())
    if isinstance(o, (list, tuple)): return all(_finite(v) for v in o)
    if isinstance(o, float): return math.isfinite(o)
    return True


def register(aid, naive, keep, passed, ev, verdict):
    if not _finite(ev): passed, verdict = False, "NONFINITE"
    RESULTS.append(dict(id=aid, naive_claim=naive, rg_claim=keep, passed=bool(passed), verdict=verdict, evidence=ev))
    print(f"[{'PASS' if passed else 'FAIL'}] {aid} {verdict:16s} {keep[:84]}")


# ------------------------------------------------------------------ the wall-tap law
def features(th, level, eps=1.0, g=1.0, c=C0, L=L0, ref=False):
    x, r, b = th
    d = (2*L-2*x)/c
    out = [x/c]; sig = [SIG["t"]]
    if level >= 1: out.append((2*L-x)/c); sig.append(SIG["t2"])
    if level >= 2: out.append(eps*g*r*math.exp(-0.08*(2*L-x))); sig.append(SIG["a"])
    if level >= 3: out.append(eps*g*r*math.exp(-((b-d)/W0)**2)); sig.append(SIG["o"])
    if level >= 4: out.append(eps*g*r*math.tanh((b-d)/W0)); sig.append(SIG["s"])
    if ref: out.append(g*0.5); sig.append(SIG["ref"])           # reference reflector of known contrast 0.5
    return np.array(out), np.array(sig)


def jac(fun, p, h=None):
    p = np.asarray(p, float); f0 = fun(p); J = np.zeros((len(f0), len(p)))
    for i in range(len(p)):
        e = np.zeros(len(p)); e[i] = (h or 1e-6)*max(1.0, abs(p[i])); J[:, i] = (fun(p+e)-fun(p-e))/(2*e[i])
    return J


def fisher(th, level, eps=1.0, nuis=(), anchors=(), shrink=False):
    """Fisher metric in (x, r, b, nuisance...). nuis subset of ('g','c','L'): free nuisance parameters."""
    base = dict(g=1.0, c=C0, L=L0)
    def fun(p):
        kw = dict(base); kw.update({k: p[3+i] for i, k in enumerate(nuis)})
        m, _ = features(p[:3], level, eps, kw["g"], kw["c"], kw["L"], ref="g" in anchors); return m
    p = np.r_[th, [base[k] for k in nuis]]
    J = jac(fun, p); _, s = features(th, level, eps, ref="g" in anchors)
    if shrink: s = s*np.where(np.arange(len(s)) >= 2, eps, 1.0)
    return J.T@np.diag(1/s**2)@J


def rand_theta(rng, away_from_fold=0.0):
    while True:
        th = np.array([rng.uniform(*K["x"]), rng.uniform(*K["r"]), rng.uniform(*K["b"])])
        d = (2*L0-2*th[0])/C0
        if abs(th[2]-d) >= away_from_fold: return th


def rel_rank(G, tol=1e-9):
    w = np.linalg.eigvalsh((G+G.T)/2); w = np.clip(w, 0, None)
    return int(np.sum(w > tol*w.max()))


# ======================================================================= checks
def WT01_saturation(rng):
    """ranks of the joint law in (x, r, b, g, c, L) as protocols and anchors are added (kernel intersection)."""
    rows = {}
    for name, level, nuis, anch in [("P0", 0, ("g", "c", "L"), ()), ("P1", 1, ("g", "c", "L"), ()),
                                    ("P2", 2, ("g", "c", "L"), ()), ("P3", 3, ("g", "c", "L"), ()),
                                    ("P4", 4, ("g", "c", "L"), ()), ("P4+A_L", 4, ("g", "c"), ()),
                                    ("P4+A_L+A_g", 4, ("g", "c"), ("g",)), ("P4+A_c+A_L+A_g", 4, ("g",), ("g",))]:
        rk = [rel_rank(fisher(rand_theta(rng, 2e-3), level, 1.0, nuis, anch)) for _ in range(30)]
        rows[name] = dict(rank=int(np.median(rk)), params=3+len(nuis))
    seq = [rows[k]["params"]-rows[k]["rank"] for k in rows]
    passed = (rows["P0"]["rank"] == 1 and rows["P1"]["rank"] == 2 and rows["P2"]["rank"] == 3 and rows["P3"]["rank"] == 4
              and rows["P4+A_c+A_L+A_g"]["rank"] == rows["P4+A_c+A_L+A_g"]["params"] and all(np.diff(seq) <= 0) and seq[-1] == 0)
    register("WT01", "The wall-tap record identifies the room.",
             "It is under-determined until the protocol grows: the infinitesimal kernel shrinks by intersection "
             "(nullity 5,4,3,2,2) and closes only with anchors for length and gain. P4 adds no rank (the fold is "
             "discrete, WT02).", passed, dict(by_protocol=rows, nullity_sequence=seq), "FALSIFIED-naive")


def WT02_fold(rng):
    n = 20000; xs = rng.uniform(*K["x"], n); bs = rng.uniform(*K["b"], n); ds = (2*L0-2*xs)/C0; p = 2*ds-bs
    inside = (p >= K["b"][0]) & (p <= K["b"][1]); frac = float(np.mean(inside))
    worst3, min4 = 0.0, np.inf
    for i in np.where(inside)[0][:400]:
        th, th2 = np.array([xs[i], 0.6, bs[i]]), np.array([xs[i], 0.6, p[i]])
        worst3 = max(worst3, float(np.max(np.abs(features(th, 3)[0]-features(th2, 3)[0]))))
        if abs(bs[i]-p[i]) > 1e-3:
            m4 = features(th, 4); m4b = features(th2, 4)
            min4 = min(min4, float(np.max(np.abs(m4[0]-m4b[0])/m4[1])))
    passed = frac > 0.4 and worst3 < 1e-15 and min4 > 1.0
    register("WT02", "For eps > 0 the regular quotient is Q = (x, r, b) (uploaded Prop. 3.1, Fig. 2).",
             "False: the overlap channel identifies b with 2d(x)-b exactly; 56% of K has a partner with identical law. "
             "The exact quotient of P3 is (x, r, |b-d|). The signed lead/lag channel (P4) separates every pair by more "
             "than one noise unit: saturation needs a new protocol, not more data.",
             passed, dict(fraction_with_partner=f_(frac), P3_law_difference=f_(worst3), P4_min_separation_noise_units=f_(min4)),
             "FALSIFIED-naive")


def WT03_fold_wall(rng):
    """b = d(x) is a latent isotropy wall: D mu (P3) loses the b-direction there; the quotient invariant is
    (b-d)^2. Jet-rescaled secants (Delta o / h^2) recover a one-sided direction that the first-order tangent misses."""
    x = 2.0; d = (2*L0-2*x)/C0; th0 = np.array([x, 0.6, d])
    J = jac(lambda p: features(p, 3)[0], th0); ker_b = abs(J[3, 2])
    jets = []
    for h in (1e-4, 1e-5, 1e-6):
        jets.append([(features(th0+np.array([0, 0, s*h]), 3)[0][3]-features(th0, 3)[0][3])/h**2 for s in (1, -1)])
    same_sign = all(a < 0 and bq < 0 for a, bq in jets)            # both directions move o the same way: one-sided
    conv = abs(jets[-1][0]-jets[-2][0])/abs(jets[-1][0])
    reg_rank = rel_rank(fisher(np.array([x, 0.6, d+0.004]), 3))
    passed = ker_b < 1e-6 and same_sign and conv < 1e-3 and reg_rank == 3
    register("WT03", "Inside the regular stratum the geometry is smooth.",
             "The fold b = d(x) is an isotropy wall inside it: the b-derivative vanishes, opposite b-displacements give "
             "the same observable change, and the rescaled jet (Delta o/h^2) converges to a one-sided direction "
             "(L16 realized by the origin experiment).",
             passed, dict(b_derivative_at_fold=f_(ker_b), jets=[[f_(v) for v in jj] for jj in jets], jet_convergence=f_(conv),
                          rank_off_fold=reg_rank), "FALSIFIED-naive")


def WT04_matched_wall(rng):
    worst_incl, maps_ok = 0.0, 0
    for _ in range(200):
        th = rand_theta(rng, 2e-3)
        for eps in (1e-2, 1e-4):
            G = fisher(th, 3, eps); w, V = np.linalg.eigh(G); Kreg = V[:, w < 1e-12*w.max()]
            K0 = np.array([[0, 0], [1, 0], [0, 1.0]])
            worst_incl = max(worst_incl, float(np.linalg.norm((np.eye(3)-K0@K0.T)@Kreg@Kreg.T)) if Kreg.shape[1] else 0.0)
        th2 = th.copy(); d = (2*L0-2*th[0])/C0; th2[2] = 2*d-th[2]
        eq_eps = np.max(np.abs(features(th, 3, 0.5)[0]-features(th2, 3, 0.5)[0])) < 1e-15
        eq_0 = np.max(np.abs(features(th, 3, 0.0)[0]-features(th2, 3, 0.0)[0])) < 1e-15
        th3 = th.copy(); th3[1] = 0.9; diff_eps = np.max(np.abs(features(th, 3, 0.5)[0]-features(th3, 3, 0.5)[0])) > 0
        eq3_0 = np.max(np.abs(features(th, 3, 0.0)[0]-features(th3, 3, 0.0)[0])) < 1e-15
        maps_ok += (not eq_eps or eq_0) and diff_eps and eq3_0
    passed = worst_incl < 1e-9 and maps_ok == 200
    register("WT04", "At the matched wall the regular geometry must be continued component by component.",
             "Kernel upper semicontinuity and inclusion K_eps <= K_0 hold (fold pairs and contrast pairs are identified "
             "at the wall), so the specialization map [x,r,|b-d|] -> [x] exists and is many-to-one.",
             passed, dict(max_kernel_inclusion_defect=f_(worst_incl), inclusion_and_collapse_ok=f"{maps_ok}/200"), "HOLDS")


def sup_hellinger(eps, shrink, rng, n=2000):
    best = 0.0
    for _ in range(n):
        th = rand_theta(rng)
        m1, s = features(th, 3, eps); m0, _ = features(th, 3, 0.0)
        if shrink: s = s*np.where(np.arange(len(s)) >= 2, max(eps, 1e-300), 1.0)
        dm = np.sum(((m1-m0)/s)**2); best = max(best, math.sqrt(1-math.exp(-dm/8)))
    return best


def WT05_hell(rng):
    eps = (0.2, 0.05, 0.0125, 0.003125)
    hf = [sup_hellinger(e, False, rng) for e in eps]; hs = [sup_hellinger(e, True, rng) for e in eps]
    slope = math.log(hf[-1]/hf[-2])/math.log(eps[-1]/eps[-2])
    gate = lambda h: h[-1] < 0.05
    if MUT.get("wt05_weak"): gate = lambda h: True
    passed = abs(slope-1) < 0.05 and gate(hf) and not gate(hs) and min(hs) > 0.5
    register("WT05", "Convergence of the mean record to the wall carries all geometry (uploaded H-hell canary aside).",
             "Fixed covariance: sup_K Hellinger -> 0 with slope 1 (O(eps), the analytic bound). Shrinking covariance "
             "Sigma_eps = eps^2 Sigma: means converge but Hellinger stays > 0.5, and the gate rejects it.",
             passed, dict(sup_hellinger_fixed=[f_(v) for v in hf], slope=f_(slope), sup_hellinger_shrinking=[f_(v) for v in hs]),
             "HOLDS")


def WT06_fisher_wall(rng):
    th = np.array([2.0, 0.6, 0.012]); small = []
    for eps in (1e-1, 1e-2, 1e-3):                       # efficient (r,b)-block given x: well conditioned
        G = fisher(th, 3, eps); S = G[1:, 1:]-np.outer(G[1:, 0], G[0, 1:])/G[0, 0]
        small.append(float(np.min(np.linalg.eigvalsh(S))))
    slope = math.log(small[-1]/small[0])/math.log(1e-2)
    G0 = fisher(th, 3, 0.0); w, V = np.linalg.eigh(G0); rad = V[:, w < 1e-9*w.max()]
    radical_ok = rad.shape[1] == 2 and np.linalg.norm(rad[0, :]) < 1e-9
    crb = [np.linalg.inv(fisher(th, 3, e))[1, 1] for e in (1e-1, 1e-2)]
    passed = abs(slope-2) < 0.05 and radical_ok and rel_rank(G0) == 1 and abs(math.log10(crb[1]/crb[0])-2) < 0.05
    register("WT06", "The material and rhythm directions remain estimable near a matched wall.",
             "Fisher rank 3 -> 1; the two collapsing eigenvalues scale as eps^2 and the CRB as eps^-2; the wall radical "
             "is exactly span(dr, db).", passed, dict(eigen_slope=f_(slope), wall_rank=rel_rank(G0), radical_dims=int(rad.shape[1]),
             crb_growth_decades=f_(math.log10(crb[1]/crb[0]))), "HOLDS")


def WT07_bayes(rng):
    from scipy.stats import norm
    th_a, th_b = np.array([2.0, 0.3, 0.012]), np.array([2.0, 0.8, 0.012])
    def err(eps, shrink):
        ma, s = features(th_a, 3, eps); mb, _ = features(th_b, 3, eps)
        if shrink: s = s*np.where(np.arange(len(s)) >= 2, eps, 1.0)
        return float(norm.cdf(-math.sqrt(np.sum(((ma-mb)/s)**2))/2))
    fixed = [err(e, False) for e in (0.5, 0.05, 0.005)]; shr = [err(e, True) for e in (0.5, 0.05, 0.005)]
    passed = abs(fixed[-1]-0.5) < 1e-2 and abs(shr[-1]-shr[0]) < 1e-9 and shr[-1] < 0.4
    register("WT07", "Decision content specializes whenever the mean record converges.",
             "Under H-hell the minimal error for r=0.3 vs 0.8 tends to the wall value 1/2; under the shrinking family it "
             "stays constant (Le Cam convergence fails).", passed, dict(error_fixed=[f_(v) for v in fixed], error_shrinking=[f_(v) for v in shr]),
             "FALSIFIED-naive")


def efficient_r(th, level, anchors):
    G = fisher(th, level, 1.0, ("g",), anchors)
    q = [1]; nu = [3]
    Iqq = G[np.ix_(q, q)]; Iqn = G[np.ix_(q, nu)]; Inn = G[np.ix_(nu, nu)]
    return float((Iqq-Iqn@np.linalg.pinv(Inn)@Iqn.T)[0, 0]), float(Iqq[0, 0])


def WT08_gain(rng):
    no, yes, full = [], [], []
    for _ in range(100):
        th = rand_theta(rng, 2e-3); e0, f0 = efficient_r(th, 4, ()); e1, _ = efficient_r(th, 4, ("g",))
        no.append(e0/f0); yes.append(e1/f0); full.append(f0)
    passed = max(no) < 1e-6 and min(yes) > 0.2
    register("WT08", "Echo amplitude measures wall contrast.",
             "Only with the gain anchored: (r, g) is a product fibre and the efficient information on r is ~0 without a "
             "reference reflector (L22/L23 nuisance); with one it is restored.", passed,
             dict(max_efficient_fraction_no_ref=f_(max(no)), min_efficient_fraction_with_ref=f_(min(yes))), "FALSIFIED-naive")


def WT09_dilation(rng):
    def rank_delays(nuis):
        th = rand_theta(rng); return rel_rank(fisher(th, 1, 1.0, nuis))
    r_free = rank_delays(("c", "L")); r_rod = rank_delays(("c",)); r_c = rank_delays(("L",))
    # dilation generator (x, L, c) is null when c and L are free (time unit fixed by clock)
    th = rand_theta(rng); G = fisher(th, 1, 1.0, ("c", "L")); gen = np.array([th[0], 0, 0, C0, L0]); gen /= np.linalg.norm(gen)
    null = float(gen@G@gen/np.linalg.norm(G))
    # thermometry: c = sqrt(gamma k_B T / m); with {k_B, T, m} only a velocity; with a counted clock a length
    kB, T, m, gam = 1.380649e-23, 293.15, 4.81e-26, 1.4
    c_th = math.sqrt(gam*kB*T/m); fs = 48000.0; n_counts = 2*L0/C0*fs
    length_from_counts = c_th*n_counts/fs/2
    # first registration expected rank 1 with (c, L) free; two delays in (x, c, L) give rank 2 with one dilation null
    passed = r_free == 2 and r_rod == 2 and r_c == 2 and null < 1e-9 and abs(length_from_counts-L0*c_th/C0) < 1e-9 and abs(c_th-343.2)/343.2 < 0.01
    register("WT09", "The wall-tap delay measures distance.",
             "Delays alone fix x/L and L/c: the dilation (x, L, c) is an exact null direction. A rod (L) or thermometry "
             "(c = sqrt(gamma k_B T/m), a velocity only) plus a counted clock anchors length; thermodynamics without the "
             "clock fixes no length.", passed, dict(rank_c_L_free=r_free, rank_rod=r_rod, rank_thermometry=r_c, dilation_null=f_(null),
                                                   thermometric_c=f_(c_th)), "FALSIFIED-naive")


def WT10_media(rng):
    D = 3.0; c1 = lambda x: 343.2 + 6.0*x/D; c2 = lambda x: 349.2 - 6.0*x/D   # warm near / far, same harmonic mean
    xs = np.linspace(0, D, 20001); t1 = np.trapezoid(1/c1(xs), xs); t2 = np.trapezoid(1/c2(xs), xs)
    cc = D/t1                                                                   # uniform profile with same delay
    t3 = D/cc
    passed = abs(t1-t2) < 1e-12 and abs(t1-t3) < 1e-12 and abs(c1(D/2)-c2(D/2)) < 1e-9 and abs(c1(0)-c2(0)) > 5
    register("WT10", "One round trip resolves the air between source and wall.",
             "Delay is integrated slowness: opposite temperature gradients and a uniform profile give identical delays; "
             "the profile is a blind sector until path diversity or local thermometry (H-med).",
             passed, dict(delays=[f_(t1), f_(t2), f_(t3)], profile_endpoints=[f_(c1(0)), f_(c2(0))]), "FALSIFIED-naive")


def WT11_wind(rng):
    D = 3.0; out = []
    for w in (0.0, 2.0, 8.0):
        t_rt = D/(C0+w) + D/(C0-w); radar = C0*t_rt/2
        ll = D/(1-(w/C0)**2)                                                    # acoustic Landau-Lifshitz distance
        tAB, tBA = D/(C0+w), D/(C0-w); w_est = 0.5*D*(1/tAB-1/tBA)
        out.append(dict(w=w, radar=radar, ll=ll, rod=D, w_est=w_est))
    passed = (all(abs(o["radar"]-o["ll"]) < 1e-12 for o in out) and abs(out[0]["radar"]-D) < 1e-12 and
              out[2]["radar"]-D > 1e-3 and all(abs(o["w_est"]-o["w"]) < 1e-9 for o in out))
    register("WT11", "Echo delay times half the sound speed is the distance to the wall.",
             "Only in still air. With wind the echo ('radar') distance is rod/(1 - w^2/c^2), the acoustic Landau-Lifshitz "
             "metric of a stationary non-static medium; a reciprocity (two-way transducer) channel measures w exactly.",
             passed, dict(rows=[{k: f_(v) for k, v in o.items()} for o in out]), "FALSIFIED-naive")


def WT12_descent(rng):
    worst_chart, worst_cocycle = 0.0, 0.0
    for _ in range(100):
        th = rand_theta(rng, 2e-3); m, s = features(th, 3); J = jac(lambda p: features(p, 3)[0], th)/s[:, None]; S = np.eye(len(s))
        # charts act on whitened features (any linear chart of Y is one of Z = S^-1/2 Y); raw units are ill-conditioned
        A, B = rng.normal(size=(4, 4))+3*np.eye(4), rng.normal(size=(4, 4))+3*np.eye(4)
        g = J.T@np.linalg.inv(S)@J
        for M in (A, B@A):
            g2 = (M@J).T@np.linalg.inv(M@S@M.T)@(M@J); worst_chart = max(worst_chart, float(np.linalg.norm(g2-g)/np.linalg.norm(g)))
        worst_cocycle = max(worst_cocycle, float(np.linalg.norm((B@A)-B@A)))
    # experiment relativity and ratio invariance in x (delay channels: constant metric in x)
    gx = lambda N: math.sqrt(N*fisher(np.array([1.0, 0.6, 0.01]), 1)[0, 0])
    ratio = [(gx(N)*1.2)/(gx(N)*0.4) for N in (1, 100)]
    passed = worst_chart < 1e-10 and worst_cocycle == 0.0 and abs(gx(100)/gx(1)-10) < 1e-9 and abs(ratio[0]-3) < 1e-12
    register("WT12", "The wall-tap geometry depends on the feature chart and the number of taps.",
             "The Fisher tensor is chart invariant with exact cocycle (natural descent); RG distance scales with sqrt(N) "
             "(experiment-relative), while displacement ratios in x are invariant (translation covariance of delays).",
             passed, dict(chart_rel_err=f_(worst_chart), sqrtN_factor=f_(gx(100)/gx(1)), ratio=f_(ratio[0])), "HOLDS")


def WT13_cone(rng):
    imag_h, imag_n = 0.0, 0.0
    for _ in range(500):
        xi = rng.normal(); w = rng.uniform(-10, 10)
        r1 = np.roots([1, 2*w*xi, (w*w-C0*C0)*xi*xi]); imag_h = max(imag_h, float(np.max(np.abs(r1.imag))))
        r2 = np.roots([1, 0, C0*C0*xi*xi]); imag_n = max(imag_n, float(np.max(np.abs(r2.imag))/abs(xi)))
    passed = imag_h < 1e-6 and imag_n > 300
    register("WT13", "The acoustic characteristic structure needs no lock.",
             "Still or moving air gives a hyperbolic symbol (tau + w xi)^2 - c^2 xi^2: real roots, a tilted convex cone "
             "(L50 hyperbolic lock). An anti-damped symbol tau^2 + c^2 xi^2 has complex roots growing with frequency "
             "(Hadamard ill-posed).", passed, dict(max_imag_hyperbolic=f_(imag_h), growth_per_unit_frequency_nonhyperbolic=f_(imag_n)),
             "HOLDS")


def WT14_clocks(rng):
    tau = np.sort(rng.uniform(0, 10, 3000)); Tenv = rng.normal(20, 3, tau.size)
    sample = 48000.0*tau + 12.0; metro = 2.0*tau - 0.5; drift = (1+2e-4*(Tenv-20))*tau
    f21 = lambda t: np.interp(t, sample, metro); A = np.vstack([sample, np.ones_like(sample)]).T
    resid = float(np.max(np.abs(A@np.linalg.lstsq(A, metro, rcond=None)[0]-metro)))
    o = np.argsort(sample); ds = np.diff(sample[o]); dd = np.abs(np.diff(drift[o]))
    nonfun = float(np.max(dd[ds < 1.0])) if np.any(ds < 1.0) else 0.0
    passed = resid < 1e-9 and nonfun > 1e-4
    register("WT14", "Any two clocks of the tapping protocol can be converted into each other.",
             "Sample clock and metronome share a kernel: their transition is affine (time flow in Stab). A temperature-"
             "sensitive clock has a different kernel: no transition map exists (non-functional by 1e-4 s).",
             passed, dict(affine_residual=f_(resid), temperature_clock_nonfunctionality=f_(nonfun)), "HOLDS")


def WT15_latent(rng):
    th = np.array([2.0, 0.6, 0.012]); J = jac(lambda p: features(p[:3], 4, 1.0, p[3])[0], np.r_[th, 1.0])
    Kd = np.array([0.0, th[1], 0.0, -1.0]); Kd /= np.linalg.norm(Kd)          # exact (r, g) fibre: law depends on g r
    B1 = np.linalg.pinv(J); w = J@rng.normal(size=4)                            # shear vector in im(J): J B = P_im
    B2 = B1 + np.outer(Kd, w)
    phi = np.eye(4) + (B2-B1)@J
    law_change = float(np.linalg.norm(J@phi-J)/np.linalg.norm(J)); maps = float(np.linalg.norm(phi@B1-B2)/np.linalg.norm(B2))
    P1, P2 = np.diag([1, 0.1, 1e-4, 0.2]), np.diag([1, 0.4, 1e-4, 0.05])
    def rg_dir(P):                                                              # lifted r-displacement, (r,g) part
        v = P@J.T@np.linalg.pinv(J@P@J.T)@(J@np.array([0, 1.0, 0, 0])); u = v[[1, 3]]; return u/np.linalg.norm(u)
    gap = float(np.degrees(np.arccos(min(1.0, abs(rg_dir(P1)@rg_dir(P2))))))
    passed = law_change < 1e-5 and maps < 1e-9 and gap > 5.0      # 1e-5: accuracy of the finite-difference Jacobian
    register("WT15", "The echoes determine how the room moves when the source moves.",
             "No latent connection is law-natural (vertical shear in the contrast-gain fibre preserves the law and maps any "
             "lift to any other); a declared prior covariance selects one, and two priors give different room transport.",
             passed, dict(shear_law_change=f_(law_change), shear_maps_lifts=f_(maps), transport_angle_two_priors_deg=f_(gap)), "FALSIFIED-naive")


# ------------------------------------------------------------------ closure at scale
STATUSES = ("LOCKED", "ESCALATE", "CORRESPONDENCE", "VACUOUS", "INCONSISTENT", "STRUCTURAL_WALL", "OUTSIDE_DOMAIN")
MODULES = ("metric_xrb", "rhythm_b", "distance_x", "wall_metric_x", "contrast_at_wall", "quantum_metric", "latent_room")


def rank_cert(ratio_true, rng, sabot=False):
    """double-escalation certificate on the precision ratio (efficient information / declared target, >= 1 means the
    declared precision is reached), estimated from finite data with relative error 1/sqrt(n)."""
    def q(n, reps=60):
        v = ratio_true*np.abs(1 + rng.normal(0, 3/np.sqrt(n), reps)); return np.quantile(v, [0.01, 0.5])
    if sabot: return "FULL" if q(500)[1] > 1e-12 else "UPPER"
    a, b = q(500), q(2000)
    return "FULL" if (a[0] > 1 and b[0] > 1) else "UPPER"


def make_request(rng):
    level = int(rng.integers(0, 5)); eps = float(rng.choice([0.0, 1e-3, 1.0], p=[0.2, 0.2, 0.6]))
    th = rand_theta(rng); d = (2*L0-2*th[0])/C0
    if rng.random() < 0.15: th[2] = d + rng.uniform(-3e-4, 3e-4)                  # near the fold
    return dict(module=str(rng.choice(MODULES)), level=level, eps=eps, th=th, fold_dist=abs(th[2]-d),
                ref=bool(rng.random() < 0.6), anchor=str(rng.choice(["none", "rod", "thermo+clock"])),
                wind=float(rng.choice([0.0, 0.0, 4.0])), recip=bool(rng.random() < 0.5),
                env_declared=bool(rng.random() < 0.5), shrink=bool(rng.random() < 0.2))


DELTA = np.array([0.1, 1e-3])        # declared target precision for (r, b)


def smallest_sv(req, params, normalized=False, fix_nuisance=False):
    """precision ratio: smallest eigenvalue of the efficient (r,b | x) information in declared precision units.
    normalized=True is the scale-free (correlation) version, kept as a sabotage: it is blind to uniform collapse."""
    if req["level"] < 3: return 0.0
    free = ("g",) if (not req["ref"] and not fix_nuisance) else ()
    G = fisher(req["th"], req["level"], req["eps"], free, ("g",) if req["ref"] else ())
    G = G[:3, :3] - (G[:3, 3:]@np.linalg.pinv(G[3:, 3:])@G[3:, :3] if G.shape[0] > 3 else 0)
    S = G[1:, 1:]-np.outer(G[1:, 0], G[0, 1:])/G[0, 0]
    if normalized:
        Dn = np.sqrt(np.maximum(np.diag(S), 1e-300)); return float(max(np.linalg.eigvalsh(S/np.outer(Dn, Dn)).min(), 0)*1e3)
    Dd = np.diag(DELTA); return float(max(np.linalg.eigvalsh(Dd@S@Dd).min(), 0.0))


def truth(req):
    m = req["module"]
    if m in ("quantum_metric", "latent_room", "contrast_at_wall"): return False
    if not (req["env_declared"] or req["recip"]): return False                 # not admitted: environment undeclared
    if m == "distance_x":
        anchored = req["anchor"] == "thermo+clock" or (req["anchor"] == "rod" and req["level"] >= 1)
        return anchored and (req["wind"] == 0.0 or req["recip"])
    if m == "wall_metric_x": return req["eps"] == 0.0 and not req["shrink"]
    if m == "metric_xrb":
        return req["level"] >= 3 and req["ref"] and req["fold_dist"] > 1e-3 and smallest_sv(req, "xrb") > 1
    if m == "rhythm_b": return req["level"] >= 4 and req["eps"] > 0 and req["fold_dist"] > 1e-3
    return False


def dispatch_request(req, rng, sab):
    m = req["module"]
    if m == "quantum_metric": return "OUTSIDE_DOMAIN"
    if m == "latent_room": return "CORRESPONDENCE"                                # no law-natural connection (WT15)
    if not (req["env_declared"] or req["recip"] or sab.get("ignore_wind")):
        return "OUTSIDE_DOMAIN"                                                    # wind neither declared nor testable
    wind_seen = req["wind"] if (req["recip"] or req["env_declared"]) else 0.0
    if m == "contrast_at_wall":
        return "VACUOUS" if req["eps"] == 0.0 else "ESCALATE"
    if m == "wall_metric_x":
        if req["eps"] != 0.0: return "CORRESPONDENCE"
        return "INCONSISTENT" if (req["shrink"] and not sab.get("weak_hell")) else "LOCKED"
    if m == "distance_x":
        if wind_seen and not req["recip"]: return "INCONSISTENT"
        if req["anchor"] == "none" and not sab.get("silent_c"): return "CORRESPONDENCE"
        if req["anchor"] == "rod" and req["level"] < 1 and not sab.get("silent_c"): return "CORRESPONDENCE"
        return "LOCKED"
    if m == "rhythm_b":
        if req["level"] < 3 or req["eps"] == 0.0: return "VACUOUS" if req["eps"] == 0.0 else "CORRESPONDENCE"
        if req["fold_dist"] <= 1e-3: return "STRUCTURAL_WALL"
        if req["level"] == 3 and not sab.get("ignore_fold"): return "CORRESPONDENCE"   # fold pair {b, 2d-b}
        return "LOCKED"
    if m == "metric_xrb":
        if req["level"] < 3: return "CORRESPONDENCE"
        if req["eps"] == 0.0: return "STRUCTURAL_WALL"
        if not req["ref"] and not sab.get("silent_gain"): return "CORRESPONDENCE"
        if req["fold_dist"] <= 1e-3 and not sab.get("ignore_fold"): return "STRUCTURAL_WALL"
        cert = rank_cert(smallest_sv(req, "xrb", normalized=sab.get("normalized_rank", False),
                                     fix_nuisance=sab.get("silent_gain", False)), rng,
                         sabot=sab.get("numerical_rank", False))
        return "LOCKED" if cert == "FULL" else "STRUCTURAL_WALL"
    return "INCONSISTENT"


def WT16_closure(rng):
    N = MUT.get("wt16_n", 3000); sab = MUT.get("wt16_sabotage", {})
    counts, locks, false_lock, lockable, locked_ok = {}, 0, 0, 0, 0
    for _ in range(N):
        req = make_request(rng); o = dispatch_request(req, rng, sab); t = truth(req)
        counts[o] = counts.get(o, 0)+1
        if o == "LOCKED": locks += 1; false_lock += not t
        lockable += t; locked_ok += t and o == "LOCKED"
    controls = {}
    if not sab:
        for name in ("numerical_rank", "normalized_rank", "ignore_fold", "weak_hell", "silent_c", "silent_gain", "ignore_wind"):
            r2 = np.random.default_rng(int(rng.integers(1 << 30))); fl = 0
            for _ in range(1500):
                req = make_request(r2); o = dispatch_request(req, r2, {name: True}); fl += o == "LOCKED" and not truth(req)
            controls[name] = fl
    power = locked_ok/max(lockable, 1)
    passed = false_lock == 0 and power > 0.9 and set(counts) == set(STATUSES) and (sab or all(v > 0 for v in controls.values()))
    register("WT16", "A worked example can be declared closed by inspection.",
             "Closure at scale: 3000 random wall-tap requests (7 modules x 5 protocols x walls, folds, anchors, wind, noise "
             "families) dispatched with real certificates (in declared precision units) give 0 false LOCKED and all seven "
             "statuses; seven sabotaged certificates, including a scale-free rank test, each produce false LOCKs.", passed,
             dict(requests=N, locks=locks, false_locks=false_lock, lockable=lockable, power=f_(power), status_counts=counts,
                  sabotage_false_locks=controls), "HOLDS")


ATTACKS = [WT01_saturation, WT02_fold, WT03_fold_wall, WT04_matched_wall, WT05_hell, WT06_fisher_wall, WT07_bayes,
           WT08_gain, WT09_dilation, WT10_media, WT11_wind, WT12_descent, WT13_cone, WT14_clocks, WT15_latent, WT16_closure]


def run_all(seed):
    for a in ATTACKS:
        rng = np.random.default_rng([seed, ATTACKS.index(a)])
        try: a(rng)
        except Exception as ex: register(a.__name__[:4], "?", f"EXCEPTION {ex!r}", False, {}, "ERROR")


def canary(seed):
    muts = [("WT05", {"wt05_weak": True})] + [("WT16", {"wt16_sabotage": {k: True}, "wt16_n": 1500}) for k in
                                              ("numerical_rank", "normalized_rank", "ignore_fold", "weak_hell", "silent_c",
                                               "silent_gain", "ignore_wind")]
    ok = True
    for tgt, m in muts:
        RESULTS.clear(); MUT.clear(); MUT.update(m); print(f"--- canary {tgt}: {m}")
        a = next(x for x in ATTACKS if x.__name__.startswith(tgt))
        try: a(np.random.default_rng([seed, ATTACKS.index(a)])); caught = not RESULTS[-1]["passed"]
        except Exception as ex: print(f"    exception {ex!r} (not a clean catch)"); caught = False
        ok &= caught; print(f"    {'CAUGHT' if caught else 'NOT CAUGHT'}")
    MUT.clear(); print("CANARY:", "all caught" if ok else "BATTERY TOO WEAK"); return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--seed", type=int, default=20261004)
    ap.add_argument("--out", default="rg_wall_tap_results.json"); ap.add_argument("--canary", action="store_true")
    a = ap.parse_args()
    if a.canary: sys.exit(canary(a.seed))
    t0 = time.time(); print(f"RG wall-tap battery, seed {a.seed}\n"); run_all(a.seed)
    n = sum(r["passed"] for r in RESULTS)
    summ = dict(seed=a.seed, n_checks=len(RESULTS), n_pass=n, runtime_s=round(time.time()-t0, 1))
    json.dump(dict(summary=summ, results=RESULTS), open(a.out, "w"), indent=2,
              default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print(f"\n{n}/{len(RESULTS)} pass."); sys.exit(0 if n == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
