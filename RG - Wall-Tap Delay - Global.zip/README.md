# RG - Wall-Tap Experiment: battery WT01-WT16 (the whole ladder on its origin)

    python3 rg_wall_tap_attack.py            # seed 20261004 (about 1-2 min)
    python3 rg_wall_tap_attack.py --canary   # 8 sabotages (Hellinger gate + 7 closure certificates); each must fail

16/16 on seeds 20261004, 1, 42, 777, 2026; canary 8/8. Saturation by kernel intersection; exact Z2 rhythm fold
(56% of K) and the fold wall; matched-wall specialization under H-hell; gain fibre; dilation and anchors
(rod, thermometry + counted clock); media blind sector; wind = acoustic Landau-Lifshitz; hyperbolic acoustic cone;
clock groupoid; latent room transport; closure at scale (3000 requests/seed, 0 false LOCKED).
