"""Rooting monotonicity and the Lorentz sign in established frameworks. Exact, symbolic or deterministic; no random sampling.
R1 Blackwell simulation: garbling never lowers Bayes risk (exact rational decision problems)
R2 H-theorem as data processing: D(p_t || pi) decreases along a Markov chain fixing pi (exact rationals, high precision logs)
R3 LAN: Bernoulli log-likelihood ratio at theta + h/sqrt(n) has mean -> -h^2 F/2 and variance -> h^2 F (exact binomial sums)
R4 Koszul-Vinberg: the characteristic function of the 1+1 Lorentz cone is 1/q (exact integral); Hess log is positive definite;
   the radial reflection is -(d/q) J (Lorentzian)
R5 the qubit state cone is the 1+3 Lorentz cone: det(t I + x.sigma) = t^2 - |x|^2; SL(2,C) boosts preserve det; Hess(-log det) > 0;
   Hess det = 2 diag(1, -1, -1, -1)
R6 Lorentz inertia = one declared negative direction (+) a positive transverse Schur complement (hyperbolicity, symbolic)
R7 observed information can be negative while Fisher is positive (Cauchy location, two points)
R8 the slipped sign of the supplied battery is a Type-S error at near-null curvature: expected count vs observed
R9 partial Legendre transform of a convex potential: inertia (1 negative, 1 positive)
Run: python rg_monotone_root.py   (sympy, mpmath, scipy; reads rg_sign_identification_results.json)
"""
import json, math, hashlib, pathlib, itertools
import sympy as sp
import mpmath as mp
from scipy.stats import norm, poisson
RES = {}
def must(c, m):
    if not c: raise AssertionError(m)
R = sp.Rational

# R1 Blackwell: binary hypothesis, prior 1/2, 0-1 loss; Bayes risk = (1 - TV)/2 ... use general losses
P = sp.Matrix([[R(7, 10), R(2, 10)], [R(2, 10), R(5, 10)], [R(1, 10), R(3, 10)]])   # columns: theta0, theta1 ; rows: outcomes
K = sp.Matrix([[R(9, 10), R(3, 10), R(1, 2)], [R(1, 10), R(7, 10), R(1, 2)]])       # garbling 3 -> 2
def bayes_risk(Pm, prior, L):
    """min over decision rules of sum_theta prior(theta) sum_y P(y|theta) L(theta, a(y))"""
    tot = 0
    for y in range(Pm.rows):
        tot += min(sum(prior[th] * Pm[y, th] * L[th][a] for th in range(2)) for a in range(len(L[0])))
    return tot
checks = []
for prior in ([R(1, 2), R(1, 2)], [R(1, 3), R(2, 3)], [R(4, 5), R(1, 5)]):
    for L in ([[0, 1], [1, 0]], [[0, 3], [1, 0]], [[0, 1, R(1, 4)], [2, 0, R(1, 4)]]):
        r_in = bayes_risk(P, prior, L); r_out = bayes_risk(K * P, prior, L)
        checks.append((str(r_in), str(r_out))); must(r_out >= r_in, "R1")
RES["R1"] = dict(claim="Garbling never lowers Bayes risk: whatever is decidable from the garbled record is decidable from the original (simulation)",
                 status="PROVED (Blackwell) + exact on 9 decision problems", risks=checks)

# R2 H-theorem
pi = sp.Matrix([R(1, 2), R(1, 3), R(1, 6)])
T = R(1, 2) * sp.eye(3) + R(1, 2) * pi * sp.ones(1, 3)                    # column-stochastic, T pi = pi
must(T * pi == pi and all(sum(T[:, j]) == 1 for j in range(3)), "R2 stationary")
p = sp.Matrix([R(1, 10), R(1, 10), R(8, 10)]); Ds = []
mp.mp.dps = 50
for n in range(8):
    Ds.append(float(sum(mp.mpf(p[i].p) / p[i].q * mp.log((mp.mpf(p[i].p) / p[i].q) / (mp.mpf(pi[i].p) / pi[i].q)) for i in range(3) if p[i] != 0)))
    p = T * p
must(all(Ds[i + 1] <= Ds[i] + 1e-40 for i in range(len(Ds) - 1)), "R2")
RES["R2"] = dict(claim="For a Markov chain with stationary law pi, D(p_t || pi) is nonincreasing: the second law as data processing",
                 status="PROVED (data processing with T pi = pi) + exact chain", D_sequence=Ds)

# R3 LAN for Bernoulli
mp.mp.dps = 40
def lan(n, th=0.3, h=1.0):
    th1 = th + h / math.sqrt(n); m1 = m2 = mp.mpf(0)
    for k in range(n + 1):
        w = mp.binomial(n, k) * mp.mpf(th) ** k * mp.mpf(1 - th) ** (n - k)
        llr = k * mp.log(th1 / th) + (n - k) * mp.log((1 - th1) / (1 - th))
        m1 += w * llr; m2 += w * llr * llr
    return float(m1), float(m2 - m1 * m1)
F = 1 / (0.3 * 0.7)
lan_vals = {n: lan(n) for n in (100, 1000, 4000)}
errs = {n: (abs(lan_vals[n][0] + F / 2), abs(lan_vals[n][1] - F)) for n in lan_vals}
ratio = errs[1000][0] / errs[4000][0]                                # O(n^-1/2): quadrupling n halves the error
must(errs[4000][0] < errs[1000][0] < errs[100][0] and errs[4000][1] < errs[1000][1] < errs[100][1] and 1.7 < ratio < 2.3, "R3")
RES["R3"] = dict(claim="Local asymptotic normality: every regular iid experiment looks locally like a Gaussian shift with Fisher covariance (Le Cam)",
                 status="IMPORTED (LAN) + exact binomial sums (errors shrink as n^-1/2)", fisher=F, error_ratio_1000_to_4000=ratio, mean_var_by_n={str(k): v for k, v in lan_vals.items()}, target=(-F / 2, F))

# R4 Koszul-Vinberg characteristic function of the 1+1 Lorentz cone
t, x, s0, s1 = sp.symbols("t x s0 s1", real=True)
# cone C = {s0 > |s1|}; pairing <z, s> = t s0 - x s1 ; light-cone coordinates u = s0 + s1, v = s0 - s1 (Jacobian 1/2)
u, v = sp.symbols("u v", positive=True)
Z = sp.integrate(sp.integrate(sp.exp(-((t - x) * u + (t + x) * v) / 2) / 2, (u, 0, sp.oo), conds="none"), (v, 0, sp.oo), conds="none")
q = t ** 2 - x ** 2
must(sp.simplify(Z - 2 / q) == 0, "R4 Z")
H = sp.hessian(sp.log(Z), (t, x))
Jm = sp.diag(1, -1); dd = 2
g = sp.simplify(H - 2 * (sp.Matrix([sp.diff(sp.log(Z), t), sp.diff(sp.log(Z), x)]) * sp.Matrix([sp.diff(sp.log(Z), t), sp.diff(sp.log(Z), x)]).T) / dd)
must(sp.simplify(g + dd * Jm / q) == sp.zeros(2), "R4 reflection")
pd = [sp.simplify(H.subs({t: 2, x: sp.Rational(1, 2)})).eigenvals()]
RES["R4"] = dict(claim="Lorentz-cone characteristic function Z = 2/(t^2 - x^2); Fisher = Hess log Z is positive definite; the radial reflection "
                       "F - alpha^{-1} dPsi dPsi equals -(d/q) J (Lorentzian)", status="PROVED (exact integral and symbolic algebra)",
                 Z=str(Z), fisher_eigs_at_t2_x0p5=[str(sp.N(e, 8)) for e in pd[0]], reflection=str(g))

# R5 qubit cone = Lorentz cone
x1, x2, x3 = sp.symbols("x1 x2 x3", real=True)
sx = sp.Matrix([[0, 1], [1, 0]]); sy = sp.Matrix([[0, -sp.I], [sp.I, 0]]); sz = sp.Matrix([[1, 0], [0, -1]])
M = t * sp.eye(2) + x1 * sx + x2 * sy + x3 * sz
detM = sp.expand(M.det())
must(sp.simplify(detM - (t ** 2 - x1 ** 2 - x2 ** 2 - x3 ** 2)) == 0, "R5 det")
eta = sp.Symbol("eta", real=True)
Bst = sp.Matrix([[sp.exp(eta / 2), 0], [0, sp.exp(-eta / 2)]])          # SL(2,C) boost along z
Mb = Bst * M * Bst.H
must(sp.simplify(Mb.det() - detM) == 0, "R5 boost")
Hdet = sp.hessian(detM, (t, x1, x2, x3)); Hlog = sp.hessian(-sp.log(detM), (t, x1, x2, x3))
pt = {t: 1, x1: sp.Rational(1, 5), x2: sp.Rational(1, 7), x3: sp.Rational(1, 3)}
eig_log = [float(e) for e in sp.Matrix(Hlog.subs(pt)).eigenvals(multiple=True)]
must(Hdet == sp.diag(2, -2, -2, -2) and min(eig_log) > 0, "R5")
RES["R5"] = dict(claim="The positive cone of a qubit (2x2 PSD matrices t I + x.sigma) is the 1+3 Lorentz cone: det = t^2 - |x|^2, preserved by SL(2,C); "
                       "Hess(-log det) > 0 (canonical barrier), Hess det = 2 diag(1,-1,-1,-1)", status="PROVED (symbolic)",
                 min_eig_barrier_hessian=min(eig_log))

# R6 hyperbolicity: inertia = (-1) + positive Schur complement
a_, b1, b2, c11, c12, c22, w, k1, k2 = sp.symbols("a b1 b2 c11 c12 c22 omega k1 k2", real=True)
Q = a_ * w ** 2 + 2 * w * (b1 * k1 + b2 * k2) + c11 * k1 ** 2 + 2 * c12 * k1 * k2 + c22 * k2 ** 2
bvec = sp.Matrix([b1, b2]); C = sp.Matrix([[c11, c12], [c12, c22]]); Hs = C - bvec * bvec.T / a_
completed = a_ * (w + (b1 * k1 + b2 * k2) / a_) ** 2 + (sp.Matrix([k1, k2]).T * Hs * sp.Matrix([k1, k2]))[0]
must(sp.simplify(sp.expand(completed - Q)) == 0, "R6")
RES["R6"] = dict(claim="Q = a (omega + b.k/a)^2 + k^T (C - b b^T/a) k: with a < 0, Q is Lorentzian (one negative direction) iff the transverse Schur "
                       "complement is positive definite. The positive block is where monotone (Fisher, efficient-information) geometry enters",
                 status="PROVED (symbolic completion of the square)")

# R7 observed information negative, Fisher positive (Cauchy location, data at +-3, evaluated at theta = 0)
th = sp.Symbol("theta", real=True)
ll = -sp.log(1 + (3 - th) ** 2) - sp.log(1 + (-3 - th) ** 2)
obs_info = sp.simplify(-sp.diff(ll, th, 2).subs(th, 0))
must(obs_info < 0, "R7")
RES["R7"] = dict(claim="Observed information (minus the Hessian of the log-likelihood) can be negative away from the maximum, while Fisher information "
                       "(its expectation) is 1/2 per Cauchy observation and never negative", status="PROVED (exact)", observed_information_at_0=str(obs_info),
                 fisher_per_point="1/2")

# R8 Type-S analysis of the supplied identification battery
d = json.loads(pathlib.Path("rg_sign_identification_results.json").read_text())
exp_count = 0.0; rows = []; observed = 0
for de in d["designs"]:
    if not de["admitted"]: continue
    Rt = -2 * (de["b_true"] + 0.15 ** 2); se = de["predicted_R_se"]
    ps = float(norm.cdf(-1.959963984540054 - abs(Rt) / se)); exp_count += 100 * ps; observed += de["wrong_sign_certificates"]
    if ps > 1e-3: rows.append(dict(L=de["L"], b=de["b_true"], exposure=de["exposure"], R_true=Rt, se=se, snr=abs(Rt) / se, p_wrong_sign=ps,
                                   observed_wrong=de["wrong_sign_certificates"]))
p_at_least = float(1 - poisson.pmf(0, exp_count)) if observed >= 1 else 1.0
must(abs(observed - 1) == 0 and exp_count > 0.5, "R8")
RES["R8"] = dict(claim="The one wrong-sign curvature certificate is a Type-S error at near-null truth (b = 0, |R|/se ~ 0.47), not a structural sign error",
                 status="COMPUTED from the supplied results", expected_wrong_sign=exp_count, observed=observed, prob_at_least_one=p_at_least, near_null_designs=rows)

# R9 partial Legendre of a convex potential
xx, yy, et = sp.symbols("x y eta", real=True)
Phi = xx ** 2 + xx * yy + yy ** 2 + sp.exp(yy)
A_ = sp.diff(Phi, xx, 2); B_ = sp.diff(Phi, xx, yy); C_ = sp.diff(Phi, yy, 2)
HPsi = sp.Matrix([[A_ - B_ ** 2 / C_, B_ / C_], [B_ / C_, -1 / C_]])
vals = [float(e) for e in HPsi.subs({xx: 0, yy: 0}).eigenvals(multiple=True)]
must(sum(1 for e in vals if e < 0) == 1 and sum(1 for e in vals if e > 0) == 1, "R9")
RES["R9"] = dict(claim="Partial Legendre transform of a convex potential in one variable has inertia (1 negative, 1 positive): thermodynamic saddles",
                 status="PROVED (block inverse, inertia additivity) + exact instance", eigenvalues=vals)
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_monotone_root_results.json").write_text(json.dumps(RES, indent=1, default=str))
for k_, v_ in RES.items():
    if isinstance(v_, dict): print(k_, "|", v_["status"])
print(Ds[:4], lan_vals, RES["R8"]["expected_wrong_sign"], RES["R8"]["prob_at_least_one"], obs_info)
