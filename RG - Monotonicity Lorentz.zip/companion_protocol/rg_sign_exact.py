"""Symbolic derivation checks for Hessians, sign, isotropy and physical curvature."""
from pathlib import Path
import hashlib,json
import sympy as s
P=Path(__file__).resolve().parent
checks=[]
def chk(name,ok,value): checks.append(dict(name=name,passed=bool(ok),value=value))
x,y,t=s.symbols('x y t',real=True)
q,u=s.symbols('q u',positive=True)
f=[t*s.log(t)-t+1,(t-1)**2/2,2*(s.sqrt(t)-1)**2,-s.log(t)+t-1]
chk('E01 normalized_f_Hessians',all(s.diff(z,t,2).subs(t,1)==1 for z in f),[str(s.diff(z,t,2).subs(t,1)) for z in f])
# Nonlinear coordinate Hessian and stationarity correction.
V=x*x/2; pull=s.exp(y)**2; ordinary=s.diff(V.subs(x,s.exp(y)),y,2)
chk('E02 Hessian_coordinate_correction',s.simplify(ordinary-2*pull)==0,str(ordinary))
theta,Y=s.symbols('theta Y',real=True); ell=-(Y-theta**2)**2/2
obs=-s.diff(ell,theta,2)
chk('E03 observed_vs_expected_information',s.simplify(obs-(6*theta**2-2*Y))==0,{'observed':str(obs),'at_theta_half_y2':str(obs.subs({theta:s.Rational(1,2),Y:2})),'expectation':str(s.simplify(obs.subs(Y,theta**2)))})
# A two-variable positive Hessian and its partial Legendre transform.
a,b,c=s.symbols('a b c',positive=True); eta=s.symbols('eta',real=True)
Phi=(a*x*x+2*b*x*y+c*y*y)/2; yy=(eta-b*x)/c; Psi=s.expand((Phi-eta*y).subs(y,yy)); H=s.hessian(Psi,(x,eta))
expected=s.Matrix([[a-b*b/c,b/c],[b/c,-1/c]])
chk('E04 partial_Legendre_Hessian',s.simplify(H-expected)==s.zeros(2),str(H))
chk('E05 partial_Legendre_determinant',s.simplify(H.det()+a/c)==0,str(s.factor(H.det())))
# 1+3 Lorentz invariant symmetric forms under rotations and boosts.
z=s.symbols('z0:10'); G=s.zeros(4); idx=0
for i in range(4):
 for j in range(i,4): G[i,j]=G[j,i]=z[idx]; idx+=1
gens=[]; rots=[]
for i in range(1,4):
 for j in range(i+1,4):
  A=s.zeros(4); A[i,j]=1; A[j,i]=-1; rots.append(A)
for i in range(1,4):
 A=s.zeros(4); A[0,i]=A[i,0]=1; gens.append(A)
def constraints(gs):
 eq=[]
 for A in gs: eq+=list(A.T*G+G*A)
 return s.linear_eq_to_matrix(eq,z)[0]
rot=constraints(rots); full=constraints(rots+gens); ns=full.nullspace()
chk('E06 rotations_leave_two_form_parameters',10-rot.rank()==2,10-rot.rank())
chk('E07 Lorentz_isotropy_form_line',len(ns)==1,len(ns))
vec=ns[0]; GG=s.zeros(4); idx=0
for i in range(4):
 for j in range(i,4): GG[i,j]=GG[j,i]=vec[idx]; idx+=1
chk('E08 Lorentz_line_is_indefinite',GG==s.diag(-1,1,1,1) or GG==-s.diag(-1,1,1,1),str(GG))
# Principal symbol discriminant identity, two spatial dimensions sufficient algebra.
A,B1,B2,C11,C12,C22,w,k1,k2=s.symbols('A B1 B2 C11 C12 C22 w k1 k2',real=True)
qq=A*w*w+2*(B1*k1+B2*k2)*w+C11*k1*k1+2*C12*k1*k2+C22*k2*k2
sch=(C11-B1*B1/A)*k1*k1+2*(C12-B1*B2/A)*k1*k2+(C22-B2*B2/A)*k2*k2
chk('E09 principal_discriminant_Schur',s.simplify(s.discriminant(qq,w)+4*A*sch)==0,str(s.factor(s.discriminant(qq,w))))
# Full connection and curvature calculation for 1+1 static and conformal metrics.
def curvature(metric,coords):
 d=len(coords); inv=metric.inv(); Gamma=[[[s.simplify(sum(inv[a,l]*(s.diff(metric[l,c],coords[b])+s.diff(metric[l,b],coords[c])-s.diff(metric[b,c],coords[l])) for l in range(d))/2) for c in range(d)] for b in range(d)] for a in range(d)]
 R={}
 for a in range(d):
  for b in range(d):
   for m in range(d):
    for n in range(d):
     val=s.diff(Gamma[a][n][b],coords[m])-s.diff(Gamma[a][m][b],coords[n])+sum(Gamma[a][m][l]*Gamma[l][n][b]-Gamma[a][n][l]*Gamma[l][m][b] for l in range(d))
     R[a,b,m,n]=s.simplify(val)
 Ric=s.Matrix(d,d,lambda b,n:s.simplify(sum(R[a,b,a,n] for a in range(d))))
 scalar=s.simplify(sum(inv[b,n]*Ric[b,n] for b in range(d) for n in range(d)))
 return Gamma,R,Ric,scalar
N=s.Function('N')(x); coords=(t,x); metric=s.diag(-N*N,1)
Gamma,R,Ric,scalar=curvature(metric,coords)
chk('E10 static_metric_scalar',s.simplify(scalar+2*s.diff(N,x,2)/N)==0,str(scalar))
chk('E11 static_tidal_component',s.simplify(R[1,0,1,0]-N*s.diff(N,x,2))==0,str(R[1,0,1,0]))
phi=s.Function('phi')(x); cm=s.exp(2*phi)*s.diag(-1,1); _,_,_,cs=curvature(cm,coords)
chk('E12 conformal_curvature_same_null_cone',s.simplify(cs+2*s.exp(-2*phi)*s.diff(phi,x,2))==0,str(cs))
aa,bb=s.symbols('a b',real=True); NN=s.exp(aa*x+bb*x*x/2); EE=s.simplify(s.diff(NN,x,2)/NN)
chk('E13 clock_family_tidal_formula',s.simplify(EE-(bb+(aa+bb*x)**2))==0,str(EE))
# Polynomial witness of missing second-derivative control on a finite grid.
B=x*x*(x*x-1)**2
chk('E14 finite_grid_second_derivative_escape',all(B.subs(x,z)==0 for z in [-1,0,1]) and s.diff(B,x,2).subs(x,0)==2,{'samples':[str(B.subs(x,z)) for z in [-1,0,1]],'second_derivative_at_zero':str(s.diff(B,x,2).subs(x,0))})
# Fisher score and curvature gradient for Poisson lapse clocks.
mu=s.exp(aa*x+bb*x*x/2); grad=s.Matrix([s.diff(mu,aa),s.diff(mu,bb)]); FI=s.simplify(grad*grad.T/mu)
chk('E15 Poisson_Fisher_design',s.simplify(FI-mu*s.Matrix([[x*x,x**3/2],[x**3/2,x**4/4]]))==s.zeros(2),str(FI))
# Mixed KL two-point Hessian on one Bernoulli coordinate.
p,r=s.symbols('p r',positive=True); D=p*s.log(p/r)+(1-p)*s.log((1-p)/(1-r)); cross=s.diff(D,p,r).subs(r,p)
chk('E16 mixed_divergence_Hessian_sign',s.simplify(cross+1/(p*(1-p)))==0,str(s.factor(cross)))
# Log-homogeneous cone potential: positive Fisher and radial Lorentz reflection.
z0,z1,z2,z3=s.symbols('z0 z1 z2 z3',real=True); zz=s.Matrix([z0,z1,z2,z3]); J=s.diag(1,-1,-1,-1); qq=(zz.T*J*zz)[0]; alpha=s.Integer(2)
psi=-alpha*s.log(qq); FF=s.hessian(psi,tuple(zz)); dpsi=s.Matrix([s.diff(psi,z) for z in zz]); gg=FF-dpsi*dpsi.T/alpha
chk('E17 cone_radial_reflection_identity',s.simplify(gg+alpha*s.hessian(qq,tuple(zz))/qq)==s.zeros(4),str(s.simplify(gg)))
chk('E18 log_homogeneous_radial_Fisher_norm',s.simplify((zz.T*FF*zz)[0]-2*alpha)==0,str(s.simplify((zz.T*FF*zz)[0])))
# Nonquadratic homogeneous perturbation with the same cone, on an admitted local window.
Q=(t*t-x*x)*(1+s.Rational(1,20)*x*x/(t*t)); third=s.diff(Q,x,3)
chk('E19 same_cone_nonquadratic_defining_function',s.simplify(third)!=0,str(s.factor(third)))
res={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'sympy':s.__version__,'checks':checks,'passed':sum(v['passed'] for v in checks),'total_checks':len(checks),'scope':'Symbolic identities and finite linear constraint systems; universal theorem proofs are in the paper.'}
(P/'rg_sign_exact_results.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n'); print(json.dumps(res,indent=2)); assert res['passed']==len(checks)
