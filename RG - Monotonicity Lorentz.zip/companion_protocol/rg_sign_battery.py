"""Probability, monotonicity, Hessian and Lorentz classification battery.
All generated records are synthetic mathematical or statistical examples.
Run python rg_sign_battery.py --out .
"""
import argparse,csv,hashlib,json,platform
from pathlib import Path
import numpy as np
import scipy
from scipy.linalg import null_space
from scipy.integrate import quad
SEED=20261102
SPEC={'seed':SEED,'random_channel_cases':500,'quadratic_dimensions':[2,3,4,5,6],'cases_per_inertia':10,'symbol_reconstruction_cases':100,'rank_one_cases':100,'mixture_integrals':100,'metric_perturbation_cases':200,'scope':'Synthetic finite laws and declared quadratic physical models only. Source-defined development design, not external preregistration.'}
def main(out):
 out=Path(out); out.mkdir(parents=True,exist_ok=True); rng=np.random.default_rng(SEED)
 rows=[]; checks=[]; summary={}
 def rec(family,**kw): rows.append(dict(family=family,**kw))
 def chk(name,ok,value): checks.append(dict(name=name,passed=bool(ok),value=value))
 def law(n): return rng.dirichlet(np.ones(n)*2)
 def chan(m,n): return np.column_stack([law(m) for _ in range(n)])
 def F(p,v): return float(np.sum(v*v/p))
 def KL(p,q): return float(np.sum(p*np.log(p/q)))
 def inertia(A,tol=1e-9):
  w=np.linalg.eigvalsh(A); return [int(sum(w<-tol)),int(sum(abs(w)<=tol)),int(sum(w>tol))]
 def pack(A): return np.array([A[i,j] for i in range(len(A)) for j in range(i,len(A))])
 def unpack(a,d):
  A=np.zeros((d,d)); z=0
  for i in range(d):
   for j in range(i,d): A[i,j]=A[j,i]=a[z]; z+=1
  return A
 def design(v): return np.array([v[i]*v[j]*(1 if i==j else 2) for i in range(len(v)) for j in range(i,len(v))])
 variance=[]; dpi=[]; hes=[]; hesserr=[]
 for trial in range(500):
  n=int(rng.choice([2,3,5,8])); m=max(2,n-1); p=law(n); q=law(n); K=chan(m,n); v=rng.normal(size=n); v-=v.mean(); v/=np.linalg.norm(v)
  s=v/p; sy=(K@v)/(K@p); dd=F(p,v)-F(K@p,K@v); vv=float(np.sum(p[None,:]*K*(s[None,:]-sy[:,None])**2))
  variance.append(abs(dd-vv)/(1+abs(dd)))
  # Four convex f-divergences, all normalized to f''(1)=1.
  funs=[lambda z:z*np.log(z)-z+1,lambda z:(z-1)**2/2,lambda z:2*(np.sqrt(z)-1)**2,lambda z:-np.log(z)+z-1]
  gaps=[]
  for f in funs: gaps.append(float(np.dot(q,f(p/q))-np.dot(K@q,f((K@p)/(K@q)))))
  dpi+=gaps
  # Stable central KL Hessian: log1p and exact cancellation of first derivative.
  step=1e-4*float(np.min(p/(abs(v)+1e-30)))
  r=step*v/p
  cent=float(np.sum(p*((1+r)*np.log1p(r)+(1-r)*np.log1p(-r))))/step**2
  hesserr.append(abs(cent/F(p,v)-1))
  rec('M01_channel',case=trial,n=n,fisher_loss=dd,variance_error=variance[-1],minimum_divergence_loss=min(gaps),hessian_relative_error=hesserr[-1])
 chk('M01 conditional_score_variance',max(variance)<1e-10,float(max(variance)))
 chk('M02 convex_divergence_DPI_examples',min(dpi)>-1e-10,float(min(dpi)))
 chk('M03 diagonal_KL_Hessian',max(hesserr)<1e-6,float(max(hesserr)))
 # Integrated Hessian defect equals finite KL loss.
 ie=[]
 for i in range(100):
  p=law(4); q=law(4); K=chan(3,4); v=p-q
  val=quad(lambda t:(1-t)*(F(q+t*v,v)-F(K@(q+t*v),K@v)),0,1,epsabs=1e-11)[0]
  gap=KL(p,q)-KL(K@p,K@q); ie.append(abs(val-gap)); rec('M02_integral',case=i,integral=val,KL_loss=gap,error=ie[-1])
 chk('M04 mixture_Hessian_loss_integral',max(ie)<1e-9,float(max(ie)))
 # Diagonal Fisher does not imply finite DPI: sufficient splitting and reverse merge.
 p=np.array([.7,.3]); q=np.array([.4,.6]); E=np.array([[.5,0],[.5,0],[0,1.]])
 D=lambda p,q:KL(p,q)+float(np.dot(p-q,p-q))**2
 violation=D(p,q)-D(E@p,E@q)
 chk('M05 same_Hessian_nonmonotone_finite_divergence',violation>1e-3,float(violation))
 summary['finite_DPI_counterexample']={'reverse_merge_increase':violation,'input_D':D(E@p,E@q),'output_D':D(p,q),'diagonal_Hessian':'Fisher exactly; quartic term has zero diagonal Hessian'}
 # Nonlinear coordinate Hessian and observed likelihood negative witnesses.
 summary['Hessian_witnesses']={'nonlinear_coordinate_at_zero':{'ordinary_Hessian':2.,'tensor_pullback':1.},'observed_Gaussian_mean_theta_squared':{'theta':.5,'y':2.,'observed_information':-2.5,'expected_Fisher':1.},'moving_support_Uniform_0_theta_at_1':{'score_square':1.,'negative_expected_log_Hessian':-1.},'thermal_two_level_at_beta_0':{'logZ_second':.25,'free_energy_T_second_at_T_1':-float(np.exp(1)/(1+np.exp(1))**2)}}
 chk('H01 coordinate_Hessian_is_not_tensor_off_critical',2.!=1.,[2.,1.])
 chk('H02 observed_Hessian_is_not_Fisher',-2.5<0 and 1.>0,[-2.5,1.])
 # Partial Legendre saddle: one dual variable gives exactly one negative direction.
 leg=[]; rankflip=[]
 for i in range(100):
  n=3; Z=rng.normal(size=(n+1,n+1)); H=Z.T@Z+np.eye(n+1); A=H[:n,:n]; B=H[:n,n:]; C=H[n:,n:]; Ci=np.linalg.inv(C)
  S=np.block([[A-B@Ci@B.T,B@Ci],[Ci@B.T,-Ci]])
  leg.append(inertia(S)==[1,0,3]);
  Z=rng.normal(size=(4,4)); FF=Z.T@Z+np.eye(4); u=rng.normal(size=4); u/=np.sqrt(u@FF@u); cov=FF@u; g=FF-2*np.outer(cov,cov)
  rankflip.append(inertia(g)==[1,0,3]); rec('S01_sign_operations',case=i,partial_Legendre_inertia=str(inertia(S)),clock_reflection_inertia=str(inertia(g)))
 chk('S01 partial_Legendre_inertia',all(leg),sum(leg))
 chk('S02 clock_reflection_inertia',all(rankflip),sum(rankflip))
 # Lorentz reflection does not preserve the positive Loewner order.
 signed_diff=np.diag([-1.,1.]); chk('S03 signed_metric_not_Fisher_DPI',inertia(signed_diff)==[1,0,1],inertia(signed_diff))
 # Exact-inertia classification of quadratic principal symbols under random congruence.
 classes={}; wrong=0; total=0
 for d in [2,3,4,5,6]:
  for neg in range(d+1):
   for z in range(10):
    Q,_=np.linalg.qr(rng.normal(size=(d,d))); vals=np.r_[-rng.uniform(.5,2,neg),rng.uniform(.5,2,d-neg)]; A=(Q*vals)@Q.T
    ni,zero,pi=inertia(A)
    label='ELLIPTIC' if ni==0 or pi==0 else ('LORENTZ' if min(ni,pi)==1 else 'ULTRAHYPERBOLIC')
    expected='ELLIPTIC' if neg in [0,d] else ('LORENTZ' if min(neg,d-neg)==1 else 'ULTRAHYPERBOLIC')
    wrong+=label!=expected; total+=1; classes[label]=classes.get(label,0)+1
    rec('Q01_classification',dimension=d,negative=ni,zero=zero,positive=pi,label=label)
 chk('Q01 quadratic_inertia_classification',wrong==0,{'cases':total,'errors':wrong,'counts':classes})
 # Construct arbitrary shift/lapse spatial form; discriminant and Schur bridge.
 disc=[]; schur=[]
 for i in range(200):
  a=-float(rng.uniform(.3,2)); b=rng.normal(size=3); Z=rng.normal(size=(3,3)); H=Z.T@Z+.5*np.eye(3); C=H+np.outer(b,b)/a
  A=np.block([[np.array([[a]]),b[None,:]],[b[:,None],C]])
  k=rng.normal(size=3); discriminant=(b@k)**2-a*(k@C@k); rhs=-a*(k@H@k)
  disc.append(abs(discriminant-rhs)/(1+abs(rhs))); schur.append(inertia(A)==[1,0,3]); rec('Q02_hyperbolic',case=i,discriminant=discriminant,identity_error=disc[-1])
 chk('Q02 discriminant_Schur_identity',max(disc)<1e-10,float(max(disc)))
 chk('Q03 one_time_signature_from_positive_Schur',all(schur),sum(schur))
 # Quadratic-form identification from directional responses, and null cone up to scale.
 ids=[]; cones=[]; held=[]
 for i in range(100):
  Z=rng.normal(size=(3,3)); H=Z.T@Z+np.eye(3); A=np.zeros((4,4)); A[0,0]=-1.; A[1:,1:]=H
  probes=[np.eye(4)[j] for j in range(4)]+[np.eye(4)[j]+np.eye(4)[k] for j in range(4) for k in range(j+1,4)]
  X=np.array([design(v) for v in probes]); y=np.array([v@A@v for v in probes]); fit=unpack(np.linalg.solve(X,y),4)
  ids.append(float(np.linalg.norm(fit-A))); v=rng.normal(size=4); held.append(abs(v@fit@v-v@A@v))
  # 30 exact null rays, arbitrary spatial directions, time root positive.
  rays=[]
  for j in range(30):
   k=rng.normal(size=3); rays.append(np.r_[np.sqrt(k@H@k),k])
  XX=np.array([design(v) for v in rays]); U,sv,Vt=np.linalg.svd(XX,full_matrices=False); cc=Vt[-1]; cc*=-1/cc[0]; fitted=unpack(cc,4)
  cones.append(float(np.linalg.norm(fitted-A)/np.linalg.norm(A)))
  rec('I01_symbol_identification',case=i,full_rank=int(np.linalg.matrix_rank(X)),cone_rank=int(np.linalg.matrix_rank(XX)),full_error=ids[-1],cone_error=cones[-1],heldout_error=held[-1])
 chk('I01 full_quadratic_identification',max(ids)<1e-10,float(max(ids)))
 chk('I02 null_cone_identification_up_to_anchor',max(cones)<1e-9,float(max(cones)))
 chk('I03 heldout_directional_response',max(held)<1e-9,float(max(held)))
 # Stability of signature under a certified operator-norm perturbation.
 stable=[]; admitted=0; abstain=0
 for i in range(200):
  vals=np.array([-1.,.4,.8,1.5]); Q,_=np.linalg.qr(rng.normal(size=(4,4))); A=(Q*vals)@Q.T; Z=rng.normal(size=(4,4)); Z=(Z+Z.T)/2
  eta=float(rng.choice([.01,.1,.5])); Z*=eta/np.linalg.norm(Z,2); B=A+Z; margin=float(np.min(abs(np.linalg.eigvalsh(B)))); admit=margin>eta
  if admit: admitted+=1; stable.append(inertia(A)==inertia(B))
  else: abstain+=1
  rec('I02_signature_margin',case=i,perturbation_bound=eta,observed_margin=margin,status='CERTIFIED' if admit else 'ABSTAIN')
 chk('I04 Weyl_signature_certificate',all(stable) and admitted>0 and abstain>0,{'admitted':admitted,'abstained':abstain})
 # Multi-cone and non-quadratic branches must not be collapsed.
 k=np.array([1.,0,0]); speeds=[1.,2.]; roots=sorted([-s*np.linalg.norm(k) for s in speeds]+[s*np.linalg.norm(k) for s in speeds])
 chk('Q04 quartic_multicone_retained',len(set(roots))==4,roots)
 # Neutral mixed divergence Hessian is not physical one-time geometry.
 neutral=np.block([[np.zeros((3,3)),-np.eye(3)],[-np.eye(3),np.zeros((3,3))]])
 chk('S04 mixed_two_point_Hessian_neutral',inertia(neutral)==[3,0,3],inertia(neutral))
 # Explicit no-go controls.
 can=[]
 def canary(name,ok,witness): can.append(dict(name=name,detected=bool(ok),witness=witness))
 canary('Fisher_pullback_cannot_create_negative_direction',min(np.linalg.eigvalsh(np.eye(4)))>0,1.)
 canary('diagonal_Hessian_does_not_imply_finite_DPI',violation>0,violation)
 canary('arbitrary_Hessian_not_tensor',2!=1,[2,1])
 canary('observed_information_not_expected_Fisher',-2.5<0,[-2.5,1.])
 canary('moving_support_breaks_information_identity',1!=-1,[1,-1])
 # Euclidean merging can increase distinguishability.
 v=np.array([1.,1.,-2.]); K=np.array([[1,1,0],[0,0,1.]])
 canary('kernel_inclusion_does_not_select_monotonic_metric',np.dot(K@v,K@v)>v@v,[float(v@v),float((K@v)@(K@v))])
 # Ultra-hyperbolic form with two time directions has imaginary frequency for a transverse time axis.
 canary('two_times_not_one_time_hyperbolicity',(-1.)<0,{'omega_squared_for_transverse_second_time':-1.})
 canary('neutral_Hessian_not_Lorentz_in_dimension_above_two',inertia(neutral)[0]>1,inertia(neutral))
 canary('sign_flip_does_not_preserve_Loewner_order',min(np.linalg.eigvalsh(signed_diff))<0,inertia(signed_diff))
 # Same null cone, nonconstant conformal scale, different curvature.
 canary('null_cone_does_not_determine_curvature',-.6!=0,{'flat_R':0.,'conformal_phi_point3_x_squared_over2_R_at_0':-.6})
 # One clock height gives one combination of two parameters, different curvature.
 a1,b1=.1,.2; a2,b2=.2,0.; f1=a1+b1/2; f2=a2+b2/2
 canary('one_clock_height_does_not_identify_curvature',abs(f1-f2)<1e-12 and abs((b1+a1*a1)-(b2+a2*a2))>.1,{'same_log_lapse':f1,'E_values':[b1+a1*a1,b2+a2*a2]})
 # Arbitrary smooth bump invisible on a finite spatial grid.
 grid=np.array([-1.,0.,1.]); values=grid**2*(grid**2-1)**2
 canary('finite_sampling_cannot_certify_unrestricted_second_derivatives',np.max(abs(values))==0 and 2.>0,{'sample_values':values.tolist(),'polynomial_second_derivative_at_zero':2.})
 # Positive scalar Hessian can fail Markov monotonicity.
 p=np.array([.5,.5]); u=np.array([1.,-1.]); E=np.array([[.5,0],[.5,0],[0,1.]])
 canary('convex_potential_does_not_imply_Markov_metric',float((E@u)@(E@u))!=float(u@u),[float(u@u),float((E@u)@(E@u))])
 chk('C01 computed_and_analytic_canaries',all(v['detected'] for v in can),len(can))
 summary.update({'max_variance_residual':max(variance),'max_KL_Hessian_relative_error':max(hesserr),'max_integral_error':max(ie),'classification_counts':classes,'classification_cases':total,'max_full_identification_error':max(ids),'max_cone_identification_error':max(cones),'max_heldout_error':max(held),'canaries':can})
 keys=['family']+sorted(set().union(*(r.keys() for r in rows))-{'family'})
 with (out/'rg_sign_runs.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=keys); w.writeheader(); w.writerows(rows)
 spec=(json.dumps(SPEC,sort_keys=True,indent=2)+'\n').encode(); (out/'rg_sign_spec.json').write_bytes(spec)
 result={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'spec_sha256':hashlib.sha256(spec).hexdigest(),'environment':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__},'rows':len(rows),'checks':checks,'passed':sum(v['passed'] for v in checks),'total_checks':len(checks),'summary':summary}
 (out/'rg_sign_results.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n'); print(json.dumps(result,indent=2)); assert result['passed']==len(checks)
if __name__=='__main__':
 ap=argparse.ArgumentParser(); ap.add_argument('--out',default='.'); main(ap.parse_args().out)
