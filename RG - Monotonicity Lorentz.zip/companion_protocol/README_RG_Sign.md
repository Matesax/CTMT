# RG monotonicity, Hessian and Lorentz-sign derivation release

## Scope
A complete conditional mathematical derivation and an executed synthetic identification pipeline. This does not claim probability alone implies spacetime, laboratory validation, or Einstein field equations.

## Files
- rg_monotonicity_lorentz_protocol.pdf / .tex: proofs, hypotheses, classification, physical-response protocol and results.
- rg_sign_battery.py: finite laws, DPI, diagonal Hessians, mixture integrals, sign operations, quadratic classification, exact-law reconstruction and spectral margins.
- rg_sign_exact.py: 19 symbolic checks.
- rg_sign_cone.py: normalized cone exponential-family sampling, positive Fisher and radial sign bridge.
- rg_sign_identification.py: 3,600 synthetic Poisson clock fits and independent Gaussian tidal readouts. Raw counts and readouts are preserved.
- rg_sign_robust.py: truth-independent uniform sensitivity bounds on |a|<=0.3, |b|<=0.2.
- rg_sign_verify.py: independent source-hash and raw-record recomputation, including likelihood scores and propagated uncertainty.
- rg_sign_run_all.py: executes all five batteries and verification.
- JSON/CSV: complete results, raw records and design gates.
- rg_sign_overview.png: synthetic diagnostic figure.

## Reproduction
python rg_sign_run_all.py
python rg_sign_verify.py
pdflatex rg_monotonicity_lorentz_protocol.tex
pdflatex rg_monotonicity_lorentz_protocol.tex

NumPy, SciPy and SymPy are required. Matplotlib is optional for plots. Tested versions are recorded in the result files and requirements.

## Final executed results
50/50 battery assertion groups; 24/24 independent consistency checks.
250 nondegenerate quadratic forms: 100 elliptic, 90 Lorentzian, 60 ultrahyperbolic; zero classification mismatches.
100 four-dimensional exact-law symbol reconstructions.
36 clock truth/design combinations, 100 trials each. Initial oracle sensitivity study admits 2,100 trials: curvature coverage 0.9480952381, held-out coverage 0.9495238095, 1 wrong-sign interval among 1,668 issued.
Uniform nonoracle gate admits 1,500 trials: curvature coverage 0.9466666667, held-out coverage 0.95, 0 observed wrong-sign intervals among 1,382 issued. Zero observed errors is not a zero-risk guarantee.
All examples are synthetic. Wald intervals have empirical calibration here, not a universal finite-sample coverage proof.

## Development audit
1. An initial symbolic assertion used structural equality for equivalent exponential expressions. It was corrected to symbolic simplification; the identity itself did not change.
2. A stronger raw-score audit detected a maximum normalized residual about 5.75e-6 despite the initial small-step Newton stop. Final Newton polishing and score-based convergence reduced the maximum residual below 8.72e-14. The raw observations, final estimates and residuals are preserved.
3. The initial oracle design gate was not presented as deployable. A separate analytically uniform parameter-box gate was derived and executed without selecting by observed coverage.
4. All counterexamples and the initial study's one wrong-sign interval remain in the release.

The six user-supplied PDFs are research inputs, not included in this archive; their SHA-256 hashes are in rg_sign_input_provenance.json. External literature/priority was not reviewed. Web search was unavailable; general knowledge cutoff December 2025.
