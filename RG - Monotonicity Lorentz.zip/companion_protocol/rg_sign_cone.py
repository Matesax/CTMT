"""Exact-law cone exponential-family sampling and Fisher/sign bridge.
The Lorentz cone is declared in the experiment support; it is NOT derived from probability alone.
"""
from pathlib import Path
import hashlib,json,csv,math
import numpy as np
P=Path(__file__).resolve().parent
rng=np.random.default_rng(20261104)
rows=[]; checks=[]
for d in [2,3,4,6]:
 n=d-1; J=np.diag(np.r_[1.,-np.ones(n)]); alpha=d/2
 for samples in [2000,10000,50000]:
  for trial in range(2):
   spatial=rng.normal(size=n)*.2; time=float(np.sqrt(1+spatial@spatial)*rng.uniform(1.1,2)); z=np.r_[time,spatial]; q=float(z@J@z); lam=np.sqrt(q); v=spatial/time; v2=v@v; gamma=time/lam
   B=np.eye(d); B[0,0]=gamma; B[0,1:]=gamma*v; B[1:,0]=gamma*v; B[1:,1:]+=((gamma-1)/v2)*np.outer(v,v)
   S0=rng.gamma(d,1/lam,samples); dirs=rng.normal(size=(samples,n)); dirs/=np.linalg.norm(dirs,axis=1)[:,None]; radius=rng.uniform(size=samples)**(1/n); rest=np.column_stack([S0,S0[:,None]*radius[:,None]*dirs]); S=rest@B.T
   T=S.copy(); T[:,0]*=-1; Fhat=np.cov(T,rowvar=False,bias=True); F=alpha*(-2*J/q+4*np.outer(J@z,J@z)/q**2)
   error=float(np.linalg.norm(Fhat-F,2)/np.linalg.norm(F,2)); cov=F@z/np.sqrt(z@F@z); g=F-2*np.outer(cov,cov); target=-2*alpha*J/q; er=float(np.linalg.norm(g-target)/np.linalg.norm(target)); inertia=[int(sum(np.linalg.eigvalsh(g)<-1e-10)),int(sum(np.linalg.eigvalsh(g)>1e-10))]
   rows.append(dict(d=d,samples=samples,trial=trial,q=q,Fisher_relative_error=error,reflection_identity_error=er,negative=inertia[0],positive=inertia[1]))
checks.append(dict(name='B01 cone_sampling_covariance_matches_Fisher',passed=max(v['Fisher_relative_error'] for v in rows)<.25,value=max(v['Fisher_relative_error'] for v in rows)))
checks.append(dict(name='B02 radial_reflection_exact_formula',passed=max(v['reflection_identity_error'] for v in rows)<1e-10,value=max(v['reflection_identity_error'] for v in rows)))
checks.append(dict(name='B03 exactly_one_negative_direction',passed=all(v['negative']==1 and v['positive']==v['d']-1 for v in rows),value=len(rows)))
with (P/'rg_sign_cone_runs.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
res={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'seed':20261104,'cases':len(rows),'checks':checks,'passed':sum(v['passed'] for v in checks),'total_checks':len(checks),'scope':'Declared Lorentz-cone exponential family; positive statistical Fisher and a separately defined radial sign operation. No identification of parameter coordinates with spacetime.'}
(P/'rg_sign_cone_results.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n'); print(json.dumps(res,indent=2)); assert res['passed']==len(checks)
