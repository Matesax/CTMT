"""Run every battery in dependency order, then verify the raw ledgers."""
from pathlib import Path
import subprocess,sys
P=Path(__file__).resolve().parent
for name in ['rg_sign_battery.py','rg_sign_exact.py','rg_sign_cone.py','rg_sign_identification.py','rg_sign_robust.py','rg_sign_verify.py']:
 args=[sys.executable,str(P/name)]
 if name=='rg_sign_battery.py': args+=['--out',str(P)]
 subprocess.run(args,cwd=P,check=True)
