"""Synthetic probability-to-curvature identification with held-out tidal readouts.
Model: ds^2=-exp(2*a*x+b*x^2)dt^2+dx^2, N(0)=1, c=1.
Clock exposure and rod x are externally calibrated; no GR field equation assumed.
"""
from pathlib import Path
import hashlib,json,csv
import numpy as np
P=Path(__file__).resolve().parent
SEED=20261103
rng=np.random.default_rng(SEED)
rows=[]; designs=[]; checks=[]
def chk(name,ok,value): checks.append(dict(name=name,passed=bool(ok),value=value))
for btrue in [-.12,0,.12]:
 for L in [.1,.3,1.,2.]:
  for exposure in [1000,10000,100000]:
   x=L*np.array([-1,-.5,0,.5,1.]); X=np.column_stack([x,x*x/2]); truth=np.array([.15,btrue]); mu=exposure*np.exp(X@truth)
   F=X.T@(mu[:,None]*X); cov=np.linalg.inv(F); grad=np.array([-4*truth[0],-2.]); seR=float(np.sqrt(grad@cov@grad)); admitted=bool(np.linalg.cond(F)<1e6 and seR<.1)
   Rtrue=-2*(btrue+.15**2); Etrue=-Rtrue/2; coverage=[]; zhold=[]; signwrong=0; signcert=0; converged=[]
   for trial in range(100):
    y=rng.poisson(mu); theta=np.zeros(2); success=False
    for iteration in range(40):
     mm=exposure*np.exp(X@theta); gradn=X.T@(mm-y); H=X.T@(mm[:,None]*X); step=np.linalg.solve(H,gradn)
     # Newton with backtracking to keep the convex objective decreasing.
     obj=lambda z:float(np.sum(exposure*np.exp(X@z)-y*(X@z)))
     lam=1.; base=obj(theta)
     while lam>1e-8 and obj(theta-lam*step)>base: lam/=2
     theta-=lam*step
     if np.linalg.norm(lam*step)<1e-9: success=True; break
    # Final score-based polish avoids cancellation in the objective stopping test.
    for polish in range(3):
     pm=exposure*np.exp(X@theta); pH=X.T@(pm[:,None]*X); theta-=np.linalg.solve(pH,X.T@(pm-y))
    pm=exposure*np.exp(X@theta); pH=X.T@(pm[:,None]*X)
    success=bool(np.max(abs(X.T@(pm-y)))/max(1.,np.sqrt(np.trace(pH)))<1e-9)
    converged.append(success)
    mm=exposure*np.exp(X@theta); covhat=np.linalg.inv(X.T@(mm[:,None]*X)); ah,bh=theta; Rhat=-2*(bh+ah*ah); gr=np.array([-4*ah,-2.]); sr=float(np.sqrt(gr@covhat@gr)); z=(Rhat-Rtrue)/sr
    # Independent signed relative-acceleration readout at x=0, separation xi=.2.
    xi=.2; noise=.02; ytidal=-(btrue+.15**2)*xi+rng.normal(0,noise); pred=-(bh+ah*ah)*xi
    # Propagate parameter uncertainty as well as independent held-out readout noise.
    zt=(ytidal-pred)/np.sqrt(noise**2+(xi*sr/2)**2)
    status='ABSTAIN_DESIGN'
    if admitted:
     coverage.append(abs(z)<=1.959963984540054); zhold.append(float(zt))
     if Rhat-1.959963984540054*sr>0: status='POSITIVE_CURVATURE'
     elif Rhat+1.959963984540054*sr<0: status='NEGATIVE_CURVATURE'
     else: status='SIGN_CORRESPONDENCE'
     if status in ['POSITIVE_CURVATURE','NEGATIVE_CURVATURE']:
      signcert+=1; signwrong+=int(np.sign(Rhat)!=np.sign(Rtrue))
    score_residual=float(np.max(abs(X.T@(mm-y)))/max(1.,np.sqrt(np.trace(X.T@(mm[:,None]*X)))))
    rows.append(dict(counts=json.dumps(y.tolist()),tidal_observed=float(ytidal),tidal_predicted=float(pred),score_residual=score_residual,b_true=btrue,L=L,exposure=exposure,trial=trial,admitted=admitted,converged=success,a_hat=float(ah),b_hat=float(bh),R_true=Rtrue,R_hat=float(Rhat),R_se=sr,z=float(z),heldout_tidal_z=float(zt),status=status))
   designs.append(dict(b_true=btrue,L=L,exposure=exposure,predicted_R_se=seR,admitted=admitted,trials=100,coverage=float(np.mean(coverage)) if coverage else None,heldout_coverage=float(np.mean(np.abs(zhold)<=1.959963984540054)) if zhold else None,sign_certificates=signcert,wrong_sign_certificates=signwrong,converged=sum(converged)))
ad=[v for v in rows if v['admitted']]; cov=float(np.mean([abs(v['z'])<=1.959963984540054 for v in ad])); hold=float(np.mean([abs(v['heldout_tidal_z'])<=1.959963984540054 for v in ad]))
chk('P01 convex_Poisson_MLE_convergence',all(v['converged'] and v['score_residual']<1e-6 for v in rows),{'converged':sum(v['converged'] for v in rows),'max_normalized_score_residual':max(v['score_residual'] for v in rows)})
chk('P02 nonvacuous_design_admission',0<len(ad)<len(rows),{'admitted_trials':len(ad),'abstained_trials':len(rows)-len(ad)})
chk('P03 aggregate_delta_interval_calibration',.90<cov<.99,cov)
chk('P04 heldout_tidal_calibration',.90<hold<.99,hold)
# Exact noiseless reconstruction at all signed ladder scales.
err=[]
for L in [.1,.3,1.,2.]:
 x=L*np.array([-1,-.5,0,.5,1.]); X=np.column_stack([x,x*x/2]); theta=np.array([.15,.12]); fit=np.linalg.lstsq(X,X@theta,rcond=None)[0]; err.append(float(np.max(abs(fit-theta))))
chk('P05 noiseless_parameter_identification',max(err)<1e-12,max(err))
with (P/'rg_sign_identification_runs.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
res={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'seed':SEED,'trials':len(rows),'designs':designs,'admitted_designs':sum(v['admitted'] for v in designs),'abstained_designs':sum(not v['admitted'] for v in designs),'aggregate_coverage':cov,'heldout_coverage':hold,'sign_certificates':sum(v['sign_certificates'] for v in designs),'wrong_sign_certificates':sum(v['wrong_sign_certificates'] for v in designs),'checks':checks,'passed':sum(v['passed'] for v in checks),'total_checks':len(checks),'scope':'Synthetic known-exposure Poisson clocks, declared two-parameter static metric and independent Gaussian tidal readouts; no empirical validation.'}
(P/'rg_sign_identification_results.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n'); print(json.dumps(res,indent=2)); assert res['passed']==len(checks)
