"""Truth-independent uniform design gate over |a|<=.3, |b|<=.2.
Consumes the fixed clock-fit CSV; no refitting or selection by observed coverage.
"""
from pathlib import Path
import hashlib,json,csv
import numpy as np
P=Path(__file__).resolve().parent
raw=list(csv.DictReader((P/'rg_sign_identification_runs.csv').open()))
A=.3; B=.2; designs=[]; admitted=[]; boundok=True
for L in [.1,.3,1.,2.]:
 for exposure in [1000,10000,100000]:
  x=L*np.array([-1,-.5,0,.5,1.]); X=np.column_stack([x,x*x/2]); G=X.T@X; inv=np.linalg.inv(G); h=A*L+B*L*L/2
  boundvar=max(np.array([-4*a,-2.])@inv@np.array([-4*a,-2.]) for a in [-A,A])*np.exp(h)/exposure
  sebound=float(np.sqrt(boundvar)); condbound=float(np.exp(2*h)*np.linalg.cond(G)); admit=sebound<.1 and condbound<1e6
  for a in np.linspace(-A,A,9):
   for b in np.linspace(-B,B,9):
    F=X.T@((exposure*np.exp(X@np.array([a,b])))[:,None]*X); gr=np.array([-4*a,-2.]); var=gr@np.linalg.inv(F)@gr
    boundok=boundok and var<=boundvar*(1+1e-12) and np.linalg.cond(F)<=condbound*(1+1e-12)
  designs.append(dict(L=L,exposure=exposure,curvature_se_bound=sebound,Fisher_condition_bound=condbound,admitted=admit))
  if admit: admitted += [r for r in raw if float(r['L'])==L and int(r['exposure'])==exposure]
zcrit=1.959963984540054
coverage=float(np.mean([abs(float(r['z']))<=zcrit for r in admitted])); hold=float(np.mean([abs(float(r['heldout_tidal_z']))<=zcrit for r in admitted]))
sign=[r for r in admitted if abs(float(r['R_hat']))>zcrit*float(r['R_se'])]; wrong=sum(np.sign(float(r['R_hat']))!=np.sign(float(r['R_true'])) for r in sign)
checks=[dict(name='R01 uniform_design_bounds_grid_sanity',passed=bool(boundok),value='81 grid points per design; analytic uniform proof in paper'),dict(name='R02 nonoracle_nonvacuous_admission',passed=0<len(admitted)<len(raw),value=len(admitted)),dict(name='R03 robust_admission_calibration',passed=.90<coverage<.99 and .90<hold<.99,value={'curvature_coverage':coverage,'heldout_coverage':hold})]
with (P/'rg_sign_robust_designs.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(designs[0])); w.writeheader(); w.writerows(designs)
res={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'parameter_box':{'abs_a_max':A,'abs_b_max':B},'designs':designs,'unique_designs':len(designs),'admitted_unique_designs':sum(d['admitted'] for d in designs),'admitted_truth_designs':3*sum(d['admitted'] for d in designs),'admitted_trials':len(admitted),'coverage':coverage,'heldout_coverage':hold,'sign_intervals':len(sign),'wrong_sign_intervals':int(wrong),'checks':checks,'passed':sum(v['passed'] for v in checks),'total_checks':len(checks),'scope':'Uniform deterministic design sensitivity gate on a declared parameter box; Wald task intervals remain approximate, not finite-sample certificates.'}
(P/'rg_sign_robust_results.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n'); print(json.dumps(res,indent=2)); assert res['passed']==len(checks)
