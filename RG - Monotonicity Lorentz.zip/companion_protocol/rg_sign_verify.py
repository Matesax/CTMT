"""Independent ledger, source-hash and raw-record consistency check."""
from pathlib import Path
import json,csv,hashlib,collections,math
import numpy as np
P=Path(__file__).resolve().parent
pairs=[('rg_sign_battery.py','rg_sign_results.json'),('rg_sign_exact.py','rg_sign_exact_results.json'),('rg_sign_cone.py','rg_sign_cone_results.json'),('rg_sign_identification.py','rg_sign_identification_results.json'),('rg_sign_robust.py','rg_sign_robust_results.json')]
checks=[]
def ck(name,ok): checks.append({'name':name,'passed':bool(ok)}); assert ok,name
results={}
for source,result in pairs:
 d=json.loads((P/result).read_text()); results[result]=d
 ck(source+' hash',hashlib.sha256((P/source).read_bytes()).hexdigest()==d['source_sha256'])
 ck(result+' checks',d['passed']==d['total_checks']==len(d['checks']) and all(v['passed'] for v in d['checks']))
main=results['rg_sign_results.json']; rows=list(csv.DictReader((P/'rg_sign_runs.csv').open()))
ck('raw mathematical row count',len(rows)==main['rows']==1450)
counts=dict(collections.Counter(v['label'] for v in rows if v['family']=='Q01_classification'))
ck('raw inertia counts',counts==main['summary']['classification_counts'])
ck('raw reconstruction ranks',all(int(v['full_rank'])==10 and int(v['cone_rank'])==9 for v in rows if v['family']=='I01_symbol_identification'))
raw=list(csv.DictReader((P/'rg_sign_identification_runs.csv').open())); ident=results['rg_sign_identification_results.json']; ad=[r for r in raw if r['admitted']=='True']; zcrit=1.959963984540054
ck('raw clock trials',len(raw)==ident['trials']==3600 and len(ad)==2100)
ck('raw clock coverage',abs(sum(abs(float(r['z']))<=zcrit for r in ad)/len(ad)-ident['aggregate_coverage'])<1e-15)
ck('raw heldout coverage',abs(sum(abs(float(r['heldout_tidal_z']))<=zcrit for r in ad)/len(ad)-ident['heldout_coverage'])<1e-15)
sign=[r for r in ad if abs(float(r['R_hat']))>zcrit*float(r['R_se'])]; wrong=sum(float(r['R_hat'])*float(r['R_true'])<0 for r in sign)
ck('wrong sign retained',len(sign)==ident['sign_certificates']==1668 and wrong==ident['wrong_sign_certificates']==1)
rob=results['rg_sign_robust_results.json']; settings={(float(v['L']),int(v['exposure'])) for v in rob['designs'] if v['admitted']}; rad=[r for r in raw if (float(r['L']),int(r['exposure'])) in settings]
ck('robust admission count',len(rad)==rob['admitted_trials']==1500)
ck('robust curvature coverage',abs(sum(abs(float(r['z']))<=zcrit for r in rad)/len(rad)-rob['coverage'])<1e-15)
ck('robust heldout coverage',abs(sum(abs(float(r['heldout_tidal_z']))<=zcrit for r in rad)/len(rad)-rob['heldout_coverage'])<1e-15)
rsign=[r for r in rad if abs(float(r['R_hat']))>zcrit*float(r['R_se'])]
ck('robust sign records',len(rsign)==rob['sign_intervals'] and sum(float(r['R_hat'])*float(r['R_true'])<0 for r in rsign)==rob['wrong_sign_intervals'])
# Recompute fitted score, Fisher uncertainty and held-out residual from raw observations.
residuals=[]
for r in raw:
 x=float(r['L'])*np.array([-1.,-.5,0,.5,1.]); X=np.column_stack([x,x*x/2]); theta=np.array([float(r['a_hat']),float(r['b_hat'])]); mu=int(r['exposure'])*np.exp(X@theta); counts=np.array(json.loads(r['counts'])); FI=X.T@(mu[:,None]*X); gr=np.array([-4*theta[0],-2.]); sr=float(np.sqrt(gr@np.linalg.inv(FI)@gr)); score=float(np.max(abs(X.T@(mu-counts)))/max(1.,np.sqrt(np.trace(FI)))); pred=-(theta[1]+theta[0]**2)*.2; zt=(float(r['tidal_observed'])-pred)/np.sqrt(.02**2+(.2*sr/2)**2)
 residuals.append(max(abs(sr-float(r['R_se'])),abs(zt-float(r['heldout_tidal_z'])),abs(score-float(r['score_residual']))))
ck('raw observations reproduce score Fisher and tidal residual',max(residuals)<1e-10)
ck('all numeric records finite',all(math.isfinite(float(r[k])) for r in raw for k in ['a_hat','b_hat','R_hat','R_se','z','heldout_tidal_z']))
ck('all assertion groups',sum(d['passed'] for d in results.values())==50)
res={'checks':checks,'passed':sum(v['passed'] for v in checks),'total_checks':len(checks),'battery_assertion_groups':50,'raw_rows':len(rows)+len(raw)+24,'scope':'Independent raw-record and source-hash consistency; not an independent proof of the physical model.'}
(P/'rg_sign_verification.json').write_text(json.dumps(res,indent=2)+'\n'); print(json.dumps(res,indent=2))
