import sympy as sp
def curvature(g, X):
    n=len(X); gi=sp.simplify(g.inv())
    Gam=[[[sp.simplify(sum(gi[a,dd]*(sp.diff(g[dd,b],X[c])+sp.diff(g[dd,c],X[b])-sp.diff(g[b,c],X[dd])) for dd in range(n))/2) for c in range(n)] for b in range(n)] for a in range(n)]
    def Riem(a,b,c,dd):  # R^a_{bcd}
        return sp.diff(Gam[a][dd][b],X[c])-sp.diff(Gam[a][c][b],X[dd])+sum(Gam[a][c][e]*Gam[e][dd][b]-Gam[a][dd][e]*Gam[e][c][b] for e in range(n))
    Rm=[[[[sp.simplify(Riem(a,b,c,dd)) for dd in range(n)] for c in range(n)] for b in range(n)] for a in range(n)]
    Ric=sp.Matrix(n,n,lambda b,dd: sp.simplify(sum(Rm[a][b][a][dd] for a in range(n))))
    Rs=sp.simplify(sum(gi[b,dd]*Ric[b,dd] for b in range(n) for dd in range(n)))
    return gi,Gam,Rm,Ric,Rs
def invariants(g,X):
    n=len(X); gi,Gam,Rm,Ric,Rs=curvature(g,X)
    # Riemann all-lower R_{abcd}
    Rl=[[[[sum(g[a,e]*Rm[e][b][c][dd] for e in range(n)) for dd in range(n)] for c in range(n)] for b in range(n)] for a in range(n)]
    Ru=[[[[sum(gi[b,b2]*gi[c,c2]*gi[dd,d2]*Rm[a][b2][c2][d2] for b2 in range(n) for c2 in range(n) for d2 in range(n)) for dd in range(n)] for c in range(n)] for b in range(n)] for a in range(n)]
    Riem2=sp.simplify(sum(Rl[a][b][c][dd]*Ru[a][b][c][dd] for a in range(n) for b in range(n) for c in range(n) for dd in range(n)))
    Ricu=gi*Ric*gi
    Ric2=sp.simplify(sum(Ric[a,b]*Ricu[a,b] for a in range(n) for b in range(n)))
    return Rs,Ric2,Riem2,Ric,gi,Gam
