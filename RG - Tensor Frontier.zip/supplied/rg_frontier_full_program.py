"""RG raw-frontier and speed-limit robustness battery.

Synthetic, unit-free falsification programme. It tests whether the estimator
C = 2/(dM/dN) recovers one finite frontier across distance, orientation,
carrier, refinement, and independently transformed raw ruler/clock standards.
It is not empirical evidence and does not prove the RG premises.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

SEED=731992
TRUE_C=3.75
OUT=Path(__file__).resolve().parent
rng=np.random.default_rng(SEED)
N=np.arange(20,501,20,dtype=float)
angles=np.deg2rad([0,45,90,135])
carriers={'field-A-low':-1.0,'field-A-high':1.0,'field-B':0.35}
refinements=[1,2,4,8]
scenarios={
 'locked_frontier':(0,0,0,0),
 'anisotropic_frontier':(.018,0,0,0),
 'dispersive_frontier':(0,.022,0,0),
 'scale_drift_frontier':(0,0,.030,0),
 'precursor_leakage':(0,0,0,.012),
}
rows=[]
for name,(anis,disp,drift,precursor) in scenarios.items():
 for refine in refinements:
  for theta in angles:
   for carrier,k in carriers.items():
    c=TRUE_C*(1+anis*np.cos(2*theta)+disp*k)
    tof=2*N/c*(1+drift*(N/N.max())**1.25)
    if precursor: tof*=1-precursor*(1-np.exp(-N/90))
    latency=11+.7*k+.3*np.cos(theta)
    M=latency+tof+rng.normal(0,.42/np.sqrt(refine),N.size)
    rows += [(name,refine,theta,carrier,n,m) for n,m in zip(N,M)]
raw=pd.DataFrame(rows,columns=['scenario','refinement','theta_rad','carrier','N','M'])

fit=[]
for key,g in raw.groupby(['scenario','refinement','theta_rad','carrier']):
 x,y=g.N.to_numpy(),g.M.to_numpy()
 slope,intercept=np.polyfit(x,y,1)
 q2,q1,_=np.polyfit(x,y,2)
 pred=intercept+slope*x
 fit.append((*key,2/slope,intercept,1-((y-pred)**2).sum()/((y-y.mean())**2).sum(),abs(q2*x.max()/q1)))
fits=pd.DataFrame(fit,columns=['scenario','refinement','theta_rad','carrier','C_hat','latency_hat','R2','curvature_ratio'])

out=[]
for name,g in fits.groupby('scenario'):
 f=g[g.refinement==8]
 mean=f.C_hat.mean(); carrier=f.groupby('carrier').C_hat.mean()
 anis=max((z.C_hat.max()-z.C_hat.min())/z.C_hat.mean() for _,z in f.groupby('carrier'))
 vals={
  'finite_positive':np.isfinite(mean) and mean>0,
  'absolute_recovery_lt_0.5pct':abs(mean-TRUE_C)/TRUE_C<.005,
  'cross_cell_spread_lt_0.75pct':(f.C_hat.max()-f.C_hat.min())/mean<.0075,
  'anisotropy_lt_0.5pct':anis<.005,
  'dispersion_lt_0.5pct':(carrier.max()-carrier.min())/carrier.mean()<.005,
  'linearity_curvature_lt_0.3pct':f.curvature_ratio.max()<.003,
  'refinement_convergence_lt_0.15pct':abs(g.groupby('refinement').C_hat.mean().loc[8]-g.groupby('refinement').C_hat.mean().loc[4])/mean<.0015,
 }
 out.append({'scenario':name,'C_mean':mean,'relative_bias':abs(mean-TRUE_C)/TRUE_C,
             'anisotropy':anis,'dispersion':(carrier.max()-carrier.min())/carrier.mean(),
             'max_curvature_ratio':f.curvature_ratio.max(),'passed_gates':sum(vals.values()),
             'total_gates':len(vals),'locked':all(vals.values()),**vals})
summary=pd.DataFrame(out).sort_values('scenario')

# Commuting raw-standard test: ell_B=ell_A/alpha, tau_B=tau_A/beta.
base=fits.query("scenario=='locked_frontier' and refinement==8").C_hat.to_numpy()
std=[]
for alpha,beta in [(1.7,.8),(.63,1.25),(2.4,3.1),(1,.37)]:
 predicted=(alpha/beta)*base
 measured=predicted+rng.normal(0,.0006*predicted.mean(),predicted.size)
 err=np.max(np.abs(measured-predicted)/predicted)
 std.append((alpha,beta,predicted.mean(),measured.mean(),err,err<.0025))
standards=pd.DataFrame(std,columns=['alpha','beta','predicted_C_B','measured_C_B','max_closure_error','pass'])

raw.to_csv(OUT/'rg_frontier_raw_measurements.csv',index=False)
fits.to_csv(OUT/'rg_frontier_cell_fits.csv',index=False)
summary.to_csv(OUT/'rg_frontier_gate_summary.csv',index=False)
standards.to_csv(OUT/'rg_frontier_standard_covariance.csv',index=False)
(OUT/'rg_frontier_results.json').write_text(json.dumps({'seed':SEED,'true_raw_C':TRUE_C,'summary':summary.to_dict('records'),'standards':standards.to_dict('records')},indent=2,default=bool))

fig,ax=plt.subplots(1,2,figsize=(11,4.5))
for name in ['locked_frontier','scale_drift_frontier']:
 g=raw.query("scenario==@name and refinement==8 and theta_rad==0 and carrier=='field-A-low'")
 ax[0].plot(g.N,g.M,'o-',label=name)
ax[0].set(xlabel='N spatial periods',ylabel='M clock periods',title='Raw round-trip law'); ax[0].legend()
for name in ['locked_frontier','anisotropic_frontier']:
 g=fits.query("scenario==@name and refinement==8 and carrier=='field-B'").sort_values('theta_rad')
 ax[1].plot(np.rad2deg(g.theta_rad),g.C_hat,'o-',label=name)
ax[1].axhline(TRUE_C,color='k',lw=1); ax[1].set(xlabel='orientation degrees',ylabel='estimated raw C',title='Orientation gate'); ax[1].legend()
fig.tight_layout(); fig.savefig(OUT/'rg_frontier_program_output.png',dpi=180)
print(summary[['scenario','C_mean','passed_gates','total_gates','locked']].to_string(index=False))
print('\nMaximum raw-standard closure error:',standards.max_closure_error.max())
