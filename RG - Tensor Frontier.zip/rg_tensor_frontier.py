#!/usr/bin/env python3
"""RG - Tensor Frontier: hostile battery.

Groups (every group carries a canary, i.e. a false variant that must fail):
  FA predictive metric = generating function of the forecast-error profile; critical discount = exponent
  FB the frontier is an upper bound over all forecasters of a record (Gaussian case); oracle canary
  FC hole cap: saturation of the horizon; closure certificate in d steps; fibre lemma
  FD second-order frontier law (exact binomial cocycles); the logistic map at r = 4 is a coboundary
  FE refinement: horizon proportional to the spacing unless the form is Lorentzian; isometries of a form
  FF interacting Lorentzian lattice in three dimensions: tangent growth uniform under refinement
  TA the precision slope is invariant under the degree and the coordinates of the record
  TB tidal tensor (symbolic): Schwarzschild, de Sitter, Friedmann; traces; Newtonian tide
  TC forecast Fisher volume: second derivative = -2 Ric(u,u); Liouville canary
  TD the volume law for all observers is the response law; source from observers; rank table
  TE light ring: logarithmic deflection, half-orbit factor exp(-pi); Leaver ladder; Kerr; ringdown numbers
  SA sources are moments: transfer inequality; concentration defect; forecast energy deficit

Deterministic. Seed 20261113. Writes rg_tensor_frontier_results.json. Run:  python3 -I rg_tensor_frontier.py
"""
import hashlib, json, math, os, sys
import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import expm
from scipy.optimize import fsolve, brentq
from scipy.stats import binom, norm

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
SEED = 20261113
R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.12g}')


# ============================================================================================ F: the frontier as an RG object
def FA():
    rng = np.random.default_rng(SEED + 1)
    # (a) two-sided bound for arbitrary profiles in [0, 1]
    worst_lo, worst_hi = np.inf, -np.inf
    for _ in range(2000):
        n = int(rng.integers(3, 40)); e = rng.uniform(0, 1, n) ** rng.uniform(0.3, 6); beta = rng.uniform(0.05, 0.95)
        eps = rng.uniform(0.01, 0.9); d = (1 - beta) * np.sum(beta ** np.arange(n) * e)
        above = np.nonzero(e > eps)[0]; bn = beta ** above[0] if len(above) else 0.0
        worst_lo = min(worst_lo, d - (1 - beta) * eps * bn); worst_hi = max(worst_hi, d - eps - bn)
    # (b) doubling map, exact profile for delta = 2^-k / 3: e_n = min(2^(n-k), 1) / 3
    def dbeta(beta, k, nmax=6000):
        n = np.arange(nmax); e = np.minimum(2.0 ** np.minimum(n - k, 0), 1.0) / 3
        return (1 - beta) * np.sum(beta ** n * e)
    expo = {}
    for beta in (0.3, 0.4, 0.6, 0.75, 0.9):
        expo[beta] = (math.log(dbeta(beta, 80) / dbeta(beta, 81)) / math.log(2), min(1.0, math.log(1 / beta) / math.log(2)))
    err = max(abs(a - b) for a, b in expo.values())
    crit = math.log(1 / 0.5)                                    # critical discount beta_c = 1/2  <->  exponent ln 2
    # (c) the family {d_beta} determines the profile (finite profile, exact inversion)
    e = rng.uniform(0, 1, 6); betas = np.linspace(0.1, 0.6, 6)
    V = np.array([[(1 - b) * b ** n for n in range(6)] for b in betas]); rec = np.linalg.solve(V, V @ e)
    inv = float(np.max(np.abs(rec - e)))
    # canary: 'the predictive metric is Lipschitz-equivalent to the present metric for every discount'
    canary = abs(expo[0.9][0] - 1.0)
    must(worst_lo > -1e-12 and worst_hi < 1e-12 and err < 1e-6 and inv < 1e-8 and canary > 0.8, 'FA')
    R['FA'] = dict(claim='The predictive metric d_beta = (1-beta) sum beta^n e_n is the generating function of the forecast-error '
                         'profile e_n. For the horizon n_eps (first n with e_n > eps): (1-beta) eps beta^n_eps <= d_beta <= eps + '
                         'beta^n_eps, for every profile. The family over beta determines the profile. For exponential separation '
                         'd_beta scales like delta^alpha with alpha = min(1, ln(1/beta)/lambda): the exponent is the critical '
                         'discount. Canary: Lipschitz equivalence at beta = 0.9 for the doubling map is false (alpha = 0.152).',
                   status='PROVED', bound_slack_lower=fl(worst_lo), bound_slack_upper=fl(worst_hi),
                   holder_exponent={str(b): [fl(v[0]), fl(v[1])] for b, v in expo.items()}, critical_exponent=fl(crit),
                   inversion_err=fl(inv), canary_gap=fl(canary))


def FB():
    rng = np.random.default_rng(SEED + 2)
    lam, tau, s0, eps, q = 0.5, 1.0, 1e-4, 1e-2, 0.9
    post = 1 / math.sqrt(1 / tau ** 2 + 1 / s0 ** 2)
    cov = lambda sd: 2 * norm.cdf(eps / sd) - 1
    n = 9; g = math.exp(lam * n); bound = cov(g * post)
    # linear forecasters c*y: error g((c-1)x + c s0 xi), exact coverage
    cs = np.linspace(0.0, 2.0, 2001); lin = np.array([cov(g * math.sqrt((c - 1) ** 2 * tau ** 2 + c ** 2 * s0 ** 2)) for c in cs])
    best_c = float(cs[np.argmax(lin)])
    # nonlinear and biased forecasters, seeded Monte Carlo
    M = 400000; x = rng.normal(0, tau, M); y = x + s0 * rng.normal(size=M); T = g * x
    fc = {'posterior_mean': g * y * tau ** 2 / (tau ** 2 + s0 ** 2), 'rounded': g * np.round(y / (3 * s0)) * 3 * s0,
          'clipped': g * np.clip(y, -1.5, 1.5), 'biased': g * (y + 0.5 * s0), 'cubic_shrink': g * (y - 0.02 * y ** 3 * s0)}
    mc = {k: float(np.mean(np.abs(T - v) <= eps)) for k, v in fc.items()}
    se = 3 * math.sqrt(0.25 / M)
    # horizons: optimal equals the bound horizon
    zq = norm.ppf((1 + q) / 2); h_bound = (math.log(eps / post) - math.log(zq)) / lam
    h_opt = max(k for k in range(0, 200) if cov(math.exp(lam * k) * post) >= q)
    # canary: a forecaster with a second independent record beats the single-record bound
    y2 = x + s0 * rng.normal(size=M); oracle = float(np.mean(np.abs(T - g * (y + y2) / 2) <= eps))
    ok = float(np.max(lin)) <= bound + 1e-12 and abs(best_c - tau ** 2 / (tau ** 2 + s0 ** 2)) < 2e-3 and all(v <= bound + se for v in mc.values()) \
        and abs(mc['posterior_mean'] - bound) < se and h_opt == math.floor(h_bound) and oracle > bound + 10 * se
    must(ok, 'FB')
    R['FB'] = dict(claim='Upper boundary. For a Gaussian record of the initial state and a forecast task T_n = g_n x, no forecaster '
                         'built on that record has coverage above 2 Phi(eps / (g_n s_post)) - 1; the posterior-mean forecast attains '
                         'it. Hence no method has a horizon beyond [ln(eps/s_post) - ln z]/lambda. Linear forecasters are checked '
                         'exactly, five nonlinear or biased ones by seeded Monte Carlo. Canary: a forecaster holding a second '
                         'independent record exceeds the bound; the bound is relative to the record.',
                   status='PROVED (Gaussian case; Anderson) + Monte Carlo check', bound=fl(bound), best_linear=fl(np.max(lin)),
                   best_linear_gain=fl(best_c), monte_carlo={k: fl(v) for k, v in mc.items()}, mc_three_sigma=fl(se),
                   horizon_bound=fl(h_bound), horizon_optimal=h_opt, oracle_coverage=fl(oracle))


def FC():
    rng = np.random.default_rng(SEED + 3)
    d, lam, eta, eps = 6, 0.4, 1e-3, 1e-1
    zq = norm.ppf(0.95)
    def horizon(A, Sig, C, nmax=400):
        P = np.eye(d); last = -1
        for n in range(nmax):
            s = math.sqrt(float(C @ P @ Sig @ P.T @ C))
            if s * zq <= eps:
                last = n
            else:
                break
            P = A @ P
        return last
    # leaking hole: generic unstable system; initial record of rank 4
    Q_, _ = np.linalg.qr(rng.normal(size=(d, d)))
    A = Q_ @ np.diag([math.exp(lam), 0.9, 0.8, -0.7, 0.6, 0.5]) @ Q_.T
    B = rng.normal(size=(4, d)); C = rng.normal(size=d); C /= np.linalg.norm(C)
    _, _, Vt = np.linalg.svd(B); Nb = Vt[4:].T
    hs = []
    for s0 in (1e-2, 1e-4, 1e-6, 1e-8, 1e-10):
        Sig = np.linalg.inv(B.T @ B / s0 ** 2 + np.eye(d) / eta ** 2); hs.append(horizon(A, Sig, C))
    cap = horizon(A, eta ** 2 * Nb @ Nb.T, C)
    # closed hole: the hole is A-invariant and inside ker C  ->  no cap
    A2 = np.zeros((d, d)); A2[:4, :4] = np.diag([math.exp(lam), 0.9, 0.8, 0.6]); A2[4:, 4:] = np.array([[1.3, 0.2], [0.0, 1.2]])
    A2[:4, 4:] = 0.0; B2 = np.hstack([rng.normal(size=(4, 4)), np.zeros((4, 2))]); C2 = np.concatenate([rng.normal(size=4), [0, 0]])
    C2 /= np.linalg.norm(C2); N2 = np.eye(d)[:, 4:]
    kry = max(abs(float(C2 @ np.linalg.matrix_power(A2, k) @ N2[:, j])) for k in range(60) for j in range(2))
    h2 = []
    for s0 in (1e-2, 1e-4, 1e-6, 1e-8, 1e-10):
        Sig = np.linalg.inv(B2.T @ B2 / s0 ** 2 + np.eye(d) / eta ** 2); h2.append(horizon(A2, Sig, C2))
    slope = (h2[-1] - h2[1]) / (math.log(1e-4) - math.log(1e-10))
    # canary: d steps are necessary. Nilpotent chain: the hole reaches the record only at step d - 1
    A3 = np.zeros((d, d))
    for i in range(d - 1):
        A3[i + 1, i] = 1.0
    leak = [float(np.eye(d)[d - 1] @ np.linalg.matrix_power(A3, k) @ np.eye(d)[0]) for k in range(d)]
    # fibre lemma: two states with equal record, predictions 2*gap apart: every forecast errs by at least gap for one of them
    ta, tb = 0.7, -0.9; best = min(max(abs(t - ta), abs(t - tb)) for t in np.linspace(-2, 2, 4001))
    ok = hs[-1] == hs[-2] == cap and hs[0] < hs[-1] and kry < 1e-12 and h2[-1] > h2[-2] > h2[-3] and abs(slope - 1 / lam) < 0.1 \
        and leak[:d - 1] == [0.0] * (d - 1) and leak[d - 1] == 1.0 and abs(best - 0.8) < 1e-3
    must(ok, 'FC')
    R['FC'] = dict(claim='Hole cap. With an unrecorded sector of scale eta in the initial record, the horizon of a later record C '
                         'saturates as the measured precision improves, at the value fixed by eta and the leakage C A^n N alone. If '
                         'C A^k N = 0 for k < d the hole never reaches the record (Cayley-Hamilton), the cap is absent and the '
                         'horizon grows with slope 1/lambda. Fibre lemma: two states with one record and predictions 2g apart force '
                         'an error of at least g. Canary: in a nilpotent chain the hole first reaches the record at step d - 1, so '
                         'fewer than d checks do not certify closure.',
                   status='PROVED (linear algebra) + IDENTIFIED (Kalman)', horizons_leaking=hs, cap=cap, krylov_max=fl(kry),
                   horizons_closed=h2, closed_slope=fl(slope), expected_slope=fl(1 / lam), chain_leak=leak, fibre_min_error=fl(best))


def FD():
    zq = norm.ppf(0.9)
    def table(p, up, dn, Ls):
        lam = p * up + (1 - p) * dn; D = p * (1 - p) * (up - dn) ** 2
        rows = []
        for L in Ls:
            n0 = L / lam; ns = np.arange(max(1, int(n0 - 12 * math.sqrt(D * n0) / lam - 50)), int(n0) + 60)
            kmax = np.floor((L - ns * dn) / (up - dn) + 1e-12)                # S_n = k up + (n-k) dn <= L
            good = ns[binom.cdf(kmax, ns, p) >= 0.9]
            n = int(good.max()); rows.append((L, n, (n - n0) / math.sqrt(L)))
        return lam, D, rows
    lam1, D1, r1 = table(0.75, 1.0, -1.0, [50, 200, 800, 3200, 12800, 51200, 204800])
    pred1 = -zq * math.sqrt(D1 / lam1 ** 3)
    p = 0.25; lam2, D2, r2 = table(p, math.log(1 / p), math.log(1 / (1 - p)), [50, 200, 800, 3200, 12800, 51200])
    pred2 = -zq * math.sqrt(D2 / lam2 ** 3)
    # logistic map at r = 4: ln |(f^n)'| - n ln 2 = ln|sin a_n| - ln|sin a_0| is a coboundary; its variance does not grow
    theta = (np.arange(400001) + 0.5) / 400001; var = {}
    for n in (5, 10, 20, 30):
        a = 2 * np.pi * theta; s = np.zeros_like(theta)
        for _ in range(n):
            s += np.log(np.abs(4 * np.cos(a))); a = (2 * a) % (2 * np.pi)
        var[n] = float(np.var(s - n * math.log(2)))
    tent_var = {n: D2 * n for n in (5, 10, 20, 30)}
    # canary: 'ergodicity gives a constant correction' -> the correction grows
    grow = abs(r1[-1][1] - r1[-1][0] / lam1) / abs(r1[0][1] - r1[0][0] / lam1)
    ok = abs(r1[-1][2] - pred1) < 0.02 * abs(pred1) and abs(r2[-1][2] - pred2) < 0.03 * abs(pred2) and abs(r1[0][2] - pred1) > abs(r1[-1][2] - pred1) \
        and max(var.values()) < 1.8 and abs(var[30] - var[20]) < 0.05 and abs(var[20] - math.pi ** 2 / 6) < 0.1 and grow > 20
    must(ok, 'FD')
    R['FD'] = dict(claim='Second-order frontier law. For a multiplicative cocycle with exponent lambda and variance rate D, the '
                         'endpoint horizon at coverage q is L/lambda - z_q sqrt(D L / lambda^3) + O(1), L = ln(eps/sigma_0). Exact '
                         'binomial computation for two cocycles reaches the predicted coefficient within 2 and 3 per cent. The '
                         'logistic map at r = 4 is a coboundary: the variance of its finite-time exponent stays at pi^2/6 and D = 0, '
                         'so that map cannot show the square-root term. Canary: a constant correction is false (it grows by more '
                         'than twenty-fold over the range).',
                   status='PROVED (central limit theorem, independent increments) + exact computation',
                   cocycle_pm1=dict(exponent=fl(lam1), variance_rate=fl(D1), predicted=fl(pred1), rows=[[a, b, fl(c)] for a, b, c in r1]),
                   cocycle_skew_tent=dict(exponent=fl(lam2), variance_rate=fl(D2), predicted=fl(pred2), rows=[[a, b, fl(c)] for a, b, c in r2]),
                   logistic_variance={str(k): fl(v) for k, v in var.items()}, coboundary_limit=fl(math.pi ** 2 / 6),
                   skew_tent_variance={str(k): fl(v) for k, v in tent_var.items()}, correction_growth=fl(grow))


def FE():
    rng = np.random.default_rng(SEED + 4)
    L10 = math.log(1e-2 / 1e-10)
    def max_growth(signs, N):
        """Largest Re(lambda) over lattice modes and over the choice of evolution direction, spacing a = 1/N."""
        k = 2 * N * np.sin(np.pi * np.arange(N) / N)               # lattice symbol sqrt(4 N^2 sin^2)
        best = np.inf
        for e, se in enumerate(signs):
            others = [s for i, s in enumerate(signs) if i != e]
            tot = np.zeros(1)
            for s in others:
                tot = (tot[:, None] + se * s * k[None, :] ** 2).ravel(); tot = np.unique(np.round(tot, 9))
            best = min(best, math.sqrt(max(0.0, float(tot.max()))))
        return best
    table = {}
    for p_, q_ in ((1, 1), (1, 2), (1, 3), (3, 1), (2, 2), (0, 3), (0, 4), (2, 3)):
        signs = [-1] * p_ + [1] * q_; g = [max_growth(signs, N) for N in (8, 16, 32)]
        m = max(0, min(p_, q_) - 1) if min(p_, q_) > 0 else p_ + q_ - 1
        table[f'{p_},{q_}'] = dict(growth=[fl(v) for v in g], horizon=[fl(L10 / v) if v > 0 else None for v in g], predicted_factor=fl(2 * math.sqrt(m)))
    lor = all(max(table[s]['growth']) == 0 for s in ('1,1', '1,2', '1,3', '3,1'))
    scal = all(abs(table[s]['growth'][2] / 32 - table[s]['predicted_factor']) < 1e-6 and abs(table[s]['horizon'][0] / table[s]['horizon'][2] - 4) < 1e-6
               for s in ('2,2', '0,3', '0,4', '2,3'))
    # isometries of a conserved form: definite -> no growth; indefinite -> growing directions are null and paired
    n = 6; G = rng.normal(size=(n, n)); Hd = G @ G.T + n * np.eye(n); Kk = rng.normal(size=(n, n)); Kk = Kk - Kk.T
    Ad = expm(np.linalg.solve(Hd, Kk)); v = rng.normal(size=n); w = v.copy(); drift = 0.0
    for _ in range(200):
        w = Ad @ w; drift = max(drift, abs(w @ Hd @ w / (v @ Hd @ v) - 1))
    Hi = np.diag([1.0, 1, 1, 1, -1, -1]); Kb = Kk.copy(); Kb[:4, :4] *= 0.2; Kb[4:, 4:] *= 0.2      # boosts dominate rotations
    Ai = expm(np.linalg.solve(Hi, Kb)); ev, U = np.linalg.eig(Ai)
    iso = float(np.max(np.abs(Ai.T @ Hi @ Ai - Hi)))
    big = [i for i in range(n) if abs(abs(ev[i]) - 1) > 1e-6]
    nullness = max(abs(U[:, i].conj() @ Hi @ U[:, i]) / (np.linalg.norm(U[:, i]) ** 2) for i in big) if big else 1.0
    pairing = max(min(abs(ev[i] * ev[j].conj() - 1) for j in big) for i in big) if big else 1.0
    ok = lor and scal and drift < 1e-9 and iso < 1e-9 and len(big) >= 2 and nullness < 1e-9 and pairing < 1e-8 \
        and table['2,2']['growth'][0] > 0                                         # canary: ultrahyperbolic is not predictive
    must(ok, 'FE')
    R['FE'] = dict(claim='Refinement law. For a second-order field with principal form of signature (p, q) on a lattice of spacing a, '
                         'the fastest mode grows at rate (2/a) sqrt(min(p,q) - 1) for the best evolution direction ((2/a) '
                         'sqrt(D - 1) for a definite form), so the forecast horizon is proportional to a; it is independent of a '
                         'exactly for min(p, q) = 1. Isometries of a positive form have no growth; isometries of an indefinite '
                         'form grow only along null directions, with multipliers paired mu, 1/mu. A free Lorentzian field has no '
                         'frontier. Canary: the (2, 2) form grows.',
                   status='PROVED', table=table, definite_norm_drift=fl(drift), indefinite_isometry_err=fl(iso),
                   growing_multipliers=[fl(abs(ev[i])) for i in big], null_defect=fl(nullness), pairing_defect=fl(pairing))


def FF():
    rng = np.random.default_rng(SEED + 8)
    lam_c, kap, m2, Tend, amp = 3.0, 1.0, 1.0, 2.0, 2.0
    def run(N):
        x = np.arange(N) / N; X, Y, Z = np.meshgrid(x, x, x, indexing='ij'); tp = 2 * np.pi
        q0 = amp * (0.4 * np.cos(tp * X) * np.cos(tp * Y) + 0.15 * np.sin(2 * tp * Z) + 0.1 * np.cos(tp * (X + Y + Z)))
        pert = {'smooth': np.cos(tp * X) + 0.5 * np.sin(tp * (Y + Z)), 'alternating': (-1.0) ** np.indices((N, N, N)).sum(axis=0),
                'white': rng.normal(size=(N, N, N))}
        M = N ** 3; names = list(pert)
        lap = lambda f: N * N * (sum(np.roll(f, s, ax) for ax in range(3) for s in (1, -1)) - 6 * f)
        l2 = lambda f: math.sqrt(float(np.mean(f * f)))
        en = lambda zz, ww: math.sqrt(l2(ww) ** 2 + kap * sum(l2(N * (np.roll(zz, -1, ax) - zz)) ** 2 for ax in range(3)) + m2 * l2(zz) ** 2)
        sup = [0.0]
        def rhs(t, Yv):
            F = Yv.reshape(8, N, N, N); q, p = F[0], F[1]; sup[0] = max(sup[0], float(np.max(q * q)))
            out = [p, kap * lap(q) - m2 * q - lam_c * q ** 3]
            for j in range(3):
                out += [F[3 + 2 * j], kap * lap(F[2 + 2 * j]) - (m2 + 3 * lam_c * q * q) * F[2 + 2 * j]]
            return np.concatenate([o.ravel() for o in out])
        Y0 = [q0, np.zeros_like(q0)]
        for nm in names:
            Y0 += [pert[nm], np.zeros_like(q0)]
        sol = solve_ivp(rhs, (0, Tend), np.concatenate([a.ravel() for a in Y0]), method='DOP853', rtol=1e-8, atol=1e-10, t_eval=[Tend])
        F = sol.y[:, -1].reshape(8, N, N, N)
        rates = {nm: math.log(en(F[2 + 2 * j], F[3 + 2 * j]) / en(pert[nm], np.zeros_like(q0))) / Tend for j, nm in enumerate(names)}
        return rates, 3 * lam_c * sup[0] / math.sqrt(m2)
    out = {N: run(N) for N in (8, 12, 16)}
    worst = {N: max(abs(v) for v in out[N][0].values()) for N in out}; bound = max(v[1] for v in out.values())
    # canary: the elliptic sign (q_tt = -kappa Lap q) amplifies the alternating perturbation at rate 2 N sqrt(3 kappa)
    ell = [2 * N * math.sqrt(3 * kap) for N in (8, 12, 16)]
    ok = max(worst.values()) < 0.01 and worst[16] < worst[8] + 0.005 and max(worst.values()) < bound and max(worst.values()) < 0.05 * ell[0] \
        and ell[2] / ell[0] == 2.0
    must(ok, 'FF')
    R['FF'] = dict(claim='Interacting Lorentzian field. For the cubic lattice field in three space dimensions (lambda = 3, amplitude '
                         'of order two) the finite-time growth rate in the energy norm of a smooth, an alternating and a white '
                         'perturbation stays below 0.01 at every spacing and far below the Gronwall rate 3 lambda sup q^2 / m, which '
                         'does not depend on the spacing; refinement creates no instability and the horizon has a lower bound '
                         'independent of the spacing. Canary: with the elliptic sign the alternating perturbation grows at rate '
                         '2 N sqrt(3 kappa), proportional to N.',
                   status='PROVED (energy estimate) + numerical check', rates={str(N): {k: fl(v) for k, v in out[N][0].items()} for N in out},
                   gronwall_bound=fl(bound), elliptic_rates=[fl(v) for v in ell])


# ============================================================================================ T: the tensor
def TA():
    lam, zq, eps = 0.7, norm.ppf(0.95), 1e-3
    Ls = np.linspace(12, 30, 10); sig = np.exp(-Ls); slopes = {}
    for k in (1, 2, 3):                                             # record x^k at zero background
        h = (math.log(eps) - k * np.log(sig * zq)) / (k * lam); slopes[f'power_{k}'] = float(np.polyfit(Ls, h, 1)[0])
    recs = {'sinh_plus_cubic': lambda u: np.sinh(u) + u ** 3, 'tanh': np.tanh, 'exp': np.exp, 'quadratic_bg': lambda u: u * u}
    x0 = 0.8
    for name, psi in recs.items():                                  # smooth record at a nonzero background, solved exactly
        h = [brentq(lambda n: abs(psi(x0 + s * zq * math.exp(lam * n)) - psi(x0)) - eps, -50, (-math.log(s) + 1) / lam) for s in sig]
        slopes[name] = float(np.polyfit(Ls, h, 1)[0])
    worst = max(abs(v - 1 / lam) for v in slopes.values())
    canary = abs(1 / (2 * lam) - slopes['power_2'])                 # 'a quadratic record halves the slope' is false
    must(worst < 1e-4 and canary > 0.5, 'TA')
    R['TA'] = dict(claim='The precision slope of the horizon is 1/lambda for every smooth record of the unstable coordinate: for a '
                         'record vanishing to order k the growth exponent is k lambda and the initial error enters to the power k, '
                         'and the two cancel; a smooth change of record coordinates changes only the intercept. Canary: slope '
                         '1/(2 lambda) for a quadratic record is false.',
                   status='PROVED', slopes={k: fl(v) for k, v in slopes.items()}, expected=fl(1 / lam), canary_gap=fl(canary))


def TB():
    import sympy as sp
    from rg_curv import curvature
    t, r, th, ph, M, H, Lam = sp.symbols('t r theta phi M H Lambda', positive=True)
    def tidal(g, X, tidx=0):
        gi, Gam, Rm, Ric, Rs = curvature(g, X); n = len(X)
        low = lambda a, b, c, d_: sum(g[a, e] * Rm[e][b][c][d_] for e in range(n))
        sp_idx = [i for i in range(n) if i != tidx]
        scale = lambda i, j: g[i, i] if i == j else sp.sqrt(g[i, i]) * sp.sqrt(g[j, j])                 # orthonormal frame of a diagonal metric
        E = sp.Matrix(3, 3, lambda i, j: sp.simplify(low(sp_idx[i], tidx, sp_idx[j], tidx) / (-g[tidx, tidx] * scale(sp_idx[i], sp_idx[j]))))
        ricuu = sp.simplify(Ric[tidx, tidx] / (-g[tidx, tidx]))
        return E, ricuu
    zero = lambda Mx: all(sp.simplify(v) == 0 for v in Mx)
    f = 1 - 2 * M / r
    E_s, ric_s = tidal(sp.diag(-f, 1 / f, r ** 2, r ** 2 * sp.sin(th) ** 2), [t, r, th, ph])
    s_ok = zero(E_s - sp.diag(-2 * M / r ** 3, M / r ** 3, M / r ** 3)) and ric_s == 0
    fd = 1 - 2 * M / r - Lam * r ** 2 / 3
    E_sd, ric_sd = tidal(sp.diag(-fd, 1 / fd, r ** 2, r ** 2 * sp.sin(th) ** 2), [t, r, th, ph])
    sd_ok = sp.simplify(E_sd.trace() + Lam) == 0 and sp.simplify(ric_sd + Lam) == 0
    a = sp.Function('a')(t); x, y, z = sp.symbols('x y z')
    E_f, ric_f = tidal(sp.diag(-1, a ** 2, a ** 2, a ** 2), [t, x, y, z])
    f_ok = zero(E_f + sp.eye(3) * sp.diff(a, t, 2) / a) and sp.simplify(ric_f + 3 * sp.diff(a, t, 2) / a) == 0
    ds_ok = zero(E_f.subs(a, sp.exp(H * t)).doit() + H ** 2 * sp.eye(3))
    # Newtonian tide: Hessian of -M/r along the axis is the same tensor
    X1, X2, X3 = sp.symbols('X1 X2 X3', real=True); Phi = -M / sp.sqrt(X1 ** 2 + X2 ** 2 + X3 ** 2)
    Hn = sp.hessian(Phi, (X1, X2, X3)).subs({X2: 0, X3: 0, X1: r}); n_ok = zero(Hn - sp.diag(-2 * M / r ** 3, M / r ** 3, M / r ** 3))
    # rain observers (free fall from rest at infinity): r'' = -M/r^2 in proper time; proper radial separation is dr
    def rain(r0, v0, T):
        s = solve_ivp(lambda tt, yv: [yv[1], -1 / yv[0] ** 2], (0, T), [r0, v0], rtol=1e-12, atol=1e-14); return s.y[0, -1]
    r0, xi, T = 10.0, 1e-4, 0.3; v = lambda rr: -math.sqrt(2 / rr)
    sep = lambda tt: rain(r0 + xi, v(r0), tt) - rain(r0, v(r0), tt)                    # equal initial velocity: pair at relative rest
    acc = (sep(T) + sep(-T) - 2 * xi) / T ** 2 / xi                                    # symmetric difference removes the odd term
    rain_err = abs(acc - 2 / r0 ** 3) / (2 / r0 ** 3)
    # numbers: local exponents; vacuum sum rule; de Sitter slope
    lam_r = math.sqrt(2 / r0 ** 3); om_t = math.sqrt(1 / r0 ** 3); sumrule = lam_r ** 2 - 2 * om_t ** 2
    H0 = 67.4 * 1e3 / 3.0856775814913673e22; HL = H0 * math.sqrt(0.685); gyr = 3.15576e16
    # canary: matter-dominated Friedmann has tr E > 0 and no unstable direction (no tidal frontier)
    dust_ok = zero(E_f.subs(a, t ** sp.Rational(2, 3)).doit() - sp.Rational(2, 9) / t ** 2 * sp.eye(3))
    ok = bool(s_ok and sd_ok and f_ok and ds_ok and n_ok and dust_ok) and rain_err < 2e-3 and abs(sumrule) < 1e-15
    must(ok, 'TB')
    R['TB'] = dict(claim='Tidal tensor E_ij = R_i0j0 (symbolic). Schwarzschild: diag(-2, 1, 1) M/r^3, trace 0; with Lambda: trace '
                         '-Lambda = Ric(u,u); Friedmann: -(a\'\'/a) delta, Ric(u,u) = -3 a\'\'/a; de Sitter: -H^2 delta, three unstable '
                         'directions with exponent H. The Newtonian tide of -M/r is the same tensor. Free-fall pairs reproduce the '
                         'radial stretching 2M/r^3. Vacuum sum rule: lambda_r^2 = 2 omega_t^2. In the Lambda era one decade of '
                         'initial precision buys ln 10 / H_Lambda of forecast. Canary: matter-dominated Friedmann has E = (2/9t^2) '
                         'delta, positive, with no unstable direction.',
                   status='PROVED (symbolic) + numerical geodesic check', schwarzschild=bool(s_ok), schwarzschild_de_sitter=bool(sd_ok),
                   friedmann=bool(f_ok), de_sitter=bool(ds_ok), newtonian_tide=bool(n_ok), dust_focusing=bool(dust_ok),
                   rain_pair_rel_err=fl(rain_err), sum_rule_defect=fl(sumrule), hubble_time_Lambda_Gyr=fl(1 / HL / gyr),
                   forecast_per_decade_Gyr=fl(math.log(10) / HL / gyr))


def TC():
    rng = np.random.default_rng(SEED + 5)
    def prop(E, tt):
        Z = np.zeros((3, 3)); G = np.block([[Z, np.eye(3)], [-E, Z]]); return expm(G * tt)
    worst, liou, shear = 0.0, 0.0, []
    Rn = rng.normal(size=(3, 3)); Rn = Rn @ Rn.T + 3 * np.eye(3)
    for case in range(40):
        E = rng.normal(size=(3, 3)); E = (E + E.T) / 2
        if case % 2 == 0:
            E -= np.trace(E) / 3 * np.eye(3)                         # vacuum: traceless
        h = 2e-3
        def logdetI(tt):
            Phi = prop(E, tt)[:3, :3]; return np.linalg.slogdet(Phi.T @ np.linalg.solve(Rn, Phi))[1]
        d2 = (logdetI(h) - 2 * logdetI(0) + logdetI(-h)) / h ** 2
        worst = max(worst, abs(d2 + 2 * np.trace(E)))
        liou = max(liou, abs(np.linalg.det(prop(E, 0.7)) - 1))
        if case % 2 == 0:
            Phi = prop(E, 0.5)[:3, :3]; sv = np.linalg.svd(Phi, compute_uv=False); shear.append(float(sv[0] / sv[2]))
    # exact identity E = -Phi''(0)
    E = rng.normal(size=(3, 3)); E = (E + E.T) / 2; h = 1e-3
    e_rec = -(prop(E, h)[:3, :3] - 2 * np.eye(3) + prop(E, -h)[:3, :3]) / h ** 2; rec = float(np.max(np.abs(e_rec - E)))
    # frontier along the unstable eigendirection of a constant vacuum E: slope 1/sqrt(-e_min)
    Ev = np.diag([-2.0, 1.0, 1.0]) * 0.05; lam = math.sqrt(0.1); zq = norm.ppf(0.95)
    Ls = np.linspace(8, 24, 9); hz = [brentq(lambda tt: math.exp(-L) * zq * math.cosh(lam * tt) - 1e-2, 0, 500) for L in Ls]
    slope = float(np.polyfit(Ls, hz, 1)[0])
    ok = worst < 2e-4 and liou < 1e-10 and min(shear) > 1.05 and rec < 1e-5 and abs(slope - 1 / lam) < 1e-3 * (1 / lam) * 5
    must(ok, 'TC')
    R['TC'] = dict(claim='Forecast Fisher volume. For two free carriers initially at relative rest, the position propagator obeys '
                         'Phi\'\' = -E Phi and the Fisher form of the initial separation is I_t = Phi^T R^-1 Phi. Then E = -Phi\'\'(0) and '
                         'd^2/dt^2 ln det I_t at t = 0 equals -2 tr E = -2 Ric(u,u), for every noise R. In vacuum the volume is '
                         'stationary to second order while the shape shears. Along the unstable direction the horizon has slope '
                         '1/sqrt(-e_min). Canary: the full phase-space propagator has determinant one for every E (Liouville); '
                         'the volume law is a statement about the position record with comoving preparation.',
                   status='PROVED', volume_law_err=fl(worst), liouville_defect=fl(liou), vacuum_shear_min=fl(min(shear)),
                   tidal_reconstruction_err=fl(rec), frontier_slope=fl(slope), expected_slope=fl(1 / lam))


def TD():
    rng = np.random.default_rng(SEED + 6)
    eta = np.diag([-1.0, 1, 1, 1]); kappa, Lam = 8 * math.pi, 0.3
    idx = [(i, j) for i in range(4) for j in range(i, 4)]
    def observers(K, dim):
        us = []
        for _ in range(K):
            v = np.zeros(3); v[:dim] = rng.normal(size=dim); v *= rng.uniform(0.05, 0.9) / np.linalg.norm(v)
            g = 1 / math.sqrt(1 - v @ v); us.append(np.concatenate([[g], g * v]))
        return us
    def design(us):
        return np.array([[(1 if i == j else 2) * u[i] * u[j] for (i, j) in idx] for u in us])
    T = rng.normal(size=(4, 4)); T = T + T.T; trT = float(np.sum(np.linalg.inv(eta) * T))
    Ric = kappa * (T - 0.5 * trT * eta) + Lam * eta
    us = observers(14, 3); Dm = design(us); data = np.array([u @ Ric @ u for u in us])
    sol = np.linalg.lstsq(Dm, data, rcond=None)[0]; Rrec = np.zeros((4, 4))
    for c, (i, j) in zip(sol, idx):
        Rrec[i, j] = Rrec[j, i] = c
    Xr = (Rrec - Lam * eta) / kappa; trX = float(np.sum(np.linalg.inv(eta) * Xr)); Trec = Xr - 0.5 * trX * eta
    rec = float(np.max(np.abs(Trec - T)))
    ranks = {'one_observer': int(np.linalg.matrix_rank(design(observers(1, 3)))), 'collinear_velocities': int(np.linalg.matrix_rank(design(observers(14, 1)))),
             'coplanar_velocities': int(np.linalg.matrix_rank(design(observers(14, 2)))), 'generic': int(np.linalg.matrix_rank(Dm)),
             'nine_generic': int(np.linalg.matrix_rank(design(observers(9, 3))))}
    # perfect fluid seen by a comoving observer: Ric(u,u) = (kappa/2)(rho + 3p) - Lambda
    rho, p = 1.3, 0.4; Tf = np.diag([rho, p, p, p]); u0 = np.array([1.0, 0, 0, 0])
    Rf = kappa * (Tf - 0.5 * (-rho + 3 * p) * eta) + Lam * eta; fluid = abs(u0 @ Rf @ u0 - (kappa / 2 * (rho + 3 * p) - Lam))
    # canary: the response law without trace reversal (Ric = kappa T) predicts a different focusing for dust
    wrong = abs(kappa * rho - kappa * rho / 2) / (kappa * rho / 2)
    # flux hole: two sources with equal energy density and opposite flux are identical to observers moving orthogonally to the flux
    Ta = np.diag([1.0, 0.3, 0.3, 0.3]); Tb = Ta.copy(); Ta[0, 1] = Ta[1, 0] = 0.4; Tb[0, 1] = Tb[1, 0] = -0.4
    ric = lambda TT: kappa * (TT - 0.5 * float(np.sum(np.linalg.inv(eta) * TT)) * eta)
    uo = []
    for _ in range(8):
        v = np.concatenate([[0.0], rng.normal(size=2)]); v *= 0.5 / np.linalg.norm(v); g = 1 / math.sqrt(1 - v @ v); uo.append(np.concatenate([[g], g * v]))
    blind = max(abs(u @ ric(Ta) @ u - u @ ric(Tb) @ u) for u in uo)
    ux = np.array([1 / math.sqrt(1 - 0.25), 0.5 / math.sqrt(1 - 0.25), 0, 0]); seen = abs(ux @ ric(Ta) @ ux - ux @ ric(Tb) @ ux)
    ok = rec < 1e-9 and ranks == {'one_observer': 1, 'collinear_velocities': 3, 'coplanar_velocities': 6, 'generic': 10, 'nine_generic': 9} \
        and fluid < 1e-12 and wrong == 1.0 and blind < 1e-12 and seen > 1.0
    must(ok, 'TD')
    R['TD'] = dict(claim='The volume law for all observers is the response law. Ric(u,u) on an open set of unit timelike vectors '
                         'determines the Ricci tensor; with ten generic observers the source tensor is recovered exactly. The rank '
                         'of the observer family is 1, 3, 6, 10 for one observer, collinear, coplanar and generic velocities: flux '
                         'and stress transverse to the velocities are in the hole. Two sources with opposite flux are identical '
                         'to every observer moving orthogonally to it. Canary: the law without trace reversal predicts twice the '
                         'focusing for dust.',
                   status='PROVED', source_recovery_err=fl(rec), ranks=ranks, fluid_identity_err=fl(fluid), wrong_law_rel_gap=fl(wrong),
                   flux_blind_difference=fl(blind), flux_seen_difference=fl(seen))


def _leaver(l, s=2, nmax=600):
    eps_ = s * s - 1; lam_c = 1 / (3 * math.sqrt(3))
    def cf(w):
        rho = -1j * w                                               # units 2M = 1
        al = lambda n: n * n + (2 * rho + 2) * n + 2 * rho + 1
        be = lambda n: -(2 * n * n + (8 * rho + 2) * n + 8 * rho * rho + 4 * rho + l * (l + 1) - eps_)
        ga = lambda n: n * n + 4 * rho * n + 4 * rho * rho - eps_ - 1
        f = 0
        for n in range(nmax, 0, -1):
            f = al(n - 1) * ga(n) / (be(n) - f)
        return be(0) - f
    F = lambda v: [cf(complex(v[0], v[1])).real, cf(complex(v[0], v[1])).imag]
    sol = fsolve(F, [2 * (l + 0.5) * lam_c, -lam_c], xtol=1e-13)
    return complex(sol[0], sol[1]) / 2


def _kerr_light_ring(a, M=1.0):
    def conds(v):
        r, b = v; P = r * r + a * a - a * b
        return [P * P - (r * r - 2 * M * r + a * a) * (b - a) ** 2, 4 * r * P - (2 * r - 2 * M) * (b - a) ** 2]
    r, b = fsolve(conds, [2 * M * (1 + math.cos(2 / 3 * math.acos(-a / M))), 3 * math.sqrt(3) * M * (1 - 0.5 * a) + 1e-3], xtol=1e-12)
    P = r * r + a * a - a * b; D = r * r - 2 * M * r + a * a; Rpp = 4 * P + 8 * r * r - 2 * (b - a) ** 2
    tdot = -a * (a - b) + (r * r + a * a) * P / D; pdot = -(a - b) + a * P / D
    return float(r), float(pdot / tdot), float(math.sqrt(Rpp / 2) / tdot)


def TE():
    bc = 3 * math.sqrt(3)
    # (a) photon orbits u'' + u = 3 u^2 (M = 1) from infinity: total azimuth diverges like -ln(b/b_c - 1)
    def azimuth(delta):
        b = bc * (1 + delta); ev = lambda p_, yv: yv[1]; ev.terminal = True; ev.direction = -1
        s = solve_ivp(lambda p_, yv: [yv[1], 3 * yv[0] ** 2 - yv[0]], (0, 200), [0.0, 1 / b], events=ev, rtol=1e-13, atol=1e-15)
        return 2 * s.t_events[0][0]
    ds = [10.0 ** (-k) for k in range(3, 9)]; az = [azimuth(d_) for d_ in ds]
    slope = float(np.polyfit(np.log(1 / np.array(ds)), az, 1)[0])
    steps = [az[i + 1] - az[i] for i in range(len(az) - 1)]
    demag = math.exp(-math.pi)                                      # impact-parameter window per extra half orbit
    # (b) light-ring exponent and Leaver quasinormal ladder (Schwarzschild, gravitational)
    rc, Om0, lam0 = _kerr_light_ring(0.0)
    ladder = {}
    for l in range(2, 13):
        w = _leaver(l); ladder[l] = (w.real, w.imag, -w.imag / (lam0 / 2), (1 + w.imag / (lam0 / 2)) * (l + 0.5) ** 2)
    conv = [ladder[l][2] for l in range(2, 13)]; tails = [ladder[l][3] for l in (8, 10, 12)]
    known = abs(complex(ladder[2][0], ladder[2][1]) - complex(0.37367, -0.08896)) < 2e-5
    # (c) Kerr light ring at the remnant spin; ringdown numbers
    a = 0.67; rk, Omk, lamk = _kerr_light_ring(a)
    Fk = 1.5251 - 1.1568 * (1 - a) ** 0.1292; Qk = 0.7 + 1.4187 * (1 - a) ** (-0.4990)        # imported fit, l = m = 2, n = 0
    F0 = 1.5251 - 1.1568; Q0 = 0.7 + 1.4187
    fit_check = (abs(F0 - ladder[2][0]) / ladder[2][0], abs(Q0 - ladder[2][0] / (-2 * ladder[2][1])) / (ladder[2][0] / (-2 * ladder[2][1])))
    Msec = 68 * 4.925490947e-6                                      # 68 solar masses, detector frame
    f_fit = Fk / (2 * math.pi * Msec); tau_fit = 2 * Qk / Fk * Msec * 1e3; tau_eik = 2 / lamk * Msec * 1e3
    f_schw = ladder[2][0] / (2 * math.pi * Msec); tau_schw = -1 / ladder[2][1] * Msec * 1e3
    ok = abs(slope - 1) < 0.01 and all(abs(s_ - math.log(10)) < 0.02 for s_ in steps[2:]) and abs(rc - 3) < 1e-8 and abs(lam0 - 1 / bc) < 1e-10 \
        and abs(Om0 - 1 / bc) < 1e-10 and known and all(conv[i] < conv[i + 1] < 1 for i in range(len(conv) - 1)) and conv[-1] > 0.997 \
        and max(tails) - min(tails) < 0.02 and abs(f_fit - 251) < 8 and abs(tau_fit - 4.0) < 0.3 and abs(tau_eik - 4.0) < 0.3 \
        and max(fit_check) < 0.02 and abs(f_schw - 251) > 8 * 5                    # canary: zero spin misses the frequency
    must(ok, 'TE')
    R['TE'] = dict(claim='Light ring. Photon orbits of Schwarzschild: the total azimuth grows like ln(1/delta), delta = b/b_c - 1, '
                         'with slope one, so each further half orbit needs the impact parameter exp(-pi) = 0.0432 times closer. The '
                         'instability exponent of the light ring is 1/(3 sqrt(3) M). Quasinormal frequencies by Leaver\'s continued '
                         'fraction: the damping rate tends to half that exponent, ratio 0.9245 at l = 2 and 0.9974 at l = 12, with '
                         '(1 - ratio)(l + 1/2)^2 constant. For a remnant of 68 solar masses and spin 0.67 the imported Kerr fit '
                         'gives 248.4 Hz and 4.06 ms; twice the Kerr light-ring e-folding time is 3.80 ms; the published values are '
                         '251 +- 8 Hz and 4.0 +- 0.3 ms. Canary: zero spin gives 177.6 Hz.',
                   status='PROVED (geodesics) + computed (Leaver) + IDENTIFIED (eikonal correspondence) + imported fit and published values',
                   azimuth_slope=fl(slope), azimuth_steps_per_decade=[fl(s_) for s_ in steps], half_orbit_factor=fl(demag),
                   light_ring_exponent=fl(lam0), ladder={str(l): [fl(v) for v in ladder[l]] for l in ladder},
                   kerr_light_ring=dict(radius=fl(rk), frequency=fl(Omk), exponent=fl(lamk)), fit_vs_leaver_rel=[fl(v) for v in fit_check],
                   ringdown_fit_Hz_ms=[fl(f_fit), fl(tau_fit)], eikonal_tau_ms=fl(tau_eik), zero_spin_Hz_ms=[fl(f_schw), fl(tau_schw)])


# ============================================================================================ S: sources are moments
def SA():
    rng = np.random.default_rng(SEED + 7)
    worst = -np.inf
    for _ in range(2000):
        k = int(rng.integers(2, 9)); pr = rng.dirichlet(np.ones(k) * rng.uniform(0.2, 2)); at = rng.normal(size=k) * 10 ** rng.uniform(-2, 2, k)
        eps = abs(rng.normal()) * 10 ** rng.uniform(-2, 1); q = float(np.sum(pr[np.abs(at) <= eps]))
        worst = max(worst, float(np.sum(pr * at ** 2)) - eps ** 2 - math.sqrt(max(0.0, 1 - q) * float(np.sum(pr * at ** 4))))
    spikes = []
    for a in (1 / 8, 1 / 32, 1 / 128, 1 / 512):
        cover, mean2, m4 = 1 - a * a, 1.0, a ** -2; spikes.append((a, cover, mean2, math.sqrt((1 - cover) * m4)))
    # forecast energy deficit: E[T] = T[xhat] + tr(M Sigma); growth 2 lambda; isometric flow: constant
    d = 4; lam = 0.6; G = rng.normal(size=(d, d)); Mq = G @ G.T; S0 = rng.normal(size=(d, d)); S0 = 1e-6 * (S0 @ S0.T + np.eye(d)); xh = rng.normal(size=d)
    Q_, _ = np.linalg.qr(rng.normal(size=(d, d))); A = Q_ @ np.diag([math.exp(lam), 0.8, 0.7, 0.5]) @ Q_.T
    Lc = np.linalg.cholesky(S0); pts = [xh] + [xh + s * math.sqrt(d) * Lc[:, i] for i in range(d) for s in (1, -1)]
    wts = [0.0] + [1 / (2 * d)] * (2 * d)
    sig_mean = sum(w * (pt @ Mq @ pt) for w, pt in zip(wts, pts)); ident = abs(sig_mean - (xh @ Mq @ xh + np.trace(Mq @ S0))) / (xh @ Mq @ xh)
    defs = [float(np.trace(Mq @ np.linalg.matrix_power(A, n) @ S0 @ np.linalg.matrix_power(A, n).T)) for n in range(40)]
    rate = math.log(defs[39] / defs[38])
    Hh = G @ G.T + d * np.eye(d); Kk = rng.normal(size=(d, d)); Kk = Kk - Kk.T; U = expm(np.linalg.solve(Hh, Kk))
    iso = [float(np.trace(Hh @ np.linalg.matrix_power(U, n) @ S0 @ np.linalg.matrix_power(U, n).T)) for n in (0, 7, 31)]
    # source horizon at an absolute tolerance: first n with tr(M A^n Sigma A^nT) >= eps_T; slope 1/lambda in ln(1/sigma)
    unit = [d_ / 1e-6 for d_ in defs] + [float(np.trace(Mq @ np.linalg.matrix_power(A, n) @ (S0 / 1e-6) @ np.linalg.matrix_power(A, n).T)) for n in range(40, 90)]
    Ls = np.arange(8, 41, 4.0); hz = [next(n for n, u in enumerate(unit) if math.exp(-2 * L) * u >= 1e-3) for L in Ls]
    slope = float(np.polyfit(Ls, hz, 1)[0])
    ok = worst < 1e-9 and all(abs(s_[3] - 1) < 1e-12 and s_[2] == 1.0 for s_ in spikes) and spikes[-1][1] > 0.99999 and ident < 1e-12 \
        and abs(rate - 2 * lam) < 1e-6 and max(iso) - min(iso) < 1e-9 * max(iso) and abs(slope - 1 / lam) < 0.03 / lam
    must(ok, 'SA')
    R['SA'] = dict(claim='Sources are moments. If a forecast error has coverage q at tolerance eps and fourth moment m4, its mean '
                         'square is at most eps^2 + sqrt((1 - q) m4); the bound holds on 2000 seeded laws and is attained by the '
                         'rare-spike family (probability a^2, amplitude 1/a), whose coverage tends to one while its mean square '
                         'stays one. For a quadratic source the expectation is the source of the forecast plus tr(M Sigma_n) >= 0, '
                         'a defect that grows at twice the exponent and is constant under an energy isometry. Canary: coverage '
                         'tending to one does not make the source converge.',
                   status='PROVED', transfer_slack=fl(worst), spikes=[[fl(v) for v in s_] for s_ in spikes], deficit_identity_err=fl(ident),
                   deficit_growth_rate=fl(rate), expected_rate=fl(2 * lam), isometric_deficit=[fl(v) for v in iso], source_horizon_slope=fl(slope))


if __name__ == '__main__':
    for f in [FA, FB, FC, FD, FE, FF, TA, TB, TC, TD, TE, SA]:
        f(); print(f.__name__, flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(open(os.path.abspath(__file__), 'rb').read()).hexdigest()
    out['helper_sha256'] = hashlib.sha256(open(os.path.join(HERE, 'rg_curv.py'), 'rb').read()).hexdigest()
    json.dump(out, open(os.path.join(HERE, 'rg_tensor_frontier_results.json'), 'w'), indent=1, sort_keys=True)
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
