#!/usr/bin/env python3
"""Mutation suite for rg_tensor_frontier.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. About two minutes.

    python3 -I rg_tensor_frontier_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('FA', 'claim: predictive metric always Lipschitz', "min(1.0, math.log(1 / beta) / math.log(2)))", "1.0)"),
    ('FB', 'claim: a tighter bound than the posterior', "post = 1 / math.sqrt(1 / tau ** 2 + 1 / s0 ** 2)", "post = 0.5 * s0"),
    ('FC', 'cap computed from the wrong hole scale', "cap = horizon(A, eta ** 2 * Nb @ Nb.T, C)", "cap = horizon(A, (10 * eta) ** 2 * Nb @ Nb.T, C)"),
    ('FD', 'wrong power of the exponent in the correction', "pred1 = -zq * math.sqrt(D1 / lam1 ** 3)", "pred1 = -zq * math.sqrt(D1 / lam1 ** 2)"),
    ('FE', 'wrong growth law in the number of like-signed directions', "predicted_factor=fl(2 * math.sqrt(m)))", "predicted_factor=fl(2 * m))"),
    ('FE', 'claim: a positive conserved form allows growth', "Hi = np.diag([1.0, 1, 1, 1, -1, -1])", "Hi = np.diag([1.0, 1, 1, 1, 1, 1])"),
    ('FF', 'elliptic sign in the perturbation equation', "out += [F[3 + 2 * j], kap * lap(F[2 + 2 * j])", "out += [F[3 + 2 * j], -kap * lap(F[2 + 2 * j])"),
    ('TA', 'record degree left out of the growth', "h = (math.log(eps) - k * np.log(sig * zq)) / (k * lam)", "h = (math.log(eps) - k * np.log(sig * zq)) / lam"),
    ('TB', 'wrong sign of the cosmological term', "fd = 1 - 2 * M / r - Lam * r ** 2 / 3", "fd = 1 - 2 * M / r + Lam * r ** 2 / 3"),
    ('TC', 'volume law with half the coefficient', "worst = max(worst, abs(d2 + 2 * np.trace(E)))", "worst = max(worst, abs(d2 + np.trace(E)))"),
    ('TD', 'response law without trace reversal', "Ric = kappa * (T - 0.5 * trT * eta) + Lam * eta", "Ric = kappa * T + Lam * eta"),
    ('TD', 'claim: coplanar observers see the whole source', "'coplanar_velocities': 6, 'generic': 10, 'nine_generic': 9}", "'coplanar_velocities': 10, 'generic': 10, 'nine_generic': 9}"),
    ('TE', 'wrong relativistic term in the photon orbit', "[yv[1], 3 * yv[0] ** 2 - yv[0]]", "[yv[1], 2 * yv[0] ** 2 - yv[0]]"),
    ('TE', 'scalar instead of gravitational perturbations', "def _leaver(l, s=2, nmax=600):", "def _leaver(l, s=0, nmax=600):"),
    ('SA', 'half the tail budget', "- eps ** 2 - math.sqrt(max(0.0, 1 - q)", "- eps ** 2 - 0.5 * math.sqrt(max(0.0, 1 - q)"),
]


def main():
    base = open(os.path.join(HERE, 'rg_tensor_frontier.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            shutil.copy(os.path.join(HERE, 'rg_curv.py'), tmp)
            open(os.path.join(tmp, 'rg_tensor_frontier.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_tensor_frontier.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_tensor_frontier_results.json')))['failures']
            except Exception:
                fails = [group] if run.returncode != 0 else []
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
