#!/usr/bin/env python3
"""
RG quantum metric selection: locked battery QS01-QS10
====================================================
Petz monotone metrics g_f(rho; A, A) = sum_ij |A_ij|^2 / (l_j f(l_i / l_j)) (eigenbasis of rho), with f operator
monotone, f(t) = t f(1/t), f(1) = 1. Every verdict is computed; no response is generated from the candidate it
is meant to select except where that is the stated point (QS05, QS06 attack exactly that).

  QS01 classical collapse: commuting tasks give one metric (Cencov)
  QS02 monotonicity is a family gate: Petz members pass random CPTP maps, a symmetric non-operator-monotone f fails
  QS03 task selection, estimation: max over measurements of classical Fisher = SLD (Braunstein-Caves)
  QS04 task selection, Stein testing: Hessian of Umegaki relative entropy = BKM
  QS05 task selection, symmetric (Chernoff) testing: local quantum Chernoff exponent = g_WY h^2 / 8
  QS06 nonparametric reconstruction of f from responses (no panel); panel 'lock' on off-panel data is false
  QS07 panel lock is resolution-relative: a BKM/SLD mixture within noise of BKM data
  QS08 wall specialization: g_f extends to a support wall iff f(0) > 0; divergence rates for f(0) = 0
  QS09 SLD limit at the pure-state wall is the Fubini-Study metric (x4)
  QS10 metric selection does not select transport: unitarily covariant lifts differ, metric identical

Run:  python3 rg_quantum_metric_attack.py [--seed 20261002] [--out FILE] [--canary]
"""
import argparse, json, math, sys, time
import numpy as np
from scipy.optimize import minimize, minimize_scalar

RESULTS, MUT = [], {}


def f_(x): return float(np.round(float(x), 12))


def _finite(o):
    if isinstance(o, dict): return all(_finite(v) for v in o.values())
    if isinstance(o, (list, tuple)): return all(_finite(v) for v in o)
    if isinstance(o, float): return math.isfinite(o)
    return True


def register(aid, naive, keep, passed, ev, verdict):
    if not _finite(ev): passed, verdict = False, "NONFINITE"
    RESULTS.append(dict(id=aid, naive_claim=naive, rg_claim=keep, passed=bool(passed), verdict=verdict, evidence=ev))
    print(f"[{'PASS' if passed else 'FAIL'}] {aid} {verdict:16s} {keep[:84]}")


H = lambda a: (a+a.conj().T)/2
PAULI = [np.array([[0, 1], [1, 0]], complex), np.array([[0, -1j], [1j, 0]]), np.array([[1, 0], [0, -1]], complex)]


def fbkm(t): return 1.0 if abs(t-1) < 1e-9 else (t-1)/math.log(t)
def fsld(t): return (1+t)/2
def frld(t): return 2*t/(1+t)
def fwy(t): return ((1+math.sqrt(t))/2)**2
def fheinz(t): return 0.5*(t**0.25+t**0.75)
PANEL = dict(BKM=fbkm, SLD=fsld, RLD=frld, WY=fwy, HEINZ=fheinz)


def density(rng, d=2, floor=0.08):
    x = rng.normal(size=(d, d))+1j*rng.normal(size=(d, d)); r = x@x.conj().T; r /= np.trace(r).real
    return H((1-d*floor)*r+floor*np.eye(d))


def tangent(rng, d=2):
    a = H(rng.normal(size=(d, d))+1j*rng.normal(size=(d, d))); a -= np.trace(a).real/d*np.eye(d)
    return a/np.linalg.norm(a)


def metric(r, a, f):
    w, u = np.linalg.eigh(H(r)); z = u.conj().T@a@u
    return float(sum(abs(z[i, j])**2/(w[j]*f(w[i]/w[j])) for i in range(len(w)) for j in range(len(w))))


def mfun(r, fn):
    w, u = np.linalg.eigh(H(r)); return (u*fn(np.maximum(w, 1e-300)))@u.conj().T


def rand_channel(rng, d=2, k=3):
    K = rng.normal(size=(k, d, d))+1j*rng.normal(size=(k, d, d))
    S = sum(Ki.conj().T@Ki for Ki in K); w, u = np.linalg.eigh(S); Si = (u*w**-0.5)@u.conj().T
    K = [Ki@Si for Ki in K]
    return lambda x: sum(Ki@x@Ki.conj().T for Ki in K)


# ======================================================================= checks
def QS01_classical(rng):
    spread = 0.0
    for _ in range(200):
        p = rng.uniform(0.05, 0.95); r = np.diag([p, 1-p]).astype(complex); x = rng.normal(); a = np.diag([x, -x]).astype(complex)
        v = [metric(r, a, f) for f in PANEL.values()]; spread = max(spread, max(v)-min(v))
    register("QS01", "Some commuting experiment can tell the Petz members apart.",
             "On commuting tasks every Petz metric reduces to the classical Fisher metric (f(1)=1, Cencov): no "
             "discrimination is possible there.", spread < 1e-12, dict(max_spread=f_(spread)), "HOLDS")


def QS02_monotone_gate(rng):
    """Random CPTP maps (3 Kraus operators): Petz members never increase; the symmetric, normalized but
    non-operator-monotone f(t) = (t^2 + 1/t)/2 does for some channel (the gate has teeth)."""
    fbad = lambda t: (t*t+1/t)/2
    worst = {k: -np.inf for k in PANEL}; bad = -np.inf
    for _ in range(MUT.get("qs02_n", 400)):
        r, a = density(rng, floor=0.05), tangent(rng); ch = rand_channel(rng)
        rr, aa = H(ch(r)), H(ch(a))
        for k, f in PANEL.items(): worst[k] = max(worst[k], metric(rr, aa, f)-metric(r, a, f))
        if not MUT.get("qs02_skip_bad"):
            bad = max(bad, metric(rr, aa, fbad)-metric(r, a, fbad))
    passed = max(worst.values()) < 1e-9 and bad > 1e-3
    register("QS02", "CPTP monotonicity selects the quantum metric.",
             "Monotonicity is a family gate (Petz): every panel member passes random channels, a symmetric "
             "non-operator-monotone candidate fails, and the gate selects no member.",
             passed, dict(max_increase_panel={k: f_(v) for k, v in worst.items()}, max_increase_nonmonotone=f_(bad)), "HOLDS")


def QS03_estimation_selects_SLD(rng):
    """Braunstein-Caves: max over (projective) measurements of the classical Fisher information of the outcome
    statistics equals the SLD metric; every other panel member is strictly larger (unattainable)."""
    gaps, worst = [], 0.0
    def Fc(n, r, a):
        n = n/np.linalg.norm(n); P = (np.eye(2)+sum(ni*s for ni, s in zip(n, PAULI)))/2
        out = 0.0
        for Pk in (P, np.eye(2)-P):
            p = np.trace(Pk@r).real; dp = np.trace(Pk@a).real; out += dp*dp/max(p, 1e-15)
        return out
    for _ in range(60):
        r, a = density(rng), tangent(rng)
        best = max(-minimize(lambda n: -Fc(n, r, a), rng.normal(size=3), method="Nelder-Mead",
                             options=dict(xatol=1e-10, fatol=1e-12, maxiter=4000)).fun for _ in range(6))
        g = {k: metric(r, a, f) for k, f in PANEL.items()}
        worst = max(worst, abs(best-g["SLD"])/g["SLD"])
        gaps.append(min(g[k]-best for k in g if k != "SLD"))
    passed = worst < 1e-6 and min(gaps) > 0
    register("QS03", "The quantum Fisher metric is one object regardless of task.",
             "For local estimation with optimal measurement the attainable metric is SLD (Braunstein-Caves): max "
             "classical Fisher over measurements equals g_SLD; all other members exceed every measured Fisher value.",
             passed, dict(max_rel_dev_from_SLD=f_(worst), min_gap_other_members=f_(min(gaps))), "HOLDS")


def QS04_stein_selects_BKM(rng):
    """Quantum Stein: the optimal type-II exponent is the Umegaki relative entropy; its Hessian is BKM."""
    worst, sld_gap = 0.0, []
    for _ in range(60):
        r, a = density(rng, floor=0.12), tangent(rng); h = 1e-4
        D = lambda x, y: np.trace(x@(mfun(x, np.log)-mfun(y, np.log))).real
        sec = (D(r+h*a, r)+D(r-h*a, r))/h**2
        worst = max(worst, abs(sec-metric(r, a, fbkm))/metric(r, a, fbkm))
        sld_gap.append(abs(sec-metric(r, a, fsld))/metric(r, a, fsld))
    passed = worst < 1e-5 and np.median(sld_gap) > 1e-3
    register("QS04", "Relative-entropy distinguishability is the SLD metric.",
             "The Stein exponent (Umegaki relative entropy) has Hessian g_BKM; it differs from SLD on noncommuting "
             "tangents.", passed, dict(max_rel_dev_from_BKM=f_(worst), median_rel_gap_SLD=f_(np.median(sld_gap))), "HOLDS")


def QS05_chernoff_selects_WY(rng):
    """Quantum Chernoff bound xi = -log min_s Tr rho^s sigma^(1-s): locally xi = g_WY h^2/8 (optimum s = 1/2)."""
    worst, gaps = 0.0, []
    for _ in range(40):
        r, a = density(rng), tangent(rng); h = 1e-4; s_ = r+h*a
        Q = lambda s: np.trace(mfun(r, lambda w: w**s)@mfun(s_, lambda w: w**(1-s))).real
        if MUT.get("qs05_fixed_s"): val = Q(0.3)                     # mutation: no optimisation over s
        else: val = minimize_scalar(Q, bounds=(0, 1), method="bounded", options=dict(xatol=1e-12)).fun
        loc = 8*(-math.log(val))/h**2
        worst = max(worst, abs(loc-metric(r, a, fwy))/metric(r, a, fwy))
        gaps.append(min(abs(loc-metric(r, a, f))/metric(r, a, f) for k, f in PANEL.items() if k != "WY"))
    passed = worst < 1e-3 and np.median(gaps) > 5e-3
    register("QS05", "Symmetric hypothesis testing uses the same metric as estimation.",
             "The local quantum Chernoff exponent is g_WY h^2/8: symmetric testing selects Wigner-Yanase, a third "
             "member. The metric is selected by the declared task.",
             passed, dict(max_rel_dev_from_WY=f_(worst), median_rel_gap_others=f_(np.median(gaps))), "HOLDS")


def reconstruct_f(rng, ftrue, kappa, noise, n=60):
    """Nonparametric: diagonal tasks calibrate kappa (classical Fisher); off-diagonal tasks on rho = diag(l1, l2)
    with A = sigma_x/sqrt2 give y = kappa * 2 |A12|^2 /(l2 f(l1/l2)) -> f(t) = kappa |A12|^2 * 2/(l2 y)."""
    ks = []
    for _ in range(20):
        p = rng.uniform(0.1, 0.9); r = np.diag([p, 1-p]).astype(complex); a = np.diag([1, -1]).astype(complex)/math.sqrt(2)
        y = kappa*metric(r, a, ftrue)*(1+noise*rng.normal()); ks.append(y/metric(r, a, fsld))   # any f: classical
    kh = float(np.mean(ks))
    ts, fh = [], []
    A = PAULI[0]/math.sqrt(2)
    for p in np.linspace(0.52, 0.97, n):
        r = np.diag([p, 1-p]).astype(complex); y = kappa*metric(r, A, ftrue)*(1+noise*rng.normal())
        t = p/(1-p); ts.append(t); fh.append(kh*2*0.5/((1-p)*y))
    return kh, np.array(ts), np.array(fh)


def QS06_reconstruction(rng):
    """Responses generated by an OFF-panel Petz function f* = 0.6 BKM + 0.4 WY (operator monotone, symmetric).
    Nonparametric reconstruction recovers f* pointwise; the panel 'lock' picks a panel member falsely."""
    fstar = lambda t: 0.6*fbkm(t)+0.4*fwy(t)
    kappa, noise = 2.75, MUT.get("qs06_noise", 1e-5)
    kh, ts, fh = reconstruct_f(rng, fstar, kappa, noise)
    err = float(np.max(np.abs(fh-np.array([fstar(t) for t in ts]))/np.array([fstar(t) for t in ts])))
    band = 5*noise*3
    survivors = [k for k, f in PANEL.items() if np.max(np.abs(fh-np.array([f(t) for t in ts]))/fh) < band]
    # panel fit (the uploaded method): fit scale per member to off-diagonal responses, pick min loss
    E = [(density(rng), tangent(rng)) for _ in range(40)]
    y = np.array([kappa*metric(r, a, fstar)*(1+noise*rng.normal()) for r, a in E])
    loss = {}
    for k, f in PANEL.items():
        v = np.array([metric(r, a, f) for r, a in E]); s = v@y/(v@v); loss[k] = float(np.mean((y-s*v)**2)/np.mean(y*y))
    panel_pick = min(loss, key=loss.get)
    passed = abs(kh-kappa)/kappa < 1e-4 and err < 1e-3 and survivors == [] and loss[panel_pick] > 10*noise**2
    register("QS06", "A finite candidate panel locks the quantum metric (uploaded Q-C1).",
             "The Petz function is identified nonparametrically: diagonal tasks fix the scale, off-diagonal tasks give "
             "f(t) pointwise. Off-panel data are reconstructed (error <1e-3) and every panel member is rejected; a panel "
             "fit still names a winner, which is false.",
             passed, dict(scale_rel_err=f_(abs(kh-kappa)/kappa), max_rel_err_f=f_(err), panel_survivors=survivors,
                          panel_pick=panel_pick, panel_pick_loss=f_(loss[panel_pick]), noise=noise), "FALSIFIED-naive")


def QS07_resolution(rng):
    """BKM-generated data with relative noise 2e-5: the mixture f_w = (1-w) BKM + w SLD with w = 1e-3 fits within
    noise. 'LOCKED BKM' is a statement about the resolution band, not about the Petz class."""
    noise = 2e-5; E = [(density(rng), tangent(rng)) for _ in range(40)]
    y = np.array([2.75*metric(r, a, fbkm)*(1+noise*rng.normal()) for r, a in E])
    def loss(f):
        v = np.array([metric(r, a, f) for r, a in E]); s = v@y/(v@v); return float(np.mean((y-s*v)**2)/np.mean(y*y))
    # resolution band computed from the data: w_res = noise / (relative SLD-BKM response gap)
    gap = float(np.median([abs(metric(r, a, fsld)-metric(r, a, fbkm))/metric(r, a, fbkm) for r, a in E]))
    w_res = noise/gap
    lb = loss(fbkm); lsld = loss(fsld)
    l_in = loss(lambda t: (1-0.1*w_res)*fbkm(t)+0.1*w_res*fsld(t))
    l_out = loss(lambda t: (1-10*w_res)*fbkm(t)+10*w_res*fsld(t))
    # first registration used a fixed w = 1e-3 (= 4 w_res here) and failed: that admixture IS resolvable
    passed = l_in < 2*lb and l_out > 10*lb and lsld > 100*lb
    register("QS07", "A best-fit panel member is identified exactly.",
             "Only up to a resolution band w_res = noise/gap: an SLD admixture of 0.1 w_res fits BKM data as well as BKM, "
             "one of 10 w_res is rejected. Certificates state the band of f, as for every window statement in RG.",
             passed, dict(w_res=f_(w_res), loss_BKM=f_(lb), loss_inside_band=f_(l_in), loss_outside_band=f_(l_out),
                          loss_SLD=f_(lsld)), "FALSIFIED-naive")


def QS08_wall(rng):
    """rho_eps = diag(1-eps, eps), A = sigma_x/sqrt2 (couples support and kernel). g_f -> 1/f(0) finite iff f(0) > 0;
    BKM ~ log(1/eps), Heinz(1/4) ~ eps^(-1/4), RLD ~ eps^(-1)."""
    eps = np.array([1e-2, 1e-4, 1e-6, 1e-8])
    vals = {k: np.array([metric(np.diag([1-e, e]).astype(complex), PAULI[0]/math.sqrt(2), f) for e in eps]) for k, f in PANEL.items()}
    lim_sld, lim_wy = vals["SLD"][-1], vals["WY"][-1]
    slope = lambda v: float(np.polyfit(np.log(1/eps[1:]), np.log(v[1:]), 1)[0])
    bkm_log = float(np.polyfit(np.log(1/eps[1:]), vals["BKM"][1:], 1)[0])
    passed = (abs(lim_sld-2.0) < 1e-6 and abs(lim_wy-4.0) < 1e-3 and abs(slope(vals["RLD"])-1) < 0.02 and
              abs(slope(vals["HEINZ"])-0.25) < 0.02 and abs(bkm_log-1.0) < 0.05)
    register("QS08", "All Petz metrics continue to rank (support) walls.",
             "Only those with f(0) > 0: SLD -> 1/f(0)=2, WY -> 4; BKM diverges like log(1/eps) (the Stein exponent is "
             "infinite across a support change), Heinz(1/4) like eps^-1/4, RLD like eps^-1.",
             passed, dict(SLD_limit=f_(lim_sld), WY_limit=f_(lim_wy), RLD_power=f_(slope(vals["RLD"])),
                          HEINZ_power=f_(slope(vals["HEINZ"])), BKM_log_coefficient=f_(bkm_log)), "FALSIFIED-naive")


def QS09_fubini_study(rng):
    """Pure-state wall: rho_eps = (1-eps)|psi><psi| + eps|psi_perp><psi_perp|, tangent of |psi_theta><psi_theta|.
    g_SLD -> 4 (<dpsi|dpsi> - |<psi|dpsi>|^2) (Fubini-Study x4)."""
    worst = 0.0
    for _ in range(100):
        psi = rng.normal(size=2)+1j*rng.normal(size=2); psi /= np.linalg.norm(psi)
        dpsi = rng.normal(size=2)+1j*rng.normal(size=2)
        dpsi -= np.real(np.vdot(psi, dpsi))*psi        # first-order normalization: Re<psi|dpsi> = 0 (trace-free tangent)
        perp = np.array([-np.conj(psi[1]), np.conj(psi[0])])
        A = np.outer(dpsi, psi.conj())+np.outer(psi, dpsi.conj())
        fs = 4*(np.vdot(dpsi, dpsi).real-abs(np.vdot(psi, dpsi))**2)
        e = 1e-9; r = (1-e)*np.outer(psi, psi.conj())+e*np.outer(perp, perp.conj())
        worst = max(worst, abs(metric(r, A, fsld)-fs)/fs)
    register("QS09", "Quantum metric geometry has no meaningful limit on pure states.",
             "SLD specializes to the pure-state wall as 4x Fubini-Study (Hellinger/Bures continuity, L24.1 analogue).",
             worst < 1e-6, dict(max_rel_dev_FS=f_(worst)), "HOLDS")


def QS10_no_transport(rng):
    """Metric selection does not select transport: rho_theta = U(theta) rho U(theta)^dag with two different
    latent generators that agree on the observed tangent (differ by the stabilizer of rho) give identical
    Petz metrics but different latent lifts."""
    worst_metric, lift_gap = 0.0, 0.0
    for _ in range(100):
        r = density(rng); w, u = np.linalg.eigh(r)
        G1 = H(rng.normal(size=(2, 2))+1j*rng.normal(size=(2, 2)))
        Z = u@np.diag(rng.normal(size=2))@u.conj().T                 # commutes with rho: stabilizer generator
        G2 = G1+Z
        A1 = -1j*(G1@r-r@G1); A2 = -1j*(G2@r-r@G2)
        worst_metric = max(worst_metric, max(abs(metric(r, H(A1), f)-metric(r, H(A2), f)) for f in PANEL.values()))
        lift_gap = max(lift_gap, float(np.linalg.norm(G1-G2)))
    passed = worst_metric < 1e-10 and lift_gap > 0.5
    register("QS10", "Locking the quantum metric fixes the transport of states.",
             "No: latent generators differing by the stabilizer of rho give the same tangent and the same metric for "
             "every Petz member; transport needs declared data (L58).",
             passed, dict(max_metric_difference=f_(worst_metric), latent_generator_gap=f_(lift_gap)), "FALSIFIED-naive")


ATTACKS = [QS01_classical, QS02_monotone_gate, QS03_estimation_selects_SLD, QS04_stein_selects_BKM,
           QS05_chernoff_selects_WY, QS06_reconstruction, QS07_resolution, QS08_wall, QS09_fubini_study, QS10_no_transport]


def run_all(seed):
    for a in ATTACKS:
        rng = np.random.default_rng([seed, ATTACKS.index(a)])
        try: a(rng)
        except Exception as ex: register(a.__name__[:4], "?", f"EXCEPTION {ex!r}", False, {}, "ERROR")


def canary(seed):
    muts = [("QS02", {"qs02_skip_bad": True}),          # no non-monotone control: the gate shows no teeth
            ("QS05", {"qs05_fixed_s": True}),         # Chernoff without optimal s: WY not recovered
            ("QS06", {"qs06_noise": 3e-2})]             # noise beyond the band: reconstruction must fail its gate
    ok = True
    for tgt, m in muts:
        RESULTS.clear(); MUT.clear(); MUT.update(m); print(f"--- canary {tgt}: {m}")
        a = next(x for x in ATTACKS if x.__name__.startswith(tgt))
        try: a(np.random.default_rng([seed, ATTACKS.index(a)])); caught = not RESULTS[-1]["passed"]
        except Exception as ex: print(f"    exception {ex!r} (not a clean catch)"); caught = False
        ok &= caught; print(f"    {'CAUGHT' if caught else 'NOT CAUGHT'}")
    MUT.clear(); print("CANARY:", "all caught" if ok else "BATTERY TOO WEAK"); return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--seed", type=int, default=20261002)
    ap.add_argument("--out", default="rg_quantum_metric_results.json"); ap.add_argument("--canary", action="store_true")
    a = ap.parse_args()
    if a.canary: sys.exit(canary(a.seed))
    t0 = time.time(); print(f"RG quantum metric selection battery, seed {a.seed}\n"); run_all(a.seed)
    n = sum(r["passed"] for r in RESULTS)
    summ = dict(seed=a.seed, n_checks=len(RESULTS), n_pass=n, runtime_s=round(time.time()-t0, 1))
    json.dump(dict(summary=summ, results=RESULTS), open(a.out, "w"), indent=2,
              default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print(f"\n{n}/{len(RESULTS)} pass."); sys.exit(0 if n == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
