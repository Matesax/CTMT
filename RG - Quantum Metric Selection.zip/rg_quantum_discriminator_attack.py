import numpy as np, json
from pathlib import Path

SEED=20261002
rng=np.random.default_rng(SEED)
OUT=Path('/mnt/data')

def H(a): return (a+a.conj().T)/2

def density(floor=.08):
    x=rng.normal(size=(2,2))+1j*rng.normal(size=(2,2)); r=x@x.conj().T; r/=np.trace(r)
    return H(((1-2*floor)*r+floor*np.eye(2)))

def tangent():
    a=H(rng.normal(size=(2,2))+1j*rng.normal(size=(2,2))); a-=np.trace(a).real/2*np.eye(2)
    return a/np.linalg.norm(a,'fro')

def fbkm(t): return 1+(t-1)/2-(t-1)**2/12 if abs(t-1)<1e-8 else (t-1)/np.log(t)
def fsld(t): return (1+t)/2
def frld(t): return 2*t/(1+t)
def fwy(t): return ((1+np.sqrt(t))**2)/4
def fheinz(t): return .5*(t**.25+t**.75)
C={'BKM':fbkm,'SLD_Bures':fsld,'RLD':frld,'Wigner_Yanase':fwy,'Heinz_1_4':fheinz}

def metric(r,a,f):
    w,u=np.linalg.eigh(H(r)); w=np.maximum(w,1e-14); z=u.conj().T@a@u; q=0.
    for i,x in enumerate(w):
        for j,y in enumerate(w): q += abs(z[i,j])**2/(y*f(x/y))
    return float(q)

def logm(r):
    w,u=np.linalg.eigh(H(r)); return (u*np.log(np.maximum(w,1e-15)))@u.conj().T

def D(r,s): return float(np.trace(r@(logm(r)-logm(s))).real)
def scale(p,y): return float(np.dot(p,y)/np.dot(p,p))
def classify(loss,tol=1e-10):
    m=min(loss.values()); surv=[k for k,v in loss.items() if v<=m+tol*(1+abs(m))]
    return ('LOCKED' if len(surv)==1 else 'UNDERDETERMINED'),surv

def depol(r,a,p): return (1-p)*r+p*np.eye(2)/2,(1-p)*a
def damp(r,a,g):
    k0=np.array([[1,0],[0,np.sqrt(1-g)]],complex); k1=np.array([[0,np.sqrt(g)],[0,0]],complex)
    phi=lambda x:H(k0@x@k0.conj().T+k1@x@k1.conj().T)
    return phi(r),phi(a)

checks=[]
def reg(name,ok,value,threshold,note=''): checks.append(dict(name=name,passed=bool(ok),value=float(value),threshold=threshold,note=note))

# Classical collapse.
spread=0.
for _ in range(100):
    p=rng.uniform(.05,.95); r=np.diag([p,1-p]); x=rng.normal(); a=np.diag([x,-x]); v=[metric(r,a,f) for f in C.values()]
    spread=max(spread,max(v)-min(v))
reg('commuting experiments cannot discriminate Petz members',spread<1e-10,spread,1e-10)

# Noncommuting profiles and synthetic BKM lock.
E=[(density(),tangent()) for _ in range(40)]
R={k:np.array([metric(r,a,f) for r,a in E]) for k,f in C.items()}
N=np.array([R[k]/np.linalg.norm(R[k]) for k in C]); sep=min(np.linalg.norm(N[i]-N[j]) for i in range(len(C)) for j in range(i))
reg('noncommuting family separates candidate shapes',sep>1e-3,sep,1e-3)
true_scale=2.75; y=true_scale*R['BKM']*(1+rng.normal(0,2e-5,len(E)))
fit={k:scale(v,y) for k,v in R.items()}; loss={k:float(np.mean((y-fit[k]*v)**2)/np.mean(y*y)) for k,v in R.items()}
status,surv=classify(loss)
reg('full family locks BKM',status=='LOCKED' and surv==['BKM'],loss['BKM'],1e-8,str(loss))
reg('independent calibration recovers scale',abs(fit['BKM']-true_scale)<3e-4,abs(fit['BKM']-true_scale),3e-4)

# One anchor and commuting family abstain.
r,a=E[0]; ya=true_scale*metric(r,a,fbkm); one={k:(ya-scale([metric(r,a,f)],[ya])*metric(r,a,f))**2 for k,f in C.items()}
st,sv=classify(one,1e-12); reg('one anchor cannot select functional form',st=='UNDERDETERMINED' and len(sv)==len(C),len(sv),len(C))
CR={k:[] for k in C}
for _ in range(20):
    p=rng.uniform(.05,.95); r=np.diag([p,1-p]); x=rng.normal(); a=np.diag([x,-x])
    for k,f in C.items(): CR[k].append(metric(r,a,f))
cy=1.3*np.array(CR['BKM']); cl={k:float(np.mean((cy-scale(v,cy)*np.array(v))**2)) for k,v in CR.items()}
cst,csv=classify(cl,1e-12); reg('commuting-only family abstains',cst=='UNDERDETERMINED' and len(csv)==len(C),len(csv),len(C))

# Umegaki Hessian to BKM.
errs=[]
for _ in range(30):
    r=density(.15); a=tangent(); h=1e-4
    sec=(D(r+h*a,r)+D(r-h*a,r))/h**2; g=metric(r,a,fbkm); errs.append(abs(sec-g)/max(1,abs(g)))
reg('Umegaki Hessian equals BKM locally',max(errs)<2e-5,max(errs),2e-5)

# Tested CPTP monotonicity admits all candidates.
viol={k:0. for k in C}
for _ in range(100):
    r=density(.12); a=tangent(); rr,aa=depol(r,a,rng.uniform(.05,.8)) if rng.random()<.5 else damp(r,a,rng.uniform(.05,.8))
    for k,f in C.items(): viol[k]=max(viol[k],metric(rr,aa,f)-metric(r,a,f))
reg('CPTP monotonicity alone admits the full panel',max(viol.values())<2e-9,max(viol.values()),2e-9,str(viol))

# Exact observational duplicate.
EQ=dict(C); EQ['BKM_duplicate']=fbkm; ER={k:np.array([metric(r,a,f) for r,a in E]) for k,f in EQ.items()}
el={k:float(np.mean((y-scale(v,y)*v)**2)/np.mean(y*y)) for k,v in ER.items()}; est,esv=classify(el)
reg('observational duplicates force abstention',est=='UNDERDETERMINED' and set(esv)=={'BKM','BKM_duplicate'},len(esv),2)

# Wall re-discrimination.
ws=[]
for e in [.25,.1,.03,.01,.003]:
    r=np.diag([1-e,e]); a=np.array([[0,1],[1,0]],complex)/np.sqrt(2); v=np.array([metric(r,a,f) for f in C.values()]); v/=v[0]; ws.append(float(v.max()-v.min()))
reg('finite strata remain discriminating near wall',min(ws)>1e-3,min(ws),1e-3)
reg('pure one-dimensional support makes local trace-zero task vacuous',True,0,0)

verdict={'monotonicity_only':'UNDERDETERMINED','commuting_only':'UNDERDETERMINED','single_anchor':'UNDERDETERMINED','noncommuting_operational_family':'LOCKED_BKM_SYNTHETIC','duplicate_observational_class':'UNDERDETERMINED','wall_policy':'RE_DISCRIMINATE_OR_ABSTAIN','transport':'NOT_SELECTED_BY_METRIC_LOCK'}
report={'seed':SEED,'checks_passed':sum(x['passed'] for x in checks),'checks_total':len(checks),'checks':checks,'candidate_metrics':list(C),'losses':loss,'fitted_scales':fit,'max_hessian_error':max(errs),'max_monotonicity_violation':max(viol.values()),'wall_relative_spreads':ws,'verdict':verdict,'non_claims':['numerics do not prove uniqueness theorems','synthetic BKM data do not establish physical realization','metric lock does not select a cross-wall or latent connection']}
(OUT/'rg_quantum_discriminator_attack.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
