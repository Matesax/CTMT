# RG Quantum Discriminator Ladder Attack

- Seed: `20261002`
- Registered checks: **11/11 passed**

## Verdict

- **monotonicity_only**: `UNDERDETERMINED`
- **commuting_only**: `UNDERDETERMINED`
- **single_anchor**: `UNDERDETERMINED`
- **noncommuting_operational_family**: `LOCKED_BKM_SYNTHETIC`
- **duplicate_observational_class**: `UNDERDETERMINED`
- **wall_policy**: `RE_DISCRIMINATE_OR_ABSTAIN`
- **transport**: `NOT_SELECTED_BY_METRIC_LOCK`

## Registered checks

- [PASS] Q-A1 commuting experiments cannot discriminate Petz members (value=0.0, threshold=1e-10)
- [PASS] Q-B1 noncommuting task family separates candidate shapes (value=0.013438479568095919, threshold=0.001)
- [PASS] Q-C1 full noncommuting battery locks BKM (value=2.799852489154756e-10, threshold=1e-08)
- [PASS] Q-C2 calibration recovers independent scale (value=1.4404812409551937e-06, threshold=0.0003)
- [PASS] Q-D1 one anchor fixes scale but not functional form (value=5.0, threshold=5)
- [PASS] Q-D2 commuting-only family abstains (value=5.0, threshold=5)
- [PASS] Q-E1 Umegaki Hessian locks to BKM locally (value=3.996453641410855e-08, threshold=2e-05)
- [PASS] Q-F1 tested CPTP monotonicity admits whole Petz panel (value=0.0, threshold=2e-09)
- [PASS] Q-G1 observationally equivalent candidates force abstention (value=2.0, threshold=2)
- [PASS] Q-H1 walls require re-discrimination rather than component transport (value=0.30341307554227903, threshold=0.001)
- [PASS] Q-H2 rank-changing wall can make metric lock vacuous (value=0.0, threshold=0)

## Interpretation

- CPTP monotonicity is a family gate, not a selector.
- Commuting experiments and a single calibration anchor cannot identify the Petz functional form.
- A diverse noncommuting task family can identify BKM when its measured response is genuinely BKM-generated.
- Umegaki relative entropy has the BKM quadratic Hessian in the finite full-rank tests.
- Exact observational duplicates remain indistinguishable by construction.
- At support/rank walls, re-run the discriminator on the wall stratum; do not transport arbitrary metric components.
- None of these tests selects a latent or cross-wall connection.