# RG - Quantum Metric Selection: battery QS01-QS10

    python3 rg_quantum_metric_attack.py            # seed 20261002
    python3 rg_quantum_metric_attack.py --canary   # QS02, QS05, QS06 sabotaged; each must fail

10/10 on seeds 20261002, 1, 42, 777, 2026; canary 3/3. Task lock (SLD / BKM / WY), nonparametric identification of
the Petz function, resolution bands, wall specialization iff f(0) > 0, no transport from metric selection.
