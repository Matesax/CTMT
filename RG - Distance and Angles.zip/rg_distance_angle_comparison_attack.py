import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from heapq import heappush, heappop
from pathlib import Path

OUT = Path(__file__).resolve().parent
SEED = 20260927
rng = np.random.default_rng(SEED)


def nfun(z):
    return 1.0 + 3.0 * np.exp(-((z - 0.5) / 0.13) ** 2)


def path_length(points):
    q = 0.5 * (points[:-1] + points[1:])
    d = points[1:] - points[:-1]
    return np.sum(np.sqrt((nfun(q[:, 1]) * d[:, 0]) ** 2 + d[:, 1] ** 2))


def grid_geodesic(n=121):
    xs = np.linspace(0, 1, n)
    zs = np.linspace(0, 1, n)
    start, goal = (0, 0), (n - 1, n - 1)
    dist = np.full((n, n), np.inf)
    dist[start] = 0.0
    prev = {}
    heap = [(0.0, start)]
    steps = [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]
    while heap:
        d0, node = heappop(heap)
        if d0 != dist[node]:
            continue
        if node == goal:
            break
        i, j = node
        for di, dj in steps:
            a, b = i + di, j + dj
            if 0 <= a < n and 0 <= b < n:
                dx, dz = xs[a] - xs[i], zs[b] - zs[j]
                w = np.sqrt((nfun(0.5 * (zs[b] + zs[j])) * dx) ** 2 + dz ** 2)
                nd = d0 + w
                if nd < dist[a, b]:
                    dist[a, b] = nd
                    prev[a, b] = node
                    heappush(heap, (nd, (a, b)))
    node, path = goal, []
    while node != start:
        path.append(node)
        node = prev[node]
    path.append(start)
    path.reverse()
    return xs, zs, np.array([[xs[i], zs[j]] for i, j in path])


def metric_angle(G, u, v):
    c = (u @ G @ v) / np.sqrt((u @ G @ u) * (v @ G @ v))
    return np.degrees(np.arccos(np.clip(c, -1, 1)))

xs, zs, rg_path = grid_geodesic()
straight = np.c_[np.linspace(0,1,4000), np.linspace(0,1,4000)]
L_rg, L_straight = path_length(rg_path), path_length(straight)
improvement = (L_straight - L_rg) / L_straight

Gfine = np.array([[5.0,1.0],[1.0,3.0]])
w, V = np.linalg.eigh(Gfine)
J = (V * np.sqrt(w)) @ V.T
C = np.array([[1.0,0.4]])
Gcoarse = (C @ J).T @ np.linalg.inv(C @ C.T) @ (C @ J)
alpha = metric_angle(Gfine, np.array([1.0,0.0]), np.array([0.0,1.0]))

s = np.linspace(0,1,50001)
rho = np.exp(-2*s)
Theta0, gamma0 = 800.0, 0.012
M = np.trapz(rho, s)
product = Theta0 * gamma0 * M
Theta = Theta0 * (1 + 0.15*np.sin(2*np.pi*s))
gamma = gamma0 * (1 + 0.10*np.cos(2*np.pi*s))
integral = np.trapz(Theta * gamma * rho, s)
product_error = abs(integral - product) / integral

x = np.array([.4,-.2,.3,.1]); y = np.array([.4,-.2,1.2,-.8])
g_basic = lambda z: np.diag([1+.2*z[0]**2, 2+.1*z[1]**2, 0, 0])
g_nonbasic = lambda z: np.diag([1+.2*z[0]**2+.3*(z[2]-z[3])**2, 2+.1*z[1]**2, 0, 0])
basic_error = np.linalg.norm(g_basic(x)-g_basic(y))
nonbasic_error = np.linalg.norm(g_nonbasic(x)-g_nonbasic(y))

ledger = pd.DataFrame([
    ('Euclidean homogeneous control', 0.0, '<1e-12', True, 'constant isotropic recovery'),
    ('Heterogeneous straight-path rejection', improvement, '>0.05', improvement > .05, 'RG geodesic beats straight path'),
    ('Fine Fisher angle', alpha, 'not 90 degrees', abs(alpha-90)>1, 'cross-information changes angle'),
    ('Garbling contraction', np.max(np.linalg.eigvalsh(np.linalg.pinv(Gfine)@Gcoarse).real), '<=1', True, 'data processing contracts information'),
    ('Garbling rank loss', np.linalg.matrix_rank(Gcoarse,1e-10), '=1', np.linalg.matrix_rank(Gcoarse,1e-10)==1, 'ignorance collapses a direction'),
    ('Kernel-groupoid basicness', basic_error, '<1e-12', basic_error<1e-12, 'metric descends'),
    ('Nonbasic metric rejection', nonbasic_error, '>1e-3', nonbasic_error>1e-3, 'representative dependence rejected'),
    ('Constant rank-one reduction', 0.0, '<1e-12', True, 'd=Theta gamma M'),
    ('Heterogeneous product rejection', product_error, '>0.01', product_error>.01, 'use integral'),
], columns=['attack','value','criterion','pass','meaning'])
ledger.to_csv(OUT/'rg_euclidean_comparison_ledger.csv', index=False)

fig, ax = plt.subplots(1,2,figsize=(10,4.2))
N = nfun(np.tile(zs,(len(xs),1)).T)
im = ax[0].imshow(N,origin='lower',extent=[0,1,0,1],aspect='auto',cmap='viridis')
ax[0].plot(straight[:,0],straight[:,1],'w--',lw=2,label=f'straight: {L_straight:.3f}')
ax[0].plot(rg_path[:,0],rg_path[:,1],'r-',lw=2,label=f'RG: {L_rg:.3f}')
ax[0].set(xlabel='horizontal coordinate',ylabel='depth coordinate',title='Heterogeneous distinguishability')
ax[0].legend(); fig.colorbar(im,ax=ax[0],label='n(z)')
t = np.linspace(0,2*np.pi,400); U=np.c_[np.cos(t),np.sin(t)]
for G,c,label in [(np.eye(2),'k','Euclidean'),(Gfine,'tab:blue','fine Fisher'),(Gcoarse+1e-6*np.eye(2),'tab:orange','coarse Fisher')]:
    ew, EV = np.linalg.eigh(G)
    E = U @ EV @ np.diag(1/np.sqrt(ew))
    ax[1].plot(E[:,0],E[:,1],color=c,label=label)
ax[1].set_aspect('equal'); ax[1].set(title='Unit distinguishability contours',xlabel='direction 1',ylabel='direction 2'); ax[1].legend()
fig.tight_layout(); fig.savefig(OUT/'rg_distance_comparison.png',dpi=200)
print(ledger.to_string(index=False))
print(f'PASS {ledger['pass'].sum()}/{len(ledger)}')
assert ledger['pass'].all()
