"""RG distance, quotient and groupoid characterization attack.
Deterministic synthetic falsification battery. Python 3 + NumPy/Pandas.
"""
import numpy as np
import pandas as pd
SEED=20260927
rng=np.random.default_rng(SEED)
def fisher(J,S): return J.T@np.linalg.inv(S)@J
def eff(F,p):
 A=F[:p,:p]; B=F[:p,p:]; C=F[p:,p:]
 return A-B@np.linalg.pinv(C)@B.T
def angle(G,u,v): return np.arccos(np.clip((u@G@v)/np.sqrt((u@G@u)*(v@G@v)),-1,1))
def plen(P,g):
 return sum(np.sqrt(max((b-a)@g((a+b)/2)@(b-a),0)) for a,b in zip(P[:-1],P[1:]))
R=[]
def test(n,v,c,p,msg): R.append((n,v,c,bool(p),msg))
J=np.array([[1.,0,0,0],[0,1,0,0],[0,0,1,1]]); F=fisher(J,np.diag([.04,.09,.16])); z=np.array([0,0,1.,-1])
test('vertical annihilation',z@F@z,'<1e-12',z@F@z<1e-12,'fibre has zero length')
x=np.array([.4,-.2,.3,.1]); y=np.array([.4,-.2,1.2,-.8])
g=lambda x:np.diag([1+.2*x[0]**2,2+.1*x[1]**2,0,0]); gn=lambda x:np.diag([1+.2*x[0]**2+.3*(x[2]-x[3])**2,2+.1*x[1]**2,0,0])
test('basic descent',np.linalg.norm(g(x)[:2,:2]-g(y)[:2,:2]),'<1e-12',np.allclose(g(x),g(y)),'representative independent')
test('nonbasic rejection',np.linalg.norm(gn(x)[:2,:2]-gn(y)[:2,:2]),'>1e-3',not np.allclose(gn(x),gn(y)),'fibre dependent metric rejected')
J=np.array([[1.,0],[.8,1],[.2,0]]); F=fisher(J,np.diag([.04,.04,.25])); Ie=eff(F,1)[0,0]
test('nuisance contraction',Ie/F[0,0],'<=1',Ie<=F[0,0]+1e-12,'use efficient Fisher')
s=np.linspace(0,1,20001); rho=np.exp(-2*s); T0=800.; ga=.012; M=np.trapz(rho,s); exact=np.trapz(T0*ga*rho,s)
test('rank-one reduction',abs(exact-T0*ga*M)/(T0*ga*M),'<1e-10',np.isclose(exact,T0*ga*M),'d=Theta gamma M only for constant factor')
Tv=T0*(1+.15*np.sin(2*np.pi*s)); gv=ga*(1+.1*np.cos(2*np.pi*s)); general=np.trapz(Tv*gv*rho,s)
test('variable-factor rejection',abs(general-T0*ga*M)/general,'>1e-3',abs(general-T0*ga*M)/general>1e-3,'use integral in heterogeneous media')
G=np.array([[4.,1.2],[1.2,2.]]); test('angle rank two',np.degrees(angle(G,np.array([1.,0]),np.array([0.,1.]))),'finite',np.linalg.matrix_rank(G)==2,'scores define angle')
G1=np.outer([2.,1.],[2.,1.]); test('rank-one no angle',np.linalg.eigvalsh(G1)[0],'<1e-12',np.linalg.matrix_rank(G1)==1,'delay alone insufficient')
def gm(q):
 n=1+3*np.exp(-((q[1]-.5)/.13)**2); return np.diag([n*n,1.])
t=np.linspace(0,1,1200); straight=np.c_[t,t]; Ls=plen(straight,gm); cand=[]
for wx in np.linspace(.05,.95,37):
 for wz in np.linspace(.02,.98,49):
  p=np.vstack([np.c_[np.linspace(0,wx,600),np.linspace(0,wz,600)],np.c_[np.linspace(wx,1,600),np.linspace(wz,1,600)][1:]])
  cand.append((plen(p,gm),wx,wz))
b=min(cand); test('Euclidean failure',(Ls-b[0])/Ls,'>1%',b[0]<.99*Ls,'heterogeneous Fisher geodesic bends')
# Data processing / ignorance contraction
Gf=np.array([[5.,1.],[1.,3.]]); w,V=np.linalg.eigh(Gf); J=(V*np.sqrt(w))@V.T; C=np.array([[1.,.4]]); Gc=(C@J).T@np.linalg.inv(C@C.T)@(C@J)
rat=[]
for _ in range(10000):
 v=rng.normal(size=2); rat.append((v@Gc@v)/(v@Gf@v))
test('ignorance contraction',max(rat),'<=1',max(rat)<=1+1e-10,'coarse graining contracts distance')
test('ignorance zero direction',np.linalg.eigvalsh(Gc)[0],'<1e-12',np.linalg.eigvalsh(Gc)[0]<1e-12,'fibres enlarge')
# Coordinate invariance
q=np.linspace(.2,1.4,20001); Lq=np.trapz(np.sqrt(1+q*q),q); r=q**3; gr=(1+q*q)/(3*q*q)**2; Lr=np.trapz(np.sqrt(gr),r)
test('coordinate invariance',abs(Lq-Lr)/Lq,'<1e-7',abs(Lq-Lr)/Lq<1e-7,'covariant metric length universal')

# Boundary attack: scale-stable eigenvalue change plus eigenspace rotation
Tb=np.linspace(.005,.080,1501); Tb0=.030
sb=1/(1+np.exp(-(Tb-Tb0)/.0015)); l1=25*np.ones_like(Tb); l2=1e-7+8*sb; ph=.7*sb
Mb=[]
for aa,bb,pp in zip(l1,l2,ph):
 Rm=np.array([[np.cos(pp),-np.sin(pp)],[np.sin(pp),np.cos(pp)]])
 Mb.append(Rm@np.diag([aa,bb])@Rm.T)
Mb=np.array(Mb); ev=np.linalg.eigvalsh(Mb)
dlam=np.abs(np.gradient(ev[:,0],Tb))/(np.ptp(ev[:,0])+1e-12)
vv=np.array([np.linalg.eigh(mm)[1][:,-1] for mm in Mb]); rr=np.zeros_like(Tb); dt=Tb[1]-Tb[0]
rr[1:]=np.arccos(np.clip(np.abs(np.sum(vv[1:]*vv[:-1],axis=1)),-1,1))/dt; rr/=np.max(rr)+1e-12
bestT=Tb[np.argmax(dlam/(np.max(dlam)+1e-12)+rr)]
test('boundary localization',abs(bestT-Tb0),'<0.004 s',abs(bestT-Tb0)<.004,'rank/conditioning/eigenspace transition')

df=pd.DataFrame(R,columns=['attack','value','criterion','pass','interpretation'])
print(df.to_string(index=False)); print(f"PASS {df['pass'].sum()}/{len(df)}")
