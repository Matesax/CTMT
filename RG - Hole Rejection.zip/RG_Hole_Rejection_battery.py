import numpy as np
np.set_printoptions(precision=3,suppress=True)
rng=np.random.default_rng(0)

def fisher_health(J, Sigma, c, tau=1.0):
    """RG healthbar for target functional g=c.theta: resolved fraction of c under
       the NOISE-AWARE Fisher F=J^T Sigma^{-1} J, plus the irreducible (hole) variance."""
    F=J.T@np.linalg.inv(Sigma)@J
    w,U=np.linalg.eigh(F)                      # eigenvectors = resolution axes
    c=c/np.linalg.norm(c)
    coeff=(U.T@c)**2
    resolved=w>=tau
    H=coeff[resolved].sum()                    # fraction of target in resolved sector  [0,1]
    # min-variance estimate variance on resolved sector; hole => +inf if attempted
    var_resolved=np.sum(coeff[resolved]/w[resolved]) if resolved.any() else np.inf
    hole_exposure=coeff[~resolved].sum()
    return H, var_resolved, hole_exposure

print("="*70); print("H1  Good global fit, UNRESOLVED target  (R^2 misses it)"); print("="*70)
m,p=300,4
s=np.array([10.,6.,3.,0.02])                   # last direction barely observed
Uo=np.linalg.qr(rng.standard_normal((m,p)))[0]; Vo=np.linalg.qr(rng.standard_normal((p,p)))[0]
J=Uo@np.diag(s)@Vo.T
theta=rng.standard_normal(p); sig=0.12; y=J@theta+sig*rng.standard_normal(m)
Sig=sig**2*np.eye(m)
th_hat=np.linalg.lstsq(J,y,rcond=None)[0]
R2=1-((y-J@th_hat)**2).sum()/((y-y.mean())**2).sum()
c_weak=Vo[:,3]; c_strong=Vo[:,0]
Hw,vw,hw=fisher_health(J,Sig,c_weak); Hs,vs,hs=fisher_health(J,Sig,c_strong)
print(f"  global fit R^2 = {R2:.4f}   <- naive verdict: 'great, trust the fit'")
print(f"  target = STRONG combo : healthbar H={Hs:.2f}  (resolved) -> ACCEPT")
print(f"  target = WEAK   combo : healthbar H={Hw:.2f}  hole-exposure={hw:.2f} -> REJECT")
print("  => same fit, R^2 high, but RG rejects the weak target the data do not constrain.")

print("\n"+"="*70); print("H2  Well-conditioned map, NOISE kills the target  (cond(J) misses it)"); print("="*70)
J2=np.linalg.qr(rng.standard_normal((m,p)))[0]  # orthonormal cols -> cond(J)=1
c=rng.standard_normal(p); c/=np.linalg.norm(c)
wdir=J2@c; wdir/=np.linalg.norm(wdir)           # obs direction carrying info about c
big=1e4
Sig2=np.eye(m)+big*np.outer(wdir,wdir)          # huge noise exactly where c is read out
condJ=np.linalg.cond(J2)
H2,_,hole2=fisher_health(J2,Sig2,c,tau=1.0)
print(f"  cond(J) = {condJ:.2f}   <- naive verdict: 'well-posed, safe'")
print(f"  RG healthbar for target c: H={H2:.2f}  hole-exposure={hole2:.2f} -> REJECT")
print("  => the map is perfectly conditioned; the NOISE makes c unidentifiable. RG sees it, cond(J) can't.")

print("\n"+"="*70); print("H4  Orient in similarity: pick the transportable source  (raw stats mislead)"); print("="*70)
d=6
def make_domain(coupling_dir, marg_cov, n=4000):
    L=np.linalg.cholesky(marg_cov); X=rng.standard_normal((n,d))@L.T
    y=X@coupling_dir+0.3*rng.standard_normal(n)
    return X,y
# two reference sources and a target
dir1=np.zeros(d); dir1[0]=1.0                    # R1 couples to feature 0
dir2=np.zeros(d); dir2[3]=1.0                    # R2 couples to feature 3
M_a=np.eye(d); M_b=np.diag([1,1,1,5.,5,5])       # two different marginal covariances
X_R1,y_R1=make_domain(dir1,M_a)
X_R2,y_R2=make_domain(dir2,M_b)
# TARGET: coupling like R1 (so R1 is the right source), but MARGINALS like R2 (so naive picks R2)
X_T,y_T=make_domain(dir1*0.95+0.05*rng.standard_normal(d), M_b, n=60)   # small noisy sample
# fit each reference, transport to target
b1=np.linalg.lstsq(X_R1,y_R1,rcond=None)[0]; b2=np.linalg.lstsq(X_R2,y_R2,rcond=None)[0]
err1=np.sqrt(np.mean((X_T@b1-y_T)**2)); err2=np.sqrt(np.mean((X_T@b2-y_T)**2))
# naive similarity: marginal covariance distance (target vs each ref)
cov_T=np.cov(X_T.T)
naive1=np.linalg.norm(cov_T-np.cov(X_R1.T)); naive2=np.linalg.norm(cov_T-np.cov(X_R2.T))
# RG similarity: alignment of the resolved/coupling DIRECTION (gauge invariant), from the small T sample
bT=np.linalg.lstsq(X_T,y_T,rcond=None)[0]; bT/=np.linalg.norm(bT)
align1=abs(bT@(b1/np.linalg.norm(b1))); align2=abs(bT@(b2/np.linalg.norm(b2)))
print(f"  transport error:      R1->T = {err1:.3f}   R2->T = {err2:.3f}   (R1 is the safe source)")
print(f"  NAIVE marginal match: R1 dist={naive1:.2f}  R2 dist={naive2:.2f}  -> picks {'R1' if naive1<naive2 else 'R2'} (WRONG)")
print(f"  RG coupling-alignment:R1={align1:.2f}  R2={align2:.2f}          -> picks {'R1' if align1>align2 else 'R2'} (correct)")
