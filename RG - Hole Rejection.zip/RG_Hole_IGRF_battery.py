"""RG hole-rejection healthbar on REAL data: IGRF-13 vs IGRF-14 Gauss coefficients.
Two model generations give an empirical 'hole' (model-revision disagreement) that grows
with spherical-harmonic degree; the healthbar then correctly flags the dangerous fit of
downward-continuing the field to the core-mantle boundary. Needs igrf13coeffs.txt,
igrf14coeffs.txt in the same directory."""
import numpy as np
def load(path):
    epochs=None; rows=[]
    for ln in open(path):
        t=ln.split()
        if not t: continue
        if t[0]=='g/h':
            epochs=[(float(x) if x.replace('.','').isdigit() else None) for x in t[3:]]; continue
        if t[0] in ('g','h'):
            rows.append((t[0],int(t[1]),int(t[2]),[float(x) for x in t[3:]]))
    return epochs,rows
e13,r13=load('igrf13coeffs.txt'); e14,r14=load('igrf14coeffs.txt')
i13=e13.index(2020.0); i14=e14.index(2020.0)               # common epoch: pure model revision
d13={(c,n,m):v[i13] for c,n,m,v in r13}; d14={(c,n,m):v[i14] for c,n,m,v in r14}
nmax=13; degs=np.arange(1,nmax+1)
Rn=np.zeros(nmax+1); Dn=np.zeros(nmax+1)                    # Lowes power & revision power per degree
for k in set(d13)&set(d14):
    c,n,m=k
    Rn[n]+=(n+1)*d14[k]**2; Dn[n]+=(n+1)*(d14[k]-d13[k])**2
Rns=np.array([Rn[n] for n in degs]); Dns=np.array([Dn[n] for n in degs])
rel=np.sqrt(Dns/Rns)
print("REAL DATA (IGRF-13 vs IGRF-14 @ 2020): resolved->hole gradient over degree")
for n in degs: print("  deg %2d  field %.2e nT^2   rel model-revision error %.2e"%(n,Rns[n-1],rel[n-1]))
print("  low-degree(1-3) mean err=%.1e  high-degree(11-13) mean err=%.1e  -> %.0fx larger (the hole)"%(
    rel[:3].mean(),rel[10:].mean(),rel[10:].mean()/rel[:3].mean()))

# healthbar = resolved-power fraction; degree resolved if model-revision amplitude error < 1%
resolved = rel < 0.01
a=6371.2; c=3485.0
print("\nDANGEROUS FIT test: downward continuation surface -> CMB (amplifies high degrees)")
for r in [a, 0.75*a+0.25*c, 0.5*a+0.5*c, c]:
    w=((a/r)**2)**(degs+2)*Rns                             # per-degree POWER at radius r
    H=w[resolved].sum()/w.sum()
    print("  r=%.0f km  healthbar H=%.3f   power-in-hole=%.1f%%"%(r,H,100*w[~resolved].sum()/w.sum()))
print("  => surface H~1.00 (trust); CMB H~0.84 (16%% of power in the unresolved hole -> flagged).")
print("     The healthbar reproduces the known geomagnetic fact that CMB field maps degrade")
print("     toward high degree, from a domain-agnostic resolved/hole power budget.")
