"""Non-spacetime attractors and the source of gravity: what can be locked. Deterministic (seeded) and exact where possible.
G1 balance: on a relational network with local pairwise exchange, sum of node loads is conserved and changes only by divergence of edge fluxes
G2 operator uniqueness: a nearest-neighbour linear response that is shift-blind (gauge), reciprocal and isotropic is c x (graph Laplacian);
   its continuum limit is c h^2 nabla^2 (symbolic)
G3 constraint attractor: on a coordinate-free graph, relaxation phi' = -(L phi - kappa (rho - mean rho)) converges from every initial state to one
   Poisson solution (unique up to a constant, the gauge null), at the rate of the spectral gap
G4 decisive test: same initial geometry, two sources, same rule -> attractors differ by kappa L^+ (rho_A - rho_B) exactly; coupling off -> no difference
G5 inverse square from a 3-D network: the point-source attractor decays as 1/r (Green's function), i.e. force ~ 1/r^2
G6 scalar is not enough: a conformally flat (scalar) metric does not bend light; GR's gamma = 1 does (1.751 arcsec); Cassini gamma - 1 = (2.1 +- 2.3)e-5
G7 scale attractor: for a weak plane wave the R^2 / EH action ratio is (l k)^2 -> 0 at large scales (power counting)
G8 consistency: the Einstein tensor of a general static spherical metric is identically divergence-free (contracted Bianchi, symbolic)
G9 no-attractor for conservative dynamics: symplectic graph wave equation conserves energy and the difference energy (Liouville)
G10 linearized Einstein operator annihilates pure gauge (spin-2 gauge invariance, symbolic)
Run: python rg_gravity_source.py   (numpy, scipy, sympy)
"""
import json, math, hashlib, pathlib
import numpy as np
import scipy.sparse as sps
import scipy.sparse.linalg as spla
import sympy as sp
RES = {}
def must(c, m):
    if not c: raise AssertionError(m)
rng = np.random.default_rng(20261109)

# a coordinate-free relational network: random 4-regular-ish graph built from a seeded edge list
n = 300
edges = set()
perm = rng.permutation(n)
for i in range(n): edges.add(tuple(sorted((perm[i], perm[(i + 1) % n]))))              # a ring ensures connectivity
while len(edges) < 2 * n:
    a, b = rng.integers(0, n, 2)
    if a != b: edges.add(tuple(sorted((int(a), int(b)))))
edges = sorted(edges)
B = sps.lil_matrix((len(edges), n))
for k, (a, b) in enumerate(edges): B[k, a] = -1; B[k, b] = 1
B = B.tocsr(); L = (B.T @ B).tocsr()                                                  # graph Laplacian = B^T B

# G1 balance
load = rng.uniform(0, 1, n); total0 = load.sum()
for step in range(200):
    flux = 0.05 * (B @ load)                                                         # exchange along edges driven by differences
    load = load + B.T @ flux * (-1)
must(abs(load.sum() - total0) < 1e-10, "G1")
RES["G1"] = dict(claim="Local pairwise exchange conserves the total load exactly; changes are divergences of edge fluxes (discrete balance law)",
                 status="PROVED (B^T has zero column sums) + executed", total_drift=float(abs(load.sum() - total0)))
# G2 operator uniqueness on the square lattice
a0, a1, a2, a3, a4, hh = sp.symbols("a0 a1 a2 a3 a4 h")
# shift-blind: a0 + a1 + a2 + a3 + a4 = 0 ; isotropic (D4): a1 = a2 = a3 = a4
sol = sp.solve([a0 + a1 + a2 + a3 + a4, a1 - a2, a2 - a3, a3 - a4], [a0, a2, a3, a4], dict=True)[0]
xx, yy = sp.symbols("x y"); f = sp.Function("f")
stencil = (a1 * (f(xx + hh, yy) + f(xx - hh, yy) + f(xx, yy + hh) + f(xx, yy - hh)) + sol[a0] * f(xx, yy))
taylor = sp.series(stencil.subs(a1, 1), hh, 0, 4).removeO()
lap = sp.simplify(taylor - hh ** 2 * (sp.diff(f(xx, yy), xx, 2) + sp.diff(f(xx, yy), yy, 2)))
must(sol[a0] == -4 * a1 and sp.simplify(lap) == 0, "G2")
RES["G2"] = dict(claim="Nearest-neighbour, shift-blind (only differences observable), reciprocal, isotropic linear response = c x Laplacian; continuum limit c h^2 nabla^2",
                 status="PROVED (symbolic)", stencil_centre=str(sol[a0]))
# G3 constraint attractor on the coordinate-free graph
rho = np.zeros(n); rho[[5, 77, 140]] = [3.0, 1.0, 2.0]; kappa = 1.0
def relax(phi0, rho, kappa, T=60.0, dt=0.02):
    phi = phi0.copy(); traj = []
    src = kappa * (rho - rho.mean())
    for s in range(int(T / dt)):
        phi = phi - dt * (L @ phi + src); traj.append(phi.copy())
    return phi, traj
Lpinv_src = lambda r: spla.lsqr(L, -kappa * (r - r.mean()), atol=1e-14, btol=1e-14, iter_lim=20000)[0]
phi_star = Lpinv_src(rho); phi_star -= phi_star.mean()
finals = []
for s in range(5):
    phi0 = np.random.default_rng(100 + s).normal(0, 5, n)
    phiT, _ = relax(phi0, rho, kappa)
    finals.append(float(np.max(np.abs((phiT - phiT.mean()) - phi_star))))
lam = np.sort(np.linalg.eigvalsh(L.toarray()))
must(max(finals) < 1e-3 and lam[0] < 1e-9 and lam[1] > 0, "G3")
RES["G3"] = dict(claim="From five random initial states, relaxation converges to one Poisson solution modulo a constant (the gauge null); rate = spectral gap",
                 status="EXECUTED (seeded)", max_deviation_from_attractor=max(finals), spectral_gap=float(lam[1]), null_eigenvalue=float(lam[0]))
# G4 decisive test
rhoA = rho.copy(); rhoB = np.zeros(n); rhoB[[20, 200]] = [4.0, 2.0]
phi0 = np.zeros(n)
pA, _ = relax(phi0, rhoA, kappa); pB, _ = relax(phi0, rhoB, kappa)
pred = Lpinv_src(rhoA) - Lpinv_src(rhoB)
diff = (pA - pA.mean()) - (pB - pB.mean())
pA0, _ = relax(phi0, rhoA, 0.0); pB0, _ = relax(phi0, rhoB, 0.0)
must(np.max(np.abs(diff - (pred - pred.mean()))) < 1e-3 and np.max(np.abs(pA0 - pB0)) < 1e-12, "G4")
RES["G4"] = dict(claim="Same initial geometry and rule, different sources: the attractors differ by kappa L^+ (rho_A - rho_B); with the coupling switched off "
                       "they do not differ (negative control)", status="EXECUTED", max_prediction_error=float(np.max(np.abs(diff - (pred - pred.mean())))),
                 control_difference=float(np.max(np.abs(pA0 - pB0))))
# G5 3-D lattice point source
N3 = 41; idx = lambda i, j, k: (i * N3 + j) * N3 + k
rows, cols, vals = [], [], []
for i in range(N3):
    for j in range(N3):
        for k in range(N3):
            c = idx(i, j, k); deg = 0
            for di, dj, dk in ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)):
                ii, jj, kk = i + di, j + dj, k + dk
                if 0 <= ii < N3 and 0 <= jj < N3 and 0 <= kk < N3:
                    rows.append(c); cols.append(idx(ii, jj, kk)); vals.append(-1.0)
                deg += 1
            rows.append(c); cols.append(c); vals.append(float(deg))                  # Dirichlet boundary (phi = 0 outside)
L3 = sps.csr_matrix((vals, (rows, cols)), shape=(N3 ** 3, N3 ** 3))
src = np.zeros(N3 ** 3); m = N3 // 2; src[idx(m, m, m)] = 1.0
phi3 = spla.spsolve(L3.tocsc(), src)
rs = np.arange(3, 10); prof = np.array([phi3[idx(m + r, m, m)] for r in rs])
Xf = np.column_stack([1.0 / rs, np.ones(len(rs))]); coef, res_, _, _ = np.linalg.lstsq(Xf, prof, rcond=None)
fit_err = float(np.max(np.abs(Xf @ coef - prof)) / np.max(prof)); slope = float(coef[0])
must(abs(coef[0] * 4 * math.pi - 1) < 0.08 and fit_err < 0.01, f"G5 {coef} {fit_err}")
RES["G5"] = dict(claim="The point-source attractor of a 3-D network is a/r + const with a = 1/(4 pi) (lattice Green's function), so the force decays as r^-2",
                 status="EXECUTED (41^3 lattice, Dirichlet box; fit a/r + b on r = 3..9)", a_times_4pi=float(coef[0] * 4 * math.pi), box_offset_b=float(coef[1]),
                 max_relative_fit_error=fit_err)
# G6 scalar vs tensor
GM = 1.32712440018e20; c = 299792458.0; R = 6.957e8; arcsec = 206264.806
defl = lambda gamma: (1 + gamma) * 2 * GM / (c ** 2 * R) * arcsec
RES["G6"] = dict(claim="A scalar (conformally flat) coupling g = (1 + 2 phi) eta leaves null geodesics unbent (conformal invariance): deflection 0 (gamma = -1); "
                       "GR gamma = 1 gives 1.751 arcsec; Cassini: gamma - 1 = (2.1 +- 2.3)e-5. The scalar attractor cannot be the whole source of GR",
                 status="PROVED (conformal invariance of null curves) + computed", deflection_scalar=defl(-1.0), deflection_GR=defl(1.0))
must(defl(-1.0) == 0.0 and abs(defl(1.0) - 1.751) < 0.002, "G6")
# G7 power counting
k, l, hk = sp.symbols("k ell h_k", positive=True)
EH = k ** 2 * hk ** 2; R2 = l ** 2 * k ** 4 * hk ** 2
must(sp.simplify(R2 / EH - (l * k) ** 2) == 0 and sp.limit(R2 / EH, k, 0) == 0, "G7")
RES["G7"] = dict(claim="Weak plane wave: R^2 / EH action ratio = (ell k)^2 -> 0 as k -> 0: among local diffeomorphism-invariant actions the lowest-derivative "
                       "(Einstein-Hilbert + Lambda) term is the large-scale attractor", status="PROVED (power counting)")
# G8 Bianchi for a static spherical metric
t, r, th, ph = sp.symbols("t r theta phi")
A = sp.Function("A")(r); Bf = sp.Function("B")(r)
g = sp.diag(-sp.exp(A), sp.exp(Bf), r ** 2, r ** 2 * sp.sin(th) ** 2); X = [t, r, th, ph]; gi = g.inv()
Gam = [[[sp.simplify(sum(gi[a, d] * (sp.diff(g[d, b], X[cc]) + sp.diff(g[d, cc], X[b]) - sp.diff(g[b, cc], X[d])) for d in range(4)) / 2)
         for cc in range(4)] for b in range(4)] for a in range(4)]
def Ric(b, d):
    return sp.simplify(sum(sp.diff(Gam[a][d][b], X[a]) - sp.diff(Gam[a][a][b], X[d]) +
                           sum(Gam[a][a][e] * Gam[e][d][b] - Gam[a][d][e] * Gam[e][a][b] for e in range(4)) for a in range(4)))
Rc = sp.Matrix(4, 4, lambda b, d: Ric(b, d)); Rs = sp.simplify(sum(gi[b, d] * Rc[b, d] for b in range(4) for d in range(4)))
G = sp.simplify(Rc - Rs * g / 2); Gup = sp.simplify(gi * G * gi)
div = [sp.simplify(sum(sp.diff(Gup[a, b], X[a]) + sum(Gam[a][a][e] * Gup[e, b] + Gam[b][a][e] * Gup[a, e] for e in range(4)) for a in range(4))) for b in range(4)]
must(all(d_ == 0 for d_ in div), "G8")
RES["G8"] = dict(claim="nabla_mu G^{mu nu} = 0 identically for a general static spherical metric: any source law G = kappa T forces nabla T = 0",
                 status="PROVED (symbolic)")
# G9 conservative dynamics has no attractor: graph wave equation (leapfrog, symplectic): energy conserved, distance between solutions not contracting
def wave(u0, v0, steps=4000, dt=0.05):
    u, v = u0.copy(), v0.copy(); E0 = None; Es = []
    for s_ in range(steps):
        v = v - dt * (L @ u); u = u + dt * v
        if s_ % 400 == 0: Es.append(float(0.5 * v @ v + 0.5 * u @ (L @ u)))
    return u, v, Es
ua = np.random.default_rng(7).normal(0, 1, n); ub = ua + 1e-2 * np.random.default_rng(8).normal(0, 1, n); va = np.zeros(n)
uA, vA, EA = wave(ua, va); uB, vB, EB = wave(ub, va)
def en(u, v): return float(0.5 * v @ v + 0.5 * u @ (L @ u))
d0 = en(ub - ua, va * 0); dT = en(uB - uA, vB - vA)
must(abs(EA[-1] - EA[0]) / EA[0] < 0.05 and abs(dT - d0) / d0 < 0.05, "G9")
RES["G9"] = dict(claim="Conservative (Hamiltonian) network dynamics has no attractor: the energy norm of the difference of two solutions is conserved "
                       "(Liouville). A GR-like evolution cannot pull arbitrary states to a preferred geometry; its constraints restrict, they do not attract",
                 status="PROVED (energy identity; Liouville) + executed (symplectic leapfrog)", energy_drift=abs(EA[-1] - EA[0]) / EA[0],
                 difference_energy_start=d0, difference_energy_end=dT)
# G10 the linearized Einstein operator annihilates pure gauge (spin-2 gauge invariance) on a plane-wave fixture
xs = sp.symbols("x0:4"); eta = sp.diag(-1, 1, 1, 1); kv = [1, 2, -1, 3]; zz = sum(kv[i] * xs[i] for i in range(4))
xi = [sp.Function(f"xi{i}")(zz) for i in range(4)]
xi_low = [sum(eta[i, j] * xi[j] for j in range(4)) for i in range(4)]
h = sp.Matrix(4, 4, lambda i, j: sp.diff(xi_low[i], xs[j]) + sp.diff(xi_low[j], xs[i]))
def lin_ricci(h):
    tr = sum(eta[i, i] * h[i, i] for i in range(4))
    def d(f, i): return sp.diff(f, xs[i])
    box = lambda f: sum(eta[i, i] * d(d(f, i), i) for i in range(4))
    R = sp.Matrix(4, 4, lambda m_, n_: sp.Rational(1, 2) * (sum(eta[a, a] * (d(d(h[a, n_], a), m_) + d(d(h[a, m_], a), n_)) for a in range(4))
                                                            - box(h[m_, n_]) - d(d(tr, m_), n_)))
    return R
Rlin = sp.simplify(lin_ricci(h))
must(Rlin == sp.zeros(4, 4), "G10")
RES["G10"] = dict(claim="The linearized Ricci (hence Einstein) operator annihilates pure-gauge perturbations h = d xi + d xi: the spin-2 source law needs this "
                       "gauge invariance, which forces the source to be conserved (Fierz-Pauli/Deser route, imported for the nonlinear completion)",
                  status="PROVED (symbolic plane-wave fixture with arbitrary profile functions)")
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_gravity_source_results.json").write_text(json.dumps(RES, indent=1, default=float))
for kk, v in RES.items():
    if isinstance(v, dict): print(kk, "|", v["status"])
print(RES["G3"], RES["G4"], RES["G5"])
