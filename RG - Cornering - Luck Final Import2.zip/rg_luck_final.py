#!/usr/bin/env python3
"""RG luck final: executable synthetic validation, not physical entropy certification.
Commands: selftest, freeze, tier1, bell, calibration, finish, verify.
Every main-stage file is generated under a frozen code/configuration manifest.
No non-rejection is called a proof of luck. No synthetic Bell record earns certified bits.
"""
import argparse, hashlib, itertools, json, math, os, platform, sys
from pathlib import Path
import numpy as np
import scipy
from scipy.special import betaln, gammaln
from scipy.stats import beta, binom
from scipy.optimize import linprog
from numba import njit

LN2=math.log(2.)
SOURCES=['coin','sqrt2','markov015','masked_shared','open_shared','link025',
         'anti_side','bias052','bias0505','alternating','parity_memory8','regime_switch']
GAMBLERS=['KT','CTW_own4','CTW_own8','CTW_own12','CTW_side8','KT_side_residual','lag_bank','declared_oracles']
MODELS=['quantum_iid','noisy_iid','local_iid','local_memory','hidden_signalling',
        'settings_dependent','test_flag_leak','noniid_drift','biased_settings_local']
DEFAULT={'version':'RG-luck-final-1','seed':20261028,'synthetic':True,
 'tier1_n':1048576,'tier1_replicates':3,'sources':SOURCES,'gamblers':GAMBLERS,
 'bell_n_per_model':10000000,'bell_chunk':250000,'bell_models':MODELS,'test_denominator':128,
 'calibration_replicates':4096,'calibration_n':8192,'checkpoint_stride':4096,
 'alpha_tier1':.004,'epsilon_bell':.003,'epsilon_bias_ci':.002,'epsilon_calibration_ci':.001,
 'target_bias':.005,'target_terminal_power':.99,
 'oracle_eta':.001,'oracle_list':['sqrt2_block','coin_seed','A_xor_mask_seed'],
 'filtration':'At t, A[0:t+1] and B[0:t] are available; B[t:] are not. Oracle algorithms/seeds declared before generation.',
 'null':'P(B[t]=1 | declared pre-bet information)=1/2. PRNG simulations model, not establish, this null.',
 'decisions':'Anytime individual family threshold log(records*gamblers/alpha); per-record fixed uniform gambler mixture log(records/alpha).',
 'bell_null':'Free uniform test settings and local causal outputs imply conditional test-win probability <=3/4, even with memory.',
 'entropy_policy':'Imported quantum single-round curve is a projection only. No EAT, physical provenance, trusted seed, external custody or certified extractor is implemented.',
 'sampling_policy':'Fixed declared sample sizes; no retries, seed searches, outcome-dependent exclusions, refits or threshold changes.',
 'seed_accounting':'Spot flag uses 7 ideal fair bits per round; test settings use 2 ideal bits per test. PRNG draws consume no certified physical entropy.',
 'iid_projection_policy':'Generation-only A; B generation output kept private. IID product cq state, fresh independent settings, valid theorem and causal wall are required but not certified.',
 'source_replication':'sqrt2 blocks are nonoverlapping portions of one deterministic expansion; replicas are software cases, not physical independence.',
 'certificate_scope':'Conditional statistical evidence and synthetic software validation only; no absolute or physical luck certificate.'}

def canonical(x): return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(x): return hashlib.sha256(canonical(x)).hexdigest()
def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''): h.update(chunk)
 return h.hexdigest()
def write(path,obj): Path(path).write_bytes(canonical(obj))
def read(path): return json.loads(Path(path).read_text())
def require(c,m):
 if not c: raise ValueError(m)
def rng(c,label):
 s=hashlib.sha256(f'{c["seed"]}:{label}'.encode()).digest()
 return np.random.Generator(np.random.PCG64(int.from_bytes(s[:16],'big')))
def bits(r,n): return r.integers(0,2,n,dtype=np.uint8)
def arrhash(a):
 a=np.ascontiguousarray(a)
 return hashlib.sha256(str(a.dtype).encode()+canonical(list(a.shape))+a.tobytes()).hexdigest()
def logsum(v): return float(np.logaddexp.reduce(np.asarray(v)))
def kt_count(n,k): return n*LN2+betaln(np.asarray(k)+.5,n-np.asarray(k)+.5)-betaln(.5,.5)
def power_exact(n,delta,threshold):
 lo=n//2; hi=n
 while lo<hi:
  mid=(lo+hi)//2
  if kt_count(n,mid)>=threshold: hi=mid
  else: lo=mid+1
 k=lo
 if kt_count(n,k)<threshold: return {'n':n,'power':0.,'upper_critical_count':None}
 p=.5+delta
 power=float(binom.sf(k-1,n,p)+binom.cdf(n-k,n,p))
 return {'n':n,'bias':delta,'threshold':threshold,'upper_critical_count':k,'power':power,
         'scope':'Exact binomial terminal KT power for iid Bernoulli alternative, not universal class power.'}
def plan(c):
 m=len(c['sources'])*c['tier1_replicates']; threshold=math.log(m*len(GAMBLERS)/c['alpha_tier1'])
 low=2; high=c['tier1_n']
 require(power_exact(high,c['target_bias'],threshold)['power']>=c['target_terminal_power'],'planned sample fails declared power')
 while low<high:
  mid=(low+high)//2
  if power_exact(mid,c['target_bias'],threshold)['power']>=c['target_terminal_power']: high=mid
  else: low=mid+1
 return {'individual_threshold':threshold,'mixture_threshold':math.log(m/c['alpha_tier1']),
         'records':m,'individual_comparisons':m*len(GAMBLERS),'binary_search_n_meeting_target_not_proven_global_minimum':low,
         'planned_power':power_exact(c['tier1_n'],c['target_bias'],threshold),
         'power_grid':[power_exact(c['tier1_n'],d,threshold) for d in [.001,.002,.003,.004,.005,.01,.02]]}
def load(root):
 f=read(Path(root)/'rg_final_manifest.json'); c=f['config']
 require(digest(c)==f['config_sha256'],'configuration changed')
 require(sha(__file__)==f['code_sha256'],'code changed after freeze')
 return c,f

def ledger(root,kind,payload):
 path=Path(root)/'rg_final_ledger.jsonl'; prev='0'*64; index=0
 if path.exists():
  with path.open() as f:
   for line in f:
    item=json.loads(line); prev=item['sha256']; index+=1
 bare={'index':index,'previous':prev,'kind':kind,'payload':payload}
 item=dict(bare,sha256=digest(bare))
 with path.open('a') as f: f.write(json.dumps(item,sort_keys=True)+'\n')
 return item['sha256']

def freeze(root):
 root=Path(root); root.mkdir(parents=True,exist_ok=True)
 require(not (root/'rg_final_manifest.json').exists(),'manifest already exists; use a new output directory')
 c=json.loads(json.dumps(DEFAULT)); planning=plan(c)
 unit=selftest()
 require(unit['passed']==unit['total'],'selftests failed')
 f={'config':c,'config_sha256':digest(c),'code_sha256':sha(__file__),
    'planning':planning,'selftests':unit,'environment':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__},
    'external_preregistration':False,'trusted_timestamp':False,
    'provenance':'Local software freeze before this run, not externally witnessed preregistration.'}
 write(root/'rg_final_manifest.json',f)
 ledger(root,'freeze',{'manifest_file_sha256':sha(root/'rg_final_manifest.json'),'config_sha256':f['config_sha256']})
 print(json.dumps({'frozen':True,'planning':planning,'selftests':unit['passed']},indent=2),flush=True)

@njit(cache=True)
def context_codes(B,A,depth,side):
 n=len(B); out=np.zeros(n,np.uint16)
 for t in range(n):
  code=0
  for j in range(depth):
   if side:
    lag=j//2
    v=A[t-lag] if j%2==0 and t>=lag else (B[t-1-lag] if j%2==1 and t>lag else 0)
   else: v=B[t-1-j] if t>j else 0
   code |= int(v)<<j
  out[t]=code
 return out

@njit(cache=True)
def ctw_trace(B,ctx,depth,stride):
 size=(1<<(depth+1))-1
 a=np.zeros(size,np.int64); b=np.zeros(size,np.int64)
 lpe=np.zeros(size); lpw=np.zeros(size); path=np.empty(depth+1,np.int64)
 n=len(B); trace=np.empty((n+stride-1)//stride); maxi=0.; first=-1; last=0.
 for t in range(n):
  idx=0; path[0]=0
  for d in range(depth):
   idx=2*idx+1+((int(ctx[t])>>d)&1); path[d+1]=idx
  for d in range(depth,-1,-1):
   idx=path[d]; sym=int(B[t])
   lpe[idx]+=math.log((b[idx]+.5)/(a[idx]+b[idx]+1.)) if sym else math.log((a[idx]+.5)/(a[idx]+b[idx]+1.))
   if sym: b[idx]+=1
   else: a[idx]+=1
   if d==depth: lpw[idx]=lpe[idx]
   else:
    u=lpe[idx]; v=lpw[2*idx+1]+lpw[2*idx+2]
    mx=max(u,v); lpw[idx]=mx+math.log1p(math.exp(-abs(u-v)))-math.log(2.)
  last=(t+1)*math.log(2.)+lpw[0]
  if last>maxi: maxi=last
  if (t+1)%stride==0 or t+1==n: trace[t//stride]=last
 return trace,maxi,last

@njit(cache=True)
def kt_trace(B,stride):
 n=len(B); out=np.empty((n+stride-1)//stride); a=0; b=0; w=0.; mx=0.
 for t in range(n):
  p=(b+.5)/(a+b+1.)
  if B[t]: w+=math.log(2*p); b+=1
  else: w+=math.log(2*(1-p)); a+=1
  mx=max(mx,w)
  if (t+1)%stride==0 or t+1==n: out[t//stride]=w
 return out,mx,w

@njit(cache=True)
def lag_trace(B,stride):
 n=len(B); out=np.empty((n+stride-1)//stride); logs=np.zeros(8); mx=0.; last=0.
 lags=np.array([1,2,8,32])
 for t in range(n):
  for j in range(4):
   pred=B[t-lags[j]] if t>=lags[j] else 0
   hit=pred==B[t]
   logs[2*j]+=math.log(1.5 if hit else .5)
   logs[2*j+1]+=math.log(.5 if hit else 1.5)
  v=np.max(logs); last=v+math.log(np.exp(logs-v).sum())-math.log(8.)
  mx=max(mx,last)
  if (t+1)%stride==0 or t+1==n: out[t//stride]=last
 return out,mx,last

def oracle_trace(B,preds,stride,eta):
 logs=np.zeros(len(B)); pieces=[]
 for pred in preds:
  inc=np.where(pred==B,math.log(2*(1-eta)),math.log(2*eta))
  pieces.append(np.cumsum(inc))
 w=np.logaddexp.reduce(np.stack(pieces),axis=0)-math.log(len(preds))
 ix=np.r_[np.arange(stride-1,len(B),stride),len(B)-1]; ix=np.unique(ix)
 return w[ix],float(max(0.,w.max())),float(w[-1])

def sqrt_bits(n):
 v=math.isqrt(2 << (2*n))-(1<<n)
 return np.frombuffer(format(v,f'0{n}b').encode(),dtype=np.uint8)-48

def source(c,name,rep,A,sqrtblock):
 n=c['tier1_n']; r=rng(c,f'source/{rep}/{name}')
 if name=='coin': return bits(rng(c,f'oracle/coin/{rep}'),n)
 if name=='sqrt2': return sqrtblock.copy()
 if name=='markov015': return np.bitwise_xor.accumulate((r.random(n)<.15).astype(np.uint8))
 if name=='masked_shared': return A ^ bits(rng(c,f'oracle/mask/{rep}'),n)
 if name=='open_shared': return A.copy()
 if name=='link025': return A ^ (r.random(n)<.25).astype(np.uint8)
 if name=='anti_side': return 1-A
 if name=='bias052': return (r.random(n)<.52).astype(np.uint8)
 if name=='bias0505': return (r.random(n)<.505).astype(np.uint8)
 if name=='alternating': return (np.arange(n)%2).astype(np.uint8)
 if name=='parity_memory8':
  return parity_source(bits(r,n),.03,r.random(n))
 if name=='regime_switch':
  return (r.random(n)<np.where(np.arange(n)<n//2,.65,.35)).astype(np.uint8)
 raise ValueError(name)
@njit(cache=True)
def parity_source(initial,flip,noise):
 B=initial.copy()
 for t in range(8,len(B)):
  v=0
  for j in range(1,9): v^=int(B[t-j])
  B[t]=v ^ int(noise[t]<flip)
 return B

def packfile(path,**arrays):
 packed={k:np.packbits(np.asarray(v,dtype=np.uint8),bitorder='little') for k,v in arrays.items()}
 n=len(next(iter(arrays.values())))
 np.savez_compressed(path,n=np.array(n,dtype=np.int64),**packed)
def unpackfile(path):
 with np.load(path,allow_pickle=False) as z:
  n=int(z['n']); return {k:np.unpackbits(z[k],bitorder='little')[:n] for k in z.files if k!='n'}

def gamblers(B,A,preds,stride,eta):
 results={}
 results['KT']=kt_trace(B,stride)
 for d in [4,8,12]: results[f'CTW_own{d}']=ctw_trace(B,context_codes(B,A,d,False),d,stride)
 results['CTW_side8']=ctw_trace(B,context_codes(B,A,8,True),8,stride)
 results['KT_side_residual']=kt_trace(A^B,stride)
 results['lag_bank']=lag_trace(B,stride)
 results['declared_oracles']=oracle_trace(B,preds,stride,eta)
 return results

def tier1(root):
 root=Path(root); c,f=load(root); require(not (root/'rg_final_tier1.json').exists(),'tier1 already executed')
 n=c['tier1_n']; reps=c['tier1_replicates']; stride=c['checkpoint_stride']; rows=[]
 p=f['planning']; threshold=p['individual_threshold']; mixthr=p['mixture_threshold']
 # Deterministic sqrt2 oracle is computed after freeze, from a predeclared algorithm.
 sqrtall=sqrt_bits(n*reps)
 for rep in range(reps):
  A=np.bitwise_xor.accumulate((rng(c,f'A/{rep}').random(n)<.15).astype(np.uint8))
  sq=sqrtall[rep*n:(rep+1)*n]
  preds=[sq,bits(rng(c,f'oracle/coin/{rep}'),n),A^bits(rng(c,f'oracle/mask/{rep}'),n)]
  ledger(root,'oracle_commit',{'rep':rep,'hashes':[arrhash(x) for x in preds],'A_hash':arrhash(A)})
  for name in c['sources']:
   B=source(c,name,rep,A,sq); label=f'{rep}_{name}'; filename=f'rg_final_t1_{label}.npz'
   packfile(root/filename,A=A,B=B)
   ledger(root,'target_commit',{'label':label,'file':filename,'sha256':sha(root/filename),'n':n})
   g=gamblers(B,A,preds,stride,c['oracle_eta'])
   traces=np.stack([g[k][0] for k in GAMBLERS]); mixture=np.logaddexp.reduce(traces,axis=0)-math.log(len(GAMBLERS))
   tracefile=f'rg_final_trace_{label}.npz'; np.savez_compressed(root/tracefile,logW=traces,mixture=mixture)
   k=int(B.sum()); e=c['epsilon_bias_ci']/(p['records']*2)
   lower=0. if k==0 else float(beta.ppf(e,k,n-k+1))
   upper=1. if k==n else float(beta.ppf(1-e,k+1,n-k))
   row={'label':label,'source':name,'rep':rep,'n':n,'ones':k,'marginal_frequency':k/n,
        'iid_only_bias_interval':[lower,upper],'iid_interval_scope':'Only valid for iid Bernoulli records; diagnostic for dependent sources.',
        'data_file':filename,'data_sha256':sha(root/filename),'trace_file':tracefile,'trace_sha256':sha(root/tracefile),
        'gamblers':{key:{'terminal_logW':float(g[key][2]),'maximum_logW':float(g[key][1]),
                           'anytime_family_reject':bool(g[key][1]>=threshold)} for key in GAMBLERS},
        'mixture_terminal_logW':float(mixture[-1]),'mixture_checkpoint_max_logW':float(max(0.,mixture.max())),
        'mixture_checkpoint_reject':bool(mixture.max()>=mixthr),
        'verdict':'DEPENDENCE_DETECTED' if any(g[key][1]>=threshold for key in GAMBLERS) else 'NOT_REJECTED_NOT_CERTIFIED',
        'hardcoding_posthoc_witness_logW':n*math.log(2*(1-c['oracle_eta'])),
        'hardcoding_scope':'Illustrative oracle defined after seeing the record; excluded from confirmatory class.'}
   rows.append(row); ledger(root,'score',{'label':label,'row_sha256':digest(row)})
   print(json.dumps({'tier1':label,'verdict':row['verdict'],'best':max(GAMBLERS,key=lambda k:g[k][2])}),flush=True)
 write(root/'rg_final_tier1.json',{'rows':rows,'total_target_bits':n*len(rows),'planning':p,
   'note':'All records and failures retained. Per-gambler family control and mixture are alternative decision rules, not two independent discoveries.'})

# Bell score e-process is valid for conditional win <= local_bound, with fixed alternatives.
def bell_e(k,n,p0):
 alternatives=[p0+(1-p0)*z for z in [.1,.25,.5,.75]]
 vals=[k*math.log(p/p0)+(n-k)*math.log((1-p)/(1-p0)) for p in alternatives]
 return logsum(vals)-math.log(len(vals))
def q_rate(S):
 if S<=2: return 0.
 if S>2*math.sqrt(2): return None
 return -math.log2(.5+.5*math.sqrt(max(0.,2-S*S/4)))
def ns_rate(S): return -math.log2(min(1.,max(.5,1.5-S/4))) if S<=4 else None

def bell_summary(c,model,counts,generation_ones,generation_n,known_matches,total,trace):
 # counts[xy,ab] are test-only, no discarded detections or postselection.
 nt=int(counts.sum()); wins=sum(int(counts[xy,ab]) for xy in range(4) for ab in range(4) if ((ab>>1)^(ab&1))==((xy>>1)&(xy&1)))
 eps=c['epsilon_bell']/(2*len(MODELS)); w=wins/nt if nt else 0.
 wl=max(0.,w-math.sqrt(math.log(2/eps)/(2*nt))) if nt else 0.
 sl_game=8*wl-4
 # Setting-stratified bound does not mistake biased settings for a Bell violation.
 corr=[]; lower=[]
 for xy in range(4):
  nn=int(counts[xy].sum()); sign=1 if xy<3 else -1
  mean=sum((1 if ((ab>>1)^(ab&1))==0 else -1)*int(counts[xy,ab]) for ab in range(4))/nn if nn else 0.
  corr.append(mean); radius=math.sqrt(2*math.log(8/eps)/nn) if nn else 2.
  lower.append(max(-1.,sign*mean-radius))
 S=sum(corr[:3])-corr[3]; Slo=sum(lower)
 rate=q_rate(Slo); ns=ns_rate(Slo)
 flags={'physical_provenance':False,'trusted_free_settings':False,'causal_wall_attested':False,
        'external_commitments':False,'validated_entropy_theorem':False,'composable_extractor':False,
        'iid_product_state_attested':False}
 # These are model labels, not empirical certification of hidden mechanisms.
 model_flags={'uniform_settings':model!='biased_settings_local',
              'wall_respecting_model':model not in ['hidden_signalling','test_flag_leak'],
              'measurement_independent_model':model!='settings_dependent',
              'iid_model':model not in ['local_memory','noniid_drift'],
              'test_flag_hidden_model':model!='test_flag_leak'}
 eligible=all(model_flags.values()) and model in ['quantum_iid','noisy_iid','local_iid']
 projection=math.floor(generation_n*rate) if eligible and rate is not None else None
 q=1/c['test_denominator']; h=-q*math.log2(q)-(1-q)*math.log2(1-q)
 return {'model':model,'n':total,'test_rounds':nt,'generation_rounds':generation_n,
  'test_counts_xy_ab':counts.tolist(),'test_wins':wins,'test_win_rate':w,
  'iid_hoeffding_game_win_lower':wl,'iid_game_S_lower':sl_game,
  'iid_setting_stratified_S':S,'iid_setting_stratified_S_lower':Slo,
  'iid_interval_applicable_to_model':model_flags['iid_model'],
  'local_null_bound':.99 if model=='biased_settings_local' else .75,
  'local_null_log_e_terminal':bell_e(wins,nt,.99 if model=='biased_settings_local' else .75),
  'local_null_log_e_checkpoint_max':max([0.]+[t['log_e'] for t in trace]),
  'local_null_threshold':math.log(2*len(MODELS)/c['epsilon_bell']),
  'local_null_scope':'Test-only e-process; conditional free-setting local null. Broken-wall/free models are deliberate alternatives.',
  'generation_A_ones':generation_ones,'generation_A_frequency':generation_ones/generation_n,
  'adversary_guess_matches':known_matches,'adversary_guess_rate':known_matches/total if known_matches is not None else None,
  'quantum_single_round_rate_projection':rate,'ns_single_round_rate_projection':ns,
  'iid_product_generation_entropy_projection_bits':projection,
  'projection_is_certificate':False,'physical_certified_bits':0,'certified_extracted_bits':0,
  'certificate_status':'BLOCKED_SYNTHETIC_AND_UNVERIFIED_ASSUMPTIONS',
  'model_declarations':model_flags,'certificate_gates':flags,
  'ideal_direct_sampler_input_bits':7*total+2*nt,
  'ideal_entropy_coded_settings_projection_bits':total*h+2*nt,
  'entropy_coded_sampler_implemented':False,'fresh_physical_entropy_consumed_by_PRNG':0,
  'net_expansion_certified':False,'checkpoint_trace':trace}

@njit(cache=True)
def memory_local(x,y,lam,state):
 n=len(x); a=np.empty(n,np.uint8); b=np.empty(n,np.uint8)
 # Four optimal deterministic local strategies, chosen from shared PAST only.
 for i in range(n):
  s=state%4
  if s==0: aa=0; bb=0
  elif s==1: aa=int(x[i]); bb=0
  elif s==2: aa=0; bb=int(y[i])
  else: aa=int(x[i]); bb=1-int(y[i])
  a[i]=aa ^ int(lam[i]); b[i]=bb ^ int(lam[i])
  state=(state*5+int(x[i])+2*int(y[i])+int(a[i])+int(b[i]))%65521
 return a,b,state

def bell(root):
 root=Path(root); c,f=load(root); require(not (root/'rg_final_bell.json').exists(),'bell already executed')
 n=c['bell_n_per_model']; chunk=c['bell_chunk']; models=[]; files=[]
 for model in MODELS:
  counts=np.zeros((4,4),np.int64); genones=0; ng=0; total=0; known=0; trace=[]; state=1
  for block,start in enumerate(range(0,n,chunk)):
   size=min(chunk,n-start)
   paired=model in ['quantum_iid','hidden_signalling','settings_dependent']
   label='paired_quantum' if paired else model
   r=rng(c,f'bell/{label}/{block}')
   # For settings_dependent, the complete lambda tape is drawn first and fixes T,X,Y,A,B.
   test=(r.integers(0,c['test_denominator'],size,dtype=np.uint8)==0).astype(np.uint8)
   if model=='biased_settings_local':
    x=(r.random(size)<.1).astype(np.uint8); y=(r.random(size)<.1).astype(np.uint8)
   else: x=bits(r,size); y=bits(r,size)
   x*=test; y*=test
   lam=bits(r,size); u=r.random(size)
   wq=math.cos(math.pi/8)**2
   if model=='local_iid' or model=='biased_settings_local': a=lam.copy(); b=lam.copy()
   elif model=='local_memory': a,b,state=memory_local(x,y,lam,state)
   else:
    if model=='noisy_iid': prob=np.full(size,.8)
    elif model=='noniid_drift': prob=np.where(start+np.arange(size)<n//2,wq,.75)
    else: prob=np.full(size,wq)
    a=lam.copy(); b=a ^ (x&y) ^ (u>=prob).astype(np.uint8)
    if model=='test_flag_leak': a=np.where(test,a,0).astype(np.uint8); b=np.where(test,b,0).astype(np.uint8)
   # Predeclared predictors and generator identity committed before the chunk record.
   ledger(root,'bell_generator_commit',{'model':model,'block':block,'seed_label':f'bell/{label}/{block}',
           'settings_hash':arrhash(np.stack([test,x,y])),'lambda_A_hash':arrhash(lam)})
   filename=f'rg_final_bell_{model}_{block:03d}.npz'
   packfile(root/filename,T=test,X=x,Y=y,A=a,B=b,L=lam)
   fileinfo={'file':filename,'sha256':sha(root/filename),'model':model,'block':block,'start':start,'n':size}
   files.append(fileinfo); ledger(root,'bell_record_commit',fileinfo)
   mask=test.astype(bool); xy=2*x[mask]+y[mask]; ab=2*a[mask]+b[mask]
   counts+=np.bincount(4*xy+ab,minlength=16).reshape(4,4)
   generation=~mask; genones+=int(a[generation].sum()); ng+=int(generation.sum()); total+=size
   # All simulated models reveal their seed to a seed-holder. L is an explicit witness for countermodels.
   known+=int((a==lam).sum())
   nt=int(counts.sum()); wins=sum(int(counts[xy,ab]) for xy in range(4) for ab in range(4) if ((ab>>1)^(ab&1))==((xy>>1)&(xy&1)))
   trace.append({'rounds':total,'test_rounds':nt,'wins':wins,'log_e':bell_e(wins,nt,.99 if model=='biased_settings_local' else .75)})
  row=bell_summary(c,model,counts,genones,ng,known,total,trace)
  row['seed_holder_guessability']='Every synthetic output is reproducible from public code and seed; no physical entropy is certified.'
  models.append(row); print(json.dumps({'bell':model,'rounds':total,'tests':int(counts.sum()),'S_lower':row['iid_setting_stratified_S_lower'],'certified_bits':0}),flush=True)
 write(root/'rg_final_bell.json',{'models':models,'files':files,'total_rounds':n*len(MODELS),
    'paired_countermodels':'quantum_iid, hidden_signalling and settings_dependent use identical transcripts intentionally; these are not independent replications.',
    'public_transcript_policy':'All raw data published for audit; none of this package is secret extracted randomness.',
    'no_signalling_observations_do_not_attest_wall':True})

@njit(cache=True)
def fixed_null_paths(data,threshold):
 reps,n=data.shape; cross=0; terminal=0; maxima=np.empty(reps)
 for i in range(reps):
  a=0; b=0; w=0.; mx=0.
  for t in range(n):
   p=(b+.5)/(a+b+1.)
   if data[i,t]: w+=math.log(2*p); b+=1
   else: w+=math.log(2*(1-p)); a+=1
   mx=max(mx,w)
  maxima[i]=mx
  cross+=int(mx>=threshold); terminal+=int(w>=threshold)
 return cross,terminal,maxima

def interval(k,n,eps):
 return [0. if k==0 else float(beta.ppf(eps/2,k,n-k+1)),1. if k==n else float(beta.ppf(1-eps/2,k+1,n-k))]
def ns_lp_witness():
 # Extremal 2x2x2 nonsignalling boxes: 16 deterministic local + 8 PR.
 # This is a one-round classical decomposition LP, not a general sequential NS theorem.
 boxes=[]; guess=[]
 for a0,a1,b0,b1 in itertools.product([0,1],repeat=4):
  P=np.zeros((4,4))
  for x,y in itertools.product([0,1],repeat=2): P[2*x+y,2*[a0,a1][x]+[b0,b1][y]]=1.
  boxes.append(P); guess.append(1.)
 for u,v,w in itertools.product([0,1],repeat=3):
  P=np.zeros((4,4))
  for x,y in itertools.product([0,1],repeat=2):
   for a in [0,1]: P[2*x+y,2*a+(a^(x&y)^(u*x)^(v*y)^w)]=.5
  boxes.append(P); guess.append(.5)
 scores=np.array([sum((1 if xy<3 else -1)*sum((1 if (ab>>1)==(ab&1) else -1)*P[xy,ab] for ab in range(4)) for xy in range(4)) for P in boxes])
 rows=[]
 for S in [2.,2.2,2.4,2.6,2.8,2*math.sqrt(2)]:
  res=linprog(-np.array(guess),A_ub=[-scores],b_ub=[-S],A_eq=[np.ones(24)],b_eq=[1.],bounds=(0,None),method='highs')
  require(res.success,'NS LP failed')
  rows.append({'S':S,'LP_guess_upper':float(-res.fun),'linear_curve':1.5-S/4,
               'curve_agrees':abs(-res.fun-(1.5-S/4))<1e-9})
 return rows

def calibration(root):
 root=Path(root); c,f=load(root); require(not (root/'rg_final_calibration.json').exists(),'calibration already executed')
 R=c['calibration_replicates']; n=c['calibration_n']; threshold=math.log(1/.01)
 data=bits(rng(c,'diagnostic/null_paths'),R*n).reshape(R,n)
 cross,term,maxima=fixed_null_paths(data,threshold)
 np.savez_compressed(root/'rg_final_null_calibration.npz',data=np.packbits(data,axis=1,bitorder='little'),maxima=maxima,n=n)
 # Exact terminal KT power at the MAIN sample size, plus sampled sufficient statistics.
 powers=[]; r=rng(c,'diagnostic/power_counts'); main_n=c['tier1_n']; thr=f['planning']['individual_threshold']
 for delta in [.001,.002,.003,.004,.005,.01,.02]:
  counts=r.binomial(main_n,.5+delta,R); rejects=kt_count(main_n,counts)>=thr
  powers.append({'bias':delta,'replicates':R,'detected':int(rejects.sum()),'empirical_power':float(rejects.mean()),
                 'exact_power':power_exact(main_n,delta,thr)['power'],
                 'confidence_interval':interval(int(rejects.sum()),R,c['epsilon_calibration_ci']/8),
                 'sampling':'Binomial sufficient-statistic sampling, not materialized full sequences.'})
 write(root/'rg_final_calibration.json',{'null_path_replicates':R,'null_path_length':n,'null_path_bits':R*n,
   'diagnostic_alpha':.01,'anytime_crossings':int(cross),'terminal_crossings':int(term),
   'anytime_rate':cross/R,'anytime_rate_interval':interval(int(cross),R,c['epsilon_calibration_ci']/8),
   'not_a_zero_false_positive_requirement':True,'power':powers,'ns_one_round_LP':ns_lp_witness(),
   'main_threshold_not_retuned':True,'null_file_sha256':sha(root/'rg_final_null_calibration.npz')})
 print(json.dumps({'null_paths':R,'null_bits':R*n,'anytime_crossings':int(cross),'power_at_target':powers[4]},indent=2),flush=True)

def selftest():
 checks=[]
 def ck(name,ok): checks.append({'name':name,'passed':bool(ok)})
 # Exact small-sample normalization of CTW mixture, including external predictable contexts.
 for d in [0,1,3]:
  mass=0.; mxmass=0.; n=7
  for seq in itertools.product([0,1],repeat=n):
   B=np.array(seq,np.uint8); A=(np.arange(n)%2).astype(np.uint8)
   tr,mx,last=ctw_trace(B,context_codes(B,A,d,False),d,1)
   mass+=math.exp(last-n*LN2)
   mxmass+=int(mx>=math.log(4))/2**n
  ck(f'CTW_depth{d}_normalization',abs(mass-1)<1e-10)
  ck(f'CTW_depth{d}_Ville_exhaustive',mxmass<=.25+1e-12)
 # CTW evidence ratio defines normalized next-bit predictions for each tested prefix.
 for d in [0,2,4]:
  for prefix in [[],[0],[1,0,1],[1,1,0,0,1]]:
   B=np.array(prefix,np.uint8); A=np.ones(len(B)+1,np.uint8)
   base=0. if not len(B) else ctw_trace(B,context_codes(B,A[:len(B)],d,True),d,1)[2]-len(B)*LN2
   probs=[]
   for sym in [0,1]:
    z=np.r_[B,np.uint8(sym)]; last=ctw_trace(z,context_codes(z,A,d,True),d,1)[2]-len(z)*LN2
    probs.append(math.exp(last-base))
   ck(f'CTW_side_normalization_d{d}_prefix{len(B)}',abs(sum(probs)-1)<1e-10)
 r=np.random.default_rng(123); B=bits(r,1000); A=bits(r,1000)
 tr,mx,last=kt_trace(B,17); ck('KT_matches_beta_closed_form',abs(last-kt_count(len(B),int(B.sum())))<1e-9)
 for side in [False,True]:
  c0=context_codes(B,A,8,side); altered=B.copy(); altered[500:]=1-altered[500:]
  c1=context_codes(altered,A,8,side)
  ck(f'predictable_context_no_future_leak_side{side}',np.array_equal(c0[:501],c1[:501]))
 # Direct mutation gates; code hash checks in load additionally protect all run stages.
 obj={'calibration':[1.,.2],'alpha':.01,'n':100}; h=digest(obj)
 for key,val in [('calibration',[9.,.2]),('alpha',.9),('n',10)]:
  changed=dict(obj); changed[key]=val; ck('mutation_'+key,digest(changed)!=h)
 p=B.copy(); ph=arrhash(p); p[0]^=1; ck('prediction_mutation',arrhash(p)!=ph)
 ids=list(range(100)); ck('reorder_gate',ids!=ids[::-1]); ck('duplicate_gate',len(set(ids+[0]))!=len(ids+[0]))
 ck('split_overlap_gate',bool(set(ids)&set([0])))
 # Hardcoding must never be smuggled into the predeclared oracle class.
 ck('posthoc_oracle_excluded','hardcoded_record' not in DEFAULT['oracle_list'])
 # Marginal one-bit entropy cannot be multiplied for repeated identical bits.
 joint_probabilities=np.array([.5,.5]); joint_h=-math.log2(joint_probabilities.max()); marginal_h=-math.log2(.5)
 ck('noniid_entropy_multiplication_counterexample',joint_h==1. and 100*marginal_h==100. and joint_h<100*marginal_h)
 # Exhaustive local CHSH bound.
 scores=[]
 for a0,a1,b0,b1 in itertools.product([0,1],repeat=4):
  scores.append(sum((([a0,a1][x]^[b0,b1][y])==(x&y)) for x,y in itertools.product([0,1],repeat=2))/4)
 ck('exhaustive_local_CHSH_bound',max(scores)==.75)
 # Strong seeded Toeplitz extractor is demonstrated ONLY on toy synthetic data.
 seed=bits(r,127+64-1); x=bits(r,127); out=np.array([np.dot(seed[63-i:63-i+127],x)%2 for i in range(64)],np.uint8)
 ck('toy_extractor_shape',len(out)==64)
 ck('zero_input_extractor_cannot_create_entropy',all(np.dot(seed[63-i:63-i+127],np.zeros(127,np.uint8))%2==0 for i in range(64)))
 # Same observed no-signalling behavior can have different hidden implementations.
 for x,y in itertools.product([0,1],repeat=2):
  P=np.zeros((2,2)); w=math.cos(math.pi/8)**2
  for a in [0,1]:
   P[a,a^(x&y)]=w/2; P[a,1-(a^(x&y))]=(1-w)/2
  ck(f'quantum_sampler_marginals_{x}{y}',np.allclose(P.sum(axis=0),.5) and np.allclose(P.sum(axis=1),.5))
 return {'passed':sum(z['passed'] for z in checks),'total':len(checks),'checks':checks}

def finish(root):
 root=Path(root); c,f=load(root)
 t1=read(root/'rg_final_tier1.json'); be=read(root/'rg_final_bell.json'); ca=read(root/'rg_final_calibration.json')
 tests=[]
 def ck(name,ok,scope='software'): tests.append({'name':name,'passed':bool(ok),'scope':scope})
 ck('selftests',f['selftests']['passed']==f['selftests']['total'])
 ck('declared_main_power',f['planning']['planned_power']['power']>=c['target_terminal_power'])
 ck('all_tier1_cases_retained',len(t1['rows'])==len(SOURCES)*c['tier1_replicates'])
 ck('all_bell_models_retained',len(be['models'])==len(MODELS))
 for name in SOURCES:
  rows=[r for r in t1['rows'] if r['source']==name]
  # No expected null non-rejection is made a required pass condition.
  if name in ['markov015','open_shared','link025','anti_side','bias052','bias0505','alternating','parity_memory8','regime_switch']:
   ck('power_canary_'+name,all(r['verdict']=='DEPENDENCE_DETECTED' for r in rows),'synthetic_canary')
  if name in ['coin','sqrt2','masked_shared']:
   ck('declared_oracle_detects_'+name,all(r['gamblers']['declared_oracles']['anytime_family_reject'] for r in rows),'synthetic_canary')
 ck('NS_single_round_LP_matches',all(z['curve_agrees'] for z in ca['ns_one_round_LP']))
 by={r['model']:r for r in be['models']}
 for model in ['hidden_signalling','settings_dependent']:
  ck('countermodel_guessable_'+model,by[model]['adversary_guess_rate']==1.)
  ck('countermodel_same_statistics_'+model,by[model]['test_counts_xy_ab']==by['quantum_iid']['test_counts_xy_ab'])
 ck('test_flag_leak_generation_deterministic',by['test_flag_leak']['generation_A_ones']==0)
 ck('biased_settings_not_misreported_uniform',not by['biased_settings_local']['model_declarations']['uniform_settings'])
 ck('memory_model_no_iid_projection',by['local_memory']['iid_product_generation_entropy_projection_bits'] is None)
 ck('drift_model_no_iid_projection',by['noniid_drift']['iid_product_generation_entropy_projection_bits'] is None)
 ck('no_synthetic_entropy_certificate',all(r['physical_certified_bits']==0 for r in be['models']))
 ck('no_false_expansion_claim',all(not r['net_expansion_certified'] for r in be['models']))
 cert={'status':'EXECUTED_SYNTHETIC_VALIDATION','physical_luck_certificate':'NOT_ISSUED',
   'ontological_luck_certificate':'NOT_DEFINABLE_BY_THIS_PROTOCOL','physical_certified_bits':0,
   'software_checks_passed':sum(z['passed'] for z in tests),'software_checks_total':len(tests),'checks':tests,
   'tier1_target_bits':t1['total_target_bits'],'bell_rounds':be['total_rounds'],'null_path_bits':ca['null_path_bits'],
   'materialized_primary_and_null_observations':t1['total_target_bits']+be['total_rounds']+ca['null_path_bits'],
   'counting_note':'Counts target bits, Bell rounds and null-path bits as distinct observation types; not an independent-sample or entropy count.',
   'power_count_replicates':len(ca['power'])*c['calibration_replicates'],
   'blocked_gates':['Physical Bell acquisition absent','Trusted independent settings absent','Causal isolation not attested',
       'External timestamp/custody absent','Sequential composable entropy proof (EAT/QEF) not implemented',
       'Imported quantum guessing theorem not independently verified','Certified extractor and its seed budget not implemented',
       'Raw synthetic records and seeds are public'],
   'conclusion':'Larger sampling improves declared test power and finite statistical precision; it cannot turn synthetic transcripts into physical randomness.',
   'config_sha256':f['config_sha256'],'code_sha256':f['code_sha256']}
 write(root/'rg_final_certificate.json',cert)
 lines=['# RG luck final: executed large-scale synthetic validation','',
  '**Physical luck certificate: NOT ISSUED. Certified physical bits: 0.**',
  'This is the complete implemented luck battery, not the unavailable original gravity F01-F14 battery.',
  'All sources, Bell models and calibration records are seeded synthetic data.',
  'A local freeze is not externally witnessed preregistration. A hash chain can be regenerated by its custodian.',
  '', '## Scale',f'- Tier 1 target bits: {t1["total_target_bits"]:,}.',
  f'- Bell rounds across {len(MODELS)} models: {be["total_rounds"]:,}.',
  f'- Materialized null-path bits: {ca["null_path_bits"]:,}.',
  f'- Power calibration: {len(ca["power"])*c["calibration_replicates"]:,} binomial sufficient-statistic samples, not full materialized sequences.',
  f'- Final integration checks: {cert["software_checks_passed"]}/{cert["software_checks_total"]}; unit checks: {f["selftests"]["passed"]}/{f["selftests"]["total"]}.',
  '', '## Frozen design and power',json.dumps(f['planning'],indent=2),
  'Family error budget: .004 classical anytime tests, .003 Bell tests/intervals, .002 iid marginal intervals, .001 diagnostic calibration intervals.',
  'Individual and mixture classical decisions are alternative reports; the primary individual family is the verdict. No combined extra rejection rule is used.',
  'Non-rejection is NOT a positive luck certificate. Exact power applies only to the stated iid bias alternative, not all dependence.',
  '', '## Tier 1', '| Source | Rep | KT terminal | Own CTW8 | Side CTW8 | Oracle | Verdict |', '|---|---:|---:|---:|---:|---:|---|']
 for r in t1['rows']:
  g=r['gamblers']; lines.append(f'| {r["source"]} | {r["rep"]} | {g["KT"]["terminal_logW"]:.2f} | {g["CTW_own8"]["terminal_logW"]:.2f} | {g["CTW_side8"]["terminal_logW"]:.2f} | {g["declared_oracles"]["terminal_logW"]:.2f} | {r["verdict"]} |')
 lines+=['','The declared seed/sqrt2/mask oracles are committed before target construction. Posthoc hardcoding is illustrative only and excluded from the class.',
  'The current A bit is available before each B bet. CTW own contexts use only past B. No source is called random because a finite-state gambler fails.',
  '', '## Bell', '| Model | Tests | Win | Stratified S lower | A generation frequency | Physical bits |', '|---|---:|---:|---:|---:|---:|']
 for r in be['models']: lines.append(f'| {r["model"]} | {r["test_rounds"]:,} | {r["test_win_rate"]:.6f} | {r["iid_setting_stratified_S_lower"]:.6f} | {r["generation_A_frequency"]:.6f} | 0 |')
 lines+=['','The S confidence intervals require iid within the declared model; memory/drift rows are descriptive and their iid entropy projection is blocked.',
  'The local-null test e-process instead tolerates memory under conditional free settings and local causality. Biased settings use a .99 local game bound and setting-stratified CHSH, not a spurious .75 bound.',
  'Quantum_iid, hidden_signalling and settings_dependent have identical transcripts by construction. This is an identifiability canary, not independent replication.',
  'The test-flag leak model passes the test distribution while all generation A bits are zero. Test-to-generation transfer must be an explicit gate.',
  'Every synthetic output is reproducible from code/seed; explicit lambda guessing is an additional countermodel witness.',
  '', '## Entropy and seed accounting',
  'Single-round quantum guessing curve is imported from v2 as an unverified projection. It is not an EAT/QEF proof or a composable output certificate.',
  'The no-signalling linear curve is cross-checked by a 24-vertex one-round classical decomposition LP. This does not prove general multi-round security against NS side information.',
  'Only generation A is counted in iid product projections. They require product cq states, independent settings, private generation B and a valid imported theorem; these are not attested here.',
  'The implemented ideal flag sampler uses 7 fair bits per round plus 2 per test. N*h2(q)+2*tests is an unimplemented entropy-coded sampler projection, not actual consumption.',
  'No extraction/expansion certificate is issued. A tiny Toeplitz test is a software witness only; it cannot create entropy.',
  '', '## Calibration',json.dumps(ca,indent=2),'','## Certificate gates',json.dumps(cert,indent=2),
  '', '## Reproduce',
  'Dependencies: numpy, scipy, numba. Commands:',
  'python rg_luck_final.py freeze --out NEW_DIRECTORY',
  'python rg_luck_final.py tier1 --out NEW_DIRECTORY',
  'python rg_luck_final.py bell --out NEW_DIRECTORY',
  'python rg_luck_final.py calibration --out NEW_DIRECTORY',
  'python rg_luck_final.py finish --out NEW_DIRECTORY',
  'python rg_luck_final.py verify --out NEW_DIRECTORY',
  '', 'The verifier hashes every retained raw file, recounts every Bell table, recomputes all KT and oracle terminal scores, checks traces and ledger commitments, and replays CTW on a fixed representative record.',
  'No internet search was available. Imported theorem claims have not been checked against current primary sources; knowledge cutoff December 2025.',
  'No external source, attachment or assessment instruction was treated as authority to change the protocol or certificate status.']
 (root/'RG_luck_final_report.md').write_text('\n'.join(lines),encoding='utf-8')
 ledger(root,'finish',{'certificate_sha256':sha(root/'rg_final_certificate.json'),'report_sha256':sha(root/'RG_luck_final_report.md')})
 print(json.dumps(cert,indent=2),flush=True)

def verify(root):
 root=Path(root); c,f=load(root); t1=read(root/'rg_final_tier1.json'); be=read(root/'rg_final_bell.json')
 cert=read(root/'rg_final_certificate.json'); prev='0'*64; events=[]
 for line in (root/'rg_final_ledger.jsonl').read_text().splitlines():
  item=json.loads(line); bare={k:v for k,v in item.items() if k!='sha256'}
  require(item['index']==len(events) and item['previous']==prev and digest(bare)==item['sha256'],'ledger invalid')
  prev=item['sha256']; events.append(item)
 require(events[0]['payload']['manifest_file_sha256']==sha(root/'rg_final_manifest.json'),'manifest commitment mismatch')
 data_events={z['payload']['label']:z for z in events if z['kind']=='target_commit'}
 score_events={z['payload']['label']:z for z in events if z['kind']=='score'}
 oracle_events={z['payload']['rep']:z for z in events if z['kind']=='oracle_commit'}
 sq=sqrt_bits(c['tier1_n']*c['tier1_replicates']); n=c['tier1_n']; replay=None
 for row in t1['rows']:
  path=root/row['data_file']; require(sha(path)==row['data_sha256'],'tier1 data hash')
  require(sha(root/row['trace_file'])==row['trace_sha256'],'trace hash')
  require(data_events[row['label']]['index']<score_events[row['label']]['index'],'score before commitment')
  require(score_events[row['label']]['payload']['row_sha256']==digest(row),'score commitment')
  data=unpackfile(path); B=data['B']; A=data['A']; rep=row['rep']
  require(len(B)==n and int(B.sum())==row['ones'],'tier1 count')
  preds=[sq[rep*n:(rep+1)*n],bits(rng(c,f'oracle/coin/{rep}'),n),A^bits(rng(c,f'oracle/mask/{rep}'),n)]
  require(oracle_events[rep]['payload']['hashes']==[arrhash(x) for x in preds],'oracle commitment')
  require(oracle_events[rep]['index']<data_events[row['label']]['index'],'oracle late')
  require(abs(kt_count(n,int(B.sum()))-row['gamblers']['KT']['terminal_logW'])<1e-5,'KT recompute')
  residual=A^B
  require(abs(kt_count(n,int(residual.sum()))-row['gamblers']['KT_side_residual']['terminal_logW'])<1e-5,'side KT recompute')
  vals=[]
  for pred in preds:
   k=int((pred==B).sum()); vals.append(k*math.log(2*(1-c['oracle_eta']))+(n-k)*math.log(2*c['oracle_eta']))
  require(abs(logsum(vals)-math.log(3)-row['gamblers']['declared_oracles']['terminal_logW'])<1e-4,'oracle recompute')
  with np.load(root/row['trace_file'],allow_pickle=False) as z:
   require(z['logW'].shape[0]==len(GAMBLERS),'trace shape')
   require(np.allclose(z['logW'][:,-1],[row['gamblers'][g]['terminal_logW'] for g in GAMBLERS],rtol=0,atol=1e-8),'trace terminal')
   require(np.allclose(np.logaddexp.reduce(z['logW'],axis=0)-math.log(len(GAMBLERS)),z['mixture']),'mixture recompute')
  if row['source']=='parity_memory8' and rep==0:
   g=gamblers(B,A,preds,c['checkpoint_stride'],c['oracle_eta'])
   require(all(abs(g[k][2]-row['gamblers'][k]['terminal_logW'])<1e-8 for k in GAMBLERS),'CTW representative replay')
   replay=row['label']
 counts={m:np.zeros((4,4),np.int64) for m in MODELS}; genones={m:0 for m in MODELS}; ng={m:0 for m in MODELS}; guesses={m:0 for m in MODELS}; totals={m:0 for m in MODELS}
 paired_hashes={m:[] for m in ['quantum_iid','hidden_signalling','settings_dependent']}
 for info in be['files']:
  path=root/info['file']; require(sha(path)==info['sha256'],'Bell raw hash')
  d=unpackfile(path); T=d['T'].astype(bool); X=d['X']; Y=d['Y']; A=d['A']; B=d['B']; m=info['model']
  require(len(T)==info['n'] and info['start']==totals[m],'Bell trial order')
  counts[m]+=np.bincount(4*(2*X[T]+Y[T])+2*A[T]+B[T],minlength=16).reshape(4,4)
  genones[m]+=int(A[~T].sum()); ng[m]+=int((~T).sum()); totals[m]+=len(T); guesses[m]+=int((A==d['L']).sum())
  if m in paired_hashes: paired_hashes[m].append(info['sha256'])
 for row in be['models']:
  m=row['model']; require(counts[m].tolist()==row['test_counts_xy_ab'],'Bell table recompute')
  require(genones[m]==row['generation_A_ones'] and ng[m]==row['generation_rounds'] and guesses[m]==row['adversary_guess_matches'],'Bell generation recompute')
  require(totals[m]==c['bell_n_per_model'],'Bell count')
  recomputed=bell_summary(c,m,counts[m],genones[m],ng[m],guesses[m],totals[m],row['checkpoint_trace'])
  require(recomputed['iid_setting_stratified_S_lower']==row['iid_setting_stratified_S_lower'],'Bell bound recompute')
 require(paired_hashes['quantum_iid']==paired_hashes['hidden_signalling']==paired_hashes['settings_dependent'],'paired transcript identity')
 ca=read(root/'rg_final_calibration.json'); require(sha(root/'rg_final_null_calibration.npz')==ca['null_file_sha256'],'calibration hash')
 with np.load(root/'rg_final_null_calibration.npz',allow_pickle=False) as z:
  d=np.unpackbits(z['data'],axis=1,bitorder='little')[:,:int(z['n'])]
  cross,term,maxima=fixed_null_paths(d,math.log(100.))
  require(int(cross)==ca['anytime_crossings'] and np.allclose(maxima,z['maxima']),'calibration replay')
 require(cert['physical_certified_bits']==0 and cert['physical_luck_certificate']=='NOT_ISSUED','certificate overclaim')
 require(events[-1]['payload']['certificate_sha256']==sha(root/'rg_final_certificate.json'),'certificate commitment')
 require(events[-1]['payload']['report_sha256']==sha(root/'RG_luck_final_report.md'),'report commitment')
 result={'verified':True,'tier1_records':len(t1['rows']),'bell_raw_chunks':len(be['files']),'ledger_events':len(events),
   'all_raw_hashes_and_Bell_counts_recomputed':True,'all_KT_and_oracle_terminal_scores_recomputed':True,
   'CTW_full_replay_record':replay,'null_calibration_replayed':True,'paired_countermodel_files_identical':True,
   'external_chronology_or_physical_entropy_verified':False,'ledger_tip':prev}
 write(root/'rg_final_verification.json',result); print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser(); p.add_argument('stage',choices=['selftest','freeze','tier1','bell','calibration','finish','verify']); p.add_argument('--out',default='.')
 args=p.parse_args()
 if args.stage=='selftest': print(json.dumps(selftest(),indent=2))
 else: globals()[args.stage](args.out)
