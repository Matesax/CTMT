#!/usr/bin/env python3
"""Independent read-only verifier. Does not import or run rg_luck_final.py.
Batch CTW terminal evidence is reconstructed from context counts and beta functions,
not the generator's sequential update algorithm. This does not attest physical entropy.
"""
import argparse, hashlib, json, math
from pathlib import Path
import numpy as np
from scipy.special import betaln

def canonical(x): return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(x): return hashlib.sha256(canonical(x)).hexdigest()
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for z in iter(lambda:f.read(1048576),b''): h.update(z)
 return h.hexdigest()
def require(c,m):
 if not c: raise ValueError(m)
def loadbits(p):
 with np.load(p,allow_pickle=False) as z:
  n=int(z['n']); return {k:np.unpackbits(z[k],bitorder='little')[:n] for k in z.files if k!='n'}
def ah(a):
 a=np.ascontiguousarray(a)
 return hashlib.sha256(str(a.dtype).encode()+canonical(list(a.shape))+a.tobytes()).hexdigest()
def seeded(seed,label,n):
 v=int.from_bytes(hashlib.sha256(f'{seed}:{label}'.encode()).digest()[:16],'big')
 return np.random.Generator(np.random.PCG64(v)).integers(0,2,n,dtype=np.uint8)
def context(B,A,D,side):
 n=len(B); code=np.zeros(n,np.uint16)
 for j in range(D):
  lag=j//2 if side else j+1
  src=A if side and j%2==0 else B
  if side and j%2: lag+=1
  if lag==0: code|=src.astype(np.uint16)<<j
  else: code[lag:]|=src[:-lag].astype(np.uint16)<<j
 return code

def batch_ctw(B,codes,D):
 n=len(B); evidences=[]
 for d in range(D+1):
  ids=codes&((1<<d)-1)
  total=np.bincount(ids,minlength=1<<d)
  one=np.bincount(ids,weights=B,minlength=1<<d)
  evidences.append(betaln(one+.5,total-one+.5)-betaln(.5,.5))
 weighted=evidences[-1]
 for d in range(D-1,-1,-1):
  size=1<<d
  weighted=np.logaddexp(evidences[d],weighted[:size]+weighted[size:])-math.log(2)
 return n*math.log(2)+float(weighted[0])

def run(root):
 root=Path(root); f=json.loads((root/'rg_final_manifest.json').read_text()); c=f['config']
 require(digest(c)==f['config_sha256'],'manifest configuration hash')
 require(sha(root/'rg_luck_final.py')==f['code_sha256'],'frozen source hash')
 t1=json.loads((root/'rg_final_tier1.json').read_text()); be=json.loads((root/'rg_final_bell.json').read_text())
 cert=json.loads((root/'rg_final_certificate.json').read_text())
 events=[]; prev='0'*64
 for line in (root/'rg_final_ledger.jsonl').read_text().splitlines():
  z=json.loads(line); bare={k:v for k,v in z.items() if k!='sha256'}
  require(z['index']==len(events) and z['previous']==prev and digest(bare)==z['sha256'],'ledger chain')
  events.append(z); prev=z['sha256']
 require(events[0]['payload']['manifest_file_sha256']==sha(root/'rg_final_manifest.json'),'manifest commitment')
 data_events={z['payload']['label']:z for z in events if z['kind']=='target_commit'}
 score_events={z['payload']['label']:z for z in events if z['kind']=='score'}
 oracle_events={z['payload']['rep']:z for z in events if z['kind']=='oracle_commit'}
 expected={(r,s) for r in range(c['tier1_replicates']) for s in c['sources']}
 require({(z['rep'],z['source']) for z in t1['rows']}==expected and len(t1['rows'])==len(expected),'complete tier1 coverage')
 n=c['tier1_n']; total=n*c['tier1_replicates']
 v=math.isqrt(2<<(2*total))-(1<<total)
 sqrtall=np.frombuffer(format(v,f'0{total}b').encode(),dtype=np.uint8)-48
 maximum_error=0.; checked=0
 for row in t1['rows']:
  require(sha(root/row['data_file'])==row['data_sha256'],'raw tier1 hash')
  require(sha(root/row['trace_file'])==row['trace_sha256'],'trace hash')
  require(score_events[row['label']]['payload']['row_sha256']==digest(row),'row commitment')
  require(oracle_events[row['rep']]['index']<data_events[row['label']]['index']<score_events[row['label']]['index'],'commit order')
  d=loadbits(root/row['data_file']); A=d['A']; B=d['B']; rep=row['rep']
  require(len(B)==n and int(B.sum())==row['ones'],'raw counts')
  own=context(B,A,12,False); side=context(B,A,8,True)
  k=int(B.sum()); residual=int((A^B).sum())
  values={'KT':n*math.log(2)+float(betaln(k+.5,n-k+.5)-betaln(.5,.5)),
    'KT_side_residual':n*math.log(2)+float(betaln(residual+.5,n-residual+.5)-betaln(.5,.5))}
  for D in [4,8,12]: values[f'CTW_own{D}']=batch_ctw(B,own,D)
  values['CTW_side8']=batch_ctw(B,side,8)
  vals=[]
  for lag in [1,2,8,32]:
   pred=np.r_[np.zeros(lag,np.uint8),B[:-lag]]; hits=int((pred==B).sum())
   vals.extend([hits*math.log(1.5)+(n-hits)*math.log(.5),hits*math.log(.5)+(n-hits)*math.log(1.5)])
  values['lag_bank']=float(np.logaddexp.reduce(vals)-math.log(8))
  preds=[sqrtall[rep*n:(rep+1)*n],seeded(c['seed'],f'oracle/coin/{rep}',n),A^seeded(c['seed'],f'oracle/mask/{rep}',n)]
  require(oracle_events[rep]['payload']['hashes']==[ah(x) for x in preds],'oracle prediction hashes')
  vals=[]
  for pred in preds:
   k=int((pred==B).sum()); vals.append(k*math.log(2*(1-c['oracle_eta']))+(n-k)*math.log(2*c['oracle_eta']))
  values['declared_oracles']=float(np.logaddexp.reduce(vals)-math.log(3))
  for key,value in values.items():
   err=abs(value-row['gamblers'][key]['terminal_logW']); maximum_error=max(maximum_error,err)
   require(err<.001,f'terminal gambler evidence mismatch {row["label"]}/{key}: {err}')
   checked+=1
  with np.load(root/row['trace_file'],allow_pickle=False) as z:
   require(np.allclose(z['logW'][:,-1],[row['gamblers'][key]['terminal_logW'] for key in c['gamblers']],atol=1e-8,rtol=0),'trace terminal')
   require(np.allclose(np.logaddexp.reduce(z['logW'],axis=0)-math.log(len(c['gamblers'])),z['mixture']),'mixture trace')
  require(row['verdict']==('DEPENDENCE_DETECTED' if any(g['maximum_logW']>=f['planning']['individual_threshold'] for g in row['gamblers'].values()) else 'NOT_REJECTED_NOT_CERTIFIED'),'verdict rule')
 counts={m:np.zeros((4,4),np.int64) for m in c['bell_models']}; totals={m:0 for m in c['bell_models']}; genones={m:0 for m in c['bell_models']}; nt={m:0 for m in c['bell_models']}
 seen=set(); chunks=0
 for info in be['files']:
  require(info['file'] not in seen,'duplicate Bell chunk'); seen.add(info['file'])
  require(sha(root/info['file'])==info['sha256'],'Bell raw hash')
  d=loadbits(root/info['file']); T=d['T'].astype(bool); X=d['X']; Y=d['Y']; A=d['A']; B=d['B']; m=info['model']
  require(info['start']==totals[m] and len(T)==info['n'],'Bell chronology')
  totals[m]+=len(T); nt[m]+=int(T.sum()); genones[m]+=int(A[~T].sum())
  counts[m]+=np.bincount(4*(2*X[T]+Y[T])+2*A[T]+B[T],minlength=16).reshape(4,4); chunks+=1
 for row in be['models']:
  m=row['model']; require(totals[m]==c['bell_n_per_model'] and nt[m]==row['test_rounds'],'Bell sample size')
  require(counts[m].tolist()==row['test_counts_xy_ab'] and genones[m]==row['generation_A_ones'],'Bell sufficient statistics')
  wins=sum(int(counts[m][xy,ab]) for xy in range(4) for ab in range(4) if ((ab>>1)^(ab&1))==((xy>>1)&(xy&1)))
  require(wins==row['test_wins'],'Bell wins')
 require(cert['physical_certified_bits']==0 and cert['physical_luck_certificate']=='NOT_ISSUED','false physical certificate')
 require(events[-1]['payload']['certificate_sha256']==sha(root/'rg_final_certificate.json'),'certificate hash')
 require(events[-1]['payload']['report_sha256']==sha(root/'RG_luck_final_report.md'),'report hash')
 result={'verified':True,'independent_of_generator_module':True,'tier1_records':len(t1['rows']),
   'all_gambler_terminal_evidences_recomputed':checked,'batch_CTW_uses_counts_not_sequential_update':True,
   'maximum_absolute_log_evidence_discrepancy':maximum_error,'bell_raw_chunks_recounted':chunks,
   'ledger_events_verified':len(events),'physical_entropy_or_external_chronology_attested':False,
   'scope':'Independent terminal-score/raw-data audit; does not independently replay every anytime maximum.'}
 (root/'rg_final_independent_verification.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(result,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser(); p.add_argument('--out',default='.'); run(p.parse_args().out)
