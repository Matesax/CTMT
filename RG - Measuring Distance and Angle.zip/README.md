# Measuring Distance and Angle: battery

This bundle is the companion **Measuring Distance and Angle: Units, Anchors, the Geometer and the Operationalist, with an Underwater Protocol**. It contains:
- `RG - Measuring Distance and Angle.pdf` and its `.tex`;
- the library `rg_underwater.py`;
- the units library `rg_units.py`;
- the battery `rg_underwater_battery.py`, its mutation suite and its reference results;
- the main print in `Resolution Geometry.pdf`.

Run `python3 -I rg_underwater_battery.py` (about 40 s), then `python3 -I rg_underwater_battery_mutations.py --jobs 3` (about 4 min).
Needs numpy and mpmath. Seeds: 1601 (waveforms, stream [1601, case index]), 1602 (admissible media), 1603 (dilations), 1604 (point sets).
Reruns are byte-identical, including from a fresh unzip in another directory.

The battery has 11 groups, all of which pass, and 27 mutations, all of which are caught. A mutation counts as caught only when the group it targets fails. A crash does not count as a catch.

| Group | Claim |
|---|---|
| UA | ray formulas against an independent Snell polyline; joint dilation; Fermat minimum; the 1500 m/s miss of 3.58 cm |
| UB | certified arrival fibre over seven records; the overlap peak moves 10 us at score 0.988 while the fibre holds the truth within 0.71 us; clean record 4.9 us; noise wall 33 us; band remedy x6.3; echo-floor No-Go |
| UC | two references exact (rationals); one reference 5.59 cm; declared zero offset -4.13 cm; held-out reference rejects a curved latency; timebase scale |
| UD | ratio invariant under dilation to 6e-50; horizontal reference 13.26 cm against vertical 1.20 mm; anchored enclosure 28.2 cm -> 3.85 cm; shape stays open |
| UE | certified enclosures (113-bit intervals); 200 admissible media inside; per-task locks; conflicting angle empties the set; a cover without a member does not lock |
| UF | reference bearing exact; 1.01 deg miss without it; front/back cone; endfire 0.86 -> 7.09 deg; three different directions |
| UG | joined protocol with a derived timing bound: two locks, one unresolved, one no-direct; the peak +- 6 us budget excludes the truth under a calibrated profile |
| UH | anchors act through records: acoustic unit hole (1,1,0); the SI speed of light declared but absent from the records predicts no hole, yet the dilation stays in the kernel; hole typing (unit, then offset) |
| UI | SI square in exact rationals: the acoustic route traced to an optical reference returns the optical distance; declared speed misses 3.43 cm; light in air read as vacuum misses 2.7 cm per 100 m |
| UJ | geometer against operationalist: five readings 12.350-12.517 m in layered water; all agree to 1e-12 in uniform water; vertical ray; the operational metric is a metric but not proportional to h |
| UK | statistical distance is dilation-blind and d_phys = d_RG / lambda; statistical angle equals physical angle iff the Fisher metric is isotropic (ring yes; lines 78.6 vs 45 and 139.0 vs 90 deg); one receiver has no angle |

Limits:
- All fixtures are synthetic.
- Horizontal layers, a stationary and reciprocal medium, a direct ray and two arrivals are declared.
- The noise set is a declared energy bound, checked against each seed.
- The Fisher kernels in UH are numerical.
