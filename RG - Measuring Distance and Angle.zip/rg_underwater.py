"""Resolution Geometry - distance and angle under water: library.

Five separate tasks, each with its own hole and its own anchor:
  arrival    which delay belongs to the direct path      -> fibre over admissible multipath decompositions
  clock      seconds and the instrument offset           -> traceable timebase + two surveyed reference lengths
  medium     metres from seconds                         -> the dilation (common speed) is quotiented by a reference
                                                            ratio; the profile shape needs a bounded profile
  geometry   ray length, chord, offset, angles            -> certified interval enclosure over the declared family
  direction  bearing from a differential delay            -> reference direction cancels baseline and local speed
Numbers are synthetic tank fixtures (layer speeds 1480/1520 m/s, spans 6/4 m, ray parameter 4e-4 s/m).
"""
import math
from fractions import Fraction as Fr
import numpy as np
import mpmath
from mpmath import iv

mpmath.mp.dps = 50
iv.prec = 113

# ------------------------------------------------------------------ fixture
C = (1480.0, 1520.0); H = (6.0, 4.0); P = 0.0004; FS = 480000.0


def ray(p, c, h):
    """Direct ray through horizontal layers, one way. q_i = p c_i = sin(theta_i) (Snell)."""
    q = [p * ci for ci in c]; f = [math.sqrt(1 - qi * qi) for qi in q]
    path = sum(hi / fi for hi, fi in zip(h, f)); X = sum(hi * qi / fi for hi, qi, fi in zip(h, q, f))
    return dict(time=2 * sum(hi / (ci * fi) for hi, ci, fi in zip(h, c, f)), path=path, horizontal=X,
                chord=math.hypot(sum(h), X), incl_top=math.degrees(math.asin(q[0])), incl_bottom=math.degrees(math.asin(q[-1])),
                chord_incl=math.degrees(math.atan2(X, sum(h))))


def ray_polyline(p, c, h):
    """Independent construction: build the polyline from Snell's law, measure it with geometry only."""
    pts = [(0.0, 0.0)]
    for ci, hi in zip(c, h):
        th = math.asin(p * ci); x, z = pts[-1]; pts.append((x + hi * math.tan(th), z + hi))
    seg = [math.dist(a, b) for a, b in zip(pts, pts[1:])]
    return dict(path=sum(seg), time=2 * sum(s / ci for s, ci in zip(seg, c)), chord=math.dist(pts[0], pts[-1]), horizontal=pts[-1][0])


# ------------------------------------------------------------------ waveform and the arrival fibre
def pulse(t, f0=24000.0, f1=74000.0, T=0.0012):
    """Hann-windowed linear chirp, analytic in continuous time so any delay is exact."""
    t = np.asarray(t, float); inside = (t >= 0) & (t <= T)
    w = 0.5 - 0.5 * np.cos(2 * np.pi * t / T)
    s = w * np.cos(2 * np.pi * (f0 * t + 0.5 * (f1 - f0) * t * t / T))
    return np.where(inside, s, 0.0)


def pulse_slope_bound(t, f0=24000.0, f1=74000.0, T=0.0012, half=0.0):
    """Pointwise upper bound of |s'| on [t - half, t + half]: |w'| + 2 pi f(t) w, each widened by its own slope."""
    t = np.asarray(t, float); inside = (t >= -half) & (t <= T + half); tt = np.clip(t, 0, T)
    wp = np.pi / T * np.abs(np.sin(2 * np.pi * tt / T)) + (2 * np.pi / T) ** 2 / 2 * half
    w = 0.5 - 0.5 * np.cos(2 * np.pi * tt / T) + np.pi / T * half
    f = f0 + (f1 - f0) * np.clip(tt + half, 0, T) / T
    return np.where(inside, wp + 2 * np.pi * f * w, 0.0)


def record(components, sigma, seed, t0, n, **pk):
    """Samples on the counted clock n/FS, n0 = t0 * FS; components = [(amplitude, delay)]."""
    k = np.arange(n) + round(t0 * FS); tk = k / FS
    x = np.random.default_rng(seed).normal(0, sigma, n)
    for a, d in components:
        x = x + a * pulse(tk - d, **pk)
    return tk, x


def peak_pick(tk, x, gate, **pk):
    """Overlap proposal: largest normalised matched-filter peak inside the gate (what is NOT a measurement)."""
    grid = np.arange(gate[0], gate[1], 0.1e-6)
    S = np.stack([pulse(tk - g, **pk) for g in grid])
    score = np.abs(S @ x) / np.sqrt((S * S).sum(1)) / np.linalg.norm(x)
    return float(grid[int(np.argmax(score))])


def _box_qp(G11, G12, G22, b1, b2, xx, box):
    """min ||x - a1 s1 - a2 s2||^2 over a box, exactly (convex 2-D QP: interior, four edges, corners)."""
    (l1, u1), (l2, u2) = box
    rss = lambda a1, a2: xx - 2 * (a1 * b1 + a2 * b2) + a1 * a1 * G11 + 2 * a1 * a2 * G12 + a2 * a2 * G22
    best = np.full(np.shape(b1), np.inf)
    det = G11 * G22 - G12 * G12
    with np.errstate(divide='ignore', invalid='ignore'):
        a1 = (G22 * b1 - G12 * b2) / det; a2 = (G11 * b2 - G12 * b1) / det
        ok = (det > 1e-9 * G11 * G22) & (a1 >= l1) & (a1 <= u1) & (a2 >= l2) & (a2 <= u2)
        best = np.where(ok, rss(a1, a2), best)
        for v in (l1, u1):                                                   # edges a1 = v
            a2e = np.clip((b2 - v * G12) / G22, l2, u2); best = np.minimum(best, rss(v, a2e))
        for v in (l2, u2):                                                   # edges a2 = v
            a1e = np.clip((b1 - v * G12) / G11, l1, u1); best = np.minimum(best, rss(a1e, v))
    return best


def energy_bound(sigma, n, k=6.0):
    """Declared noise set ||e||^2 <= sigma^2 (n + k sqrt(2n)) (chi-square mean plus k standard deviations)."""
    return sigma * sigma * (n + k * math.sqrt(2 * n))


BOX = ((0.5, 1.5), (-1.5, 1.5))          # declared arrival family: direct present, echo of either sign


def slope_norm(tk, centers, half, **pk):
    """Certified bound of || s(. - t) - s(. - t') || / |t - t'| for |t - t'| <= half, sup over the given centres."""
    return max(float(np.linalg.norm(pulse_slope_bound(tk - g, half=half, **pk))) for g in centers)


def arrival_fibre(tk, x, sigma, gate, min_sep=2e-6, max_sep=60e-6, box=BOX, direct_first=True, k=6.0, h0=0.4e-6, levels=6, pad=True, trace=None, **pk):
    """Projection on the direct delay t1 of the set of two-arrival decompositions a1 s(t - t1) + a2 s(t - t2) that
    fit the record within the declared noise energy. Direct = FIRST arrival, present (a1 >= 0.5), and an echo trails it
    by at least min_sep (declared geometry: the shortest extra path over the speed); without that floor a coincident
    inverted echo cancels the direct arrival and absence is undecidable.
    Branch and bound on (t1, t2) cells of half-width h: a cell is discarded only when the best amplitude fit at its
    centre exceeds (sqrt(E) + (|a1| + |a2|)max D h)^2, which no member inside the cell can beat (triangle inequality
    and the slope bound D). Returns (lo, hi, cells) or None when the fibre is empty (no direct arrival in the gate)."""
    E = energy_bound(sigma, len(x), k); A = max(map(abs, box[0])) + max(map(abs, box[1])); xx = float(x @ x)
    t1 = np.arange(gate[0] + h0, gate[1], 2 * h0)
    lo2 = min_sep if direct_first else -max_sep
    d = np.arange(lo2 - h0, max_sep + 2 * h0, 2 * h0)
    T1, T2 = np.meshgrid(t1, d, indexing='ij'); cells = np.stack([T1.ravel(), (T1 + T2).ravel()], 1); h = h0
    for lev in range(levels + 1):
        u, inv = np.unique(np.round(cells / (h / 4)).astype(np.int64), return_inverse=True)
        tv = u * (h / 4); Sv = np.stack([pulse(tk - v, **pk) for v in tv]); inv = inv.reshape(-1, 2)
        nv = (Sv * Sv).sum(1); bv = Sv @ x; best = np.empty(len(inv))
        for j in range(0, len(inv), 8192):
            ii = inv[j:j + 8192]; G12 = np.einsum('ij,ij->i', Sv[ii[:, 0]], Sv[ii[:, 1]])
            best[j:j + 8192] = _box_qp(nv[ii[:, 0]], G12, nv[ii[:, 1]], bv[ii[:, 0]], bv[ii[:, 1]], xx, box)
        if pad:
            D = slope_norm(tk, tv, h, **pk)
            thr = (math.sqrt(E) + A * D * h) ** 2
        else:
            thr = E
        cells = cells[best <= thr]
        if trace is not None:
            trace.append((lev, h, len(best), len(cells)))
        if cells.size == 0:
            return None
        if lev == levels:
            break
        h = h / 2; q = np.array([[-h, -h], [-h, h], [h, -h], [h, h]])
        cells = (cells[:, None, :] + q[None]).reshape(-1, 2)
        if direct_first:
            cells = cells[cells[:, 1] - cells[:, 0] >= min_sep - 2 * h]
    return float(cells[:, 0].min() - h), float(cells[:, 0].max() + h), int(len(cells))


# ------------------------------------------------------------------ clock: offset and scale anchors
def two_reference(L1, tau1, L2, tau2):
    """tau_i = 2 L_i / c + delta: two surveyed lengths fix the medium speed and the instrument offset exactly."""
    inv = (Fr(tau2) - Fr(tau1)) / (2 * (Fr(L2) - Fr(L1))); return 1 / inv, Fr(tau1) - 2 * Fr(L1) * inv


def one_reference_range(L_ref, tau_ref, tau, delta_box):
    """With one reference the pair (c, delta) is a line; the target length runs along it."""
    vals = [Fr(L_ref) * (Fr(tau) - d) / (Fr(tau_ref) - d) for d in (Fr(delta_box[0]), Fr(delta_box[1]))]
    return min(vals), max(vals)


# ------------------------------------------------------------------ medium: the dilation quotient
def ratio_length(L_ref, tau_ref, tau):
    return L_ref * tau / tau_ref


def mp_time_along(segments, c):
    """Travel time (round trip) along given straight segments (lengths, layer index) in mp precision."""
    return 2 * sum(mpmath.mpf(s) / mpmath.mpf(c[i]) for s, i in segments)


def mp_ray(p, c, h):
    q = [mpmath.mpf(p) * mpmath.mpf(ci) for ci in c]; f = [mpmath.sqrt(1 - qi * qi) for qi in q]
    return dict(time=2 * sum(mpmath.mpf(hi) / (mpmath.mpf(ci) * fi) for hi, ci, fi in zip(h, c, f)),
                path=sum(mpmath.mpf(hi) / fi for hi, fi in zip(h, f)))


# ------------------------------------------------------------------ geometry: certified enclosures
def iv_tasks(pb, cb, h):
    """Interval images of the tasks on a ray-parameter box pb and per-layer speed boxes cb (outward rounded)."""
    q = [pb * ci for ci in cb]; f = [iv.sqrt(1 - qi * qi) for qi in q]
    X = sum(iv.mpf(hi) * qi / fi for hi, qi, fi in zip(h, q, f)); Ht = iv.mpf(sum(h))
    out = dict(time=2 * sum(iv.mpf(hi) / (ci * fi) for hi, ci, fi in zip(h, cb, f)),
               path=sum(iv.mpf(hi) / fi for hi, fi in zip(h, f)), horizontal=X, chord=iv.sqrt(Ht * Ht + X * X))
    lo, hi = ends(q[0])                                                     # sin(top inclination); asin is monotone
    out['incl_top'] = iv.mpf([_asin_deg(lo, -1), _asin_deg(hi, +1)])
    return out


def ends(v):
    """Exact endpoints of an interval (already outward rounded)."""
    return mpmath.mp.make_mpf(v._mpi_[0]), mpmath.mp.make_mpf(v._mpi_[1])


def _asin_deg(v, d):
    """asin in degrees at 50 digits, pushed outward by 1e-40 (far above the 1e-50 evaluation error)."""
    r = mpmath.degrees(mpmath.asin(max(mpmath.mpf(-1), min(mpmath.mpf(1), v))))
    return r + d * mpmath.mpf('1e-40')


def enclose(y_lo, y_hi, cbox, h, p_max=0.0006, depth=46, angle=None):
    """Certified outer enclosure of every task over {(p, c): c in cbox, round-trip time in [y_lo, y_hi], optional
    top inclination in angle}. Branch and bound on p; a box is discarded only when its interval time (or angle)
    misses the data interval. Returns status and intervals."""
    cb = [iv.mpf(list(b)) for b in cbox]
    if p_max * max(b[1] for b in cbox) >= 1:
        return dict(status='OUTSIDE_DIRECT_BRANCH')
    Y = iv.mpf([y_lo, y_hi])
    def alive(a, b):
        T = iv_tasks(iv.mpf([a, b]), cb, h)
        if T['time'].b < Y.a or T['time'].a > Y.b:
            return None
        if angle is not None and (T['incl_top'].b < angle[0] or T['incl_top'].a > angle[1]):
            return None
        return T
    boxes = [(mpmath.mpf(0), mpmath.mpf(p_max))]
    for _ in range(depth):
        nxt = []
        for a, b in boxes:
            m = (a + b) / 2
            for s in ((a, m), (m, b)):
                if alive(*s) is not None:
                    nxt.append(s)
        boxes = _merge(nxt) if len(nxt) > 64 else nxt
    if not boxes:
        return dict(status='INCONSISTENT_ENVELOPE')
    hull = {}
    for a, b in _split_fine(boxes, 64):
        T = alive(a, b)
        if T is None:
            continue
        for k, v in T.items():
            if k == 'time':
                continue
            a, b = ends(v); lo, hi = hull.get(k, (a, b)); hull[k] = (min(lo, a), max(hi, b))
    return dict(status='ENCLOSED', p=(boxes[0][0], boxes[-1][1]), hull=hull)


def _merge(boxes):
    """Keep only the two boundary fronts fine: interior boxes are merged into one (sound: a superset)."""
    boxes = sorted(boxes)
    return [boxes[0], boxes[1], (boxes[2][0], boxes[-3][1]), boxes[-2], boxes[-1]]


def _split_fine(boxes, n):
    out = []
    for a, b in boxes:
        for i in range(n):
            out.append((a + (b - a) * i / n, a + (b - a) * (i + 1) / n))
    return out


def enclose_ref(y, yref, c0, lam, dshape, h, href, p_max=0.0006, levels=40):
    """Certified enclosure when the speed profile is c_i = lam * c0_i + e_i with an unknown common dilation lam in
    a box and a bounded shape error |e_i| <= dshape. yref: round-trip time of a surveyed vertical reference through
    the spans href, or None (no medium anchor). Branch and bound over (p, lam)."""
    if p_max * (lam[1] * max(c0) + dshape) >= 1:
        return dict(status='OUTSIDE_DIRECT_BRANCH')
    Y = iv.mpf(list(y)); YR = None if yref is None else iv.mpf(list(yref)); E = iv.mpf([-dshape, dshape])
    def alive(box):
        pb, lb = iv.mpf(list(box[0])), iv.mpf(list(box[1])); cb = [lb * ci + E for ci in c0]
        T = iv_tasks(pb, cb, h)
        if T['time'].b < Y.a or T['time'].a > Y.b:
            return None
        if YR is not None:
            tr = 2 * sum(iv.mpf(hi) / ci for hi, ci in zip(href, cb))
            if tr.b < YR.a or tr.a > YR.b:
                return None
        return T
    boxes = [[(mpmath.mpf(0), mpmath.mpf(p_max)), (mpmath.mpf(lam[0]), mpmath.mpf(lam[1]))]]
    for lev in range(levels):
        j = lev % 2; nxt = []
        for bx in boxes:
            a, b = bx[j]; m = (a + b) / 2
            for s in ((a, m), (m, b)):
                nb = list(bx); nb[j] = s
                if alive(nb) is not None:
                    nxt.append(nb)
        boxes = nxt
        if not boxes:
            return dict(status='INCONSISTENT_ENVELOPE')
        if len(boxes) > 4000:
            break
    hull = {}
    for bx in boxes:
        T = alive(bx)
        for k, v in T.items():
            if k == 'time':
                continue
            a, b = ends(v); lo, hi = hull.get(k, (a, b)); hull[k] = (min(lo, a), max(hi, b))
    return dict(status='ENCLOSED', hull=hull, boxes=len(boxes))


def witness(y_lo, y_hi, c, h, p_max=0.0006, cbox=None):
    """Constructive member: a speed profile (central, then each corner of the box) and a ray parameter whose
    round-trip time lies inside the data interval. A lock needs one; a nonempty cover alone does not."""
    trials = [tuple(c)]
    if cbox is not None:
        trials += [tuple(cbox[i][(k >> i) & 1] for i in range(len(cbox))) for k in range(2 ** len(cbox))]
    y = (mpmath.mpf(y_lo) + mpmath.mpf(y_hi)) / 2
    for cc in trials:
        T = lambda p: mp_ray(p, cc, h)['time']
        if T(0) <= y <= T(p_max):
            return mpmath.findroot(lambda q: T(q) - y, (mpmath.mpf(0), mpmath.mpf(p_max)), solver='bisect', tol=mpmath.mpf('1e-40'))
    return None


def release(member, widths, tol_m=0.03, tol_deg=0.5):
    """Per task: LOCKED needs a constructive member AND a width inside its own tolerance; otherwise UNRESOLVED."""
    return {k: 'LOCKED' if (member is not None and w <= (tol_deg if k.startswith('incl') else tol_m)) else 'UNRESOLVED'
            for k, w in widths.items()}


# ------------------------------------------------------------------ direction
def bearing_direct(dtau, b, c_local):
    return math.degrees(math.asin(max(-1.0, min(1.0, c_local * dtau / b))))


def bearing_reference(dtau, dtau_ref, theta_ref_deg):
    """A source at a surveyed bearing calibrates the product b / c_local: both cancel."""
    return math.degrees(math.asin(max(-1.0, min(1.0, math.sin(math.radians(theta_ref_deg)) * dtau / dtau_ref))))


def bearing_interval(delay, e, b, c):
    """Exact image of a bounded far-field differential delay through the monotone arcsin branch."""
    lo, hi = [math.degrees(math.asin(max(-1, min(1, c * (delay + d) / b)))) for d in (-e, e)]
    return lo, hi


# ------------------------------------------------------------------ units: which anchors a record actually contains
C_SI = Fr(299792458); NU_CS = Fr(9192631770)                          # exact SI defining constants


def acoustic_records(lp, refs=()):
    """Round trips in seconds (Cs-anchored) for log-parameters (L, c_w, delta) and surveyed reference lengths."""
    L, c, d = np.exp(lp)
    return np.array([2 * L / c + d] + [2 * r / c + d for r in refs])


def optical_records(lp, n_index=1.0, refs=()):
    """Optical round trips in seconds, vacuum speed c (an SI anchor) times a group index; parameters (L, delta)."""
    L, d = np.exp(lp); c = float(C_SI)
    return np.array([2 * n_index * L / c + d] + [2 * n_index * r / c + d for r in refs])


def radar_metres(n_cycles, index=Fr(1)):
    """L102 in exact arithmetic: d = c n / (2 Delta nu_Cs), divided by a declared group index (H-med)."""
    return C_SI * Fr(n_cycles) / (2 * NU_CS * Fr(index))


# ------------------------------------------------------------------ geometer and operationalist in a layered medium
def fermat_time(A, B, c=C, zi=H[0]):
    """One-way least time between points A=(x,z), B=(x,z) of a two-layer medium (interface at depth zi).
    Same layer: straight. Across: the crossing point solves Snell's law (bisection on the increasing derivative)."""
    (xa, za), (xb, zb) = A, B
    la, lb = (0 if za < zi else 1), (0 if zb < zi else 1)
    if la == lb:
        return math.dist(A, B) / c[la]
    if la == 1:
        (xa, za), (xb, zb), la, lb = (xb, zb), (xa, za), lb, la
    g = lambda x: (x - xa) / (c[0] * math.hypot(x - xa, zi - za)) - (xb - x) / (c[1] * math.hypot(xb - x, zb - zi))
    lo, hi = min(xa, xb) - 1.0, max(xa, xb) + 1.0
    for _ in range(200):
        m = (lo + hi) / 2
        if g(m) > 0:
            hi = m
        else:
            lo = m
    x = (lo + hi) / 2
    return math.hypot(x - xa, zi - za) / c[0] + math.hypot(xb - x, zb - zi) / c[1]


def fisher_position(target, receivers, sigma, N=1, c=1500.0):
    """Fisher metric of a target position (x, z) from N two-way delays per receiver in uniform water, noise sigma."""
    g = np.zeros((2, 2))
    for r in receivers:
        d = np.subtract(target, r); u = d / np.linalg.norm(d); grad = 2 * u / c
        g += N * np.outer(grad, grad) / sigma ** 2
    return g


def stat_angle(g, u, w):
    u, w = np.asarray(u, float), np.asarray(w, float)
    return math.degrees(math.acos(max(-1.0, min(1.0, float(u @ g @ w) / math.sqrt(float(u @ g @ u) * float(w @ g @ w))))))
