#!/usr/bin/env python3
"""Resolution Geometry - hostile battery for distance and angle under water (rg_underwater.py).

  UA truth and units: the layered-ray formulas agree with an independent Snell polyline (1e-12); a joint dilation of
     lengths, speeds and slowness leaves seconds fixed (the medium has no internal unit); the Snell ray is the fastest
     of nearby polylines with the same ends (Fermat); the fixed 1500 m/s shortcut misses the ray length by 3.58 cm
  UB arrival: overlap proposes, the fibre decides. The direct delay is the projection of every two-arrival
     decomposition that fits the record inside the declared noise energy (certified branch and bound). A close echo
     moves the overlap peak by 10 us (outside a 6 us budget) at a normalised score above 0.9, while the fibre holds the
     truth inside 0.71 us; a clean record leaves 4.9 us, not the peak's apparent sub-microsecond; high noise opens a
     wall (fibre wider than 30 us); a wider band closes the 4 us case by a factor above 5; without the declared echo
     floor an inverted coincident echo cancels the direct arrival and absence becomes undecidable; with it, dropout
     returns an empty fibre
  UC clock anchors: tau = 2L/c + delta has two holes (scale and offset); two surveyed references fix both exactly
     (rationals); one reference leaves a line along which the target moves 5.5 cm for a 0-50 us offset box, and a
     declared zero offset biases it 4.1 cm; a held-out third reference passes the affine clock and rejects a
     range-curved latency; a timebase scale error scales every length by the same factor
  UD medium anchor: the reference ratio L_ref tau / tau_ref is exactly invariant under a common dilation of the
     profile (1e-40) and exact in a uniform medium; in layered water a horizontal reference misses by more than 10 cm
     and a vertical reference through the same layers by under 2 mm; with a 1% unknown common speed the enclosure of
     the ray length shrinks from above 25 cm to under 6 cm once a vertical reference is timed; the shape stays a hole
  UE certified geometry: interval enclosures (outward rounded, 113-bit) contain the truth and every one of 200 seeded
     admissible media; they reproduce the outer widths of an independent monotone-envelope replay (2.6656 cm, 4.4517 cm, 0.16116 deg) and the 33.24 cm
     wide case; ray length, chord and inclination lock at 3 cm / 0.5 deg while the horizontal offset does not; a
     wrong angle empties the set; a witness exists for every lock
  UF direction: a reference source at a surveyed bearing cancels both baseline and local speed (exact); the direct
     formula with 1% / 2% errors misses by more than 0.9 deg; one baseline cannot tell theta from 180 - theta; the
     bounded-delay bearing widens from 0.86 deg at broadside to 7.09 deg at 89 deg; the local arrival angle, the
     inclination at the far end and the chord bearing are three different numbers and the chord lies outside the
     arrival enclosure
  UG joined pipeline: the fibre interval (not an assumed budget) is carried into the geometry; clean and near-echo
     records lock the ray length, the noisy record does not, dropout returns NO_DIRECT; with a well-calibrated profile
     the peak-plus-6-us interval excludes the true ray length and the fibre interval contains it
  UH anchors act through records: with only the caesium clock in the acoustic record the unit hole is (1,1,0) in
     (log L, log c_w, log delta) and lies in the Fisher kernel; declaring the SI speed of light predicts no hole, yet
     the kernel keeps it; one reference removes the unit part, the offset is intrinsic, two references empty the
     kernel; optical timing in vacuum has no unit part
  UI the SI square in exact rationals: the acoustic route traced to an optically surveyed reference returns the
     optical distance; a declared water speed misses 3.43 cm; light in air read as vacuum misses 2.7 cm per 100 m
  UJ geometer against operationalist: chord, ray length, radar at 1500 m/s and two reference ratios are five
     different numbers in layered water and agree to 1e-12 in uniform water; on a vertical ray ray = chord = vertical
     ratio but not radar; least-time distance is a metric (triangle inequality) not proportional to Euclidean
  UK statistical against physical: d_RG is dilation-blind and d_RG / lambda gives metres once c_w is anchored; the
     statistical angle equals the physical one for a ring of receivers and not for line arrays; one receiver has
     rank one and no angle

Seeds 1601 (waveforms; stream [1601, case index]), 1602 (admissible media), 1603 (dilations), 1604 (point sets).
Writes rg_underwater_battery_results.json.
Run:  python3 -I rg_underwater_battery.py     (numpy, mpmath)
"""
import hashlib, itertools, json, math, os, sys
from fractions import Fraction as Fr
from pathlib import Path
import numpy as np
import mpmath

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rg_underwater as W
import rg_units as U

R, FAILS = {}, []
TRUTH = W.ray(W.P, W.C, W.H); TAU = TRUTH['time']
T0 = TAU - 0.2e-3; NS = int(1.9e-3 * W.FS)
GATE = (round(TAU * 1e6) / 1e6 - 30e-6, round(TAU * 1e6) / 1e6 + 30e-6)
CBOX = [(c - 0.5, c + 0.5) for c in W.C]
CASES = {'clean': ([(1.0, TAU)], 0.045, {}),
         'near_echo_20us': ([(1.0, TAU), (0.9, TAU + 20e-6)], 0.045, {}),
         'near_echo_4us': ([(1.0, TAU), (0.9, TAU + 4e-6)], 0.045, {}),
         'inverted_echo_4us': ([(1.0, TAU), (-0.9, TAU + 4e-6)], 0.045, {}),
         'noisy_4us': ([(1.0, TAU), (0.9, TAU + 4e-6)], 0.3, {}),
         'wideband_4us': ([(1.0, TAU), (0.9, TAU + 4e-6)], 0.045, dict(f1=174000.0)),
         'dropout': ([(1.6, TAU + 2.1e-3)], 0.045, {})}
FIBRE = {}


def must(cond, tag):
    if not cond:
        if tag not in FAILS:
            FAILS.append(tag)
        print('FAILED', tag, flush=True)


def r6(v):
    return None if v is None else float('%.6g' % v)


def fibre(name):
    if name not in FIBRE:
        comp, sig, pk = CASES[name]
        tk, x = W.record(comp, sig, [1601, list(CASES).index(name)], T0, NS, **pk)
        e = x - sum(a * W.pulse(tk - d, **pk) for a, d in comp)
        fb = W.arrival_fibre(tk, x, sig, GATE, **pk)
        p = W.peak_pick(tk, x, (TAU - 1e-4, TAU + 1e-4), **pk)
        grid = np.array([p]); s = W.pulse(tk - p, **pk)
        score = abs(float(s @ x)) / float(np.linalg.norm(s) * np.linalg.norm(x))
        FIBRE[name] = dict(tk=tk, x=x, sig=sig, pk=pk, fb=fb, peak=p, score=score,
                           noise_ratio=float(e @ e) / W.energy_bound(sig, NS))
    return FIBRE[name]


def us(v):
    return r6((v - TAU) * 1e6)


# ------------------------------------------------------------------ UA
def group_UA():
    out = {}
    poly = W.ray_polyline(W.P, W.C, W.H)
    out['polyline_gap'] = max(abs(poly[k] - TRUTH[k]) / TRUTH[k] for k in ('path', 'time', 'chord', 'horizontal'))
    must(out['polyline_gap'] < 1e-12, 'UA')
    for lam in (2.0, 0.37, 11.0):                                   # lengths and speeds dilated together, slowness inversely
        d = W.ray(W.P / lam, tuple(lam * c for c in W.C), tuple(lam * h for h in W.H))
        must(abs(d['time'] - TAU) < 1e-15 and abs(d['path'] / lam - TRUTH['path']) < 1e-12 and abs(d['incl_top'] - TRUTH['incl_top']) < 1e-12, 'UA')
    dims = dict(speed=(1, -1), slowness=(-1, 1), time=(0, 1))
    add = lambda a, b: tuple(i + j for i, j in zip(a, b))
    must(add(dims['speed'], dims['time']) == (1, 0) and add(dims['slowness'], dims['time']) != (1, 0), 'UA')
    # Fermat: polylines with the same ends and moved interface crossing are slower
    X1 = W.H[0] * math.tan(math.asin(W.P * W.C[0])); Xend = TRUTH['horizontal']
    def T_of(x1):
        return 2 * (math.hypot(x1, W.H[0]) / W.C[0] + math.hypot(Xend - x1, W.H[1]) / W.C[1])
    deltas = [T_of(X1 + d) - T_of(X1) for d in (-0.05, -0.01, 0.01, 0.05)]
    out['fermat_min_excess_s'] = min(deltas)
    must(min(deltas) > 0 and abs(T_of(X1) - TAU) < 1e-15, 'UA')
    out['naive_1500_error_m'] = 1500 * (TAU + 2e-6) / 2 - TRUTH['path']
    must(0.035 < out['naive_1500_error_m'] < 0.036 and out['naive_1500_error_m'] > 0.03, 'UA')
    out['truth'] = {k: r6(v) for k, v in TRUTH.items()}
    R['UA'] = out


# ------------------------------------------------------------------ UB
def group_UB():
    out = {}
    for name in CASES:
        f = fibre(name)
        must(f['noise_ratio'] <= 1.0, 'UB')                        # the declared noise set holds for the seed
        row = dict(noise_ratio=r6(f['noise_ratio']), peak_error_us=us(f['peak']), score=r6(f['score']))
        if f['fb'] is None:
            row['fibre'] = 'EMPTY'
        else:
            lo, hi, cells = f['fb']; row.update(fibre_us=[us(lo), us(hi)], width_us=r6((hi - lo) * 1e6))
            if name != 'dropout':
                must(lo <= TAU <= hi, 'UB')                        # the fibre holds the truth
        out[name] = row
    ne = out['near_echo_20us']
    must(abs(ne['peak_error_us']) > 6 and ne['score'] > 0.9 and ne['width_us'] < 1.0, 'UB')   # counterexample + repair
    must(out['clean']['width_us'] > 3 and out['clean']['width_us'] < 6 and abs(out['clean']['peak_error_us']) < 0.2, 'UB')
    must(out['noisy_4us']['width_us'] > 30, 'UB')                  # the wall at this noise
    must(out['near_echo_4us']['width_us'] > 5 * out['wideband_4us']['width_us'], 'UB')        # bandwidth repairs it
    must(out['dropout'].get('fibre') == 'EMPTY', 'UB')
    f = fibre('dropout')                                            # without the echo floor, absence is undecidable
    fb0 = W.arrival_fibre(f['tk'], f['x'], f['sig'], GATE, min_sep=0.0)
    out['dropout_without_echo_floor'] = None if fb0 is None else [us(fb0[0]), us(fb0[1])]
    must(fb0 is not None and fb0[1] - fb0[0] > 50e-6, 'UB')
    R['UB'] = out


# ------------------------------------------------------------------ UC
def group_UC():
    out = {}; c = Fr(1500); delta = Fr(37, 10 ** 6)
    tau = lambda L: 2 * Fr(L) / c + delta
    c_hat, d_hat = W.two_reference(5, tau(5), 10, tau(10))
    must(c_hat == c and d_hat == delta, 'UC')
    L = Fr(12482924720280682, 10 ** 15)
    target = c_hat * (tau(L) - d_hat) / 2
    must(target == L, 'UC')
    lo, hi = W.one_reference_range(5, tau(5), tau(L), (0, Fr(50, 10 ** 6)))
    out['one_reference_width_m'] = float(hi - lo)
    must(hi - lo > Fr(3, 100) and lo <= L <= hi, 'UC')
    biased = Fr(5) * tau(L) / tau(5)
    out['declared_zero_offset_bias_m'] = float(biased - L)
    must(abs(biased - L) > Fr(3, 100), 'UC')
    pred = 2 * Fr(15, 2) / c_hat + d_hat                             # held-out reference at 7.5 m
    out['held_out_residual_affine_s'] = float(tau(Fr(15, 2)) - pred)
    must(tau(Fr(15, 2)) == pred, 'UC')
    curved = lambda Lx: 2 * Fr(Lx) / c + delta + Fr(8, 10 ** 8) * (Fr(Lx) - Fr(15, 2)) ** 2
    c2, d2 = W.two_reference(5, curved(5), 10, curved(10))
    res = curved(Fr(15, 2)) - (2 * Fr(15, 2) / c2 + d2)
    out['held_out_residual_curved_s'] = float(res)
    must(abs(res) > Fr(2, 10 ** 7), 'UC')                           # rejects the affine clock at a 0.2 us budget
    eps = Fr(1, 10 ** 6)                                             # timebase scale error
    c3, d3 = W.two_reference(5, tau(5) * (1 + eps), 10, tau(10) * (1 + eps))
    must(c3 * (tau(L) * (1 + eps) - d3) / 2 == L and c3 == c / (1 + eps), 'UC')
    R['UC'] = out


# ------------------------------------------------------------------ UD
def group_UD():
    out = {}; rng = np.random.default_rng(1603)
    mt = W.mp_ray(W.P, W.C, W.H)
    vert = 2 * sum(mpmath.mpf(h) / mpmath.mpf(c) for h, c in zip(W.H, W.C))
    horiz = 2 * mpmath.mpf(5) / mpmath.mpf(W.C[0])
    est_v = W.ratio_length(mpmath.mpf(sum(W.H)), vert, mt['time']); est_h = W.ratio_length(mpmath.mpf(5), horiz, mt['time'])
    out['vertical_reference_error_m'] = float(est_v - mt['path']); out['horizontal_reference_error_m'] = float(est_h - mt['path'])
    must(abs(est_v - mt['path']) < 0.002 and abs(est_h - mt['path']) > 0.10, 'UD')
    worst = mpmath.mpf(0)
    for lam in rng.uniform(0.9, 1.1, 8):
        lam = mpmath.mpf(float(lam)); cl = [lam * mpmath.mpf(c) for c in W.C]
        m2 = W.mp_ray(mpmath.mpf(W.P) / lam, cl, W.H)
        v2 = 2 * sum(mpmath.mpf(h) / c for h, c in zip(W.H, cl))
        worst = max(worst, abs(W.ratio_length(mpmath.mpf(sum(W.H)), v2, m2['time']) - est_v), abs(m2['path'] - mt['path']))
    out['dilation_invariance'] = float(worst)
    must(worst < mpmath.mpf('1e-40'), 'UD')
    cu = (1500.0, 1500.0); mu = W.mp_ray(W.P, cu, W.H)
    vu = 2 * sum(mpmath.mpf(h) / mpmath.mpf(c) for h, c in zip(W.H, cu))
    must(abs(W.ratio_length(mpmath.mpf(sum(W.H)), vu, mu['time']) - mu['path']) < mpmath.mpf('1e-40'), 'UD')
    y = (TAU - 4e-6, TAU + 8e-6); tv = float(vert) + 0.3e-6; yref = (tv - 1e-6, tv + 1e-6)
    free = W.enclose_ref(y, None, W.C, (0.99, 1.01), 0.5, W.H, W.H)
    anch = W.enclose_ref(y, yref, W.C, (0.99, 1.01), 0.5, W.H, W.H)
    shape = W.enclose_ref(y, yref, W.C, (0.99, 1.01), 3.0, W.H, W.H)
    wid = lambda e: float(e['hull']['path'][1] - e['hull']['path'][0])
    out.update(path_width_no_reference_m=r6(wid(free)), path_width_vertical_reference_m=r6(wid(anch)), path_width_reference_shape3_m=r6(wid(shape)))
    for e in (free, anch, shape):
        must(all(a <= TRUTH[k] <= b for k, (a, b) in e['hull'].items()), 'UD')
    must(wid(free) > 0.25 and wid(anch) < 0.06 and wid(shape) > 2 * wid(anch), 'UD')
    R['UD'] = out


# ------------------------------------------------------------------ UE
def group_UE():
    out = {}; y = TAU + 2e-6; ang = TRUTH['incl_top'] + 0.04
    base = W.enclose(y - 6e-6, y + 6e-6, CBOX, W.H)
    joint = W.enclose(y - 6e-6, y + 6e-6, CBOX, W.H, angle=(ang - 0.15, ang + 0.15))
    wide = W.enclose(y - 6e-6, y + 6e-6, [(c - 15, c + 15) for c in W.C], W.H, angle=(ang - 0.15, ang + 0.15))
    bad = W.enclose(y - 6e-6, y + 6e-6, CBOX, W.H, angle=(ang + 3 - 0.15, ang + 3 + 0.15))
    must(bad['status'] == 'INCONSISTENT_ENVELOPE', 'UE')
    must(W.enclose(y - 6e-6, y + 6e-6, CBOX, W.H, p_max=0.0007)['status'] == 'OUTSIDE_DIRECT_BRANCH', 'UE')
    widths = {k: float(b - a) for k, (a, b) in base['hull'].items()}
    out['widths'] = {k: r6(v) for k, v in widths.items()}
    out['wide_path_width_m'] = r6(float(wide['hull']['path'][1] - wide['hull']['path'][0]))
    for e in (base, joint, wide):
        must(all(a <= TRUTH[k] <= b for k, (a, b) in e['hull'].items()), 'UE')
    must(abs(widths['path'] - 0.026656) < 2e-6 and abs(widths['horizontal'] - 0.044517) < 2e-6 and abs(widths['incl_top'] - 0.161163) < 2e-6, 'UE')
    must(abs(out['wide_path_width_m'] - 0.33242) < 2e-5, 'UE')
    p0 = W.witness(y - 6e-6, y + 6e-6, W.C, W.H, cbox=CBOX)
    locks = {k: v == 'LOCKED' for k, v in W.release(p0, widths).items()}
    out['locks'] = locks
    must(locks == dict(path=True, chord=True, incl_top=True, horizontal=False), 'UE')
    # a cover without a member: data just above the largest time the declared family reaches (steep rays, where the
    # round-trip time grows with speed) still meets the interval cover, which overestimates; no witness exists
    pm = 0.0006; tmax = W.ray(pm, [b for a, b in CBOX], W.H)['time']
    gap = W.enclose(tmax + 2e-6, tmax + 6e-6, CBOX, W.H, p_max=pm)
    pg = W.witness(tmax + 2e-6, tmax + 6e-6, W.C, W.H, p_max=pm, cbox=CBOX)
    gw = {k: float(b - a) for k, (a, b) in gap['hull'].items()} if gap['status'] == 'ENCLOSED' else {}
    gl = {k: v == 'LOCKED' for k, v in W.release(pg, gw).items()}
    out['cover_without_member'] = dict(status=gap['status'], witness=pg is not None, incl_width_deg=r6(gw.get('incl_top', 0)), locks=gl)
    must(gap['status'] == 'ENCLOSED' and pg is None and gw['incl_top'] < 0.5 and not any(gl.values()), 'UE')
    rng = np.random.default_rng(1602); escaped = 0
    for _ in range(200):                                            # admissible media and delays, solved exactly
        c = [rng.uniform(a, b) for a, b in CBOX]; d = rng.uniform(-6e-6, 6e-6)
        p = mpmath.findroot(lambda q: W.mp_ray(q, c, W.H)['time'] - (y + d), (mpmath.mpf(0), mpmath.mpf(0.0006)), solver='bisect', tol=mpmath.mpf('1e-30'))
        m = W.ray(float(p), c, W.H)
        escaped += not all(a <= m[k] <= b for k, (a, b) in base['hull'].items())
    out['admissible_draws_escaped'] = escaped
    must(escaped == 0, 'UE')
    R['UE'] = out


# ------------------------------------------------------------------ UF
def group_UF():
    out = {}; b, c, th, th_ref = 0.2, 1500.0, 30.0, 10.0
    dt = b * math.sin(math.radians(th)) / c; dt_ref = b * math.sin(math.radians(th_ref)) / c
    out['reference_error_deg'] = abs(W.bearing_reference(dt, dt_ref, th_ref) - th)
    out['direct_error_deg'] = abs(W.bearing_direct(dt, b * 0.99, c * 1.02) - th)
    must(out['reference_error_deg'] < 1e-12 and out['direct_error_deg'] > 0.9, 'UF')
    must(abs(b * math.sin(math.radians(180 - th)) / c - dt) < 1e-18, 'UF')                    # front/back: one cone
    fr = {}
    for deg in (0, 45, 80, 89):
        lo, hi = W.bearing_interval(b * math.sin(math.radians(deg)) / c, 1e-6, b, c); fr[deg] = r6(hi - lo)
    out['endfire_width_deg'] = fr
    must(abs(fr[0] - 0.859445) < 1e-5 and abs(fr[89] - 7.09269) < 1e-4 and fr[89] > 8 * fr[0], 'UF')
    three = (TRUTH['incl_top'], TRUTH['incl_bottom'], TRUTH['chord_incl'])
    out['angles_deg'] = dict(arrival_top=r6(three[0]), far_end=r6(three[1]), chord=r6(three[2]))
    y = TAU + 2e-6; e = W.enclose(y - 6e-6, y + 6e-6, CBOX, W.H); a, bb = e['hull']['incl_top']
    must(min(abs(three[0] - three[1]), abs(three[0] - three[2]), abs(three[1] - three[2])) > 0.4 and not (a <= three[2] <= bb), 'UF')
    R['UF'] = out


# ------------------------------------------------------------------ UG
def group_UG():
    out = {}; tight = [(c - 0.05, c + 0.05) for c in W.C]
    for name in ('clean', 'near_echo_20us', 'noisy_4us', 'dropout'):
        f = fibre(name)
        if f['fb'] is None:
            out[name] = dict(status='NO_DIRECT'); continue
        lo, hi = f['fb'][0], f['fb'][1]
        e = W.enclose(lo * (1 - 1e-6), hi * (1 + 1e-6), CBOX, W.H)
        w = float(e['hull']['path'][1] - e['hull']['path'][0]); p0 = W.witness(lo, hi, W.C, W.H, cbox=CBOX)
        out[name] = dict(status=W.release(p0, {'path': w})['path'], path_width_m=r6(w),
                         contains_truth=bool(e['hull']['path'][0] <= TRUTH['path'] <= e['hull']['path'][1]))
        must(out[name]['contains_truth'], 'UG')
    must(out['clean']['status'] == 'LOCKED' and out['near_echo_20us']['status'] == 'LOCKED', 'UG')
    must(out['noisy_4us']['status'] == 'UNRESOLVED' and out['dropout']['status'] == 'NO_DIRECT', 'UG')
    f = fibre('near_echo_20us'); pk = f['peak']
    lo, hi = f['fb'][0], f['fb'][1]
    e_f = W.enclose(lo * (1 - 1e-6), hi * (1 + 1e-6), tight, W.H)
    e_p = W.enclose((pk - 6e-6) * (1 - 1e-6), (pk + 6e-6) * (1 + 1e-6), tight, W.H)
    inside = lambda e: bool(e['hull']['path'][0] <= TRUTH['path'] <= e['hull']['path'][1])
    out['calibrated_profile'] = dict(fibre_contains_truth=inside(e_f), peak_budget_contains_truth=inside(e_p),
                                     peak_budget_low_m=r6(float(e_p['hull']['path'][0] - TRUTH['path'])))
    must(inside(e_f) and not inside(e_p), 'UG')
    R['UG'] = out


# ------------------------------------------------------------------ UH
def group_UH():
    """Hole typing: which part of the acoustic hole is a unit and which anchor closes it."""
    out = {}; lp = np.log([12.48, 1496.0, 37e-6])
    Dsys = np.stack([U.dim(L=1), U.dim(L=1, T=-1), U.dim(T=1)], 1)
    hole_cs = U.unit_hole(Dsys, np.stack([U.dim(T=-1)], 1))
    hole_nominal = U.unit_hole(Dsys, np.stack([U.dim(T=-1), U.dim(L=1, T=-1)], 1))
    K0, s0 = U.fisher_kernel(lambda p: W.acoustic_records(p), lp)
    K1, s1 = U.fisher_kernel(lambda p: W.acoustic_records(p, (5.0,)), lp)
    K2, s2 = U.fisher_kernel(lambda p: W.acoustic_records(p, (5.0, 10.0)), lp)
    inside = lambda v, K: float(np.linalg.norm(v - K @ (K.T @ v)))
    must(hole_cs.shape[1] == 1, 'UH')
    if hole_cs.shape[1] != 1:                                # a failed prediction is a failure, not a crash
        R['UH'] = out; return
    out['kernel_dims'] = [K0.shape[1], K1.shape[1], K2.shape[1]]
    out['unit_direction'] = [r6(abs(x)) for x in hole_cs[:, 0]]
    out['unit_in_kernel_residual'] = r6(inside(hole_cs[:, 0], K0))
    out['nominal_si_hole_dims'] = hole_nominal.shape[1]
    out['unit_after_reference_residual'] = r6(inside(hole_cs[:, 0], K1))
    must(K0.shape[1] == 2 and hole_cs.shape[1] == 1 and inside(hole_cs[:, 0], K0) < 1e-6, 'UH')       # predicted unit hole
    must(hole_nominal.shape[1] == 0, 'UH')               # SI c declared but absent from the records: predicts no hole ...
    must(inside(hole_cs[:, 0], K0) < 1e-6, 'UH')        # ... yet the dilation is in the kernel: anchors act through records
    must(K1.shape[1] == 1 and inside(hole_cs[:, 0], K1) > 0.5, 'UH')     # one reference closes the unit part only
    must(K2.shape[1] == 0, 'UH')                         # the intrinsic offset needs a second reference
    Ko, so = U.fisher_kernel(lambda p: W.optical_records(p), np.log([12.48, 37e-6]))
    Kr, sr = U.fisher_kernel(lambda p: W.optical_records(p, refs=(5.0,)), np.log([12.48, 37e-6]))
    hole_opt = U.unit_hole(np.stack([U.dim(L=1), U.dim(T=1)], 1), np.stack([U.dim(T=-1), U.dim(L=1, T=-1)], 1))
    out['optical_kernel_dims'] = [Ko.shape[1], Kr.shape[1]]
    must(hole_opt.shape[1] == 0 and Ko.shape[1] == 1 and Kr.shape[1] == 0, 'UH')   # vacuum: no unit hole, offset only
    R['UH'] = out


# ------------------------------------------------------------------ UI
def group_UI():
    """The SI square commutes through a traceable reference, and only through it (exact rationals)."""
    out = {}; L = Fr(12482924720280682, 10 ** 15); Lref = Fr(5); cw = Fr(149589, 100)
    n_ref = 2 * W.NU_CS * Lref / W.C_SI                                    # optical cycles (interpolated count)
    n_tgt = 2 * W.NU_CS * L / W.C_SI
    route_a = W.radar_metres(n_tgt)                                         # optical radar in vacuum (L102)
    ref_si = W.radar_metres(n_ref)                                          # the reference, surveyed optically
    tau, tau_ref = 2 * L / cw, 2 * Lref / cw                                # acoustic round trips, offset removed
    route_b = ref_si * tau / tau_ref                                        # acoustic, traced to the optical reference
    must(route_a == L and ref_si == Lref and route_b == L, 'UI')
    route_c = Fr(1500) * tau / 2                                            # acoustic with a declared speed
    out['declared_speed_miss_m'] = float(route_c - L)
    must(route_c != L and abs(route_c - L) > Fr(1, 100), 'UI')
    n_air = 1 + Fr(27, 100000)                                              # optical in air: the index is a medium hole
    L100 = Fr(100); n_air_cycles = 2 * W.NU_CS * n_air * L100 / W.C_SI
    out['air_without_index_miss_m'] = float(W.radar_metres(n_air_cycles) - L100)
    must(W.radar_metres(n_air_cycles) != L100 and W.radar_metres(n_air_cycles, n_air) == L100, 'UI')
    must(abs(W.radar_metres(n_air_cycles) - L100 - Fr(27, 1000)) < Fr(1, 10 ** 12), 'UI')
    for lam in (Fr(1, 2), Fr(3), Fr(1001, 1000)):                           # no internal unit: the acoustic records
        must((2 * lam * L) / (lam * cw) == tau, 'UI')                       # cannot tell (L, c_w) from (lam L, lam c_w)
    out['cycles_per_metre_round_trip'] = float(2 * W.NU_CS / W.C_SI)
    R['UI'] = out


# ------------------------------------------------------------------ UJ
def group_UJ():
    """Geometer and operationalist: five distances, and the conditions under which they commute."""
    out = {}; r = TRUTH; v = 1500.0
    vert = 2 * sum(h / c for h, c in zip(W.H, W.C)); horiz = 2 * 5 / W.C[0]
    d = dict(chord=r['chord'], ray=r['path'], radar_1500=v * r['time'] / 2, ratio_vertical=10 * r['time'] / vert,
             ratio_horizontal=5 * r['time'] / horiz)
    out['layered_m'] = {k: r6(x) for k, x in d.items()}
    vals = sorted(d.values())
    must(min(b - a for a, b in zip(vals, vals[1:])) > 5e-4, 'UJ')          # five tasks, five numbers
    must(abs(2 * W.fermat_time((0.0, 0.0), (r['horizontal'], 10.0)) - r['time']) < 1e-12, 'UJ')
    cu = (1500.0, 1500.0)
    for p in (0.0, 0.0002, 0.0005):                                         # uniform medium: all commute
        u = W.ray(p, cu, W.H); du = [u['chord'], u['path'], v * u['time'] / 2, 10 * u['time'] / (2 * 10 / 1500.0)]
        must(max(du) - min(du) < 1e-12, 'UJ')
    z = W.ray(0.0, W.C, W.H)                                                # vertical ray in layers: ray = chord,
    must(abs(z['path'] - z['chord']) < 1e-12 and abs(10 * z['time'] / vert - z['chord']) < 1e-12, 'UJ')
    must(abs(v * z['time'] / 2 - z['chord']) > 1e-3, 'UJ')                  # but a declared speed does not commute
    rng = np.random.default_rng(1604); pts = [(rng.uniform(-10, 10), rng.uniform(0, 10)) for _ in range(30)]
    dop = lambda a, b: v * W.fermat_time(a, b)
    tri = min(dop(a, b) + dop(b, c) - dop(a, c) for a, b, c in itertools.combinations(pts[:15], 3))
    ratios = [dop(a, b) / math.dist(a, b) for a, b in itertools.combinations(pts, 2)]
    out['operational_triangle_min_excess_m'] = r6(tri); out['operational_over_euclid'] = [r6(min(ratios)), r6(max(ratios))]
    must(tri >= -1e-9 and max(ratios) - min(ratios) > 0.02, 'UJ')          # a metric, not proportional to h (L99 fails)
    R['UJ'] = out


# ------------------------------------------------------------------ UK
def group_UK():
    """Statistical distance and angle against physical ones."""
    out = {}; N, sig = 64, 1e-6
    dRG = lambda dL, c: math.sqrt(N) * 2 * dL / (c * sig)
    must(all(abs(dRG(0.01 * k, 1496 * k) - dRG(0.01, 1496)) < 1e-9 for k in (2.0, 0.5, 7.0)), 'UK')   # dilation-blind
    lam = math.sqrt(N) * 2 / (1496 * sig); out['lambda_per_m'] = r6(lam)
    must(abs(dRG(0.01, 1496) / lam - 0.01) < 1e-15, 'UK')                  # d_phys = d_RG / lambda once c_w is anchored
    ring = [(20 * math.cos(2 * math.pi * k / 12), 20 * math.sin(2 * math.pi * k / 12)) for k in range(12)]
    sym = [(-5, -20), (0, -20), (5, -20)]; asym = [(0, -20), (5, -20), (10, -20)]
    ang = {}
    for name, rec in (('ring', ring), ('symmetric_line', sym), ('offset_line', asym)):
        g = W.fisher_position((0.0, 0.0), rec, sig, N)
        ang[name] = dict(x_z=r6(W.stat_angle(g, (1, 0), (0, 1))), x_diag=r6(W.stat_angle(g, (1, 0), (1, 1))),
                         anisotropy=r6(float(np.linalg.cond(g))))
    out['statistical_angles_deg'] = ang
    must(abs(ang['ring']['x_z'] - 90) < 1e-9 and abs(ang['ring']['x_diag'] - 45) < 1e-9, 'UK')
    must(abs(ang['symmetric_line']['x_diag'] - 45) > 20 and abs(ang['offset_line']['x_z'] - 90) > 20, 'UK')
    g1 = W.fisher_position((0.0, 0.0), [(0, -20)], sig, N)                   # one receiver: rank one, no angle
    must(np.linalg.matrix_rank(g1, tol=1e-6 * np.abs(g1).max()) == 1, 'UK')
    R['UK'] = out


GROUPS = dict(UA=group_UA, UB=group_UB, UC=group_UC, UD=group_UD, UE=group_UE, UF=group_UF, UG=group_UG, UH=group_UH,
              UI=group_UI, UJ=group_UJ, UK=group_UK)


CLAIMS = dict(
    UA='layered ray formulas agree with a Snell polyline; joint dilation; Fermat minimum; fixed-speed miss 3.58 cm',
    UB='certified arrival fibre: overlap peak is not the arrival; derived timing bound; noise wall; band remedy; echo-floor No-Go',
    UC='clock anchors: two references fix scale and offset; one leaves a line; held-out reference rejects a curved latency',
    UD='medium quotient: the reference ratio removes the common dilation exactly; the profile shape stays a hole',
    UE='certified interval enclosures per task; admissible media inside; locks need a witness; a cover is not a member',
    UF='direction: a reference bearing cancels baseline and local speed; cone; endfire widening; three directions',
    UG='joined protocol: fibre interval carried into geometry; peak budget excludes the truth under a calibrated profile',
    UH='anchors act through records: acoustic unit hole (1,1,0); SI c absent from records leaves it; hole typing',
    UI='SI square in exact rationals commutes only through a record containing c; declared speed and air-as-vacuum misses',
    UJ='geometer against operationalist: five readings in layered water, all equal in uniform water; Fermat metric not proportional',
    UK='statistical distance is dilation-blind; statistical angle equals physical angle iff the Fisher metric is isotropic')


def main():
    want = os.environ.get('RG_UNDERWATER_GROUPS'); sel = want.split(',') if want else list(GROUPS)
    for g in sel:
        GROUPS[g]()                                               # a crash writes no results: never a pass, never a catch
        R[g]['claim'] = CLAIMS[g]
        print(g, 'done', flush=True)
    R['failures'] = FAILS; R['groups_run'] = sel
    R['source_sha256'] = {f: hashlib.sha256((HERE / f).read_bytes()).hexdigest() for f in ('rg_underwater.py', 'rg_units.py', 'rg_underwater_battery.py')}
    (HERE / 'rg_underwater_battery_results.json').write_text(json.dumps(R, indent=1, sort_keys=True, default=float))
    print(json.dumps({k: R[k] for k in sel}, indent=1, sort_keys=True, default=float)[:9000])
    return 1 if FAILS else 0


if __name__ == '__main__':
    sys.exit(main())
