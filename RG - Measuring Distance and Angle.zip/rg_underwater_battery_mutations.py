#!/usr/bin/env python3
"""Mutation suite for rg_underwater_battery.py.

Each mutation changes one line of the library (or of the battery's reference computation) so that a claim of the
underwater distance and angle protocol becomes false. It is caught only when the targeted group fails; the battery is run on that
group alone. A survivor is a defect of the battery; a crash is a defect of the suite, not a catch. Runs in temporary
copies.

    python3 -I rg_underwater_battery_mutations.py [--jobs 2] [--only UA,UB]
"""
import argparse, json, os, shutil, subprocess, sys, tempfile
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
NAME = 'rg_underwater_battery'
LIB = 'rg_underwater.py'
BAT = NAME + '.py'
MUTATIONS = [  # (group, description, file, old, new)
    ('UA', 'horizontal offset without the refraction factor', LIB, 'X = sum(hi * qi / fi for hi, qi, fi in zip(h, q, f))\n    return', 'X = sum(hi * qi for hi, qi in zip(h, q))\n    return'),
    ('UA', 'travel time one way, called round trip', LIB, 'return dict(time=2 * sum(hi / (ci * fi) for hi, ci, fi in zip(h, c, f)), path=path,', 'return dict(time=sum(hi / (ci * fi) for hi, ci, fi in zip(h, c, f)), path=path,'),
    ('UB', 'no echo floor: a coincident inverted echo may cancel the direct arrival', LIB, 'min_sep=2e-6, max_sep', 'min_sep=0.0, max_sep'),
    ('UB', 'direct arrival not required to be first', LIB, 'max_sep=60e-6, box=BOX, direct_first=True', 'max_sep=60e-6, box=BOX, direct_first=False'),
    ('UB', 'direct arrival allowed to vanish', LIB, 'BOX = ((0.5, 1.5), (-1.5, 1.5))', 'BOX = ((0.0, 1.5), (-1.5, 1.5))'),
    ('UB', 'noise set without its deviation margin', LIB, 'def energy_bound(sigma, n, k=6.0):', 'def energy_bound(sigma, n, k=0.0):'),
    ('UB', 'overlap peak reported as the arrival', BAT, "lo, hi, cells = f['fb']; row.update", "lo, hi, cells = f['peak'] - 6e-6, f['peak'] + 6e-6, 0; row.update"),
    ('UC', 'two-reference solve without the round-trip factor', LIB, 'inv = (Fr(tau2) - Fr(tau1)) / (2 * (Fr(L2) - Fr(L1)))', 'inv = (Fr(tau2) - Fr(tau1)) / (Fr(L2) - Fr(L1))'),
    ('UC', 'one reference with the offset taken as known', LIB, 'for d in (Fr(delta_box[0]), Fr(delta_box[1]))]', 'for d in (Fr(delta_box[0]), Fr(delta_box[0]))]'),
    ('UD', 'ratio anchor replaced by a declared speed', LIB, 'return L_ref * tau / tau_ref', 'return 1495 * tau / 2'),
    ('UD', 'reference timing ignored by the anchored enclosure', LIB, 'Y = iv.mpf(list(y)); YR = None if yref is None else iv.mpf(list(yref))', 'Y = iv.mpf(list(y)); YR = None'),
    ('UE', 'speed boxes collapsed to their centres', LIB, 'cb = [iv.mpf(list(b)) for b in cbox]\n    if p_max', 'cb = [iv.mpf((b[0] + b[1]) / 2) for b in cbox]\n    if p_max'),
    ('UE', 'a box pruned against the wrong end of the data', LIB, "        if T['time'].b < Y.a or T['time'].a > Y.b:\n            return None\n        if angle", "        if T['time'].b < Y.a or T['time'].a > Y.a:\n            return None\n        if angle"),
    ('UE', 'lock without a constructive witness', LIB, "'LOCKED' if (member is not None and w <=", "'LOCKED' if (w <="),
    ('UF', 'reference ratio inverted', LIB, 'math.sin(math.radians(theta_ref_deg)) * dtau / dtau_ref', 'math.sin(math.radians(theta_ref_deg)) * dtau_ref / dtau'),
    ('UF', 'bearing interval without the delay bound', LIB, 'c * (delay + d) / b)))) for d in (-e, e)]', 'c * (delay + 0 * d) / b)))) for d in (-e, e)]'),
    ('UF', 'chord bearing reported as the arrival angle', LIB, 'chord_incl=math.degrees(math.atan2(X, sum(h))))', 'chord_incl=math.degrees(math.asin(q[0])))'),
    ('UG', 'supplied 6 us budget around the overlap peak carried into geometry', BAT, "        lo, hi = f['fb'][0], f['fb'][1]\n        e = W.enclose", "        lo, hi = f['peak'] - 6e-6, f['peak'] + 6e-6\n        e = W.enclose"),
    ('UG', 'path tolerance loosened, the noisy record locked', BAT, "status=W.release(p0, {'path': w})['path']", "status=W.release(p0, {'path': w}, tol_m=0.05)['path']"),
    ('UH', 'reference record dropped from the acoustic records', LIB, 'return np.array([2 * L / c + d] + [2 * r / c + d for r in refs])', 'return np.array([2 * L / c + d])'),
    ('UH', 'SI speed of light counted as an anchor of the acoustic record', BAT, 'hole_cs = U.unit_hole(Dsys, np.stack([U.dim(T=-1)], 1))', 'hole_cs = U.unit_hole(Dsys, np.stack([U.dim(T=-1), U.dim(L=1, T=-1)], 1))'),
    ('UI', 'radar distance without the round-trip half', LIB, 'return C_SI * Fr(n_cycles) / (2 * NU_CS * Fr(index))', 'return C_SI * Fr(n_cycles) / (NU_CS * Fr(index))'),
    ('UI', 'group index ignored (light in air read as vacuum)', LIB, 'return C_SI * Fr(n_cycles) / (2 * NU_CS * Fr(index))', 'return C_SI * Fr(n_cycles) / (2 * NU_CS)'),
    ('UJ', 'least-time path with the layer speeds exchanged', LIB, 'return math.hypot(x - xa, zi - za) / c[0] + math.hypot(xb - x, zb - zi) / c[1]', 'return math.hypot(x - xa, zi - za) / c[1] + math.hypot(xb - x, zb - zi) / c[0]'),
    ('UJ', 'vertical reference timed through the top layer only', BAT, 'vert = 2 * sum(h / c for h, c in zip(W.H, W.C)); horiz = 2 * 5 / W.C[0]', 'vert = 2 * 10 / W.C[0]; horiz = 2 * 5 / W.C[0]'),
    ('UK', 'statistical angle read with the Euclidean product', LIB, 'float(u @ g @ w) / math.sqrt(float(u @ g @ u) * float(w @ g @ w))', 'float(u @ w) / math.sqrt(float(u @ u) * float(w @ w))'),
    ('UK', 'Fisher metric from range only along x', LIB, 'g += N * np.outer(grad, grad) / sigma ** 2', 'g += N * np.outer(grad * np.array([1.0, 0.0]), grad * np.array([1.0, 0.0])) / sigma ** 2 + 1e-30 * np.eye(2)'),
]


def run(mut):
    group, desc, rel, old, new = mut
    base = open(os.path.join(HERE, rel)).read()
    if base.count(old) != 1:
        return group, desc, 'anchor not found exactly once -> SUITE DEFECT', False
    with tempfile.TemporaryDirectory() as tmp:
        work = os.path.join(tmp, 'b')
        shutil.copytree(HERE, work, ignore=shutil.ignore_patterns('__pycache__', NAME + '_results.json', NAME + '_mutations.py',
                                                                  '*.log', 'paper', '*.zip', 'RG_*bundle*', 'run*.log'))
        open(os.path.join(work, rel), 'w').write(base.replace(old, new))
        env = dict(os.environ, RG_UNDERWATER_GROUPS=group)
        subprocess.run([sys.executable, '-I', NAME + '.py'], cwd=work, capture_output=True, text=True, env=env)
        try:
            fails = json.load(open(os.path.join(work, NAME + '_results.json')))['failures']
        except Exception:
            fails = ['CRASHED']
    ok = group in fails
    return group, desc, ('caught ' if ok else 'SURVIVED ') + str(fails), ok


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--jobs', type=int, default=2); ap.add_argument('--only', default='')
    a = ap.parse_args(); sel = [m for m in MUTATIONS if not a.only or m[0] in a.only.split(',')]
    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(run, sel))
    for g, d, msg, _ in res:
        print(f'{g}  {d}: {msg}', flush=True)
    caught = sum(r[3] for r in res)
    print(f'{caught} / {len(sel)} caught')
    return 0 if caught == len(sel) else 1


if __name__ == '__main__':
    sys.exit(main())
