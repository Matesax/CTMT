import json
from pathlib import Path
import numpy as np
from numpy.linalg import eigvalsh, matrix_rank, cond, norm
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score
from sklearn.preprocessing import StandardScaler

SEED=20260927
rng=np.random.default_rng(SEED)
OUT=Path('/mnt/data')
checks=[]
def reg(name, passed, value, consequence):
    checks.append({'name':name,'passed':bool(passed),'value':value,'consequence':consequence})

# A. AAA: output sensitivity is neither identifiability nor admissibility.
# y(theta,a)=theta+a has nonzero derivative in a, but only theta+a is identified.
J=np.array([[1.,1.]])
F=J.T@J
reg('AAA-A1 phase/output sensitivity does not imply identifiability', matrix_rank(F)==1,
    {'dY_da':1.0,'rank_F':int(matrix_rank(F)),'dim_theta':2},
    'The early criterion dP/da != 0 is necessary at most; the AAA direction may remain in a mixed observational fibre.')
# Add genuinely independent channel y2=theta-a.
J2=np.array([[1.,1.],[1.,-1.]])
F2=J2.T@J2
reg('AAA-A2 independent channel resolves deformation', matrix_rank(F2)==2 and eigvalsh(F2).min()>0,
    {'eigenvalues':eigvalsh(F2).tolist(),'condition':float(cond(F2))},
    'AAA becomes a resolved direction only after the enlarged experiment separates it.')
# Nuisance attack: a channel sensitive to a and nuisance n only through a+n.
Jn=np.array([[1.,1.],[2.,2.],[3.,3.]]) # columns a,n
Fn=Jn.T@Jn
reg('AAA-A3 nuisance closure is indispensable', matrix_rank(Fn)==1,
    {'rank_F':int(matrix_rank(Fn)),'null_vector':[1,-1]},
    'Nonzero phase sensitivity can still be pure nuisance confounding.')

# B. Tikhonov: stable smooth reconstruction can be wrong.
n=80
D=np.eye(n)-np.eye(n,k=-1); D=D[1:]
x_true=np.zeros(n); x_true[25:50]=1; x_true[50:]=-0.5
A=np.zeros((25,n))
for i in range(25):
    idx=rng.choice(n,8,replace=False); A[i,idx]=rng.normal(size=8)
y=A@x_true+0.01*rng.normal(size=25)
lam=10.0
xh=np.linalg.solve(A.T@A+lam*(D.T@D)+1e-8*np.eye(n),A.T@y)
res=float(norm(A@xh-y)); err=float(norm(xh-x_true)); smooth=float(norm(D@xh))
reg('INV-B1 Tikhonov stability does not prove physical continuation', res<0.15 and err>1.0,
    {'residual':res,'latent_error':err,'roughness':smooth},
    'A smooth low-residual solution can erase genuine chambers; regularization success is not a structural theorem.')

# C. Rupture: second differences can be caused by scale, sampling, or coordinate choice.
z=np.arange(1,101.)
f=np.sin(z/10)
scale=np.ones_like(z); scale[z>=50]=2.0
yjump=scale*f
r=np.diff(yjump,2); hit=int(z[1:-1][np.argmax(abs(r))])
# Normalize locally by known scale: rupture disappears except smooth curvature.
ycorr=yjump/scale
ratio=float(np.max(abs(np.diff(ycorr,2)))/(np.max(abs(r))+1e-15))
reg('RUP-C1 scalar rupture is not invariant', hit in [49,50,51] and ratio<0.2,
    {'raw_peak_Z':hit,'normalized_to_raw_peak_ratio':ratio},
    'A second-difference kink may be a protocol-scale discontinuity, not a change of quotient experiment.')

# D. Group regularization circularity.
Z=np.arange(1,61)
true=(Z%8) # hidden recurrent type, deliberately not contiguous
X=np.c_[Z/60,np.sin(Z/6)]
# Unsupervised baseline.
p0=KMeans(8,random_state=SEED,n_init=30).fit_predict(StandardScaler().fit_transform(X))
ari0=float(adjusted_rand_score(true,p0))
# Label leakage: append one-hot of the target partition as old groupwise constraints effectively do.
one=np.eye(8)[true]
p1=KMeans(8,random_state=SEED,n_init=30).fit_predict(np.c_[StandardScaler().fit_transform(X),10*one])
ari1=float(adjusted_rand_score(true,p1))
reg('GRP-D1 imposed groups can manufacture apparent recovery', ari1>0.95 and ari0<0.5,
    {'ARI_without_group_input':ari0,'ARI_with_group_leakage':ari1},
    'Recovery after groupwise penalties or anchors cannot characterize the groups independently.')

# E. Chamber/recurrence characterization on a synthetic but label-blind declared experiment.
# Construct six local chamber types repeated across four periods, then change coordinates per period.
P=4; T=6; d=4
base=rng.normal(size=(T,d))
obs=[]; types=[]; periods=[]
for p in range(P):
    Q,_=np.linalg.qr(rng.normal(size=(d,d)))
    b=rng.normal(scale=.5,size=d)
    for t in range(T):
        for j in range(5):
            obs.append(Q@base[t]+b+rng.normal(scale=.04,size=d)); types.append(t); periods.append(p)
obs=np.array(obs); types=np.array(types); periods=np.array(periods)
# Unsafe global clustering without transport.
pg=KMeans(T,random_state=SEED,n_init=50).fit_predict(StandardScaler().fit_transform(obs))
ari_global=float(adjusted_rand_score(types,pg))
# Estimate period transports by Procrustes using only local adjacency/order correspondence, not type labels in features.
# This models a declared correspondence map, which the RG ladder requires rather than derives.
ref=np.array([obs[periods==0][5*t:5*(t+1)].mean(0) for t in range(T)])
aligned=[]; aligned_types=[]
for p in range(P):
    means=np.array([obs[periods==p][5*t:5*(t+1)].mean(0) for t in range(T)])
    mc=means-means.mean(0); rc=ref-ref.mean(0)
    U,_,Vt=np.linalg.svd(mc.T@rc); R=U@Vt
    xp=(obs[periods==p]-means.mean(0))@R+ref.mean(0)
    aligned.append(xp); aligned_types.extend(types[periods==p])
aligned=np.vstack(aligned); aligned_types=np.array(aligned_types)
pa=KMeans(T,random_state=SEED,n_init=50).fit_predict(StandardScaler().fit_transform(aligned))
ari_aligned=float(adjusted_rand_score(aligned_types,pa))
reg('STR-E1 transported recurrence classes can lock', ari_global<0.8 and ari_aligned>0.95,
    {'ARI_without_transport':ari_global,'ARI_with_declared_transport':ari_aligned},
    'Groups are recurrence classes of local chambers only relative to a valid transport/correspondence protocol.')
# Cocycle attack.
R01=np.eye(d); R12=np.eye(d); R02=np.eye(d); R02[0,1]=0.2
coc=float(norm(R12@R01-R02))
reg('STR-E2 pairwise comparisons without cocycle do not define a group', coc>0.1,
    {'cocycle_defect':coc},
    'Pairwise similarity is insufficient; recurrence classes require identity, inverse, and cocycle closure.')

# F. Fisher/projector chamber boundary.
tau=.5
Ls=[]; ranks=[]
for i in range(40):
    vals=np.array([1.2,0.9,0.7,0.65])
    if i>=20: vals[-1]=0.35
    L=np.diag(vals)+rng.normal(scale=.004,size=(d,d)); L=(L+L.T)/2
    Ls.append(L); ranks.append(int(np.sum(eigvalsh(L)>tau)))
margin=min(abs(np.concatenate([eigvalsh(L)-tau for L in Ls])))
reg('STR-F1 spectral discriminant produces a genuine chamber boundary', ranks[:20]==[4]*20 and ranks[20:]==[3]*20 and margin>0,
    {'ranks_before':sorted(set(ranks[:20])),'ranks_after':sorted(set(ranks[20:])),'minimum_margin':float(margin)},
    'A chamber boundary is certified by a stable invariant change, not merely a peak in one scalar series.')

# G. Claims ledger.
claims={
 'phase_sensitivity_makes_AAA_admissible':'rejected_as_sufficient; retained_as_necessary_candidate_gate',
 'Tikhonov_success_reveals_elemental_structure':'rejected',
 'second_difference_rupture_is_structural_boundary':'rejected_as_invariant; retained_as_candidate_detector',
 'groupwise_regularization_discovers_groups':'rejected_as_circular',
 'lanthanide_anchor_proves_long_stratum':'rejected_without_anchor_ablation_and_independent_channels',
 'groups_are_connected_strata':'rejected',
 'elemental_group_is_recurrence_class_of_compatible_local_strata':'locked_as_a_conditional_characterization',
 'actual_chemical_groups_are_empirically_RG_recurrence_classes':'open_requires_measured_multichannel_data'
}
result={'seed':SEED,'checks':checks,'passed':sum(c['passed'] for c in checks),'total':len(checks),'claims':claims,
        'overall_verdict':'The logical characterization locks, but empirical elemental identification does not. Early CTMT claims survive only as gated diagnostics or are rejected as circular/sufficiently false.'}
(OUT/'rg_elemental_final_attack.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
