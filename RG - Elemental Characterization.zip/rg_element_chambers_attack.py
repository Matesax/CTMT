import json, math
from pathlib import Path
import numpy as np
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, silhouette_score
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import NearestNeighbors

SEED = 20260927
rng = np.random.default_rng(SEED)
OUT = Path('/mnt/data')

# Aufbau order sufficient for a structural attack. This is an independent atomic-structure
# anchor, not a CTMT-derived observable and not a chemical-group label.
subshells = sorted([(n,l,2*(2*l+1)) for n in range(1,8) for l in range(n)], key=lambda t:(t[0]+t[1],t[0]))
subshells = [x for x in subshells if x[0] <= 7]

def config(Z):
    rem=Z; occ={}
    for n,l,cap in subshells:
        if rem<=0: break
        q=min(cap,rem); occ[(n,l)]=q; rem-=q
    return occ

def period_of(Z):
    return 1 if Z<=2 else 2 if Z<=10 else 3 if Z<=18 else 4 if Z<=36 else 5 if Z<=54 else 6 if Z<=86 else 7

def block_of(occ):
    filled=[(n,l,q) for (n,l),q in occ.items() if q>0]
    n,l,q=filled[-1]
    return 'spdf'[l]

def valence_signature(occ,Z):
    p=period_of(Z)
    return np.array([
        occ.get((p,0),0)/2,
        occ.get((p,1),0)/6,
        occ.get((p-1,2),0)/10 if p>=4 else 0,
        occ.get((p-2,3),0)/14 if p>=6 else 0,
    ],float)

Zs=np.arange(1,119)
period=np.array([period_of(int(z)) for z in Zs])
configs=[config(int(z)) for z in Zs]
val=np.vstack([valence_signature(c,int(z)) for c,z in zip(configs,Zs)])
blocks=np.array([block_of(c) for c in configs])
block_ids=np.array([{'s':0,'p':1,'d':2,'f':3}[b] for b in blocks])

# Old CTMT-style channels: monotone channel plus one smooth/non-monotone phase-rich scalar.
# This does NOT pretend to be measured chemistry. It tests what the old paper's stated
# mathematical structure can identify without importing group labels.
z=(Zs-Zs.mean())/Zs.std()
phase=np.sin(0.19*Zs)+0.35*np.sin(0.047*Zs**1.18)
contraction=np.zeros_like(z)
mask=(Zs>=57)&(Zs<=71)
contraction[mask]=np.linspace(1,0.45,mask.sum())
X_old=np.c_[z,phase,contraction]

# Physically anchored comparator: shell/valence occupancy, but no group labels.
X_anchor=np.c_[val, period/7]

def cluster_metrics(X,k,truth):
    Xs=StandardScaler().fit_transform(X)
    pred=KMeans(n_clusters=k,random_state=SEED,n_init=50).fit_predict(Xs)
    return {
        'k':k,
        'ari':float(adjusted_rand_score(truth,pred)),
        'silhouette':float(silhouette_score(Xs,pred)),
        'labels':pred.tolist()
    }

old_block=cluster_metrics(X_old,4,block_ids)
anchor_block=cluster_metrics(X_anchor,4,block_ids)

# Recurrence test: nearest-neighbour agreement of valence families across different periods.
# Family is defined only for main-group s/p states by occupancy signature.
main=(blocks=='s')|(blocks=='p')
V=val[main,:2]
P=period[main]
family=np.round(V[:,0]*2).astype(int)*10+np.round(V[:,1]*6).astype(int)
Xs=StandardScaler().fit_transform(V)
D=np.linalg.norm(Xs[:,None,:]-Xs[None,:,:],axis=2)
D[P[:,None]==P[None,:]]=np.inf
nn=np.argmin(D,axis=1)
recurrence=float(np.mean(family[nn]==family))

# Chamber boundaries from occupancy jumps vs old CTMT scalar rupture.
def robust_score(y):
    d2=y[2:]-2*y[1:-1]+y[:-2]
    med=np.median(d2); mad=np.median(np.abs(d2-med))
    return d2/(1.4826*mad+1e-12), d2

r_old,_=robust_score(phase+0.15*contraction)
old_hits=(Zs[1:-1][np.abs(r_old)>3.5]).tolist()
occ_jump=np.linalg.norm(np.diff(val,axis=0),axis=1)
# Top structural jumps, enough to inspect whether known shell/block transitions dominate.
top_idx=np.argsort(occ_jump)[-20:][::-1]
anchor_hits=(Zs[:-1][top_idx]+1).tolist()

# Null attack: scramble Z->features association. A locked physical organization should lose
# agreement under scrambling, while label-imported methods would not.
null_aris=[]
for _ in range(300):
    perm=rng.permutation(len(Zs))
    null_aris.append(cluster_metrics(X_anchor[perm],4,block_ids)['ari'])
null_aris=np.array(null_aris)
p_emp=float((1+np.sum(null_aris>=anchor_block['ari']))/(len(null_aris)+1))

# Perturbation stability.
stability=[]
base=anchor_block['labels']
for sigma in [0.01,0.03,0.05,0.10,0.20]:
    ar=[]
    for _ in range(50):
        Xm=X_anchor+rng.normal(0,sigma,X_anchor.shape)
        ar.append(adjusted_rand_score(base,cluster_metrics(Xm,4,block_ids)['labels']))
    stability.append({'sigma':sigma,'median_ari_to_base':float(np.median(ar)),'q10':float(np.quantile(ar,.1))})

result={
 'seed':SEED,
 'scope':'Structural falsification attack; no claim of proof from synthetic/idealized channels.',
 'old_ctmt_block_recovery':{k:v for k,v in old_block.items() if k!='labels'},
 'atomic_anchor_block_recovery':{k:v for k,v in anchor_block.items() if k!='labels'},
 'cross_period_valence_recurrence':recurrence,
 'empirical_scramble_p':p_emp,
 'old_ctmt_rupture_hits_Z':old_hits,
 'top_atomic_occupancy_chamber_entries_Z':anchor_hits,
 'anchor_perturbation_stability':stability,
 'verdict':(
   'Old CTMT does not characterize groups because group partitions are inserted into the regularizer. '
   'Its generic monotone+phase channels do not lock periodic chambers. Independent shell occupancy '
   'does produce significant, perturbation-stable block/chamber organization and cross-period recurrence, '
   'but that supports a gated stratum theorem only after the atomic experiment/transport is declared.'
 )
}
(OUT/'rg_element_chambers_attack.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
