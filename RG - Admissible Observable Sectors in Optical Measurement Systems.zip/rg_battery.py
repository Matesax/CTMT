import numpy as np, pandas as pd, json, os
from scipy.optimize import least_squares, curve_fit
from numpy.linalg import svd, eigvalsh, cond
base='/mnt/data'
out={'ac':{},'spectroscopy':{},'optical_activity':{}}
# AC fit: V=V0/sqrt(1+(f/fc)^(2n)); log params for stability
for fn in ['0_OHM.CSV','500_OHM.CSV','1000_OHM.CSV','5100_OHM.CSV','10000_OHM.CSV']:
    df=pd.read_csv(os.path.join(base,fn))
    f=df.iloc[:,0].to_numpy(float); y=df.iloc[:,1].to_numpy(float)
    def pred(p):
        V0, lfc, ln=p; fc=np.exp(lfc); n=np.exp(ln)
        return V0/np.sqrt(1+(f/fc)**(2*n))
    p0=[np.max(y), np.log(f[np.argmin(abs(y-np.max(y)/np.sqrt(2)))]), 0.0]
    fit=least_squares(lambda p: pred(p)-y,p0,max_nfev=20000)
    yh=pred(fit.x); res=y-yh; dof=max(1,len(y)-3); s2=np.sum(res**2)/dof
    J=fit.jac; F=J.T@J/max(s2,1e-12); ev=eigvalsh(F); fc=np.exp(fit.x[1]); n=np.exp(fit.x[2])
    # empirical normalized sensitivity to log f: finite gradient of fitted response; identifiability density
    x=f/fc; sens=np.abs(-np.max(y)*n*x**(2*n)/(1+x**(2*n))**1.5)
    out['ac'][fn]={'V0_mV':fit.x[0],'fc_Hz':fc,'order_n':n,'rmse_mV':float(np.sqrt(np.mean(res**2))),'r2':float(1-np.sum(res**2)/np.sum((y-y.mean())**2)),'F_eigs':ev.tolist(),'F_condition':float(ev[-1]/max(ev[0],1e-300)),'peak_logf_sensitivity_Hz':float(f[np.argmax(sens)])}
# spectroscopy: background subtract per column, normalize columns, SVD across 6 channels
sp=pd.read_csv(os.path.join(base,'LED_OPTIC_SPECTRUM.CSV'))
wl=sp.iloc[:,0].to_numpy(float); X=sp.iloc[:,1:].to_numpy(float)
Xb=np.maximum(X-np.percentile(X,5,axis=0),0)
Xn=Xb/np.maximum(np.linalg.norm(Xb,axis=0),1e-12)
U,s,Vt=svd(Xn,full_matrices=False)
energy=s*s/np.sum(s*s); eff=np.exp(-np.sum(energy*np.log(np.maximum(energy,1e-300))))
out['spectroscopy']={'singular_values':s.tolist(),'energy_fractions':energy.tolist(),'effective_rank_entropy':float(eff),'condition_full':float(s[0]/s[-1]),'rank_99pct':int(np.searchsorted(np.cumsum(energy),.99)+1),'rank_999pct':int(np.searchsorted(np.cumsum(energy),.999)+1)}
# pair cosine similarities
cols=list(sp.columns[1:]); G=Xn.T@Xn
out['spectroscopy']['pair_cosines']={f'{cols[i]}|{cols[j]}':float(G[i,j]) for i in range(len(cols)) for j in range(i+1,len(cols))}
# optical activity: use explicitly listed concentration and length series from workbook content
L=np.array([1.7,4.05,7.3,12.8,16.7]); aL=np.array([4,9,16,28,40.])
P=np.array([10,20,30,40,50.]); aP=np.array([9,20,30,40,50.])
def linfit(x,y):
    A=np.c_[np.ones(len(x)),x]; beta=np.linalg.lstsq(A,y,rcond=None)[0]; r=y-A@beta; s2=np.sum(r*r)/(len(x)-2); cov=s2*np.linalg.inv(A.T@A); ev=eigvalsh((A.T@A)/s2)
    return {'intercept':beta[0],'slope':beta[1],'slope_se':np.sqrt(cov[1,1]),'r2':1-np.sum(r*r)/np.sum((y-y.mean())**2),'F_eigs':ev.tolist(),'F_condition':float(ev[-1]/ev[0])}
out['optical_activity']['length']=linfit(L,aL)
out['optical_activity']['concentration']=linfit(P,aP)
# local Fisher density for concentration under alpha=kP/S; constant derivative => no intrinsic threshold absent noise variation
out['optical_activity']['note']='Linear Biot data support stable identifiability over sampled range; they do not exhibit an observed R/N threshold.'
with open(os.path.join(base,'rg_optics_battery_results.json'),'w') as f: json.dump(out,f,indent=2)
print(json.dumps(out,indent=2))
