"""Evidence additions for the adversarial brief on GR (light, published inputs).
N1  Mercury: GR perihelion shift from orbital elements; the share carried by the nonlinear (beta, U^2) term;
    beta = 0 (linear superposition) vs the planetary-ephemeris measurement (INPOP13a).
N2  dark-sector accounting: Omega_m (our Pantheon+ fit) vs Omega_b from Omega_b h^2 = 0.0224 over h in [0.67, 0.73].
Run: python rg_gr_brief_data.py   (requires rg_gr_naturality_results.json from rg_gr_naturality_data.py)
"""
import json, math, hashlib, pathlib
RES = {}
GM = 1.32712440018e20; c = 299792458.0; AU = 1.495978707e11
a = 0.38709927 * AU; e = 0.20563593; P_days = 87.9691
per_orbit = 6 * math.pi * GM / (c ** 2 * a * (1 - e ** 2))
orbits = 36525.0 / P_days
gr_shift = per_orbit * orbits * 180 / math.pi * 3600
def shift(beta, gamma=1.0): return (2 + 2 * gamma - beta) / 3 * gr_shift
beta_m1, beta_s = 0.2e-5, 2.5e-5                                   # INPOP13a (Verma et al. 2014)
RES["N1"] = dict(GR_shift_arcsec_per_century=gr_shift,
                 nonlinear_beta_share_arcsec=shift(1.0) - shift(0.0),
                 linear_superposition_beta0_prediction=shift(0.0),
                 beta_measured=dict(value=1 + beta_m1, sigma=beta_s),
                 beta0_excluded_by_sigma=1 / beta_s,
                 status="MEASURED: the U^2 (self-coupling) term of GR is required; beta = 1 to 2.5e-5")
nat = json.loads(pathlib.Path("rg_gr_naturality_results.json").read_text())
om = nat["D1"]["flat_LCDM"]["Omega_m"]; om_lo, om_hi = nat["D1"]["flat_LCDM"]["ci68"]
obh2 = 0.0224
rows = {}
for h in (0.67, 0.70, 0.73):
    ob = obh2 / h ** 2; rows[str(h)] = dict(Omega_b=ob, dark_matter_fraction_of_matter=(om - ob) / om,
                                            visible_fraction_of_total=ob)
RES["N2"] = dict(Omega_m=om, Omega_m_ci68=[om_lo, om_hi], Omega_Lambda=1 - om, Omega_b_h2=obh2, by_h=rows,
                 status="ACCOUNTED: baryons are ~4-5% of the budget; GR's cosmological fit needs two non-baryonic components")
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_gr_brief_results.json").write_text(json.dumps(RES, indent=1))
print(json.dumps(RES, indent=1))
