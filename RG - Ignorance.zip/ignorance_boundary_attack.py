#!/usr/bin/env python3
"""Finite-sample attack on observable ignorance boundaries.

The experiment is a calibrated binary observer
    P(Y=1|x) = sigmoid(k (x-b))
with unknown boundary b and sharpness k>0.  The attack asks whether finite
samples determine boundary location, protocol width, Fisher prediction, and
failure modes.  Synthetic only; no physical claim.
"""
from __future__ import annotations
import json, math
from dataclasses import dataclass, asdict
from pathlib import Path
import numpy as np

SEED=20260827
RNG=np.random.default_rng(SEED)

@dataclass
class Check:
    name:str; passed:bool; value:object; consequence:str
CHECKS=[]
def rec(n,p,v,c): CHECKS.append(Check(n,bool(p),v,c))
def sigmoid(z):
    z=np.clip(z,-40,40); return 1/(1+np.exp(-z))
def nll_grad_hess(beta,x,y):
    # beta=(b,a), k=exp(a)
    b,a=beta; k=np.exp(a); z=k*(x-b); p=sigmoid(z)
    nll=-np.sum(y*np.log(p+1e-15)+(1-y)*np.log(1-p+1e-15))
    # dz/db=-k, dz/da=z
    D=np.column_stack((-k*np.ones_like(x),z))
    grad=D.T@(p-y)
    W=p*(1-p)
    # exact Hessian: D'WD + sum(p-y) d2z
    H=D.T@(W[:,None]*D)
    H[0,1]+=np.sum((p-y)*(-k)); H[1,0]=H[0,1]
    H[1,1]+=np.sum((p-y)*z)
    return nll,grad,H

def fit(x,y,start=(0.,0.)):
    beta=np.array(start,float)
    for _ in range(80):
        f,g,H=nll_grad_hess(beta,x,y)
        H=H+1e-8*np.eye(2)
        try: step=np.linalg.solve(H,g)
        except np.linalg.LinAlgError: step=np.linalg.pinv(H)@g
        t=1.; accepted=False
        for _ in range(25):
            cand=beta-t*step
            cand[1]=np.clip(cand[1],-5,5)
            fc,_,_=nll_grad_hess(cand,x,y)
            if fc<=f-1e-4*t*np.dot(g,step): beta=cand; accepted=True; break
            t*=.5
        if not accepted: beta=beta-.01*g/max(1,np.linalg.norm(g))
        if np.linalg.norm(t*step)<1e-8: break
    b,a=beta; k=float(np.exp(a)); p=sigmoid(k*(x-b));
    D=np.column_stack((-k*np.ones_like(x),k*(x-b)))
    I=D.T@((p*(1-p))[:,None]*D)
    return float(b),k,I

def sample(n,b,k,design='wide',rng=RNG):
    if design=='wide': x=rng.uniform(-2,2,n)
    elif design=='boundary': x=np.clip(rng.normal(b,.45,n),-2,2)
    elif design=='left': x=rng.uniform(-2,-.7,n)
    else: raise ValueError(design)
    p=sigmoid(k*(x-b)); y=rng.binomial(1,p)
    return x,y

def main():
    b0=.35; k0=4.0
    # Large finite ensemble for accuracy and Fisher calibration.
    reps=600; n=400
    bh=[]; kh=[]; se=[]; cover=[]; failures=0
    for _ in range(reps):
        x,y=sample(n,b0,k0,'wide')
        if y.min()==y.max(): failures+=1; continue
        b,k,I=fit(x,y,start=(0.,math.log(3)))
        cov=np.linalg.pinv(I); s=math.sqrt(max(cov[0,0],0))
        bh.append(b); kh.append(k); se.append(s); cover.append(abs(b-b0)<=1.96*s)
    bh=np.array(bh); kh=np.array(kh); se=np.array(se)
    bias=float(bh.mean()-b0); rmse=float(np.sqrt(np.mean((bh-b0)**2)))
    coverage=float(np.mean(cover)); empirical_sd=float(bh.std(ddof=1)); fisher_se=float(se.mean())
    rec('finite_boundary_location_recovered',abs(bias)<.015 and rmse<.07,
        {'fits':len(bh),'failures':failures,'bias':bias,'rmse':rmse},
        'A calibrated smooth finite-sample protocol estimates the boundary coordinate.')
    rec('fisher_predicts_boundary_uncertainty',abs(empirical_sd/fisher_se-1)<.18,
        {'empirical_sd':empirical_sd,'mean_fisher_se':fisher_se,'ratio':empirical_sd/fisher_se},
        'Inverse Fisher predicts repeated-sample boundary dispersion in the regular regime.')
    rec('wald_interval_has_nominal_coverage',.91<coverage<.98,coverage,
        'Finite-sample 95% Wald coverage is approximately calibrated for this protocol.')
    rec('protocol_sharpness_recovered',abs(np.median(kh)-k0)<.35,
        {'median_k':float(np.median(kh)),'true_k':k0},
        'The experiment separates boundary location from observer transition width.')

    # Scaling with n.
    ns=[100,200,400,800]; rmses=[]
    for nn in ns:
        vals=[]
        for _ in range(220):
            x,y=sample(nn,b0,k0,'wide')
            if y.min()!=y.max(): vals.append(fit(x,y,(0.,math.log(3)))[0])
        rmses.append(float(np.sqrt(np.mean((np.array(vals)-b0)**2))))
    slope=float(np.polyfit(np.log(ns),np.log(rmses),1)[0])
    rec('boundary_error_has_root_n_scaling',-.65<slope<-.35,{'n':ns,'rmse':rmses,'log_slope':slope},
        'Regular boundary uncertainty contracts approximately as n^{-1/2}.')

    # Active design near boundary.
    def ensemble(design):
        vals=[]
        for _ in range(300):
            x,y=sample(160,b0,k0,design)
            if y.min()!=y.max(): vals.append(fit(x,y,(b0,math.log(3)))[0])
        return float(np.sqrt(np.mean((np.array(vals)-b0)**2)))
    rw=ensemble('wide'); rb=ensemble('boundary')
    rec('boundary_focused_protocol_improves_quantity',rb<.85*rw,{'wide_rmse':rw,'focused_rmse':rb,'ratio':rb/rw},
        'Protocol design changes boundary precision even when the latent boundary is unchanged.')

    # Known-boundary Fisher profile vanishes far from transition.
    grid=np.linspace(-4,4,2001); p=sigmoid(k0*(grid-b0)); If=k0*k0*p*(1-p)
    peakx=float(grid[np.argmax(If)]); edge=float(max(If[0],If[-1])); peak=float(If.max())
    rec('fisher_localizes_observable_boundary',abs(peakx-b0)<.005 and edge/peak<1e-5,
        {'peak_x':peakx,'true_b':b0,'edge_to_peak':edge/peak},
        'The protocol Fisher density peaks at the transition and collapses in saturated regions.')

    # Hard quotient identifies cells but not the coordinate quantity.
    x=np.linspace(-2,2,101); q=(x>=b0).astype(int)
    phi=lambda z: 3*z+7
    transformed_boundary=phi(b0)
    same_partition=np.array_equal(q,(phi(x)>=transformed_boundary).astype(int))
    rec('quotient_does_not_fix_boundary_number',same_partition and transformed_boundary!=b0,
        {'b_original':b0,'b_reparameterized':transformed_boundary},
        'The same partition under reparameterization has a different numerical boundary coordinate.')

    # Units/scale ambiguity: x'=a x+c; k'=k/a, b'=ab+c yields same laws.
    a,c=2.5,-1.2; xp=a*x+c; bp=a*b0+c; kp=k0/a
    law_gap=float(np.max(np.abs(sigmoid(k0*(x-b0))-sigmoid(kp*(xp-bp)))))
    rec('calibration_is_required_for_absolute_boundary',law_gap<1e-14,law_gap,
        'Observation laws cannot distinguish affine coordinate gauges without external calibration.')

    # Censoring away from boundary causes near singularity/nonidentifiability.
    bad=[]; cond=[]
    for _ in range(180):
        x,y=sample(250,b0,k0,'left')
        if y.min()==y.max(): bad.append(1); continue
        b,k,I=fit(x,y,(0.,math.log(2))); w=np.linalg.eigvalsh(I)
        cond.append(float(w[-1]/max(w[0],1e-18)))
    frac_bad=len(bad)/180; medcond=float(np.median(cond)) if cond else float('inf')
    rec('one_sided_sampling_fails_identification',frac_bad>.1 or medcond>1e4,
        {'single_class_fraction':frac_bad,'median_condition':medcond},
        'A finite sample not crossing the transition cannot reliably lock boundary and sharpness.')

    # Model misspecification: probit-like truth fit with logistic shifts width and can bias b under asymmetric design.
    vals=[]
    for _ in range(350):
        xx=np.clip(RNG.normal(b0-.35,.6,350),-2,2)
        # asymmetric contaminated response law
        u=xx-b0
        pp=sigmoid(k0*u+1.8*u*u)
        yy=RNG.binomial(1,pp)
        vals.append(fit(xx,yy,(0.,math.log(3)))[0])
    miss_bias=float(np.mean(vals)-b0)
    rec('misspecification_can_bias_boundary_quantity',abs(miss_bias)>.025,miss_bias,
        'Boundary quantity is model-conditional; asymmetric lapse contamination defeats the ideal likelihood.')

    # Finite threshold sets interval-valued boundary without response model.
    xx=np.sort(RNG.uniform(-2,2,80)); yy=(xx>=b0).astype(int)
    L=float(xx[yy==0].max()); U=float(xx[yy==1].min())
    rec('finite_hard_labels_only_bracket_boundary',L<b0<=U and U-L>0,
        {'lower':L,'upper':U,'width':U-L},
        'Without smooth stochastic structure, finite exact labels determine only a version-space interval.')

    # Replicate seed stability.
    seeds=[20260827,20260828,20260829,20260830,20260831]
    seed_est=[]
    for sd in seeds:
        rr=np.random.default_rng(sd); local=[]
        for _ in range(120):
            xx=rr.uniform(-2,2,n); yy=rr.binomial(1,sigmoid(k0*(xx-b0)))
            local.append(fit(xx,yy,(0.,math.log(3)))[0])
        seed_est.append(float(np.mean(local)))
    spread=float(max(seed_est)-min(seed_est))
    rec('multi_seed_stability',spread<.02,{'seeds':seeds,'mean_estimates':seed_est,'spread':spread},
        'The locked regular-regime conclusion is not specific to one random seed.')

    # Fisher cannot recover full fibre width: add an unobserved h with arbitrary domain.
    widths=[2,20,200]
    fisher=np.diag([k0*k0*.25,0.])
    rec('same_fisher_allows_arbitrary_blind_extent',fisher[1,1]==0 and widths[-1]/widths[0]==100,
        {'fisher':fisher.tolist(),'compatible_hidden_widths':widths},
        'Fisher locates a blind direction but does not quantify its global extent.')

    passed=sum(c.passed for c in CHECKS)
    out={'seed_primary':SEED,'seeds_stability':seeds,'passed':passed,'total':len(CHECKS),
         'all_passed':passed==len(CHECKS),
         'locked_statement':(
          'A known-coordinate, calibrated, smooth statistical protocol with samples spanning a regular transition '
          'can estimate an operational ignorance boundary and its finite-sample uncertainty. The boundary is the '
          'rank/decision transition of the declared experiment, not an intrinsic boundary of a bare quotient. '
          'Fisher localizes and quantifies regular boundary estimation, but cannot supply absolute coordinate scale, '
          'survive arbitrary misspecification, identify a boundary from one-sided data, or determine the global '
          'extent of exactly blind fibres. Hard finite labels yield only a bracket unless an additional response '
          'model is declared.'),
         'checks':[asdict(c) for c in CHECKS]}
    Path('ignorance_boundary_attack_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps({k:out[k] for k in ['seed_primary','seeds_stability','passed','total','all_passed','locked_statement']},indent=2))
    for i,c in enumerate(CHECKS,1): print(f"{i:02d} {'PASS' if c.passed else 'FAIL'} {c.name}: {c.value}")
    if not out['all_passed']: raise SystemExit(1)
if __name__=='__main__': main()
