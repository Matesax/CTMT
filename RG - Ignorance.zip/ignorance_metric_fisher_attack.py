#!/usr/bin/env python3
"""Metric-of-ignorance and Fisher-reconstruction hostile battery.
Seed 20260827. Synthetic/analytic tests only; no physical claim.
"""
from __future__ import annotations
import json
from dataclasses import dataclass, asdict
from pathlib import Path
import numpy as np

SEED=20260827
rng=np.random.default_rng(SEED)
TOL=5e-8

@dataclass
class Check:
    name:str; passed:bool; value:object; consequence:str
C=[]
def rec(n,p,v,c): C.append(Check(n,bool(p),v,c))
def spd(n, floor=.3):
    A=rng.normal(size=(n,n)); return A@A.T+floor*np.eye(n)
def pinv_psd(A,tol=1e-10):
    w,V=np.linalg.eigh((A+A.T)/2); wi=np.where(w>tol,1/w,0); return (V*wi)@V.T
def nullspace(A,tol=1e-10):
    u,s,vt=np.linalg.svd(A,full_matrices=True); r=(s>tol).sum(); return vt[r:].T
def range_basis(A,tol=1e-10):
    u,s,vt=np.linalg.svd(A,full_matrices=False); r=(s>tol).sum(); return vt[:r].T

def main():
    # Gaussian protocol Y~N(J theta,Sigma): pullback Mahalanobis = Fisher.
    max_pull=0.; max_kl=0.; max_vert=0.; trials=500
    for _ in range(trials):
        m=int(rng.integers(2,8)); d=int(rng.integers(2,8))
        J=rng.normal(size=(m,d)); S=spd(m); G=J.T@np.linalg.solve(S,J)
        v=rng.normal(size=d)
        max_pull=max(max_pull,abs(v@G@v-(J@v)@np.linalg.solve(S,J@v)))
        # exact Gaussian KL with equal covariance = .5 delta^T G delta
        h=rng.normal(size=d)*1e-3
        kl=.5*(J@h)@np.linalg.solve(S,J@h)
        max_kl=max(max_kl,abs(2*kl-h@G@h))
        N=nullspace(J)
        if N.size:
            max_vert=max(max_vert,float(np.linalg.norm(N.T@G@N)))
    rec('mahalanobis_pullback_equals_fisher',max_pull<TOL,max_pull,
        'Protocol covariance plus observation Jacobian induces Fisher exactly.')
    rec('local_KL_hessian_recovers_fisher',max_kl<TOL,max_kl,
        'For equal-covariance Gaussian protocols, twice local KL is the Fisher quadratic form.')
    rec('exact_invisible_directions_have_zero_fisher_length',max_vert<TOL,max_vert,
        'The protocol-induced form is degenerate on ker J; it is not a metric on the ignorance fibre.')

    # Quotient metric: choose complement B to ker J and show positive definite and lift independent modulo vertical.
    min_eig=1e9; max_lift=0.
    for _ in range(300):
        m,d=5,7; J=rng.normal(size=(m,d)); J[-1]=J[0]+J[1] # encourage rank deficiency
        S=spd(m); G=J.T@np.linalg.solve(S,J); B=range_basis(J); Gq=B.T@G@B
        if Gq.size: min_eig=min(min_eig,float(np.linalg.eigvalsh(Gq).min()))
        N=nullspace(J)
        if B.size and N.size:
            a=rng.normal(size=B.shape[1]); z=rng.normal(size=N.shape[1]); x=B@a; xp=x+N@z
            max_lift=max(max_lift,abs(x@G@x-xp@G@xp))
    rec('fisher_descends_to_positive_metric_on_regular_quotient',min_eig>1e-9,min_eig,
        'After removing ker J, the induced regular quotient form is positive definite.')
    rec('quotient_length_is_lift_independent',max_lift<TOL,max_lift,
        'Adding an exactly invisible lift does not change Fisher length.')

    # Coordinate covariance.
    max_coord=0.
    for _ in range(300):
        d=4; J=rng.normal(size=(6,d)); S=spd(6); G=J.T@np.linalg.solve(S,J)
        A=rng.normal(size=(d,d))
        while abs(np.linalg.det(A))<.1: A=rng.normal(size=(d,d))
        # theta=A phi, J_phi=J A
        Gp=(J@A).T@np.linalg.solve(S,J@A)
        max_coord=max(max_coord,float(np.linalg.norm(Gp-A.T@G@A)))
    rec('fisher_reparameterization_covariance',max_coord<TOL,max_coord,
        'The induced form transforms tensorially under latent reparameterization.')

    # Observation-coordinate invariance with covariance pushforward.
    max_obs=0.
    for _ in range(300):
        m,d=5,3; J=rng.normal(size=(m,d)); S=spd(m); L=rng.normal(size=(m,m))
        while abs(np.linalg.det(L))<.1: L=rng.normal(size=(m,m))
        G=J.T@np.linalg.solve(S,J); J2=L@J; S2=L@S@L.T
        G2=J2.T@np.linalg.solve(S2,J2)
        max_obs=max(max_obs,float(np.linalg.norm(G-G2)))
    rec('invertible_observation_change_preserves_metric',max_obs<TOL,max_obs,
        'Changing observable coordinates preserves Fisher only when covariance is transported too.')

    # Protocol limit scaling: same quotient/kernel, different noise gives different metric.
    J=np.array([[1.,0.,0.],[0.,1.,0.]])
    S1=np.eye(2); S2=np.diag([4.,.25]); G1=J.T@J; G2=J.T@np.linalg.solve(S2,J)
    same_kernel=np.allclose(nullspace(J),nullspace(J))
    rec('quotient_alone_does_not_fix_metric',same_kernel and np.linalg.norm(G1-G2)>1,
        {'metric_gap':float(np.linalg.norm(G1-G2))},
        'Identical fibres with different protocol noise have different distinguishability metrics.')
    rec('protocol_limits_fix_metric_only_with_statistical_model',np.allclose(G2,np.diag([.25,4.,0.])),G2.tolist(),
        'J and Sigma fix a pullback pseudometric; the equivalence relation alone does not.')

    # Global scale ambiguity if covariance known only up to scalar.
    alpha=7.3; Gscale=J.T@np.linalg.solve(alpha*S1,J)
    rec('unknown_noise_scale_leaves_metric_normalization_free',np.allclose(Gscale,G1/alpha),
        float(np.linalg.norm(Gscale-G1/alpha)),
        'Protocol shape without calibrated noise scale determines at most a metric ray.')

    # Fisher data processing for linear Gaussian postprocessing with added noise.
    worst=0.; strict_count=0
    for _ in range(500):
        m,d,k=6,4,3; J=rng.normal(size=(m,d)); S=spd(m); L=rng.normal(size=(k,m)); R=spd(k,.1)
        G=J.T@np.linalg.solve(S,J)
        Jp=L@J; Sp=L@S@L.T+R; Gp=Jp.T@np.linalg.solve(Sp,Jp)
        mine=float(np.linalg.eigvalsh((G-Gp+G.T-Gp.T)/2).min()); worst=min(worst,mine)
        strict_count+=int(np.trace(G-Gp)>1e-8)
    rec('noisy_postprocessing_contracts_fisher',worst>-TOL,{'worst_psd_eigenvalue':worst,'strict':strict_count},
        'A linear Gaussian channel cannot increase Fisher information.')

    # Sufficient invertible postprocessing equality already checked; lossy projection strict.
    J=np.eye(3); S=np.eye(3); L=np.array([[1.,0.,0.],[0.,1.,0.]])
    G=J.T@J; Gp=(L@J).T@np.linalg.solve(L@S@L.T,L@J)
    rec('lossy_protocol_opens_new_null_direction',np.linalg.matrix_rank(Gp)==2 and np.linalg.matrix_rank(G)==3,
        {'rank_before':3,'rank_after':int(np.linalg.matrix_rank(Gp))},
        'Coarse observation can enlarge the local ignorance kernel.')

    # Cramer-Rao / inverse Fisher belongs to resolved estimator uncertainty, not vertical fibre metric.
    J=np.array([[1.,0.],[0.,2.],[1.,1.]]) ; S=spd(3); G=J.T@np.linalg.solve(S,J); CR=np.linalg.inv(G)
    rec('inverse_fisher_is_resolved_uncertainty_bound',np.all(np.linalg.eigvalsh(CR)>0),np.linalg.eigvalsh(CR).tolist(),
        'On an identifiable regular chart, inverse Fisher is a covariance-scale tensor, not a distance along exact fibres.')
    Js=np.array([[1.,0.,0.],[0.,1.,0.]]) ; Gs=Js.T@Js; Gplus=np.linalg.pinv(Gs)
    rec('pseudoinverse_fisher_does_not_measure_blind_width',abs(Gplus[2,2])<TOL,Gplus.tolist(),
        'Moore-Penrose inversion assigns zero, not infinite calibrated width, to an unidentifiable direction.')

    # Same Fisher, different observation covariance/dimension; Fisher cannot reconstruct full protocol.
    J1=np.eye(2); S1=np.eye(2)
    J2=np.vstack([np.eye(2),np.zeros((1,2))]); S2=np.diag([1.,1.,9.])
    F1=J1.T@np.linalg.solve(S1,J1); F2=J2.T@np.linalg.solve(S2,J2)
    rec('fisher_does_not_reconstruct_full_observation_covariance',np.allclose(F1,F2) and S1.shape!=S2.shape,
        {'same_fisher':F1.tolist(),'covariance_shapes':[list(S1.shape),list(S2.shape)]},
        'An added parameter-insensitive noisy channel changes full covariance without changing Fisher.')

    # Nuisance elimination = Schur complement; full Fisher needed.
    max_schur=0.
    for _ in range(300):
        F=spd(6); A=F[:3,:3]; B=F[:3,3:]; D=F[3:,3:]
        eff=A-B@np.linalg.solve(D,B.T)
        invblock=np.linalg.inv(F)[:3,:3]
        max_schur=max(max_schur,float(np.linalg.norm(np.linalg.inv(eff)-invblock)))
    rec('nuisance_ignorance_uses_fisher_schur_complement',max_schur<TOL,max_schur,
        'Eliminating nuisance parameters reduces resolved Fisher by the Schur complement.')

    # Same quotient/rank and same diagonal Fisher but different coupling gives different nuisance-effective metric.
    F_a=np.array([[2.,0.,0.],[0.,2.,0.],[0.,0.,2.]])
    F_b=np.array([[2.,0.,.9],[0.,2.,.7],[.9,.7,2.]])
    Ea=F_a[:2,:2]-F_a[:2,2:]@np.linalg.inv(F_a[2:,2:])@F_a[2:,:2]
    Eb=F_b[:2,:2]-F_b[:2,2:]@np.linalg.inv(F_b[2:,2:])@F_b[2:,:2]
    rec('fisher_coupling_is_needed_for_effective_reconstruction',np.linalg.norm(Ea-Eb)>.5,
        {'effective_gap':float(np.linalg.norm(Ea-Eb))},
        'Marginal diagonal sensitivities do not determine the metric after nuisance elimination.')

    # Rank/conditioning instability under limits.
    epsvals=np.logspace(0,-12,13); mins=[]; conds=[]
    for e in epsvals:
        Je=np.diag([1.,e]); Fe=Je.T@Je; w=np.linalg.eigvalsh(Fe); mins.append(float(w[0])); conds.append(float(w[-1]/w[0]))
    rec('approaching_protocol_limit_collapses_metric',mins[-1]<1e-20 and conds[-1]>1e20,
        {'last_min_eigenvalue':mins[-1],'last_condition':conds[-1]},
        'Near a resolution limit the metric becomes ill-conditioned before exact rank loss.')

    # Hard threshold creates discontinuous/non-Riemannian observation; quotient not enough for Fisher.
    def hard(theta): return int(theta>=0)
    left=hard(-1e-9); right=hard(1e-9)
    rec('hard_protocol_threshold_breaks_smooth_fisher_reconstruction',left!=right,
        {'left':left,'right':right},
        'A hard decision quotient can jump while supplying no smooth likelihood Hessian.')

    # Bayesian posterior width depends on prior despite same Fisher.
    F=np.array([[4.]])
    post1=np.linalg.inv(F+np.array([[1.]])); post2=np.linalg.inv(F+np.array([[100.]]))
    rec('fisher_does_not_fix_posterior_ignorance',abs(post1[0,0]-post2[0,0])>.15,
        {'weak_prior_variance':float(post1[0,0]),'strong_prior_variance':float(post2[0,0])},
        'Posterior uncertainty requires prior information in addition to the protocol Fisher metric.')

    # Replication scaling shows metric depends on exposure/sample count.
    n1,n2=1,25; Fn1=n1*F; Fn2=n2*F
    rec('replication_scales_fisher_metric',np.allclose(Fn2,25*Fn1),float(Fn2[0,0]),
        'The operational metric depends on protocol exposure; normalization per trial must be declared.')

    passed=sum(x.passed for x in C)
    result={
      'seed':SEED,'passed':passed,'total':len(C),'all_passed':passed==len(C),
      'locked_statement':(
       'A bare observational quotient determines only indistinguishability. A calibrated smooth statistical '
       'protocol theta -> P_theta induces the Fisher pullback pseudometric on latent parameters. Its radical '
       'is the locally invisible tangent space under regular identifiability, and it descends to a Riemannian '
       'metric on the regular identifiable quotient. It does not canonically metricize the ignorance fibre. '
       'Inverse Fisher quantifies estimator uncertainty only on identifiable directions; it does not recover '
       'blind-fibre width. Fisher is reconstructible from the local second variation of statistical divergence '
       'or from J and full observational covariance in the Gaussian fixed-covariance model, but Fisher alone '
       'does not reconstruct the full covariance, nuisance coupling, prior-dependent posterior uncertainty, '
       'hard-threshold geometry, or singular strata.'),
      'checks':[asdict(x) for x in C]
    }
    Path('ignorance_metric_fisher_attack_results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({k:result[k] for k in ['seed','passed','total','all_passed','locked_statement']},indent=2))
    for i,x in enumerate(C,1): print(f"{i:02d} {'PASS' if x.passed else 'FAIL'} {x.name}: {x.value}")
    if not result['all_passed']: raise SystemExit(1)
if __name__=='__main__': main()
