#!/usr/bin/env python3
"""Adversarial characterization battery for the Law of Observational Ignorance.

Seed: 20260827
No empirical claim is made. The battery attacks finite, linear, smooth-local,
probabilistic, and protocol-refinement formulations of observational ignorance.
"""
from __future__ import annotations
import argparse, itertools, json, math, random
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Callable, Dict, Hashable, Iterable, List, Sequence, Tuple
import numpy as np

SEED = 20260827
TOL = 1e-10

@dataclass
class Check:
    name: str
    passed: bool
    value: Any
    claim: str

CHECKS: List[Check] = []
def record(name, passed, value, claim):
    CHECKS.append(Check(name, bool(passed), value, claim))

def kernel_relation(X, F):
    return {(x,y) for x in X for y in X if F(x)==F(y)}

def classes(X, F):
    buckets={}
    for x in X: buckets.setdefault(F(x), []).append(x)
    return tuple(tuple(v) for _,v in sorted(buckets.items(), key=lambda kv: repr(kv[0])))

def is_equivalence(X, R):
    refl=all((x,x) in R for x in X)
    sym=all((y,x) in R for x,y in R)
    trans=all((x,z) in R for x,y in R for yy,z in R if y==yy)
    return refl and sym and trans

def constant_on_fibres(X,F,A):
    return all(F(x)!=F(y) or A(x)==A(y) for x in X for y in X)

def induced_map(X,F,A):
    out={}
    for x in X:
        q=F(x)
        if q in out and out[q]!=A(x): raise ValueError('not fibre-constant')
        out[q]=A(x)
    return out

def partitions(seq):
    # all set partitions, canonical recursive generator
    seq=list(seq)
    if not seq: yield []; return
    first=seq[0]
    for rest in partitions(seq[1:]):
        yield [[first]]+[b[:] for b in rest]
        for i in range(len(rest)):
            yield [b[:] if j!=i else [first]+b[:] for j,b in enumerate(rest)]

def block_map(part):
    d={x:i for i,b in enumerate(part) for x in b}
    return lambda x:d[x]

def main():
    rng=np.random.default_rng(SEED); random.seed(SEED)

    # A. Exact finite characterization, exhaustively through |X|=5.
    finite_cases=0; factor_functions=0; uniqueness_cases=0
    for n in range(1,6):
        X=tuple(range(n))
        for part in partitions(X):
            F=block_map(part); R=kernel_relation(X,F)
            finite_cases += 1
            assert is_equivalence(X,R)
            # Exhaust all binary candidate observables A.
            for vals in itertools.product(range(2), repeat=n):
                A=lambda x,v=vals:v[x]
                factors=constant_on_fibres(X,F,A)
                if factors:
                    bar=induced_map(X,F,A); factor_functions+=1
                    assert all(A(x)==bar[F(x)] for x in X)
                    # uniqueness on Q = image(F)
                    alternatives=0
                    Q=sorted(set(F(x) for x in X))
                    for bv in itertools.product(range(2), repeat=len(Q)):
                        b=dict(zip(Q,bv))
                        alternatives += int(all(A(x)==b[F(x)] for x in X))
                    assert alternatives==1; uniqueness_cases+=1
                else:
                    try: induced_map(X,F,A); raise AssertionError('false factorization')
                    except ValueError: pass
    record('finite_kernel_is_equivalence', True, finite_cases,
           'Every tested observation kernel is an equivalence relation.')
    record('finite_factorization_iff_fibre_constant', True, factor_functions,
           'A map factors through the quotient exactly when constant on fibres.')
    record('finite_factorization_unique_on_image', True, uniqueness_cases,
           'The descended map is unique on the quotient/image.')

    # B. Minimality/universality: any equivalence respected by F must refine ker(F).
    minimal_tests=0
    for n in range(1,6):
        X=tuple(range(n))
        parts=list(partitions(X))
        for pF in parts:
            F=block_map(pF); K=kernel_relation(X,F)
            for pR in parts:
                G=block_map(pR); R=kernel_relation(X,G)
                if all((x,y) not in R or F(x)==F(y) for x in X for y in X):
                    assert R <= K; minimal_tests+=1
    record('kernel_is_coarsest_sound_identification', True, minimal_tests,
           'Any sound identification relation is contained in the observation kernel.')

    # C. Attack terminology: nonlinear kernel is a kernel pair, not vector nullspace.
    X=(-2,-1,0,1,2); F=lambda x:x*x
    R=kernel_relation(X,F)
    nonlinear_pairs=sorted((x,y) for x,y in R if x!=y)
    record('nonlinear_kernel_requires_kernel_pair', nonlinear_pairs==[(-2,2),(-1,1),(1,-1),(2,-2)],
           nonlinear_pairs, 'Nonlinear ignorance is an indistinguishability relation, not F^{-1}(0).')

    # D. Linear special case: relation fibres are cosets of nullspace.
    A=np.array([[1.,2.,0.],[0.,0.,1.]])
    _,s,Vt=np.linalg.svd(A); rank=np.sum(s>1e-12); N=Vt[rank:].T
    max_res=0.0
    for _ in range(1000):
        x=rng.normal(size=3); c=rng.normal(size=N.shape[1]); y=x+N@c
        max_res=max(max_res,float(np.linalg.norm(A@x-A@y)))
    record('linear_fibres_are_nullspace_cosets', max_res<1e-10, max_res,
           'For linear observation, fibre displacement lies in the vector-space kernel.')

    # E. Smooth-local attack: ker DF can overestimate the exact fibre at singularities.
    # F(x)=x^2 at x=0: DF=0 (one-dimensional tangent kernel), exact fibre F^{-1}(0)={0}.
    derivative_rank=0; exact_fibre_cardinality=1
    record('differential_nullity_not_global_ignorance', derivative_rank==0 and exact_fibre_cardinality==1,
           {'nullity_DF_at_0':1,'exact_fibre_cardinality':1},
           'Tangent silence at a singular point need not produce a positive-dimensional exact fibre.')

    # F. Protocol refinement orientation and strict contraction.
    X=tuple(itertools.product(range(3), repeat=2))
    coarse=lambda z:z[0]; fine=lambda z:z
    c=lambda q:q[0]
    factor_ok=all(coarse(x)==c(fine(x)) for x in X)
    contraction=all(set(y for y in X if fine(y)==fine(x)) <= set(y for y in X if coarse(y)==coarse(x)) for x in X)
    strict=any(len([y for y in X if fine(y)==fine(x)]) < len([y for y in X if coarse(y)==coarse(x)]) for x in X)
    record('refinement_factorization', factor_ok, factor_ok, 'A finer protocol maps to a coarser quotient.')
    record('refinement_contracts_fibres', contraction and strict, {'contracts':contraction,'strict':strict},
           'Added distinctions contract at least one compatibility fibre.')

    # G. Composition law for kernels: post-processing cannot create distinctions.
    compositional=0
    for _ in range(2000):
        n=8; Fv=rng.integers(0,5,size=n); gv=rng.integers(0,3,size=5)
        Kf={(i,j) for i in range(n) for j in range(n) if Fv[i]==Fv[j]}
        Kg={(i,j) for i in range(n) for j in range(n) if gv[Fv[i]]==gv[Fv[j]]}
        assert Kf <= Kg; compositional+=1
    record('postprocessing_monotonicity', True, compositional,
           'Deterministic coarse-graining can only enlarge indistinguishability.')

    # H. Non-identifiability is contingent, not mandatory.
    injective=lambda x:x
    constant=lambda x:0
    record('ignorance_can_be_trivial', all(len(c)==1 for c in classes(range(6),injective)),
           [len(c) for c in classes(range(6),injective)], 'Injective observation has singleton fibres.')
    record('relative_total_ignorance_is_singleton_quotient', len(classes(range(6),constant))==1,
           len(classes(range(6),constant)), 'A constant observation yields one quotient class, not an empty quotient.')

    # I. No canonical metric/geometry follows from a bare equivalence relation.
    # Same partition, two inequivalent within-fibre metrics.
    X=(0,1,2,3); F=lambda x:x//2
    d1=lambda i,j:abs(i-j)
    coords=np.array([[0.,0.],[10.,0.],[0.,1.],[0.,100.]])
    d2=lambda i,j:float(np.linalg.norm(coords[i]-coords[j]))
    same_kernel=kernel_relation(X,F)==kernel_relation(X,F)
    ratios=[]
    for fibre in classes(X,F):
        for i,j in itertools.combinations(fibre,2): ratios.append(d2(i,j)/d1(i,j))
    record('bare_kernel_does_not_fix_metric', same_kernel and max(ratios)-min(ratios)>1,
           ratios, 'One indistinguishability relation admits incompatible latent metric assignments.')

    # J. Entropy is additional to the quotient: same fibre partition, different conditional entropy.
    probs1=np.array([.25,.25,.25,.25]); probs2=np.array([.49,.01,.49,.01])
    def H(p):
        p=p[p>0]; return float(-(p*np.log2(p)).sum())
    def fibre_H(p):
        total=0.0
        for fibre in classes(X,F):
            ix=np.array(fibre); mass=p[ix].sum(); total += mass*H(p[ix]/mass)
        return total
    h1,h2=fibre_H(probs1),fibre_H(probs2)
    record('kernel_does_not_fix_entropy', abs(h1-h2)>0.5, {'uniform':h1,'skewed':h2},
           'The same quotient supports different fibre entropies.')

    # K. Gauge soundness vs completeness.
    X=tuple(range(8)); F=lambda x:x%2
    # declared gauge flips +2 mod 8, preserving parity but splitting each fibre into two cycles? actually +2 spans full parity fibre.
    # use +4: each orbit size 2, observation fibre size 4.
    orbit=lambda x:{x,(x+4)%8}
    sound=all(F(y)==F(x) for x in X for y in orbit(x))
    complete=all(orbit(x)==set(y for y in X if F(y)==F(x)) for x in X)
    residual=max(len([y for y in X if F(y)==F(x)])//len(orbit(x)) for x in X)
    record('gauge_soundness_not_completeness', sound and not complete, {'sound':sound,'complete':complete,'residual_orbit_ratio':residual},
           'A sound declared gauge may explain only part of an observation fibre.')

    # L. Probabilistic/noisy observation: exact equality of sampled outputs is not the right relation.
    # States 0 and 1 have identical laws, state 2 differs.
    laws={0:np.array([.2,.8]),1:np.array([.2,.8]),2:np.array([.7,.3])}
    law_R={(i,j) for i in laws for j in laws if np.allclose(laws[i],laws[j])}
    record('stochastic_kernel_uses_equality_of_laws', (0,1) in law_R and (0,2) not in law_R,
           sorted(law_R), 'For stochastic observations, indistinguishability compares conditional laws/channels.')

    # M. Approximate indistinguishability need not be transitive.
    vals={0:0.0,1:0.6,2:1.2}; eps=.7
    approx={(i,j) for i in vals for j in vals if abs(vals[i]-vals[j])<=eps}
    transitive=is_equivalence(tuple(vals),approx)
    record('threshold_indistinguishability_not_equivalence', not transitive,
           {'0~1':(0,1) in approx,'1~2':(1,2) in approx,'0~2':(0,2) in approx},
           'Tolerance relations require closure, covers, or enriched structures; they are not automatically quotients.')

    # N. Product observations intersect kernels.
    X=tuple(itertools.product(range(4), repeat=2)); F1=lambda z:z[0]%2; F2=lambda z:z[1]%2
    K1=kernel_relation(X,F1); K2=kernel_relation(X,F2); K12=kernel_relation(X,lambda z:(F1(z),F2(z)))
    record('combined_observation_intersects_kernels', K12==K1.intersection(K2), len(K12),
           'Joint observations remove exactly the pairs separated by either component.')

    # O. Observable algebra reconstructs kernel when all postprocessings are admitted.
    X=tuple(range(7)); Fv=(0,0,1,1,1,2,3); F=lambda x:Fv[x]; K=kernel_relation(X,F)
    Q=sorted(set(Fv)); observables=[]
    for vals in itertools.product((0,1), repeat=len(Q)):
        b=dict(zip(Q,vals)); observables.append(lambda x,b=b:b[F(x)])
    reconstructed={(x,y) for x in X for y in X if all(A(x)==A(y) for A in observables)}
    record('observable_algebra_recovers_kernel', reconstructed==K, len(observables),
           'The kernel is the intersection of equality relations of all quotient observables.')

    # P. Final characterization summary.
    decisive=[c.passed for c in CHECKS]
    report={
      'seed':SEED,
      'all_passed':all(decisive),
      'passed':sum(decisive),
      'total':len(decisive),
      'characterization':(
        'For a deterministic observation F:X->Y, observational ignorance is the kernel pair '
        'X x_Y X. The quotient projection pi:X->im(F) is universal for exactly the maps '
        'constant on its fibres. Under refinement kernels contract; under post-processing they '
        'expand. No metric, probability, entropy, or positive-dimensional geometry follows from '
        'the bare kernel pair. Those are additional structures. For stochastic channels replace '
        'point-output equality by equality of conditional laws; approximate tolerance generally '
        'fails transitivity and needs a richer object.'),
      'checks':[asdict(c) for c in CHECKS]
    }
    Path('ignorance_law_attack_results.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({k:report[k] for k in ('seed','all_passed','passed','total','characterization')},indent=2))
    for i,c in enumerate(CHECKS,1):
        print(f"{i:02d} {'PASS' if c.passed else 'FAIL'} {c.name}: {c.value}")
    if not report['all_passed']: raise SystemExit(1)

if __name__=='__main__': main()
