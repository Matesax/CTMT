Synthetic example track, not a real release.

example_run.csv: 10 s at 60 fps, columns t,x,y (origin at the pivot, y upward, length 0.97).
Truth: bob held at 0.2 rad until t = 1.0 s, then released from rest; omega = 3.10 rad/s, gamma = 0.008 1/s.
Tracking error: uniform within +-0.003 rad on every frame. Seed 20261124.

release.json  t0 by the pre-registered rule (release frame + 2 s)
stage1.json   status, interval, lock depth, least-squares comparison, commitment (reads only t0 .. t0 + 2.4 s)
stage2.json   the target reading at t0 + 5.0 s, inside the interval or not

Rerun:
  python3 -I ../rg_pendulum.py release ../class_default.json example_run.csv
  python3 -I ../rg_pendulum.py stage1  ../class_default.json example_run.csv --t0 <t0 from release.json>
  python3 -I ../rg_pendulum.py stage2  ../class_default.json example_run.csv stage1.json
