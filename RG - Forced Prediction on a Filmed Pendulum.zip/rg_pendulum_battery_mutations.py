#!/usr/bin/env python3
"""Mutation suite for rg_pendulum_battery.py.

Each mutation changes one line of the tool (or of the battery's reference data) so that a claim of the pendulum paper
becomes false. It is caught only when the targeted group fails; the battery is run on that group alone. A mutation that
survives is a defect of the battery; a crash is a defect of the suite, not a catch. Runs in temporary copies; shipped
files are not modified.

    python3 -I rg_pendulum_battery_mutations.py [--jobs 2] [--only PB,PC]
"""
import argparse, json, os, shutil, subprocess, sys, tempfile
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
NAME = 'rg_pendulum_battery'
TOOL = 'rg_pendulum.py'
MUTATIONS = [  # (group, description, file, old, new)
    ('PA', 'integration step five times coarser', TOOL, 'DT = 0.02 ', 'DT = 0.1 '),
    ('PA', 'damping sensitivity with the wrong sign', TOOL, 'dS[:, 1, 3] -= 2 * v', 'dS[:, 1, 3] += 2 * v'),
    ('PB', 'model-error budget eta left out of the record bound', TOOL,
     "return C['eps_track'] + C['eta'] + C['V'] * C['dt_time'] + NUM_ERR", "return C['eps_track'] + C['V'] * C['dt_time'] + NUM_ERR"),
    ('PB', 'interval pruning without its inflation', TOOL, 'D = (1 + rho) * np.einsum', 'D = 0.3 * np.einsum'),
    ('PC', 'linearization remainder dropped', TOOL, 'return 2 * np.max(np.abs(thx - lin), axis=1)', 'return 0 * np.max(np.abs(thx - lin), axis=1)'),
    ('PD', 'lock criterion four times stricter', TOOL, "'LOCKED' if hiF - loF <= 2 * tol", "'LOCKED' if hiF - loF <= 0.5 * tol"),
    ('PE', 'lock depth reported as the full window', TOOL, '    lo, hi, at = 0, len(r), full\n', '    return len(r), full\n'),
    ('PF', 'amplitude bound not enforced', TOOL, 'if abs(r[0]) > A + eps:', 'if abs(r[0]) > 3 * A + eps:'),
    ('PF', 'calibration never flags the range edge', TOOL, '< 0.1 * wr or', '< 0.0 * wr or'),
    ('PG', 'stage 1 reads past the record window', TOOL, "rows = read_rows(csv, t0, last)", "rows = read_rows(csv, t0, last + C['tF'])"),
    ('PG', 'release threshold ten times smaller', TOOL, 'hold=0.5, k=5.0)', 'hold=0.5, k=0.5)'),
    ('PG', 'stage 2 does not verify the commitment', TOOL,
     "if sha(json.dumps(body, sort_keys=True).encode()) != s1['commitment']:", 'if False:'),
    ('PH', 'least-squares interval at 68% presented as 95%', TOOL, 'half = 1.96 * math.sqrt', 'half = 1.0 * math.sqrt'),
    ('PI', 'prediction seed ignored', TOOL, 'rng = np.random.default_rng(seed); depths', 'rng = np.random.default_rng(); depths'),
    ('PI', 'class hash independent of the class', TOOL, "return sha(json.dumps(C, sort_keys=True).encode())", "return sha(b'class')"),
]


def run(mut):
    group, desc, rel, old, new = mut
    base = open(os.path.join(HERE, rel)).read()
    if base.count(old) != 1:
        return group, desc, 'anchor not found exactly once -> SUITE DEFECT', False
    with tempfile.TemporaryDirectory() as tmp:
        work = os.path.join(tmp, 'b')
        shutil.copytree(HERE, work, ignore=shutil.ignore_patterns('__pycache__', NAME + '_results.json', NAME + '_mutations.py',
                                                                  '*.log', 'pred', 'paper', '*.zip', 'r1.json'))
        open(os.path.join(work, rel), 'w').write(base.replace(old, new))
        env = dict(os.environ, RG_PEND_GROUPS=group)
        subprocess.run([sys.executable, '-I', NAME + '.py'], cwd=work, capture_output=True, text=True, env=env)
        try:
            fails = json.load(open(os.path.join(work, NAME + '_results.json')))['failures']
        except Exception:
            fails = ['CRASHED']
    ok = group in fails
    return group, desc, ('caught ' if ok else 'SURVIVED ') + str(fails), ok


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--jobs', type=int, default=2); ap.add_argument('--only', default='')
    a = ap.parse_args(); sel = [m for m in MUTATIONS if not a.only or m[0] in a.only.split(',')]
    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(run, sel))
    for g, d, msg, _ in res:
        print(f'{g}  {d}: {msg}', flush=True)
    caught = sum(r[3] for r in res)
    print(f'{caught} / {len(sel)} caught')
    return 0 if caught == len(sel) else 1


if __name__ == '__main__':
    sys.exit(main())
