#!/usr/bin/env python3
"""Resolution Geometry - hostile battery for the pendulum protocol (rg_pendulum.py).

  PA integrator: RK4 at dt = 0.02 against a step eight times finer stays below the declared numerical error 1e-6 rad;
     forward sensitivities agree with central finite differences
  PB coverage: in-class truths, errors bounded by eps_track + eta, independent / constant offset / sign pattern, at 5
     and 25 records: every interval contains the noise-free future; no in-class release is called INCONSISTENT
  PC tightness: the extremes of the target over the fibre, found from inside (sampled members of the fibre in the
     surviving cells, then constrained optimization, kept only if exactly feasible) lie inside the outer interval, and
     the outer diameter is at most 1.5 times the inner one; three error patterns, 6 and 12 records
  PD lock depth: every in-class release of the sample locks within the window; the status sequence over prefixes is
     monotone (never LOCKED then CORRESPONDENCE), which the bisection of the tool assumes
  PE lock without identification: at the lock depth, members of the fibre still span at least half of the declared
     omega range and half of the declared gamma range
  PF class violations: a sail (gamma = 0.5 or 0.25) and omega 10% off are INCONSISTENT on the full window, amplitude 0.6 is
     OUTSIDE DOMAIN; counterexamples kept: (i) omega = 2.9 LOCKS on a 12-record prefix and misses the target, which is
     why the tool predicts only from the full window; (ii) omega just outside the range (3.02) can stay consistent on the
     full window and lock wrongly; the calibration run flags that case (omega fibre near the edge)
  PG blinding and records: stage 1 output is unchanged when every row after the record window is altered, and it reads
     no row past the window; the release rule finds the release and uses no later row; a missing record frame is an error; stage 2 rejects an edited stage-1 file or a changed class
  PH comparison: with a constant offset (a rest-angle error) on records and target, ordinary least squares with its 95%
     Gaussian prediction interval covers at most 8 of 12 targets while the enclosure covers 12 of 12; with independent
     errors both cover at least 10 of 12
  PI pre-registration: predictions are byte-identical on rerun and change when the class changes

Deterministic seeds. Writes rg_pendulum_battery_results.json.
Run:  python3 -I rg_pendulum_battery.py      (numpy, scipy). Optional: RG_PEND_GROUPS=PA,PB to run a subset.
"""
import copy, hashlib, json, os, shutil, sys, tempfile
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rg_pendulum as T

C0 = T.load_class(HERE / 'class_default.json')
R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        if tag not in FAILS:
            FAILS.append(tag)
        print('FAILED', tag, flush=True)


def inner_points(r, rt, C, cells, n, rng):
    """Exactly integrated parameter points that satisfy every record bound (members of the admissible fibre)."""
    Cc, H = cells; idx = rng.integers(0, len(Cc), n)
    P = Cc[idx] + (2 * rng.random((n, 4)) - 1) * H[idx]
    th, _ = T.integrate(P, np.r_[rt, C['tF']], sens=False)
    ok = np.all(np.abs(th[:, :len(r)] - r[None, :]) <= T.eps_total(C), axis=1)
    return P[ok], th[ok, len(r)]


def write_csv(path, truth, C, rng, noise=0.004, fps=60, L=0.98, offset=0.0):
    fr = np.arange(0, int(9 * fps)) / fps; tt = fr - C['t_start']; th = np.zeros(len(fr)); k = tt >= -1e-9
    th[k] = T.integrate(truth[None], tt[k], sens=False)[0][0]
    th[~k] = truth[0]                                             # bob held at its starting angle before release
    th = th + rng.uniform(-noise, noise, len(fr)) + offset
    rows = ['t,x,y'] + [f'{a:.5f},{L * np.sin(b):.6f},{-L * np.cos(b):.6f}' for a, b in zip(fr, th)]
    Path(path).write_text('\n'.join(rows) + '\n')


TRUTH = np.array([0.15, 0.2, 3.12, 0.02])


def group_PA():
    rng = np.random.default_rng(101); P = np.stack([rng.uniform(-C0['A'], C0['A'], 20), rng.uniform(-C0['V'], C0['V'], 20),
                                                    rng.uniform(*C0['omega'], 20), rng.uniform(*C0['gamma'], 20)], 1)
    ts = np.r_[np.sort(rng.uniform(0, C0['tF'], 12)), C0['tF']]
    ref, _ = T.integrate(P, ts, dt=T.DT / 8, sens=False); out, S = T.integrate(P, ts)
    err = float(np.abs(out - ref).max()); h = 1e-6; fd = np.zeros_like(S)
    for j in range(4):
        a, b = P.copy(), P.copy(); a[:, j] += h; b[:, j] -= h
        fd[:, :, j] = (T.integrate(a, ts, sens=False)[0] - T.integrate(b, ts, sens=False)[0]) / (2 * h)
    serr = float(np.abs(fd - S).max())
    must(err <= T.NUM_ERR and serr <= 1e-6, 'PA')
    R['PA'] = dict(claim='RK4 at dt = 0.02 is within 1e-6 rad of a step 8 times finer on the class; sensitivities match '
                         'finite differences', seed=101, max_error=err, declared=T.NUM_ERR, sensitivity_error=serr)


def group_PB():
    rng = np.random.default_rng(202); rows = []
    for i in range(6):
        tr = T.sample_truth(C0, rng)
        for mode in ('uniform', 'offset', 'sign'):
            r, rt, fut = T.simulate_records(tr, C0, C0['records'], rng, mode)
            for m in (5, 25):
                a = T.analyse(r[:m], rt[:m], C0)
                ok = a['status'] in ('LOCKED', 'CORRESPONDENCE') and a['lower'] <= fut <= a['upper']
                rows.append(dict(truth=i, mode=mode, m=m, status=a['status'], covered=bool(ok),
                                 diameter=a.get('diameter')))
    miss = [x for x in rows if not x['covered']]
    must(len(rows) == 36 and not miss, 'PB')
    R['PB'] = dict(claim='Every in-class release (36 cases, three error patterns) is covered; none is INCONSISTENT',
                   seed=202, cases=len(rows), misses=miss,
                   median_diameter_m5=float(np.median([x['diameter'] or 0 for x in rows if x['m'] == 5])),
                   median_diameter_m25=float(np.median([x['diameter'] or 0 for x in rows if x['m'] == 25])))


def fibre_extremes(r, rt, C, cells, rng):
    """Inner bound on the target range: sampled members of the fibre, then SLSQP from the lowest and highest member,
    keeping the optimum only when it satisfies every record bound to within 1e-9 rad."""
    from scipy.optimize import minimize
    P, y = inner_points(r, rt, C, cells, 20000, rng); E = T.eps_total(C)
    box = list(zip([-C['A'], -C['V'], C['omega'][0], C['gamma'][0]], [C['A'], C['V'], C['omega'][1], C['gamma'][1]]))
    ext = [float(y.min()), float(y.max())]
    for k, (sgn, start) in enumerate(((1, P[np.argmin(y)]), (-1, P[np.argmax(y)]))):
        f = lambda p: sgn * T.integrate(p[None], [C['tF']], sens=False)[0][0, 0]
        cons = [{'type': 'ineq', 'fun': lambda p: E - np.abs(T.integrate(p[None], rt, sens=False)[0][0] - r)}]
        s = minimize(f, start, constraints=cons, bounds=box, method='SLSQP', options={'maxiter': 200, 'ftol': 1e-12})
        if np.all(np.abs(T.integrate(s.x[None], rt, sens=False)[0][0] - r) <= E + 1e-9):   # 1e-9 << NUM_ERR
            ext[k] = min(ext[k], sgn * s.fun) if sgn == 1 else max(ext[k], sgn * s.fun)
    return len(y), ext


def group_PC():
    rng = np.random.default_rng(303); out = []
    for mode in ('uniform', 'sign', 'offset'):
        for m in (6, 12):
            tr = T.sample_truth(C0, rng); r, rt, _ = T.simulate_records(tr, C0, m, rng, mode)
            cells = []; a = T.analyse(r, rt, C0, cells_out=cells)
            n, (lo, hi) = fibre_extremes(r, rt, C0, cells, rng)
            out.append(dict(mode=mode, m=m, members=n, inner=[lo, hi], outer=[a['lower'], a['upper']],
                            contained=bool(a['lower'] <= lo and hi <= a['upper']), ratio=a['diameter'] / (hi - lo),
                            slack=[lo - a['lower'], a['upper'] - hi]))
    must(all(o['contained'] and o['ratio'] <= 1.5 and o['members'] >= 5 for o in out), 'PC')
    R['PC'] = dict(claim='The outer interval contains the optimized extremes of the fibre (6 cases, three error patterns) '
                         'and is at most 1.5 times wider', seed=303, cases=out)


def group_PD():
    rng = np.random.default_rng(404); depths = []
    for i in range(6):
        tr = T.sample_truth(C0, rng); r, rt, _ = T.simulate_records(tr, C0, C0['records'], rng)
        depths.append(T.lock_depth(r, rt, C0)[0])
    r, rt, _ = T.simulate_records(TRUTH, C0, C0['records'], rng); seq = []
    for m in range(4, 26, 3):
        seq.append(T.analyse(r[:m], rt[:m], C0)['status'])
    mono = all(not (seq[k] == 'LOCKED' and seq[k + 1] != 'LOCKED') for k in range(len(seq) - 1))
    must(all(d is not None and d <= C0['records'] for d in depths) and mono and 'CORRESPONDENCE' in seq, 'PD')
    R['PD'] = dict(claim='Every sampled in-class release locks within the window; the prefix status sequence is monotone',
                   seed=404, lock_depths=depths, prefix_statuses=dict(zip(range(4, 26, 3), seq)))


def group_PE():
    rng = np.random.default_rng(505); r, rt, fut = T.simulate_records(TRUTH, C0, C0['records'], rng)
    d, at = T.lock_depth(r, rt, C0); spans = {}
    for name, m in (('lock_depth', d), ('full_window', C0['records'])):
        cells = []; T.analyse(r[:m], rt[:m], C0, cells_out=cells)
        P, y = inner_points(r[:m], rt[:m], C0, cells, 40000, rng)
        spans[name] = dict(records=int(m), members=int(len(P)),
                           omega_span_fraction=float((P[:, 2].max() - P[:, 2].min()) / (C0['omega'][1] - C0['omega'][0])),
                           gamma_span_fraction=float((P[:, 3].max() - P[:, 3].min()) / (C0['gamma'][1] - C0['gamma'][0])),
                           omega_inner=[float(P[:, 2].min()), float(P[:, 2].max())], gamma_inner=[float(P[:, 3].min()), float(P[:, 3].max())])
    must(at['status'] == 'LOCKED' and spans['lock_depth']['gamma_span_fraction'] >= 0.5
         and spans['full_window']['gamma_span_fraction'] >= 0.25 and all(s['members'] >= 50 for s in spans.values()), 'PE')
    R['PE'] = dict(claim='The future is fixed to within tol while the damping law is not: at the lock depth members of the '
                         'fibre span at least half of the declared gamma range, and at least a quarter on the full window '
                         '(sampled members: lower bounds on the spans); omega is narrowed and reported', seed=505, interval_at_lock=[at['lower'], at['upper']], **spans)


def group_PF():
    rng = np.random.default_rng(606); res = {}
    for name, law in (('sail', (3.12, 0.5)), ('light_sail', (3.12, 0.25)), ('omega_low_10pct', (3.12 * 0.9, 0.01)), ('omega_high_10pct', (3.12 * 1.1, 0.01))):
        tr = np.array([0.2, 0.0, law[0], law[1]]); r, rt, _ = T.simulate_records(tr, C0, C0['records'], rng)
        res[name] = T.analyse(r, rt, C0)['status']
    tr = np.array([0.6, 0.0, 3.12, 0.01]); r, rt, _ = T.simulate_records(tr, C0, 3, rng); res['amplitude_0.6'] = T.analyse(r, rt, C0)['status']
    tr = np.array([0.2, 0.0, 2.9, 0.01]); r, rt, fut = T.simulate_records(tr, C0, C0['records'], np.random.default_rng(7))
    pre = T.analyse(r[:12], rt[:12], C0); full = T.analyse(r, rt, C0)
    prefix_cx = dict(prefix_status=pre['status'], prefix_covers=bool(pre.get('lower', 9) <= fut <= pre.get('upper', -9)),
                     full_status=full['status'])
    blind = []; brng = np.random.default_rng(11)
    for k in range(6):
        tr = T.sample_truth(C0, brng); tr[2], tr[3] = 3.02, 0.01
        r, rt, fut = T.simulate_records(tr, C0, C0['records'], brng); a = T.analyse(r, rt, C0)
        blind.append(dict(status=a['status'], covers=None if 'lower' not in a else bool(a['lower'] <= fut <= a['upper'])))
    with tempfile.TemporaryDirectory() as tmp:
        p = Path(tmp) / 'calib.csv'; write_csv(p, np.array([0.18, 0.1, 3.02, 0.01]), C0, np.random.default_rng(12), noise=0.003)
        cal = T.calibrate(C0, p, C0['t_start'])
    ok = (res == {'sail': 'INCONSISTENT', 'light_sail': 'INCONSISTENT', 'omega_low_10pct': 'INCONSISTENT', 'omega_high_10pct': 'INCONSISTENT',
                  'amplitude_0.6': 'OUTSIDE DOMAIN'}
          and prefix_cx == dict(prefix_status='LOCKED', prefix_covers=False, full_status='INCONSISTENT')
          and any(b['status'] == 'LOCKED' and b['covers'] is False for b in blind)
          and cal['status'] != 'INCONSISTENT' and cal['omega_fibre_near_edge'] is True)
    must(ok, 'PF')
    R['PF'] = dict(claim='Gross violations are refused; a prefix can lock on a wrong class (so only the full window '
                         'predicts); a law just outside the range can pass and lock wrongly, and calibration flags it',
                   seed=606, controls=res, prefix_counterexample=prefix_cx, blind_band_omega_3_02=blind,
                   calibration_on_blind_band=dict(status=cal['status'], omega_fibre=cal['fibre']['omega'] if cal['fibre'] else None,
                                                  near_edge=cal['omega_fibre_near_edge'], eta_min=cal['eta_min']))


def group_PG():
    rng = np.random.default_rng(707); out = {}
    with tempfile.TemporaryDirectory() as tmp:
        p = Path(tmp) / 'run.csv'; write_csv(p, TRUTH, C0, rng)
        s1 = T.stage1(C0, p)
        last = C0['t_start'] + C0['tau'] * (C0['records'] - 1)
        lines = p.read_text().splitlines(); alt = [lines[0]]
        for ln in lines[1:]:
            t = float(ln.split(',')[0])
            alt.append(ln if t <= last + T.HALF_FRAME else f'{t:.5f},0.5,0.1')
        q = Path(tmp) / 'alt.csv'; q.write_text('\n'.join(alt) + '\n'); s1b = T.stage1(C0, q)
        out['unchanged_after_window_edit'] = s1b['commitment'] == s1['commitment']
        out['latest_time_read'] = s1['latest_time_read']; out['window_end'] = last
        drop = [ln for ln in lines if not ln.startswith(f'{C0["t_start"] + 0.5:.5f}')]
        d = Path(tmp) / 'drop.csv'; d.write_text('\n'.join(drop) + '\n')
        try:
            T.stage1(C0, d); out['missing_frame_rejected'] = False
        except ValueError:
            out['missing_frame_rejected'] = True
        s2 = T.stage2(C0, p, s1); out['stage2_inside'] = s2['inside']
        out['explicit_t0_same'] = T.stage1(C0, p, C0['t_start'])['commitment'] == s1['commitment']
        rel, t0 = T.release_time(C0, p); cut = [ln for ln in lines if ln[0] == 't' or float(ln.split(',')[0]) <= rel + 1e-9]
        c = Path(tmp) / 'cut.csv'; c.write_text('\n'.join(cut) + '\n')
        out['release_time'] = rel; out['release_uses_nothing_later'] = T.release_time(C0, c) == (rel, t0)
        bad = copy.deepcopy(s1); bad['analysis']['upper'] += 0.01
        try:
            T.stage2(C0, p, bad); out['edited_stage1_rejected'] = False
        except ValueError:
            out['edited_stage1_rejected'] = True
        C1 = dict(C0); C1['eta'] = 0.01
        try:
            T.stage2(C1, p, s1); out['changed_class_rejected'] = False
        except ValueError:
            out['changed_class_rejected'] = True
    ok = (out['unchanged_after_window_edit'] and out['explicit_t0_same'] and C0['t_start'] <= out['release_time'] <= C0['t_start'] + 0.4
          and out['release_uses_nothing_later'] and out['latest_time_read'] <= last + T.HALF_FRAME and out['missing_frame_rejected']
          and out['stage2_inside'] and out['edited_stage1_rejected'] and out['changed_class_rejected'])
    must(ok, 'PG')
    R['PG'] = dict(claim='Stage 1 is blind to the target; record frames are required; stage-1 and class edits are detected',
                   seed=707, **out)


def group_PH():
    rng = np.random.default_rng(808); E = T.eps_total(C0); tab = {}
    for mode in ('uniform', 'offset'):
        n_cov = e_cov = 0
        for k in range(12):
            tr = T.sample_truth(C0, rng); r, rt, y = T.simulate_records(tr, C0, C0['records'], rng, mode, target=True)
            ls = T.nls(r, rt, C0); n_cov += ls['lower'] <= y <= ls['upper']
            a = T.analyse(r, rt, C0); e_cov += a['status'] in ('LOCKED', 'CORRESPONDENCE') and a['lower'] - E <= y <= a['upper'] + E
        tab[mode] = dict(nls_covered=int(n_cov), enclosure_covered=int(e_cov), of=12)
    ok = tab['offset']['nls_covered'] <= 8 and tab['offset']['enclosure_covered'] == 12 and \
        tab['uniform']['nls_covered'] >= 10 and tab['uniform']['enclosure_covered'] == 12
    must(ok, 'PH')
    R['PH'] = dict(claim='Under a constant bounded offset the 95% least-squares interval under-covers (<= 8/12) and the '
                         'enclosure does not (12/12); under independent errors both cover', seed=808, **tab)


def group_PI():
    a = T.predict(C0, 2, 1); b = T.predict(C0, 2, 1); C1 = dict(C0); C1['tol'] = 0.03; c = T.predict(C1, 2, 1)
    same = json.dumps(a, sort_keys=True) == json.dumps(b, sort_keys=True)
    ok = same and c['class_sha256'] != a['class_sha256'] and a['tool_sha256'] == hashlib.sha256((HERE / 'rg_pendulum.py').read_bytes()).hexdigest()
    must(ok, 'PI')
    R['PI'] = dict(claim='Predictions are reproducible and bound to the class and tool hashes', seed=1, identical_rerun=same,
                   prediction_sample=a)


GROUPS = dict(PA=group_PA, PB=group_PB, PC=group_PC, PD=group_PD, PE=group_PE, PF=group_PF, PG=group_PG, PH=group_PH, PI=group_PI)


def main():
    want = os.environ.get('RG_PEND_GROUPS'); sel = want.split(',') if want else list(GROUPS)
    for g in sel:
        GROUPS[g]()                                               # a crash writes no results: never a pass, never a catch
        print(g, 'done', flush=True)
    R['failures'] = FAILS; R['groups_run'] = sel
    R['source_sha256'] = {f: hashlib.sha256((HERE / f).read_bytes()).hexdigest()
                          for f in ('rg_pendulum.py', 'rg_pendulum_battery.py', 'class_default.json')}
    (HERE / 'rg_pendulum_battery_results.json').write_text(json.dumps(R, indent=1, sort_keys=True))
    print(json.dumps({k: v for k, v in R.items() if k not in ('PI',)}, indent=1, sort_keys=True)[:6000])
    return 1 if FAILS else 0


if __name__ == '__main__':
    sys.exit(main())
