# Resolution Geometry in Practice: Forced Prediction on a Filmed Pendulum

Protocol, tool and battery for a pre-registered physical test of RG's forcing criterion. You film a pendulum with a
phone; the tool decides from 25 early readings whether the angle 2.6 s after the last reading is **forced** (one value to
within ±0.02 rad on every state and every law of the declared class that agrees with the readings), and you check it
against the frame you have not yet looked at.

Paper: `RG - Forced Prediction on a Filmed Pendulum.pdf` (source `RG_Pendulum_Protocol.tex`). The programme's main
print and README are in `CTMT` repository.

## What is here

| File | What it is |
|---|---|
| `rg_pendulum.py` | the tool: `predict`, `calibrate`, `release`, `stage1`, `stage2` |
| `class_default.json` | the default class (1 m pendulum, 60 fps, target 5.0 s after the first record) |
| `predictions_default.json` | frozen predictions for the default class (200 simulated releases, seed 1), bound to the SHA-256 of the class and the tool |
| `rg_pendulum_battery.py` | hostile battery, groups PA–PI; writes `rg_pendulum_battery_results.json` |
| `rg_pendulum_battery_mutations.py` | fifteen one-line falsifications of the tool; each must fail its target group |
| `example/` | a synthetic track (`example_run.csv`) with its `release.json`, `stage1.json`, `stage2.json` |

```
pip install -r requirements.txt           # numpy, scipy
python3 -I rg_pendulum_battery.py          # about 4 minutes; byte-identical on rerun
python3 -I rg_pendulum_battery_mutations.py --jobs 2
```

## Running the test

1. **Build and film calibration releases** (Sections 4–5 of the paper): still-bob clip, then a few releases that will
   never be scored. Track them in Tracker with the origin at the pivot and the y axis upward; export `t,x,y`.
2. **Declare the class.** Copy `class_default.json`; set `omega` from your length (±3% or wider), `rest_angle` from
   the still clip, `eps_track` from its spread. For each calibration release:
   `python3 -I rg_pendulum.py calibrate class.json calib1.csv --t0 <release + 2 s>`. Set `eta >= 2 * max eta_min`;
   widen `omega` if any calibration flags `omega_fibre_near_edge`.
3. **Freeze.** `python3 -I rg_pendulum.py predict class.json --truths 200 --seed 1` (about half an hour). Deposit the
   class, the tool, `predictions.json` and the paper with a timestamp (Zenodo or OSF).
4. **Film at least ten test releases and two sail releases.** Track every frame.
5. **Stage 1, per release:** `release class.json run.csv`, then `stage1 class.json run.csv --t0 <t0 from release.json>`.
   Decide exclusions now. Deposit all `stage1.json` files.
6. **Stage 2, per release:** `stage2 class.json run.csv stage1.json`. Report every release.

A miss or an `INCONSISTENT` test release refutes the declaration, and the protocol has failed. Report it.

## What a pass shows

A locked future, correct on every release, with the damping law left undetermined: a prospective physical instance
of forced prediction across an unresolved law. It is not evidence of physics beyond Newtonian mechanics, and the
estimator is set-membership estimation (Schweppe 1968). Kept counterexamples (battery PF): a prefix lock on a wrong
law, and a law 0.3% outside the class that locks wrongly. The second is why the calibration edge check exists.

Author: Matěj Rada, MatejRada@email.cz. License: CC BY-NC-ND 4.0.
