# RG gravity duality: lock report

**Thesis.** Gravity has two forms, structure and energy footprint. Newton works where they overlap and fails
where they diverge.

**Locked form.** A static field is a pair (h, N): structure (rods, radar) and energy footprint (clocks,
redshift, support). Free motion at asymptotic speed v follows the Jacobi pencil j_v = (N^-2 - 1 + v^2) h.

| Result | Statement | Witness |
|---|---|---|
| Flat structure is exactly Newtonian | if h is flat, all orbits at all speeds (light included) are Newtonian in Φ_kin = (c²/2)(1 − N⁻²), at any field strength | D03: independent 4D geodesic vs Newton ODE, 1.9e-9 rad |
| Exact affine law | v² n_v² = ψ²(N⁻² − 1) + ψ² v² in isotropic radius, after Firsov inversion; slope = structure, intercept = energy | D04–D06 |
| Representability ⟺ flat h | two functional speeds are Newton-representable by any potential iff h is flat | D05 (6 metrics) |
| Single-speed no-go | one speed never refutes Newton | D10 |
| Newton's miss = structure | index error is exactly (ψ² − 1)(v2² − v1²); angle miss ≈ A_S(v2)(1 − v1²/v2²) | D10 (0.1–3.2%) |
| Energy channel | trajectory, support and clock potentials agree at 1st order and split at 2nd; support/orbit force ratio is N² | D02, D13 |
| Failure point | structure: ε < ε_crit = γ\|v1²−v2²\|/(2+γ(v1²+v2²)), radius-independent in the weak field; energy: 1 − N² > δ | D12, D13 |

**Prior hostile findings, absorbed.**
- α v² refuted at finite strength: this is the nonlinear α ↔ n map; after inversion the law is exact (D07).
- A_S = 0 without α v² scaling: the flat-h orbit is exactly Newtonian with a non-Coulomb Φ_kin (D08).
- Single-b two-speed collision: a finite panel gives a correspondence; the functional panel separates the two
  metrics (D09).

**Battery.** 14/14 locked. 6/6 canaries rejected. Master seed 20261024. Reruns identical.

**Limits.**
- Static, spherical, asymptotically flat; no orbiting.
- Functional panel approximated by 700 impact parameters plus an analytic tail.
- Synthetic data only; not blind.
- γ is measured, not derived. No GR derivation.
