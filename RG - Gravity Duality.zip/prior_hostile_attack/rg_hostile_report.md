# RG hostile scattering and geometry-identifiability attack

## Status and provenance

This is a newly constructed analytical and numerical development battery. All forward-model records are synthetic. No observational dataset, literature novelty search, empirical gravity test, or stress reconstruction was performed. The final executable has 41 passing assertions, including counterexample detection. Passing assertions do not mean the pasted conjectures all passed.

The test panel is written before forward evaluation. This is not independent preregistration: during development an arbitrary 1e-3 effect-size threshold in the flat-spatial canary was corrected to 1e-6 after the initial run stopped at an effect of 1.598e-4. The correction is recorded in the JSON. The model collision is deliberately fitted to two records; the clock and third-speed records are withheld from that fit, but are not empirical blind data.

## 1. Scope

Static, spherical, asymptotically flat scattering on an admitted exterior domain, in areal radius, with asymptotic time normalization and G=c=1. Competitor metrics need not satisfy Einstein equations. The scattering integrator rejects missing turning points and quadrature warnings; it is not a general capture classifier or an exhaustive metric search. Strong-lensing winding, finite endpoints, stationary shift terms, and time dependence require different boundary/domain treatment.

## 2. Exact local relation and its sign

For a massive geodesic in ds^2=-N^2 c^2 dt^2+h, the Jacobi factor is p^2=E^2/(c^2 N^2)-m^2 c^2. For local speed v, d log p=-(c^2/v^2)d log N. A path extremizing integral p dl_h therefore satisfies the vector relation

    nabla_T T = -(c^2/v^2) (grad_h log N)_perp.

The support acceleration of a static observer is a_support=c^2 grad_h log N. Thus the signed vector path curvature is -a_support,perp/v^2. A positive scalar bending convention can use the inward magnitude. Omitting this convention is a sign error. The massless limit uses the optical metric h/N^2.

This is not a proof that spatial flatness is Newton's only possible error. Even for h flat and N=exp(-m/r), where support acceleration equals m/r^2, relativistic local speed obeys v_local^2=1-(1-v_infinity^2)exp(-2m/r), not the Newtonian v_infinity^2+2m/r. The finite-strength lapse response can differ independently of spatial curvature.

## 3. Gauss-Bonnet split on the tested domain

For h=B(r)^2 dr^2+r^2 dphi^2, Gaussian curvature is

    K_h=B'(r)/(r B(r)^3).

With an asymptotic, simple scattering boundary and consistent inward bending convention,

    alpha=AE+AS,
    AE=integral_gamma kappa_h dl_h,
    AS=-integral_D K_h dA_h
      =integral_path (1-1/B(r)) dphi.

The radial primitive follows from K_h B r=-d(1/B)/dr. Schwarzschild has B=1/N and hence AS=integral(1-N)dphi. This formula is not a generic finite-endpoint or multiple-winding formula without additional boundary terms.

The split is geometrically meaningful relative to the chosen static observer congruence. It is not a decomposition independent of all possible spacetime slicings. Nor do two deflection values directly measure the two path integrals without a model.

The harness evaluates alpha from the geodesic radial integral, AE from the Jacobi curvature integrand, and AS from the Gaussian-curvature radial primitive. Schwarzschild deflections are also checked by an independent orbit ODE. A general-metric ODE separately checks the fitted collision. Symbolic checks cover the Jacobi gradient identity, Gaussian curvature, its primitive, and radial reparameterization.

## 4. Newton canary: first order is not exact

For a fixed-shape Newtonian potential lambda Phi, rescaling time makes orbit shape depend on lambda/v_infinity^2, with impact parameter and other dimensionless initial data held fixed. This does not make alpha v_infinity^2 constant at finite strength.

For an attractive inverse-square potential, exactly:

    alpha_Newton=2 atan(mu/(b v_infinity^2)).

Thus alpha v_infinity^2 is constant only to first order in source strength. In this particular potential, v_infinity^2 tan(alpha/2)=mu/b is the exact relation. That replacement is not universal for arbitrary Newtonian potentials.

At mu/b=0.02, speeds 0.2 and 0.8, the exact Newtonian angles are 0.9272952180016121 and 0.06247966686053654 radians. The proposed linear two-speed slope is 0.004825296784464842. An exact interpretation of that slope as non-Newtonian structure would falsely reject a Newtonian model.

A second canary uses N^2=1-2m/r, B=1. Its spatial contribution AS vanishes exactly, yet the same slope at speeds 0.3 and 0.8 is -0.00015982837086266703. Therefore AS=0 does not enforce exact linear speed scaling.

## 5. Corrected two-speed theorem

At fixed nonzero asymptotic speeds, under a first-order weak-scattering expansion in a declared two-coefficient model,

    alpha(b,v)=A(b)/v^2+S(b)+R(b,v).

For a point-source first-order metric family,

    A=2GM/b,
    S=2 gamma GM/(b c^2).

Distinct speeds identify A and S if R is absent or bounded. This is an exact algebraic identification result for the truncated model, not for arbitrary metric functions.

The contribution ratio is AS/AE=gamma v^2/c^2 at leading order. Gamma itself is c^2 S/A, not the unnormalised ratio of the contributions.

The fitted slope has contamination

    S_hat-S=(v1^2 R1-v2^2 R2)/(v1^2-v2^2).

For bounded angular errors epsilon_i and bounded model remainders eta_i, with exact speeds and impact parameter, a valid worst-case bound is

    |S_hat-S| <= [v1^2(epsilon1+eta1)+v2^2(epsilon2+eta2)]/|v1^2-v2^2|.

Speed, impact-parameter, source, and calibration errors must also be included when present. A common epsilon expression is a worst-case bound, not a Gaussian standard deviation. Correlations matter for statistical propagation. Nearby speeds make the inverse problem ill-conditioned.

## 6. Exact-geodesic numerical collision

Use u=b/r, epsilon=m/b, and the independent metric coefficients

    N^2=1-2 epsilon u+q epsilon^2 u^2,
    B^(-2)=1-2 gamma epsilon u+beta epsilon^2 u^2.

The parameter q is just a metric coefficient here, not an assumed physical charge. Beta is not the standard PPN beta.

At epsilon=0.025, the baseline (gamma,q,beta)=(1,0,0) and an alternative fitted with beta=0.8 agree at v=0.5 and v=0.9 to numerical tolerance. No first-order scattering formula is used for this fit.

The alternative is:

    gamma=1.0078727217683385
    q=-0.01030885838607218
    beta=0.8

Maximum fitted angle difference: 3.1086244689504383e-15 radians in the quadrature implementation. Independent orbit ODE differences are about 1.8e-14 and 1.1e-13 radians. These figures demonstrate a numerical collision, not an exact symbolic equality theorem.

At r=b, the alternative-minus-baseline clock lapse differs by -3.305213584936517e-6. At the withheld third speed v=0.7, the angle differs by 3.7363258353906303e-7 radians. The geometries are not merely coordinate relabelings: areal radius and asymptotic time normalization are fixed, and the anchored lapse differs.

The two-speed Jacobian has rank two for three independent metric parameters. This is consistent with a local residual family; a numerical rank test alone is not a global uniqueness theorem.

## 7. Stress and unsampled-interior boundary

Even successful identification of exterior scattering does not identify an interior stress tensor. Without field equations, stress is an independent physical target. With Einstein equations declared, stress requires the relevant metric derivatives and the field equation; it is not obtained from a two-angle panel alone.

An exact observation-collision construction is available for a restricted exterior protocol: modify the metric smoothly in a region disjoint from every admitted probe path and detector. The exterior records are unchanged while interior curvature can change. This follows from locality of the forward geodesic problem on the retained region. It is a scoped analytical counterexample, not a numerical exhaustive search. Independent interior transfer measurements or dynamical assumptions are needed to exclude it.

## 8. Results and limitations

Final battery: 41/41 assertions passed. Nine frozen static metric cases include Schwarzschild weak and stronger scattering, flat spatial geometry, and positive and negative spatial coefficients. Maximum |alpha-AE-AS| across those cases is 2.426346273963313e-13 radians. Independent Schwarzschild orbit ODE discrepancies are below 2.7e-13 radians in the tested cases.

The stationary-shift and time-dependence checks only test explicit input guards that return ABSTAIN. They do not establish that rotation or time dependence can be detected from observations, and do not simulate those geometries.

No real solar-system, lensing, or gravitational-wave data were retrieved or fitted. No empirical bound, new stress law, universal two-speed uniqueness theorem, or derivation of Einstein dynamics is claimed.

## 9. Lock ledger

- Local Jacobi curvature relation: derived under static metric/geodesic coupling, with corrected vector sign.
- Gauss-Bonnet split: derived and numerically supported on the declared asymptotic spherical scattering domain.
- First-order two-speed coefficient identification: conditional algebraic closure, requiring controlled remainders.
- Universal exact alpha v^2 Newton test: refuted by an exact Newtonian canary.
- Universal two-speed geometry identification: defeated by a tolerance-level exact-geodesic collision in a larger family.
- Stress tensor from this scattering panel: not identified.
- Physical bridge or gravitational dynamics from RG alone: not established.

## Reproducibility

Run rg_hostile_attack.py with Python, NumPy, SciPy, and SymPy. It writes rg_hostile_frozen_panel.json and rg_hostile_results.json. The code uses no network access. Output paths are /mnt/data; change OUT if running elsewhere.
