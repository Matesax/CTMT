"""Hostile RG scattering harness. All generated records are synthetic.
Units G=c=1. Static spherical asymptotically flat metrics, areal radius.
No Einstein equation is imposed on competitor metrics.
"""
import json, math, warnings
from pathlib import Path
import numpy as np
from scipy.integrate import quad, solve_ivp, IntegrationWarning
from scipy.optimize import brentq, root

OUT=Path('/mnt/data')
checks=[]
def check(name, condition, detail=None):
    checks.append({'name':name,'passed':bool(condition),'detail':detail})
    if not condition: raise AssertionError(name+': '+str(detail))

def scatter(eps,v,gamma=1.,charge=0.,beta=0.,tol=2e-11):
    # N^2=A; B^(-2)=H. charge and beta are independent metric coefficients.
    if not (0<v<=1 and eps>0): raise ValueError('invalid scattering parameters')
    def A(u): return 1-2*eps*u+charge*eps**2*u*u
    def H(u): return 1-2*gamma*eps*u+beta*eps**2*u*u
    # Q=P/(v^2 A); P coefficients in ascending order.
    co=[v*v,2*eps*(1-v*v),-v*v-charge*eps**2*(1-v*v),2*v*v*eps,-v*v*charge*eps**2]
    def P(u): return sum(c*u**i for i,c in enumerate(co))
    grid=np.linspace(0,min(30.,.499/eps),12001)
    u0=None
    for lo,hi in zip(grid[:-1],grid[1:]):
        if A(hi)<=0 or H(hi)<=0: break
        if P(hi)<0:
            u0=brentq(P,lo,hi,xtol=1e-14); break
    if u0 is None: raise ValueError('no certified scattering turning point in search domain')
    def stableQ(u):
        # P(u)-P(u0), avoiding cancellation near the turning point.
        slope=sum(co[i]*sum(u**j*u0**(i-1-j) for j in range(i)) for i in range(1,5))
        return (u-u0)*slope/(v*v*A(u))
    def integrand(z,kind):
        u=u0*(1-z*z); q=stableQ(u)
        if q<=0: raise ValueError('nonpositive radial kinetic term')
        common=2*u0*z/math.sqrt(q)
        B=1/math.sqrt(H(u))
        if kind=='phi': return B*common
        if kind=='energy':
            minus_dlogN=(eps-charge*eps**2*u)/A(u)
            vl2=1-(1-v*v)*A(u)
            return minus_dlogN*u/vl2*common
        if kind=='structure': return (B-1)*common
    vals={}; errs={}
    with warnings.catch_warnings():
        warnings.simplefilter('error',IntegrationWarning)
        for kind in ['phi','energy','structure']:
            val,err=quad(lambda z:integrand(z,kind),0,1,epsabs=tol,epsrel=tol,limit=300)
            vals[kind]=2*val; errs[kind]=2*err
    return {'alpha':vals['phi']-math.pi,'AE':vals['energy'],'AS':vals['structure'],
            'u0':u0,'quadrature_error_estimates':errs,
            'decomposition_residual':vals['phi']-math.pi-vals['energy']-vals['structure']}

def slope(a1,a2,v1,v2): return (a1*v1*v1-a2*v2*v2)/(v1*v1-v2*v2)
def schwarz_ode(eps,v):
    def f(phi,z): return [z[1],-z[0]+eps*(1/v**2-1)+3*eps*z[0]**2]
    def done(phi,z): return z[0]
    done.direction=-1; done.terminal=True
    sol=solve_ivp(f,[0,20],[0.,1.],events=done,rtol=2e-12,atol=2e-13,max_step=.01)
    if not len(sol.t_events[0]): raise ValueError('no escaping ODE orbit')
    return float(sol.t_events[0][0]-math.pi)

# Freeze the test panel before evaluating it.
frozen=[{'eps':e,'v':v,'gamma':g} for e,v,g in [
 (1e-5,.1,1.),(1e-4,.6,1.),(1e-4,.9,1.),(1e-4,.999,1.),
 (.1,.999,1.),(.01,.6,0.),(.01,.6,.4),(.01,.6,1.6),(.01,.6,-.5)]]
(OUT/'rg_hostile_frozen_panel.json').write_text(json.dumps(frozen,indent=2))
rows=[]
for i,p in enumerate(frozen):
    d=scatter(**p); rows.append(dict(p,**d))
    check('GB decomposition '+str(i),abs(d['decomposition_residual'])<2e-9,d['decomposition_residual'])
    if p['gamma']==1:
        independent=schwarz_ode(p['eps'],p['v'])
        check('independent orbit ODE '+str(i),abs(independent-d['alpha'])<2e-9,independent-d['alpha'])
    if p['gamma']==0: check('flat spatial channel',abs(d['AS'])<1e-14,d['AS'])
# Weak-field coefficient, including a negative spatial-curvature parameter.
for g in [-.5,0.,.4,1.,1.6]:
    d=scatter(1e-7,.6,gamma=g)
    leading=2e-7*(1/.6**2+g)
    check('weak coefficient gamma '+str(g),abs(d['alpha']/leading-1)<3e-5,d['alpha']/leading-1)
# A finite-strength Newton potential violates alpha*v^2 constancy.
e=.02; v1=.2; v2=.8
an1=2*math.atan(e/v1**2); an2=2*math.atan(e/v2**2)
Snew=slope(an1,an2,v1,v2)
check('canary: reject exact alpha*v^2 Newton theorem',abs(Snew)>1e-3,Snew)
# Exact Newton source-strength/speed scaling survives instead.
check('exact Newton simultaneous scaling',abs(2*math.atan(e/v1**2)-2*math.atan((4*e)/(2*v1)**2))<1e-15)
# Flat h, curved lapse: AS=0 does not imply exact Newton scattering.
f1=scatter(.02,.3,gamma=0); f2=scatter(.02,.8,gamma=0)
Sflat=slope(f1['alpha'],f2['alpha'],.3,.8)
check('canary: AS zero does not enforce speed scaling',abs(Sflat)>1e-6 and f1['AS']==0 and f2['AS']==0,Sflat)
# One-speed first-order collision: distinct lapse amplitude and gamma.
v=.6; m1,g1=1.,1.; g2=0.; m2=m1*(1/v**2+g1)/(1/v**2+g2)
check('single-speed leading collision',abs(m1*(1/v**2+g1)-m2*(1/v**2+g2))<1e-14)
check('collision redshift differs',abs(m1-m2)>.1,m2)
# Exact two-speed collision in a larger static metric family.
e=.025; speeds=(.5,.9); target=np.array([scatter(e,v)['alpha'] for v in speeds])
beta_fixed=.8

def residual(z):
    g,q=z
    return np.array([scatter(e,v,gamma=g,charge=q,beta=beta_fixed)['alpha'] for v in speeds])-target
fit=root(residual,[1.,0.],tol=1e-9)
err=float(np.max(np.abs(residual(fit.x))))
check('two-speed exact numerical collision',fit.success and err<2e-10,{'gamma':float(fit.x[0]),'charge':float(fit.x[1]),'beta':beta_fixed,'max_residual':err})
g,q=map(float,fit.x)
u_clock=1.
clock_base=math.sqrt(1-2*e*u_clock)
clock_alt=math.sqrt(1-2*e*u_clock+q*e**2*u_clock**2)
held_v=.7
held_base=scatter(e,held_v)['alpha']; held_alt=scatter(e,held_v,gamma=g,charge=q,beta=beta_fixed)['alpha']
check('held-out clock breaks two-speed collision',abs(clock_alt-clock_base)>1e-6,clock_alt-clock_base)
check('held-out third speed breaks two-speed collision',abs(held_alt-held_base)>1e-8,held_alt-held_base)
# Local rank: two records cannot identify three independent metric parameters.
delta=1e-4; z=np.array([1.,0.,0.]); jac=np.zeros((2,3))
for j in range(3):
    zp=z.copy(); zm=z.copy(); zp[j]+=delta; zm[j]-=delta
    for i,v in enumerate(speeds):
        jac[i,j]=(scatter(e,v,gamma=zp[0],charge=zp[1],beta=zp[2])['alpha']-scatter(e,v,gamma=zm[0],charge=zm[1],beta=zm[2])['alpha'])/(2*delta)
check('two-speed three-parameter rank gate',np.linalg.matrix_rank(jac,tol=1e-8)==2,np.linalg.svd(jac)[1].tolist())
# Independent general-metric orbit ODE checks the fitted collision.
def general_ode(eps,v,gamma,charge,beta):
    def f(phi,z):
        u=z[0]; A=1-2*eps*u+charge*eps**2*u*u
        H=1-2*gamma*eps*u+beta*eps**2*u*u
        Q=(1/A-(1-v*v))/(v*v)-u*u
        Qp=(2*eps-2*charge*eps**2*u)/(v*v*A*A)-2*u
        Hp=-2*gamma*eps+2*beta*eps**2*u
        return [z[1],.5*(Qp*H+Q*Hp)]
    def done(phi,z): return z[0]
    done.direction=-1; done.terminal=True
    sol=solve_ivp(f,[0,20],[0.,1.],events=done,rtol=2e-12,atol=2e-13,max_step=.005)
    if not len(sol.t_events[0]): raise ValueError('no escaping general orbit')
    return float(sol.t_events[0][0]-math.pi)
for i,v in enumerate(speeds):
    alt_ode=general_ode(e,v,g,q,beta_fixed)
    check('independent collision ODE '+str(i),abs(alt_ode-target[i])<2e-10,alt_ode-target[i])
# Symbolic checks independent of quadrature.
import sympy as sy
rr=sy.symbols('r',positive=True); BB=sy.Function('B')(rr)
# Surface of revolution: K=-(1/r) d^2 r/dell^2, dell=B dr.
K=sy.diff(BB,rr)/(rr*BB**3)
check('Gaussian curvature warped-product identity',sy.simplify(K+(1/rr)*(1/BB)*sy.diff(1/BB,rr))==0)
check('GB radial primitive',sy.simplify(K*BB*rr+sy.diff(1/BB,rr))==0)
NN,EE,mm=sy.symbols('N E m',positive=True)
p2=EE**2/NN**2-mm**2
vl2=1-mm**2*NN**2/EE**2
check('Jacobi momentum gradient identity',sy.simplify(sy.diff(sy.log(p2),NN)/2+1/(NN*vl2))==0)
# Coordinate change r=exp(s): both radial and angular coefficients transform.
ss=sy.symbols('s',real=True); BBs=sy.Function('B')(sy.exp(ss))
Kpull=-(1/sy.exp(ss))*(1/(BBs*sy.exp(ss)))*sy.diff(1/BBs,ss)
check('radial reparameterization curvature invariance',sy.simplify(Kpull-K.subs(rr,sy.exp(ss)))==0)

# Finite-precision practical identifiability: close speeds amplify bounded angle error.
noise=1e-6
amp_far=(.2**2+.8**2)/abs(.2**2-.8**2)
amp_near=(.8**2+.80001**2)/abs(.8**2-.80001**2)
check('near-speed conditioning canary',amp_near>10000*amp_far,{'far':amp_far,'near':amp_near})
# Guard-only checks, not rotating/dynamical geodesic simulations.
def static_gate(g0i,dtg): return 'ABSTAIN' if g0i!=0 or dtg!=0 else 'ADMIT'
check('stationary shift guard',static_gate(1,0)=='ABSTAIN')
check('time-dependence guard',static_gate(0,1)=='ABSTAIN')
# Sign canary: spatially outward support acceleration has opposite normal direction to bending.
check('signed curvature mutation caught',abs(rows[0]['alpha']-(-rows[0]['AE']+rows[0]['AS']))>1e-3)
# Omitted spatial channel must fail the Schwarzschild light-limit prediction.
light=scatter(1e-5,1.)
check('omitted structure mutation caught',abs(light['alpha']-light['AE'])>1e-5)
# Refine quadrature for the strongest field case.
coarse=scatter(.1,.999,tol=2e-10); fine=scatter(.1,.999,tol=2e-12)
check('strong-case quadrature refinement',abs(coarse['alpha']-fine['alpha'])<2e-10)
result={'scope':'Synthetic static spherical scattering; no empirical validation; no stress reconstruction',
 'checks':checks,'passed':sum(c['passed'] for c in checks),'total':len(checks),'frozen_results':rows,
 'newton_canary':{'eps':.02,'speeds':[v1,v2],'alpha':[an1,an2],'false_structural_slope':Snew},
 'flat_spatial_canary':{'speeds':[.3,.8],'false_structural_slope':Sflat},
 'exact_two_speed_collision':{'eps':e,'speeds':speeds,'base':{'gamma':1,'charge':0,'beta':0},
 'alternative':{'gamma':g,'charge':q,'beta':beta_fixed},'fit_residual':err,
 'held_out_clock_difference':clock_alt-clock_base,'held_out_third_speed':held_v,
 'held_out_deflection_difference':held_alt-held_base},
 'two_speed_jacobian':jac.tolist(),'light_limit':light,
 'development_note':'The initial flat-spatial canary used an arbitrary 1e-3 effect threshold and stopped at a real 1.598e-4 effect. It was corrected to 1e-6, well above numerical tolerance. This is a development battery, not preregistered validation.',
 'limitations':['Not an exhaustive search over metrics','Numerical collision is tolerance-level, not exact symbolic equality',
 'Static/stationary guards are interface tests only','No real data, stress inference, or dynamical-law derivation']}
(OUT/'rg_hostile_results.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'passed':result['passed'],'total':result['total'],'newton_canary':result['newton_canary'],
 'flat_spatial_canary':result['flat_spatial_canary'],'collision':result['exact_two_speed_collision'],
 'frozen_results':[{'eps':r['eps'],'v':r['v'],'gamma':r['gamma'],'alpha':r['alpha'],'AE':r['AE'],'AS':r['AS'],'ratio':r['AS']/r['AE'],'residual':r['decomposition_residual']} for r in rows]},indent=2))
if __name__=='__main__': pass
