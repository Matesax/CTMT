"""Core numerics for the RG gravity-duality lock. Units G=c=1, mass m=1.
Static spherical metric ds^2 = -A(u) dt^2 + dr^2/H(u) + r^2 dOmega^2,  u = 1/r.
A = N^2 (energy/lapse channel), H = B^-2 (structural/spatial channel).
"""
import math
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.interpolate import CubicSpline


class Metric:
    """Polynomial family N^2 = 1-2u+q u^2, B^-2 = 1-2 g u + be u^2, or exponential lapse."""
    def __init__(self, g=1.0, q=0.0, be=0.0, lapse="poly", flat=False, name=""):
        self.g, self.q, self.be, self.lapse, self.flat, self.name = g, q, be, lapse, flat, name

    def A(self, u):
        return math.exp(-2 * u) if self.lapse == "exp" else 1 - 2 * u + self.q * u * u

    def dA_over(self, u, u0):
        """(A(u0) - A(u)) / (u0 - u), cancellation free."""
        d = u0 - u
        if self.lapse == "exp":
            if abs(d) < 1e-300:
                return -2 * math.exp(-2 * u0)
            return math.exp(-2 * u) * math.expm1(-2 * d) / d
        return -2 + self.q * (u0 + u)

    def dAdr(self, r):
        u = 1 / r
        dAdu = -2 * math.exp(-2 * u) if self.lapse == "exp" else -2 + 2 * self.q * u
        return -u * u * dAdu

    def dHdr(self, r):
        u = 1 / r
        return 0.0 if self.flat else -u * u * (-2 * self.g + 2 * self.be * u)

    def H(self, u):
        return 1.0 if self.flat else 1 - 2 * self.g * u + self.be * u * u

    def N(self, r):
        return math.sqrt(self.A(1 / r))

    def B(self, r):
        return 1 / math.sqrt(self.H(1 / r))


def alpha(met, b, v, tol=1e-13):
    """Exact geodesic deflection (Jacobi/radial quadrature). v = asymptotic speed (v=1: light)."""
    kap = 1 - v * v
    F = lambda u: 1 / met.A(u) - kap - v * v * b * b * u * u
    umax = 0.49
    grid = np.linspace(0, umax, 4001)
    u0 = None
    for lo, hi in zip(grid[:-1], grid[1:]):
        if met.A(hi) <= 0 or met.H(hi) <= 0:
            break
        if F(hi) < 0:
            u0 = brentq(F, lo, hi, xtol=1e-16, rtol=1e-15)
            break
    if u0 is None:
        raise ValueError("capture or no turning point")
    A0 = met.A(u0)

    def G(u):  # F(u) = (u0-u) G(u)
        return met.dA_over(u, u0) / (met.A(u) * A0) + v * v * b * b * (u0 + u)

    def integrand(z):
        u = u0 * (1 - z * z)
        g = G(u)
        if g <= 0:
            raise ValueError("nonpositive G")
        return 2 * math.sqrt(u0) * v * b / (math.sqrt(met.H(u)) * math.sqrt(g))
    val, err = quad(integrand, 0, 1, epsabs=tol, epsrel=tol, limit=400)
    return 2 * val - math.pi


def alpha_newton_coulomb(mu, b, v):
    return 2 * math.atan(mu / (b * v * v))


class Firsov:
    """Classical inverse scattering: ln n(s) = (1/pi) int_0^inf alpha(s cosh t) dt, rho = s/n."""
    def __init__(self, bs, alphas):
        self.bs = np.asarray(bs); self.al = np.asarray(alphas)
        self.spl = CubicSpline(np.log(self.bs), self.al * self.bs)
        bm = self.bs[-2:]; am = self.al[-2:]
        # tail alpha ~ c1/b + c2/b^2 from the last two nodes
        M = np.array([[1 / bm[0], 1 / bm[0] ** 2], [1 / bm[1], 1 / bm[1] ** 2]])
        self.c1, self.c2 = np.linalg.solve(M, am)
        self.bmax = self.bs[-1]; self.bmin = self.bs[0]

    def a(self, b):
        if b <= self.bmax:
            return float(self.spl(math.log(b))) / b
        return self.c1 / b + self.c2 / b ** 2

    def ln_n(self, s):
        if s < self.bmin:
            raise ValueError("outside data domain")
        T = math.acosh(self.bmax / s) if self.bmax > s else 0.0
        I = 0.0
        if T > 0:
            I = quad(lambda t: self.a(s * math.cosh(t)), 0, T, epsabs=1e-14, epsrel=1e-12, limit=400)[0]
        gd = 2 * math.atan(math.tanh(T / 2))
        I += self.c1 / s * (math.pi / 2 - gd) + self.c2 / s ** 2 * (1 - math.tanh(T))
        return I / math.pi

    def profile(self, ss):
        ln = np.array([self.ln_n(s) for s in ss])
        n = np.exp(ln)
        return np.asarray(ss) / n, n          # rho, n


def data(met, v, bs):
    return np.array([alpha(met, b, v) for b in bs])


def isotropic(met, r):
    """rho(r) = r exp(-int_r^inf (B-1)/r' dr'), psi = r/rho."""
    if met.flat:
        return r, 1.0
    I = quad(lambda x: (met.B(x) - 1) / x, r, np.inf, epsabs=1e-14, epsrel=1e-12, limit=400)[0]
    rho = r * math.exp(-I)
    return rho, r / rho


def truth_on_rho(met, rho_targets):
    """Return psi^2 and N at given isotropic radii (root-solve r(rho))."""
    out = []
    for rt in rho_targets:
        r = brentq(lambda r: isotropic(met, r)[0] - rt, rt * 0.5 + 0.3, rt * 2 + 10, xtol=1e-13)
        rho, psi = isotropic(met, r)
        out.append((psi * psi, met.N(r)))
    return np.array(out)


def reconstruct(prof1, prof2, v1, v2, rho_eval):
    """Exact functional two-speed identification: v^2 n^2 = P + psi^2 v^2."""
    def interp(prof):
        rho, n = prof
        o = np.argsort(rho)
        cs = CubicSpline(np.log(rho[o]), np.log(n[o]))
        return lambda x: np.exp(cs(np.log(x)))
    n1 = interp(prof1)(rho_eval); n2 = interp(prof2)(rho_eval)
    y1, y2 = v1 * v1 * n1 * n1, v2 * v2 * n2 * n2
    psi2 = (y1 - y2) / (v1 * v1 - v2 * v2)
    P = y1 - psi2 * v1 * v1
    Ninv2 = 1 + P / psi2
    return psi2, 1 / np.sqrt(Ninv2), n1, n2


def split(met, b, v, tol=1e-13):
    """Gauss-Bonnet split alpha = AE + AS relative to the static congruence."""
    kap = 1 - v * v
    F = lambda u: 1 / met.A(u) - kap - v * v * b * b * u * u
    grid = np.linspace(0, 0.49, 4001); u0 = None
    for lo, hi in zip(grid[:-1], grid[1:]):
        if F(hi) < 0:
            u0 = brentq(F, lo, hi, xtol=1e-16, rtol=1e-15); break
    A0 = met.A(u0)
    G = lambda u: met.dA_over(u, u0) / (met.A(u) * A0) + v * v * b * b * (u0 + u)
    h = 1e-7
    def dlnN_du(u):
        return (math.log(met.A(u + h)) - math.log(met.A(u - h))) / (4 * h) if u > h else \
               (math.log(met.A(u + h)) - math.log(met.A(u))) / (2 * h)
    def base(z):                                  # d(phi_flat)/dz without the 1/sqrt(H) factor
        u = u0 * (1 - z * z)
        return u, 2 * math.sqrt(u0) * v * b / math.sqrt(G(u))
    def i_phi(z):
        u, c = base(z); return c / math.sqrt(met.H(u))
    def i_S(z):
        u, c = base(z); return c / math.sqrt(met.H(u)) * (1 - math.sqrt(met.H(u)))
    def i_E(z):
        u, c = base(z); vl2 = 1 - kap * met.A(u)
        return (-u * dlnN_du(u)) / vl2 * c
    q = lambda f: quad(f, 0, 1, epsabs=tol, epsrel=tol, limit=400)[0]
    al = 2 * q(i_phi) - math.pi
    return al, 2 * q(i_E), 2 * q(i_S)


def forward_from_index(w_nodes, lnn_nodes, b):
    """alpha(b) = -2 b int_0^inf (d ln n/dw)(b cosh t) dt, n given as function of w = rho n."""
    cs = CubicSpline(np.log(w_nodes), lnn_nodes)
    d = cs.derivative()
    wmax = w_nodes[-1]
    def integrand(t):
        w = b * math.cosh(t)
        if w > wmax:
            return 0.0
        return float(d(math.log(w))) / w
    T = math.acosh(wmax / b)
    val = quad(integrand, 0, T, epsabs=1e-14, epsrel=1e-11, limit=600)[0]
    # tail beyond the last node: ln n ~ c1/w + c2/w^2 fitted on the last two nodes
    w2 = np.asarray(w_nodes[-2:]); l2 = np.asarray(lnn_nodes[-2:])
    c1, c2 = np.linalg.solve(np.array([[1 / w2[0], 1 / w2[0] ** 2], [1 / w2[1], 1 / w2[1] ** 2]]), l2)
    gd = 2 * math.atan(math.tanh(T / 2))
    sech2 = 1 - math.tanh(T)                                            # int_T^inf sech^2
    sech3 = 0.5 * (math.pi / 2 - math.tanh(T) / math.cosh(T) - gd)      # int_T^inf sech^3
    tail = c1 / b ** 2 * sech2 + 2 * c2 / b ** 3 * sech3
    return -2 * b * val + 2 * b * tail
