"""RG gravity duality: hostile lock battery.
Claim attacked: a static gravitational field is a pair (h, N) -- structure and energy footprint --
and Newton fails EXACTLY when (S) h is not flat (two-speed trajectory panels) or (E) N is not constant
(trajectory + support panels).  Every attack has a witness; canaries are false claims that must be rejected.
Synthetic/analytic fixtures only.  G=c=m=1.
Run: python rg_duality_attacks.py --out DIR      (numpy, scipy, sympy)
"""
import argparse, hashlib, json, math, pathlib, platform, sys, time, warnings
import numpy as np, sympy as sp
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline
from rg_duality_core import (Metric, alpha, alpha_newton_coulomb, Firsov, data, truth_on_rho,
                             reconstruct, split, forward_from_index)

warnings.filterwarnings("ignore")
MASTER_SEED = 20261024
RES, CAN = [], []
BS = np.geomspace(30, 2e6, 700)          # impact-parameter scan (functional panel)
SS = np.geomspace(32, 1e6, 160)          # Firsov abscissae
RHO = np.array([40., 60., 100., 300., 1e3, 1e4])


def must(c, m):
    if not c:
        raise AssertionError(m)


def rec(i, claim, status, witness, details=None):
    RES.append(dict(id=i, claim=claim, status=status, witness=witness, details=details or {}))


def profile(met, v, bs=BS, noise=None):
    al = data(met, v, bs)
    if noise is not None:
        al = al * (1 + noise(bs))
    return Firsov(bs, al).profile(SS)


# ------------------------------------------------------------------ D01 pencil (symbolic)
def D01():
    E, m, N, v, Phi = sp.symbols("E m N v Phi", positive=True)
    jac = E ** 2 / N ** 2 - m ** 2                          # coefficient of h in the Jacobi metric
    Ev = m / sp.sqrt(1 - v ** 2)
    pencil = sp.simplify(jac.subs(E, Ev) - m ** 2 / (1 - v ** 2) * (1 / N ** 2 - (1 - v ** 2)))
    PhiK = (1 - N ** -2) / 2
    newton = sp.simplify((1 / N ** 2 - (1 - v ** 2)) - 2 * (v ** 2 / 2 - PhiK))
    must(pencil == 0 and newton == 0, "pencil identities")
    rec("D01", "Free motion is the Jacobi pencil j = (N^-2 - kappa) h, kappa = 1 - v^2; for flat h it IS "
        "Newton's Jacobi metric 2(v^2/2 - Phi_kin) delta with Phi_kin = (1 - N^-2)/2", "LOCKED",
        "sympy: (E^2/N^2 - m^2) = m^2/(1-v^2) (N^-2 - kappa) and (N^-2 - kappa) = 2(v^2/2 - Phi_kin) identically")


# ------------------------------------------------------------------ D02 energy-channel potentials
def D02():
    N, x = sp.symbols("N x", positive=True)
    kin, hold, clock = (1 - N ** -2) / 2, sp.log(N), N - 1
    ratio = sp.simplify(sp.diff(hold, N) / sp.diff(kin, N))
    must(sp.simplify(ratio - N ** 2) == 0, "support/trajectory ratio")
    ser = {k: sp.series(f.subs(N, 1 - x), x, 0, 4).removeO() for k, f in
           (("kin", kin), ("hold", hold), ("clock", clock))}
    first = {k: sp.Poly(s, x).coeff_monomial(x) for k, s in ser.items()}
    second = {k: sp.Poly(s, x).coeff_monomial(x ** 2) for k, s in ser.items()}
    must(len(set(first.values())) == 1 and len(set(second.values())) == 3, "overlap at 1st, split at 2nd")
    rec("D02", "Energy channel: trajectory, support and clock potentials coincide at first order and split at "
        "second; support/trajectory force ratio is exactly N^2", "LOCKED",
        f"With x = 1-N: first-order coefficients {first} (equal); second-order {second} (distinct). "
        "d(c^2 ln N)/d[(c^2/2)(1-N^-2)] = N^2 exactly.", dict(series={k: str(s) for k, s in ser.items()}))


# ------------------------------------------------------------------ D03 flat h => exactly Newtonian (independent ODEs)
def rel_geodesic(met, b, v, X0=2e4):
    A = lambda r: met.A(1 / r)
    dA = met.dAdr
    H = lambda r: met.H(1 / r)
    massive = v < 1
    E = 1 / math.sqrt(1 - v * v) if massive else 1.0
    L = E * v * b if massive else b
    r0 = math.hypot(X0, b); p0 = math.atan2(b, -X0)
    rd = -math.sqrt(H(r0) * (E * E / A(r0) - (1 if massive else 0) - L * L / r0 ** 2))
    def f(s, y):
        t, r, p, td, rdd, pd = y
        Ar, dAr, Hr = A(r), dA(r), H(r)
        dH = met.dHdr(r)
        return [td, rdd, pd, -dAr / Ar * td * rdd,
                -0.5 * Hr * dAr * td * td + 0.5 * dH / Hr * rdd * rdd + Hr * r * pd * pd,
                -2 * rdd * pd / r]
    ev = lambda s, y: y[1] - r0; ev.direction = 1; ev.terminal = True
    sol = solve_ivp(f, [0, 1e9], [0, r0, p0, E / A(r0), rd, L / r0 ** 2], events=ev, rtol=1e-12,
                    atol=1e-14, method="DOP853", first_step=1.0)
    y = sol.y_events[0][0]
    Econs = A(y[1]) * y[3]; Lcons = y[1] ** 2 * y[5]
    return y[2], abs(Econs / E - 1), abs(Lcons / L - 1)


def newton_orbit(Phi, dPhi, b, v, X0=2e4):
    r0 = math.hypot(X0, b); p0 = math.atan2(b, -X0); L = v * b
    rd = -math.sqrt(v * v - 2 * Phi(r0) - L * L / r0 ** 2)
    def f(t, y):
        r, p, rdd, pd = y
        return [rdd, pd, r * pd * pd - dPhi(r), -2 * rdd * pd / r]
    ev = lambda t, y: y[0] - r0; ev.direction = 1; ev.terminal = True
    sol = solve_ivp(f, [0, 1e9], [r0, p0, rd, L / r0 ** 2], events=ev, rtol=1e-12, atol=1e-14,
                    method="DOP853", first_step=1.0)
    return sol.y_events[0][0][1]


def D03():
    out = []
    for met in (Metric(lapse="poly", flat=True, name="N^2=1-2m/r, h flat"),
                Metric(lapse="exp", flat=True, name="N=exp(-m/r), h flat")):
        Phi = lambda r, met=met: 0.5 * (1 - 1 / met.A(1 / r))
        dPhi = lambda r, met=met: 0.5 * met.dAdr(r) / met.A(1 / r) ** 2
        for b, v in ((20, 0.3), (40, 0.6), (15, 0.95), (30, 1.0)):
            pr, dE, dL = rel_geodesic(met, b, v)
            pn = newton_orbit(Phi, dPhi, b, v)
            out.append(dict(metric=met.name, b=b, v=v, dphi=abs(pr - pn), Econs=dE, Lcons=dL,
                            alpha=alpha(met, b, v)))
    worst = max(o["dphi"] for o in out)
    must(worst < 1e-8 and max(o["Econs"] for o in out) < 1e-9, "flat h gives exactly Newtonian orbits")
    rec("D03", "If h is flat, every free orbit (all speeds, light included) is EXACTLY a Newtonian orbit in "
        "Phi_kin = (c^2/2)(1 - N^-2), at any field strength", "LOCKED",
        f"Two flat-h metrics x 4 (b,v) incl. v=1: full 4D geodesic ODE (Christoffels) vs Newton ODE in Phi_kin "
        f"from the same point: max exit-angle difference {worst:.1e} rad (deflections up to "
        f"{max(o['alpha'] for o in out):.2f} rad); E, L conserved to {max(o['Econs'] for o in out):.0e}.",
        dict(cases=out))


# ------------------------------------------------------------------ D04 Firsov inversion validated
def D04():
    errs = []
    for v in (0.3, 0.6, 1.0):
        al = [alpha_newton_coulomb(1.0, b, v) for b in BS]
        rho, n = Firsov(BS, al).profile(SS)
        errs.append(float(np.max(np.abs(n / np.sqrt(1 + 2 / (rho * v * v)) - 1))))
    S = Metric(); worst = 0.0
    for v in (0.5, 1.0):
        rho, n = profile(S, v)
        sel = rho > 35
        p2 = (1 + 1 / (2 * rho[sel])) ** 4; Nn = (1 - 1 / (2 * rho[sel])) / (1 + 1 / (2 * rho[sel]))
        worst = max(worst, float(np.max(np.abs(n[sel] / np.sqrt(p2 * (Nn ** -2 - (1 - v * v)) / v ** 2) - 1))))
    must(max(errs) < 1e-10 and worst < 1e-7, "Firsov")
    rec("D04", "Classical inverse scattering (Firsov) recovers the refractive index n_v(rho) of the Jacobi metric "
        "in isotropic radius", "LOCKED",
        f"Coulomb (exact alpha): max rel. err {max(errs):.1e}; Schwarzschild (exact geodesic alpha) vs "
        f"n^2 = psi^2 (N^-2 - kappa)/v^2: {worst:.1e}.", dict(coulomb=errs, schw=worst))


# ------------------------------------------------------------------ D05 exact functional two-speed identification
def D05():
    out = {}
    for name, met in (("Schwarzschild", Metric()), ("gamma=-0.5", Metric(g=-0.5)), ("gamma=0.4", Metric(g=0.4)),
                      ("gamma=1.6", Metric(g=1.6)), ("q=0.5,beta=0.8", Metric(q=0.5, be=0.8)),
                      ("exp lapse, gamma=1", Metric(lapse="exp"))):
        p1, p2 = profile(met, 0.5), profile(met, 1.0)
        psi2, N, _, _ = reconstruct(p1, p2, 0.5, 1.0, RHO)
        tr = truth_on_rho(met, RHO)
        e_psi = float(np.max(np.abs(psi2 - tr[:, 0]) / np.maximum(np.abs(tr[:, 0] - 1), 1e-12)))
        e_N = float(np.max(np.abs(N - tr[:, 1]) / (1 - tr[:, 1])))
        out[name] = dict(rel_err_structure=e_psi, rel_err_energy=e_N,
                         psi2_minus1_at_rho100=float(tr[2, 0] - 1))
    must(all(o["rel_err_structure"] < 1e-4 and o["rel_err_energy"] < 1e-4 for o in out.values()), "identification")
    rec("D05", "Exact functional two-speed theorem: v^2 n_v^2 = psi^2 (N^-2 - 1) + psi^2 v^2 exactly; full-b scans at "
        "two speeds identify structure psi^2 (slope) and energy N (intercept)", "LOCKED",
        "Six static metrics (incl. gamma<0, nonlinear q, beta, exponential lapse): structure and energy "
        "reconstructed from speeds 0.5 and light on rho in [40, 1e4]; max errors relative to the signal: "
        f"structure {max(o['rel_err_structure'] for o in out.values()):.1e}, energy "
        f"{max(o['rel_err_energy'] for o in out.values()):.1e}.", out)


# ------------------------------------------------------------------ D06 exact linearity: held-out speeds
def D06():
    S = Metric(); pr = {v: profile(S, v) for v in (0.5, 0.9, 0.7, 1.0, 0.3)}
    psi2, N, n1, _ = reconstruct(pr[0.5], pr[0.9], 0.5, 0.9, RHO)
    P = 0.25 * n1 ** 2 - psi2 * 0.25
    worst = 0.0
    for v in (0.7, 1.0, 0.3):
        rho, n = pr[v]; o = np.argsort(rho)
        nobs = np.exp(CubicSpline(np.log(rho[o]), np.log(n[o]))(np.log(RHO)))
        npred = np.sqrt((P + psi2 * v * v) / (v * v))
        worst = max(worst, float(np.max(np.abs(npred / nobs - 1) / (nobs - 1))))
    must(worst < 1e-4, "linearity")
    rec("D06", "Held-out speeds are predicted exactly by the affine law (no first-order remainder R(b,v))", "LOCKED",
        f"Fit on v = 0.5, 0.9; predict v = 0.7, 0.3 and light: max error relative to (n-1) {worst:.1e}. The "
        f"remainder that contaminated the alpha v^2 slope is a property of the alpha <-> n transform, not of the law.")


# ------------------------------------------------------------------ D07 Newton accepted exactly (Coulomb), canary C1
def D07():
    prof = {}
    for v in (0.5, 0.9):
        prof[v] = Firsov(BS, [alpha_newton_coulomb(1.0, b, v) for b in BS]).profile(SS)
    psi2, _, _, _ = reconstruct(prof[0.5], prof[0.9], 0.5, 0.9, RHO)
    dev = float(np.max(np.abs(psi2 - 1)))
    a1, a2 = alpha_newton_coulomb(1, 40, 0.5), alpha_newton_coulomb(1, 40, 0.9)
    slope = (a1 * 0.25 - a2 * 0.81) / (0.25 - 0.81)
    must(dev < 1e-8 and abs(slope) > 1e-4, "Newton accepted exactly")
    CAN.append(dict(statement="nonzero alpha v^2 slope proves non-Newtonian gravity", accepted=False,
                    witness=f"exact Coulomb data: slope {slope:.2e} but structure |psi^2-1| <= {dev:.0e}"))
    rec("D07", "The exact test accepts Newtonian data that the first-order alpha v^2 test rejects", "LOCKED",
        f"Exact Coulomb deflections at v=0.5, 0.9: recovered structure |psi^2 - 1| <= {dev:.1e} (flat); the "
        f"alpha v^2 slope at b=40 is {slope:.2e} (false structure).")


# ------------------------------------------------------------------ D08 flat-h with curved lapse: accepted, canary C3
def D08():
    met = Metric(flat=True)
    p1, p2 = profile(met, 0.3), profile(met, 0.8)
    psi2, N, _, _ = reconstruct(p1, p2, 0.3, 0.8, RHO)
    dev = float(np.max(np.abs(psi2 - 1)))
    Nt = np.sqrt(1 - 2 / RHO)
    eN = float(np.max(np.abs(N - Nt) / (1 - Nt)))
    a1, a2 = alpha(met, 40, 0.3), alpha(met, 40, 0.8)
    slope = (a1 * 0.09 - a2 * 0.64) / (0.09 - 0.64)
    must(dev < 1e-6 and eN < 1e-4 and abs(slope) > 1e-6, "flat-h accepted")
    CAN.append(dict(statement="A_S = 0 must force alpha v^2 constancy (otherwise Newton fails)", accepted=False,
                    witness=f"N^2 = 1-2m/r, flat h: slope {slope:.2e} yet exactly Newtonian (D03) and |psi^2-1| <= {dev:.0e}"))
    rec("D08", "Curved lapse with flat space is exactly Newtonian, however strong; the hostile flat-spatial canary "
        "is resolved", "LOCKED",
        f"N^2 = 1-2m/r, h flat: recovered |psi^2-1| <= {dev:.1e}, lapse recovered to {eN:.1e}; the nonzero "
        f"alpha v^2 slope ({slope:.2e}) is the non-Coulomb shape of Phi_kin = -m/(r-2m), not structure.")


# ------------------------------------------------------------------ D09 finite-panel collision vs functional panel, canary C4
def D09():
    S = Metric(); Alt = Metric(g=1.0078727217683385, q=-0.01030885838607218, be=0.8)
    col = max(abs(alpha(S, 40, v) - alpha(Alt, 40, v)) for v in (0.5, 0.9))
    off = {b: abs(alpha(S, b, 0.5) - alpha(Alt, b, 0.5)) for b in (30, 100, 1000)}
    pS = reconstruct(profile(S, 0.5), profile(S, 0.9), 0.5, 0.9, RHO)[0]
    pA = reconstruct(profile(Alt, 0.5), profile(Alt, 0.9), 0.5, 0.9, RHO)[0]
    tS, tA = truth_on_rho(S, RHO)[:, 0], truth_on_rho(Alt, RHO)[:, 0]
    sep = float(np.max(np.abs(pS - pA))); floor = float(max(np.max(np.abs(pS - tS)), np.max(np.abs(pA - tA))))
    must(col < 1e-10 and min(off.values()) > 1e-9 and sep > 100 * floor, "collision resolved")
    CAN.append(dict(statement="two speeds at one impact parameter identify the geometry", accepted=False,
                    witness=f"hostile collision reproduced: |dalpha| = {col:.1e} at b=40, v=0.5, 0.9"))
    rec("D09", "Finite panels collide; functional panels identify (RG: correspondence vs lock)", "LOCKED",
        f"The hostile alternative (gamma=1.00787, q=-0.0103, beta=0.8) matches Schwarzschild at b=40 to {col:.1e} "
        f"for both speeds, but differs at b=30, 100, 1000 by {[f'{x:.1e}' for x in off.values()]}; full-b "
        f"reconstruction separates the structures by {sep:.1e} against a numerical floor {floor:.1e}.")


# ------------------------------------------------------------------ D10 single-speed no-go, canary C2
def D10():
    S = Metric(); v1, v2 = 0.5, 0.9
    rho1, n1 = profile(S, v1)
    o = np.argsort(rho1); rho1, n1 = rho1[o], n1[o]
    w1 = rho1 * n1
    back = max(abs(forward_from_index(w1, np.log(n1), b) / alpha(S, b, v1) - 1) for b in (60, 200, 2000))
    # Newton with the single-speed potential Phi_1 = (v1^2/2)(1-n1^2) predicts at v2:
    nN2 = np.sqrt(1 + (v1 ** 2 / v2 ** 2) * (n1 ** 2 - 1))
    wN = rho1 * nN2
    miss = {b: alpha(S, b, v2) - forward_from_index(wN, np.log(nN2), b) for b in (60, 200, 2000)}
    struct = {b: split(S, b, v2)[2] for b in miss}
    pred = {b: struct[b] * (1 - v1 ** 2 / v2 ** 2) for b in miss}
    rel = {b: abs(miss[b] / pred[b] - 1) for b in miss}
    must(back < 1e-6 and all(m > 0 for m in miss.values()) and rel[2000] < 0.02 and rel[200] < 0.03, "single-speed")
    CAN.append(dict(statement="single-speed scattering data can refute Newton", accepted=False,
                    witness=f"Schwarzschild at v=0.5 is reproduced by a Newtonian potential to {back:.1e}"))
    rec("D10", "Single-speed no-go: every single-speed deflection function is exactly Newtonian; Newton fails only "
        "against a second speed", "LOCKED",
        f"Schwarzschild, v=0.5: the Firsov potential reproduces alpha(b) to {back:.1e}. Carried to v=0.9 it "
        f"under-predicts by {[f'{x:.2e}' for x in miss.values()]} rad at b=60, 200, 2000, matching "
        f"A_S(v2)(1 - v1^2/v2^2) = {[f'{x:.2e}' for x in pred.values()]} to {[f'{x:.1%}' for x in rel.values()]}: "
        f"the Newtonian miss IS the structural Gauss-Bonnet term, scaled by the speed contrast.",
        dict(miss={str(k): v for k, v in miss.items()}, A_S={str(k): v for k, v in struct.items()}))


# ------------------------------------------------------------------ D11 Gauss-Bonnet split as per-path diagnostic
def D11():
    worst = 0.0; rows = []
    for met in (Metric(), Metric(g=-0.5), Metric(flat=True)):
        for b, v in ((1e4, 0.6), (10, 0.999), (200, 0.3)):
            try:
                al, AE, AS = split(met, b, v)
            except Exception:
                continue
            worst = max(worst, abs(al - AE - AS)); rows.append(dict(b=b, v=v, AS_over_AE=AS / AE, AS=AS))
    flatAS = [r["AS"] for r in rows[-3:]]
    rS = split(Metric(), 1e4, 0.6); rg = split(Metric(g=-0.5), 1e4, 0.6)
    must(worst < 1e-9 and max(abs(x) for x in flatAS) < 1e-15, "GB")
    must(abs(rS[2] / rS[1] / 0.36 - 1) < 2e-3 and abs(rg[2] / rg[1] / (-0.18) - 1) < 2e-3, "weak-field ratio gamma v^2")
    rec("D11", "Gauss-Bonnet split alpha = A_E + A_S (relative to the static congruence) holds; A_S vanishes for flat h",
        "LOCKED", f"Max |alpha - A_E - A_S| = {worst:.1e} over Schwarzschild, gamma=-0.5, flat-h cases; "
        f"A_S = 0 exactly for flat h. Weak-field A_S/A_E = gamma v^2.", dict(rows=rows))


# ------------------------------------------------------------------ D12 failure point in precision units
def D12():
    rng = np.random.default_rng(MASTER_SEED + 12)
    S = Metric(); v1, v2 = 0.5, 1.0; g = 1.0
    eps_crit = g * abs(v1 ** 2 - v2 ** 2) / (2 + g * (v1 ** 2 + v2 ** 2))
    out = {}
    for label, eps in (("0.5 eps_crit", 0.5 * eps_crit), ("2 eps_crit", 2 * eps_crit)):
        ph = rng.uniform(0, 2 * math.pi, 3); amp = rng.uniform(0.3, 1, 3); amp /= amp.sum()
        noise = lambda bs, ph=ph, amp=amp, eps=eps: eps * sum(a * np.sin((k + 1) * np.log(bs) + p)
                                                              for k, (a, p) in enumerate(zip(amp, ph)))
        p1, p2 = profile(S, v1, noise=noise), profile(S, v2, noise=noise)
        psi2, _, n1, n2 = reconstruct(p1, p2, v1, v2, RHO)
        bound = (v1 ** 2 * n1 ** 2 * np.expm1(2 * eps * np.log(n1) / (1 - eps))
                 + v2 ** 2 * n2 ** 2 * np.expm1(2 * eps * np.log(n2) / (1 - eps))) / abs(v1 ** 2 - v2 ** 2)
        true = truth_on_rho(S, RHO)[:, 0]
        covered = bool(np.all(np.abs(psi2 - true) <= bound + 1e-9))
        refuted = (np.abs(psi2 - 1) > bound).tolist()
        out[label] = dict(eps=eps, covered=covered, newton_refuted_at_rho=dict(zip(map(float, RHO), refuted)))
    must(out["0.5 eps_crit"]["covered"] and out["2 eps_crit"]["covered"], "bound valid")
    must(all(out["0.5 eps_crit"]["newton_refuted_at_rho"].values()), "refuted below eps_crit")
    must(not any(out["2 eps_crit"]["newton_refuted_at_rho"].values()), "not refuted above eps_crit")
    rec("D12", "Failure point in precision units: with relative deflection error eps, two-speed panels refute Newton "
        "iff eps < eps_crit = gamma|v1^2-v2^2| / (2 + gamma(v1^2+v2^2)) (weak field, radius-independent)", "LOCKED",
        f"Schwarzschild, v = 0.5 and light: eps_crit = {eps_crit:.4f}. Seeded smooth noise at 0.5 eps_crit: Newton "
        f"refuted at every tested radius (rho = 40 ... 1e4); at 2 eps_crit: refuted at none. The worst-case bound "
        f"covered the true structure in both runs. In the weak field the threshold does not depend on radius.", out)


# ------------------------------------------------------------------ D13 energy-channel failure point, canary C5
def D13():
    met = Metric(lapse="exp", flat=True)
    rs = np.array([3., 10., 100., 1e4])
    a_true = np.array([1 / r ** 2 for r in rs])                        # d ln N/dr for N = exp(-1/r)
    a_kin = np.array([math.exp(2 / r) / r ** 2 for r in rs])           # |dPhi_kin/dr|
    ratio = a_true / a_kin; N2 = np.exp(-2 / rs)
    must(np.allclose(ratio, N2, rtol=1e-14) and abs(ratio[0] - 1) > 0.1, "ratio")
    CAN.append(dict(statement="for flat h one Newtonian potential reproduces both orbits and static support", accepted=False,
                    witness=f"N = exp(-m/r): support/orbit force ratio = N^2 = {ratio[0]:.3f} at r = 3m"))
    delta = 0.01
    rec("D13", "Energy-channel failure point: one potential cannot serve orbits and support unless N is constant; the "
        "fractional mismatch is exactly 1 - N^2", "LOCKED",
        f"N = exp(-m/r) (support acceleration exactly m/r^2): orbit potential force exceeds support by 1/N^2; "
        f"ratios {ratio.round(6).tolist()} at r = {rs.tolist()}. For N^2 = 1-2m/r the mismatch exceeds delta iff "
        f"r < 2m/delta (delta = {delta}: r < {2 / delta:.0f} m).")


# ------------------------------------------------------------------ D14 kinematics mutation canary C6
def D14():
    S = Metric(); pr = {v: profile(S, v) for v in (0.5, 0.9, 0.7)}
    def recon(power):
        def interp(p):
            rho, n = p; o = np.argsort(rho)
            return np.exp(CubicSpline(np.log(rho[o]), np.log(n[o]))(np.log(RHO)))
        n1, n2, n3 = interp(pr[0.5]), interp(pr[0.9]), interp(pr[0.7])
        y = lambda v, n: v ** power * n ** 2
        s = (y(0.5, n1) - y(0.9, n2)) / (0.5 ** power - 0.9 ** power); P = y(0.5, n1) - s * 0.5 ** power
        return float(np.max(np.abs((P + s * 0.7 ** power) / y(0.7, n3) - 1)))
    good, bad = recon(2), recon(1)
    must(good < 1e-7 and bad > 1e-5, "kinematics")
    CAN.append(dict(statement="the affine law holds with any kinematic weight (v instead of v^2)", accepted=False,
                    witness=f"held-out speed error {bad:.1e} with weight v vs {good:.1e} with v^2"))
    rec("D14", "The affine variable is exactly v^2 (Newton kinematics); mutating it breaks held-out prediction",
        "LOCKED", f"Held-out v=0.7 prediction error: weight v^2 {good:.1e}; weight v {bad:.1e}.")


def main(outdir):
    out = pathlib.Path(outdir); out.mkdir(parents=True, exist_ok=True)
    src = b"".join(pathlib.Path(f).read_bytes() for f in (__file__, "rg_duality_core.py"))
    man = dict(master_seed=MASTER_SEED, blind=False, data="synthetic/analytic only",
               source_sha256=hashlib.sha256(src).hexdigest(),
               written_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
               attacks=[f"D{k:02d}" for k in range(1, 15)])
    mt = json.dumps(man, indent=2); (out / "rg_duality_manifest.json").write_text(mt)
    t0 = time.time()
    for f in (D01, D02, D03, D04, D05, D06, D07, D08, D09, D10, D11, D12, D13, D14):
        f(); print(RES[-1]["id"], RES[-1]["status"], round(time.time() - t0, 1), flush=True)
    must(len(CAN) == 6 and not any(c["accepted"] for c in CAN), "canaries")
    res = dict(manifest_sha256=hashlib.sha256(mt.encode()).hexdigest(), python=sys.version.split()[0],
               numpy=np.__version__, sympy=sp.__version__, platform=platform.platform(),
               runtime_s=round(time.time() - t0, 1), attacks=RES, canaries=CAN,
               summary=dict(locked=sum(r["status"] == "LOCKED" for r in RES), total=len(RES), canaries_rejected=len(CAN)))
    (out / "rg_duality_results.json").write_text(json.dumps(res, indent=2, default=str))
    print(json.dumps(res["summary"]))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default="."); main(ap.parse_args().out)
