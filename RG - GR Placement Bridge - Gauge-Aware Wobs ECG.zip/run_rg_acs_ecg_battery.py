import json, hashlib
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import kurtosis, spearmanr
from scipy.linalg import subspace_angles

ROOT=Path('/mnt/data/ecg_work')
TRAIN=Path('/mnt/data/train.csv')
IDS=['04904','08040','08381','16145','03362','01107','07001','09347','05154','16028']
EPS=[1e-2,1e-3,1e-4]
PRIM=['I','II','V1','V2','V3','V4','V5','V6']
BANDS=[(2,5),(5,15),(15,40),(40,80),(80,150),(150,250)]
WIN=250

def sha256(p):
    h=hashlib.sha256(); h.update(p.read_bytes()); return h.hexdigest()

def read_record(rid):
    lines=(ROOT/f'{rid}.hea').read_text().strip().splitlines()
    h=lines[0].split(); n_sig=int(h[1]); fs=float(h[2]); n=int(h[3])
    leads=[ln.split()[-1] for ln in lines[1:1+n_sig]]
    gains=[]; bases=[]
    for ln in lines[1:1+n_sig]:
        t=ln.split(); gains.append(float(t[2].split('(')[0])); bases.append(float(t[4]))
    raw=np.fromfile(ROOT/f'{rid}.dat',dtype='<i2')
    if raw.size != n*n_sig: raise ValueError((rid,raw.size,n*n_sig))
    raw=raw.reshape(n,n_sig).astype(float)
    x=(raw-np.array(bases))/np.array(gains)
    return x, fs, leads

def lead_gate(x,leads):
    d={k:x[:,leads.index(k)] for k in leads}
    identities={
      'III-(II-I)': d['III']-(d['II']-d['I']),
      'aVR+(I+II)/2': d['aVR']+(d['I']+d['II'])/2,
      'aVL-(I-II/2)': d['aVL']-(d['I']-d['II']/2),
      'aVF-(II-I/2)': d['aVF']-(d['II']-d['I']/2),
    }
    scale=np.sqrt(np.mean(np.c_[d['I'],d['II']]**2))
    return {k:{'rms_mV':float(np.sqrt(np.mean(v*v))), 'relative_rms':float(np.sqrt(np.mean(v*v))/scale)} for k,v in identities.items()}

def features(rid,x,fs,leads):
    p=x[:,[leads.index(k) for k in PRIM]]
    out=[]
    freqs=np.fft.rfftfreq(WIN,1/fs)
    for start in range(0,len(p)-WIN+1,WIN):
        w=p[start:start+WIN]
        flat=w.ravel()
        spec=np.fft.rfft(w,axis=0)
        ps=np.abs(spec)**2/(WIN**2)
        vals=[np.log(np.std(flat)+1e-15),np.log(np.max(np.abs(flat))+1e-15),np.log(kurtosis(flat,fisher=False,bias=False)+1e-15)]
        bp=[]
        for a,b in BANDS:
            mask=(freqs>=a)&(freqs < b if b<fs/2 else freqs<=b)
            val=float(ps[mask].sum())
            bp.append(val); vals.append(np.log(val+1e-30))
        rho=sum((2*np.pi*np.sqrt(a*b))**2*v for (a,b),v in zip(BANDS,bp))
        out.append([rid,start/fs,*vals,np.log(rho+1e-30)])
    cols=['record','time_s','log_std','log_maxabs','log_kurtosis']+[f'logP_{a}_{b}' for a,b in BANDS]+['log_rho']
    return pd.DataFrame(out,columns=cols)

def spectrum(A):
    Z=(A-A.mean(0))/A.std(0,ddof=1)
    C=np.cov(Z,rowvar=False)
    ev=np.linalg.eigvalsh(C)[::-1]; rel=ev/ev[0]
    p=ev/ev.sum(); part=1/(p@p); entr=np.exp(-(p*np.log(p+1e-300)).sum())
    return {'relative_eigenvalues':rel.tolist(),'ranks':{str(e):int((rel>e).sum()) for e in EPS},'participation_rank':float(part),'entropy_rank':float(entr)},Z

def projector(Z,k):
    _,_,vt=np.linalg.svd(Z,full_matrices=False)
    return vt[:k].T

train=pd.read_csv(TRAIN,dtype={'ecg_row_record':str,'ecg_med_record':str})
train['rid']=train.ecg_row_record.str.replace('.dat','',regex=False).str.zfill(5)
meta=train[train.rid.isin(IDS)].copy()
label={r.rid:('STEMI' if r.STEMI==1 else 'NSTEMI' if r.NSTEMI==1 else 'CONTROL') for _,r in meta.iterrows()}
# Repeat pair stays clinically labelled but marked separately.
allf=[]; gates={}; checks={}
for rid in IDS:
    x,fs,leads=read_record(rid)
    gates[rid]=lead_gate(x,leads)
    checks[rid]={'fs':fs,'samples':len(x),'leads':leads,'dat_sha256':sha256(ROOT/f'{rid}.dat'),'hea_sha256':sha256(ROOT/f'{rid}.hea'),'med_sha256':sha256(ROOT/f'{rid}.med')}
    f=features(rid,x,fs,leads); f['group']=label[rid]; f['patient']=meta.loc[meta.rid==rid,'Patient_id'].iloc[0]
    allf.append(f)
F=pd.concat(allf,ignore_index=True)
feat=['log_std','log_maxabs','log_kurtosis']+[f'logP_{a}_{b}' for a,b in BANDS]
results={'records':checks,'lead_identity_gate':gates,'feature_definition':{'primitive_leads':PRIM,'window_samples':WIN,'window_seconds':WIN/500,'bands_hz':BANDS,'coordinates':feat},'groups':{}}
S,Z=spectrum(F[feat].to_numpy()); results['pooled']=S
for g,df in F.groupby('group'):
    results['groups'][g]={'records':sorted(df.record.unique().tolist()),'windows':len(df),**spectrum(df[feat].to_numpy())[0]}
# Record-level spectra and rank stability
results['record_local']={}
for rid,df in F.groupby('record'):
    results['record_local'][rid]=spectrum(df[feat].to_numpy())[0]
# leave-one-record-out leading-projector stability: pooled k chosen by 95% explained variance
A=F[feat].to_numpy(); Zall=(A-A.mean(0))/A.std(0,ddof=1); ev=np.linalg.eigvalsh(np.cov(Zall,rowvar=False))[::-1]; k95=int(np.searchsorted(np.cumsum(ev)/ev.sum(),.95)+1)
U0=projector(Zall,k95); loo=[]
for rid in IDS:
    A2=F.loc[F.record!=rid,feat].to_numpy(); Z2=(A2-A2.mean(0))/A2.std(0,ddof=1); U=projector(Z2,k95)
    ang=subspace_angles(U0,U)
    loo.append({'omitted':rid,'max_angle_rad':float(ang.max()),'angles_rad':ang.tolist()})
results['leave_one_record_out']={'k95':k95,'comparisons':loo,'median_max_angle_rad':float(np.median([x['max_angle_rad'] for x in loo]))}
# bootstrap rank robustness
rng=np.random.default_rng(31072026); br=[]
for _ in range(1000):
    idx=rng.integers(0,len(F),len(F)); br.append(spectrum(F.iloc[idx][feat].to_numpy())[0]['ranks']['0.001'])
vals,cnt=np.unique(br,return_counts=True); results['bootstrap_rank_1e-3']={str(int(v)):int(c) for v,c in zip(vals,cnt)}
# placement identity from stored log powers
rho2=np.zeros(len(F))
for a,b in BANDS: rho2+=(2*np.pi*np.sqrt(a*b))**2*np.exp(F[f'logP_{a}_{b}'])
results['placement_bridge']={'max_abs_log_reconstruction_error':float(np.max(np.abs(np.log(rho2)-F.log_rho)))}
# record centroids; repeat pair relative to all pair distances
C=F.groupby('record')[feat].mean(); Cz=(C-C.mean())/C.std(ddof=1)
D=np.sqrt(((Cz.to_numpy()[:,None,:]-Cz.to_numpy()[None,:,:])**2).sum(2)); names=C.index.tolist(); i=names.index('05154'); j=names.index('16028'); tri=D[np.triu_indices(len(D),1)]
rd=float(D[i,j]); results['repeat_pair']={'records':['05154','16028'],'distance':rd,'all_pair_median':float(np.median(tri)),'percentile':float((tri<=rd).mean()*100)}
# save
F.to_csv('/mnt/data/rg_acs_ecg_features.csv',index=False)
Path('/mnt/data/rg_acs_ecg_results.json').write_text(json.dumps(results,indent=2))
print(json.dumps({'pooled':results['pooled'],'groups':results['groups'],'loo':results['leave_one_record_out'],'bootstrap':results['bootstrap_rank_1e-3'],'placement':results['placement_bridge'],'repeat':results['repeat_pair']},indent=2))
