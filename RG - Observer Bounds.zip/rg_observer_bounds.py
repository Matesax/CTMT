"""RG Observer Bounds battery (print: 'RG - Observer Bounds').

Purpose: attack the claim that the limited observer of RG is more than philosophy. Every group either (a) checks an exact
identity, (b) recomputes a published number from its published inputs, or (c) confronts a structural RG statement with an
independent measurement. Every group carries a canary that must fail when the claim is false or the method is circular.

Groups:
  OA  horizon energy / Landauer cost / de Sitter entropy identity (exact, sympy); black-hole canary (factor 2)
  OB  finite record capacity from the measured Lambda (Bousso N-bound, conjecture-labelled); Lambda <= 0 canary
  OC  cosmic horizons from Planck 2018 parameters: age, particle and event horizon, reachable fraction; EdS canary
  OD  travel bounds: relativistic photon rocket (closed form vs ODE); reach capped by the event horizon; Newtonian canary
  OE  observer budgets: Bekenstein, Margolus-Levitin, Landauer for a 1.4 kg, 0.1 m, 20 W, 310 K processor; violation canary
  OF  thermal dimension witness from absolute radiometry (Quinn-Martin sigma); exponent bound; n = 2, 4 canaries
  OG  FIRAS circularity audit: a differential null against a blackbody calibrator is independent of n (canary for the
      withdrawn shape claim); an absolute radiometer does discriminate n
  OH  gravitational dimension witnesses: polarization count D(D-3)/2, GW170817 amplitude-distance D, cone speed
  OI  universal action quantum: fine-structure determinations (Rb, Cs recoil; electron g-2), z-scores, Birge ratio
  OJ  parity of lattice Lorentz violation: 1-D Dirac walk even; 3-D sequential walk has a linear term n_x n_y n_z;
      palindromic walk even; GRB 090510 linear-delay recomputation; orientation probability; quadratic delay
  OK  thermodynamic uncertainty relation as a Cramer-Rao bound (Fisher <= Sigma/2); clock accuracy bound; fake-4 canary
  OL  resolution horizon of a turbulent cascade: finite iff p < 3; decade-gain ratio 10^{(p-3)/2}; p = 3 canary

Run: python rg_observer_bounds.py  (numpy, scipy, sympy). Seed 20261111. Deterministic. Writes rg_observer_bounds_results.json.
"""
import hashlib, json, math, sys
from pathlib import Path
import numpy as np
import sympy as s
from scipy.integrate import quad, solve_ivp
from scipy.optimize import brentq
from scipy.linalg import expm, null_space

HERE = Path(__file__).resolve().parent
SEED = 20261111
rng = np.random.default_rng(SEED)
R, FAILS = {}, []

# exact SI (2019) and CODATA 2018
c = 299792458.0
h = 6.62607015e-34
hbar = h / (2 * math.pi)
kB = 1.380649e-23
G = 6.67430e-11
eV = 1.602176634e-19
Mpc = 3.0856775814913673e22
ly = 9.4607304725808e15
Gly = 1e9 * ly
yr = 3.15576e7
lP = math.sqrt(hbar * G / c ** 3)
EPl_GeV = math.sqrt(hbar * c ** 5 / G) / eV / 1e9
sigma_SB = 2 * math.pi ** 5 * kB ** 4 / (15 * h ** 3 * c ** 2)

# Planck 2018 VI, TT,TE,EE+lowE+lensing (Table 2)
P18 = dict(H0=67.36, H0_err=0.54, Om=0.3153, Om_err=0.0073, OL=0.6847, OL_err=0.0073, age=13.797, age_err=0.023)
TCMB = 2.7255
Neff = 3.046


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.10g}')


def cosmology(H0kms, Om, OL=None, rad=True):
    H0 = H0kms * 1e3 / Mpc
    hh = H0kms / 100
    Og = 2.4728e-5 * (TCMB / 2.7255) ** 4 / hh ** 2  # photon density, Omega_gamma h^2 = 2.473e-5 at 2.7255 K
    Or = Og * (1 + 0.2271 * Neff) if rad else 0.0
    if OL is None:
        OL = 1 - Om - Or
    Ok = 1 - Om - Or - OL
    Hf = lambda a: H0 * math.sqrt(Or / a ** 4 + Om / a ** 3 + Ok / a ** 2 + OL)
    return H0, Hf, dict(Or=Or, OL=OL)


# ============================================================================================  OA
def OA():
    Rr, cc, GG, hb, k = s.symbols('R c G hbar k', positive=True)
    rho = 3 * cc ** 2 / (8 * s.pi * GG * Rr ** 2)                 # vacuum density of a de Sitter patch of radius R (mass units)
    E = rho * cc ** 2 * s.Rational(4, 3) * s.pi * Rr ** 3            # energy within the horizon
    T = hb * cc / (2 * s.pi * k * Rr)                                 # Gibbons-Hawking temperature
    S = k * s.pi * Rr ** 2 * cc ** 3 / (GG * hb)                      # A/(4 l_P^2) in units of k
    id1 = s.simplify(E / (k * T) - S / k)
    komar = s.simplify(2 * E / (T * S))                               # Komar energy |rho+3p|V = 2E: Smarr form 2TS
    # canary: Schwarzschild horizon. M c^2 / (k T_H) = 2 S/k, not S/k: the dS factor 1 is horizon-specific
    M = s.symbols('M', positive=True)
    rs = 2 * GG * M / cc ** 2
    TH = hb * cc ** 3 / (8 * s.pi * GG * M * k)
    SBH = k * s.pi * rs ** 2 * cc ** 3 / (GG * hb)
    bh_ratio = s.simplify((M * cc ** 2 / (k * TH)) / (SBH / k))
    # numbers for the asymptotic de Sitter patch of the measured Lambda
    H0, _, _ = cosmology(P18['H0'], P18['Om'], P18['OL'])
    RL = c / (H0 * math.sqrt(P18['OL']))
    TdS = hbar * c / (2 * math.pi * kB * RL)
    SdS = math.pi * RL ** 2 / lP ** 2
    E_num = c ** 4 * RL / (2 * G)
    ratio = E_num / (kB * TdS) / SdS
    bits = SdS / math.log(2)
    ok = id1 == 0 and komar == 2 and bh_ratio == 2 and abs(ratio - 1) < 1e-12 and 1e122 < bits < 1e123
    must(ok, 'OA')
    R['OA'] = dict(claim='Exact identity for a de Sitter patch: the vacuum energy inside the horizon divided by k T_GH equals the horizon '
                         'entropy, E/(k T) = pi R^2 / l_P^2 = S/k; equivalently E = T S, so E is exactly the Landauer cost of erasing the '
                         'horizon capacity at the horizon temperature. Komar form 2TS (Smarr). This is Padmanabhan holographic '
                         'equipartition in another normalisation, identified, not new. Canary: for a Schwarzschild horizon '
                         'M c^2/(k T_H) = 2 S/k, so the factor 1 is not generic numerology.',
                   status='PROVED (exact) + IDENTIFIED', identity_residual=str(id1), komar_over_TS=str(komar), schwarzschild_ratio=str(bh_ratio),
                   R_Lambda_Gly=fl(RL / Gly), T_dS_K=fl(TdS), S_dS_over_k=fl(SdS), capacity_bits=fl(bits), numeric_ratio_minus_1=fl(ratio - 1))


# ============================================================================================  OB
def OB():
    H0, _, _ = cosmology(P18['H0'], P18['Om'], P18['OL'])
    Lam = 3 * P18['OL'] * H0 ** 2 / c ** 2
    N_bound = 3 * math.pi * c ** 3 / (Lam * G * hbar)                 # Bousso N-bound, units of k (nats)
    RL = math.sqrt(3 / Lam)
    same = abs(N_bound / (math.pi * RL ** 2 / lP ** 2) - 1)
    signif = P18['OL'] / P18['OL_err']
    # Monte-Carlo propagation of H0 and Omega_Lambda (independent, conservative) -> log10 bits
    Hs = rng.normal(P18['H0'], P18['H0_err'], 20000) * 1e3 / Mpc
    Ls = rng.normal(P18['OL'], P18['OL_err'], 20000)
    logbits = np.log10(math.pi * c ** 2 / (Hs ** 2 * Ls) / lP ** 2 / math.log(2))
    # canary: Lambda <= 0 gives no finite bound (N -> infinity as Lambda -> 0+, undefined for Lambda < 0)
    n_small = 3 * math.pi * c ** 3 / (1e-60 * Lam * G * hbar)
    canary = n_small > 1e180
    ok = same < 1e-12 and signif > 50 and np.std(logbits) < 0.02 and canary
    must(ok, 'OB')
    R['OB'] = dict(claim='Finite record capacity (RG premise P1) as a consequence of a measurement: with Lambda > 0 measured at about '
                         '94 sigma (Planck 2018, LCDM), the N-bound limits the observable entropy of any observer to 3 pi/(Lambda l_P^2) '
                         '= S_dS, about 10^122.7 bits. The N-bound rests on the covariant entropy conjecture (Bousso 2000); the '
                         'statement is conditional on it. Canary: as Lambda -> 0 the bound diverges, so P1 is not grounded in a flat '
                         'or anti-de Sitter world by this route.',
                   status='CONDITIONAL (conjecture) + MEASURED input', Lambda_m2=fl(Lam), N_bound_nats=fl(N_bound),
                   log10_bits_mean=fl(np.mean(logbits)), log10_bits_std=fl(np.std(logbits)), Lambda_significance_sigma=fl(signif),
                   canary_N_at_tiny_Lambda=fl(n_small))


# ============================================================================================  OC
def horizons(H0kms, Om, OL=None, rad=True):
    H0, H, par = cosmology(H0kms, Om, OL, rad)
    chi = lambda a1, a2: c * quad(lambda a: 1 / (a * a * H(a)), a1, a2, limit=400, epsabs=0, epsrel=1e-11)[0]
    ph = chi(1e-12, 1.0)
    eh = c * quad(lambda a: 1 / (a * a * H(a)), 1.0, np.inf, limit=400, epsabs=0, epsrel=1e-11)[0]
    age = quad(lambda a: 1 / (a * H(a)), 1e-12, 1.0, limit=400, epsabs=0, epsrel=1e-11)[0] / (1e9 * yr)
    zof = lambda X: brentq(lambda z: chi(1 / (1 + z), 1.0) - X, 0, 1e5, xtol=1e-12)
    return dict(particle_Gly=ph / Gly, event_Gly=eh / Gly, z_event=zof(eh), reach_fraction=(eh / ph) ** 3, age_Gyr=age), chi, H


def OC():
    d, chi, H = horizons(P18['H0'], P18['Om'])
    # canary: Einstein-de Sitter (Lambda = 0): the future conformal integral diverges like 2 sqrt(a_max)
    H0, Hf, _ = cosmology(70.0, 1.0, 0.0, rad=False)
    grow = [c * quad(lambda a: 1 / (a * a * Hf(a)), 1, amax)[0] / Gly for amax in (1e2, 1e4, 1e6)]
    eds_div = grow[2] / grow[1] > 9 and grow[1] / grow[0] > 9
    ok = abs(d['age_Gyr'] - P18['age']) < 2 * P18['age_err'] and 46 < d['particle_Gly'] < 46.5 and 16.5 < d['event_Gly'] < 16.9 \
        and 1.8 < d['z_event'] < 1.95 and 0.04 < d['reach_fraction'] < 0.055 and eds_div
    must(ok, 'OC')
    R['OC'] = dict(claim='Cosmic existence bounds from measured parameters (Planck 2018): age 13.80 Gyr (recomputed, matches the '
                         'published 13.797 +- 0.023), particle horizon 46.1 Gly, event horizon 16.7 Gly comoving at z = 1.87. Matter '
                         'beyond z = 1.87 can never receive a signal sent now, and only 4.7 % of the comoving volume now observable '
                         'is reachable by any signal or traveller. Canary: with Lambda = 0 the event horizon does not exist (the '
                         'conformal future grows without bound), so the bound is a measured-Lambda effect, not a kinematic tautology.',
                   status='COMPUTED from MEASURED input', **{k: fl(v) for k, v in d.items()}, eds_future_Gly=[fl(g) for g in grow])


# ============================================================================================  OD
def OD():
    g = 9.80665
    # photon rocket, constant proper acceleration, accelerate half then decelerate: d = 2 c^2/g (cosh(g tau/2c) - 1)
    def tau_for(dist):
        return 2 * c / g * math.acosh(1 + dist * g / (2 * c ** 2))
    def mass_ratio(tau):
        return math.exp(g * tau / c)                                    # photon exhaust: dM/M = -d(rapidity), total rapidity change g tau/c
    # ODE check of the photon-rocket rapidity law: d(gamma M v)/dtau... use rapidity eta, M' = -M eta'
    def rhs(t, y):
        eta, M = y
        a = g if t < 1.0 * yr else -g
        return [a / c, -M * abs(a) / c]
    sol = solve_ivp(rhs, [0, 2 * yr], [0.0, 1.0], rtol=1e-11, atol=1e-14)
    ode_ratio = 1 / sol.y[1, -1]
    closed = mass_ratio(2 * yr)
    d_and = 2.537e6 * ly                                                # Andromeda, about 2.54 Mly (illustrative)
    t_and = tau_for(d_and)
    r_and = mass_ratio(t_and)
    # the Newtonian canary: proper time with Galilean kinematics d = g t^2/4 gives t = 2 sqrt(d/g), wildly different
    t_newt = 2 * math.sqrt(d_and / g)
    # cosmological cap: a photon emitted now reaches comoving distance = event horizon; any massive traveller strictly less
    d, _, _ = horizons(P18['H0'], P18['Om'])
    ok = abs(ode_ratio / closed - 1) < 1e-8 and 25 < t_and / yr < 32 and r_and > 1e12 and t_newt / t_and > 50
    must(ok, 'OD')
    R['OD'] = dict(claim='Travel bounds: a photon rocket at 1 g (accelerate, then decelerate) reaches Andromeda (2.54 Mly) in about '
                         '28.6 years proper time at a mass ratio of about 6.9e12 (closed form checked against the rocket ODE). No mass '
                         'ratio, however large, reaches comoving distances beyond the event horizon (16.7 Gly). Canary: Galilean '
                         'kinematics would give about 3100 years, two orders of magnitude more; the relativistic bound is not '
                         'decoration.',
                   status='COMPUTED (exact kinematics)', ode_vs_closed_rel=fl(abs(ode_ratio / closed - 1)), andromeda_tau_yr=fl(t_and / yr),
                   andromeda_mass_ratio=fl(r_and), galilean_tau_yr=fl(t_newt / yr), reach_cap_Gly=fl(d['event_Gly']))


# ============================================================================================  OE
def OE():
    m, Rr, P, T = 1.4, 0.1, 20.0, 310.0
    E = m * c ** 2
    bek_bits = 2 * math.pi * Rr * E / (hbar * c * math.log(2))
    ml_ops = 2 * E / (math.pi * hbar)
    land_rate = P / (kB * T * math.log(2))
    lifetime = 80 * yr
    land_life = land_rate * lifetime
    # canary: a claimed model storing 1e50 bits in this volume and mass violates Bekenstein; the bound bites
    claim_bits = 1e50
    canary = claim_bits > bek_bits
    # cosmic budget: all bits any observer can ever register is bounded by S_dS (OB)
    ok = 1e42 < bek_bits < 1e43 and 1e50 < ml_ops < 1e51 and 1e21 < land_rate < 1e22 and canary
    must(ok, 'OE')
    R['OE'] = dict(claim='Observer budgets for a 1.4 kg, 0.1 m, 20 W processor at 310 K: Bekenstein capacity 3.6e42 bits; '
                         'Margolus-Levitin rate 7.6e50 operations/s; Landauer erasure rate at most 6.7e21 bits/s, about 1.7e31 bits '
                         'over 80 years. These are ceilings, not estimates of brains. Landauer cost has been measured (Berut et al. '
                         '2012). Canary: a model claiming 1e50 stored bits in that volume is rejected by the Bekenstein bound.',
                   status='COMPUTED (established bounds)', bekenstein_bits=fl(bek_bits), margolus_levitin_ops_per_s=fl(ml_ops),
                   landauer_bits_per_s=fl(land_rate), landauer_bits_80yr=fl(land_life))


# ============================================================================================  OF
def sigma_n(n):
    """Radiant exitance coefficient in n space dimensions, in SI-like form (dimension changes with n): M = sigma_n T^{n+1}."""
    from scipy.special import zeta, gamma
    S = 2 * math.pi ** (n / 2) / gamma(n / 2)              # area of unit S^{n-1}
    Snm2 = 2 * math.pi ** ((n - 1) / 2) / gamma((n - 1) / 2)
    pol = n - 1
    # energy density u = pol * S * kB^{n+1} T^{n+1} / (h^n c^n) * Gamma(n+1) zeta(n+1)
    u_coef = pol * S * kB ** (n + 1) / (h ** n * c ** n) * gamma(n + 1) * zeta(n + 1)
    # exitance = (c/ S) * u * integral over hemisphere of cos = c u * Snm2 / (S * (n-1))
    return c * u_coef * Snm2 / (S * (n - 1))


def OF():
    s3 = sigma_n(3)
    QM, QM_err = 5.66967e-8, 0.00076e-8                     # Quinn and Martin 1985, total radiation, 233-373 K
    z = (QM - s3) / QM_err
    # exponent witness. Radiometric temperatures agreed with gas thermometry to a few mK over 233-373 K.
    # if exitance ~ T^{4+delta}, a T^4 inversion gives T_rad/T = (T/T0)^{delta/4}; |T_rad - T| <= dT at 373 K bounds delta
    T0, T1 = 273.16, 373.15
    bounds = {}
    for dT in (0.003, 0.010):
        bounds[str(dT)] = fl(4 * (dT / T1) / math.log(T1 / T0))
    # canaries: n = 2 and n = 4 change the exponent by one unit, i.e. by > 1e3 times the conservative bound
    ex = {str(n): n + 1 for n in (2, 3, 4)}
    sep = 1.0 / bounds['0.01']
    ok = abs(s3 / sigma_SB - 1) < 1e-12 and abs(z) < 2 and sep > 1e3
    must(ok, 'OF')
    R['OF'] = dict(claim='Non-circular thermal dimension witness. sigma computed from exact h, k_B, c in n = 3 equals 5.670374e-8; the '
                         'absolute cryogenic radiometer value of Quinn and Martin (5.66967 +- 0.00076)e-8 W m^-2 K^-4 agrees at '
                         '0.93 sigma. h and k_B are realised by Kibble balance and acoustic gas thermometry, not by radiometry, so the '
                         'comparison is independent. The temperature exponent: agreement of radiometric and gas temperatures to '
                         '10 mK over 273-373 K bounds |delta| < 3.4e-4 in M ~ T^{4+delta}; 3 mK gives 1.0e-4. Exponent n + 1 = 4 '
                         'forces n = 3; n = 2 or 4 is excluded by more than 3000 times the bound.',
                   status='MEASURED (independent data) + COMPUTED', sigma_theory=fl(s3), quinn_martin=QM, z_score=fl(z),
                   exponent_delta_bound=bounds, exponents=ex, separation_factor=fl(sep))


# ============================================================================================  OG
def OG():
    nu = np.linspace(1.0, 20.0, 300)                       # arbitrary frequency grid (units of kT/h at T = 1)
    def B(n, nu, T):
        return nu ** n / np.expm1(nu / T)
    # differential instrument: output = response(nu) * [B_sky - B_cal]; calibrator at thermometer temperature T_cal
    resp = 1 + 0.3 * np.sin(nu)                           # unknown response, deliberately non-flat
    nulls = {}
    for n in (2, 3, 4):
        Tsky = 1.0
        out = resp * (B(n, nu, Tsky) - B(n, nu, 1.0))
        nulls[str(n)] = fl(np.max(np.abs(out)))
    # an absolute radiometer (known response, total power) separates n through the T-scaling
    totals = {}
    for n in (3, 4):
        P1 = np.trapezoid(B(n, nu, 1.0), nu) if hasattr(np, 'trapezoid') else np.trapz(B(n, nu, 1.0), nu)
        nu2 = np.linspace(2.0, 40.0, 300)
        P2 = np.trapezoid(B(n, nu2, 2.0), nu2) if hasattr(np, 'trapezoid') else np.trapz(B(n, nu2, 2.0), nu2)
        totals[str(n)] = fl(math.log2(P2 / P1))
    ok = all(v == 0.0 for v in nulls.values()) and abs(totals['3'] - 4) < 1e-9 and abs(totals['4'] - 5) < 1e-9
    must(ok, 'OG')
    R['OG'] = dict(claim='Circularity audit of the withdrawn FIRAS-shape dimension claim. FIRAS measures sky minus an external blackbody '
                         'calibrator; when the sky is a blackbody at the calibrator temperature the output is identically zero for any '
                         'n and any instrument response. The FIRAS null therefore certifies "CMB = cavity radiation" (|y| < 1.5e-5, '
                         '|mu| < 9e-5) and not n; any frequency-shape statement uses a response calibrated with Planck\'s law. An '
                         'absolute radiometer separates n through the temperature exponent (log2 of power ratio at doubled T = n + 1). '
                         'The dimension witness is moved to OF and OH.',
                   status='CANARY (circularity) + CORRECTION', differential_null_max=nulls, absolute_log2_power_ratio=totals)


# ============================================================================================  OH
def OH():
    pol = {D: D * (D - 3) // 2 for D in range(3, 8)}
    sol = [D for D, p in pol.items() if p == 2]
    # Pardo, Fishbach, Holz, Spergel 2018: D = 4.02 +0.07 -0.10 (SH0ES H0), 3.98 +0.07 -0.09 (Planck H0)
    pardo = {'SH0ES': (4.02, 0.07, 0.10), 'Planck': (3.98, 0.07, 0.09)}
    z5 = {k: fl((5 - v[0]) / v[1]) for k, v in pardo.items()}
    z3 = {k: fl((v[0] - 3) / v[2]) for k, v in pardo.items()}
    # GW170817 + GRB 170817A: -3e-15 <= (v_g - c)/c <= +7e-16
    cone = (-3e-15, 7e-16)
    # amplitude-distance law h ~ d^{-(D-2)/2}; canary D = 5 gives d^{-3/2}
    amp = {D: fl((D - 2) / 2) for D in (4, 5)}
    ok = sol == [4] and all(v > 10 for v in z5.values()) and all(v > 9 for v in z3.values()) and amp[4] == 1.0
    must(ok, 'OH')
    R['OH'] = dict(claim='Gravitational dimension witnesses, independent of electromagnetism and of each other. (i) The count of '
                         'propagating tensor polarizations D(D-3)/2 equals 2 only for D = 4 (GW170814: pure tensor favoured over '
                         'pure vector by > 200 and over pure scalar by > 1000). (ii) GW170817 amplitude-distance versus the '
                         'electromagnetic distance gives D = 4.02 (+0.07, -0.10) or 3.98 (+0.07, -0.09); D = 5 is excluded at more '
                         'than 13 sigma. (iii) One cone: |v_g/c - 1| < 3e-15. These are data for premises III and IV of the tensor '
                         'derivation, not consequences of it.',
                   status='MEASURED (independent data)', polarizations=pol, D_from_polarization=sol, pardo_z_vs_D5=z5, pardo_z_vs_D3=z3,
                   cone_bounds=list(cone), amplitude_exponent=amp)


# ============================================================================================  OI
def OI():
    a = {'Rb_recoil_2020': (137.035999206, 11e-9), 'Cs_recoil_2018': (137.035999046, 27e-9), 'e_g2_2023': (137.035999166, 15e-9)}
    keys = list(a)
    z = {}
    for i in range(3):
        for j in range(i + 1, 3):
            (x1, s1), (x2, s2) = a[keys[i]], a[keys[j]]
            z[f'{keys[i]}-{keys[j]}'] = fl((x1 - x2) / math.hypot(s1, s2))
    w = np.array([1 / v[1] ** 2 for v in a.values()]); x = np.array([v[0] for v in a.values()])
    mean = float(np.sum(w * x) / np.sum(w)); chi2 = float(np.sum(w * (x - mean) ** 2)); birge = math.sqrt(chi2 / 2)
    # without Cs
    w2, x2 = w[[0, 2]], x[[0, 2]]
    m2 = float(np.sum(w2 * x2) / np.sum(w2)); birge2 = math.sqrt(float(np.sum(w2 * (x2 - m2) ** 2)))
    # canary: synthetic consistent triple drawn from one value gives Birge ratio of order 1
    syn = []
    for _ in range(2000):
        xs = mean + rng.normal(0, 1, 3) * np.array([v[1] for v in a.values()])
        ms = float(np.sum(w * xs) / np.sum(w)); syn.append(math.sqrt(float(np.sum(w * (xs - ms) ** 2)) / 2))
    p_exceed = float(np.mean(np.array(syn) >= birge))
    # gravity sector: qBounce g = 9.84 +- 0.04 m/s^2 with transition frequencies nu ~ g^{2/3} hbar^{-1/3}:
    # agreement with any terrestrial g in [9.78, 9.83] bounds hbar_grav/hbar - 1 within 2*(|dg| + 0.04)/9.8
    hb_grav = fl(2 * (abs(9.84 - 9.805) + 0.04) / 9.805)
    ok = abs(z['Rb_recoil_2020-Cs_recoil_2018'] - 5.48) < 0.05 and birge > 2.5 and p_exceed < 1e-3 and birge2 < 2.5
    must(ok, 'OI')
    R['OI'] = dict(claim='Universal action quantum across sectors. Atom-recoil (h/m) and QED (electron g-2) determinations of alpha agree '
                         'at 1e-10 relative with one hbar: Rb vs g-2 at 2.2 sigma. The Rb-Cs pair differs by 5.5 sigma (Birge ratio '
                         'of the triple 3.9; none of 2000 consistent synthetic triples reaches it). RG requires one exchange quantum for all carriers, '
                         'so it predicts the Rb-Cs tension is systematic and that new determinations converge; a species-dependent '
                         'h/m surviving systematics would falsify universal hbar. Gravity sector (qBounce, neutron bound states): '
                         'hbar_grav/hbar = 1 within about 1.5 %.',
                   status='MEASURED + PREDICTION (shared with standard physics)', z_pairs=z, weighted_mean=f'{mean:.12f}',
                   birge_ratio=fl(birge), birge_without_Cs=fl(birge2), p_consistent_exceeds=fl(p_exceed), hbar_grav_rel_bound=hb_grav)


# ============================================================================================  OJ
sx = np.array([[0, 1], [1, 0]], complex); sy = np.array([[0, -1j], [1j, 0]]); sz = np.array([[1, 0], [0, -1]], complex)


def U_seq(k):
    return expm(-1j * k[0] * sx) @ expm(-1j * k[1] * sy) @ expm(-1j * k[2] * sz)


def U_pal(k):
    return expm(-0.5j * k[0] * sx) @ expm(-0.5j * k[1] * sy) @ expm(-1j * k[2] * sz) @ expm(-0.5j * k[1] * sy) @ expm(-0.5j * k[0] * sx)


def omega(U):
    ev = np.linalg.eigvals(U)
    return float(np.max(np.abs(np.angle(ev))))


def K_lin(z, H0kms, Om, OL):
    return quad(lambda zz: (1 + zz) / math.sqrt(Om * (1 + zz) ** 3 + OL), 0, z)[0] / (H0kms * 1e3 / Mpc)


def K_quad(z, H0kms, Om, OL):
    return 1.5 * quad(lambda zz: (1 + zz) ** 2 / math.sqrt(Om * (1 + zz) ** 3 + OL), 0, z)[0] / (H0kms * 1e3 / Mpc)


def OJ():
    # 1-D Dirac walk: cos w = n cos k, even in k
    m = 0.05; n = math.sqrt(1 - m * m)
    w1 = lambda k: math.acos(n * math.cos(k))
    odd1 = max(abs(w1(k) - w1(-k)) for k in np.linspace(0.001, 0.5, 50))
    # 3-D walks: fit (w - |k|)/|k|^2 along random directions at small |k|
    dirs = rng.normal(size=(40, 3)); dirs /= np.linalg.norm(dirs, axis=1)[:, None]
    fs, fp, pal_rel = [], [], []
    for d in dirs:
        ks = np.array([1e-3, 2e-3])
        ws = np.array([omega(U_seq(kk * d)) for kk in ks])
        coef = (ws - ks) / ks ** 2
        fs.append((coef[0], d[0] * d[1] * d[2]))
        wp = np.array([omega(U_pal(kk * d)) for kk in ks])
        fp.append(np.max(np.abs((wp - ks) / ks ** 2)))
        k3 = 1e-2
        d1 = abs(omega(U_pal(k3 * d)) - k3); d2 = abs(omega(U_pal(2 * k3 * d)) - 2 * k3)
        pal_rel.append((d1 / k3, d2 / d1 if d1 > 0 else 8.0))
    lin_err = max(abs(a - b) for a, b in fs)
    pal_lin = max(fp)
    pal_scaling = max(r[0] for r in pal_rel) / 1e-4             # relative deviation / k^2: O(1e-2..1) for quadratic
    pal_power = [r[1] for r in pal_rel if r[0] > 1e-9]           # deviation ratio at 2k vs k: 8 for a cubic (relative quadratic) term
    # GRB 090510: Abdo et al. 2009 cosmology (H0 71, Om 0.27, OL 0.73), z = 0.903, 31 GeV, dt < 0.859 s
    K1 = K_lin(0.903, 71, 0.27, 0.73)
    E_cons = 30.53 - 2.56                                       # photon energy minus its 1-sigma, as used for the conservative limit
    EQG1_abdo = E_cons * K1 / 0.859 / EPl_GeV
    # quadratic delay of the same photon at E_QG,2 = E_Pl
    dt2 = (31.0 / EPl_GeV) ** 2 * K_quad(0.903, 71, 0.27, 0.73)
    # sequential walk at a = l_P: E_QG,1 = E_Pl / (2 |f|), f = n_x n_y n_z; Vasileiou 2013 subluminal bound E_QG,1 > 7.6 E_Pl
    fmax = 1 / (3 * math.sqrt(3))
    fcrit = 1 / (2 * 7.6)
    u = rng.normal(size=(200000, 3)); u /= np.linalg.norm(u, axis=1)[:, None]
    f = u[:, 0] * u[:, 1] * u[:, 2]
    p_excluded = float(np.mean(f < -fcrit))                     # subluminal and above the bound
    p_sub = float(np.mean(f < 0))
    ok = odd1 < 1e-14 and lin_err < 5e-3 and pal_lin < 5e-3 and 1e-3 < pal_scaling < 10 and min(pal_power) > 7.5 and max(pal_power) < 8.5 and abs(EQG1_abdo - 1.19) < 0.02 and dt2 < 1e-15 \
        and fmax > fcrit and 0.05 < p_excluded < 0.5
    must(ok, 'OJ')
    R['OJ'] = dict(claim='Parity of lattice Lorentz violation, confronted with data. The 1-D Dirac walk of the quantum-gravity print has '
                         'cos w = n cos k: even, so its leading violation is quadratic. In 3-D the answer depends on how the walk is '
                         'composed. The sequential walk exp(-i kx sx) exp(-i ky sy) exp(-i kz sz) has cos w = cx cy cz - sx sy sz and '
                         'w = |k| + f |k|^2 with f = nx ny nz: a linear, direction-dependent violation, E_QG,1 = E_a/(2|f|). The '
                         'palindromic (time-symmetric) walk has no linear term (relative deviation O(k^2), checked by the factor 8 of '
                         'the absolute deviation at doubled k). Recomputing the Fermi GRB 090510 linear limit from '
                         'its inputs gives 1.2 E_Pl (published 1.19); the later bound is 7.6 E_Pl (subluminal). A sequential walk at '
                         'a = l_P with photons on the same lattice is excluded for orientations with f < -0.066, about 26 % of all '
                         'orientations for this one burst; the quadratic delay at E_Pl is 1e-17 s, untestable. Prediction: the '
                         'physical walk is palindromic (inversion-symmetric) and no propagation-origin linear delay exists.',
                   status='COMPUTED + MEASURED bound + PREDICTION', odd_part_1D=fl(odd1), seq_linear_coef_vs_nxnynz_maxerr=fl(lin_err),
                   pal_linear_coef_max=fl(pal_lin), pal_rel_dev_over_k2=fl(pal_scaling), pal_power_ratio_range=[fl(min(pal_power)), fl(max(pal_power))], EQG1_recomputed_over_EPl=fl(EQG1_abdo),
                   quadratic_delay_s_at_EPl=fl(dt2), f_max=fl(fmax), f_crit=fl(fcrit), p_orientation_excluded=fl(p_excluded),
                   p_subluminal=fl(p_sub), E_Pl_GeV=fl(EPl_GeV))


# ============================================================================================  OK
def generator(W):
    L = W.copy(); np.fill_diagonal(L, 0); L -= np.diag(L.sum(axis=0)); return L


def steady(W):
    L = generator(W); p = null_space(L)[:, 0]; return np.real(p / p.sum())


def scgf(W, D, lam):
    T = W * np.exp(lam * D); np.fill_diagonal(T, 0); T = T - np.diag(W.sum(axis=0) - np.diag(W))
    return float(np.max(np.real(np.linalg.eigvals(T))))


def tur_stats(W, D):
    p = steady(W)
    hh = 1e-4
    th = [scgf(W, D, l) for l in (-2 * hh, -hh, 0.0, hh, 2 * hh)]
    J = (-th[4] + 8 * th[3] - 8 * th[1] + th[0]) / (12 * hh)
    V = (-th[4] + 16 * th[3] - 30 * th[2] + 16 * th[1] - th[0]) / (12 * hh * hh)
    n = W.shape[0]; Sig = 0.0; Fis = 0.0
    for i in range(n):
        for j in range(i + 1, n):
            f1, f2 = W[i, j] * p[j], W[j, i] * p[i]
            if f1 > 0 and f2 > 0:
                Sig += (f1 - f2) * math.log(f1 / f2); Fis += (f1 - f2) ** 2 / (f1 + f2)
    return J, V, Sig, Fis


def OK():
    worst, worst_cr, saturation = np.inf, np.inf, None
    for trial in range(120):
        n = int(rng.integers(3, 7))
        W = np.zeros((n, n))
        for i in range(n):                                       # ring plus random chords
            j = (i + 1) % n
            W[j, i] = rng.uniform(0.2, 3.0); W[i, j] = rng.uniform(0.2, 3.0)
        for _ in range(int(rng.integers(0, 3))):
            i, j = rng.choice(n, 2, replace=False); W[j, i] = rng.uniform(0.1, 2); W[i, j] = rng.uniform(0.1, 2)
        D = np.zeros((n, n)); D[1, 0] = 1; D[0, 1] = -1             # current: net jumps across edge 0 -> 1
        J, V, Sig, Fis = tur_stats(W, D)
        if abs(J) < 1e-6:
            continue
        worst = min(worst, V * Sig / (2 * J * J))
        worst_cr = min(worst_cr, V * Fis / (J * J))             # Cramer-Rao: Var >= J^2 / I with I = Fisher <= Sigma/2
        must(Fis <= Sig / 2 + 1e-12, 'OK-fisher')
    # near-equilibrium uniform ring: ratio -> 1 (bound saturates); clock accuracy per cycle <= dS/2
    N = 5; eps = 1e-3
    W = np.zeros((N, N))
    for i in range(N):
        W[(i + 1) % N, i] = 1 + eps; W[i, (i + 1) % N] = 1.0
    D = np.zeros((N, N)); D[1, 0] = 1; D[0, 1] = -1
    J, V, Sig, Fis = tur_stats(W, D)
    near = V * Sig / (2 * J * J)
    fake4 = V * Sig / (J * J)                                    # canary: a claimed constant 4 is violated near equilibrium
    # clock: strongly driven uniform ring; accuracy per cycle (J^2/V per cycle-time) vs entropy per cycle
    Wc = np.zeros((N, N))
    for i in range(N):
        Wc[(i + 1) % N, i] = 5.0; Wc[i, (i + 1) % N] = 0.05
    Dc = np.zeros((N, N)); Dc[1, 0] = 1; Dc[0, 1] = -1
    Jc, Vc, Sc, _ = tur_stats(Wc, Dc)
    acc = Jc / Vc                                                 # accuracy per tick for a renewal clock: mean^2/var of period
    dS_tick = Sc / Jc
    ok = worst >= 1 - 1e-6 and worst_cr >= 1 - 1e-6 and abs(near - 1) < 1e-2 and fake4 < 4 and acc <= dS_tick / 2 + 1e-9 and acc <= N + 1e-9
    must(ok, 'OK')
    R['OK'] = dict(claim='The thermodynamic uncertainty relation is a Cramer-Rao bound of the RG Fisher geometry. The virtual '
                         'perturbation d ln w_ij = j_ij / a_ij (net flux over traffic) keeps the steady state, scales every current '
                         'by (1 + theta) and has path Fisher rate I = sum j^2/a <= Sigma/2 by the log-mean inequality; hence '
                         'Var(J)/<J>^2 >= 1/I >= 2/Sigma. Checked on 120 random networks. For any discrete-state clock the accuracy '
                         'per tick is at most dS_tick/(2 k_B). Data: biochemical oscillator models lie orders of magnitude below the '
                         'bound (Marsland et al. 2019); a nanomechanical clock shows accuracy linear in entropy per tick (Pearson '
                         'et al. 2021), a continuous-variable class with its own constant. Canary: a claimed constant 4 is violated '
                         'near equilibrium, where the bound saturates.',
                   status='PROVED (inequality) + IDENTIFIED (Barato-Seifert, Hasegawa-Van Vu)', min_tur_ratio=fl(worst),
                   min_cramer_rao_ratio=fl(worst_cr), near_equilibrium_ratio=fl(near), fake4_value=fl(fake4), clock_accuracy=fl(acc),
                   clock_dS_tick_over_2=fl(dS_tick / 2))


# ============================================================================================  OL
def OL():
    def horizon(p, N, kt=None, p2=None):
        tot = 0.0
        for nshell in range(1, N + 1):
            k = 10.0 ** (nshell / 3)
            if kt is None or k <= kt:
                E = k ** (-p)
            else:
                E = kt ** (-p) * (k / kt) ** (-p2)
            tot += (k ** 3 * E) ** -0.5
        return tot
    dec = 3                                                      # three shells per decade, shell ratio 10^(1/3)
    res = {}
    for p in (5 / 3, 2.0, 3.0):
        Ts = [horizon(p, dec * d) for d in (1, 2, 3, 4, 5, 6)]
        gains = np.diff(Ts)
        res[f'{p:.4f}'] = dict(T=[fl(t) for t in Ts], gain_ratios=[fl(g2 / g1) for g1, g2 in zip(gains[:-1], gains[1:])])
    r53 = res[f'{5/3:.4f}']['gain_ratios'][-1]
    r3 = res['3.0000']['gain_ratios'][-1]
    # two-regime atmosphere: k^-3 at large scales, k^-5/3 beyond the transition (Nastrom-Gage), transition at 2^5
    Ts2 = [horizon(3.0, dec * d, kt=1e2, p2=5 / 3) for d in range(1, 9)]
    limit = horizon(3.0, 150, kt=1e2, p2=5 / 3)
    theory = 10 ** ((5 / 3 - 3) / 2)
    # canary: p = 3 everywhere has constant decade gains (no intrinsic limit)
    ok = abs(r53 - theory) < 1e-9 and abs(r3 - 1) < 1e-9 and Ts2[-1] < limit and limit - Ts2[-1] < 1e-2 * limit
    must(ok, 'OL')
    R['OL'] = dict(claim='Resolution horizon of a cascade (Lorenz 1969, made explicit). With kinetic-energy spectrum E(k) ~ k^-p, the '
                         'time for an error confined below the resolved scale to reach the largest scale is a sum of eddy times '
                         'k^{(p-3)/2}. It is finite as resolution -> infinity iff p < 3; the gain per decade of resolution shrinks by '
                         '10^{(p-3)/2} = 0.215 for p = 5/3 (measured mesoscale atmospheric slope, Nastrom-Gage). For p = 3 the gain per '
                         'decade is constant (logarithmic horizon). A two-regime spectrum has a finite limit. Data consistency: '
                         'Zhang et al. 2019 find a midlatitude limit near two weeks and a gain of up to 5 days for an order-of-magnitude '
                         'error reduction. Canary: p = 3 yields no intrinsic limit.',
                   status='PROVED (series) + IDENTIFIED (Lorenz) + data consistency', spectra=res, gain_ratio_theory_p53=fl(theory),
                   two_regime_T=[fl(t) for t in Ts2], two_regime_limit=fl(limit))


if __name__ == '__main__':
    for fn in [OA, OB, OC, OD, OE, OF, OG, OH, OI, OJ, OK, OL]:
        fn(); print(fn.__name__, flush=True)
    R['source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    R['seed'] = SEED
    R['failures'] = FAILS
    (HERE / 'rg_observer_bounds_results.json').write_text(json.dumps(R, indent=1, sort_keys=True, default=str) + '\n')
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
