"""RG Coherence Geometry battery (print: 'RG - Coherence Geometry').

Question: does coherence deserve a standalone geometry in Resolution Geometry, or is it a sector of uncertainty
(Fisher) geometry? Each group constructs a criterion or attacks it, and carries a canary.

  K1  identification layer: collisions for population, partial-quadrature and scalar records; complete pair protocols
  K2  existence criterion: a maximal frame is complete iff the record cone is a simplex; Peirce gap k d(d-1)/2, k = 0,1,2,4
  K3  dephasing = conditional expectation = twirl over the frame gauge group (real Z2, complex U(1), quaternionic Sp(1))
  K4  gauge classification: invariants = populations, magnitudes, support graph, holonomy on b1 cycles; reconstruction;
      non-abelian (quaternionic) holonomy only up to conjugation
  K5  holonomy is physical: the admissible coherence magnitude depends on the loop phase
  K6  metric freedom: all monotone (Petz) metrics agree with Fisher on population directions and differ on coherence
      directions; ordering SLD <= WY <= BKM <= max; monotone under channels; non-Petz (Hilbert-Schmidt) canary
  K7  task selection: sup over protocols of record Fisher = SLD (Braunstein-Caves); larger monotone metrics are
      never attained: the resolution task selects SLD (= 4 Bures) on coherence
  K8  curvature: Berry curvature on the pure stratum, Chern number 1; mean Uhlmann curvature vanishes on commuting
      families and not on coherent ones; Gill-Massar cap Tr(F_Q^-1 F_C) <= d-1 (joint resolution obstructed)
  K9  Kahler pure stratum: g = Re Q, omega = Im Q, J = i; Schrodinger flow is the Hamiltonian flow of <H>
  K10 morphism class: relative-entropy coherence is monotone under a channel for all inputs iff the channel is MIO
  K11 RG reading: coherence = resolvability of the reference orbit (orbit QFI zero iff incoherent, for nondegenerate
      reference); monotone under covariant channels; degenerate-reference canary
  K12 frame relativity: every state is incoherent in its own eigenframe; pure-state maximum log2 d in an unbiased frame
  K13 structure-group destructor: local tomography K(dA dB) = K(dA) K(dB) holds only for k = 2 (complex), conditional
      on tensor-product composition
  K14 realization canary: classical partially coherent waves realize the same coherence geometry (it is a property of
      the record cone, not of quantum ontology)
  K15 bundle form: base = population simplex (Fisher), fibre = coherence over p, collapse at simplex walls,
      orthogonal split of every monotone metric on the zero section, mixing away from it

Run: python rg_coherence_geometry.py   (numpy, scipy). Seed 20261110. Deterministic.
"""
import hashlib, itertools, json, sys
from pathlib import Path
import numpy as np
from scipy.linalg import expm

HERE = Path(__file__).resolve().parent
SEED = 20261110
rng = np.random.default_rng(SEED)
R, FAILS = {}, []


def must(c, tag):
    if not c:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.12g}')


# ------------------------------------------------------------------ helpers
def herm(A):
    return (A + A.conj().T) / 2


def rand_rho(d, rank=None):
    r = rank or d
    A = rng.normal(size=(d, r)) + 1j * rng.normal(size=(d, r))
    M = A @ A.conj().T
    return M / np.trace(M).real


def rand_herm0(d):
    A = rng.normal(size=(d, d)) + 1j * rng.normal(size=(d, d))
    H = herm(A)
    return H - np.trace(H) / d * np.eye(d)


def delta(M):
    return np.diag(np.diag(M))


def entropy(M):
    e = np.linalg.eigvalsh(herm(M)); e = e[e > 1e-14]
    return float(-np.sum(e * np.log2(e)))


def c_rel(M):
    return entropy(delta(M)) - entropy(M)


def l1(M):
    return float(np.sum(np.abs(M - delta(M))))


def trace_dist(A, B):
    return float(np.sum(np.abs(np.linalg.eigvalsh(herm(A - B)))) / 2)


FS = {'SLD': lambda x: (1 + x) / 2,
      'WY': lambda x: ((1 + np.sqrt(x)) / 2) ** 2,
      'BKM': lambda x: (x - 1) / np.log(x) if abs(x - 1) > 1e-12 else 1.0,
      'max': lambda x: 2 * x / (1 + x)}


def petz(rho, X, f):
    lam, U = np.linalg.eigh(herm(rho)); Xe = U.conj().T @ X @ U
    tot = 0.0
    for i in range(len(lam)):
        for j in range(len(lam)):
            tot += abs(Xe[i, j]) ** 2 / (lam[j] * f(lam[i] / lam[j]))
    return float(tot)


def classical_fisher(rho, X, povm):
    tot = 0.0
    for E in povm:
        p = np.trace(E @ rho).real
        if p > 1e-15:
            tot += np.trace(E @ X).real ** 2 / p
    return tot


def rand_povm(d, n):
    A = rng.normal(size=(n, d)) + 1j * rng.normal(size=(n, d))
    Q, _ = np.linalg.qr(A)
    V = Q[:, :d]                          # isometry C^d -> C^n
    return [np.outer(V[k].conj(), V[k]) for k in range(n)]


def rand_channel(d, dout, env):
    A = rng.normal(size=(dout * env, d)) + 1j * rng.normal(size=(dout * env, d))
    Q, _ = np.linalg.qr(A)
    V = Q[:, :d].reshape(dout, env, d)
    return [V[:, e, :] for e in range(env)]


def apply(Ks, M):
    return sum(K @ M @ K.conj().T for K in Ks)


def bloch(v):
    I = np.eye(2); X = np.array([[0, 1], [1, 0]], complex); Y = np.array([[0, -1j], [1j, 0]]); Z = np.diag([1., -1.])
    return (I + v[0] * X + v[1] * Y + v[2] * Z) / 2


# ------------------------------------------------------------------ K1
def K1():
    out = {}
    a, phi = 0.7, 0.83
    rho = bloch([a * np.cos(phi), a * np.sin(phi), 0.2])
    out['population_collision'] = dict(record_gap=fl(np.max(np.abs(np.diag(rho) - np.diag(delta(rho))))),
                                       trace_distance=fl(trace_dist(rho, delta(rho))))
    I = np.eye(2); X = np.array([[0, 1], [1, 0]], complex); Z = np.diag([1., -1.])
    r1 = bloch([0, 0.6, 0]); r0 = np.eye(2) / 2
    xz = [(I + X) / 2, (I + Z) / 2]
    out['XZ_collision'] = dict(record_gap=fl(max(abs(np.trace((r1 - r0) @ E)) for E in xz)), trace_distance=fl(trace_dist(r1, r0)))
    rp, rm = bloch([0.8, 0, 0]), bloch([-0.8, 0, 0])
    out['scalar_collision'] = dict(l1=[fl(l1(rp)), fl(l1(rm))], c_rel=[fl(c_rel(rp)), fl(c_rel(rm))], trace_distance=fl(trace_dist(rp, rm)))

    def loop_state(th, c=0.08):
        M = np.eye(3, dtype=complex) / 3
        M[0, 1] = M[1, 2] = c; M[0, 2] = c * np.exp(-1j * th)
        M[1, 0], M[2, 1], M[2, 0] = np.conj(M[0, 1]), np.conj(M[1, 2]), np.conj(M[0, 2])
        return M
    A, B = loop_state(0), loop_state(np.pi / 2)
    out['loop_collision'] = dict(l1=[fl(l1(A)), fl(l1(B))], magnitudes_equal=bool(np.allclose(np.abs(A), np.abs(B))),
                                 trace_distance=fl(trace_dist(A, B)))
    # complete pair protocols: d diagonal + 2 per pair (real and imaginary quadratures)
    errs = []
    for d in [2, 3, 4, 5]:
        for _ in range(40):
            M = rand_rho(d); Mh = np.diag(np.diag(M).real).astype(complex)
            for i, j in itertools.combinations(range(d), 2):
                for ph in [1, 1j]:
                    v = np.zeros(d, complex); v[i] = 1 / np.sqrt(2); v[j] = ph / np.sqrt(2)
                    p = np.real(v.conj() @ M @ v)
                    if ph == 1:
                        re = p - (M[i, i].real + M[j, j].real) / 2
                    else:
                        im = (M[i, i].real + M[j, j].real) / 2 - p
                Mh[i, j] = re + 1j * im; Mh[j, i] = re - 1j * im
            errs.append(np.max(np.abs(Mh - M)))
    out['pair_protocol_reconstruction_max_error'] = fl(max(errs))
    ok = (out['population_collision']['record_gap'] == 0 and out['population_collision']['trace_distance'] > 0.3
          and out['XZ_collision']['record_gap'] < 1e-15 and out['XZ_collision']['trace_distance'] > 0.29
          and abs(out['scalar_collision']['l1'][0] - out['scalar_collision']['l1'][1]) < 1e-12 and out['scalar_collision']['trace_distance'] > 0.79
          and out['loop_collision']['magnitudes_equal'] and out['loop_collision']['trace_distance'] > 0.01
          and out['pair_protocol_reconstruction_max_error'] < 1e-13)
    must(ok, 'K1')
    R['K1'] = dict(claim='Coherence is not identified by population records, by X,Z-only records, by scalar coherence values, or by '
                         'pair magnitudes (loop phase); d diagonal + 2 quadrature settings per pair (d^2 settings) identify it '
                         'completely', status='CONSTRUCTED (collisions + exact reconstruction)', **out)


# ------------------------------------------------------------------ K2
def herm_basis(d, k):
    """real basis of d x d Hermitian matrices over R (k=1), C (k=2), H (k=4, as 2d x 2d complex)."""
    qunits = [np.eye(2, dtype=complex), np.array([[1j, 0], [0, -1j]]), np.array([[0, 1], [-1, 0]], complex),
              np.array([[0, 1j], [1j, 0]])]
    basis = []
    for i in range(d):
        if k == 4:
            M = np.zeros((2 * d, 2 * d), complex); M[2 * i:2 * i + 2, 2 * i:2 * i + 2] = np.eye(2)
        else:
            M = np.zeros((d, d), complex); M[i, i] = 1
        basis.append(M)
    for i, j in itertools.combinations(range(d), 2):
        units = {1: [1], 2: [1, 1j]}.get(k)
        if k in (1, 2):
            for u in units:
                M = np.zeros((d, d), complex); M[i, j] = u; M[j, i] = np.conj(u); basis.append(M)
        else:
            for q in qunits:
                M = np.zeros((2 * d, 2 * d), complex)
                M[2 * i:2 * i + 2, 2 * j:2 * j + 2] = q; M[2 * j:2 * j + 2, 2 * i:2 * i + 2] = q.conj().T
                basis.append(M)
    return basis


def K2():
    table = {}
    for k in [1, 2, 4]:
        for d in [2, 3, 4, 5]:
            B = herm_basis(d, k)
            vecs = np.array([np.concatenate([M.real.ravel(), M.imag.ravel()]) for M in B])
            dim = int(np.linalg.matrix_rank(vecs))
            # frame records: probabilities of the d frame idempotents (complex trace / block size)
            bs = 2 if k == 4 else 1
            frame = np.array([[np.trace(M[bs * i:bs * i + bs, bs * i:bs * i + bs]).real / bs for i in range(d)] for M in B])
            rk = int(np.linalg.matrix_rank(frame))
            table[f'k{k}_d{d}'] = dict(state_dim=dim, frame_rank=rk, gap=dim - rk, peirce=k * d * (d - 1) // 2)
    simplex = {f'd{d}': dict(state_dim=d, frame_rank=d, gap=0) for d in [2, 3, 4, 5]}
    ok = all(v['gap'] == v['peirce'] and v['frame_rank'] == int(v['state_dim'] - v['peirce']) for v in table.values())
    must(ok, 'K2')
    R['K2'] = dict(claim='A maximal frame (d orthogonal minimal idempotents) leaves exactly k d(d-1)/2 unresolved real directions, the '
                         'Peirce off-diagonal spaces (k = 1 real, 2 complex, 4 quaternionic); in a simplex (commutative records) the '
                         'gap is 0. Coherence exists iff the record cone is not a simplex', status='CONSTRUCTED (exact rank count)',
                   hermitian=table, simplex=simplex)


# ------------------------------------------------------------------ K3
def qrand_rho(d):
    """random quaternionic density matrix as 2d x 2d complex with quaternion blocks."""
    def q(a, b, c, e):
        return np.array([[a + 1j * b, c + 1j * e], [-c + 1j * e, a - 1j * b]])
    A = np.zeros((2 * d, 2 * d), complex)
    for i in range(d):
        for j in range(d):
            A[2 * i:2 * i + 2, 2 * j:2 * j + 2] = q(*rng.normal(size=4))
    M = A @ A.conj().T
    return M / (np.trace(M).real / 2)


def K3():
    out = {}
    d = 4
    rho = rand_rho(d)
    tw = np.zeros((d, d), complex)
    roots = np.exp(2j * np.pi * np.arange(3) / 3)
    for ph in itertools.product(roots, repeat=d):
        D = np.diag(ph); tw += D @ rho @ D.conj().T
    tw /= 3 ** d
    out['complex_U1_twirl_error'] = fl(np.max(np.abs(tw - delta(rho))))
    rr = rand_rho(d).real; rr = rr / np.trace(rr)
    tw = np.zeros((d, d))
    for sg in itertools.product([1, -1], repeat=d):
        D = np.diag(sg); tw += D @ rr @ D
    tw /= 2 ** d
    out['real_Z2_twirl_error'] = fl(np.max(np.abs(tw - np.diag(np.diag(rr)))))
    dq = 3; rq = qrand_rho(dq)
    Q8 = [s * u for s in [1, -1] for u in [np.eye(2, dtype=complex), np.array([[1j, 0], [0, -1j]]), np.array([[0, 1], [-1, 0]], complex),
                                             np.array([[0, 1j], [1j, 0]])]]
    tw = np.zeros_like(rq)
    for qs in itertools.product(Q8, repeat=dq):
        D = np.zeros_like(rq)
        for i, qq in enumerate(qs):
            D[2 * i:2 * i + 2, 2 * i:2 * i + 2] = qq
        tw += D @ rq @ D.conj().T
    tw /= 8 ** dq
    blockdiag = np.zeros_like(rq)
    for i in range(dq):
        blockdiag[2 * i:2 * i + 2, 2 * i:2 * i + 2] = rq[2 * i:2 * i + 2, 2 * i:2 * i + 2]
    out['quaternion_Sp1_twirl_error'] = fl(np.max(np.abs(tw - blockdiag)))
    # conditional expectation properties of Delta
    A = rand_herm0(d); Bm = rand_herm0(d)
    out['idempotent'] = fl(np.max(np.abs(delta(delta(A)) - delta(A))))
    out['HS_selfadjoint'] = fl(abs(np.trace(delta(A) @ Bm) - np.trace(A @ delta(Bm))))
    Dg = np.diag(rng.normal(size=d))
    out['bimodule'] = fl(np.max(np.abs(delta(Dg @ A) - Dg @ delta(A))))
    a1 = np.array([[0.5, 0.1], [0.1, 0.5]], complex); a2 = np.array([[0.5, 0.4], [0.4, 0.5]], complex)
    same_fibre = float(np.max(np.abs(delta(a1) - delta(a2))))
    spectra = [list(np.round(np.linalg.eigvalsh(a1), 12)), list(np.round(np.linalg.eigvalsh(a2), 12))]
    must(all(v < 1e-13 for v in out.values()) and same_fibre == 0 and spectra[0] != spectra[1], 'K3')
    out['fibre_union_of_orbits'] = dict(same_dephasing=same_fibre == 0, spectra=[[fl(x) for x in s_] for s_ in spectra])
    R['K3'] = dict(claim='Dephasing Delta is the conditional expectation onto the frame algebra (idempotent, HS self-adjoint, '
                         'bimodule) and equals the twirl over the frame gauge group: Z2^d (real), U(1)^d (complex, exact with cube '
                         'roots of unity), Sp(1)^d (quaternionic, exact with Q8). Coherence is the part of the state that a forgotten '
                         'reference phase erases. The fibre of Delta is a union of gauge orbits, not one orbit (equal populations, '
                         'different magnitudes, different spectra); the orbit space is classified in K4', status='CONSTRUCTED (exact)', errors=out)


# ------------------------------------------------------------------ K4
def sparse_state(d, p_edge):
    edges = [(i, j) for i, j in itertools.combinations(range(d), 2) if rng.random() < p_edge]
    M = np.diag(rng.uniform(1, 2, size=d)).astype(complex)
    for i, j in edges:
        z = rng.uniform(0.05, 0.15) * np.exp(1j * rng.uniform(-np.pi, np.pi))
        M[i, j] = z; M[j, i] = np.conj(z)
    M /= np.trace(M).real
    assert np.linalg.eigvalsh(M).min() > 0
    return M, edges


def cycle_basis(d, edges):
    parent = {}
    adj = {i: [] for i in range(d)}
    for i, j in edges:
        adj[i].append(j); adj[j].append(i)
    tree, seen = [], set()
    for r in range(d):
        if r in seen:
            continue
        seen.add(r); parent[r] = None; stack = [r]
        while stack:
            u = stack.pop()
            for v in adj[u]:
                if v not in seen:
                    seen.add(v); parent[v] = u; tree.append((u, v)); stack.append(v)
    comps = sum(1 for v in parent if parent[v] is None)
    tset = {frozenset(e) for e in tree}
    nontree = [e for e in edges if frozenset(e) not in tset]

    def path_to_root(v):
        p = [v]
        while parent[p[-1]] is not None:
            p.append(parent[p[-1]])
        return p
    cycles = []
    for i, j in nontree:
        pi, pj = path_to_root(i), path_to_root(j)
        common = set(pi) & set(pj)
        lca = next(v for v in pi if v in common)
        cyc = pi[:pi.index(lca) + 1] + list(reversed(pj[:pj.index(lca)]))
        cycles.append(cyc)                 # i -> ... -> lca -> ... -> j, closed by edge j -> i
    return tree, cycles, comps, parent


def holonomy(M, cyc):
    h = 1.0 + 0j
    loop = cyc + [cyc[0]]
    for a, b in zip(loop[:-1], loop[1:]):
        h *= M[a, b] / abs(M[a, b])
    return h


def K4():
    res = []
    for trial in range(60):
        d = int(rng.integers(4, 8))
        M, edges = sparse_state(d, 0.6)
        tree, cycles, comps, parent = cycle_basis(d, edges)
        b1 = len(edges) - d + comps
        # incidence rank = removable phases
        Bm = np.zeros((len(edges), d))
        for e, (i, j) in enumerate(edges):
            Bm[e, i] = 1; Bm[e, j] = -1
        rank = int(np.linalg.matrix_rank(Bm)) if edges else 0
        # gauge invariance of invariants
        D = np.diag(np.exp(1j * rng.uniform(-np.pi, np.pi, d)))
        S = D @ M @ D.conj().T
        inv_err = max([abs(holonomy(M, c) - holonomy(S, c)) for c in cycles] + [np.max(np.abs(np.abs(M) - np.abs(S)))])
        # reconstruction of the gauge from invariants (spanning tree)
        th = np.zeros(d)
        order = [v for v in parent if parent[v] is None]
        for (u, v) in tree:
            th[v] = th[u] + np.angle(M[u, v]) - np.angle(S[u, v])
        # tree edges fix e^{i(th_u - th_v)} M_uv = S_uv
        Dr = np.diag(np.exp(1j * th))
        rec_err = float(np.max(np.abs(Dr @ M @ Dr.conj().T - S)))
        # canary: change one loop phase on a non-tree edge
        canary = None
        if cycles:
            c0 = cycles[0]; i, j = c0[-1], c0[0]
            T = M.copy(); T[i, j] *= np.exp(0.7j); T[j, i] = np.conj(T[i, j])
            canary = abs(holonomy(T, c0) - holonomy(M, c0))
        res.append(dict(d=d, edges=len(edges), b1=b1, removable=rank, comps=comps, inv_err=inv_err, rec_err=rec_err, canary=canary))
    ok = all(r['removable'] == r['d'] - r['comps'] and r['inv_err'] < 1e-12 and r['rec_err'] < 1e-12 for r in res) \
        and all(r['canary'] > 0.1 for r in res if r['canary'] is not None) and any(r['b1'] >= 3 for r in res)
    # real: Z2 holonomy = sign of the cycle product
    rr = np.array([[1, .1, -.1], [.1, 1, .1], [-.1, .1, 1]]) / 3
    zsign = np.sign(rr[0, 1] * rr[1, 2] * rr[2, 0])
    sg = np.diag([1, -1, -1])
    zsign2 = np.sign((sg @ rr @ sg)[0, 1] * (sg @ rr @ sg)[1, 2] * (sg @ rr @ sg)[2, 0])
    # quaternionic: holonomy defined up to conjugation
    rq = qrand_rho(3)
    blk = lambda M, i, j: M[2 * i:2 * i + 2, 2 * j:2 * j + 2]
    def qhol(M, cyc):
        H = np.eye(2, dtype=complex)
        loop = cyc + [cyc[0]]
        for a, b in zip(loop[:-1], loop[1:]):
            q = blk(M, a, b); H = H @ (q / np.sqrt(abs(np.linalg.det(q))))
        return H
    D = np.zeros((6, 6), complex)
    for i in range(3):
        v = rng.normal(size=4); v /= np.linalg.norm(v)
        D[2 * i:2 * i + 2, 2 * i:2 * i + 2] = np.array([[v[0] + 1j * v[1], v[2] + 1j * v[3]], [-v[2] + 1j * v[3], v[0] - 1j * v[1]]])
    rq2 = D @ rq @ D.conj().T
    H1, H2 = qhol(rq, [0, 1, 2]), qhol(rq2, [0, 1, 2])
    trace_inv = abs(np.trace(H1) - np.trace(H2))
    matrix_changed = np.max(np.abs(H1 - H2))
    Hb = qhol(rq, [1, 2, 0])
    base_point = abs(np.trace(H1) - np.trace(Hb))
    nonabelian = np.max(np.abs(qhol(rq, [0, 1, 2]) @ qhol(rq, [0, 2, 1]) - qhol(rq, [0, 2, 1]) @ qhol(rq, [0, 1, 2])))
    rq4 = qrand_rho(4)
    na2 = np.max(np.abs(qhol(rq4, [0, 1, 2]) @ qhol(rq4, [0, 1, 3]) - qhol(rq4, [0, 1, 3]) @ qhol(rq4, [0, 1, 2])))
    ok = ok and zsign == zsign2 and trace_inv < 1e-12 and matrix_changed > 1e-3 and base_point < 1e-12 and na2 > 1e-3
    must(ok, 'K4')
    R['K4'] = dict(claim='Relative to a frame, coherence is a connection on the support graph: off-diagonal phases transform as '
                         'e^{i(th_i - th_j)}. Gauge classes are exactly (populations, magnitudes, support graph, holonomy on a cycle '
                         'basis): removable phases = |V| - c, invariant loop phases b1 = |E| - |V| + c; equal invariants => explicit '
                         'gauge reconstruction; changing one loop phase gives an inequivalent state. Real: Z2 holonomy (sign); '
                         'quaternionic: non-abelian Sp(1) holonomy, gauge-invariant only through its conjugacy class (trace)',
                   status='CONSTRUCTED (60 random sparse states, exact)', trials=len(res), max_b1=max(r['b1'] for r in res),
                   max_invariant_error=fl(max(r['inv_err'] for r in res)), max_reconstruction_error=fl(max(r['rec_err'] for r in res)),
                   min_canary_shift=fl(min(r['canary'] for r in res if r['canary'] is not None)),
                   quaternion=dict(trace_invariance=fl(trace_inv), holonomy_matrix_changes=fl(matrix_changed),
                                   noncommuting_cycles=fl(na2)))


# ------------------------------------------------------------------ K5
def K5():
    out = {}
    for name, th in [('0', 0.0), ('pi/2', np.pi / 2), ('pi', np.pi)]:
        lo, hi = 0.0, 0.5
        for _ in range(80):
            c = (lo + hi) / 2
            M = np.eye(3, dtype=complex) / 3
            M[0, 1] = M[1, 2] = c; M[2, 0] = c * np.exp(1j * th)
            M[1, 0], M[2, 1], M[0, 2] = c, c, c * np.exp(-1j * th)
            if np.linalg.eigvalsh(M).min() >= 0:
                lo = c
            else:
                hi = c
        pred = 1 / (6 * max(-np.cos((th + 2 * np.pi * k) / 3) for k in range(3)))
        out[name] = dict(c_max=fl(lo), predicted=fl(pred))
    ok = all(abs(v['c_max'] - v['predicted']) < 1e-12 for v in out.values()) and abs(out['0']['c_max'] - 1 / 3) < 1e-12 \
        and abs(out['pi']['c_max'] - 1 / 6) < 1e-12
    must(ok, 'K5')
    R['K5'] = dict(claim='Holonomy is physical, not a gauge artefact: for equal populations and equal pair magnitudes c, positivity '
                         'allows c <= 1/(6 max_k(-cos((Theta + 2 pi k)/3))): 1/3 at Theta = 0, 1/(3 sqrt 3) at pi/2, 1/6 at pi',
                   status='CONSTRUCTED (exact formula + bisection)', c_max=out)


# ------------------------------------------------------------------ K6
def K6():
    agree, order, monotone, gap = 0.0, 0, {k: -1e9 for k in FS}, []
    for _ in range(300):
        d = 3; rho = rand_rho(d); lam, U = np.linalg.eigh(rho)
        Xd = U @ np.diag(np.r_[rng.normal(size=d - 1), 0]) @ U.conj().T
        Xd -= np.trace(Xd).real / d * np.eye(d)
        fisher = sum((U.conj().T @ Xd @ U)[i, i].real ** 2 / lam[i] for i in range(d))
        vals = [petz(rho, Xd, f) for f in FS.values()]
        agree = max(agree, max(abs(v - fisher) / fisher for v in vals))
        Xo = U @ (lambda A: A - np.diag(np.diag(A)))(rand_herm0(d)) @ U.conj().T
        vo = [petz(rho, Xo, FS[k]) for k in ['SLD', 'WY', 'BKM', 'max']]
        order += int(all(vo[i] <= vo[i + 1] * (1 + 1e-12) for i in range(3)))
        gap.append(vo[3] / vo[0])
        X = rand_herm0(d)
        do = int(rng.integers(2, 4)); Ks = rand_channel(d, do, int(rng.integers(-(-d // do), 4)))
        for k, f in FS.items():
            a = petz(rho, X, f); b = petz(apply(Ks, rho), apply(Ks, X), f)
            monotone[k] = max(monotone[k], (b - a) / a)
    # partial-trace monotonicity on extreme spectra
    for _ in range(300):
        dA, dB = 2, int(rng.integers(2, 4)); n = dA * dB
        lam = rng.dirichlet(np.ones(n) * 0.3) + 1e-6; lam /= lam.sum()
        Uq, _ = np.linalg.qr(rng.normal(size=(n, n)) + 1j * rng.normal(size=(n, n)))
        rho = (Uq * lam) @ Uq.conj().T; X = rand_herm0(n)
        pt = lambda M: np.trace(M.reshape(dA, dB, dA, dB), axis1=1, axis2=3)
        for k, f in FS.items():
            a = petz(rho, X, f); b = petz(pt(rho), pt(X), f)
            monotone[k] = max(monotone[k], (b - a) / a)
    # canary: Hilbert-Schmidt metric is not monotone (partial trace of A (x) I/dB)
    A = rand_herm0(2); Xc = np.kron(A, np.eye(3) / 3)
    hs_increase = np.trace(A @ A).real / np.trace(Xc @ Xc).real
    ok = agree < 1e-10 and order == 300 and all(v < 1e-9 for v in monotone.values()) and hs_increase > 2.9 and max(gap) > 2
    must(ok, 'K6')
    R['K6'] = dict(claim='All monotone (Morozova-Cencov-Petz) metrics coincide with the Fisher metric on population (commuting) '
                         'directions and differ on coherence directions, ordered SLD <= WY <= BKM <= max (ratio max/SLD up to %.1f in '
                         'the sample). Each is monotone under random channels and partial traces; the Hilbert-Schmidt metric is not '
                         '(it grows by dB under partial trace). Cencov uniqueness fails exactly on coherence' % max(gap),
                   status='CONSTRUCTED (Petz classification imported; 600 channel checks)', max_population_disagreement=fl(agree),
                   ordering_ok=order, max_relative_increase={k: fl(v) for k, v in monotone.items()}, hs_canary_growth=fl(hs_increase),
                   max_over_sld_ratio=fl(max(gap)))


# ------------------------------------------------------------------ K7
def K7():
    attain, exceed, strict = 0.0, -1e9, []
    for _ in range(200):
        d = int(rng.integers(2, 5)); rho = rand_rho(d); X = rand_herm0(d)
        lam, U = np.linalg.eigh(rho); Xe = U.conj().T @ X @ U
        Le = 2 * Xe / (lam[:, None] + lam[None, :]); L = U @ Le @ U.conj().T
        Fq = petz(rho, X, FS['SLD'])
        w, V = np.linalg.eigh(herm(L))
        povm = [np.outer(V[:, k], V[:, k].conj()) for k in range(d)]
        attain = max(attain, abs(classical_fisher(rho, X, povm) - Fq) / Fq)
        for _ in range(10):
            exceed = max(exceed, (classical_fisher(rho, X, rand_povm(d, int(rng.integers(d, 2 * d + 2)))) - Fq) / Fq)
        Xo = U @ (Xe - np.diag(np.diag(Xe))) @ U.conj().T
        strict.append(min(petz(rho, Xo, FS[k]) / petz(rho, Xo, FS['SLD']) for k in ['WY', 'BKM', 'max']))
    ok = attain < 1e-9 and exceed < 1e-9 and min(strict) > 1 + 1e-6
    must(ok, 'K7')
    R['K7'] = dict(claim='The record Fisher information of the SLD-eigenbasis measurement equals the SLD metric, and 2000 random POVMs '
                         'never exceed it (Braunstein-Caves). On coherence directions WY, BKM and max are strictly larger, so no '
                         'protocol attains them. The resolution task (sup over protocols of record Fisher) selects the SLD metric, '
                         'the smallest monotone one (Stein and Chernoff tasks select BKM and WY instead)',
                   status='CONSTRUCTED (theorem imported; executed)', max_attainment_gap=fl(attain), max_povm_excess=fl(exceed),
                   min_ratio_other_over_SLD_on_coherence=fl(min(strict)))


# ------------------------------------------------------------------ K8
def sld_matrix(rho, Xs):
    lam, U = np.linalg.eigh(rho)
    Ls = []
    for X in Xs:
        Xe = U.conj().T @ X @ U
        Ls.append(U @ (2 * Xe / (lam[:, None] + lam[None, :])) @ U.conj().T)
    F = np.array([[np.trace(rho @ (Li @ Lj + Lj @ Li) / 2).real for Lj in Ls] for Li in Ls])
    Uc = np.array([[np.trace(rho @ (Li @ Lj - Lj @ Li)).imag / 4 for Lj in Ls] for Li in Ls])
    return F, Uc


def K8():
    # Berry curvature on CP^1 and Chern number
    n = 400
    th = (np.arange(n) + 0.5) * np.pi / n; dth = np.pi / n; dph = 2 * np.pi / n
    def psi(t, p):
        return np.array([np.cos(t / 2), np.exp(1j * p) * np.sin(t / 2)])
    def dpsi_t(t, p):
        return np.array([-np.sin(t / 2) / 2, np.exp(1j * p) * np.cos(t / 2) / 2])
    def dpsi_p(t, p):
        return np.array([0, 1j * np.exp(1j * p) * np.sin(t / 2)])
    total = 0.0
    for t in th:
        p = 0.3
        s, a, b = psi(t, p), dpsi_t(t, p), dpsi_p(t, p)
        Q = np.vdot(a, b) - np.vdot(a, s) * np.vdot(s, b)
        total += -2 * Q.imag * dth * dph * n            # phi-independent
    chern = total / (2 * np.pi)
    # mean Uhlmann curvature: coherent two-parameter family vs commuting family
    Xg = np.array([[0, 1], [1, 0]], complex) / 2; Yg = np.array([[0, -1j], [1j, 0]]) / 2
    coh, com = [], []
    for _ in range(100):
        r = rng.uniform(0.2, 0.95); rho = bloch([0, 0, r])
        Xs = [-1j * (Xg @ rho - rho @ Xg), -1j * (Yg @ rho - rho @ Yg)]
        F, Uc = sld_matrix(rho, Xs); coh.append(abs(Uc[0, 1]))
        lam = rng.dirichlet(np.ones(3)); rho3 = np.diag(lam).astype(complex)
        Xs3 = [np.diag([1, -1, 0]).astype(complex), np.diag([0, 1, -1]).astype(complex)]
        F3, U3 = sld_matrix(rho3, Xs3); com.append(abs(U3[0, 1]))
    # Gill-Massar: Tr(F_Q^-1 F_C) <= d - 1 for any measurement
    gm_q, gm_c = 0.0, 0.0
    for _ in range(200):
        r = rng.uniform(0.3, 0.95); rho = bloch([0, 0, r])
        Xs = [-1j * (Xg @ rho - rho @ Xg), -1j * (Yg @ rho - rho @ Yg)]
        Fq, _ = sld_matrix(rho, Xs)
        P = rand_povm(2, int(rng.integers(2, 6)))
        Fc = np.array([[sum(np.trace(E @ Xi).real * np.trace(E @ Xj).real / max(np.trace(E @ rho).real, 1e-15) for E in P)
                        for Xj in Xs] for Xi in Xs])
        gm_q = max(gm_q, np.trace(np.linalg.solve(Fq, Fc)))
    # commuting family in d = 3 attains 2 = d - 1 with the reference measurement
    lam = np.array([0.5, 0.3, 0.2]); rho3 = np.diag(lam).astype(complex)
    Xs3 = [np.diag([1, -1, 0]).astype(complex), np.diag([0, 1, -1]).astype(complex)]
    Fq3, _ = sld_matrix(rho3, Xs3)
    P3 = [np.diag(np.eye(3)[k]).astype(complex) for k in range(3)]
    Fc3 = np.array([[sum(np.trace(E @ Xi).real * np.trace(E @ Xj).real / np.trace(E @ rho3).real for E in P3) for Xj in Xs3] for Xi in Xs3])
    gm_c = np.trace(np.linalg.solve(Fq3, Fc3))
    # toric structure: populations are the moment map of the frame torus; fixed-population pure fibres are Lagrangian
    lag, pair = 0.0, []
    for _ in range(100):
        pv = rng.dirichlet(np.ones(3)); th3 = rng.uniform(-np.pi, np.pi, 3)
        ps = np.sqrt(pv) * np.exp(1j * th3)
        dth = [1j * np.sqrt(pv[j]) * np.exp(1j * th3[j]) * np.eye(3)[j] for j in range(3)]
        dp = []
        for i in range(2):                    # independent populations p1, p2 with p3 = 1 - p1 - p2
            v = np.zeros(3, complex)
            v[i] = np.exp(1j * th3[i]) / (2 * np.sqrt(pv[i])); v[2] = -np.exp(1j * th3[2]) / (2 * np.sqrt(pv[2]))
            dp.append(v)
        Qf = lambda a, b: np.vdot(a, b) - np.vdot(a, ps) * np.vdot(ps, b)
        lag = max(lag, max(abs(Qf(dth[a], dth[b]).imag) for a in range(3) for b in range(3)))
        W = np.array([[Qf(dp[i], dth[j]).imag for j in range(2)] for i in range(2)])
        pair.append(np.max(np.abs(W - 0.5 * np.eye(2))))
    ok = lag < 1e-15 and max(pair) < 1e-12 and abs(abs(chern) - 1) < 1e-4 and min(coh) > 1e-3 and max(com) < 1e-15 and gm_q <= 1 + 1e-9 and abs(gm_c - 2) < 1e-12
    must(ok, 'K8')
    R['K8'] = dict(claim='Toric identification: populations are the moment map of the frame torus on the pure stratum (image = simplex), '
                         'so fixed-population pure fibres are Lagrangian tori (omega pulls back to 0) and omega pairs populations with '
                         'phases, Im Q(d p_i, d theta_j) = delta_ij / 2 (action-angle). The curvature therefore lives on the total space, '
                         'not on a fibre. Coherence geometry carries curvature: the Berry curvature of the pure qubit stratum integrates to 2 pi C with '
                         '|C| = 1 (sign = orientation convention); the mean Uhlmann curvature Tr(rho [L1, L2])/4 is nonzero on coherent two-parameter '
                         'families and identically zero on commuting (population) families. Joint resolution is obstructed: on a qubit '
                         'Tr(F_Q^-1 F_C) <= 1 for every POVM (Gill-Massar), while a commuting family attains d - 1 = 2',
                   status='CONSTRUCTED (numerical integration, exact families; Gill-Massar, Atiyah-Guillemin-Sternberg imported)', chern=fl(chern),
                   max_omega_on_fibre=fl(lag), max_action_angle_error=fl(max(pair)),
                   min_uhlmann_coherent=fl(min(coh)), max_uhlmann_commuting=fl(max(com)), max_gill_massar_qubit=fl(gm_q),
                   commuting_family_attains=fl(gm_c))


# ------------------------------------------------------------------ K9
def K9():
    errs = []
    for _ in range(200):
        d = 3
        psi = rng.normal(size=d) + 1j * rng.normal(size=d); psi /= np.linalg.norm(psi)
        def hor():
            v = rng.normal(size=d) + 1j * rng.normal(size=d); return v - np.vdot(psi, v) * psi
        u, v = hor(), hor()
        g = lambda a, b: np.vdot(a, b).real
        w = lambda a, b: np.vdot(a, b).imag
        J = lambda a: 1j * a
        A = rng.normal(size=(d, d)) + 1j * rng.normal(size=(d, d)); H = herm(A)
        EH = np.vdot(psi, H @ psi).real
        vH = -1j * (H @ psi - EH * psi)
        dE = 2 * np.vdot(H @ psi, u).real               # d<H>(u) for horizontal u
        errs.append(max(abs(g(J(u), J(v)) - g(u, v)), abs(w(u, v) - g(J(u), v)), np.max(np.abs(J(J(u)) + u)),
                        abs(np.vdot(psi, J(u))), abs(2 * w(vH, u) - dE)))
    must(max(errs) < 1e-12, 'K9')
    R['K9'] = dict(claim='On the pure stratum the coherence geometry is Kahler: g = Re<.,.>, omega = Im<.,.>, J = i on horizontal '
                         'vectors, g(Ju,Jv) = g(u,v), omega(u,v) = g(Ju,v), J^2 = -1; the Schrodinger velocity -i(H - <H>)psi is the '
                         'Hamiltonian vector field of <H>: 2 omega(v_H, u) = d<H>(u). Uncertainty (Fisher) geometry of a simplex has no '
                         'such compatible structure', status='CONSTRUCTED (algebraic identities on 200 random points; Kahler property of '
                         'Fubini-Study imported)', max_error=fl(max(errs)))


# ------------------------------------------------------------------ K10
def rel_coh(M):
    return c_rel(M)


def K10():
    d = 3
    worst, made = -1e9, []
    for _ in range(300):
        kind = rng.integers(0, 3)
        if kind == 0:     # SIO: permutation x diagonal Kraus
            w = rng.dirichlet(np.ones(4), size=d).T
            Ks = [np.eye(d)[:, rng.permutation(d)] @ np.diag(np.sqrt(w[k]) * np.exp(1j * rng.uniform(-np.pi, np.pi, d))) for k in range(4)]
            Phi = lambda M, Ks=Ks: apply(Ks, M)
        elif kind == 1:   # classical stochastic map after dephasing
            T = rng.dirichlet(np.ones(d), size=d).T
            Phi = lambda M, T=T: np.diag(T @ np.diag(M).real).astype(complex)
        else:             # mixture of the two
            w = rng.dirichlet(np.ones(4), size=d).T
            Ks = [np.eye(d)[:, rng.permutation(d)] @ np.diag(np.sqrt(w[k])) for k in range(4)]
            T = rng.dirichlet(np.ones(d), size=d).T; p = rng.uniform()
            Phi = lambda M, Ks=Ks, T=T, p=p: p * apply(Ks, M) + (1 - p) * np.diag(T @ np.diag(M).real).astype(complex)
        # MIO check: maps incoherent to incoherent
        sig = np.diag(rng.dirichlet(np.ones(d))).astype(complex)
        made.append(l1(Phi(sig)))
        for _ in range(5):
            rho = rand_rho(d)
            worst = max(worst, rel_coh(Phi(rho)) - rel_coh(rho))
    # canary: a Haar unitary creates coherence from an incoherent state
    A = rng.normal(size=(d, d)) + 1j * rng.normal(size=(d, d)); Uh, _ = np.linalg.qr(A)
    sig = np.diag([1, 0, 0]).astype(complex)
    created = rel_coh(Uh @ sig @ Uh.conj().T)
    ok = worst < 1e-10 and max(made) < 1e-13 and created > 0.1
    must(ok, 'K10')
    R['K10'] = dict(claim='C_r(rho) = S(Delta rho) - S(rho) = min_{sigma incoherent} D(rho||sigma) is non-increasing under a channel for '
                          'all inputs iff the channel maps incoherent states to incoherent states (MIO): sufficiency by data processing, '
                          'necessity because an incoherent input with coherent output raises C_r from 0. Morphisms of coherence '
                          'geometry = channels that create no coherence from the reference section',
                    status='PROVED (data processing) + 1500 checks + canary', max_increase=fl(worst), max_created_by_MIO=fl(max(made)),
                    unitary_canary_created=fl(created))


# ------------------------------------------------------------------ K11
def orbit_qfi(rho, H):
    return petz(rho, -1j * (H @ rho - rho @ H), FS['SLD'])


def K11():
    h = np.array([0., 1., 2.]); H = np.diag(h).astype(complex)
    zero_incoh = max(orbit_qfi(np.diag(rng.dirichlet(np.ones(3))).astype(complex), H) for _ in range(50))
    pos = min(orbit_qfi(rand_rho(3), H) for _ in range(50))
    psi = rng.normal(size=3) + 1j * rng.normal(size=3); psi /= np.linalg.norm(psi); P = np.outer(psi, psi.conj())
    var = np.vdot(psi, H @ H @ psi).real - np.vdot(psi, H @ psi).real ** 2
    pure = abs(orbit_qfi(P * (1 - 1e-9) + np.eye(3) * 1e-9 / 3, H) - 4 * var)
    # monotone under covariant channels (twirl of random channels over e^{-iHt}, exact with m = 5 phases)
    worst = -1e9
    for _ in range(100):
        Ks = rand_channel(3, 3, 2)
        def cov(M, Ks=Ks):
            out = np.zeros((3, 3), complex)
            for k in range(5):
                Ut = np.diag(np.exp(-1j * h * 2 * np.pi * k / 5))
                out += Ut.conj().T @ apply(Ks, Ut @ M @ Ut.conj().T) @ Ut
            return out / 5
        rho = rand_rho(3)
        worst = max(worst, orbit_qfi(cov(rho), H) - orbit_qfi(rho, H))
    # degenerate reference canary: coherence inside a degenerate block is invisible to the orbit
    Hd = np.diag([1., 1., 2.]).astype(complex)
    v = np.array([1, 1, 0], complex) / np.sqrt(2); Pd = np.outer(v, v.conj()) * (1 - 1e-6) + np.eye(3) * 1e-6 / 3
    deg = dict(orbit_qfi=fl(orbit_qfi(Pd, Hd)), c_rel=fl(c_rel(Pd)))
    ok = zero_incoh < 1e-14 and pos > 1e-6 and pure < 1e-5 and worst < 1e-9 and deg['orbit_qfi'] < 1e-12 and deg['c_rel'] > 0.9
    must(ok, 'K11')
    R['K11'] = dict(claim='RG reading: coherence is the resolvability of the reference group orbit. For a nondegenerate reference '
                          'generator H, the orbit QFI sum 2(l_k - l_l)^2/(l_k + l_l)|H_kl|^2 vanishes iff rho is incoherent, equals '
                          '4 Var(H) on pure states, and is monotone under covariant channels. Canary: a degenerate reference cannot '
                          'see coherence inside its degenerate block', status='CONSTRUCTED (exact + 100 covariant channels)',
                    max_incoherent=fl(zero_incoh), min_coherent=fl(pos), pure_state_4var_error=fl(pure), max_covariant_increase=fl(worst),
                    degenerate_canary=deg)


# ------------------------------------------------------------------ K12
def K12():
    d = 4
    eig, mub, rnd = [], [], []
    F = np.exp(2j * np.pi * np.outer(np.arange(d), np.arange(d)) / d) / np.sqrt(d)
    for _ in range(50):
        rho = rand_rho(d); lam, U = np.linalg.eigh(rho)
        eig.append(c_rel(U.conj().T @ rho @ U))
        psi = rng.normal(size=d) + 1j * rng.normal(size=d); psi /= np.linalg.norm(psi)
        Ub, _ = np.linalg.qr(np.column_stack([psi] + [rng.normal(size=d) + 1j * rng.normal(size=d) for _ in range(d - 1)]))
        P = np.outer(psi, psi.conj())
        frame = Ub @ F                    # psi is the first column of Ub, unbiased w.r.t. columns of Ub F
        mub.append(c_rel(frame.conj().T @ P @ frame))
        A = rng.normal(size=(d, d)) + 1j * rng.normal(size=(d, d)); Q, _ = np.linalg.qr(A)
        rnd.append(c_rel(Q.conj().T @ P @ Q))
    ok = max(eig) < 1e-10 and max(abs(np.array(mub) - np.log2(d))) < 1e-10 and max(rnd) <= np.log2(d) + 1e-10
    must(ok, 'K12')
    R['K12'] = dict(claim='Coherence is relative: every state is incoherent in its own eigenframe (spectral theorem), and a pure state '
                          'reaches the maximum C_r = log2 d in a frame unbiased to it. There is no frame-free coherence; the geometry is '
                          'a geometry of (state, frame) pairs', status='CONSTRUCTED', max_eigenframe=fl(max(eig)),
                    unbiased_value=fl(np.mean(mub)), max_random_frame=fl(max(rnd)))


# ------------------------------------------------------------------ K13
def K13():
    K = lambda k, d: d + k * d * (d - 1) // 2
    res = {}
    for k, name in [(0, 'classical'), (1, 'real'), (2, 'complex'), (4, 'quaternionic')]:
        res[name] = all(K(k, a * b) == K(k, a) * K(k, b) for a in range(2, 7) for b in range(2, 7))
        res[name + '_2x2'] = [K(k, 4), K(k, 2) ** 2]
    # subspace-equivalent rank-4 composite of two rank-2 cones of the same type: 4 + 6k = (2 + k)^2  <=>  k in {0, 2}
    roots = [k for k in range(0, 9) if 4 + 6 * k == (2 + k) ** 2]
    must(res['classical'] and res['complex'] and not res['real'] and not res['quaternionic'] and roots == [0, 2], 'K13')
    R['K13'] = dict(claim='Structure-group destructor (conditional on tensor-product composition): local tomography K_AB = K_A K_B holds '
                          'in all dimensions for the classical simplex (k = 0) and, among non-simplicial matrix cones, only for complex '
                          '(k = 2, U(1) holonomy); real (Z2) has too many joint parameters (10 vs 9), quaternionic (Sp(1)) too few '
                          '(28 vs 36); for same-type composites 4 + 6k = (2 + k)^2 forces k in {0, 2}. Composition does NOT supply '
                          'non-simpliciality; that must come from elsewhere. A real formulation with a modified composition rule can '
                          'reproduce complex predictions, so the lock is relative to the declared composition',
                    status='DESTRUCTOR (exact counting) + data (network tests of real QM, imported)', result=res, same_type_roots=roots)


# ------------------------------------------------------------------ K14
def K14():
    # classical partially coherent 3-mode field: random complex amplitudes with a declared coherency matrix J
    J = np.array([[0.4, 0.1, 0.05 * np.exp(-0.9j)], [0.1, 0.35, 0.1], [0.05 * np.exp(0.9j), 0.1, 0.25]])
    Lc = np.linalg.cholesky(J)
    n = 200000
    E = Lc @ ((rng.normal(size=(3, n)) + 1j * rng.normal(size=(3, n))) / np.sqrt(2))
    Jhat = (E @ E.conj().T) / n
    hol = np.angle(J[0, 1] * J[1, 2] * J[2, 0]); holhat = np.angle(Jhat[0, 1] * Jhat[1, 2] * Jhat[2, 0])
    v = np.array([1, 1j, 0]) / np.sqrt(2)
    inten = np.mean(np.abs(v.conj() @ E) ** 2); born = np.real(v.conj() @ J @ v)
    ok = np.max(np.abs(Jhat - J)) < 0.01 and abs(hol - holhat) < 0.1 and abs(inten - born) < 0.01
    must(ok, 'K14')
    R['K14'] = dict(claim='Realization canary: a classical partially coherent 3-mode wave field (no quantum ontology) realizes a '
                          'coherency matrix with the same populations, quadratures and loop holonomy, and analyser intensities follow '
                          'v^dag J v. Coherence geometry is a property of the record cone; quantum-specific content enters through '
                          'composition (K13), not through single-system coherence',
                    status='EXECUTED (200000 samples)', max_matrix_error=fl(np.max(np.abs(Jhat - J))), holonomy=fl(hol),
                    holonomy_estimate=fl(holhat), intensity=fl(inten), predicted=fl(born))


# ------------------------------------------------------------------ K15
def K15():
    # bundle structure: base = population simplex (Delta), fibre = coherence compatible with p
    minors, pure_sat = -1.0, 0.0
    for _ in range(300):
        d = int(rng.integers(2, 6)); rho = rand_rho(d)
        P = np.abs(rho) ** 2 - np.outer(np.diag(rho).real, np.diag(rho).real)
        minors = max(minors, float(np.max(P[~np.eye(d, dtype=bool)])))
        psi = rng.normal(size=d) + 1j * rng.normal(size=d); psi /= np.linalg.norm(psi); Pp = np.outer(psi, psi.conj())
        pure_sat = max(pure_sat, float(np.max(np.abs(np.abs(Pp) ** 2 - np.outer(np.diag(Pp).real, np.diag(Pp).real)))))
    # fibre collapse at the boundary of the simplex: p_0 = 0 forces row/column 0 to vanish
    p = np.array([0.0, 0.5, 0.5]); M = np.diag(p).astype(complex); M[0, 1] = M[1, 0] = 1e-3
    collapse = float(np.linalg.eigvalsh(M).min())
    # at incoherent states every Petz metric splits orthogonally: Fisher (base) + sum c_f(p_i,p_j)|X_ij|^2 (fibre)
    split, mixed = 0.0, []
    for _ in range(200):
        d = 3; pv = rng.dirichlet(np.ones(d)); rho = np.diag(pv).astype(complex)
        Xp = np.diag(np.r_[rng.normal(size=d - 1), 0]).astype(complex); Xp -= np.trace(Xp) / d * np.eye(d)
        Xc = rand_herm0(d); Xc -= np.diag(np.diag(Xc))
        for f in FS.values():
            whole = petz(rho, Xp + Xc, f)
            base = sum(Xp[i, i].real ** 2 / pv[i] for i in range(d))
            fib = sum(abs(Xc[i, j]) ** 2 / (pv[j] * f(pv[i] / pv[j])) for i in range(d) for j in range(d) if i != j)
            split = max(split, abs(whole - base - fib) / whole)
        rc = rand_rho(d)
        cross = petz(rc, Xp + Xc, FS['SLD']) - petz(rc, Xp, FS['SLD']) - petz(rc, Xc, FS['SLD'])
        mixed.append(abs(cross) / petz(rc, Xp + Xc, FS['SLD']))
    ok = minors <= 1e-15 and pure_sat < 1e-14 and collapse < 0 and split < 1e-12 and max(mixed) > 1e-3
    must(ok, 'K15')
    R['K15'] = dict(claim='Bundle form: dephasing Delta projects states onto the population simplex (base, Fisher = uncertainty '
                          'geometry); the fibre over p is the set of coherences with |rho_ij|^2 <= p_i p_j (saturated by pure states), '
                          'collapsing where p_i = 0 (stratified walls). At incoherent states every monotone metric splits orthogonally '
                          'into base Fisher plus fibre coefficients c_f(p_i, p_j); away from the zero section base and fibre mix',
                    status='CONSTRUCTED', max_minor_violation=fl(minors), max_pure_saturation_error=fl(pure_sat),
                    boundary_collapse_min_eig=fl(collapse), max_split_error=fl(split), max_mixing_at_coherent_states=fl(max(mixed)))


if __name__ == '__main__':
    for f in [K1, K2, K3, K4, K5, K6, K7, K8, K9, K10, K11, K12, K13, K14, K15]:
        f(); print(f.__name__, flush=True)
    R['source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    R['seed'] = SEED
    R['failures'] = FAILS
    (HERE / 'rg_coherence_geometry_results.json').write_text(json.dumps(R, indent=1, sort_keys=True, default=str) + '\n')
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
