import json
from pathlib import Path
import numpy as np

SEED=20260807
rng=np.random.default_rng(SEED)
tol=1e-10
R={"seed":SEED,"tests":{},"verdict":{}}

# A. Toy linearized Einstein bridge: A g = T. Gauge/kernel leaves metric non-identifiable.
A=np.array([[1.,0.,1.,0.,0.,0.],
            [0.,1.,0.,1.,0.,0.],
            [0.,0.,0.,0.,1.,1.]])
g0=rng.normal(size=6); T=A@g0
u,s,vh=np.linalg.svd(A,full_matrices=True)
rank=np.linalg.matrix_rank(A); N=vh[rank:].T
alpha=rng.normal(size=N.shape[1]); g1=g0+N@alpha
same_source=np.linalg.norm(A@g1-T)
metric_difference=np.linalg.norm(g1-g0)
R["tests"]["stress_tensor_does_not_fix_metric"]={
 "operator_rank":int(rank),"metric_unknowns":6,"kernel_dimension":int(N.shape[1]),
 "same_source_residual":float(same_source),"distinct_metric_norm":float(metric_difference),
 "nonuniqueness_witnessed":bool(same_source<tol and metric_difference>1e-6)}

# B. Vacuum/source-free bridge still permits nontrivial homogeneous geometry.
h=N@rng.normal(size=N.shape[1])
R["tests"]["vacuum_homogeneous_freedom"]={
 "source_norm":float(np.linalg.norm(A@h)),"geometry_norm":float(np.linalg.norm(h)),
 "witnessed":bool(np.linalg.norm(A@h)<tol and np.linalg.norm(h)>1e-6)}

# C. Proper-time observations y=Dg: rank-deficient path design does not identify metric.
D=rng.normal(size=(3,6)); y=D@g0
_,_,vhD=np.linalg.svd(D,full_matrices=True); ND=vhD[np.linalg.matrix_rank(D):].T
g2=g0+ND@rng.normal(size=ND.shape[1])
R["tests"]["clock_paths_do_not_fix_metric_without_rank"]={
 "design_rank":int(np.linalg.matrix_rank(D)),"metric_unknowns":6,
 "same_clock_data_residual":float(np.linalg.norm(D@g2-y)),
 "distinct_metric_norm":float(np.linalg.norm(g2-g0)),
 "nonuniqueness_witnessed":bool(np.linalg.norm(D@g2-y)<tol and np.linalg.norm(g2-g0)>1e-6)}

# D. Joint source + clock data may identify geometry when combined design has full rank.
# Search deterministically for enough rows.
Dfull=rng.normal(size=(6,6)); J=np.vstack([A,Dfull]); rJ=np.linalg.matrix_rank(J)
ghat=np.linalg.lstsq(J,np.concatenate([T,Dfull@g0]),rcond=None)[0]
R["tests"]["joint_bridge_conditional_identification"]={
 "joint_rank":int(rJ),"metric_unknowns":6,"reconstruction_error":float(np.linalg.norm(ghat-g0)),
 "identified_in_test":bool(rJ==6 and np.linalg.norm(ghat-g0)<tol)}

# E. Wobs|adm supports multiple scalar clocks unless scalarization semantics are imposed.
Tdur=np.diag([1.,2.,4.])
clocks={"trace":float(np.trace(Tdur)),"mean":float(np.trace(Tdur)/3),
        "max_mode":float(np.max(np.diag(Tdur))),"first_mode":float(Tdur[0,0])}
R["tests"]["duration_scalarization_ambiguity"]={
 "clock_values":clocks,"number_distinct":len(set(clocks.values())),
 "ambiguity_witnessed":len(set(clocks.values()))>1}

# F. Unsigned quadratic duration is reversal invariant and cannot set orientation.
v=rng.normal(size=4); eta=np.diag([-1.,1.,1.,1.])
q1=float(v@eta@v); q2=float((-v)@eta@(-v))
R["tests"]["orientation_no_go"]={"q_v":q1,"q_minus_v":q2,
 "reversal_invariant":bool(abs(q1-q2)<tol)}

# G. Conservation/admissibility gate: arbitrary observable source need not satisfy divergence-free constraint.
# Toy divergence B T = 0.
B=np.array([[1.,-1.,0.],[0.,1.,-1.]])
Tbad=rng.normal(size=3)
# project to kernel(B)
P=np.eye(3)-B.T@np.linalg.pinv(B@B.T)@B
Tgood=P@Tbad
R["tests"]["stress_conservation_gate"]={
 "raw_divergence":float(np.linalg.norm(B@Tbad)),"projected_divergence":float(np.linalg.norm(B@Tgood)),
 "gate_needed":bool(np.linalg.norm(B@Tbad)>1e-6 and np.linalg.norm(B@Tgood)<tol)}

# H. Exact placement ledger.
R["verdict"]={
 "Wobs_adm_is_a_valid_input_layer":True,
 "Wobs_adm_alone_identifies_GR_metric":False,
 "stress_tensor_alone_identifies_GR_metric":False,
 "duration_alone_identifies_time_orientation":False,
 "joint_GR_realization_can_identify_observable_metric_conditionally":R["tests"]["joint_bridge_conditional_identification"]["identified_in_test"],
 "bridge_supported":"Wobs|adm may supply admissible matter/clock observables to a GR realization functor after conservation, gauge, field-equation, boundary/initial-data, path-rank, and scalarization gates.",
 "physical_overreach_undermined":"Neither observable duration nor stress-energy alone forces a unique metric, global time, time orientation, latent dimension, or primitive temporal ontology.",
 "strongest_safe_claim":"GR is a non-faithful realization of admissible observable structure unless the declared competitor class and additional identification data remove homogeneous, gauge, path-design, and scalarization ambiguities."
}

p=Path('/mnt/data/rg_gr_bridge_attack.json'); p.write_text(json.dumps(R,indent=2))
print(json.dumps(R["verdict"],indent=2)); print(p)
