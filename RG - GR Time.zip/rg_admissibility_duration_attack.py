import json
import numpy as np
from pathlib import Path

SEED = 20260807
rng = np.random.default_rng(SEED)
tol = 1e-10
out = {"seed": SEED, "tolerance": tol, "tests": {}, "witnesses": {}, "verdict": {}}

# 1. Quotient invariance: observation map A kills the second latent coordinate.
A = np.array([[1.0, 0.0]])
x = np.array([0.37, -4.0]); y = np.array([0.37, 9.0])
obs_equal = np.allclose(A @ x, A @ y)
bad_latent_duration = float(np.linalg.norm(x) - np.linalg.norm(y))
good_quotient_duration = float(np.linalg.norm(A @ x) - np.linalg.norm(A @ y))
out["tests"]["quotient_invariance"] = {
    "observations_equal": bool(obs_equal),
    "bad_latent_distinction": abs(bad_latent_duration),
    "quotient_distinction": abs(good_quotient_duration),
    "necessity_witnessed": bool(obs_equal and abs(bad_latent_duration) > tol and abs(good_quotient_duration) < tol)
}

# 2. Rank-stability removal: an admissible sector dimension jumps at epsilon=0.
eps = np.logspace(-14, -1, 100)
ranks_exact = [np.linalg.matrix_rank(np.diag([1.0, e]), tol=0.0) for e in eps]
ranks_cut = [np.linalg.matrix_rank(np.diag([1.0, e]), tol=1e-8) for e in eps]
out["tests"]["rank_stability"] = {
    "exact_rank_min": int(min(ranks_exact)), "threshold_rank_min": int(min(ranks_cut)),
    "threshold_rank_max": int(max(ranks_cut)),
    "rank_jump_observed": bool(min(ranks_cut) != max(ranks_cut))
}

# 3. Bounded conditioning: inverse transport amplifies perturbations by ~kappa.
kappas = np.logspace(1, 12, 12)
amplifications = []
for k in kappas:
    T = np.diag([1.0, 1.0/k])
    delta = np.array([0.0, 1e-12])
    amplifications.append(float(np.linalg.norm(np.linalg.solve(T, delta))/np.linalg.norm(delta)))
out["tests"]["bounded_conditioning"] = {
    "max_condition_number": float(kappas[-1]),
    "max_inverse_amplification": max(amplifications),
    "scaling_ratio": float(max(amplifications)/kappas[-1]),
    "unbounded_instability_witnessed": bool(max(amplifications) > 1e11)
}

# 4. Coarse-graining monotonicity: arbitrary metric can increase after forgetting.
# Fine distance is Euclidean; coarse map P has operator norm 2, hence expands.
P = np.array([[2.0, 0.0]])
u = np.array([1.0, 0.0]); v = np.zeros(2)
fine = np.linalg.norm(u-v); coarse = np.linalg.norm(P@(u-v))
out["tests"]["coarse_graining_monotonicity"] = {
    "fine_distance": float(fine), "coarse_distance": float(coarse),
    "expansion_factor": float(coarse/fine),
    "violation_without_axiom": bool(coarse > fine + tol)
}

# 5. Transport composability: direct and composed transports disagree.
T01 = np.array([[1.0, 1.0], [0.0, 1.0]])
T12 = np.array([[1.0, 0.0], [1.0, 1.0]])
T02_bad = T12 @ T01 + np.array([[0.0, 0.1], [0.0, 0.0]])
z = np.array([0.3, -0.7])
defect = np.linalg.norm(T02_bad@z - T12@(T01@z))
out["tests"]["transport_composability"] = {
    "path_defect": float(defect), "gluing_failure_witnessed": bool(defect > tol)
}

# 6. Continuity: discontinuous additive Cauchy maps cannot be numerically constructed,
# but a discontinuous threshold duration explicitly destroys stability (not additivity).
def threshold_duration(c): return 0.0 if c == 1.0 else 1.0
cs = 1.0 - 10.0**(-np.arange(1, 16))
jumps = [abs(threshold_duration(c)-threshold_duration(1.0)) for c in cs]
out["tests"]["continuity"] = {
    "max_input_distance": float(max(abs(cs-1.0))), "min_input_distance": float(min(abs(cs-1.0))),
    "output_jump_near_identity": float(max(jumps)), "instability_witnessed": bool(max(jumps) == 1.0)
}

# 7. Log uniqueness in a finite candidate family under normalization h(e^-1)=1.
samples = rng.uniform(1e-5, 1.0, size=(5000,2))
def norm_candidate(name, x):
    if name == "log": return -np.log(x)
    if name == "log_squared": return (-np.log(x))**2
    if name == "one_minus": return (1-x)/(1-np.exp(-1))
    if name == "sqrt_log": return np.sqrt(-np.log(x))
    raise KeyError(name)
errs = {}
for name in ["log", "log_squared", "one_minus", "sqrt_log"]:
    x,y=samples[:,0],samples[:,1]
    hxy=norm_candidate(name,x*y); hs=norm_candidate(name,x)+norm_candidate(name,y)
    errs[name]=float(np.max(np.abs(hxy-hs)))
out["tests"]["duration_linearization"] = {
    "max_composition_errors": errs,
    "only_log_survives_candidate_family": bool(errs["log"] < tol and all(errs[k] > 1e-3 for k in errs if k != "log"))
}

# 8. Memory/gluing obstruction on a finite interval complex.
# Local edge durations; direct 02 differs by m. Coboundary-zero iff triangle closure.
t01, t12 = 0.8, 1.3
memory_values = [0.0, 0.05, -0.2]
closures=[]
for m in memory_values:
    t02=t01+t12+m
    M=t02-t01-t12
    closures.append({"inserted_memory":m,"measured_obstruction":float(M),"global_additive_gluing":bool(abs(M)<tol)})
out["tests"]["memory_obstruction"] = closures

# 9. Affine clock cocycle reconstruction.
a = rng.uniform(0.2, 3.0, 8); b = rng.normal(size=8)
max_aff=0.0
for i in range(8):
  for j in range(8):
    for k in range(8):
      aij=a[j]/a[i]; bij=b[j]-aij*b[i]
      ajk=a[k]/a[j]; bjk=b[k]-ajk*b[j]
      aik=a[k]/a[i]; bik=b[k]-aik*b[i]
      max_aff=max(max_aff,abs(ajk*aij-aik),abs(ajk*bij+bjk-bik))
out["tests"]["affine_clock_gluing"] = {"max_cocycle_error":float(max_aff),"passes":bool(max_aff<tol)}

# 10. Independence/minimality ledger: each axiom has a finite witness, but this is not
# a proof that the chosen list is globally minimal or initial among all protocols.
keys = ["quotient_invariance","rank_stability","bounded_conditioning","coarse_graining_monotonicity","transport_composability","continuity"]
flags = {
 "quotient_invariance": out["tests"]["quotient_invariance"]["necessity_witnessed"],
 "rank_stability": out["tests"]["rank_stability"]["rank_jump_observed"],
 "bounded_conditioning": out["tests"]["bounded_conditioning"]["unbounded_instability_witnessed"],
 "coarse_graining_monotonicity": out["tests"]["coarse_graining_monotonicity"]["violation_without_axiom"],
 "transport_composability": out["tests"]["transport_composability"]["gluing_failure_witnessed"],
 "continuity": out["tests"]["continuity"]["instability_witnessed"]
}
out["verdict"] = {
    "all_six_axioms_have_independence_witnesses": bool(all(flags.values())),
    "finite_candidate_log_characterization_passes": out["tests"]["duration_linearization"]["only_log_survives_candidate_family"],
    "affine_gluing_passes": out["tests"]["affine_clock_gluing"]["passes"],
    "global_duration_iff_zero_obstruction_in_test_complex": bool(all(r["global_additive_gluing"] == (abs(r["measured_obstruction"])<tol) for r in closures)),
    "universal_protocol_theorem_proved": False,
    "universal_duration_object_theorem_proved": False,
    "supported_claim": "The tested axioms are independently necessary for the corresponding finite target properties; logarithmic duration is selected in the tested continuous candidate family; zero triangle obstruction is equivalent to additive gluing on the tested complex.",
    "remaining_gap": "A universal/initial admissibility protocol requires a precisely defined protocol category and factorization morphisms. Quotient invariance alone cannot force two duration functors to agree; normalization and a separation/completeness axiom are also required."
}

path=Path('/mnt/data/rg_admissibility_duration_attack.json')
path.write_text(json.dumps(out,indent=2))
print(json.dumps(out["verdict"],indent=2))
print(path)
