import json, numpy as np
from pathlib import Path
rng=np.random.default_rng(20260807)

# Semigroup stratum
rates=np.array([0.2,0.5,1.1])
errs=[]
for _ in range(500):
 t1,t2=rng.uniform(0.01,3,2)
 C1=np.diag(np.exp(-rates*t1)); C2=np.diag(np.exp(-rates*t2))
 T1=-np.log(np.diag(C1)); T2=-np.log(np.diag(C2))
 T12=-np.log(np.diag(C2@C1))
 errs.append(np.max(np.abs(T12-(T1+T2))))

# Memory cocycle model
m=rng.normal(0,0.1,1000)
cocycle=np.sqrt(np.mean(m**2))

# Factorization candidates through T
# determinant clock and modal clocks
T=np.diag([1.0,2.0,3.0])
vol=np.trace(T)
modal=max(np.diag(T))

# affine clock atlas consistency
a=[1.2,0.8,2.1]
b=[0.4,-1.1,3.0]
ce=[]
for i in range(3):
 for j in range(3):
  for k in range(3):
   aij=a[j]/a[i]; bij=b[j]-aij*b[i]
   ajk=a[k]/a[j]; bjk=b[k]-ajk*b[j]
   aik=a[k]/a[i]; bik=b[k]-aik*b[i]
   ce.append(max(abs(ajk*aij-aik),abs(ajk*bij+bjk-bik)))

result={
 'semigroup_additivity_max_error':max(errs),
 'memory_obstruction_rms':float(cocycle),
 'factorization_examples':{'volume_clock':vol,'modal_clock':modal},
 'clock_cocycle_max_error':max(ce),
 'verdict':{
   'universal_duration_functor_supported':max(errs)<1e-12,
   'memory_as_gluing_obstruction_supported':cocycle>0,
   'clock_factorization_supported':max(ce)<1e-12
 }
}
Path('/mnt/data/rg_functor_universality_attack.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
