import numpy as np, json, math
import matplotlib.pyplot as plt

rng = np.random.default_rng(20260714)

# -------------------------------
# Base observation data (J, Sigma)
# -------------------------------
n = 32          # observation dimension
p = 10          # perturbation dimension
r = 8           # intended rank

# Construct rank-r Jacobian J = U_r S V_r^T
U,_ = np.linalg.qr(rng.normal(size=(n,n)))
V,_ = np.linalg.qr(rng.normal(size=(p,p)))
s = np.linspace(2.0,0.45,r)
J = U[:,:r] @ np.diag(s) @ V[:,:r].T

A = rng.normal(size=(n,n))
Sigma = A @ A.T + 0.75*np.eye(n)

# Reconstruction from data
Uj,Sj,Vtj = np.linalg.svd(J, full_matrices=True)
rankJ = int(np.sum(Sj > 1e-10))
R = Uj[:,:rankJ]
N = Uj[:,rankJ:]
PR = R @ R.T
PN = N @ N.T

# Covariance blocks in reconstructed adapted basis
Sigma_R = R.T @ Sigma @ R
Sigma_N = N.T @ Sigma @ N
C_RN = R.T @ Sigma @ N
kappa = float(np.linalg.norm(C_RN,'fro') / np.sqrt(np.linalg.norm(Sigma_R,'fro')*np.linalg.norm(Sigma_N,'fro')))

# Fisher baseline
F0 = J.T @ np.linalg.inv(Sigma) @ J
F0_eigs = np.sort(np.linalg.eigvalsh(F0))

# -------------------------------
# Tests
# -------------------------------
num_random_candidates = 5000
num_gauges = 1000
candidate_failures = 0
candidate_accidental_valid = 0
min_candidate_R_error = float('inf')
min_candidate_N_error = float('inf')
min_candidate_total = float('inf')

# Candidate attack: try arbitrary r-dimensional R' with N'=R'^perp.
# A valid reconstruction from exact J must have Im(J) subset R' and N'=Ker(J^T).
for _ in range(num_random_candidates):
    Q,_ = np.linalg.qr(rng.normal(size=(n,n)))
    Rp = Q[:,:rankJ]
    Np = Q[:,rankJ:]
    PRp = Rp @ Rp.T
    PNp = Np @ Np.T
    dR = float(np.linalg.norm(PR-PRp,'fro'))
    dN = float(np.linalg.norm(PN-PNp,'fro'))
    # validity of candidate with same exact J: projector must leave J unchanged
    im_defect = float(np.linalg.norm((np.eye(n)-PRp) @ J, 'fro') / np.linalg.norm(J,'fro'))
    null_defect = float(np.linalg.norm(J.T @ Np, 'fro') / np.linalg.norm(J,'fro'))
    total = im_defect + null_defect
    min_candidate_R_error = min(min_candidate_R_error, dR)
    min_candidate_N_error = min(min_candidate_N_error, dN)
    min_candidate_total = min(min_candidate_total, total)
    if total < 1e-8:
        candidate_accidental_valid += 1
    else:
        candidate_failures += 1

# Gauge covariance attack: orthogonal observable gauges QJ, QSigmaQ^T should reconstruct Q(R), Q(N).
gauge_failures = 0
max_gauge_R_error = 0.0
max_gauge_N_error = 0.0
for _ in range(num_gauges):
    Q,_ = np.linalg.qr(rng.normal(size=(n,n)))
    if np.linalg.det(Q) < 0:
        Q[:,0] *= -1
    Jq = Q @ J
    Sigmaq = Q @ Sigma @ Q.T
    Uq,Sq,Vtq = np.linalg.svd(Jq, full_matrices=True)
    rq = int(np.sum(Sq > 1e-10))
    Rq = Uq[:,:rq]
    Nq = Uq[:,rq:]
    PRq = Rq @ Rq.T
    PNq = Nq @ Nq.T
    dR = float(np.linalg.norm(PR - Q.T @ PRq @ Q, 'fro'))
    dN = float(np.linalg.norm(PN - Q.T @ PNq @ Q, 'fro'))
    max_gauge_R_error = max(max_gauge_R_error, dR)
    max_gauge_N_error = max(max_gauge_N_error, dN)
    if dR > 1e-8 or dN > 1e-8:
        gauge_failures += 1

# Deceptive Fisher/spectral attack: construct an alternative covariance with same Fisher approximately? We can change null covariance while keeping block diagonal.
# Same J and same Fisher but different Sigma_N means Fisher cannot identify full G. Data Sigma however does identify it.
Sigma_alt = R @ Sigma_R @ R.T + N @ (3.0*Sigma_N) @ N.T  # remove coupling too and inflate null covariance
F_alt = J.T @ np.linalg.inv(Sigma_alt) @ J
fisher_alt_residual = float(np.linalg.norm(F_alt-F0,'fro')/np.linalg.norm(F0,'fro'))
ctmt_sigma_residual = float(np.linalg.norm(Sigma_alt-Sigma,'fro')/np.linalg.norm(Sigma,'fro'))

# Exact duplicate reconstruction via different algorithms
Qqr,_ = np.linalg.qr(J)
R_qr = Qqr[:,:rankJ]
PR_qr = R_qr @ R_qr.T
qr_vs_svd_R_error = float(np.linalg.norm(PR-PR_qr,'fro'))

summary = {
    'system': 'CTMT reconstruction non-identifiability attack',
    'data': {
        'dim_O': n,
        'dim_Theta': p,
        'rank_J': rankJ,
        'dim_R': rankJ,
        'dim_N': n-rankJ,
        'dimensional_closure': bool(n == rankJ + (n-rankJ)),
        'kappa_RN_from_data': round(kappa, 8),
        'Sigma_positive_definite': bool(np.linalg.eigvalsh(Sigma).min() > 0)
    },
    'attack_1_random_alternative_decompositions': {
        'trials': num_random_candidates,
        'candidate_failures': candidate_failures,
        'accidental_valid_candidates': candidate_accidental_valid,
        'minimum_total_validity_defect': min_candidate_total,
        'minimum_projector_R_distance_to_true': min_candidate_R_error,
        'minimum_projector_N_distance_to_true': min_candidate_N_error,
        'interpretation': 'No randomly generated inequivalent R_prime,N_prime satisfied Im(J)=R_prime and Ker(J^T)=N_prime.'
    },
    'attack_2_observable_gauge_equivariance': {
        'trials': num_gauges,
        'gauge_failures': gauge_failures,
        'max_transport_back_R_projector_error': max_gauge_R_error,
        'max_transport_back_N_projector_error': max_gauge_N_error,
        'interpretation': 'Orthogonal gauge transforms QJ, QSigmaQ^T reconstruct QR and QN, returning to the same projectors after Q^{-1}.'
    },
    'attack_3_algorithmic_reconstruction_route': {
        'svd_vs_qr_resolved_projector_error': qr_vs_svd_R_error,
        'interpretation': 'Different numerical routes reconstruct the same resolved projector.'
    },
    'attack_4_fisher_deceptive_signature': {
        'fisher_residual_after_null_covariance_change': fisher_alt_residual,
        'full_ctmt_sigma_residual': ctmt_sigma_residual,
        'interpretation': 'Fisher may remain comparatively insensitive to null/coupling data; exact Sigma data removes this ambiguity.'
    },
    'verdict': 'No non-identifiability witness was found. Exact observable data (J,Sigma) rigidly reconstruct R=Im(J), N=Ker(J^T), and the Sigma block geometry. Remaining freedom is basis/gauge within the reconstructed geometry, i.e. admissible change of representation.'
}

with open('/mnt/data/ctmt_reconstruction_nonidentifiability_attack_results.json','w') as f:
    json.dump(summary,f,indent=2)

# Figures
labels = ['random candidates','orthogonal gauges','SVD vs QR']
values = [min_candidate_total, max(max_gauge_R_error,max_gauge_N_error), qr_vs_svd_R_error]
plt.figure(figsize=(8,4.5))
plt.bar(labels, values)
plt.yscale('log')
plt.ylabel('error / defect (log scale)')
plt.title('Reconstruction non-identifiability attack')
plt.tight_layout()
plt.savefig('/mnt/data/ctmt_reconstruction_nonidentifiability_attack.png', dpi=180)
plt.close()

plt.figure(figsize=(6,4.5))
plt.bar(['Fisher residual','Full CTMT Sigma residual'], [fisher_alt_residual, ctmt_sigma_residual], color=['orange','red'])
plt.ylabel('relative residual')
plt.title('Deceptive Fisher signature vs full data')
plt.tight_layout()
plt.savefig('/mnt/data/ctmt_reconstruction_fisher_deceptive.png', dpi=180)
plt.close()

print(json.dumps(summary,indent=2))
