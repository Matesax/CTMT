#!/usr/bin/env python3
"""Mutation suite for rg_units_battery.py.

Each mutation changes one line of the library (or of the battery's reference computation) so that a claim of the
dimensional-closure paper becomes false. It is caught only when the targeted group fails; the battery is run on that
group alone. A survivor is a defect of the battery; a crash is a defect of the suite, not a catch. Runs in temporary
copies.

    python3 -I rg_units_battery_mutations.py [--jobs 2] [--only UA,UB]
"""
import argparse, json, os, shutil, subprocess, sys, tempfile
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
NAME = 'rg_units_battery'
LIB = 'rg_units.py'
BAT = NAME + '.py'
MUTATIONS = [  # (group, description, file, old, new)
    ('UA', 'only the first pi-group returned', LIB, 'for v in M.nullspace():', 'for v in M.nullspace()[:1]:'),
    ('UA', 'rational kernel vectors truncated to integers', LIB, 'w = [int(x * den) for x in v]', 'w = [int(x) for x in v]'),
    ('UB', 'addition accepts unequal dimensions', LIB, 'return a if np.all(a == b) else None', 'return a'),
    ('UB', 'exponential accepts a dimensioned argument', LIB, "return None if a is None or np.any(a != 0) else np.zeros(7)", 'return None if a is None else np.zeros(7)'),
    ('UB', 'power loses the sign of the exponent', LIB, 'return None if a is None else a * e[2]', 'return None if a is None else a * abs(e[2])'),
    ('UB', 'damping rate given the dimension of omega squared', BAT, "'gamma': U.dim(T=-1),\n           'z'", "'gamma': U.dim(T=-2),\n           'z'"),
    ('UC', 'luminous efficacy without its candela', LIB, "'K_cd': dim(J=1, M=-1, L=-2, T=3)", "'K_cd': dim(M=-1, L=-2, T=3)"),
    ('UC', 'anchor rank undercounted by one', LIB, 'r = int(np.sum(s_ > 1e-12)); S = Vt[r:].T', 'r = int(np.sum(s_ > 1e-12)); S = Vt[max(r - 1, 0):].T'),
    ('UD', 'G given the dimension of a rate (T^-1 for T^-2)', BAT, 'U.dim(L=3, M=-1, T=-2), U.dim(L=1, T=-1)]).T', 'U.dim(L=3, M=-1, T=-1), U.dim(L=1, T=-1)]).T'),
    ('UD', 'shadow angle made dimensioned (M / r^2)', BAT, 'x = _m(M) / r; return', 'x = _m(M) / r ** 2; return'),
    ('UE', 'Lambda declared to scale with the system (not anchored)', BAT, 'ratio(q[0], np.log(0.01))', 'ratio(q[0], -2 * q[0] + np.log(0.01))'),
    ('UE', 'metric function with a wrong power of r', BAT, 'f = 1 - 2 * M / r\n', 'f = 1 - 2 * M / r ** 2\n'),
    ('UF', 'clock record made dimensionless (P c / r)', BAT, 'np.log(period(E(p)[0], E(p)[1]))]', 'np.log(period(E(p)[0], E(p)[1]) * C_SI / E(p)[1])]'),
    ('UG', 'record times not rescaled', BAT, 'a2 = P.analyse(r, rt * s, C2)', 'a2 = P.analyse(r, rt, C2)'),
    ('UG', 'damping range not rescaled', BAT, "C2['gamma'] = [g / s for g in C['gamma']]", "C2['gamma'] = list(C['gamma'])"),
    ('UH', 'repair term with a tenth of its coefficient', LIB, 'g = lambda LL, a: np.sqrt((LL ** 2 + 0.4 * a ** 2) / LL)', 'g = lambda LL, a: np.sqrt((LL ** 2 + 0.04 * a ** 2) / LL)'),
    ('UH', 'timing bound inflated tenfold in the upper end', LIB, 'hi = (T + eT) / np.sqrt(L - eL)', 'hi = (T + 10 * eT) / np.sqrt(L - eL)'),
    ('UI', 'cell remainder dropped', LIB, '    R = 2 * R\n', '    R = 0 * R\n'),
    ('UI', 'witness accepted at any remainder', LIB, 'if R < eps / 4:', 'if R < 1e9:'),
    ('UJ', 'lock computed at half the error bound', BAT, 'L = U.lock_memory(y, eps, k12,', 'L = U.lock_memory(y, eps / 2, k12,'),
    ('UJ', 'cells accepted without the tolerance test', LIB, '        if excess <= 0:\n', '        if True:\n'),
    ('UK', 'memory cell remainder dropped', LIB, 'Ra = 2 * np.abs(ap - a0 - dP @ da).max(0); Rb = 2 * np.abs(bp - b0 - dP @ db).max(0)',
     'Ra = 0 * np.abs(ap - a0 - dP @ da).max(0); Rb = 0 * np.abs(bp - b0 - dP @ db).max(0)'),
    ('UK', 'task remainder not added to the cell interval', LIB, 'L_c, U_c = r1.fun - R[task_k], -r2.fun + R[task_k]', 'L_c, U_c = r1.fun, -r2.fun'),
    ('UK', 'initial-velocity bound tightened below the LP range', LIB, 'Xv = min(Xv, max(abs(r[0].fun), abs(r[1].fun)))', 'Xv = min(Xv, 0.3 * max(abs(r[0].fun), abs(r[1].fun)))'),
]


def run(mut):
    group, desc, rel, old, new = mut
    base = open(os.path.join(HERE, rel)).read()
    if base.count(old) != 1:
        return group, desc, 'anchor not found exactly once -> SUITE DEFECT', False
    with tempfile.TemporaryDirectory() as tmp:
        work = os.path.join(tmp, 'b')
        shutil.copytree(HERE, work, ignore=shutil.ignore_patterns('__pycache__', NAME + '_results.json', NAME + '_mutations.py',
                                                                  '*.log', 'paper', '*.zip', 'r[0-9]*.json', 'RG_*bundle*', 'uj.log', 'uk.log'))
        open(os.path.join(work, rel), 'w').write(base.replace(old, new))
        env = dict(os.environ, RG_UNIT_GROUPS=group)
        subprocess.run([sys.executable, '-I', NAME + '.py'], cwd=work, capture_output=True, text=True, env=env)
        try:
            fails = json.load(open(os.path.join(work, NAME + '_results.json')))['failures']
        except Exception:
            fails = ['CRASHED']
    ok = group in fails
    return group, desc, ('caught ' if ok else 'SURVIVED ') + str(fails), ok


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--jobs', type=int, default=2); ap.add_argument('--only', default='')
    a = ap.parse_args(); sel = [m for m in MUTATIONS if not a.only or m[0] in a.only.split(',')]
    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(run, sel))
    for g, d, msg, _ in res:
        print(f'{g}  {d}: {msg}', flush=True)
    caught = sum(r[3] for r in res)
    print(f'{caught} / {len(sel)} caught')
    return 0 if caught == len(sel) else 1


if __name__ == '__main__':
    sys.exit(main())
