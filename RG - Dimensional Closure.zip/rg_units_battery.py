#!/usr/bin/env python3
"""Resolution Geometry - hostile battery for dimensional closure as the unit gauge (rg_units.py).

  UA Buckingham is universal factorization: for 60 random integer dimension matrices the unit orbits have dimension
     rank D and the dimensionless monomials number n - rank D; functions of them are invariant under random unit
     changes, a monomial outside ker D is not
  UB the closure checker is validated, and it does not select dynamics: on 400 random dimensioned expressions the
     symbolic verdict (dimension or malformed) agrees with a numerical unit-scaling test; the damped oscillator and its
     memory extension are both closed, a memory term with a dimensionless coefficient is rejected; of the eight
     entries of a unit audit of that programme, four cannot fail under any dimension table
  UC the 2019 SI is an exact anchor set: the seven defining constants have rank 7 and close every unit direction;
     removing any one reopens exactly one direction
  UD the unit hole is the Fisher kernel: in Schwarzschild with G and c anchored, dimensionless records (shadow angle,
     redshift ratios) leave exactly the dilation (M, r) -> (lambda M, lambda r) in the kernel, as predicted from the
     dimension vectors; a clock record closes it
  UE gravity's scale: vacuum Schwarzschild is scale-covariant (Kretschmann K(lambda M, lambda r) = K / lambda^4,
     exact); in Schwarzschild-de Sitter a dimensionless horizon ratio closes the dilation only if Lambda is a fixed
     (anchored) constant; with Lambda free the kernel is (1, -2) in (log M, log Lambda)
  UF hole typing: with redshift-ratio records only, the kernel in (log M, log r1, log r2) has dimension 2 = one unit
     direction + one intrinsic direction; a clock removes the unit part only; a shadow angle removes the rest
  UG similarity transfer of a lock: the pendulum enclosure at length 4L with time scaled by 2 returns the interval
     of length L to 1e-5 (the fixed integration step is the only hidden scale); a class that scales omega wrongly does
     not transfer
  UH scale rupture: periods at four lengths with timing bound 0.2 ms and length bound 0.5 mm; complete similarity
     T = C sqrt(L) is CONSISTENT for a point bob and INCONSISTENT for a bob of radius 3 cm; declaring the radius
     restores consistency; the detection threshold is reported
  UI certified exclusion on the frozen record (fixture/observable.json, 81 samples, bound 0.002): the damped oscillator, its calibration extension and its
     constant-force extension are EXCLUDED by cells and linear programmes (no optimizer); positive controls: an
     oscillator-generated record is NOT EXCLUDED with a witness cell, also when its parameters lie between cell
     centres and its noise is at the bound (the remainder keeps the true cell); the frozen record at a bound of 0.04
     is NOT EXCLUDED
  UJ certified task lock of the memory extension: branch and bound in (omega, gamma, beta, lambda) with a first-order
     cell model gives an outer interval for x(12 s) within 1e-3 of an inner interval of verified members; diameter
     below 2 delta = 0.03 (LOCKED); the held-out value lies inside; members found in 40 random directions never leave the outer interval;
     local perturbation sampling around the best fit covers less than a quarter of the inner interval; the same
     family on a pure-oscillator record is EMPTY
  UK the remainders are sound where they are checked: in 120 cells of three sizes around members of the frozen record,
     every sampled member lies in a surviving cell and its task value inside the cell's interval, for first-order
     cells and for zeroth-order cells, where the remainder is the only cover; dense samples never
     exceed the doubled sub-grid remainder, for the oscillator cells and for the first-order memory cells

Deterministic seeds. Writes rg_units_battery_results.json.
Run:  python3 -I rg_units_battery.py      (numpy, scipy, sympy; UG needs rg_pendulum.py, class_default.json;
                                           UI needs fixture/observable.json)
"""
import hashlib, json, os, sys
from pathlib import Path
import numpy as np
import sympy as sp

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rg_units as U

R, FAILS = {}, []
G_SI, C_SI = 6.67430e-11, 299792458.0


def must(cond, tag):
    if not cond:
        if tag not in FAILS:
            FAILS.append(tag)
        print('FAILED', tag, flush=True)


# ------------------------------------------------------------------ UA
def group_UA():
    rng = np.random.default_rng(1301); bad = 0; rows = []
    for k in range(60):
        n = int(rng.integers(3, 8)); D = np.zeros((7, n)); D[:3] = rng.integers(-2, 3, (3, n))
        if k % 3 == 0:
            D[3:5] = rng.integers(-1, 2, (2, n))
        r = np.linalg.matrix_rank(D); P = U.pi_groups(D)
        orbit = np.linalg.matrix_rank(D.T)                         # generators of log-unit action on the n quantities
        vals = rng.uniform(0.5, 2, n)
        inv_err = 0.0; non_inv = None
        for _ in range(5):
            s = rng.normal(size=7); v2 = vals * np.exp(D.T @ s)
            for p in P:
                inv_err = max(inv_err, abs(np.prod(v2 ** np.array(p)) / np.prod(vals ** np.array(p)) - 1))
            q = np.zeros(n); q[int(np.argmax(np.abs(D).sum(0)))] = 1
            if np.any(D @ q):
                non_inv = abs(np.prod(v2 ** q) / np.prod(vals ** q) - 1)
        ok = len(P) == n - r and orbit == r and inv_err < 1e-12 and (non_inv is None or non_inv > 1e-6) and \
            all(np.all(D @ np.array(p) == 0) for p in P)
        bad += not ok; rows.append([n, int(r), len(P)])
    must(bad == 0, 'UA')
    R['UA'] = dict(claim='Unit orbits have dimension rank D; n - rank D integer pi-groups; invariance exact; non-pi '
                         'monomials vary', seed=1301, matrices=60, failures=bad, sample=rows[:8])


# ------------------------------------------------------------------ UB
def typing_audit(DIM):
    """An eight-entry unit audit of the oscillator and memory programme, as functions of a dimension table."""
    eq = lambda a, b: bool(np.all(a == b)); z = np.zeros(7)
    return {'E_over_nu_is_action': eq(DIM['E'] - DIM['nu'], DIM['action']),
            'oscillator_acceleration_matches_omega2x': eq(DIM['a'], 2 * DIM['omega'] + DIM['x']),
            'damping_term_matches_acceleration': eq(DIM['gamma'] + DIM['v'], DIM['a']),
            'force_over_mass_matches_acceleration': eq(DIM['force'] - DIM['mass'], DIM['a']),
            'memory_beta_z_can_match_acceleration_with_declared_beta_units': True,
            'coherence_deficit_is_dimensionless': eq(DIM['one'], z),
            'dimension_equality_does_not_fix_coefficient': True,
            'same_dimensions_allow_distinct_coefficients': bool(sp.simplify(sp.Symbol('c1') - sp.Symbol('c2')) != 0)}


def group_UB():
    rng = np.random.default_rng(1302); nvar = 5; agree = disagree = degenerate = malformed = 0
    for k in range(400):
        dims = [rng.integers(-2, 3, 7) * (np.arange(7) < 3) for _ in range(nvar)]
        if k % 4 == 0:
            dims[0] = np.zeros(7)
        e = U.random_expr(rng, nvar, 4); sym = U.check(e, [d.astype(float) for d in dims])
        num = U.scaling_test(e, [d.astype(float) for d in dims], rng)
        if isinstance(num, str):
            degenerate += 1; continue
        malformed += sym is None
        same = (sym is None and num is None) or (sym is not None and num is not None and np.allclose(sym, num, atol=1e-6))
        agree += same; disagree += not same
    DIM = {'x': U.dim(L=1), 'v': U.dim(L=1, T=-1), 'a': U.dim(L=1, T=-2), 'omega': U.dim(T=-1), 'gamma': U.dim(T=-1),
           'z': U.dim(L=1), 'beta': U.dim(T=-2), 'lam': U.dim(T=-1)}
    osc = np.all(DIM['a'] == 2 * DIM['omega'] + DIM['x']) and np.all(DIM['a'] == DIM['gamma'] + DIM['v'])
    mem = osc and np.all(DIM['a'] == DIM['beta'] + DIM['z']) and np.all(DIM['lam'] + DIM['z'] == DIM['v'])
    bad_mem = np.all(DIM['a'] == np.zeros(7) + DIM['z'])          # beta dimensionless
    base = {'one': np.zeros(7), 'E': U.dim(M=1, L=2, T=-2), 'nu': U.dim(T=-1), 'action': U.dim(M=1, L=2, T=-1), 'x': U.dim(L=1),
            'v': U.dim(L=1, T=-1), 'a': U.dim(L=1, T=-2), 'omega': U.dim(T=-1), 'gamma': U.dim(T=-1), 'force': U.dim(M=1, L=1, T=-2),
            'mass': U.dim(M=1)}
    vals = {k_: set() for k_ in typing_audit(base)}
    for k in range(200):
        tab = {k_: (rng.integers(-2, 3, 7) * (np.arange(7) < 3)).astype(float) for k_ in base}; tab['one'] = np.zeros(7)
        for k_, v in typing_audit(tab).items():
            vals[k_].add(v)
    for k_, v in typing_audit(base).items():
        vals[k_].add(v)
    constant = sorted(k_ for k_, v in vals.items() if len(v) == 1)
    ok = disagree == 0 and agree > 300 and malformed > 50 and osc and mem and not bad_mem and len(constant) == 4
    must(ok, 'UB')
    R['UB'] = dict(claim='Symbolic closure agrees with numerical scaling; both dynamics are closed (no selection); half of '
                         'the eight-entry audit cannot fail', seed=1302, expressions=400, agree=agree, disagree=disagree,
                   malformed=malformed, degenerate=degenerate, oscillator_closed=bool(osc), memory_closed=bool(mem),
                   dimensionless_beta_rejected=not bad_mem, audit_entries_that_cannot_fail=constant)


# ------------------------------------------------------------------ UC
def group_UC():
    D = np.array(list(U.SI_CONSTANTS.values())).T; rk = int(np.linalg.matrix_rank(D))
    full = U.unit_hole(np.eye(7), D).shape[1]; reopen = {}
    for k in U.SI_CONSTANTS:
        Dk = np.array([v for kk, v in U.SI_CONSTANTS.items() if kk != k]).T; h = U.unit_hole(np.eye(7), Dk)
        reopen[k] = dict(dimension=int(h.shape[1]), direction=np.round(h[:, 0] / np.abs(h[:, 0]).max(), 3).tolist())
    clock_c = U.unit_hole(np.eye(7), np.array([U.SI_CONSTANTS['Delta_nu_Cs'], U.SI_CONSTANTS['c']]).T).shape[1]
    ok = rk == 7 and full == 0 and all(v['dimension'] == 1 for v in reopen.values()) and clock_c == 5
    must(ok, 'UC')
    R['UC'] = dict(claim='The seven SI defining constants close the unit gauge exactly; each is necessary', rank=rk,
                   hole_with_all=full, hole_when_one_removed=reopen, hole_with_clock_and_c_only=clock_c)


# ------------------------------------------------------------------ UD, UE, UF
def _m(M):
    return G_SI * M / C_SI ** 2


def shadow(M, r):
    x = _m(M) / r; return 3 * np.sqrt(3) * x * np.sqrt(1 - 2 * x)


def redshift(M, r1, r2):
    return np.sqrt((1 - 2 * _m(M) / r2) / (1 - 2 * _m(M) / r1))


def period(M, r):
    return 2 * np.pi * np.sqrt(r ** 3 / (G_SI * M))


M0 = 10 * 1.989e30


def group_UD():
    p0 = np.log([M0, 12 * _m(M0)])
    f_dimless = lambda p: np.array([shadow(np.exp(p[0]), np.exp(p[1])), redshift(np.exp(p[0]), np.exp(p[1]), 3 * np.exp(p[1]))])
    K1, s1 = U.fisher_kernel(f_dimless, p0)
    Dsys = np.array([U.dim(M=1), U.dim(L=1)]).T; Danc = np.array([U.dim(L=3, M=-1, T=-2), U.dim(L=1, T=-1)]).T
    pred = U.unit_hole(Dsys, Danc)
    f_clock = lambda p: np.r_[f_dimless(p), np.log(period(np.exp(p[0]), np.exp(p[1])))]
    K2, _ = U.fisher_kernel(f_clock, p0)
    pred2 = U.unit_hole(Dsys, np.c_[Danc, U.dim(T=1)])
    gap = U.subspace_gap(K1, pred)
    ok = K1.shape[1] == 1 and pred.shape[1] == 1 and gap < 1e-6 and K2.shape[1] == 0 and pred2.shape[1] == 0
    must(ok, 'UD')
    R['UD'] = dict(claim='Dimensionless Schwarzschild records: Fisher kernel = predicted unit hole (the dilation); a clock '
                         'closes it', kernel_dimension=int(K1.shape[1]), kernel=np.round(K1[:, 0] / K1[0, 0], 8).tolist() if K1.shape[1] else [],
                   predicted=np.round(pred[:, 0] / pred[0, 0], 8).tolist() if pred.shape[1] else [], subspace_gap=gap,
                   kernel_with_clock=int(K2.shape[1]), predicted_with_clock=int(pred2.shape[1]))


def group_UE():
    M, r, lam = sp.symbols('M r lambda', positive=True)
    K = 48 * M ** 2 / r ** 6                                        # Schwarzschild Kretschmann (geometric units)
    t_, th, ph = sp.symbols('t theta phi'); X = [t_, r, th, ph]; f = 1 - 2 * M / r
    g = sp.diag(-f, 1 / f, r ** 2, r ** 2 * sp.sin(th) ** 2); gi = g.inv()
    Gm = [[[sp.simplify(sum(gi[a, d] * (sp.diff(g[d, b], X[c]) + sp.diff(g[d, c], X[b]) - sp.diff(g[b, c], X[d])) for d in range(4)) / 2)
            for c in range(4)] for b in range(4)] for a in range(4)]
    Rm = {}
    for a in range(4):
        for b in range(4):
            for c in range(4):
                for d in range(4):
                    Rm[a, b, c, d] = sp.simplify(sp.diff(Gm[a][b][d], X[c]) - sp.diff(Gm[a][b][c], X[d]) +
                                                 sum(Gm[a][c][e] * Gm[e][b][d] - Gm[a][d][e] * Gm[e][b][c] for e in range(4)))
    Rl = {k: sp.simplify(sum(g[k[0], e] * Rm[e, k[1], k[2], k[3]] for e in range(4))) for k in Rm}
    Kc = sp.simplify(sum(Rl[k] * sum(gi[k[0], a] * gi[k[1], b] * gi[k[2], c] * gi[k[3], d] * Rl[a, b, c, d]
                                      for a in range(4) for b in range(4) for c in range(4) for d in range(4)) for k in Rl if Rl[k] != 0))
    scale = sp.simplify(Kc.subs({M: lam * M, r: lam * r}) / Kc)
    # Schwarzschild-de Sitter horizon ratio (geometric units): roots of 1 - 2M/x - Lambda x^2 / 3
    def ratio(logM, logL):
        Mv, Lv = np.exp(logM), np.exp(logL); roots = np.roots([-Lv / 3, 0, 1, -2 * Mv]); rr = np.sort(roots[np.isreal(roots)].real)
        pos = rr[rr > 0]; return np.log(pos[-1] / pos[0])
    p = np.log([1.0, 0.01])
    Kfree, _ = U.fisher_kernel(lambda q: np.array([ratio(q[0], q[1])]), p)
    Kfix, _ = U.fisher_kernel(lambda q: np.array([ratio(q[0], np.log(0.01))]), p[:1])
    direction = (Kfree[:, 0] / Kfree[0, 0]).tolist() if Kfree.shape[1] == 1 else []
    ok = sp.simplify(Kc - K) == 0 and scale == lam ** -4 and len(direction) == 2 and abs(direction[1] + 2) < 1e-6 and Kfix.shape[1] == 0
    must(ok, 'UE')
    R['UE'] = dict(claim='Vacuum Schwarzschild is scale-covariant; Lambda closes the dilation only as a fixed constant',
                   kretschmann=str(Kc), scaling=str(scale), sds_kernel_lambda_free=direction, sds_kernel_lambda_fixed=int(Kfix.shape[1]))


def group_UF():
    p0 = np.log([M0, 8 * _m(M0), 20 * _m(M0)])
    E = lambda p: [np.exp(x) for x in p]
    f1 = lambda p: np.array([np.log(redshift(*E(p)))])
    f2 = lambda p: np.r_[f1(p), np.log(period(E(p)[0], E(p)[1]))]
    f3 = lambda p: np.r_[f2(p), shadow(E(p)[0], E(p)[1])]
    u = np.ones((3, 1)) / np.sqrt(3)
    K1, _ = U.fisher_kernel(f1, p0); K2, _ = U.fisher_kernel(f2, p0); K3, _ = U.fisher_kernel(f3, p0)
    unit_in_K1 = float(np.linalg.norm(u - K1 @ (K1.T @ u)))
    unit_in_K2 = float(np.linalg.norm(K2.T @ u)) if K2.shape[1] else 0.0
    K2_in_K1 = float(np.linalg.norm(K2 - K1 @ (K1.T @ K2))) if K2.shape[1] else 0.0
    ok = K1.shape[1] == 2 and unit_in_K1 < 1e-6 and K2.shape[1] == 1 and K2_in_K1 < 1e-6 and unit_in_K2 < 0.5 and K3.shape[1] == 0
    must(ok, 'UF')
    R['UF'] = dict(claim='Hole typing: redshift ratio only -> unit + intrinsic; a clock removes only the unit part; a '
                         'shadow angle removes the rest', kernel_dims=[int(K1.shape[1]), int(K2.shape[1]), int(K3.shape[1])],
                   unit_direction_residual_in_first_kernel=unit_in_K1, second_kernel_residual_in_first=K2_in_K1, overlap_of_unit_with_second_kernel=unit_in_K2,
                   intrinsic_direction=(K2[:, 0] / np.abs(K2[:, 0]).max()).round(6).tolist())


# ------------------------------------------------------------------ UG, UH
def group_UG():
    import rg_pendulum as P
    C = P.load_class(HERE / 'class_default.json'); s = 2.0
    C2 = dict(C); C2['omega'] = [w / s for w in C['omega']]; C2['gamma'] = [g / s for g in C['gamma']]; C2['V'] = C['V'] / s
    C2['tau'] = C['tau'] * s; C2['tF'] = C['tF'] * s; C2['dt_time'] = C['dt_time'] * s
    r, rt, fut = P.simulate_records(np.array([0.15, 0.2, 3.12, 0.02]), C, 19, np.random.default_rng(1307))
    a1 = P.analyse(r, rt, C); a2 = P.analyse(r, rt * s, C2)
    C3 = dict(C2); C3['omega'] = list(C['omega'])                  # omega not rescaled: not a unit transformation
    a3 = P.analyse(r, rt * s, C3)
    num = all(isinstance(a.get(k), float) for a in (a1, a2) for k in ('lower', 'upper'))
    dl, du = (abs(a1['lower'] - a2['lower']), abs(a1['upper'] - a2['upper'])) if num else (np.inf, np.inf)
    ok = num and a1['status'] == a2['status'] and max(dl, du) < 1e-5 and a3['status'] == 'INCONSISTENT'
    must(ok, 'UG')
    R['UG'] = dict(claim='A lock transfers across a unit change to 1e-5; a wrongly scaled class does not', seed=1307,
                   interval_L=[a1.get('lower'), a1.get('upper')], interval_4L=[a2.get('lower'), a2.get('upper')], difference=max(dl, du),
                   wrong_scaling_status=a3['status'])


def group_UH():
    gacc = 9.81; L = np.array([0.25, 0.5, 1.0, 2.0]); eL, eT = 5e-4, 2e-4; rng = np.random.default_rng(1308)
    T = lambda a: 2 * np.pi * np.sqrt((L ** 2 + 0.4 * a * a) / (gacc * L))
    noisy = lambda a: T(a) + rng.uniform(-0.5, 0.5, 4) * eT
    Lm = lambda: L + rng.uniform(-0.5, 0.5, 4) * eL
    point = U.similarity_test(Lm(), noisy(0.0), eL, eT)
    big = U.similarity_test(Lm(), noisy(0.03), eL, eT)
    repaired = U.similarity_test(Lm(), noisy(0.03), eL, eT, (0.029, 0.031))
    lo, hi = 0.0, 0.05                                             # threshold on noise-free records (best case)
    for _ in range(30):
        mid = (lo + hi) / 2
        if U.similarity_test(L, T(mid), eL, eT)['status'] == 'INCONSISTENT':
            hi = mid
        else:
            lo = mid
    def ref_consistent(a):                                         # independent: extremes of T / sqrt(L) over a grid of each box
        Tg = T(a); lo_, hi_ = -np.inf, np.inf
        for Li, Ti in zip(L, Tg):
            v = np.array([[tt / np.sqrt(ll) for tt in np.linspace(Ti - eT, Ti + eT, 21)] for ll in np.linspace(Li - eL, Li + eL, 21)])
            lo_, hi_ = max(lo_, v.min()), min(hi_, v.max())
        return lo_ <= hi_
    rlo, rhi = 0.0, 0.05
    for _ in range(30):
        mid = (rlo + rhi) / 2
        rlo, rhi = (rlo, mid) if not ref_consistent(mid) else (mid, rhi)
    ok = point['status'] == 'CONSISTENT' and big['status'] == 'INCONSISTENT' and repaired['status'] == 'CONSISTENT' and \
        0.015 < hi < 0.03 and abs(hi - rhi) < 1e-6
    must(ok, 'UH')
    R['UH'] = dict(claim='Complete similarity fails for a 3 cm bob; declaring the radius repairs it', seed=1308,
                   lengths=L.tolist(), length_bound=eL, timing_bound=eT, point_bob=point, bob_3cm=big,
                   bob_3cm_radius_declared=repaired, detection_threshold_radius=hi,
                   threshold_independent_grid=rhi)


# ------------------------------------------------------------------ UI
def group_UI():
    O = json.loads((HERE / 'fixture' / 'observable.json').read_text())
    t = np.array(O['times']); y = np.array(O['observations']); m = np.array(O['train_mask']); t, y = t[m], y[m]
    res = {mode: U.exclude_oscillator(t, y, 0.002, mode) for mode in ('baseline', 'calibration', 'known_force')}
    rng = np.random.default_rng(1309)
    yo = U.oscillator(t, 1.07, 0.045, 0.8, -0.15) + rng.uniform(-0.0015, 0.0015, len(t))
    pos = U.exclude_oscillator(t, yo, 0.002, 'baseline')
    loose = U.exclude_oscillator(t, y, 0.04, 'baseline')
    yh = U.oscillator(t, 1.0937, 0.0333, -0.6, 0.4) + rng.uniform(-0.0019, 0.0019, len(t))   # between cell centres, noise at the bound
    hard = U.exclude_oscillator(t, yh, 0.002, 'baseline')
    ok = all(v['status'] == 'EXCLUDED' for v in res.values()) and pos['status'] == 'NOT EXCLUDED' and \
        loose['status'] == 'NOT EXCLUDED' and hard['status'] == 'NOT EXCLUDED'
    must(ok, 'UI')
    R['UI'] = dict(claim='The three declared baseline families are EXCLUDED by cells and linear programmes; an oscillator '
                         'record and a loose bound are not', seed=1309, observable_sha256=hashlib.sha256((HERE / 'fixture' / 'observable.json').read_bytes()).hexdigest(),
                   exclusion=res, oscillator_record=pos, bound_0_04=loose, off_centre_record_at_bound=hard)


# ------------------------------------------------------------------ UJ
def group_UJ():
    from scipy.optimize import least_squares, minimize, linprog
    O = json.loads((HERE / 'fixture' / 'observable.json').read_text())
    yy = np.array(O['observations']); m_ = np.array(O['train_mask']); y = yy[m_]; m = len(y); eps, k12, delta = 0.002, 120, 0.015
    box = np.array([(0.8, 1.3), (0.0, 0.12), (0.12, 0.18), (0.25, 0.45)]); lob, hib = np.r_[box[:, 0], -1.5, -1.5], np.r_[box[:, 1], 1.5, 1.5]
    rec = lambda p: (lambda ab: p[4] * ab[0][0] + p[5] * ab[1][0])(U.memory_basis(p[:4], k12))
    fit = least_squares(lambda p: rec(p)[:m] - y, np.r_[box.mean(1), y[0], 0.0], bounds=(lob, hib))
    cons = {'type': 'ineq', 'fun': lambda p: np.r_[eps - (rec(p)[:m] - y), eps + (rec(p)[:m] - y)]}
    seeds = [fit.x[:4]] + [minimize(lambda p, sg=sg: sg * rec(p)[k12], fit.x, constraints=[cons], bounds=list(zip(lob, hib)),
                                    method='SLSQP', options=dict(maxiter=300, ftol=1e-12)).x[:4] for sg in (1, -1)]
    L = U.lock_memory(y, eps, k12, tol=1e-3, cap=40000, seeds=seeds)
    rng = np.random.default_rng(1310); lo_mc, hi_mc, members = np.inf, -np.inf, 0
    for _ in range(40):                                            # members in random directions (optimizer, then exact LP)
        g = rng.normal(size=6)
        th = minimize(lambda p: g @ ((p - lob) / (hib - lob)), fit.x, constraints=[cons], bounds=list(zip(lob, hib)),
                      method='SLSQP', options=dict(maxiter=200, ftol=1e-12)).x[:4]
        a, b = U.memory_basis(th, k12); M0 = np.c_[a[0, :m], b[0, :m]]; tv = np.array([a[0, k12], b[0, k12]])
        r1 = linprog(tv, A_ub=np.vstack([M0, -M0]), b_ub=np.r_[y + eps, eps - y], bounds=[(-1.5, 1.5)] * 2, method='highs')
        if r1.status == 0:
            r2 = linprog(-tv, A_ub=np.vstack([M0, -M0]), b_ub=np.r_[y + eps, eps - y], bounds=[(-1.5, 1.5)] * 2, method='highs')
            members += 1; lo_mc, hi_mc = min(lo_mc, r1.fun), max(hi_mc, -r2.fun)
    sc = np.array([0.5, 0.12, 0.06, 0.2, 3, 3]); fut = []                # local perturbation sampling around the best fit
    for scale in (1e-5, 3e-5, 1e-4, 3e-4, 1e-3):
        for _ in range(200):
            q = np.clip(fit.x + rng.normal(size=6) * scale * sc, lob, hib); r_ = rec(q)
            if np.abs(r_[:m] - y).max() <= eps:
                fut.append(r_[k12])
    samp = [float(min(fut)), float(max(fut))] if fut else None
    rng2 = np.random.default_rng(1311); tt = np.arange(m) * 0.1
    empty = U.lock_memory(U.oscillator(tt, 1.07, 0.045, 0.8, -0.15) + rng2.uniform(-0.0015, 0.0015, m), eps, k12, tol=1e-3, cap=40000)
    ok = L['status'] == 'INTERVAL'
    if ok:
        (olo, ohi), (ilo, ihi) = L['outer'], L['inner']
        ok = (olo <= ilo and ihi <= ohi and ilo - olo <= 1e-3 + 1e-12 and ohi - ihi <= 1e-3 + 1e-12 and L['diameter'] <= 2 * delta
              and olo - eps <= yy[-1] <= ohi + eps and members >= 20 and olo <= lo_mc and hi_mc <= ohi
              and samp is not None and samp[1] - samp[0] < (ihi - ilo) / 4 and empty['status'] == 'EMPTY')
    must(ok, 'UJ')
    R['UJ'] = dict(claim='The declared memory extension LOCKS x(12 s) on the frozen record (outer interval certified within '
                         '1e-3 of verified members); local sampling under-covers; on a pure-oscillator record it is EMPTY',
                   seed=1310, lock=L, delta=delta, held_out_value=float(yy[-1]), random_members=members,
                   random_member_range=[lo_mc, hi_mc], local_sampling_range=samp, local_sampling_count=len(fut),
                   oscillator_record=empty)


# ------------------------------------------------------------------ UK
def group_UK():
    from scipy.optimize import least_squares, linprog
    O = json.loads((HERE / 'fixture' / 'observable.json').read_text())
    y = np.array(O['observations'])[np.array(O['train_mask'])]; t = np.array(O['times'])[np.array(O['train_mask'])]
    m = len(y); eps, k12 = 0.002, 120; box = np.array([(0.8, 1.3), (0.0, 0.12), (0.12, 0.18), (0.25, 0.45)])
    lo_, hi_ = box[:, 0], box[:, 1]; Xx = abs(y[0]) + eps
    rec = lambda p: (lambda ab: p[4] * ab[0][0] + p[5] * ab[1][0])(U.memory_basis(p[:4], k12))
    fit = least_squares(lambda p: rec(p)[:m] - y, np.r_[box.mean(1), y[0], 0.0], bounds=(np.r_[lo_, -1.5, -1.5], np.r_[hi_, 1.5, 1.5]))
    offs = np.stack(np.meshgrid(*[np.linspace(-1, 1, 3)] * 4, indexing='ij'), -1).reshape(-1, 4)
    rng = np.random.default_rng(1312); viol = 0; checked = 0; ratio_mem = 0.0
    for frac in (0.02, 0.005, 0.001):
        for _ in range(40):
            h = frac * (hi_ - lo_); c = np.clip(fit.x[:4] + rng.uniform(-0.5, 0.5, 4) * h, lo_, hi_)
            cells = [U.mem_cell(c, h, y, eps, k12, lo_, hi_, Xx, 1.5, k12, 0.1, offs, order) for order in (1, 0)]
            P = np.clip(c + rng.uniform(-1, 1, (60, 4)) * h, lo_, hi_); a, b = U.memory_basis(np.vstack([c, P]), k12)
            fd = 1e-6; F = np.vstack([c + fd * e for e in np.eye(4)] + [c - fd * e for e in np.eye(4)]); af, bf = U.memory_basis(F, k12)
            da = (af[:4] - af[4:]) / (2 * fd); db = (bf[:4] - bf[4:]) / (2 * fd); dP = P - c
            sub = np.clip(c + offs * h, lo_, hi_); asb, bsb = U.memory_basis(sub, k12); dS = sub - c
            Ra = np.abs(asb - a[0] - dS @ da).max(0); Rb = np.abs(bsb - b[0] - dS @ db).max(0)
            Da = np.abs(a[1:] - a[0] - dP @ da).max(0); Db = np.abs(b[1:] - b[0] - dP @ db).max(0)
            ratio_mem = max(ratio_mem, float(np.max(Da / (2 * Ra + 1e-15))), float(np.max(Db / (2 * Rb + 1e-15))))
            for j in range(len(P)):
                M0 = np.c_[a[j + 1, :m], b[j + 1, :m]]; tv = np.array([a[j + 1, k12], b[j + 1, k12]])
                r1 = linprog(tv, A_ub=np.vstack([M0, -M0]), b_ub=np.r_[y + eps, eps - y], bounds=[(-Xx, Xx), (-1.5, 1.5)], method='highs')
                if r1.status != 0:
                    continue
                r2 = linprog(-tv, A_ub=np.vstack([M0, -M0]), b_ub=np.r_[y + eps, eps - y], bounds=[(-Xx, Xx), (-1.5, 1.5)], method='highs')
                checked += 1
                for cell in cells:                                  # first-order cells and zeroth-order cells (remainder only)
                    if cell is None or r1.fun < cell[0] - 1e-9 or -r2.fun > cell[1] + 1e-9:
                        viol += 1
    ratio_osc = 0.0                                                  # oscillator cells: dense deviation vs doubled sub-grid remainder
    for _ in range(200):
        oc, gc = rng.uniform(0.8, 1.3), rng.uniform(0.0, 0.12); ho, hg = 10 ** rng.uniform(-4, -1.5), 10 ** rng.uniform(-4, -2)
        a, b = U._basis(oc, gc, t); Ra = np.zeros_like(t); Rb = np.zeros_like(t)
        for o in np.linspace(oc - ho, oc + ho, 5):
            for g in np.linspace(max(gc - hg, 0.0), gc + hg, 5):
                aa, bb = U._basis(o, g, t); Ra = np.maximum(Ra, np.abs(aa - a)); Rb = np.maximum(Rb, np.abs(bb - b))
        for o, g in zip(rng.uniform(oc - ho, oc + ho, 100), rng.uniform(max(gc - hg, 0.0), gc + hg, 100)):
            aa, bb = U._basis(o, g, t)
            ratio_osc = max(ratio_osc, float(np.max(np.abs(aa - a) / (2 * Ra + 1e-15))), float(np.max(np.abs(bb - b) / (2 * Rb + 1e-15))))
    ok = viol == 0 and checked > 500 and ratio_mem < 1 and ratio_osc < 1
    must(ok, 'UK')
    R['UK'] = dict(claim='Cell remainders are sound where checked: members never fall outside a first- or zeroth-order cell '
                         'interval; dense deviations stay below the doubled sub-grid remainder', seed=1312, members_checked=checked, violations=viol,
                   worst_dense_over_doubled_memory=ratio_mem, worst_dense_over_doubled_oscillator=ratio_osc)


GROUPS = dict(UA=group_UA, UB=group_UB, UC=group_UC, UD=group_UD, UE=group_UE, UF=group_UF, UG=group_UG, UH=group_UH, UI=group_UI, UJ=group_UJ, UK=group_UK)


def main():
    want = os.environ.get('RG_UNIT_GROUPS'); sel = want.split(',') if want else list(GROUPS)
    for g in sel:
        GROUPS[g]()                                               # a crash writes no results: never a pass, never a catch
        print(g, 'done', flush=True)
    R['failures'] = FAILS; R['groups_run'] = sel
    R['source_sha256'] = {f: hashlib.sha256((HERE / f).read_bytes()).hexdigest() for f in ('rg_units.py', 'rg_units_battery.py')}
    (HERE / 'rg_units_battery_results.json').write_text(json.dumps(R, indent=1, sort_keys=True, default=float))
    print(json.dumps(R, indent=1, sort_keys=True, default=float)[:6000])
    return 1 if FAILS else 0


if __name__ == '__main__':
    sys.exit(main())
