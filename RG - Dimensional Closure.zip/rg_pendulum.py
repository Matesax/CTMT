#!/usr/bin/env python3
"""Resolution Geometry: fibre transfer on a real pendulum. Analysis tool.

A pendulum is filmed; its angle is read at evenly spaced early frames (the records). The tool computes the set of every
initial state AND every law in a declared class that agrees with those records within declared error bounds (the
admissible fibre), transports the whole fibre to a later time, and returns the range of the future angle over it.

  status LOCKED          the range is narrower than the declared tolerance (diameter <= 2 tol)
  status CORRESPONDENCE  the range is wider: several futures remain compatible; the range is returned
  status INCONSISTENT    no member of the class agrees with the records: the declared class is refuted
  status OUTSIDE DOMAIN  the first record lies outside the declared amplitude bound

Model class (declared before the test run, in class.json):
  theta'' = -omega^2 sin(theta) - 2 gamma theta',  omega in [w_lo, w_hi], gamma in [g_lo, g_hi], |theta0| <= A,
  |theta0'| <= V; every record and the target are within eps_track + eta + V*dt_time + 1e-6 of the true angle
  (tracking error, unmodelled physics, timing error, integration error).

The enclosure: the parameter box is cut into cells; a cell is removed when a cheap interval test shows it cannot meet
the records; on the remaining cells the trajectory is linearized (forward sensitivities), its departure from the
linearization is bounded by twice the largest departure at the 16 corners, and two linear programmes give the
smallest and largest target over the linearized cell. Cells with a large remainder are bisected. This is a numerical
enclosure, validated by coverage tests (battery), not an interval-certified proof.

Commands
  python3 -I rg_pendulum.py predict   class.json --truths 200 --seed 1     -> predictions.json (frozen before any test)
  python3 -I rg_pendulum.py calibrate class.json calib.csv --t0 2.0         -> calibration.json (calibration releases only)
  python3 -I rg_pendulum.py release   class.json run.csv                    -> release.json (t0 by the pre-registered rule)
  python3 -I rg_pendulum.py stage1    class.json run.csv --t0 3.47          -> stage1.json (reads only the record window)
  python3 -I rg_pendulum.py stage2    class.json run.csv stage1.json        -> stage2.json (reads the target frame)

CSV: columns t,x,y (seconds, any length unit), origin at the pivot, y upward (Tracker export). Angle = atan2(x, -y)
minus the rest angle of the class.
"""
import argparse, hashlib, json, math, sys
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
DT = 0.02          # RK4 step; error below 1e-6 rad on the class (battery group PA)
NUM_ERR = 1e-6


# ------------------------------------------------------------------ dynamics
def _rhs(th, v, S, w2, w, g, sens):
    dth = v; dv = -w2 * np.sin(th) - 2 * g * v
    if not sens:
        return dth, dv, None
    dS = np.empty_like(S)
    dS[:, 0, :] = S[:, 1, :]
    dS[:, 1, :] = (-w2 * np.cos(th))[:, None] * S[:, 0, :] - 2 * g[:, None] * S[:, 1, :]
    dS[:, 1, 2] -= 2 * w * np.sin(th); dS[:, 1, 3] -= 2 * v
    return dth, dv, dS


def integrate(P, times, dt=DT, sens=True):
    """P (n,4): theta0, v0, omega, gamma at t = 0. Returns theta at the given times (n,k) and d theta / d P (n,k,4).
    Values between RK4 steps use cubic Hermite interpolation with the exact derivatives."""
    P = np.atleast_2d(np.asarray(P, float)); times = np.asarray(times, float)
    n = len(P); th = P[:, 0].copy(); v = P[:, 1].copy(); w = P[:, 2]; w2 = w ** 2; g = P[:, 3]
    S = np.zeros((n, 2, 4)); S[:, 0, 0] = 1; S[:, 1, 1] = 1
    out = np.zeros((n, len(times))); outS = np.zeros((n, len(times), 4)) if sens else None
    order = np.argsort(times); ti = 0; t = 0.0; T = times.max()
    while ti < len(order):
        a1, b1, c1 = _rhs(th, v, S, w2, w, g, sens)
        a2, b2, c2 = _rhs(th + dt / 2 * a1, v + dt / 2 * b1, S + dt / 2 * c1 if sens else None, w2, w, g, sens)
        a3, b3, c3 = _rhs(th + dt / 2 * a2, v + dt / 2 * b2, S + dt / 2 * c2 if sens else None, w2, w, g, sens)
        a4, b4, c4 = _rhs(th + dt * a3, v + dt * b3, S + dt * c3 if sens else None, w2, w, g, sens)
        th1 = th + dt / 6 * (a1 + 2 * a2 + 2 * a3 + a4); v1 = v + dt / 6 * (b1 + 2 * b2 + 2 * b3 + b4)
        S1 = S + dt / 6 * (c1 + 2 * c2 + 2 * c3 + c4) if sens else None
        while ti < len(order) and times[order[ti]] <= t + dt + 1e-12:
            s = (times[order[ti]] - t) / dt                      # Hermite basis on [t, t+dt]
            h00, h10, h01, h11 = 2*s**3 - 3*s**2 + 1, s**3 - 2*s**2 + s, -2*s**3 + 3*s**2, s**3 - s**2
            out[:, order[ti]] = h00 * th + h10 * dt * v + h01 * th1 + h11 * dt * v1
            if sens:
                outS[:, order[ti]] = h00 * S[:, 0] + h10 * dt * S[:, 1] + h01 * S1[:, 0] + h11 * dt * S1[:, 1]
            ti += 1
        th, v, S, t = th1, v1, S1, t + dt
        if t > T + dt:
            break
    return out, outS


# ------------------------------------------------------------------ enclosure
def corners_remainder(Cc, H, th_c, S, times):
    sg = np.array(np.meshgrid(*[[-1, 1]] * 4, indexing='ij')).reshape(4, -1).T
    P = (Cc[:, None, :] + sg[None, :, :] * H[:, None, :]).reshape(-1, 4)
    thx, _ = integrate(P, times, sens=False); thx = thx.reshape(len(Cc), 16, -1)
    lin = th_c[:, None, :] + np.einsum('nki,nci->nck', S, sg[None, :, :] * H[:, None, :])
    return 2 * np.max(np.abs(thx - lin), axis=1)


def lp_ranges(c_th, S, R, r, eps, H, m):
    from scipy.optimize import linprog
    out = np.full((len(c_th), 3), np.nan)
    for i in range(len(c_th)):
        Sk = S[i, :m, :]; b = eps + R[i, :m]; d = r - c_th[i, :m]
        G = np.vstack([Sk, -Sk]); h = np.r_[d + b, -d + b]
        bounds = [(-H[i, j], H[i, j]) for j in range(4)]
        a = linprog(S[i, m, :], A_ub=G, b_ub=h, bounds=bounds, method='highs')
        if a.status == 2:
            out[i] = [0, np.nan, np.nan]; continue
        z = linprog(-S[i, m, :], A_ub=G, b_ub=h, bounds=bounds, method='highs')
        if a.status != 0 or z.status != 0:
            raise RuntimeError('linear programme failed')
        out[i] = [1, c_th[i, m] + a.fun - R[i, m], c_th[i, m] - z.fun + R[i, m]]
    return out


def eps_total(C):
    return C['eps_track'] + C['eta'] + C['V'] * C['dt_time'] + NUM_ERR


def analyse(r, rt, C, rho=0.5, lp_cap=3000, cap=60000, levels=10, n0=(1, 24, 32, 8), cells_out=None):
    """r: record angles at times rt (seconds after the first record). Target at C['tF']."""
    r = np.asarray(r, float); rt = np.asarray(rt, float); m = len(r); A = C['A']; eps = eps_total(C); tol = C['tol']
    if m < 1:
        raise ValueError('no records')
    if abs(r[0]) > A + eps:
        return dict(m=m, status='OUTSIDE DOMAIN')
    lo = np.array([max(r[0] - eps, -A), -C['V'], C['omega'][0], C['gamma'][0]])
    hi = np.array([min(r[0] + eps, A), C['V'], C['omega'][1], C['gamma'][1]])
    n0 = np.array(n0)
    cen = [lo[i] + (np.arange(n0[i]) + 0.5) * (hi[i] - lo[i]) / n0[i] for i in range(4)]
    Cc = np.stack(np.meshgrid(*cen, indexing='ij'), -1).reshape(-1, 4); H = np.tile((hi - lo) / n0 / 2, (len(Cc), 1))
    times = np.r_[rt - rt[0], C['tF']]; mode = 'interval'
    for lev in range(levels):
        th, S = integrate(Cc, times)
        D = (1 + rho) * np.einsum('nki,ni->nk', np.abs(S), H)
        keep = ~np.any(np.abs(th[:, :m] - r[None, :]) > eps + D[:, :m], axis=1)
        Cc, H, th, S, D = Cc[keep], H[keep], th[keep], S[keep], D[keep]
        if len(Cc) == 0:
            return dict(m=m, status='INCONSISTENT', level=lev)
        loF, hiF = float(np.min(th[:, m] - D[:, m])), float(np.max(th[:, m] + D[:, m])); mode = 'interval'
        if len(Cc) <= lp_cap:
            R = corners_remainder(Cc, H, th, S, times)
            L = lp_ranges(th, S, R, r, eps, H, m); feas = L[:, 0] == 1
            Cc, H, th, S, R, L = Cc[feas], H[feas], th[feas], S[feas], R[feas], L[feas]
            if len(Cc) == 0:
                return dict(m=m, status='INCONSISTENT', level=lev)
            loF, hiF = float(np.min(L[:, 1])), float(np.max(L[:, 2])); mode = 'lp'
            refine = np.max(R, axis=1) > eps / 4
        else:
            refine = np.ones(len(Cc), bool)
        if not refine.any() or len(Cc) + refine.sum() > cap:
            break
        j = np.argmax((np.abs(S[refine, m, :]) + np.max(np.abs(S[refine, :m, :]), axis=1)) * H[refine], axis=1)
        Cs, Hs = Cc[refine].copy(), H[refine].copy(); ii = np.arange(len(j)); Hs[ii, j] /= 2
        a, b = Cs.copy(), Cs.copy(); a[ii, j] -= Hs[ii, j]; b[ii, j] += Hs[ii, j]
        Cc = np.vstack([Cc[~refine], a, b]); H = np.vstack([H[~refine], Hs, Hs])
    if cells_out is not None:
        cells_out.extend([Cc, H])
    fib = {k: [float(np.min(Cc[:, i] - H[:, i])), float(np.max(Cc[:, i] + H[:, i]))] for i, k in enumerate(['theta0', 'v0', 'omega', 'gamma'])}
    return dict(m=m, status='LOCKED' if hiF - loF <= 2 * tol else 'CORRESPONDENCE', lower=loF, upper=hiF,
                diameter=hiF - loF, mode=mode, cells=len(Cc), fibre=fib)


# ------------------------------------------------------------------ class, records, commitments
REQUIRED = ['A', 'V', 'omega', 'gamma', 'eps_track', 'eta', 'dt_time', 'tau', 'tF', 'tol', 'rest_angle', 't_start', 'records']


def load_class(p):
    C = json.loads(Path(p).read_text()) if not isinstance(p, dict) else dict(p)
    miss = [k for k in REQUIRED if k not in C]
    if miss:
        raise ValueError(f'class lacks {miss}')
    if not (C['omega'][0] < C['omega'][1] and C['gamma'][0] <= C['gamma'][1] and C['records'] >= 5
            and C['tF'] > C['tau'] * (C['records'] - 1) + C['tau']):
        raise ValueError('class is inconsistent (ranges, fewer than 5 records, or target not after the record window)')
    return C


def sha(b):
    return hashlib.sha256(b).hexdigest()


def class_hash(C):
    return sha(json.dumps(C, sort_keys=True).encode())


HALF_FRAME = 0.006


def read_rows(csv, t_lo, t_hi):
    """Rows (t, x, y) of a Tracker export with t_lo - 6 ms <= t <= t_hi + 6 ms. Nothing outside the window is kept."""
    rows = []
    for line in Path(csv).read_text().splitlines():
        parts = [q.strip() for q in line.replace(';', ',').split(',')]
        try:
            t, x, y = float(parts[0]), float(parts[1]), float(parts[2])
        except (ValueError, IndexError):
            continue                                              # header, blank or untracked frame
        if not all(map(math.isfinite, (t, x, y))):
            continue
        if t_lo - HALF_FRAME <= t <= t_hi + HALF_FRAME:
            rows.append((t, x, y))
    return np.array(rows).reshape(-1, 3)


def angles(rows, C):
    return np.arctan2(rows[:, 1], -rows[:, 2]) - C['rest_angle']


def pick(rows, targets):
    """For each target time the row closest to it; it must be within 6 ms."""
    out = []
    for tt in targets:
        if len(rows) == 0:
            raise ValueError(f'no frame near t = {tt:.3f}')
        i = int(np.argmin(np.abs(rows[:, 0] - tt)))
        if abs(rows[i, 0] - tt) > HALF_FRAME:
            raise ValueError(f'no frame within 6 ms of t = {tt:.3f}')
        out.append(rows[i])
    return np.array(out)


def nls(r, rt, C):
    """Ordinary nonlinear least squares in the same model, with the usual Gaussian 95% prediction interval for a new
    reading at the target time. The comparison method; it does not use the error bounds."""
    from scipy.optimize import least_squares
    m = len(r); res = lambda p: integrate(p[None], rt, sens=False)[0][0] - r
    jac = lambda p: integrate(p[None], rt)[1][0]; best = None
    for v0 in np.linspace(-C['V'], C['V'], 7):
        s = least_squares(res, np.array([r[0], v0, np.mean(C['omega']), np.mean(C['gamma'])]), jac=jac, method='lm')
        if best is None or s.cost < best.cost:
            best = s
    th, S = integrate(best.x[None], np.r_[rt, C['tF']]); J, g = S[0, :m], S[0, m]
    s2 = 2 * best.cost / (m - 4); cov = s2 * np.linalg.pinv(J.T @ J); half = 1.96 * math.sqrt(float(g @ cov @ g) + s2)
    return dict(prediction=float(th[0, m]), lower=float(th[0, m] - half), upper=float(th[0, m] + half),
                params=[float(x) for x in best.x])


def lock_depth(r, rt, C, full=None):
    """Smallest prefix length that locks, by bisection, and the analysis at that length (assumes the status sequence
    is monotone; battery PD checks it). (None, None) when the full window does not lock."""
    full = full or analyse(r, rt, C)
    if full['status'] != 'LOCKED':
        return None, None
    lo, hi, at = 0, len(r), full
    while hi - lo > 1:
        mid = (lo + hi) // 2; a = analyse(r[:mid], rt[:mid], C)
        if a['status'] == 'LOCKED':
            hi, at = mid, a
        else:
            lo = mid
    return hi, at


def release_time(C, csv, hold=0.5, k=5.0):
    """Pre-registered release rule: the reference is the median angle over the first `hold` seconds of the clip (the bob
    held still); the release frame is the first later frame whose angle differs from it by more than k * eps_track.
    No row after the release frame affects the result. Returns (release time, t0 = release + 2 s)."""
    rows = []
    for line in Path(csv).read_text().splitlines():
        parts = [q.strip() for q in line.replace(';', ',').split(',')]
        try:
            rows.append((float(parts[0]), float(parts[1]), float(parts[2])))
        except (ValueError, IndexError):
            continue
    rows = np.array(sorted(rows)).reshape(-1, 3); th = angles(rows, C); t = rows[:, 0]
    held = t <= t[0] + hold
    if held.sum() < 5:
        raise ValueError('fewer than 5 frames in the hold interval')
    ref = float(np.median(th[held]))
    for i in np.nonzero(~held)[0]:
        if abs(th[i] - ref) > k * C['eps_track']:
            return float(t[i]), float(t[i] + 2.0)
    raise ValueError('no release found')


def stage1(C, csv, t0=None):
    """Reads only the record window [t0, t0 + tau (records - 1)]; t0 defaults to the class t_start and is chosen per
    release by the pre-registered rule (release frame + 2 s). The prediction uses every record in the
    window: the full window is also the audit of the class (a prefix may lock on a wrong class; the full window is
    what detects it - battery group PF)."""
    t0 = C['t_start'] if t0 is None else float(t0); m = C['records']; last = t0 + C['tau'] * (m - 1)
    rows = read_rows(csv, t0, last)
    R = pick(rows, t0 + C['tau'] * np.arange(m))
    th = angles(R, C); rt = R[:, 0] - R[0, 0]
    res = analyse(th, rt, C)
    rec = dict(t0=t0, records=[float(x) for x in th], record_times=[float(x) for x in R[:, 0]], analysis=res,
               lock_depth=None, at_lock_depth=None,
               nls=nls(th, rt, C) if res['status'] in ('LOCKED', 'CORRESPONDENCE') else None,
               latest_time_read=float(rows[:, 0].max()), class_sha256=class_hash(C),
               tool_sha256=sha(Path(__file__).read_bytes()), target_time=float(R[0, 0] + C['tF']))
    rec['lock_depth'], rec['at_lock_depth'] = lock_depth(th, rt, C, res)
    rec['commitment'] = sha(json.dumps(rec, sort_keys=True).encode())
    return rec


def stage2(C, csv, s1):
    body = {k: v for k, v in s1.items() if k != 'commitment'}
    if sha(json.dumps(body, sort_keys=True).encode()) != s1['commitment']:
        raise ValueError('stage-1 record does not match its commitment')
    if s1['class_sha256'] != class_hash(C):
        raise ValueError('class differs from the one used in stage 1')
    tt = s1['target_time']; R = pick(read_rows(csv, tt, tt), [tt]); y = float(angles(R, C)[0])
    a = s1['analysis']; e = eps_total(C); out = dict(target_angle=y, status=a['status'], margin=e, stage1_commitment=s1['commitment'])
    if a['status'] in ('LOCKED', 'CORRESPONDENCE'):
        out.update(interval=[a['lower'], a['upper']], inside=bool(a['lower'] - e <= y <= a['upper'] + e),
                   nls_interval=[s1['nls']['lower'], s1['nls']['upper']],
                   nls_inside=bool(s1['nls']['lower'] <= y <= s1['nls']['upper']))
    return out


def calibrate(C, csv, t0):
    """A calibration release (never a test release): the record window starts at t0 and runs to t0 + tF. Returns the
    status of the class on that whole span, the smallest eta that keeps it consistent, and the fibre of the law."""
    n = int(round(C['tF'] / C['tau'])) + 1; rows = read_rows(csv, t0, t0 + C['tau'] * (n - 1))
    R = pick(rows, t0 + C['tau'] * np.arange(n)); th = angles(R, C); rt = R[:, 0] - R[0, 0]
    res = analyse(th, rt, C); lo, hi = 0.0, 0.05; D = dict(C)
    D['eta'] = hi
    if analyse(th, rt, D)['status'] == 'INCONSISTENT':
        eta_min = None                                            # not consistent even with eta = 0.05: wrong class
    else:
        for _ in range(9):
            D['eta'] = (lo + hi) / 2
            if analyse(th, rt, D)['status'] == 'INCONSISTENT':
                lo = D['eta']
            else:
                hi = D['eta']
        eta_min = hi
    edge = None
    if res['status'] != 'INCONSISTENT':
        f = res['fibre']; wr = C['omega'][1] - C['omega'][0]
        edge = bool(f['omega'][0] - C['omega'][0] < 0.1 * wr or C['omega'][1] - f['omega'][1] < 0.1 * wr)
    return dict(status=res['status'], eta_min=eta_min, fibre=res.get('fibre'), omega_fibre_near_edge=edge,
                advice='eta_min is the smallest error budget beyond eps_track that keeps the release consistent; declare eta >= 2 eta_min; if the omega fibre is near an edge of the declared range, widen the range '
                       'before freezing (battery PF: a law just outside the class can stay consistent and lock wrongly)')


# ------------------------------------------------------------------ prediction before the test
def simulate_records(truth, C, m, rng, mode='uniform', target=False):
    """Records at 0, tau, ... and the target at tF. Errors (bounded by eps_track + eta) are added to records and, when
    target=True, to the target reading: 'uniform' independent, 'offset' one constant (a rest-angle error), 'sign' +-."""
    rt = C['tau'] * np.arange(m); th, _ = integrate(truth[None, :], np.r_[rt, C['tF']], sens=False); th = th[0]
    e = C['eps_track'] + C['eta']
    if mode == 'uniform':
        noise = rng.uniform(-e, e, m + 1)
    elif mode == 'offset':
        noise = np.full(m + 1, e * rng.choice([-1, 1]))
    else:
        noise = e * rng.choice([-1, 1], m + 1)
    return th[:m] + noise[:m], rt, (th[m] + noise[m]) if target else th[m]


def sample_truth(C, rng):
    while True:
        w = rng.uniform(*C['omega']); g = rng.uniform(*C['gamma'])
        A0 = rng.uniform(0.5, 0.9) * C['A']; ph = rng.uniform(0, 2 * np.pi)
        th0, v0 = A0 * np.cos(ph), -A0 * w * np.sin(ph)
        if abs(th0) <= C['A'] and abs(v0) <= C['V']:
            return np.array([th0, v0, w, g])


def predict(C, truths, seed):
    """Simulated test releases from the declared class, analysed exactly as stage 1 does. Frozen before any test."""
    rng = np.random.default_rng(seed); depths = []; covered = 0; locked = 0; om = []; ga = []
    for _ in range(truths):
        tr = sample_truth(C, rng); r, rt, fut = simulate_records(tr, C, C['records'], rng)
        res = analyse(r, rt, C); d, at = lock_depth(r, rt, C, res)
        depths.append(d if d is not None else C['records'] + 1)
        if res['status'] in ('LOCKED', 'CORRESPONDENCE'):
            covered += res['lower'] <= fut <= res['upper']
        if res['status'] == 'LOCKED':
            locked += 1
            om.append((at['fibre']['omega'][1] - at['fibre']['omega'][0]) / (C['omega'][1] - C['omega'][0]))
            ga.append((at['fibre']['gamma'][1] - at['fibre']['gamma'][0]) / max(C['gamma'][1] - C['gamma'][0], 1e-12))
    from scipy.stats import binom
    d = np.array([x for x in depths if x <= C['records']]); rate = locked / truths
    q = (lambda a: int(math.ceil(np.quantile(d, a)))) if len(d) else (lambda a: None)
    need = {n: int(next(k for k in range(n, -1, -1) if binom.sf(k - 1, n, rate) >= 0.99)) for n in (10, 15, 20)}
    return dict(class_sha256=class_hash(C), tool_sha256=sha(Path(__file__).read_bytes()), truths=truths, seed=seed,
                locked_full_window=int(locked), lock_rate=rate, covered=int(covered),
                lock_depth_median_locked=float(np.median(d)) if len(d) else None, lock_depth_q90_locked=q(0.9),
                lock_depth_q99_locked=q(0.99), min_locked_at_99pct=need,
                omega_fibre_fraction_at_lock_median=float(np.median(om)) if om else None,
                gamma_fibre_fraction_at_lock_median=float(np.median(ga)) if ga else None,
                F1=(f'lock rate {rate:.3f} on the full window: of 10 / 15 / 20 test releases at least {need[10]} / {need[15]} / '
                    f'{need[20]} lock (probability >= 0.99 under the class)'),
                F2='every LOCKED or CORRESPONDENCE interval contains the measured target within the margin eps_total',
                F3='no test release is INCONSISTENT',
                F4='a release with the sail attached is INCONSISTENT',
                F5='reported, not a test: the gamma fibre span at the lock depth (outer cells), against the frozen median',
                F6='reported, not a test: coverage of the least-squares 95% interval next to the enclosure')


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest='cmd', required=True)
    p = sub.add_parser('predict'); p.add_argument('cls'); p.add_argument('--truths', type=int, default=200)
    p.add_argument('--seed', type=int, default=1); p.add_argument('--out', default='predictions.json')
    q = sub.add_parser('release'); q.add_argument('cls'); q.add_argument('csv'); q.add_argument('--out', default='release.json')
    c = sub.add_parser('calibrate'); c.add_argument('cls'); c.add_argument('csv'); c.add_argument('--t0', type=float, required=True)
    c.add_argument('--out', default='calibration.json')
    s = sub.add_parser('stage1'); s.add_argument('cls'); s.add_argument('csv'); s.add_argument('--t0', type=float, default=None)
    s.add_argument('--out', default='stage1.json')
    t = sub.add_parser('stage2'); t.add_argument('cls'); t.add_argument('csv'); t.add_argument('stage1'); t.add_argument('--out', default='stage2.json')
    a = ap.parse_args(); C = load_class(a.cls)
    if a.cmd == 'predict':
        out = predict(C, a.truths, a.seed)
    elif a.cmd == 'release':
        rt_, t0_ = release_time(C, a.csv); out = dict(release_time=rt_, t0=t0_, rule='median of first 0.5 s; first frame off by > 5 eps_track; t0 = release + 2 s')
    elif a.cmd == 'calibrate':
        out = calibrate(C, a.csv, a.t0)
    elif a.cmd == 'stage1':
        out = stage1(C, a.csv, a.t0)
    else:
        out = stage2(C, a.csv, json.loads(Path(a.stage1).read_text()))
    Path(a.out).write_text(json.dumps(out, indent=1, sort_keys=True)); print(json.dumps(out, indent=1, sort_keys=True))
    return 0


if __name__ == '__main__':
    sys.exit(main())
