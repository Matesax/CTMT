# Dimensional Closure in Resolution Geometry: The Unit Gauge, Anchors and Scale Rupture

Dimensional closure placed in RG as the unit gauge, then attacked with a seeded battery. Paper:
`RG - Dimensional Closure.pdf` (source `RG_Dimensional_Closure.tex`). The programme's main print and README are in
`Resolution Geometry.pdf` and `README.md`.

| File | What it is |
|---|---|
| `rg_units.py` | the unit gauge as computation: Pi groups, the unit hole, Fisher kernels, the SI anchors, a closure checker, certified oscillator exclusion, a certified task lock of the memory extension, and the similarity test |
| `rg_pendulum.py`, `class_default.json` | the filmed-pendulum enclosure, used for lock transfer (group UG) |
| `fixture/observable.json` | the frozen record: 121 samples at 0.1 s, of which the first 81 are training samples; bound 0.002; synthetic |
| `rg_units_battery.py` | groups UA–UK; writes `rg_units_battery_results.json` |
| `rg_units_battery_mutations.py` | twenty-four one-line falsifications; each must fail its target group |

```
pip install -r requirements.txt            # numpy, scipy, sympy
python3 -I rg_units_battery.py              # about 5 min (UJ about 4 min); byte-identical on rerun
python3 -I rg_units_battery_mutations.py --jobs 2
```

What the battery shows:
- **Buckingham is universal factorization.** Buckingham's theorem is RG's universal factorization applied to the unit
  group. The open unit directions are {D_sys^T s : D_anchor^T s = 0}.
- **The SI closes the unit gauge exactly.** The seven SI defining constants have rank 7, and each one is necessary.
- **The unit hole is the Fisher kernel.** In Schwarzschild records with G and c anchored, the Fisher kernel of
  dimensionless records is the predicted dilation, and a clock closes it. Lambda closes the dilation only when it is
  anchored. Holes split into a unit part and an intrinsic part.
- **Locks transfer under the unit gauge.** A lock transfers to 1e-8; a class that is not unit-closed does not transfer.
- **Scale rupture.** Complete similarity of the pendulum detects a hidden bob radius above 2.1 cm at bounds of
  0.2 ms and 0.5 mm.
- **Dimensions do not select; records do.** Three baseline families are excluded by cells and linear programmes. The
  memory extension locks x(12 s): the outer interval is [0.65007, 0.66419] and the held-out value lies inside. Local
  sampling had covered less than a fifth of the range.

Author: Matěj Rada, MatejRada@email.cz. License: CC BY-NC-ND 4.0.
