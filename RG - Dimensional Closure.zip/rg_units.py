#!/usr/bin/env python3
"""Resolution Geometry - dimensional closure as the unit gauge, as computation.

Dimensions are characters of the unit group U = (R_>0)^7 (bases M, L, T, I, Theta, N, J). A change of units by
s in R^7 (log scale per base) multiplies a quantity of dimension d by exp(d . s).

  pi_groups         integer basis of ker D (the dimensionless monomials of n quantities, D is 7 x n)
  unit_hole         directions D_sys^T s with D_anchor^T s = 0: the unit directions of the system parameters that no
                    anchor fixes (log coordinates)
  fisher_kernel     numerical kernel of a record map in log-parameter coordinates
  expression trees  random dimensioned expressions, a symbolic closure checker and a numerical scaling test
  SI_CONSTANTS      the seven defining constants of the 2019 SI with their dimension vectors
  exclude_oscillator  certified exclusion of a damped-oscillator family (with calibration or constant-force extension)
                    on bounded records: cells in (omega, gamma), one LP per cell in the linear coordinates, remainder
                    from a sub-grid (doubled), adaptive bisection. Status EXCLUDED, NOT EXCLUDED (with a witness cell
                    whose remainder is below eps/4) or UNDECIDED.
  similarity        period-length test of complete similarity T = C sqrt(L), and its repair with a declared length

numpy, scipy, sympy. Deterministic.
"""
from fractions import Fraction
import numpy as np
import sympy as sp
from scipy.optimize import linprog

BASES = ['M', 'L', 'T', 'I', 'Theta', 'N', 'J']


def dim(**kw):
    v = np.zeros(7)
    for k, e in kw.items():
        v[BASES.index(k)] = e
    return v


SI_CONSTANTS = {                                                  # 2019 SI defining constants
    'Delta_nu_Cs': dim(T=-1), 'c': dim(L=1, T=-1), 'h': dim(M=1, L=2, T=-1), 'e': dim(I=1, T=1),
    'k_B': dim(M=1, L=2, T=-2, Theta=-1), 'N_A': dim(N=-1), 'K_cd': dim(J=1, M=-1, L=-2, T=3)}


def pi_groups(D):
    """Integer basis of the kernel of the 7 x n dimension matrix D (sympy, exact)."""
    M = sp.Matrix(np.asarray(D).astype(int).tolist()); out = []
    for v in M.nullspace():
        den = sp.ilcm(*[sp.fraction(x)[1] for x in v]) if len(v) else 1
        w = [int(x * den) for x in v]; g = int(np.gcd.reduce(np.abs(w))) or 1
        out.append([x // g for x in w])
    return out


def unit_hole(D_sys, D_anchor):
    """Basis of {D_sys^T s : D_anchor^T s = 0} (columns = system parameters / anchors)."""
    D_sys = np.atleast_2d(D_sys); D_anchor = np.zeros((7, 0)) if D_anchor is None else np.atleast_2d(D_anchor)
    if D_anchor.shape[1]:
        _, s_, Vt = np.linalg.svd(D_anchor.T); r = int(np.sum(s_ > 1e-12)); S = Vt[r:].T
    else:
        S = np.eye(7)
    G = D_sys.T @ S
    if G.size == 0:
        return np.zeros((D_sys.shape[1], 0))
    U, s2, _ = np.linalg.svd(G, full_matrices=False); r2 = int(np.sum(s2 > 1e-10))
    return U[:, :r2]


def fisher_kernel(f, p, h=1e-6, rel=1e-7, floor=1e-8):
    """Kernel of the Jacobian of f at log-parameters p (central differences), and its singular values. A singular
    value counts when it exceeds rel times the largest and the absolute floor (a constant record has no rank)."""
    p = np.asarray(p, float)
    J = np.array([(np.atleast_1d(f(p + h * e)) - np.atleast_1d(f(p - h * e))) / (2 * h) for e in np.eye(len(p))]).T
    U, s, Vt = np.linalg.svd(J); r = int(np.sum(s > max(rel * s[0], floor))) if len(s) else 0
    return Vt[r:].T, s


def subspace_gap(A, B):
    """Largest principal-angle sine between the column spans of A and B (0 if equal)."""
    if A.shape[1] != B.shape[1]:
        return 1.0
    if A.shape[1] == 0:
        return 0.0
    Qa, _ = np.linalg.qr(A); Qb, _ = np.linalg.qr(B)
    return float(np.linalg.norm(Qa - Qb @ (Qb.T @ Qa), 2))


# ------------------------------------------------------------------ expression trees
def random_expr(rng, nvar, depth):
    if depth == 0 or rng.random() < 0.25:
        return ('var', int(rng.integers(nvar)))
    op = rng.choice(['mul', 'div', 'pow', 'add', 'exp'], p=[0.3, 0.2, 0.15, 0.25, 0.1])
    if op in ('mul', 'div', 'add'):
        return (op, random_expr(rng, nvar, depth - 1), random_expr(rng, nvar, depth - 1))
    if op == 'pow':
        return ('pow', random_expr(rng, nvar, depth - 1), int(rng.choice([-2, -1, 2, 3])))
    return ('exp', random_expr(rng, nvar, depth - 1))


def check(e, dims):
    """Symbolic closure check: the dimension vector, or None when the expression is malformed."""
    k = e[0]
    if k == 'var':
        return dims[e[1]]
    if k == 'pow':
        a = check(e[1], dims); return None if a is None else a * e[2]
    if k == 'exp':
        a = check(e[1], dims); return None if a is None or np.any(a != 0) else np.zeros(7)
    a, b = check(e[1], dims), check(e[2], dims)
    if a is None or b is None:
        return None
    if k == 'mul':
        return a + b
    if k == 'div':
        return a - b
    return a if np.all(a == b) else None                          # add


def evaluate(e, vals):
    k = e[0]
    if k == 'var':
        return vals[e[1]]
    if k == 'pow':
        return evaluate(e[1], vals) ** e[2]
    if k == 'exp':
        return np.exp(np.clip(evaluate(e[1], vals), -50, 50))
    a, b = evaluate(e[1], vals), evaluate(e[2], vals)
    return a * b if k == 'mul' else (a / b if k == 'div' else a + b)


def scaling_test(e, dims, rng, trials=3):
    """Numerical closure: under a random unit change, does the value transform by a single character exp(d . s)?
    Returns the dimension inferred from the scaling (or None if no character fits)."""
    vals = rng.uniform(0.5, 2.0, len(dims)); f0 = evaluate(e, vals)
    if not np.isfinite(f0) or f0 == 0:
        return 'degenerate'
    S = rng.normal(size=(trials + 7, 7)) * 0.3; logs = []
    for s in S:
        v2 = vals * np.exp(np.array([d @ s for d in dims])); f1 = evaluate(e, v2)
        if not np.isfinite(f1) or f1 <= 0 or f0 <= 0:
            return 'degenerate'
        logs.append(np.log(f1 / f0))
    d, res, *_ = np.linalg.lstsq(S, np.array(logs), rcond=None)
    if np.max(np.abs(S @ d - np.array(logs))) > 1e-8:
        return None
    return np.round(d, 6)


# ------------------------------------------------------------------ certified exclusion of oscillator families
def _basis(om, ga, t):
    wd = np.sqrt(np.maximum(om * om - ga * ga, 1e-12)); e = np.exp(-ga * t)
    return e * (np.cos(wd * t) + ga / wd * np.sin(wd * t)), e * np.sin(wd * t) / wd


def _cell(t, y, eps, oc, gc, ho, hg, mode, X, off, fmax, sub=5):
    a, b = _basis(oc, gc, t)
    Ra = np.zeros_like(t); Rb = np.zeros_like(t)
    for o in np.linspace(oc - ho, oc + ho, sub):
        for g in np.linspace(max(gc - hg, 0.0), gc + hg, sub):
            aa, bb = _basis(o, g, t); Ra = np.maximum(Ra, np.abs(aa - a)); Rb = np.maximum(Rb, np.abs(bb - b))
    cols = [a, b]; bnd = [(-X, X), (-X, X)]; R = X * Ra + X * Rb
    if mode == 'calibration':
        cols.append(np.ones_like(t)); bnd.append((-off, off))
    if mode == 'known_force':
        xe = fmax / (oc - ho) ** 2; cols.append(1 - a); bnd.append((-xe, xe)); R = R + xe * Ra
    R = 2 * R
    Mx = np.array(cols).T
    res = linprog(np.zeros(Mx.shape[1]), A_ub=np.vstack([Mx, -Mx]), b_ub=np.r_[y + eps + R, eps + R - y], bounds=bnd, method='highs')
    return res.status == 0, float(R.max())


def exclude_oscillator(t, y, eps, mode, om=(0.8, 1.3), ga=(0.0, 0.12), X=1.5, gain=0.02, ts=0.02, off=0.02, fmax=0.03, cap=100000):
    """Certified (numerical-remainder) exclusion of x'' + 2 gamma x' + omega^2 x = 0 with |x0|, |v0| <= X, optionally
    with gain, time-scale and offset calibration ('calibration') or a constant force ('known_force'). The time scale is
    absorbed into (omega, gamma) and the gain into the initial-condition box."""
    olo, ohi, ghi = om[0], om[1], ga[1]
    if mode == 'calibration':
        olo, ohi, ghi = olo * (1 - ts), ohi * (1 + ts), ghi * (1 + ts); X = X * (1 + gain) * (1 + ts)
    q = [(olo + (i + 0.5) * (ohi - olo) / 40, (j + 0.5) * ghi / 10, (ohi - olo) / 80, ghi / 20) for i in range(40) for j in range(10)]
    tested = 0
    while q:
        oc, gc, ho, hg = q.pop(); f, R = _cell(t, y, eps, oc, gc, ho, hg, mode, X, off, fmax); tested += 1
        if not f:
            continue
        if R < eps / 4:
            return dict(status='NOT EXCLUDED', cells=tested, witness=[oc, gc])
        if tested > cap:
            return dict(status='UNDECIDED', cells=tested)
        if ho / (ohi - olo) > hg / ghi:
            q += [(oc - ho / 2, gc, ho / 2, hg), (oc + ho / 2, gc, ho / 2, hg)]
        else:
            q += [(oc, gc - hg / 2, ho, hg / 2), (oc, gc + hg / 2, ho, hg / 2)]
    return dict(status='EXCLUDED', cells=tested)


def oscillator(t, om, ga, x0, v0):
    a, b = _basis(om, ga, t)
    return x0 * a + v0 * b


# ------------------------------------------------------------------ complete similarity and scale rupture
def similarity_test(L, T, eL, eT, a_range=None):
    """Complete similarity T = C sqrt(L) (a_range None), or the repaired law T = C sqrt((L^2 + 0.4 a^2) / L) with the
    bob radius a in a_range. Each record gives an interval for C; the class is INCONSISTENT iff they do not meet."""
    L = np.asarray(L, float); T = np.asarray(T, float)
    if a_range is None:
        lo = (T - eT) / np.sqrt(L + eL); hi = (T + eT) / np.sqrt(L - eL)
    else:
        g = lambda LL, a: np.sqrt((LL ** 2 + 0.4 * a ** 2) / LL)
        cand = [g(LL, a) for LL in (L - eL, L + eL) for a in a_range]
        lo = (T - eT) / np.max(cand, axis=0); hi = (T + eT) / np.min(cand, axis=0)
    l, u = float(lo.max()), float(hi.min())
    return dict(status='INCONSISTENT' if l > u else 'CONSISTENT', C_interval=[l, u])


# ------------------------------------------------------------------ certified task interval of a memory-extended oscillator
def memory_basis(P, K, dt=0.1):
    """Records of x'' + 2 gamma x' + omega^2 x = beta z, z' = -lambda z + x' (z(0) = 0), as integrated by classical RK4 at
    step dt: x_k = x0 a_k + v0 b_k. P is an (n, 4) array of (omega, gamma, beta, lambda). Returns a, b of shape (n, K+1)."""
    P = np.atleast_2d(P); n = len(P); om, ga, be, la = P.T
    A = np.zeros((n, 3, 3)); A[:, 0, 1] = 1; A[:, 1, 0] = -om * om; A[:, 1, 1] = -2 * ga; A[:, 1, 2] = be
    A[:, 2, 1] = 1; A[:, 2, 2] = -la
    H = dt * A; I3 = np.broadcast_to(np.eye(3), H.shape); H2 = H @ H; Ms = I3 + H + H2 / 2 + H2 @ H / 6 + H2 @ H2 / 24
    S = np.zeros((n, 3, 2)); S[:, 0, 0] = 1; S[:, 1, 1] = 1; a = np.empty((n, K + 1)); b = np.empty((n, K + 1))
    for k in range(K + 1):
        a[:, k] = S[:, 0, 0]; b[:, k] = S[:, 0, 1]; S = Ms @ S
    return a, b


def mem_cell(c, h, y, eps, task_k, lo_, hi_, Xx, X, K, dt, offs, order=1):
    """One cell of lock_memory: None when the relaxed LP is infeasible, else (L_c, U_c, a0, b0, task row)."""
    m = len(y); fd = 1e-6
    pts = np.clip(c + offs * h, lo_, hi_)
    fdp = np.vstack([c + fd * e for e in np.eye(4)] + [c - fd * e for e in np.eye(4)])
    a, b = memory_basis(np.vstack([c, pts, fdp]), K, dt); n = len(pts)
    a0, b0, ap, bp = a[0], b[0], a[1:n + 1], b[1:n + 1]
    da = (a[n + 1:n + 5] - a[n + 5:n + 9]) / (2 * fd) * order; db = (b[n + 1:n + 5] - b[n + 5:n + 9]) / (2 * fd) * order
    dP = pts - c
    Ra = 2 * np.abs(ap - a0 - dP @ da).max(0); Rb = 2 * np.abs(bp - b0 - dP @ db).max(0)
    Mx = np.c_[a0[:m], b0[:m], da[:, :m].T, db[:, :m].T]; A_ub = np.vstack([Mx, -Mx])
    tv = np.r_[a0[task_k], b0[task_k], da[:, task_k], db[:, task_k]]
    Xv, ok = X, True
    bnds = lambda Xv: [(-Xx, Xx), (-Xv, Xv)] + [(-Xx * hh, Xx * hh) for hh in h] + [(-Xv * hh, Xv * hh) for hh in h]
    ev = np.zeros(10); ev[1] = 1
    for _ in range(2):                                     # tighten |v0| with the cell's own outer LP
        R = Xx * Ra + Xv * Rb; ub = np.r_[y + eps + R[:m], eps + R[:m] - y]
        r = [linprog(sg * ev, A_ub=A_ub, b_ub=ub, bounds=bnds(Xv), method='highs') for sg in (1, -1)]
        if r[0].status == 2 or r[1].status == 2:
            ok = False; break
        if r[0].status == 0 and r[1].status == 0:
            Xv = min(Xv, max(abs(r[0].fun), abs(r[1].fun)))
    if not ok:
        return None
    R = Xx * Ra + Xv * Rb; ub = np.r_[y + eps + R[:m], eps + R[:m] - y]
    r1 = linprog(tv, A_ub=A_ub, b_ub=ub, bounds=bnds(Xv), method='highs')
    r2 = linprog(-tv, A_ub=A_ub, b_ub=ub, bounds=bnds(Xv), method='highs')
    if r1.status == 2 or r2.status == 2:
        return None
    if r1.status != 0 or r2.status != 0:                       # numerical trouble: never drop, refine
        L_c, U_c = -np.inf, np.inf
    else:
        L_c, U_c = r1.fun - R[task_k], -r2.fun + R[task_k]
    return L_c, U_c, a0, b0, tv


def lock_memory(y, eps, task_k, box=((0.8, 1.3), (0.0, 0.12), (0.12, 0.18), (0.25, 0.45)), X=1.5, dt=0.1, sub=3,
                tol=1e-3, cap=40000, init=(10, 4, 3, 3), hmin=1e-6, order=1, seeds=()):
    """Outer task interval of x(task_k dt) over the memory family consistent with the records y (samples 0..len(y)-1),
    by branch and bound in theta = (omega, gamma, beta, lambda).

    In a cell with centre c and half-widths h the record is modelled as
        x_k = x0 a_k(c) + v0 b_k(c) + sum_i (u_i d_i a_k(c) + w_i d_i b_k(c)) +- r_k,
    with u_i = x0 (theta_i - c_i), w_i = v0 (theta_i - c_i) relaxed to |u_i| <= Xx h_i, |w_i| <= Xv h_i (order=1; order=0
    drops the linear terms). The remainder r_k is the sub-grid maximum of the deviation from this model, doubled.
    Initial-condition bounds: |x0| <= |y_0| + eps (exact: a_0 = 1, b_0 = 0) and |v0| <= X, tightened by the cell's own
    LP. A cell whose LP (records within eps + r) is infeasible is dropped; a feasible cell contributes its LP task range
    widened by the task remainder. An inner interval is built from exact members (zero remainder at the centre). A cell
    is refined while its contribution reaches more than tol beyond the inner interval. On success the outer interval
    contains every member's task value and exceeds the inner interval by at most tol on each side. Seeds (points of
    theta, e.g. from a local optimizer) are checked exactly and, when members, start the inner interval; they change
    the work, never the certificate.
    Returns EMPTY, INTERVAL (outer, inner, witness) or UNDECIDED (cap or minimal cell)."""
    import heapq
    box = np.array(box, float); K = max(task_k, len(y) - 1); m = len(y); lo_, hi_ = box[:, 0], box[:, 1]
    w0 = (hi_ - lo_) / np.array(init); Xx = abs(y[0]) + eps
    grid = np.stack(np.meshgrid(*[lo_[i] + (np.arange(init[i]) + 0.5) * w0[i] for i in range(4)], indexing='ij'), -1).reshape(-1, 4)
    offs = np.stack(np.meshgrid(*[np.linspace(-1, 1, sub)] * 4, indexing='ij'), -1).reshape(-1, 4)
    heap = [(0.0, k, c, w0 / 2) for k, c in enumerate(grid)]; heapq.heapify(heap); ctr = len(grid)
    tested = 0; ilo, ihi = np.inf, -np.inf; olo, ohi = np.inf, -np.inf; witness = None
    for sd in seeds:                                               # exact members among the seeds
        sd = np.clip(np.asarray(sd, float), lo_, hi_); a, b = memory_basis(sd, K, dt); M0 = np.c_[a[0, :m], b[0, :m]]
        tv0 = np.array([a[0, task_k], b[0, task_k]]); A0 = np.vstack([M0, -M0]); ub0 = np.r_[y + eps, eps - y]
        e1 = linprog(tv0, A_ub=A0, b_ub=ub0, bounds=[(-X, X)] * 2, method='highs')
        e2 = linprog(-tv0, A_ub=A0, b_ub=ub0, bounds=[(-X, X)] * 2, method='highs')
        if e1.status == 0 and e2.status == 0:
            ilo, ihi = min(ilo, e1.fun), max(ihi, -e2.fun); witness = witness or sd.tolist()
    while heap:
        _, _, c, h = heapq.heappop(heap); tested += 1
        if tested > cap:
            return dict(status='UNDECIDED', cells=tested, reason='cap')
        cell = mem_cell(c, h, y, eps, task_k, lo_, hi_, Xx, X, K, dt, offs, order)
        if cell is None:
            continue
        L_c, U_c, a0, b0, tv = cell
        M0 = np.c_[a0[:m], b0[:m]]; ub0 = np.r_[y + eps, eps - y]  # exact members at the centre
        e1 = linprog(tv[:2], A_ub=np.vstack([M0, -M0]), b_ub=ub0, bounds=[(-X, X)] * 2, method='highs')
        if e1.status == 0:
            e2 = linprog(-tv[:2], A_ub=np.vstack([M0, -M0]), b_ub=ub0, bounds=[(-X, X)] * 2, method='highs')
            ilo, ihi = min(ilo, e1.fun), max(ihi, -e2.fun)
            if witness is None:
                witness = c.tolist()
        excess = max(ilo - tol - L_c, U_c - ihi - tol) if np.isfinite(ilo) else np.inf
        if excess <= 0:
            olo, ohi = min(olo, L_c), max(ohi, U_c); continue
        rel = h / (hi_ - lo_)
        if rel.max() < hmin:
            return dict(status='UNDECIDED', cells=tested, reason='minimal cell')
        i = int(np.argmax(rel)); d = np.zeros(4); d[i] = h[i] / 2; h2 = h.copy(); h2[i] /= 2
        pr = -(U_c - L_c)
        heapq.heappush(heap, (pr, ctr, c - d, h2)); heapq.heappush(heap, (pr, ctr + 1, c + d, h2)); ctr += 2
    if witness is None:
        return dict(status='EMPTY' if not np.isfinite(olo) else 'UNDECIDED', cells=tested)
    return dict(status='INTERVAL', cells=tested, outer=[float(olo), float(ohi)], inner=[float(ilo), float(ihi)],
                diameter=float(ohi - olo), witness=witness)
