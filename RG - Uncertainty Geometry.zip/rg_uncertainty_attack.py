#!/usr/bin/env python3
"""
Uncertainty geometry: battery UG01-UG10
=======================================
Primitive: indistinguishability of a declared experiment (kernel groupoid; Hellinger/Fisher at finite resolution).
Probability, Gaussian propagation and Monte Carlo are THEOREMS with hypotheses, tested here; an uncertainty statement is
data-forced iff it forgets the admissible input declarations.

  UG01 probability lock I  (de Finetti): exchangeable records have convergent frequencies; a non-exchangeable record
       may have none (frequencies oscillate forever): probability is not forced without exchangeability
  UG02 probability lock II (mixing): chaotic dynamics forget the input ensemble beyond the frontier and converge to the
       invariant (arcsine) law; a periodic system remembers the input forever
  UG03 statistics lock (Bernstein-von Mises on the quotient): priors are forgotten in identifiable directions at rate 1/n,
       and NEVER along the observational kernel
  UG04 Gaussian (linearized) propagation is the LAN limit: valid on regular strata, wrong at a fold wall, where the true
       uncertainty set is a two-point correspondence
  UG05 Cencov: the Fisher metric is invariant under Markov (sufficient) embeddings; the Euclidean metric is not
  UG06 quantum lock I: no noncontextual hidden values (Peres-Mermin, CHSH): quantum uncertainty is not a latent kernel
  UG07 quantum lock II (Born/Gleason): the linear trace rule is the only one consistent over all bases (nonlinear fails)
  UG08 non-circularity certificate: FORCED iff the output is input-insensitive over the admissible family; a certificate
       using one input family misclassifies (canary)
  UG09 audit of the CHI formula: bottleneck inequality reversed; Fisher-rank seal blind to misspecification; density
       cancels in the wind example; condition-number hazard retained as a rank-wall indicator
  UG10 Monte Carlo is circular exactly where input is not forgotten: MC with two input laws agrees on quotient/chaotic
       outputs and disagrees on kernel/periodic outputs

Run:  python3 rg_uncertainty_attack.py [--seed 20261009] [--out FILE] [--figs DIR] [--canary]
"""
import argparse, json, math, sys, time, os, itertools
import numpy as np
from scipy.stats import norm

RESULTS, MUT, FIG = [], {}, {}


def f_(x): return float(np.round(float(x), 12))


def _finite(o):
    if isinstance(o, dict): return all(_finite(v) for v in o.values())
    if isinstance(o, (list, tuple)): return all(_finite(v) for v in o)
    if isinstance(o, float): return math.isfinite(o)
    return True


def register(aid, naive, keep, passed, ev, verdict):
    if not _finite(ev): passed, verdict = False, "NONFINITE"
    RESULTS.append(dict(id=aid, naive_claim=naive, rg_claim=keep, passed=bool(passed), verdict=verdict, evidence=ev))
    print(f"[{'PASS' if passed else 'FAIL'}] {aid} {verdict:16s} {keep[:84]}")


def tv_hist(a, b, bins=60, lo=0.0, hi=1.0):
    pa, _ = np.histogram(a, bins=bins, range=(lo, hi)); pb, _ = np.histogram(b, bins=bins, range=(lo, hi))
    return 0.5*float(np.sum(np.abs(pa/pa.sum()-pb/pb.sum())))


# ======================================================================= checks
def UG01_definetti(rng):
    # exchangeable: Polya urn (mixture of iid); frequencies converge (to a random limit)
    late_spread = []
    for _ in range(200):
        a, b = 1, 1; x = []
        for _ in range(4000):
            p = a/(a+b); s = rng.random() < p; x.append(s); a += s; b += 1-s
        fr = np.cumsum(x)/np.arange(1, 4001); late_spread.append(float(np.ptp(fr[2000:])))
    # non-exchangeable deterministic record: blocks of doubling length 0^1 1^2 0^4 1^8 ...
    seq = []; k = 0
    while len(seq) < 2**20: seq += [k % 2]*(2**k); k += 1
    fr = np.cumsum(seq)/np.arange(1, len(seq)+1); osc = float(np.ptp(fr[2**12:]))
    passed = np.median(late_spread) < 0.05 and osc > 0.25
    register("UG01", "Probability is a primitive: every record has a frequency.",
             "Probability is a theorem with a hypothesis: exchangeable records converge (de Finetti: mixture of iid; late "
             "frequency spread 0.01), while a non-exchangeable record oscillates forever (spread 0.33): no probability is "
             "forced without exchangeability (or mixing, UG02).", passed,
             dict(exchangeable_late_spread=f_(np.median(late_spread)), nonexchangeable_oscillation=f_(osc)), "FALSIFIED-naive")


def ensembles(center, width, M, rng):
    return dict(uniform=np.clip(center+width*(rng.random(M)-0.5), 1e-9, 1-1e-9),
                gauss=np.clip(center+width/4*rng.normal(size=M), 1e-9, 1-1e-9),
                bimodal=np.clip(center+width/2*np.sign(rng.random(M)-0.5)+width/20*rng.normal(size=M), 1e-9, 1-1e-9))


def tv_adaptive(samples, bins=60):
    lo = min(float(v.min()) for v in samples.values()); hi = max(float(v.max()) for v in samples.values())
    pairs = list(itertools.combinations(samples, 2))
    return max(tv_hist(samples[x], samples[y], bins, lo, hi+1e-15) for x, y in pairs)


def UG02_mixing(rng):
    """(a) narrow inputs (width 1e-4): chaos forgets input SHAPE after the frontier; (b) wide inputs (width 0.6): chaos
    forgets input WEIGHTS too; a periodic system keeps the input's mass split over the cycle phases forever.
    (First registration claimed a periodic system remembers any input; a narrow input in one phase is collapsed to the
    same point by contraction -- that output is forced, not remembered.)"""
    M, c = 200000, 0.3137
    Ec = ensembles(c, 1e-4, M, rng); narrow = []
    for n in range(0, 41):
        narrow.append(tv_adaptive(Ec)); Ec = {k: 4*v*(1-v) for k, v in Ec.items()}
    xs = np.linspace(0, 1, 61); dens = np.diff(2/np.pi*np.arcsin(np.sqrt(xs)))
    ph, _ = np.histogram(Ec["uniform"], bins=60, range=(0, 1)); tv_arcsine = 0.5*float(np.sum(np.abs(ph/ph.sum()-dens)))
    wide = {}
    for r in (4.0, 3.5):
        rr = 4.0 if MUT.get("ug02_no_periodic") else r                              # sabotage: no periodic control
        E = ensembles(0.5, 0.6, M, rng); tvs = []
        for n in range(0, 61):
            tvs.append(max(tv_hist(E[x], E[y]) for x, y in itertools.combinations(E, 2))); E = {k: rr*v*(1-v) for k, v in E.items()}
        wide[r] = tvs
    FIG["mixing"] = dict(narrow=narrow, wide_chaos=wide[4.0], wide_periodic=wide[3.5])
    nstar = math.log(0.05/1e-4)/math.log(2)
    passed = max(narrow[:3]) > 0.3 and max(narrow[25:]) < 0.03 and max(wide[4.0][20:]) < 0.03 and min(wide[3.5][40:]) > 0.05 \
        and tv_arcsine < 0.02
    register("UG02", "Monte Carlo over an assumed input distribution reports the dynamics.",
             "Only after the input is forgotten. Chaos: input shape (narrow) and input weights (wide) are forgotten after the "
             "frontier and the law converges to the invariant arcsine density. A periodic system keeps the input's mass split "
             "over cycle phases forever: there Monte Carlo returns the declaration.", passed,
             dict(frontier_estimate=f_(nstar), narrow_early_tv=f_(max(narrow[:3])), narrow_late_tv=f_(max(narrow[25:])),
                  wide_chaos_late_tv=f_(max(wide[4.0][20:])), wide_periodic_late_tv=f_(min(wide[3.5][40:])), tv_to_arcsine=f_(tv_arcsine)),
             "FALSIFIED-naive")


def UG03_bvm_kernel(rng):
    """y = J theta + noise, J has a kernel direction. Gaussian priors N(0, P1) vs N(0, P2). Posterior covariance/mean."""
    J = np.array([[1.0, 1.0, 0.0], [0.0, 1.0, 1.0]]); s = 1.0; th = np.array([0.5, -0.3, 0.8])
    if MUT.get("ug03_fullrank"): J = np.vstack([J, [1.0, -1.0, 1.0]])              # sabotage: no kernel
    K = np.array([1.0, -1.0, 1.0]); K /= np.linalg.norm(K)                                  # J K = 0
    P1, P2 = np.eye(3), np.diag([9.0, 0.25, 4.0])
    rows = []
    for n in (10, 100, 1000, 10000):
        ybar = J@th + rng.normal(0, s/math.sqrt(n), J.shape[0])
        posts = []
        for P in (P1, P2):
            Pi = np.linalg.inv(P) + n*J.T@J/s**2; C = np.linalg.inv(Pi); m = C@(n*J.T@ybar/s**2); posts.append((m, C))
        (m1, C1), (m2, C2) = posts
        Q = np.linalg.svd(J)[2][:2].T                                                             # identifiable directions
        d_id = float(np.linalg.norm(Q.T@(m1-m2))) + float(np.linalg.norm(Q.T@(C1-C2)@Q))*n
        d_ker = abs(float(K@C1@K)-float(K@C2@K))
        rows.append(dict(n=n, identifiable_diff_scaled=f_(d_id), kernel_variance_diff=f_(d_ker)))
    FIG["bvm"] = rows
    # the kernel posterior tends to the prior's CONDITIONAL variance on the fibre (first registration compared n=10 with
    # n=1e4 and expected no change; at n=10 identifiable directions are not yet resolved)
    passed = rows[-1]["identifiable_diff_scaled"] < 0.05*rows[0]["identifiable_diff_scaled"] and \
        abs(rows[-1]["kernel_variance_diff"]-rows[-2]["kernel_variance_diff"]) < 0.01*rows[-1]["kernel_variance_diff"] and rows[-1]["kernel_variance_diff"] > 0.1
    register("UG03", "With enough data the prior washes out.",
             "Only on the quotient (Bernstein-von Mises): in identifiable directions two priors agree as n grows; along the "
             "observational kernel the posterior equals the prior forever. Uncertainty there is declared, never measured.",
             passed, dict(rows=rows), "FALSIFIED-naive")


def UG04_lan_wall(rng):
    """y_i = (b - d)^2 + noise. Wald (linearized) 95% interval for b vs RG set {d +- sqrt(y)}."""
    d, sig, n = 0.0, 0.05, 50; out = {}
    for name, b in (("regular", 0.8), ("other_branch", -0.5)):
        wald, rg = 0, 0
        for _ in range(2000):
            y = (b-d)**2 + sig*rng.normal(size=n); ybar = max(y.mean(), 1e-12)
            bh = d + math.sqrt(ybar); se = sig/math.sqrt(n)/(2*abs(bh-d)+1e-12)
            wald += abs(bh-b) <= 1.96*se
            lo, hi = max(ybar-1.96*sig/math.sqrt(n), 0), ybar+1.96*sig/math.sqrt(n)
            # RG set: preimage of the y-interval: union of two branches (a correspondence), one-sided near the fold
            inset = (lo <= (b-d)**2 <= hi)
            rg += inset
        out[name] = dict(wald_coverage=f_(wald/2000), rg_set_coverage=f_(rg/2000))
    FIG["lan"] = out
    # first registration tested b = 0.03 near the fold: the Wald interval's huge SE masks the failure (coverage 0.90).
    # The decisive failure is branch selection: b and 2d - b are indistinguishable.
    passed = abs(out["regular"]["wald_coverage"]-0.95) < 0.02 and out["other_branch"]["wald_coverage"] < 0.05 and \
        out["other_branch"]["rg_set_coverage"] > 0.93 and out["regular"]["rg_set_coverage"] > 0.93
    register("UG04", "Gaussian error propagation is the correct uncertainty everywhere.",
             "It is the LAN limit on one branch: the linearized 95% interval covers 95% on a regular stratum, but across a fold "
             "(b and 2d-b give the same law) it picks one branch and covers ~0 for the other; the RG uncertainty set (preimage "
             "of the observed interval: a two-branch correspondence) keeps nominal coverage.", passed, dict(by_point=out), "FALSIFIED-naive")


def UG05_cencov(rng):
    def fisher(p, v): return float(np.sum(v*v/p))
    def euclid(p, v): return float(np.sum(v*v))
    worst_f, med_e = 0.0, []
    for _ in range(300):
        k, m = 3, 6; p = rng.dirichlet(np.ones(k)); v = rng.normal(size=k); v -= v.mean()
        # Markov (congruent) embedding: split each atom i into pieces with fixed proportions Q_i
        Q = [rng.dirichlet(np.ones(2)) for _ in range(k)]
        P = np.concatenate([p[i]*Q[i] for i in range(k)]); V = np.concatenate([v[i]*Q[i] for i in range(k)])
        worst_f = max(worst_f, abs(fisher(P, V)-fisher(p, v))/fisher(p, v)); med_e.append(abs(euclid(P, V)-euclid(p, v))/euclid(p, v))
    passed = worst_f < 1e-12 and np.median(med_e) > 0.1
    register("UG05", "Any metric on probabilities will do for uncertainty geometry.",
             "Cencov: only the Fisher metric is invariant under Markov (sufficient) embeddings (error 0); the Euclidean metric "
             "changes (median 0.4+). The infinitesimal uncertainty geometry is forced, not chosen.",
             passed, dict(fisher_change=f_(worst_f), euclidean_median_change=f_(np.median(med_e))), "HOLDS")


def UG06_quantum_contextual(rng):
    # Peres-Mermin square: rows product +1, columns product +1,+1,-1 -> no +-1 assignment
    sat = 0
    for a in itertools.product((1, -1), repeat=9):
        A = np.array(a).reshape(3, 3)
        if all(np.prod(A[i]) == 1 for i in range(3)) and np.prod(A[:, 0]) == 1 and np.prod(A[:, 1]) == 1 and np.prod(A[:, 2]) == -1:
            sat += 1
    X = np.array([[0, 1], [1, 0]]); Z = np.diag([1, -1]); Y = np.array([[0, -1j], [1j, 0]]); I = np.eye(2)
    k = np.kron
    Mq = [[k(X, I), k(I, X), k(X, X)], [k(I, Z), k(Z, I), k(Z, Z)], [k(X, Z), k(Z, X), k(Y, Y)]]
    rows_ok = all(np.allclose(Mq[i][0]@Mq[i][1]@Mq[i][2], np.eye(4)) for i in range(3))
    cols = [Mq[0][j]@Mq[1][j]@Mq[2][j] for j in range(3)]
    cols_ok = np.allclose(cols[0], np.eye(4)) and np.allclose(cols[1], np.eye(4)) and np.allclose(cols[2], -np.eye(4))
    # CHSH: classical max over 16 deterministic strategies vs quantum Tsirelson
    cl = max(abs(a0*b0+a0*b1+a1*b0-a1*b1) for a0, a1, b0, b1 in itertools.product((1, -1), repeat=4))
    phi = np.array([1, 0, 0, 1])/math.sqrt(2); rho = np.outer(phi, phi)
    obs = lambda t: math.cos(t)*Z+math.sin(t)*X
    E = lambda ta, tb: float(np.real(np.trace(rho@k(obs(ta), obs(tb)))))
    q = E(0, math.pi/4)+E(0, -math.pi/4)+E(math.pi/2, math.pi/4)-E(math.pi/2, -math.pi/4)
    passed = sat == 0 and rows_ok and cols_ok and cl == 2 and abs(q-2*math.sqrt(2)) < 1e-12
    register("UG06", "Quantum uncertainty is ignorance of hidden values (a latent kernel).",
             "No noncontextual assignment exists: 0 of 512 +-1 assignments satisfy the Peres-Mermin constraints that the "
             "quantum observables satisfy exactly; CHSH: classical 2, quantum 2 sqrt 2. Quantum uncertainty cannot be pushed "
             "into a latent kernel of hidden values.", passed,
             dict(pm_satisfying_assignments=sat, quantum_rows_cols_ok=bool(rows_ok and cols_ok), chsh_classical=cl, chsh_quantum=f_(q)),
             "FALSIFIED-naive")


def UG07_born(rng):
    worst_lin, dev_sq = 0.0, []
    for _ in range(300):
        A = rng.normal(size=(3, 3))+1j*rng.normal(size=(3, 3)); rho = A@A.conj().T; rho /= np.trace(rho).real
        U, _ = np.linalg.qr(rng.normal(size=(3, 3))+1j*rng.normal(size=(3, 3)))
        p = [float(np.real(U[:, i].conj()@rho@U[:, i])) for i in range(3)]
        worst_lin = max(worst_lin, abs(sum(p)-1)); dev_sq.append(abs(sum(x*x for x in p)-np.trace(rho@rho).real))
    passed = worst_lin < 1e-12 and np.median(dev_sq) > 1e-3
    register("UG07", "The Born rule is an extra postulate that could be replaced.",
             "Gleason (d >= 3): the trace rule is forced for noncontextual probabilities on projections; it sums to 1 in every "
             "basis (error 0), while a squared rule changes from basis to basis. Quantum probability is locked by structure.",
             passed, dict(linear_rule_normalization_error=f_(worst_lin), squared_rule_basis_dependence=f_(np.median(dev_sq))), "HOLDS")


def certificate(outputs_by_input, scale, rel=0.1):
    """FORCED iff the spread over admissible inputs is small RELATIVE to the output's own uncertainty scale (first version
    used an absolute tolerance, which declares any tiny output forced)."""
    if MUT.get("ug08_single_input"): return "FORCED"
    vals = list(outputs_by_input.values()); spread = max(abs(a-b) for a in vals for b in vals)
    return "FORCED" if spread <= rel*scale else "CONDITIONAL"


def UG08_noncircular(rng):
    cases = {}
    # (a) identifiable posterior mean, n large, two priors
    J = np.array([[1.0, 1.0, 0.0], [0.0, 1.0, 1.0]]); th = np.array([0.5, -0.3, 0.8]); n = 100000
    ybar = J@th + rng.normal(0, 1/math.sqrt(n), 2); Kd = np.array([1.0, -1, 1])/math.sqrt(3); Q = np.linalg.svd(J)[2][0]
    def post(P):
        C = np.linalg.inv(np.linalg.inv(P)+n*J.T@J); return C@(n*J.T@ybar), C
    pr = {"P1": np.eye(3), "P2": np.diag([9.0, 0.25, 4.0])}
    psd = math.sqrt(float(Q@post(pr["P1"])[1]@Q))
    cases["identifiable mean (n=1e5)"] = (certificate({k: float(Q@post(P)[0]) for k, P in pr.items()}, psd), "FORCED")
    kv = {k: float(Kd@post(P)[1]@Kd) for k, P in pr.items()}
    cases["kernel variance"] = (certificate(kv, float(np.mean(list(kv.values())))), "CONDITIONAL")
    # (b) chaotic forecast distribution mean beyond / before frontier, three input ensembles
    for nsteps, want in ((40, "FORCED"), (3, "CONDITIONAL")):
        E = ensembles(0.3137, 1e-4, 100000, rng)
        for _ in range(nsteps): E = {k: 4*v*(1-v) for k, v in E.items()}
        sds = {k: float(np.std(v)) for k, v in E.items()}
        cases[f"chaotic forecast spread, n={nsteps}"] = (certificate(sds, float(np.mean(list(sds.values())))), want)
    E = ensembles(0.3137, 0.2, 100000, rng)
    for _ in range(60): E = {k: 3.5*v*(1-v) for k, v in E.items()}
    E = ensembles(0.5, 0.6, 100000, rng)
    for _ in range(60): E = {k: 3.5*v*(1-v) for k, v in E.items()}
    cases["periodic forecast mean, n=60 (wide input)"] = (certificate({k: float(np.mean(v)) for k, v in E.items()},
                                                                      float(np.mean([np.std(v) for v in E.values()]))), "CONDITIONAL")
    wrong = [k for k, (got, want) in cases.items() if got != want]
    passed = not wrong
    register("UG08", "Input hypotheses (priors, error laws, ensembles) are harmless modelling choices.",
             "Non-circularity certificate: an uncertainty statement is FORCED iff it is insensitive over the admissible input "
             "family, CONDITIONAL otherwise. Identifiable posteriors and post-frontier chaotic forecasts are FORCED; kernel "
             "variances, pre-frontier and periodic forecasts are CONDITIONAL (they report the declaration back).",
             passed, dict(cases={k: dict(certificate=g, expected=w) for k, (g, w) in cases.items()}, misclassified=wrong), "FALSIFIED-naive")


def UG09_chi_audit(rng):
    # (a) bottleneck: harmonic mean >= min (paper claims chi_eff <= chi_min)
    chis = rng.uniform(0.2, 5.0, (1000, 6)); heff = 1/np.mean(1/chis, axis=1)
    viol_claim = int(np.sum(heff <= chis.min(1)-1e-12)); holds_correct = int(np.sum((heff >= chis.min(1)-1e-12) & (heff <= chis.mean(1)+1e-12)))
    # (b) misspecification: fuel per time from rolling + drag; CHI predicts v^2 scaling; Fisher rank of Y = k chi is 1 everywhere
    m, g, cr, rho, CdA = 1500.0, 9.81, 0.01, 1.2, 0.66
    Ptrue = lambda v: (cr*m*g + 0.5*rho*CdA*v*v)*v
    v0 = 20.0; k = Ptrue(v0)/(v0**2)
    errs = {str(v): f_(abs(k*v*v-Ptrue(v))/Ptrue(v)) for v in (10.0, 30.0, 40.0)}
    rank = [int(np.linalg.matrix_rank(np.array([[v*v]]))) for v in (10, 20, 30, 40)]   # d(k chi)/dk: one direction always
    # (c) wind: P = 0.5 rho A v^3 Cp; CHI with M = rho A v gives chi independent of rho
    Pw = lambda rho_, v: 0.5*rho_*10.0*v**3*0.45; chi_w = lambda rho_, v: (rho_*10.0*v)*v*v/(1.0*9.81*1.0*rho_)
    kw = Pw(1.225, 10)/chi_w(1.225, 10); dens_err = abs(kw*chi_w(0.9, 10)-Pw(0.9, 10))/Pw(0.9, 10)
    # (d) hazard H = lambda_min/lambda_max -> 0 at a rank wall (retained)
    Hs = []
    for e in (1.0, 0.1, 0.01):
        Jm = np.array([[1.0, 0.0], [0.0, e]]); w = np.linalg.eigvalsh(Jm.T@Jm); Hs.append(f_(w[0]/w[-1]))
    passed = viol_claim < 50 and holds_correct == 1000 and max(errs.values()) > 0.2 and rank == [1, 1, 1, 1] and dens_err > 0.3 and Hs[-1] < 1e-3
    register("UG09", "The CHI coherence volume, sealed by constant Fisher rank, transports with one anchor (early attempt).",
             "Audit: the bottleneck theorem is reversed (harmonic mean >= min, 1000/1000); the Fisher-rank seal is blind to "
             "misspecification (rank 1 everywhere while the v^2 law misses rolling+drag by 20%+ away from the anchor); in the "
             "wind example density cancels from chi though power is proportional to it (36% error at altitude). Retained: "
             "H = lambda_min/lambda_max -> 0 is a valid rank-wall indicator.", passed,
             dict(harmonic_le_min_cases=viol_claim, harmonic_between_min_and_mean=holds_correct, fuel_rel_errors=errs,
                  fisher_rank_of_k_chi=rank, wind_density_error=f_(dens_err), hazard_H=Hs), "FALSIFIED-naive")


def UG10_monte_carlo(rng):
    """MC over two declared priors (importance sampling). Agreement = forced output; disagreement = MC returns the
    declaration. MC carries its own validity certificate: effective sample size (first registration used n = 5000, where
    importance weights collapsed onto a few draws on one seed and both kernel variances degenerated)."""
    J = np.array([[1.0, 1.0, 0.0], [0.0, 1.0, 1.0]]); th = np.array([0.5, -0.3, 0.8]); n = 200
    ybar = J@th + rng.normal(0, 1/math.sqrt(n), 2); Kd = np.array([1.0, -1, 1])/math.sqrt(3); Q = np.linalg.svd(J)[2][0]
    out, ess = {}, {}
    for name, draw in (("gaussian prior", lambda N: rng.normal(size=(N, 3))), ("laplace prior", lambda N: rng.laplace(size=(N, 3))*1.5)):
        T = draw(400000); ll = -0.5*n*np.sum((T@J.T-ybar)**2, axis=1); w = np.exp(ll-ll.max()); w /= w.sum()
        ess[name] = float(1/np.sum(w*w))
        mq = float(w@(T@Q)); vq = float(w@(T@Q)**2-mq**2); mk = float(w@(T@Kd)); vk = float(w@(T@Kd)**2-mk**2)
        out[name] = (mq, vq, vk)
    g, l = out["gaussian prior"], out["laplace prior"]
    psd = math.sqrt(0.5*(g[1]+l[1])); gq = abs(g[0]-l[0])/psd; gk = abs(g[2]-l[2])/(0.5*(g[2]+l[2]))
    # the MC must resolve the registered kernel gap (0.3) at 3 SE: 3 sqrt(2/ESS) < 0.3  <=>  ESS > 200
    # (a fixed 1000 was first used; it was arbitrary and is replaced by this derivation)
    valid = 3*math.sqrt(2/min(ess.values())) < 0.3
    passed = valid and gq < 0.25 and gk > 0.3
    register("UG10", "Monte Carlo over a prior is an objective uncertainty computation.",
             "MC over two priors agrees on quotient outputs (gap a fraction of a posterior sd) and disagrees on kernel outputs "
             "(relative variance gap 0.3+): objective where the input is forgotten, circular where it is not; and valid only "
             "with an effective-sample-size certificate.", passed,
             dict(quotient_gap_in_posterior_sd=f_(gq), kernel_variance_rel_gap=f_(gk), min_effective_sample_size=f_(min(ess.values()))),
             "FALSIFIED-naive")


ATTACKS = [UG01_definetti, UG02_mixing, UG03_bvm_kernel, UG04_lan_wall, UG05_cencov, UG06_quantum_contextual, UG07_born,
           UG08_noncircular, UG09_chi_audit, UG10_monte_carlo]


def make_figures(d):
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    os.makedirs(d, exist_ok=True)
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.6))
    ax[0].plot(FIG["mixing"]["narrow"], label="chaotic, narrow inputs (shape)")
    ax[0].plot(FIG["mixing"]["wide_chaos"], label="chaotic, wide inputs (weights)")
    ax[0].plot(FIG["mixing"]["wide_periodic"], label="periodic, wide inputs (weights)")
    ax[0].axvline(math.log(1/1e-4)/math.log(2), color="k", ls="--", lw=0.8, label=r"spreading time $\log(1/w)/\lambda$")
    ax[0].set_xlabel("steps $n$"); ax[0].set_ylabel("TV between input ensembles"); ax[0].set_title("dynamics forgets the input (or not)", fontsize=10)
    ax[0].legend(fontsize=7)
    rows = FIG["bvm"]; ns = [r["n"] for r in rows]
    ax[1].loglog(ns, [max(r["identifiable_diff_scaled"], 1e-16) for r in rows], "o-", label="identifiable directions")
    ax[1].loglog(ns, [r["kernel_variance_diff"] for r in rows], "s-", label="observational kernel")
    ax[1].set_xlabel("sample size $n$"); ax[1].set_ylabel("difference between two priors"); ax[1].set_title("data forgets the prior only on the quotient", fontsize=10)
    ax[1].legend(fontsize=7); fig.tight_layout(); fig.savefig(f"{d}/ug_forgetting.png", dpi=170); plt.close(fig)


def run_all(seed):
    for a in ATTACKS:
        rng = np.random.default_rng([seed, ATTACKS.index(a)])
        try: a(rng)
        except Exception as ex: register(a.__name__[:4], "?", f"EXCEPTION {ex!r}", False, {}, "ERROR")


def canary(seed):
    muts = [("UG08", {"ug08_single_input": True}), ("UG03", {"ug03_fullrank": True}), ("UG02", {"ug02_no_periodic": True})]
    ok = True
    for tgt, m in muts:
        RESULTS.clear(); MUT.clear(); MUT.update(m); print(f"--- canary {tgt}: {m}")
        a = next(x for x in ATTACKS if x.__name__.startswith(tgt))
        try: a(np.random.default_rng([seed, ATTACKS.index(a)])); caught = not RESULTS[-1]["passed"]
        except Exception as ex: print(f"    exception {ex!r} (not a clean catch)"); caught = False
        ok &= caught; print(f"    {'CAUGHT' if caught else 'NOT CAUGHT'}")
    MUT.clear(); print("CANARY:", "all caught" if ok else "BATTERY TOO WEAK"); return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--seed", type=int, default=20261009)
    ap.add_argument("--out", default="rg_uncertainty_results.json"); ap.add_argument("--figs", default="")
    ap.add_argument("--canary", action="store_true"); a = ap.parse_args()
    if a.canary: sys.exit(canary(a.seed))
    t0 = time.time(); print(f"RG uncertainty geometry battery, seed {a.seed}\n"); run_all(a.seed)
    if a.figs: make_figures(a.figs)
    n = sum(r["passed"] for r in RESULTS)
    summ = dict(seed=a.seed, n_checks=len(RESULTS), n_pass=n, runtime_s=round(time.time()-t0, 1))
    json.dump(dict(summary=summ, results=RESULTS), open(a.out, "w"), indent=2,
              default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print(f"\n{n}/{len(RESULTS)} pass."); sys.exit(0 if n == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
