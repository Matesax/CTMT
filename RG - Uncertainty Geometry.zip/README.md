# RG - Uncertainty Geometry: battery UG01-UG10

    python3 rg_uncertainty_attack.py --figs figs   # seed 20261009 (~1 min)
    python3 rg_uncertainty_attack.py --canary      # single-input certificate, full-rank law, no periodic control

10/10 on seeds 20261009, 1, 42, 777, 2026; canary 3/3.
Primitive: indistinguishability (kernel; Hellinger/Fisher). Probability lock: de Finetti, mixing (input forgotten after the
spreading time; periodic phase weights persist), Gleason. Statistics lock: Cencov, LAN (Gaussian propagation valid on regular
strata, fails across a fold), Bernstein-von Mises on the quotient, prior never forgotten on the kernel. Quantum lock: Peres-Mermin,
CHSH, trace rule. Non-circularity certificate (FORCED / CONDITIONAL). Monte Carlo objective only on FORCED outputs, with an ESS
certificate. Audit of the CHI coherence-volume formula.
