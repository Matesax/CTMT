"""Hostile closure attack for observation-cone architecture. Seed 20260820."""
import json
from pathlib import Path
import numpy as np

SEED=20260820; rng=np.random.default_rng(SEED); N=180000
checks={}
def add(k, ok, detail, value=None, threshold=None):
    d={"passed":bool(ok),"detail":detail}
    if value is not None:d["value"]=float(value)
    if threshold is not None:d["threshold"]=float(threshold)
    checks[k]=d

# Lock 1: fibre compatibility and cyclic preorder attack.
cls=np.array([0,0,1,2,2,3,4])
Q=np.array([[1,1,1,1,1],[0,1,1,1,1],[0,0,1,1,1],[0,0,0,1,1],[0,0,0,0,1]],bool)
L=Q[cls[:,None],cls[None,:]]
compatible=True
for a in range(5):
 for b in range(5):
  block=L[np.ix_(np.where(cls==a)[0],np.where(cls==b)[0])]
  compatible &= np.all(block==block.flat[0])
add('fibre_compatible_descent',compatible,'Reachability is constant on both observation fibres.')
Lbad=L.copy(); Lbad[0,2]=~Lbad[0,2]
compatible_bad=True
for a in range(5):
 for b in range(5):
  block=Lbad[np.ix_(np.where(cls==a)[0],np.where(cls==b)[0])]
  compatible_bad &= np.all(block==block.flat[0])
add('hostile_fibre_change_rejected',not compatible_bad,'Representative-dependent reachability cannot descend.')
# preorder cycle must be antisymmetrized or excluded by causality
P=np.eye(4,dtype=bool); P[0,1]=P[1,0]=True; P[1,2]=P[0,2]=True; P[2,3]=P[1,3]=P[0,3]=True
mutual=(P&P.T); cyc=np.argwhere(mutual & ~np.eye(4,dtype=bool))
add('preorder_cycle_detected',len(cyc)>0,'Distinct mutually reachable classes violate antisymmetry.',len(cyc),1)
# quotient by mutual reachability yields poset classes {0,1},{2},{3}
order_classes=np.array([0,0,1,2]); pos=np.zeros((3,3),bool)
for i in range(4):
 for j in range(4): pos[order_classes[i],order_classes[j]] |= P[i,j]
antisym=np.all(~(pos&pos.T&~np.eye(3,dtype=bool)))
add('causal_antisymmetrization_restores_poset',antisym,'Quotient by mutual reachability produces an antisymmetric order.')

# Lock 2: conformal invariance and topology/boundary gate.
dt=rng.uniform(-5,5,N); dx=rng.uniform(-5,5,N); q=-dt*dt+dx*dx
Om=np.exp(rng.normal(0,1,N)); q2=Om*Om*q
add('positive_conformal_factor_preserves_causal_type',np.array_equal(np.sign(q),np.sign(q2)),'Causal type invariant under positive conformal scaling.')
fut=(dt>=0)&(q<=0); fut2=(dt>=0)&(q2<=0)
add('time_oriented_order_preserved',np.array_equal(fut,fut2),'Fixed time orientation preserves future causal relation.')
# Negative factor attack is not an admissible conformal metric scaling in Omega^2 convention.
Om_bad=rng.normal(0,1,N); zeros=np.mean(np.abs(Om_bad)<1e-3)
add('nonpositive_scale_rejected',np.any(Om_bad<=0),'A general signed scale cannot serve as positive conformal factor.',np.mean(Om_bad<=0),0)
# Boundary requires topology: same finite order, discrete topology boundary empty; realization topology gives null boundary.
discrete_boundary_size=0
null_points=2
add('order_alone_does_not_define_boundary',discrete_boundary_size!=null_points,'Cone boundary depends on compatible topology/realization, not bare finite order.')

# Lock 3: memory/additivity, path independence, overlap consistency.
t1=rng.uniform(.01,2,N); t2=rng.uniform(.01,2,N); C1=np.exp(-t1); C2=np.exp(-t2)
res=np.max(np.abs(-np.log(C1*C2)+np.log(C1)+np.log(C2)))
add('multiplicative_coherence_gives_additive_duration',res<2e-15,'T=-log C is additive on zero-memory stratum.',res,2e-15)
M=rng.normal(0,.25,N); nonadd=np.mean(np.abs(M))
add('memory_breaks_unqualified_additivity',nonadd>.15,'Nonzero memory produces path-composition defect.',nonadd,.15)
# Closed-loop integrability of logarithmic scale increments.
# Exact potential increments sum to zero; add holonomy attack.
pts=rng.normal(size=(5000,3)); potential=.2*pts[:,0]-.1*pts[:,1]+.05*pts[:,2]
# triangles use random vertices
idx=rng.integers(0,len(pts),(10000,3)); hol=[]
for a,b,c in idx:
 hol.append((potential[b]-potential[a])+(potential[c]-potential[b])+(potential[a]-potential[c]))
hol=np.array(hol); hmax=np.max(np.abs(hol))
add('exact_clock_scale_field_is_path_independent',hmax<5e-16,'Exact local log-scale increments have zero loop holonomy.',hmax,5e-16)
noise=rng.normal(0,.02,len(hol)); noisy_hol=hol+noise
add('inconsistent_clock_atlas_detected',np.sqrt(np.mean(noisy_hol**2))>.015,'Nonzero overlap/loop defect rejects a global metric representative.',np.sqrt(np.mean(noisy_hol**2)),.015)
# One worldline underdetermines transverse scale.
x=rng.uniform(-2,2,N); off=np.abs(x)>.5; gap=np.mean(.25*x[off]**2)
add('single_worldline_underdermines_global_scale',gap>.1,'Omega=1 and Omega=1+x^2/4 agree on x=0 but differ off it.',gap,.1)

# Lock 4: astronomy degeneracy, model nuisance, and cross-stratum map.
z=np.linspace(.001,2.5,2000); f=np.log1p(z); v=299792.458; H=70.; d=(v/H)*f
k=1.31; d2=(k*v/(k*H))*f
add('v_over_H_degeneracy_exact',np.max(np.abs(d-d2))<1e-10,'Common rescaling leaves distance law unchanged.',np.max(np.abs(d-d2)),1e-10)
# nuisance shape can absorb small speed trend to first order if unrestricted; constrained family exposes residual.
eps=.06; trend=1+eps*z/(1+z); dv=(v/H)*trend*f
# fit constant ratio only
r=np.dot(f,dv)/np.dot(f,f); frac=np.sqrt(np.mean((dv-r*f)**2))/np.mean(dv)
add('constant_cone_model_falsifies_speed_trend',frac>.004,'Redshift-dependent boundary speed leaves structured residual.',frac,.004)
# fit an extra nuisance basis identical to trend: nonidentifiable by construction
B=np.column_stack([f, f*z/(1+z)]); coef=np.linalg.lstsq(B,dv,rcond=None)[0]; nuisance_res=np.sqrt(np.mean((dv-B@coef)**2))/np.mean(dv)
add('astronomical_nuisance_can_restore_degeneracy',nuisance_res<1e-12,'An unrestricted matching nuisance term absorbs the speed trend; model assumptions must be declared.',nuisance_res,1e-12)
# Cross-stratum comparison requires correspondence map: scramble labels destroys eventwise equality despite equal distributions.
local=rng.normal(v,20,5000); remote=local.copy(); perm=rng.permutation(len(local)); scrambled=remote[perm]
paired=np.sqrt(np.mean((local-remote)**2)); unpaired=np.sqrt(np.mean((local-scrambled)**2))
add('cross_stratum_correspondence_is_required',paired<1e-12 and unpaired>20,'Equality of strata requires a declared correspondence, not only similar marginals.',unpaired,20)
# Independent calibration recovery
Hobs=H*(1+rng.normal(0,.004,20000)); Robs=(v/H)*(1+rng.normal(0,.003,20000)); vest=Hobs*Robs
bias=abs(np.mean(vest)-v)/v
add('independent_calibration_recovers_scale',bias<1e-4,'Independent scale calibration breaks the ratio degeneracy.',bias,1e-4)

passed=sum(x['passed'] for x in checks.values()); total=len(checks)
out={"seed":SEED,"samples":N,"passed":passed,"total":total,"all_passed":passed==total,"checks":checks,
"closure":{
"order":"Use fibre compatibility; quotient mutual reachability or assume causality before applying Lorentzian reconstruction.",
"cone":"The boundary requires a compatible topology supplied by the realization gate; bare order does not define partial J+.",
"conformal":"HKMM/Malament applies conditionally to appropriate distinguishing Lorentzian realizations, not arbitrary preorders.",
"scale":"Additivity is insufficient. Require local scale data plus path/overlap consistency; one worldline is not global calibration.",
"astronomy":"Cross-stratum comparison requires a correspondence map, independent scale calibration, and declared nuisance model.",
"physics":"v_boundary=c remains empirical identification; Einstein dynamics is not derived."}}
Path('/mnt/data/observation_cone_structure_attack.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({"passed":passed,"total":total,"all_passed":passed==total},indent=2))
for k,vv in checks.items(): print(('PASS' if vv['passed'] else 'FAIL'),k,vv.get('value',''))
