"""Observation-cone uniqueness attack.

Tests four distinct claims:
1. A nondegenerate Lorentzian quadratic cone determines a pointwise metric ray.
2. Null samples alone recover the ray but not its positive factor.
3. A cone field permits an arbitrary positive conformal function Omega(x), not one global constant.
4. Additional cross-point compatibility can reduce the conformal function to one global constant.

This is a synthetic algebraic battery, not a proof for arbitrary non-quadratic cones.
"""
import json
from pathlib import Path
import numpy as np

SEED = 20260820
rng = np.random.default_rng(SEED)
DIM = 4
N_NULL = 1200
N_TIMELIKE = 800
N_POINTS = 40
TOL = 1e-10

checks = {}
def add(name, ok, detail, value=None, threshold=None):
    item = {"passed": bool(ok), "detail": detail}
    if value is not None: item["value"] = float(value)
    if threshold is not None: item["threshold"] = float(threshold)
    checks[name] = item


def random_invertible(n):
    while True:
        A = rng.normal(size=(n,n))
        if abs(np.linalg.det(A)) > 0.15:
            return A


def lorentz_metric(n=4):
    S = random_invertible(n)
    eta = np.diag([-1.0] + [1.0]*(n-1))
    g = S.T @ eta @ S
    return g, S, eta


def symvec_matrix(v):
    """Row q(v)=v^T G v in coordinates of independent symmetric entries."""
    vals=[]
    for i in range(DIM):
        vals.append(v[i]*v[i])
    for i in range(DIM):
        for j in range(i+1,DIM):
            vals.append(2*v[i]*v[j])
    return np.array(vals)


def vec_to_sym(a):
    G=np.zeros((DIM,DIM)); k=0
    for i in range(DIM):
        G[i,i]=a[k]; k+=1
    for i in range(DIM):
        for j in range(i+1,DIM):
            G[i,j]=G[j,i]=a[k]; k+=1
    return G


def frob_ray_error(A,B):
    alpha=np.sum(A*B)/np.sum(B*B)
    return np.linalg.norm(A-alpha*B)/np.linalg.norm(A), alpha

# ------------------------------------------------------------------
# Pointwise theorem attack: reconstruct a Lorentzian quadratic form from its null cone.
# ------------------------------------------------------------------
g,S,eta = lorentz_metric(DIM)
Sinv=np.linalg.inv(S)
# In eta coordinates choose future null vectors u=(r, r*n_hat), then v=S^{-1}u.
dirs=rng.normal(size=(N_NULL,DIM-1)); dirs/=np.linalg.norm(dirs,axis=1)[:,None]
radii=np.exp(rng.uniform(-2,2,N_NULL))
u=np.column_stack([radii, radii[:,None]*dirs])
v=(Sinv@u.T).T
null_res=np.max(np.abs(np.einsum('ni,ij,nj->n',v,g,v)) / np.sum(v*v,axis=1))
add("generated_vectors_are_null", null_res < 2e-10,
    "Synthetic future-cone generators satisfy v^T g v=0.", null_res, 2e-10)

M=np.vstack([symvec_matrix(x) for x in v])
sv=np.linalg.svd(M,compute_uv=False)
rank=int(np.sum(sv > sv[0]*1e-11))
unknowns=DIM*(DIM+1)//2
nullity=unknowns-rank
add("null_constraints_have_one_dimensional_kernel", nullity==1,
    "For a regular four-dimensional quadratic cone, null evaluations leave one symmetric-form direction.", nullity, 1)

_,_,VT=np.linalg.svd(M,full_matrices=False)
ghat=vec_to_sym(VT[-1])
ray_err,alpha=frob_ray_error(ghat,g)
add("metric_ray_recovered_from_null_cone", ray_err < 2e-10,
    "The recovered symmetric form is proportional to the generating Lorentzian form.", ray_err, 2e-10)

# Positive factors preserve null cone and time orientation; negative factors preserve cone set but reverse sign convention.
pos_factors=np.exp(rng.uniform(-5,5,80))
max_pos=0.0
qg=np.einsum('ni,ij,nj->n',v,g,v)
for a in pos_factors:
    max_pos=max(max_pos,float(np.max(np.abs(np.einsum('ni,ij,nj->n',v,a*g,v)-a*qg))))
add("positive_scale_preserves_cone", max_pos < 1e-7,
    "All tested positive multiples preserve the same null set.", max_pos, 1e-7)

# Timelike sign fixes positivity if convention and time orientation are part of the data.
w_u=np.column_stack([np.ones(N_TIMELIKE)*2.0, rng.normal(0,0.2,size=(N_TIMELIKE,DIM-1))])
w=(Sinv@w_u.T).T
q_time=np.einsum('ni,ij,nj->n',w,g,w)
q_neg=np.einsum('ni,ij,nj->n',w,-g,w)
add("time_orientation_selects_positive_ray", np.all(q_time<0) and np.all(q_neg>0),
    "The null set alone permits nonzero scalar multiples; a declared timelike sign convention selects the positive ray.")

# Perturb a non-conformal component and verify cone mismatch.
H=rng.normal(size=(DIM,DIM)); H=(H+H.T)/2
H-=np.sum(H*g)/np.sum(g*g)*g
best_eps=None; mismatch=None
for eps in [1e-5,1e-4,1e-3,1e-2]:
    gp=g+eps*H
    vals=np.einsum('ni,ij,nj->n',v,gp,v)
    mm=float(np.sqrt(np.mean(vals*vals))/np.linalg.norm(gp))
    if mm>1e-7:
        best_eps=eps; mismatch=mm; break
add("nonconformal_perturbation_changes_cone", mismatch is not None,
    "A transverse perturbation no longer vanishes on the original null generators.", mismatch or 0.0, 1e-7)

# Finite/noisy data attack: rank-one conclusion is not exact without model and tolerance.
noise_levels=[0.0,1e-8,1e-6,1e-4]
noisy_errors=[]
for sig in noise_levels:
    vn=v+rng.normal(0,sig,size=v.shape)
    Mn=np.vstack([symvec_matrix(x) for x in vn])
    _,_,VTn=np.linalg.svd(Mn,full_matrices=False)
    gn=vec_to_sym(VTn[-1])
    er,_=frob_ray_error(gn,g)
    noisy_errors.append(er)
add("finite_noise_requires_statistical_model", noisy_errors[-1] > noisy_errors[1],
    "Metric-ray recovery degrades with perturbation of inferred null directions.", noisy_errors[-1], noisy_errors[1])

# ------------------------------------------------------------------
# Cone-field attack: pointwise uniqueness is a function Omega(x), not one constant.
# ------------------------------------------------------------------
# Use one base cone field and multiply by a nonconstant smooth/discrete positive field.
xs=np.linspace(0,1,N_POINTS)
omega=np.exp(0.8*np.sin(2*np.pi*xs)+0.25*xs)
g_field=np.stack([(1+0.15*x)*g for x in xs])
g_tilde=np.stack([omega[i]**2*g_field[i] for i in range(N_POINTS)])
# Every point has same cone, but no single scalar fits all points.
point_scales=[]; point_errors=[]
for i in range(N_POINTS):
    er,a=frob_ray_error(g_tilde[i],g_field[i])
    point_errors.append(er); point_scales.append(a)
point_scales=np.array(point_scales)
A=np.concatenate([x.ravel() for x in g_tilde])
B=np.concatenate([x.ravel() for x in g_field])
global_alpha=np.dot(A,B)/np.dot(B,B)
global_err=np.linalg.norm(A-global_alpha*B)/np.linalg.norm(A)
add("cone_field_allows_nonconstant_conformal_function", max(point_errors)<1e-13 and np.std(point_scales)>0.1,
    "Pointwise cones agree although the positive proportionality factor varies over the base.", np.std(point_scales), 0.1)
add("single_global_factor_rejected_by_cone_data_alone", global_err>0.1,
    "No single constant scalar fits the conformally related cone fields used in the attack.", global_err, 0.1)

# ------------------------------------------------------------------
# Additional compatibility attack: edge transport preserving representatives forces equal scales.
# If P_ij^T g_j P_ij = g_i and also for g~ with same P_ij, then omega_i^2=omega_j^2.
# On a connected graph this reduces Omega to one positive constant.
# We use identity transports and a constant base representative for a transparent exact test.
base=np.stack([g.copy() for _ in range(N_POINTS)])
# Constraint matrix on log scale differences z_i-z_j=0 for chain plus random edges.
edges=[(i,i+1) for i in range(N_POINTS-1)]
edges += [(int(rng.integers(0,N_POINTS-1)),int(rng.integers(1,N_POINTS))) for _ in range(30)]
edges=[(i,j) if i!=j else (i,(j+1)%N_POINTS) for i,j in edges]
C=np.zeros((len(edges),N_POINTS))
for k,(i,j) in enumerate(edges): C[k,i]=1; C[k,j]-=1
sC=np.linalg.svd(C,compute_uv=False)
rankC=int(np.sum(sC>sC[0]*1e-12))
compat_nullity=N_POINTS-rankC
add("connected_transport_compatibility_leaves_one_global_scale", compat_nullity==1,
    "Exact representative-preserving transport on a connected graph leaves only the constant log-scale mode.", compat_nullity, 1)

# Nonconstant Omega violates compatibility; constant Omega passes.
viol=np.linalg.norm(C@np.log(omega))
const_omega=np.ones(N_POINTS)*2.7
const_viol=np.linalg.norm(C@np.log(const_omega))
add("nonconstant_scale_violates_strict_transport_compatibility", viol>1.0 and const_viol<1e-12,
    "The same strict transport rejects the nonconstant conformal field and accepts a global constant.", viol, 1.0)

# Disconnected graph leaves one scale per connected component.
C2=np.zeros((N_POINTS-2,N_POINTS)); row=0
for start,end in [(0,N_POINTS//2),(N_POINTS//2,N_POINTS)]:
    for i in range(start,end-1):
        C2[row,i]=1; C2[row,i+1]=-1; row+=1
rankC2=np.linalg.matrix_rank(C2)
nullity2=N_POINTS-rankC2
add("disconnected_transport_leaves_one_scale_per_component", nullity2==2,
    "Global uniqueness requires connectedness; two components retain two independent scales.", nullity2, 2)

# Weyl-compatible transport counterexample: if transport may rescale representatives, arbitrary Omega survives.
# Edge factor rho_ij=omega_i/omega_j compensates the conformal change.
weyl_res=[]
for i,j in edges:
    rho=omega[i]/omega[j]
    # rho^2 * gtilde_j should equal gtilde_i for constant base g.
    weyl_res.append(np.linalg.norm(rho**2*(omega[j]**2*g)-omega[i]**2*g)/np.linalg.norm(g))
weyl_max=max(weyl_res)
add("weyl_rescaling_restores_functional_freedom", weyl_max<1e-12,
    "If admissible transport includes edgewise scale compensation, arbitrary positive Omega survives.", weyl_max, 1e-12)

passed=sum(v["passed"] for v in checks.values()); total=len(checks)
result={
    "seed":SEED,"dimension":DIM,"null_samples":N_NULL,"base_points":N_POINTS,
    "checks":checks,"passed":passed,"total":total,"all_passed":passed==total,
    "metrics":{"null_constraint_rank":rank,"null_constraint_nullity":nullity,
               "metric_ray_error":ray_err,"global_constant_fit_error_for_variable_Omega":global_err,
               "point_scale_std":float(np.std(point_scales)),"transport_constraint_nullity_connected":compat_nullity,
               "transport_constraint_nullity_disconnected":nullity2,"weyl_compensated_max_residual":weyl_max,
               "noise_levels":noise_levels,"noisy_recovery_errors":noisy_errors},
    "verdict":{
        "pointwise":"For a nondegenerate Lorentzian quadratic cone in dimension four, the symmetric bilinear form is recovered up to a nonzero scalar; time orientation/sign convention restricts this to a positive scalar.",
        "field_level":"A cone field determines a conformal class g~=Omega(x)^2 g with an arbitrary positive function, not one global constant.",
        "global_constant":"One global positive constant follows only after adding connected, representative-preserving cross-point compatibility (or an equivalent scale connection/clock synchronization law).",
        "countercondition":"If admissible transport is Weyl/conformally rescaling, the functional Omega(x) freedom remains.",
        "scope":"The battery addresses quadratic Lorentzian cones. Convex homogeneous cones in general need not arise from a unique quadratic form."
    }
}
Path('/mnt/data/observation_cone_uniqueness_attack.json').write_text(json.dumps(result,indent=2,default=lambda o: o.item() if hasattr(o,'item') else str(o)),encoding='utf-8')
print(json.dumps({"passed":passed,"total":total,"all_passed":passed==total,"metrics":result["metrics"],"verdict":result["verdict"]},indent=2,default=lambda o: o.item() if hasattr(o,'item') else str(o)))
