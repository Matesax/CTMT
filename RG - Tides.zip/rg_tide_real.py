"""Tides through the RG window: forcing (exact), and real tide-gauge evidence (UTide example record can1998: hourly sea level, 1998).
F1 lunar differential forcing, quadrupole eigenstructure, equilibrium heights, Sun/Moon ratio, M2 period (exact formulas, nominal constants)
D1 full-year harmonic analysis (UTide, OLS, lat -25 as in the UTide example)
D2 out-of-sample prediction: fit Jan-Jun, predict Jul-Dec; skill and the prediction ceiling (non-tidal floor)
D3 honest band: coverage of the +-1.96 sigma band built from the training residual
D4 residual spectrum: share of the non-tidal (hidden) variance in the subtidal band
D5 Rayleigh resolution: K1/P1 Gram conditioning for 29-day vs 365-day records (exact design matrices)
D6 the inference declaration: equilibrium P1/K1 ratio vs fitted; prediction cost of the declaration
D7 the basin fibre: two different damped-mode systems match the fitted admittance at every resolved constituent exactly,
   yet respond differently off the tidal bands (blindness of harmonic constants to basin dynamics)
Run: python rg_tide_real.py   (numpy, pandas, utide); data/can1998.dtf from github.com/wesleybowman/UTide (notebooks)
"""
import json, math, hashlib, pathlib, warnings
import numpy as np, pandas as pd
import utide
warnings.filterwarnings("ignore")
RES = {}
def must(c, m):
    if not c: raise AssertionError(m)

# ---------------- F1 forcing
muM = 4.9048695e12; muS = 1.32712440018e20; D = 384400000.0; DS = 1.495978707e11; RE = 6371000.0; g = 9.81
def a_tide(r, Rv, mu):
    return mu * ((Rv - r) / np.linalg.norm(Rv - r) ** 3 - Rv / np.linalg.norm(Rv) ** 3)
Rv = np.array([D, 0, 0])
near = a_tide(np.array([RE, 0, 0]), Rv, muM)[0]; far = -a_tide(np.array([-RE, 0, 0]), Rv, muM)[0]
quad = a_tide(np.array([0, RE, 0]), Rv, muM)[1]
eta_axis = muM * RE ** 2 / (g * D ** 3); eta_quad = -eta_axis / 2
ratio_sun = (muS / DS ** 3) / (muM / D ** 3)
T_sid, T_month = 86164.0905, 27.321661 * 86400
omega_rel = 2 * math.pi / T_sid - 2 * math.pi / T_month
M2_hours = math.pi / omega_rel / 3600
must(abs(near - 1.12828e-6) < 1e-10 and abs(M2_hours - 12.4206) < 1e-3, "F1")
RES["F1"] = dict(near_side=near, far_side=far, quadrature=quad, eta_axis_m=eta_axis, eta_quadrature_m=eta_quad, sun_over_moon=ratio_sun,
                 M2_period_h=M2_hours, quadrupole_eigs="mu/D^3 (2, -1, -1); antipodal invariance T(n) = T(-n): direction known only in RP^2")

# ---------------- data
names = ["seconds", "year", "month", "day", "hour", "elev", "flag"]
obs = pd.read_csv("data/can1998.dtf", names=names, sep=r"\s+")
idx = pd.to_datetime(dict(year=obs.year, month=obs.month, day=obs.day, hour=obs.hour))
obs.index = idx
obs.loc[obs.flag == 2, "elev"] = np.nan
obs["anom"] = (obs.elev - obs.elev.mean()).interpolate()
t = obs.index; y = obs.anom.values
sha = hashlib.sha256(pathlib.Path("data/can1998.dtf").read_bytes()).hexdigest()
def fit(tt, yy, **kw):
    return utide.solve(tt, yy, lat=-25, method="ols", conf_int="linear", verbose=False, **kw)
def recon(tt, coef):
    return utide.reconstruct(tt, coef, verbose=False).h

# D1 full year
cf = fit(t, y); full_pred = recon(t, cf)
var_expl = 1 - np.var(y - full_pred) / np.var(y)
top = sorted(zip(cf.name, cf.A, cf.g, cf.A_ci), key=lambda r: -r[1])[:10]
RES["D1"] = dict(data_sha256=sha, n_hours=len(y), n_constituents=len(cf.name), variance_explained=float(var_expl),
                 top_constituents=[dict(name=n, amp_m=float(a), phase_deg=float(p), amp_ci95=float(c)) for n, a, p, c in top])

# D2 out of sample
half = t < pd.Timestamp("1998-07-01")
cf_tr = fit(t[half], y[half]); pred_te = recon(t[~half], cf_tr); pred_tr = recon(t[half], cf_tr)
res_tr = y[half] - pred_tr; res_te = y[~half] - pred_te
rmse_te = float(np.sqrt(np.mean(res_te ** 2))); skill = float(1 - np.var(res_te) / np.var(y[~half]))
# prediction ceiling: residual of the full-year in-sample fit on the test half is the non-tidal part no tidal predictor can remove
cf_te = fit(t[~half], y[~half])                                        # oracle: best tidal fit on the test half itself
floor = float(np.sqrt(np.mean((y[~half] - recon(t[~half], cf_te)) ** 2)))
RES["D2"] = dict(train_months="Jan-Jun", test_months="Jul-Dec", rmse_test_m=rmse_te, skill_test=skill, nontidal_floor_m=floor,
                 excess_over_floor_m=rmse_te - floor)
# D3 coverage
sig = float(np.std(res_tr)); cover = float(np.mean(np.abs(res_te) <= 1.96 * sig))
ac1 = float(np.corrcoef(res_tr[:-1], res_tr[1:])[0, 1])
RES["D3"] = dict(sigma_train_m=sig, nominal=0.95, coverage_test=cover, residual_lag1_autocorrelation=ac1)
# D4 residual spectrum
r = y - full_pred; fr = np.fft.rfftfreq(len(r), d=1 / 24.0); P = np.abs(np.fft.rfft(r - r.mean())) ** 2
sub = P[(fr > 0) & (fr < 0.5)].sum() / P[fr > 0].sum()
diu = P[(fr >= 0.8) & (fr <= 1.2)].sum() / P[fr > 0].sum(); semi = P[(fr >= 1.7) & (fr <= 2.2)].sum() / P[fr > 0].sum()
RES["D4"] = dict(residual_rms_m=float(np.std(r)), subtidal_share=float(sub), diurnal_band_share=float(diu), semidiurnal_band_share=float(semi))
# D5 Rayleigh: conditioning of [cos, sin] for K1 and P1
wK1, wP1 = 2 * math.pi * 1.0027379, 2 * math.pi * 0.9972621            # cycles per day
def cond(days):
    tt = np.arange(0, days * 24) / 24.0
    X = np.column_stack([np.cos(wK1 * tt), np.sin(wK1 * tt), np.cos(wP1 * tt), np.sin(wP1 * tt)])
    s = np.linalg.svd(X / np.sqrt(len(tt)), compute_uv=False); return float(s[0] / s[-1])
c29, c182, c365 = cond(29), cond(182.6), cond(365)
cf29 = fit(t[:29 * 24], y[:29 * 24])
RES["D5"] = dict(rayleigh_period_days=1 / (1.0027379 - 0.9972621), cond_29d=c29, cond_182d=c182, cond_365d=c365,
                 utide_29d_includes_P1=bool("P1" in list(cf29.name)), utide_365d_includes_P1=bool("P1" in list(cf.name)))
# D6 inference declaration
eq = dict(K1=0.14156, P1=0.04685, O1=0.10051, S2=0.11284, K2=0.03068, M2=0.24227)  # equilibrium amplitudes (m), Cartwright-Tayler
nm = list(cf.name)
A = {n: float(cf.A[nm.index(n)]) for n in ("K1", "P1", "S2", "K2") if n in nm}
K2_over_S2_fit = A["K2"] / A["S2"]; K2_over_S2_eq = eq["K2"] / eq["S2"]; G = {n: float(cf.g[nm.index(n)]) for n in ("K1", "P1", "S2", "K2") if n in nm}
ratio_fit = A["P1"] / A["K1"]; ratio_eq = eq["P1"] / eq["K1"]; dphase = ((G["P1"] - G["K1"] + 180) % 360) - 180
# cost: replace P1 by the inferred value (equilibrium ratio, K1 phase) and measure the change of the full-year prediction
import copy
cf_inf = copy.deepcopy(cf); j = nm.index("P1"); jk = nm.index("K1")
cf_inf.A[j] = ratio_eq * cf.A[jk]; cf_inf.g[j] = cf.g[jk]
cost = float(np.sqrt(np.mean((recon(t, cf_inf) - full_pred) ** 2)))
RES["D6"] = dict(K2_over_S2_fitted=K2_over_S2_fit, K2_over_S2_equilibrium=K2_over_S2_eq, P1_over_K1_fitted=ratio_fit, P1_over_K1_equilibrium=ratio_eq, phase_P1_minus_K1_deg=dphase, rms_cost_of_inference_m=cost,
                 note="inference fills the K1/P1 fibre of a short record with a declared (equilibrium/smooth-admittance) relation")
# D7 basin fibre from fitted admittances at resolved constituents
freqs_cpd = {"O1": 0.9295357, "K1": 1.0027379, "N2": 1.8959820, "M2": 1.9322736, "S2": 2.0000000}
Z = []
for n in freqs_cpd:
    k = nm.index(n); amp = cf.A[k] / eq.get(n, {"N2": 0.04639}.get(n, 0.04639)); ph = math.radians(cf.g[k])
    Z.append(amp * np.exp(-1j * ph))
w = np.array([2 * math.pi * f for f in freqs_cpd.values()]); Z = np.array(Z)
def design(modes, gam):
    cols = [1.0 / (wm ** 2 - w ** 2 + 2j * gam * w) for wm in modes]
    Hm = np.array(cols).T; return np.vstack([Hm.real, Hm.imag])
# room A: ten damped modes placed in the tidal bands, real couplings solved exactly from the five complex admittances
modesA = 2 * math.pi * np.array([0.85, 0.95, 1.05, 1.15, 1.25, 1.80, 1.90, 2.00, 2.10, 2.20]); gamA = 2 * math.pi * 0.08
betaA = np.linalg.solve(design(modesA, gamA), np.concatenate([Z.real, Z.imag]))
def HA(f_cpd):
    ww = 2 * math.pi * f_cpd; return sum(be / (wm ** 2 - ww ** 2 + 2j * gamA * ww) for wm, be in zip(modesA, betaA))
# room B = room A + Q, where Q is a stable, real-impulse-response filter vanishing at every resolved constituent frequency
poles = 2 * math.pi * np.array([0.55, 0.75, 2.6, 3.0, 3.4]); gq = 2 * math.pi * 0.15
def Qraw(f_cpd):
    ww = 2 * math.pi * f_cpd; num = np.prod([(wk ** 2 - ww ** 2) for wk in w]); den = np.prod([(wp ** 2 - ww ** 2 + 2j * gq * ww) for wp in poles]); return num / den
cQ = 1.0 / abs(Qraw(0.5))                                              # scale: |Q| = 1 at 0.5 cpd, comparable to in-band admittances
def HB(f_cpd): return HA(f_cpd) + cQ * Qraw(f_cpd)
match = max(abs(HA(f) - HB(f)) for f in freqs_cpd.values())
off = {f: (complex(HA(f)), complex(HB(f))) for f in (0.2, 0.5, 3.0, 4.0)}
diff_off = max(abs(a_ - b_) for a_, b_ in off.values())
inband = float(np.max(np.abs(Z)))
must(match < 1e-9 and diff_off > 0.1 * inband, "D7")
RES["D7"] = dict(constituents=list(freqs_cpd), admittances=[str(np.round(z, 4)) for z in Z], max_inband_admittance=inband,
                 max_mismatch_at_constituents=float(match), max_difference_off_band=float(diff_off),
                 off_band_responses={str(k): [str(np.round(v[0], 4)), str(np.round(v[1], 4))] for k, v in off.items()},
                 note="room A: ten damped tidal-band modes fitted exactly; room B = A + a stable filter vanishing at every constituent: identical tidal constants, different off-band response")
# D8 hidden is not null: the non-tidal residual is recoverable from the record's own history up to its memory time
phi = ac1; res_test = y[~half] - pred_te; tide_test = pred_te; yt = y[~half]
nowcast = {}
for hh in (1, 3, 6, 12, 24, 48, 96, 168):
    errs_rg = yt[hh:] - (tide_test[hh:] + phi ** hh * res_test[:-hh]); errs_tide = yt[hh:] - tide_test[hh:]
    nowcast[str(hh)] = dict(rmse_tide_only=float(np.sqrt(np.mean(errs_tide ** 2))), rmse_tide_plus_memory=float(np.sqrt(np.mean(errs_rg ** 2))))
RES["D8"] = dict(ar1_coefficient=phi, horizons_h=nowcast,
                 note="tide-only prediction cannot see the non-tidal component (hidden for the tidal protocol); the record's history recovers it up to its decorrelation time")
must(nowcast["1"]["rmse_tide_plus_memory"] < 0.3 * nowcast["1"]["rmse_tide_only"] and nowcast["168"]["rmse_tide_plus_memory"] <= nowcast["168"]["rmse_tide_only"] * 1.05, "D8")
must(var_expl > 0.5 and skill > 0.5 and rmse_te >= floor - 1e-9 and c29 > 5 * c365, "data")
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_tide_real_results.json").write_text(json.dumps(RES, indent=1, default=float))
print(json.dumps({k: v for k, v in RES.items() if k in ("F1", "D2", "D3", "D4", "D5", "D6", "D8")}, indent=1, default=float))
print(RES["D1"]["variance_explained"], RES["D1"]["top_constituents"][:6]); print(RES["D7"]["max_difference_off_band"], RES["D7"]["off_band_responses"])
