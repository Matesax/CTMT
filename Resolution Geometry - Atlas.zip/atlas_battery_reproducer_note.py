# Full numeric results are in atlas_battery_results.json.
