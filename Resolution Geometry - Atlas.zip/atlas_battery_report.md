# RG Atlas Synthetic Falsification Battery v1

- seed: `20260713`
- base dimensions: `dim O=5`, `dim R=3`, `dim N=2`
- base canonical coupling singular values: `[0.15298089 0.07368975]`
- null-sector information gain Frobenius norm: `0.02346412`

## Master Results

| Battery | Atlas pass | Obstruction / confirmation | Key metric |
|---|---:|---|---:|
| B1_identity_atlas | PASS | confirmed | True |
| B2_admissible_gauge_control | PASS | confirmed | None |
| B3_coupling_stratum_mismatch | FAIL | coupling_stratum_mismatch | 9.570e-02 |
| B4_fisher_false_positive | FAIL | Fisher_only_false_positive_raw_blocks | 0.000e+00 |
| B5_null_sector_information_contribution | PASS | confirmed | 2.346e-02 |
| B6_pairwise_admissible_cocycle_fail | FAIL | incoherent_atlas_cocycle_failure | 5.619e-01 |
| B7_nontrivial_holonomy_valid | PASS | nontrivial_holonomy_class_not_failure | 8.359e-01 |
| B8_rank_changing_boundary | FAIL | rank_obstruction_stratified_boundary | False |
| B9_singular_covariance_support_boundary | n/a | singular_support_boundary_when_R_not_subset_range | None |
| B10_strict_vs_conformal_scale | n/a | strict_scale_mismatch_conformal_pass | 1.750e+00 |

## Interpretation
The attack behaves as expected: rank-only and Fisher-only compatibility are insufficient; canonical coupling strata and Cech cocycles create independent obstructions; nontrivial admissible holonomy is not atlas failure; rank-changing and singular-support cases are correctly reported as boundary cases.