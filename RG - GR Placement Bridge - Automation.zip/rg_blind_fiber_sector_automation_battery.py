import numpy as np
from scipy.optimize import minimize, brentq
from scipy.linalg import eigh, cholesky, solve_triangular, subspace_angles
np.set_printoptions(precision=6, suppress=True)

m2 = 0.7
lam = 0.12

def idx(t,x,Nt,Nx): return t*Nx+x

def metric_to_weights(gtt,gxx,q):
    sqrtg=np.sqrt(gtt*gxx)
    wt_node=q*sqrtg/gtt
    wx_node=q*sqrtg/gxx
    pot=q*sqrtg
    Nt,Nx=gtt.shape
    wt_face=wt_node.copy()
    wx_face=np.zeros_like(wx_node)
    for t in range(Nt):
        for x in range(Nx):
            wx_face[t,x]=0.5*(wx_node[t,x]+wx_node[t,(x+1)%Nx])
    return wt_face,wx_face,pot,wt_node,wx_node

def build_K(Nt,Nx,wt_face,wx_face,periodic_x=True):
    N=Nt*Nx; K=np.zeros((N,N))
    for t in range(Nt):
        for x in range(Nx):
            i=idx(t,x,Nt,Nx); j=idx((t+1)%Nt,x,Nt,Nx); w=wt_face[t,x]
            K[i,i]+=w; K[j,j]+=w; K[i,j]-=w; K[j,i]-=w
    xmax=Nx if periodic_x else Nx-1
    for t in range(Nt):
        for x in range(xmax):
            i=idx(t,x,Nt,Nx); j=idx(t,(x+1)%Nx,Nt,Nx); w=wx_face[t,x if x<Nx-1 else 0]
            K[i,i]+=w; K[j,j]+=w; K[i,j]-=w; K[j,i]-=w
    return 0.5*(K+K.T)

def frw_metric(Nt,Nx):
    eta=np.arange(Nt)
    a=1.0+0.22*np.sin(2*np.pi*eta/Nt+0.2)+0.08*np.cos(4*np.pi*eta/Nt)
    A=np.repeat((a*a)[:,None],Nx,axis=1)
    return A.copy(),A.copy(),np.ones((Nt,Nx)),True,{'a_min':float(a.min()),'a_max':float(a.max())}

def tortoise(r,M): return r+2*M*np.log(r/(2*M)-1)

def invert_tortoise(rs,M):
    lo=2*M*(1+1e-10); hi=max(10*M,rs+10*M)
    while tortoise(hi,M)<rs: hi*=2
    return brentq(lambda r: tortoise(r,M)-rs,lo,hi,maxiter=100)

def schwarz_metric(Nt,Nx,M=1.0,rmin=6.0,rmax=20.0):
    rs_min=tortoise(rmin,M); rs_max=tortoise(rmax,M)
    rstars=np.linspace(rs_min,rs_max,Nx)
    r=np.array([invert_tortoise(s,M) for s in rstars])
    f=1-2*M/r
    g=np.repeat(f[None,:],Nt,axis=0)
    q=np.repeat((r*r)[None,:],Nt,axis=0)
    return g.copy(),g.copy(),q,False,{'r_min':float(r.min()),'r_max':float(r.max()),'f_min':float(f.min()),'f_max':float(f.max())}

def flat_metric(Nt,Nx): return np.ones((Nt,Nx)),np.ones((Nt,Nx)),np.ones((Nt,Nx)),True,{}

def random_conformal_metric(Nt,Nx):
    T,X=np.meshgrid(np.arange(Nt),np.arange(Nx),indexing='ij')
    th=0.18*np.cos(2*np.pi*X/Nx+0.4)+0.09*np.sin(2*np.pi*T/Nt+0.2)+0.05*np.sin(2*np.pi*(T+X)/(Nt+Nx))
    g=np.exp(2*th)
    return g,g,np.ones((Nt,Nx)),True,{'theta_min':float(th.min()),'theta_max':float(th.max())}

def observation_matrix(Nt,Nx,block=2,noise_perturb=0.0,seed=0):
    rng=np.random.default_rng(seed); rows=[]
    for t0 in range(0,Nt,block):
        for x0 in range(0,Nx,block):
            row=np.zeros(Nt*Nx); pts=[]
            for dt in range(block):
                for dx in range(block): pts.append(idx((t0+dt)%Nt,(x0+dx)%Nx,Nt,Nx))
            weights=np.ones(len(pts))/len(pts)
            if noise_perturb>0:
                weights*=1+noise_perturb*rng.normal(size=len(pts)); weights/=np.sum(weights)
            for p,w in zip(pts,weights): row[p]=w
            rows.append(row)
    return np.vstack(rows)

def generalized_split(H,F,k):
    L=cholesky(H,lower=True)
    Y=solve_triangular(L,F,lower=True)
    C=solve_triangular(L,Y.T,lower=True).T
    C=0.5*(C+C.T)
    vals,U=eigh(C); order=np.argsort(vals)[::-1]
    vals=vals[order]; U=U[:,order]
    Q=solve_triangular(L.T,U,lower=False)
    G=Q.T@H@Q; d,V=eigh(0.5*(G+G.T)); Q=Q@V@np.diag(1/np.sqrt(np.maximum(d,1e-14)))@V.T
    return vals,Q[:,:k],Q[:,k:],Q

def physical_test_field(Nt,Nx):
    phi=np.zeros(Nt*Nx)
    for t in range(Nt):
        for x in range(Nx): phi[idx(t,x,Nt,Nx)] = 0.48*np.cos(2*np.pi*x/Nx-2*np.pi*t/Nt)+0.13*np.sin(4*np.pi*x/Nx+0.4)
    return phi

def action_phi(phi,K,pot): return 0.5*float(phi@K@phi)+float(np.sum(pot.reshape(-1)*(0.5*m2*phi**2+0.25*lam*phi**4)))
def grad_phi(phi,K,pot): return K@phi+pot.reshape(-1)*(m2*phi+lam*phi**3)

def eliminate(QR,QN,a,K,pot,n0=None,scale=1.0):
    if n0 is None: n0=np.zeros(QN.shape[1])
    z0=scale*n0
    def unpack(z): return z/scale
    def fun(z): return action_phi(QR@a+QN@unpack(z),K,pot)
    def jac(z): return (QN.T@grad_phi(QR@a+QN@unpack(z),K,pot))/scale
    res=minimize(fun,z0,jac=jac,method='L-BFGS-B',options={'gtol':1e-12,'ftol':1e-14,'maxiter':3000})
    return res.fun,unpack(res.x),res

def random_capture_whitened(vals,k,ntrials=20,seed=123):
    rng=np.random.default_rng(seed); caps=[]; total=np.sum(np.maximum(vals,0))
    D=np.diag(np.maximum(vals,0))
    for _ in range(ntrials):
        Z=rng.normal(size=(len(vals),k)); U,_=np.linalg.qr(Z)
        caps.append(float(np.trace(U.T@D@U)/max(total,1e-14)))
    return float(np.mean(caps))

def run_case(bg,Nt,Nx,kfrac=0.28,perturb=0.02):
    if bg=='FRW': gtt,gxx,q,periodic,meta=frw_metric(Nt,Nx)
    elif bg=='Schwarzschild': gtt,gxx,q,periodic,meta=schwarz_metric(Nt,Nx)
    elif bg=='Flat': gtt,gxx,q,periodic,meta=flat_metric(Nt,Nx)
    elif bg=='RandomConformal': gtt,gxx,q,periodic,meta=random_conformal_metric(Nt,Nx)
    else: raise ValueError(bg)
    wt,wx,pot,wt_node,wx_node=metric_to_weights(gtt,gxx,q)
    K=build_K(Nt,Nx,wt,wx,periodic_x=periodic)
    H=K+m2*np.diag(pot.reshape(-1))+1e-10*np.eye(Nt*Nx)
    B=observation_matrix(Nt,Nx,block=2,seed=1); F=B.T@B
    n=Nt*Nx; k=max(2,min(B.shape[0],int(kfrac*n)))
    vals,QR,QN,Q=generalized_split(H,F,k)
    phi0=physical_test_field(Nt,Nx); a=QR.T@H@phi0
    W,b,res=eliminate(QR,QN,a,K,pot)
    phi=QR@a+QN@b; grad=grad_phi(phi,K,pot)
    stat=float(np.linalg.norm(QN.T@grad,np.inf)); relstat=stat/(1+float(np.linalg.norm(grad,np.inf)))
    rng=np.random.default_rng(42); sites=np.sort(rng.choice(np.arange(n),size=min(10,n),replace=False)); h=1e-5
    errs=[]; exvals=[]
    for p in sites:
        pot_p=pot.reshape(-1).copy(); pot_m=pot.reshape(-1).copy()
        pot_p[p]*=np.exp(2*h); pot_m[p]*=np.exp(-2*h)
        Wp,_,_=eliminate(QR,QN,a,K,pot_p.reshape(Nt,Nx),n0=b)
        Wm,_,_=eliminate(QR,QN,a,K,pot_m.reshape(Nt,Nx),n0=b)
        fd=(Wp-Wm)/(2*h)
        ex=2*pot.reshape(-1)[p]*(0.5*m2*phi[p]**2+0.25*lam*phi[p]**4)
        errs.append(abs(fd-ex)); exvals.append(abs(ex))
    W3,b3,_=eliminate(QR,QN,a,K,pot,n0=b,scale=3.0)
    B2=observation_matrix(Nt,Nx,block=2,noise_perturb=perturb,seed=2); F2=B2.T@B2
    _,QR2,_,_=generalized_split(H,F2,k)
    U1,_=np.linalg.qr(QR); U2,_=np.linalg.qr(QR2)
    angle=float(np.max(subspace_angles(U1,U2)))
    total=np.sum(np.maximum(vals,0)); obs_auto=float(np.sum(np.maximum(vals[:k],0))/max(total,1e-14))
    obs_rand=random_capture_whitened(vals,k)
    rec={}
    if bg=='FRW':
        rec['metric_weight_error']=float(max(np.linalg.norm(wt-1)/np.linalg.norm(np.ones_like(wt)), np.linalg.norm(wx-1)/np.linalg.norm(np.ones_like(wx)), np.linalg.norm(pot-gtt)/np.linalg.norm(gtt)))
    elif bg=='Schwarzschild':
        f=gtt; expected_pot=q*f
        # expected kinetic nodes are q; compare temporal faces to q and spatial faces to averaged q.
        q_face=np.zeros_like(q)
        for t in range(Nt):
            for x in range(Nx): q_face[t,x]=0.5*(q[t,x]+q[t,(x+1)%Nx])
        rec['metric_weight_error']=float(max(np.linalg.norm(wt-q)/np.linalg.norm(q), np.linalg.norm(wx[:,:-1]-q_face[:,:-1])/np.linalg.norm(q_face[:,:-1]), np.linalg.norm(pot-expected_pot)/np.linalg.norm(expected_pot)))
    else: rec['metric_weight_error']=0.0
    return dict(background=bg,grid=f'{Nt}x{Nx}',n=n,k=k,Wobs=float(W),success=bool(res.success),stat_inf=stat,stat_rel=relstat,
                envelope_abs=float(max(errs)),envelope_rel=float(max(errs)/(1e-12+max(exvals))),quotient_W_error_s3=float(abs(W3-W)),
                quotient_b_rel_s3=float(np.linalg.norm(b3-b)/(1e-12+np.linalg.norm(b))),split_angle_perturbed_obs_rad=angle,
                obs_capture_auto=obs_auto,obs_capture_random_mean=obs_rand,cond_HNN_auto=float(np.linalg.cond(QN.T@H@QN)),**rec,**meta)

if __name__=='__main__':
    results=[]
    for bg in ['Flat','RandomConformal','FRW','Schwarzschild']:
        for N in [8,10]: results.append(run_case(bg,N,N))
    print('BLIND FIBER-SECTOR AUTOMATION BATTERY v2')
    for r in results: print(r)
