"""Observation-cone closure attack. Seed 20260820.
Analytic/synthetic checks of causal order, conformal invariance, clock-scale selection,
and astronomical parameter degeneracy. Not an empirical astronomy analysis.
"""
import json
from pathlib import Path
import numpy as np

SEED=20260820
N=150000
rng=np.random.default_rng(SEED)
checks={}
def add(name, ok, detail, value=None, threshold=None):
    d={"passed":bool(ok),"detail":detail}
    if value is not None: d["value"]=float(value)
    if threshold is not None: d["threshold"]=float(threshold)
    checks[name]=d

# 1+1 Minkowski causal relation; random positive conformal factors preserve cone signs.
dt=rng.uniform(-4,4,N); dx=rng.uniform(-4,4,N)
q=-dt*dt+dx*dx
omega=np.exp(rng.normal(0,0.8,N))
q2=omega*omega*q
cone_mismatch=np.mean(np.sign(q)!=np.sign(q2))
add("positive_conformal_rescaling_preserves_cones",cone_mismatch==0,
    "Positive conformal factors preserve timelike/null/spacelike classification.",cone_mismatch,0)
future=(dt>=0)&(q<=0); future2=(dt>=0)&(q2<=0)
order_mismatch=np.mean(future!=future2)
add("positive_conformal_rescaling_preserves_causal_order",order_mismatch==0,
    "Time orientation fixed; future causal relation is unchanged.",order_mismatch,0)

# Boundary speed is invariant under conformal rescaling.
slopes=np.array([-1.0,1.0]); null_res=np.max(np.abs(-slopes**0+slopes**2)) # -1+s^2
add("null_boundary_identified",null_res<1e-15,"Null boundary satisfies |dx/dt|=1 in calibrated units.",null_res,1e-15)

# Preorder must descend: construct equivalence classes and verify representative independence.
classes=np.array([0,0,1,2,2,3])
# causal relation on quotient classes
R=np.array([[1,1,1,1],[0,1,1,1],[0,0,1,1],[0,0,0,1]],dtype=bool)
Rl=R[classes[:,None],classes[None,:]]
well=True
for a in range(4):
  idx=np.where(classes==a)[0]
  for b in range(4):
    jdx=np.where(classes==b)[0]
    well &= np.all(Rl[np.ix_(idx,jdx)]==R[a,b])
add("causal_preorder_descends_to_observation_quotient",well,
    "Relation is constant on observational equivalence classes in both arguments.")

# Counterattack: arbitrary latent relation not fibre-compatible.
Rbad=Rl.copy(); Rbad[0,2]=~Rbad[0,2]
compatible=True
for a in range(4):
  idx=np.where(classes==a)[0]
  for b in range(4):
    jdx=np.where(classes==b)[0]
    compatible &= np.all(Rbad[np.ix_(idx,jdx)]==Rbad[idx[0],jdx[0]])
add("noncompatible_causal_relation_rejected",not compatible,
    "A relation varying inside one observation fibre cannot define quotient causal order.")

# Clock attack. T=-log C additive iff C multiplicative.
t1=rng.uniform(.001,3,N); t2=rng.uniform(.001,3,N)
C1=np.exp(-t1); C2=np.exp(-t2); C12=C1*C2
T_res=np.max(np.abs(-np.log(C12)-(-np.log(C1)-np.log(C2))))
add("zero_memory_log_coherence_additive",T_res<2e-15,
    "Multiplicative coherence yields additive T=-log C.",T_res,2e-15)
# memory correction produces detectable nonadditivity
M=rng.normal(0,.2,N); T02=t1+t2+M
mem_res=np.max(np.abs(T02-(t1+t2+M)))
nonadd=np.mean(np.abs(T02-(t1+t2)))
add("memory_corrected_composition_consistent",mem_res<1e-15,
    "T02=T01+T12+M012 implemented exactly.",mem_res,1e-15)
add("nonzero_memory_rejects_additive_clock",nonadd>.1,
    "Generic memory term prevents unqualified additivity.",nonadd,.1)

# Scale identifiability: one reference worldline clock fixes Omega only along that curve,
# not off it. Construct two conformal factors identical on x=0 but different elsewhere.
t=rng.uniform(-2,2,N); x=rng.uniform(-2,2,N)
Om1=np.ones(N); Om2=1+0.25*x*x
on_curve=np.abs(x)<1e-3
off_curve=np.abs(x)>.5
on_gap=np.max(np.abs(Om2[on_curve]-Om1[on_curve])) if np.any(on_curve) else 0
# exact symbolic condition at x=0, numerical off-curve check
add("single_worldline_clock_does_not_fix_global_scale",np.mean(np.abs(Om2[off_curve]-Om1[off_curve]))>.1,
    "Omega1=1 and Omega2=1+x^2/4 agree at x=0 but differ off the calibrated worldline.",
    np.mean(np.abs(Om2[off_curve]-Om1[off_curve])),.1)
# Dense/local clock calibration simulated as Omega samples at points: recovers factor there.
pts=rng.uniform(-1,1,(5000,2)); true_Om=np.exp(.15*pts[:,0]-.1*pts[:,1])
measured=true_Om*(1+rng.normal(0,1e-4,len(true_Om)))
rel=np.sqrt(np.mean(((measured-true_Om)/true_Om)**2))
add("local_clock_field_can_select_conformal_representative",rel<2e-4,
    "A calibrated local clock field determines the conformal factor pointwise in the synthetic realization.",rel,2e-4)

# Astronomy degeneracy: d(z)= (v/H0)*f(z). Same ratio => same law.
z=np.linspace(.001,2,1000); f=np.log1p(z)
v1,H1=299792.458,70.0
scale=1.17; v2,H2=v1*scale,H1*scale
d1=(v1/H1)*f; d2=(v2/H2)*f
deg=np.max(np.abs(d1-d2))
add("astronomy_ratio_degeneracy",deg<1e-10,
    "Synthetic redshift-distance law identifies v_boundary/H0, not either parameter alone.",deg,1e-10)
# Independent H0 calibration recovers v.
Hobs=H1*(1+rng.normal(0,.005,10000)); Robs=(v1/H1)*(1+rng.normal(0,.003,10000)); vest=Hobs*Robs
bias=abs(np.mean(vest)-v1)/v1
add("independent_calibration_recovers_boundary_speed",bias<5e-4,
    "Independent scale calibration breaks the ratio degeneracy.",bias,5e-4)
# redshift-dependent violation leaves structured residual after best constant fit.
eps=.08; dviol=(v1/H1)*(1+eps*z/(1+z))*f
rhat=np.dot(f,dviol)/np.dot(f,f); resid=dviol-rhat*f
frac=np.sqrt(np.mean(resid**2))/np.mean(dviol)
add("redshift_dependent_boundary_violation_detectable",frac>.003,
    "A varying boundary speed is not absorbed by one constant ratio.",frac,.003)
# Cross-stratum consistency test
vlocal=v1*(1+rng.normal(0,2e-5,20000)); vastro=v1*(1+rng.normal(0,3e-3,20000))
zscore=abs(np.mean(vlocal)-np.mean(vastro))/np.sqrt(np.var(vlocal)/len(vlocal)+np.var(vastro)/len(vastro))
add("cross_stratum_constant_speed_consistency",zscore<3,
    "Synthetic local and astronomical calibrated estimates are statistically consistent.",zscore,3)

passed=sum(v['passed'] for v in checks.values()); total=len(checks)
result={"seed":SEED,"samples":N,"checks":checks,"passed":passed,"total":total,"all_passed":passed==total,
"verdict":{
 "causal_lock":"A causal relation descends only if fibre-compatible; under distinguishing Lorentzian realization it determines conformal geometry, not scale.",
 "clock_lock":"T=-log C is additive only on the multiplicative/zero-memory stratum. A single clock worldline does not fix a spacetime-wide conformal factor; a local calibrated clock field or equivalent volume/scale data is required.",
 "astronomy_lock":"Astronomy is a cross-stratum test. A redshift-distance law may identify only v_boundary/H0 until independent calibration is supplied.",
 "physics_boundary":"Identifying the calibrated cone boundary with c is an empirical physical identification, not a quotient theorem.",
 "nonclaim":"No Einstein equations or GR dynamics are derived."
}}
Path('/mnt/data/observation_cone_final_attack.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({"passed":passed,"total":total,"all_passed":passed==total},indent=2))
for k,v in checks.items(): print(('PASS' if v['passed'] else 'FAIL'),k,v.get('value',''))
