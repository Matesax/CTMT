"""Attack battery for quotient-level cone invariance across local and astronomical strata.
Synthetic calibration study; it does not use real astronomical data and does not derive c.
"""
import json
from pathlib import Path
import numpy as np

SEED=20260820
rng=np.random.default_rng(SEED)
C_KMS=299792.458
H0=70.0
OM=0.3
OL=0.7

# ---------- helpers ----------
def E(z): return np.sqrt(OM*(1+z)**3+OL)
def cumtrapz(y,x):
    out=np.zeros_like(x)
    out[1:]=np.cumsum(0.5*(y[1:]+y[:-1])*np.diff(x))
    return out

def weighted_ls(X,y,s):
    Xw=X/s[:,None]; yw=y/s
    b=np.linalg.lstsq(Xw,yw,rcond=None)[0]
    r=(y-X@b)/s
    return b,float(np.sum(r*r))

checks={}
def add(name,ok,detail,value=None,threshold=None):
    d={"passed":bool(ok),"detail":detail}
    if value is not None: d["value"]=float(value)
    if threshold is not None: d["threshold"]=float(threshold)
    checks[name]=d

# ---------- stratum L: local time-of-flight ----------
# Delays are generated from known baselines.  This independently fixes a dimensional speed scale.
L_km=np.geomspace(1e-3,1e6,180)
sig_t=2e-10 + 2e-7*(L_km/L_km.max()) # seconds
true_t=L_km/C_KMS
t_obs=true_t+rng.normal(0,sig_t)
# Fit t = q L, q=1/v.
q,chiL=weighted_ls(L_km[:,None],t_obs,sig_t)
v_local=1/q[0]
rel_local=abs(v_local/C_KMS-1)
add("local_dimensional_calibration_recovers_boundary",rel_local<2e-4,
    "Known baselines and delays recover the local cone scale.",rel_local,2e-4)

# ---------- stratum A: astronomical radial-null relation ----------
zgrid=np.linspace(0,3.0,5001)
Jgrid=cumtrapz(1/E(zgrid),zgrid)
z=np.sort(rng.uniform(0.01,3.0,260))
J=np.interp(z,zgrid,Jgrid)
chi_true=(C_KMS/H0)*J # Mpc
sig_chi=0.018*chi_true+8.0
chi_obs=chi_true+rng.normal(0,sig_chi)
# If H0 is independently calibrated, fit chi=(v/H0)J.
coef,chiA=weighted_ls(J[:,None],chi_obs,sig_chi)
v_astro=coef[0]*H0
rel_astro=abs(v_astro/C_KMS-1)
add("astronomical_fixed_H0_recovers_same_scale",rel_astro<0.01,
    "With independent H0 calibration, null-distance data recover the injected boundary.",rel_astro,0.01)

# Shared vs separate cone scale under independent calibration.
# local equation uses q=1/v and is nonlinear in v; compare estimates by normalized discrepancy.
# uncertainty estimates from linear fits.
varq=np.linalg.inv((L_km[:,None]/sig_t[:,None]).T@(L_km[:,None]/sig_t[:,None]))[0,0]
sig_v_local=np.sqrt(varq)/(q[0]**2)
varcoef=np.linalg.inv((J[:,None]/sig_chi[:,None]).T@(J[:,None]/sig_chi[:,None]))[0,0]
sig_v_astro=H0*np.sqrt(varcoef)
zscore=abs(v_local-v_astro)/np.sqrt(sig_v_local**2+sig_v_astro**2)
add("cross_stratum_boundary_consistency",zscore<3.0,
    "Local and astronomical calibrated estimates agree within three combined standard errors.",zscore,3.0)

# ---------- exact scale degeneracy attack ----------
# Astronomy identifies beta=v/H0, not v and H0 separately.
beta_true=C_KMS/H0
lambdas=np.geomspace(0.2,5.0,50)
pred0=beta_true*J
max_degen=0.0
for lam in lambdas:
    v=lam*C_KMS; h=lam*H0
    max_degen=max(max_degen,float(np.max(np.abs((v/h)*J-pred0))))
add("astronomical_scale_degeneracy_exact",max_degen<1e-10,
    "Simultaneous scaling (v,H0)->(lambda v,lambda H0) leaves radial-null distances unchanged.",max_degen,1e-10)

# Jacobian rank of chi=(v/H)J with respect to v,H is one.
Jac=np.column_stack([J/H0,-C_KMS*J/H0**2])
svals=np.linalg.svd(Jac,compute_uv=False)
rank=int(np.sum(svals>svals[0]*1e-12))
add("astronomical_absolute_scale_rank_deficient",rank==1,
    "Distance-redshift data alone identify only v/H0.",rank,1)

# Cone is invariant under common conformal/unit rescaling: slope scale cannot be numerical without clock/ruler normalization.
# Null equation -v^2 dt^2+a^2 dchi^2=0 remains zero under metric multiplication Omega^2.
dt=rng.uniform(1e-6,2.0,500)
a=rng.uniform(0.1,1.0,500)
dchi=C_KMS*dt/a
omega=rng.uniform(0.1,10.0,500)
null0=-C_KMS**2*dt**2+a**2*dchi**2
null1=omega**2*null0
null_res=max(np.max(np.abs(null0)),np.max(np.abs(null1)))
# Floating cancellation grows with units; use scale-normalized residual.
scale=C_KMS**2*dt**2
norm_res=max(np.max(np.abs(null0)/scale),np.max(np.abs(null1)/(omega**2*scale)))
add("cone_structure_scale_free",norm_res<1e-12,
    "Conformal multiplication preserves the null boundary and does not set its dimensional normalization.",norm_res,1e-12)

# ---------- stratum-varying boundary attack ----------
# Generate alternative data v(z)=v0[1+eps z/(1+z)] and test whether enriched astronomy detects it.
eps_true=0.035
f=zgrid/(1+zgrid)
J0=cumtrapz(1/E(zgrid),zgrid)
J1=cumtrapz(f/E(zgrid),zgrid)
K0=np.interp(z,zgrid,J0); K1=np.interp(z,zgrid,J1)
chi_var=(C_KMS/H0)*(K0+eps_true*K1)
sig_var=0.004*chi_var+1.0
obs_var=chi_var+rng.normal(0,sig_var)
# constant model y=b0 K0; varying model y=b0 K0+b1 K1, eps=b1/b0
b_const,chis_const=weighted_ls(K0[:,None],obs_var,sig_var)
b_var,chis_var=weighted_ls(np.column_stack([K0,K1]),obs_var,sig_var)
eps_hat=b_var[1]/b_var[0]
dchi=chis_const-chis_var
add("enriched_astronomy_detects_stratum_variation",dchi>25,
    "A redshift-dependent cone scale is rejected against the injected varying-boundary alternative.",dchi,25)
add("variation_parameter_recovered",abs(eps_hat-eps_true)<0.01,
    "The injected cross-stratum drift is recovered.",abs(eps_hat-eps_true),0.01)

# ---------- wrong cosmological realization attack ----------
# Fit the constant-boundary data with an Einstein-de Sitter expansion law. Cone coefficient absorbs some mismatch, not all.
E_wrong=(1+zgrid)**1.5
J_wrong_grid=cumtrapz(1/E_wrong,zgrid)
J_wrong=np.interp(z,zgrid,J_wrong_grid)
_,chi_wrong=weighted_ls(J_wrong[:,None],chi_obs,sig_chi)
delta_wrong=chi_wrong-chiA
add("cosmology_cone_model_nonseparable_without_assumptions",delta_wrong>100,
    "Wrong expansion history degrades fit: cone calibration depends on the cosmological realization.",delta_wrong,100)

# Redshift identity is model/realization input, not a quotient theorem.
add("redshift_scale_factor_relation_flagged_as_input",True,
    "The battery treats 1+z=a0/aem and E(z) as realization assumptions, not consequences of observational quotienting.")

passed=sum(v["passed"] for v in checks.values()); total=len(checks)
result={
 "seed":SEED,"synthetic":True,"constants":{"c_km_s":C_KMS,"H0_km_s_Mpc":H0,"Omega_m":OM,"Omega_L":OL},
 "checks":checks,"passed":passed,"total":total,"all_passed":passed==total,
 "estimates":{"v_local_km_s":float(v_local),"v_astronomical_fixed_H0_km_s":float(v_astro),"cross_stratum_zscore":float(zscore),"eps_injected":eps_true,"eps_recovered":float(eps_hat),"delta_chi2_variation":float(dchi),"delta_chi2_wrong_cosmology":float(delta_wrong)},
 "verdict":{
  "structural":"A common null-boundary parameter can be tested for invariance across local and astronomical observational strata.",
  "calibration":"Astronomical distance-redshift data recover the dimensional boundary only after an independent scale calibration such as H0 or an equivalent ruler/clock normalization.",
  "noncircular_limit":"The cone supplies causal structure; it does not supply the numerical value c. Identification with c is an empirical cross-stratum calibration statement.",
  "model_dependence":"Redshift-scale-factor and distance-redshift relations belong to the chosen cosmological realization and cannot be claimed as quotient-only theorems.",
  "falsifiability":"A sufficiently enriched redshift-distance protocol can detect a stratum-dependent boundary, subject to cosmological-model and calibration assumptions."
 }
}
Path('/mnt/data/astronomical_cone_invariance_attack.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({"passed":passed,"total":total,"all_passed":passed==total,"estimates":result["estimates"]},indent=2))
