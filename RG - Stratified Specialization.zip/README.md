# RG - Stratified Specialization: battery SP01-SP11

    python3 rg_stratified_specialization_attack.py            # seed 20261001 (seconds)
    python3 rg_stratified_specialization_attack.py --canary   # 5 code-path mutations; each must fail

11/11 on seeds 20261001, 1, 42, 777, 2026; canary 5/5. All limits, kernels, stabilizers and certificates are
computed; each theorem hypothesis has a counterexample (pointwise convergence, missing inclusion, missing
normalizer, weak convergence). Replaces SC01-SC12 (see paper, Appendix B).
