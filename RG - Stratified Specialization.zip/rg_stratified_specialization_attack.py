#!/usr/bin/env python3
"""
RG stratified specialization: locked battery SP01-SP11
=====================================================
Every limit, kernel, stabilizer and certificate is COMPUTED from the families; nothing is hard-coded.
Each theorem hypothesis has a counterexample showing it is necessary. --canary mutates the certifier code
paths (not boolean flags) and requires the targeted check to fail.

  SP01 kernel upper semicontinuity (linear and nonlinear families)     SP07 latent walls: fold/cusp strata
  SP02 local uniformity is necessary (moving-bump counterexample)      SP08 natural modules specialize; CRB blows up
  SP03 specialization map exists iff K_eps <= K_0; else a correspondence SP09 connection no-go (L58 independence)
  SP04 functoriality of specializations (computed factorizations)      SP10 statistical rank certificates
  SP05 symmetry descent = normalizer of K_0; wall isotropy can grow    SP11 Le Cam: experiment convergence
  SP06 metric gate: Hellinger, not weak, convergence                        controls decision risk

Run:  python3 rg_stratified_specialization_attack.py [--seed 20261001] [--out FILE] [--canary]
"""
import argparse, itertools, json, math, sys, time
import numpy as np
from scipy.stats import norm

RESULTS, MUT = [], {}


def f(x): return float(np.round(float(x), 12))


def _finite(o):
    if isinstance(o, dict): return all(_finite(v) for v in o.values())
    if isinstance(o, (list, tuple)): return all(_finite(v) for v in o)
    if isinstance(o, float): return math.isfinite(o)
    return True


def register(aid, naive, keep, passed, ev, verdict):
    if not _finite(ev): passed, verdict = False, "NONFINITE"
    RESULTS.append(dict(id=aid, naive_claim=naive, rg_claim=keep, passed=bool(passed), verdict=verdict, evidence=ev))
    print(f"[{'PASS' if passed else 'FAIL'}] {aid} {verdict:16s} {keep[:84]}")


def kernel(A, tol=1e-9):
    u, s, vt = np.linalg.svd(A); r = int(np.sum(s > tol*max(1, s[0]))); return vt[r:].T


def incl_defect(Kl, Kw):
    """|| (I - P_w) P_l ||: zero iff span(Kl) is contained in span(Kw)."""
    if Kl.shape[1] == 0: return 0.0
    Pw = Kw @ Kw.T if Kw.shape[1] else np.zeros((Kl.shape[0],)*2)
    return float(np.linalg.norm((np.eye(Kl.shape[0])-Pw) @ (Kl @ Kl.T)))


# ======================================================================= checks
def SP01_usc(rng):
    """A_eps = A_0 + eps B, A_0 of rank r < m < n: ker A_eps (dim n-m) rotates and must converge into
    ker A_0 (dim n-r). Nonlinear: F_eps(x) = tanh(A_eps x) at random base points. Rank is lower
    semicontinuous: rank A_0 <= rank A_eps."""
    worst_small, slopes, rank_ok = 0.0, [], True
    for _ in range(200):
        m, n = int(rng.integers(2, 5)), 0; n = m + int(rng.integers(1, 3)); r = int(rng.integers(0, m))
        A0 = rng.normal(size=(m, r)) @ rng.normal(size=(r, n)) if r else np.zeros((m, n)); B = rng.normal(size=(m, n))
        Kw = kernel(A0); ds = []
        for eps in (1e-2, 1e-4, 1e-6):
            Ae = A0 + eps*B
            x0 = 0.1*rng.normal(size=n)/max(1.0, np.linalg.norm(Ae))   # keep sech^2 ~ 1 (well-conditioned)
            J = np.diag(1-np.tanh(Ae @ x0)**2) @ Ae               # nonlinear family Jacobian, same kernel
            ds.append(incl_defect(kernel(J), Kw))
            rank_ok &= np.linalg.matrix_rank(A0, tol=1e-9) <= np.linalg.matrix_rank(Ae, tol=1e-12)
        worst_small = max(worst_small, ds[-1])
        if ds[0] > 1e-12: slopes.append(math.log10(ds[0]/max(ds[1], 1e-300))/2)
    passed = worst_small < 1e-4 and rank_ok and np.median(slopes) > 0.9
    register("SP01", "A kernel present on the regular stratum can be lost at the wall.",
             "Kernel upper semicontinuity: every limit of regular kernels lies in the wall kernel (defect decays "
             "linearly in eps); rank can only drop at a wall.",
             passed, dict(max_inclusion_defect_eps_1em6=f(worst_small), median_decay_order=f(np.median(slopes)),
                          rank_lower_semicontinuous=bool(rank_ok), families=200), "HOLDS")


def SP02_uniformity(rng):
    """Moving bump: F_eps(x) = x + B_eps(x), bump of height H at x = eps with width eps^2. Pointwise
    F_eps -> F_0 = id, but the pair (eps, eps + H) lies in K_eps and converges to (0, H), not in K_0.
    With height eps (uniform convergence) no such pair survives."""
    def F(eps, x, H):
        return x + H*np.maximum(0, 1-np.abs(x-eps)/eps**2)
    out = {}
    for H, label in ((1.0, "pointwise_only"), (None, "uniform")):
        viol, sup, pw = [], [], []
        for eps in (1e-1, 1e-2, 1e-3, 1e-4):
            h = H if H is not None else eps
            a = eps; b = a + h                                   # F(a) = a + h = F(b) = b (b outside bump)
            pair_ok = abs(F(eps, a, h) - F(eps, b, h)) < 1e-12
            viol.append(abs(b - a) if pair_ok else 0.0)          # F_0 = id distinguishes a, b by |b-a|
            grid = np.linspace(-1, 2, 3001); sup.append(float(np.max(np.abs(F(eps, grid, h)-grid))))
            pw.append(float(abs(F(eps, 0.5, h)-0.5)))
        out[label] = dict(limit_violation=f(viol[-1]), sup_norm=f(sup[-1]), pointwise_at_half=f(pw[-1]))
    # no-go: the grid sup-norm (spacing 1e-3) does not see a bump of width eps^2 -> it reads 0
    grid_blind = out["pointwise_only"]["sup_norm"] < 1e-12 and out["pointwise_only"]["limit_violation"] > 0.5
    # certifier: uniform convergence must be DECLARED with a modulus (Lipschitz L) and checked at visible scales
    def certifier(declared_L, fam_H):
        if MUT.get("sp02_grid_supnorm"): return "SPECIALIZE"           # trusts the blind grid sup-norm
        if declared_L is None: return "ABSTAIN"
        for eps in (1e-1, 3e-2, 1e-2):
            h = fam_H if fam_H is not None else eps
            g = np.linspace(eps-2*eps**2, eps+2*eps**2, 401); slope = np.max(np.abs(np.diff(F(eps, g, h)-g)/np.diff(g)))
            if slope > declared_L: return "REFUSE"
        return "SPECIALIZE"
    cert = dict(undeclared=certifier(None, 1.0), declared_L10_pointwise=certifier(10.0, 1.0))
    passed = (grid_blind and out["uniform"]["limit_violation"] < 1e-3 and cert["undeclared"] == "ABSTAIN" and
              cert["declared_L10_pointwise"] == "REFUSE")
    register("SP02", "Pointwise convergence of the law suffices for kernel specialization.",
             "No: a moving bump converges pointwise but carries an identified pair to a separated pair. Locally "
             "uniform convergence is required, and it cannot be certified by sampling (a grid reads sup-norm 0): it "
             "must be declared with a modulus, which the certifier checks at visible scales, or it abstains.",
             passed, dict(families=out, certifier=cert), "FALSIFIED-naive")


def quotient_labels(laws, tol=1e-12):
    labs, reps = [], []
    for v in laws:
        for i, r in enumerate(reps):
            if np.max(np.abs(v-r)) < tol: labs.append(i); break
        else: reps.append(v); labs.append(len(reps)-1)
    return np.array(labs)


def factor_map(lab_from, lab_to):
    """sigma: Q_from -> Q_to with lab_to = sigma(lab_from); None if not well defined."""
    sig = {}
    for a, b in zip(lab_from, lab_to):
        if sig.setdefault(int(a), int(b)) != b: return None
    return sig


def SP03_map_iff_inclusion(rng):
    """(a) Garbling walls F_0 = M F_eps: K_eps <= K_0 and sigma exists. (b) F_eps(x) = x^2 + eps x:
    K_eps contains (x, -x-eps), not in K_0, so no specialization MAP exists; the limit relation
    limsup K_eps = {(x,-x)} <= K_0 survives as a correspondence."""
    ok_garb = 0
    for _ in range(100):
        k, n = 5, 8; laws = rng.dirichlet(np.ones(k), size=n)
        M = np.zeros((k, 3)); M[np.arange(k), rng.integers(0, 3, k)] = 1    # deterministic outcome merge
        lab_e, lab_0 = quotient_labels(laws), quotient_labels(laws @ M)
        ok_garb += factor_map(lab_e, lab_0) is not None
    xs = rng.uniform(-2, 2, 200); eps_list = (1e-1, 1e-3, 1e-5)
    pair_in_Ke = max(abs((x**2+e*x)-((-x-e)**2+e*(-x-e))) for x in xs for e in eps_list)
    pair_in_K0 = min(abs(x**2-(-x-e)**2) for x in xs for e in (1e-1,))
    limit_rel = max(abs(x**2-(-x)**2) for x in xs)
    passed = ok_garb == 100 and pair_in_Ke < 1e-12 and pair_in_K0 > 0 and limit_rel < 1e-12
    register("SP03", "A specialization map Q_eps -> Q_0 always exists at a wall.",
             "Only iff K_eps <= K_0 (e.g. garbling walls). Otherwise specialization is the limit correspondence "
             "limsup K_eps <= K_0, not a map: x^2 + eps x identifies (x, -x-eps), which the wall separates.",
             passed, dict(garbling_maps_exist=f"{ok_garb}/100", pair_in_K_eps_defect=f(pair_in_Ke),
                          same_pair_separated_at_wall_min=f(pair_in_K0), limit_relation_defect=f(limit_rel)), "FALSIFIED-naive")


def SP04_functoriality(rng):
    """Chain of coarsenings K_eps <= K_delta <= K_0 on finite X: computed factorizations compose,
    sigma_{delta,0} o sigma_{eps,delta} = sigma_{eps,0}. A sabotaged intermediate map (nearest-law matching)
    breaks commutation."""
    good, bad = 0, 0
    for _ in range(100):
        n, k = 24, 6
        Le = rng.dirichlet(np.ones(k), size=n)
        Ld = rng.dirichlet(np.ones(k), size=n//2)[np.arange(n)//2]          # depends on x//2
        L0 = rng.dirichlet(np.ones(k), size=n//6)[np.arange(n)//6]          # depends on x//6
        le, ld, l0 = quotient_labels(Le), quotient_labels(Ld), quotient_labels(L0)
        s_ed, s_d0, s_e0 = factor_map(le, ld), factor_map(ld, l0), factor_map(le, l0)
        if MUT.get("sp04_nearest"):
            reps_d = {int(b): Ld[np.where(ld == b)[0][0]] for b in set(ld.tolist())}
            s_ed = {int(a): min(reps_d, key=lambda b: np.linalg.norm(reps_d[b]-Le[np.where(le == a)[0][0]])) for a in set(le.tolist())}
        comp = all(s_d0[s_ed[a]] == s_e0[a] for a in s_e0)
        good += comp
        alt = {a: (s_ed[a]+1) % (max(s_ed.values())+1) for a in s_ed}               # a non-factorization map
        bad += not all(s_d0.get(alt[a], -1) == s_e0[a] for a in s_e0)
    passed = good == 100 and bad >= 95
    register("SP04", "Specializations need to be chosen consistently by hand.",
             "They are unique factorizations, hence compose: sigma_{d0} o sigma_{ed} = sigma_{e0} in 100/100 chains; "
             "a map that is not the factorization fails commutation.",
             passed, dict(commuting_chains=good, sabotage_detected=bad), "HOLDS")


def SP05_symmetry_descent(rng):
    """Finite X (6 points), outcomes 3, relabelings Psi = S_3 on outcomes. Stab is computed by brute force.
    A regular symmetry descends to Q_0 iff it preserves K_0. The wall can have STRICTLY larger effective
    symmetry: generic regular laws (trivial Gamma) specialize to cyclically related wall laws (Gamma_0 >= Z3)."""
    X = range(6); perms_x = list(itertools.permutations(X)); perms_y = list(itertools.permutations(range(3)))
    def stab(L):
        S = []
        for ph in perms_x:
            for ps in perms_y:
                if all(np.max(np.abs(L[ph[x]]-L[x][list(ps)])) < 1e-12 for x in X): S.append((ph, ps)); break
        return S
    # regular: injective law with a built-in symmetry (swap 0<->1 with outcome swap) to have nontrivial Stab
    def sym():                                                     # law with q0 = q1 (invariant under outcome swap)
        a = rng.uniform(0.05, 0.45); return np.array([a, a, 1-2*a])
    pr = rng.dirichlet(np.ones(3))
    while abs(pr[0]-pr[1]) < 0.05: pr = rng.dirichlet(np.ones(3))
    # regular symmetry phi = (1 2) with outcome swap (0 1): crosses the wall classes {0,1},{2,3},{4,5}
    Le = np.array([sym(), pr, pr[[1, 0, 2]], sym(), sym(), sym()])
    q = rng.dirichlet(np.ones(3)); q = q[[0, 1, 2]]
    L0 = np.array([q, q, q[[1, 2, 0]], q[[1, 2, 0]], q[[2, 0, 1]], q[[2, 0, 1]]])   # wall: classes {01},{23},{45}
    Se, S0 = stab(Le), stab(L0)
    lab0 = quotient_labels(L0)
    def descends(ph):
        if MUT.get("sp05_no_normalizer"): return True
        img = {}
        for x in X:
            if img.setdefault(int(lab0[x]), int(lab0[ph[x]])) != lab0[ph[x]]: return False
        return True
    desc = [g for g in Se if descends(g[0])]
    # verify descended maps are well defined actions on Q_0 (consistency)
    def well_defined(ph):
        img = {}
        for x in X:
            if img.setdefault(int(lab0[x]), int(lab0[ph[x]])) != lab0[ph[x]]: return False
        return True
    wrong = sum(1 for g in desc if not well_defined(g[0]))
    gam0 = {tuple(int(lab0[g[0][x]]) for x in (0, 2, 4)) for g in S0}
    gam_desc = {tuple(int(lab0[g[0][x]]) for x in (0, 2, 4)) for g in desc if well_defined(g[0])}
    passed = wrong == 0 and len(desc) < len(Se) and len(gam0) > len(gam_desc) and len(gam0) >= 3
    register("SP05", "Regular symmetries pass to the wall and the wall has the same effective symmetry.",
             "A regular symmetry descends iff it preserves K_0 (normalizer condition); the wall group can be strictly "
             "larger, because distinctions lost at the wall no longer break symmetry.",
             passed, dict(regular_stab=len(Se), descending=len(desc), ill_defined_descents=wrong,
                          wall_gamma_order=len(gam0), descended_gamma_order=len(gam_desc)), "FALSIFIED-naive")


def SP06_metric_gate(rng):
    """(a) y observed as N(eps y, 1): Hellinger-continuous; Fisher diag(1, eps^2) -> diag(1, 0); CRB on y
    diverges as eps^-2. (b) y observed as N(eps y, eps^2): weakly converges to delta_0 (the wall identifies y),
    yet Hellinger distance between y and y' and the Fisher metric stay constant: distinguishability does NOT
    specialize. Gate: locally uniform Hellinger convergence."""
    y, yp = 0.3, 1.1
    hell = lambda m1, m2, s: math.sqrt(1-math.exp(-(m1-m2)**2/(8*s*s)))
    rows = {}
    for lab in ("a", "b"):
        r = []
        for eps in (1e-1, 1e-2, 1e-3):
            s = 1.0 if lab == "a" else eps
            fisher_y = (eps/s)**2; H = hell(eps*y, eps*yp, s)
            W1 = abs(eps*y) + s*math.sqrt(2/math.pi)                 # E|Z| bound distance to delta_0 for (b); for (a) to N(0,1)
            W1 = abs(eps*y) if lab == "a" else W1
            r.append(dict(eps=eps, fisher_y=f(fisher_y), hellinger=f(H), w1_to_wall=f(W1), crb_y=f(1/fisher_y)))
        rows[lab] = r
    def gate(r):
        if MUT.get("sp06_weak_only"): return r[-1]["w1_to_wall"] < 1e-2
        return r[-1]["hellinger"] < 1e-2 and r[-1]["w1_to_wall"] < 1e-2
    ga, gb = gate(rows["a"]), gate(rows["b"])
    passed = (ga and not gb and rows["a"][-1]["fisher_y"] < 1e-5 and rows["a"][-1]["crb_y"] > 1e5 and
              rows["b"][-1]["fisher_y"] == 1.0 and rows["b"][-1]["hellinger"] > 0.2 and rows["b"][-1]["w1_to_wall"] < 1e-2)
    register("SP06", "Convergence of the laws carries the RG distance to the wall.",
             "Only Hellinger (locally uniform) convergence does. A weakly convergent family with noise shrinking with "
             "the signal keeps constant Hellinger distance and Fisher metric although its weak limit identifies y.",
             passed, dict(families=rows, gate_a=bool(ga), gate_b=bool(gb)), "FALSIFIED-naive")


def SP07_latent_walls(rng):
    """Whitney cusp F(u,v) = (u, v^3 + u v). Rank strata: regular (rank 2), fold (rank 1, kernel transverse),
    cusp point (rank 1, kernel tangent to the fold). Computed: finitely many strata components; kernel limits
    along sequences approaching fold and cusp lie in the wall kernel."""
    J = lambda u, v: np.array([[1.0, 0.0], [v, 3*v*v+u]])
    us = np.linspace(-1, 1, 801); vs = np.linspace(-1, 1, 801); U, V = np.meshgrid(us, vs, indexing="ij")
    det = 3*V*V+U
    from scipy import ndimage
    pos, neg = ndimage.label(det > 0)[1], ndimage.label(det < 0)[1]
    vfold = np.linspace(-1, 1, 4001)
    ufold = -3*vfold**2; tang = np.stack([-6*vfold, np.ones_like(vfold)], 1)
    tang /= np.linalg.norm(tang, axis=1)[:, None]
    kerf = np.array([0.0, 1.0])
    tangency = np.abs(tang @ kerf) > 1-1e-9
    cusp_pts = int(np.sum(tangency))
    worst = 0.0
    for _ in range(300):
        v0 = rng.uniform(-0.6, 0.6); u0 = -3*v0*v0; d = rng.normal(size=2); d /= np.linalg.norm(d)
        K0 = kernel(J(u0, v0))
        for t in (1e-3, 1e-5, 1e-7):
            Kt = kernel(J(u0+t*d[0], v0+t*d[1]), tol=1e-12)
            worst = max(worst, incl_defect(Kt, K0))
    # along the fold towards the cusp the kernel is constant (0,1): contained in cusp kernel
    along = max(incl_defect(kernel(J(-3*v*v, v)), kernel(J(0.0, 0.0))) for v in (1e-2, 1e-4, 1e-6))
    passed = pos == 1 and neg == 1 and cusp_pts == 1 and worst < 1e-9 and along < 1e-9
    register("SP07", "Latent rank walls are coordinate defects to be smoothed over.",
             "They are a finite stratification (regular / fold / cusp, computed); along every approach the kernel "
             "limit lies in the wall kernel; at the cusp the kernel becomes tangent to the wall (a lower stratum).",
             passed, dict(regular_components=[int(pos), int(neg)], cusp_points=cusp_pts,
                          max_inclusion_defect_approach=f(worst), along_fold_defect=f(along)), "HOLDS")


def SP08_natural_specialize(rng):
    """Linear-Gaussian families y = A_eps x + noise(Sigma fixed): the Fisher metric g_eps = A^T S^-1 A converges
    to the wall Fisher g_0 linearly in eps, its radical contains ker A_0, and the Cramer-Rao bound diverges
    exactly on the gained kernel."""
    worst, crb_ratio, rad = 0.0, [], 0.0
    for _ in range(200):
        m, n = 4, 3; r = 2
        A0 = rng.normal(size=(m, r)) @ rng.normal(size=(r, n)); B = rng.normal(size=(m, n))
        L = rng.normal(size=(m, m)); S = L @ L.T + np.eye(m); Si = np.linalg.inv(S)
        g0 = A0.T @ Si @ A0
        for eps in (1e-2, 1e-4):
            Ae = A0+eps*B; ge = Ae.T @ Si @ Ae; worst = max(worst, np.linalg.norm(ge-g0)/eps) if eps == 1e-4 else worst
        K0 = kernel(A0); rad = max(rad, float(np.linalg.norm(g0 @ K0)))
        k = K0[:, 0]
        c2, c4 = [k @ np.linalg.inv((A0+e*B).T @ Si @ (A0+e*B)) @ k for e in (1e-2, 1e-4)]
        crb_ratio.append(c4/c2)
    passed = worst < 1e3 and rad < 1e-9 and np.median(crb_ratio) > 5e3
    register("SP08", "The regular geometry has no meaningful limit at a wall.",
             "Natural modules specialize: the Fisher metric converges to the wall Fisher (O(eps)), its radical "
             "contains the wall kernel, and the Cramer-Rao bound diverges ~eps^-2 exactly on the gained kernel.",
             passed, dict(max_lipschitz_const=f(worst), radical_defect=f(rad), median_crb_growth_100x=f(np.median(crb_ratio))), "HOLDS")


def SP09_connection_nogo(rng):
    """Two horizontal distributions differing by a vertical shear give identical laws, identical natural
    modules (Fisher), and identical specializations, but different latent lifts: specialization selects no
    connection (L58 is independent)."""
    worst_fisher, worst_spec, lift_gap = 0.0, 0.0, 0.0
    for _ in range(100):
        a, b = rng.normal(size=2)
        # law depends on x only; y is vertical; horizontal lifts (1, a) and (1, b) of d/dx
        J = np.array([[1.0, 0.0]]); g = J.T @ J
        H1, H2 = np.array([1.0, a]), np.array([1.0, b])
        worst_fisher = max(worst_fisher, abs(H1 @ g @ H1 - H2 @ g @ H2))
        worst_spec = max(worst_spec, float(np.linalg.norm(J @ H1 - J @ H2)))
        lift_gap = max(lift_gap, abs(a-b))
    passed = worst_fisher < 1e-12 and worst_spec < 1e-12 and lift_gap > 1
    register("SP09", "A canonical specialization determines a canonical cross-wall connection.",
             "No: lifts differing by vertical shear are law-indistinguishable before and after specialization; the "
             "latent connection problem (L58) is independent of specialization.",
             passed, dict(fisher_difference=f(worst_fisher), specialized_difference=f(worst_spec), lift_gap=f(lift_gap)),
             "FALSIFIED-naive")


def SP10_rank_certificate(rng):
    """Finite-sample rank certificates with double escalation. FULL only if the 1% quantile of sigma_min exceeds
    tau at n and 4n; rank deficiency is never certified (only an upper bound); near the wall: abstain."""
    tau = 0.005
    def q(eps, n, reps=200):
        vals = [np.linalg.svd(np.diag([1.0, eps]) + rng.normal(0, 1/np.sqrt(n), (2, 2))*0.05, compute_uv=False)[-1]
                for _ in range(reps)]
        return np.quantile(vals, [0.01, 0.99])
    def cert(eps):
        a, b = q(eps, 2000), q(eps, 8000)
        if a[0] > tau and b[0] > tau: return "FULL", float(b[1])
        if MUT.get("sp10_certify_drop") and b[1] < 2*tau: return "DEFICIENT", float(b[1])
        return "UPPER-BOUND", float(b[1])
    res = {str(e): cert(e) for e in (0.08, 0.004, 0.0)}
    passed = res["0.08"][0] == "FULL" and res["0.004"][0] == "UPPER-BOUND" and res["0.0"][0] == "UPPER-BOUND"
    register("SP10", "A small singular value certifies a rank wall.",
             "A wall is never certified from finite data; only FULL rank (double escalation) or an upper bound on "
             "sigma_min. A true rank-2 matrix with sigma_min = 0.004 is indistinguishable from the wall here.",
             passed, dict(certificates={k: dict(cert=v[0], sigma_min_upper=f(v[1])) for k, v in res.items()}, tau=tau),
             "FALSIFIED-naive")


def SP11_lecam(rng):
    """Le Cam: if experiments converge (Hellinger-continuous family), Bayes risks of a fixed test converge to the
    wall risk; under weak-only convergence (SP06 b) the risk does not converge to the wall value."""
    y, yp = 0.0, 1.0
    def bayes_err(m1, m2, s):           # equal priors, two Gaussians with common sd s
        return norm.cdf(-abs(m1-m2)/(2*s))
    a = [f(bayes_err(e*y, e*yp, 1.0)) for e in (1e-1, 1e-2, 1e-3)]
    b = [f(bayes_err(e*y, e*yp, e)) for e in (1e-1, 1e-2, 1e-3)]
    wall = 0.5                         # the wall identifies y and y': error 1/2
    passed = abs(a[-1]-wall) < 1e-3 and abs(b[-1]-wall) > 0.1
    register("SP11", "Decision-theoretic content specializes whenever laws converge.",
             "Only under experiment convergence: with Hellinger continuity the minimal test error tends to the wall "
             "value 1/2; with weak-only convergence it stays at 0.31.",
             passed, dict(hellinger_family_error=a, weak_family_error=b, wall_error=wall), "FALSIFIED-naive")


ATTACKS = [SP01_usc, SP02_uniformity, SP03_map_iff_inclusion, SP04_functoriality, SP05_symmetry_descent,
           SP06_metric_gate, SP07_latent_walls, SP08_natural_specialize, SP09_connection_nogo, SP10_rank_certificate,
           SP11_lecam]


def run_all(seed):
    for a in ATTACKS:
        rng = np.random.default_rng([seed, ATTACKS.index(a)])
        try: a(rng)
        except Exception as ex: register(a.__name__[:4], "?", f"EXCEPTION {ex!r}", False, {}, "ERROR")


def canary(seed):
    muts = [("SP02", {"sp02_grid_supnorm": True}), ("SP04", {"sp04_nearest": True}),
            ("SP05", {"sp05_no_normalizer": True}), ("SP06", {"sp06_weak_only": True}),
            ("SP10", {"sp10_certify_drop": True})]
    ok = True
    for tgt, m in muts:
        RESULTS.clear(); MUT.clear(); MUT.update(m); print(f"--- canary {tgt}: {m}")
        a = next(x for x in ATTACKS if x.__name__.startswith(tgt))
        try: a(np.random.default_rng([seed, ATTACKS.index(a)])); caught = not RESULTS[-1]["passed"]
        except Exception as ex: print(f"    exception {ex!r} (not a clean catch)"); caught = False
        ok &= caught; print(f"    {'CAUGHT' if caught else 'NOT CAUGHT'}")
    MUT.clear(); print("CANARY:", "all caught" if ok else "BATTERY TOO WEAK"); return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--seed", type=int, default=20261001)
    ap.add_argument("--out", default="rg_stratified_specialization_results.json"); ap.add_argument("--canary", action="store_true")
    a = ap.parse_args()
    if a.canary: sys.exit(canary(a.seed))
    t0 = time.time(); print(f"RG stratified specialization battery, seed {a.seed}\n"); run_all(a.seed)
    n = sum(r["passed"] for r in RESULTS)
    summ = dict(seed=a.seed, n_checks=len(RESULTS), n_pass=n, runtime_s=round(time.time()-t0, 1))
    json.dump(dict(summary=summ, results=RESULTS), open(a.out, "w"), indent=2,
              default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print(f"\n{n}/{len(RESULTS)} pass."); sys.exit(0 if n == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
