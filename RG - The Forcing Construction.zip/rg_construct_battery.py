#!/usr/bin/env python3
"""Resolution Geometry - hostile battery for the forcing construction (rg_construct.py).

  CA exactness and duality: on linear models the first-order range is the exact fibre range (sampled members never
     leave it); primal width equals the dual (load-split) total; two LP algorithms agree
  CB forcing at first order: Q = 0 (task covector in the record row space) iff the width vanishes with eps; otherwise
     the width tends to the declared-box width over the kernel; the width is concave and nondecreasing in eps
  CC the native local object is a norm, not a tensor: with per-record bounds the width is a norm on task covectors
     (homogeneous, subadditive) that fails the parallelogram law; with an ellipsoidal error set it is the Fisher form
     2 sqrt(tau I^+ tau); always Fisher width <= l_inf width <= sqrt(m) Fisher width
  CD load split: record cost + declaration cost = width; share in [0, 1]; Q != 0 with a box forces a positive share;
     a task in the row space with a loose box has share 0; a tight box carries the task even when Q = 0; a degenerate
     dual gives the interval [0, 1]
  CE local is not global: F(x) = x^2, T(x) = x is forced at first order at x = 0.7 and not forced on the exact fibre
     {+-0.7}; on the pendulum Q is identically 0 from 4 records while the enclosure is CORRESPONDENCE; records beyond
     eps give INCONSISTENT
  CF pendulum: the first-order width with the realized records, linearized at the truth, is 0.80-1.0 of the enclosure
     diameter at 19 records; the first-order lock depth at the least-squares point is never later than the enclosure's,
     equal in at least 6 of 8 releases, earlier by at most two records (so a first-order lock is not a lock)
  CG free fall: the velocity-ignorance transfer tensor of exact Kepler orbits gives the tidal tensor,
     Q_t = t^2 I - (t^4 / 3) E + O(t^5): E within 1% of GM/r^3 diag(-2, 1, 1); Q transforms as a tensor
  CH compass: two epochs leave the curvature in the ignorance bundle (kernel 6, share 1); three epochs with
     non-coplanar probes force it (kernel 0, share 0); coplanar probes leak E_zz; width scales as eps / (t^2 xi0); on
     exact orbit records at 400 km the Ric(u,u) interval contains 0 and the radial interval contains -2GM/r^3; inside a
     uniform body of density 2700 kg/m^3 the interval excludes 0
  CI curvature from observers (frames checked Lorentz; static Schwarzschild tidal tensor anchored to GM/r^3
     diag(-2, 1, 1), the sign found in CG): tidal tensors of 1, 2, 3, 4, 5 generic observers have rank 6, 11, 15, 18, 20 on the
     20-dimensional curvature space (30 random observer sets); Ric(u,u) is determined by one observer, G(u,u) only by
     five; Schwarzschild (static frame) and FLRW dust are reconstructed from five observers: G = 0, Kretschmann
     48 M^2 / r^6, and G(u,u) = 8 pi rho, Ric(u,u) = 4 pi rho
  CJ invariance: Q(v, v) = (tau v)^2 is coordinate-free on V; the width is invariant under reparametrization, record
     permutation and sign flips, and not under mixing records (per-record bounds are protocol data)
  CK attachment re-check and novelty audit: log(Q + eps^2 I) is not covariant (relative error > 0.3), log(g^-1 Q +
     eps^2) is similarity-covariant (< 1e-10); pairs (g, Q) with equal generalized eigenvalues are congruent and
     unequal ones are not: the first-order local invariants are classical

Deterministic seeds. Writes rg_construct_battery_results.json.
Run:  python3 -I rg_construct_battery.py       (numpy, scipy; CF needs rg_pendulum.py and class_default.json)
"""
import hashlib, json, os, sys
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from scipy.integrate import solve_ivp
from scipy.linalg import logm, eigh

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rg_construct as K

R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        if tag not in FAILS:
            FAILS.append(tag)
        print('FAILED', tag, flush=True)


def rel(a, b):
    return float(np.linalg.norm(np.asarray(a) - np.asarray(b)) / max(np.linalg.norm(b), 1e-300))


# ------------------------------------------------------------------ CA
def group_CA():
    rng = np.random.default_rng(1101); worst_dual = worst_alg = 0.0; escaped = 0
    for k in range(25):
        m, n = rng.integers(2, 7), rng.integers(3, 8); A = rng.normal(size=(m, n)); tau = rng.normal(size=n)
        eps = rng.uniform(0.01, 0.1, m); v0 = rng.uniform(-0.3, 0.3, n); d = A @ v0 + rng.uniform(-1, 1, m) * eps * 0.5
        bl, bu = -np.ones(n), np.ones(n)
        wr = K.width(A, tau, eps, d, bl, bu)
        if wr is None:
            worst_dual = np.inf; continue
        lo, hi = wr
        ls = K.load_split(A, tau, eps, d - A @ v0, bl - v0, bu - v0)
        worst_dual = max(worst_dual, abs(ls['width'] - (hi - lo)) / (hi - lo))
        G = np.vstack([A, -A]); h = np.r_[d + eps, eps - d]; bnd = list(zip(bl, bu))
        a = linprog(-tau, A_ub=G, b_ub=h, bounds=bnd, method='highs-ipm'); b = linprog(tau, A_ub=G, b_ub=h, bounds=bnd, method='highs-ipm')
        worst_alg = max(worst_alg, abs((-a.fun - b.fun) - (hi - lo)) / (hi - lo))
        P = v0 + rng.uniform(-1, 1, (20000, n)) * 0.6
        ok = np.all(np.abs(P @ A.T - d) <= eps, axis=1) & np.all((P >= bl) & (P <= bu), axis=1)
        y = P[ok] @ tau
        escaped += int(np.sum((y < lo - 1e-12) | (y > hi + 1e-12)))
    must(worst_dual < 1e-7 and worst_alg < 1e-6 and escaped == 0, 'CA')
    R['CA'] = dict(claim='Linear models: first-order range = exact fibre range; primal = dual; LP algorithms agree', seed=1101,
                   cases=25, worst_dual_gap=worst_dual, worst_algorithm_gap=worst_alg, sampled_members_outside=escaped)


# ------------------------------------------------------------------ CB
def group_CB():
    rng = np.random.default_rng(1102); rows = []
    for k in range(20):
        m, n = 3, 5; A = rng.normal(size=(m, n)); inrow = k % 2 == 0
        tau = A.T @ rng.normal(size=m) if inrow else rng.normal(size=n)
        J, Q, V, _ = K.transfer(A, tau); b = np.ones(n)
        ws = [K.width(A, tau, e, None, -b, b) for e in (1e-1, 3e-2, 1e-2, 3e-3, 1e-3, 1e-6)]
        w = np.array([x[1] - x[0] for x in ws])
        # width over the kernel inside the box (eps -> 0 limit)
        nV = V.shape[1]
        if nV:
            G = np.vstack([V, -V]); h = np.r_[b, b]
            up = -linprog(-(tau @ V), A_ub=G, b_ub=h, bounds=[(None, None)] * nV, method='highs').fun
            w0 = 2 * up
        else:
            w0 = 0.0
        eg = np.array([1e-1, 3e-2, 1e-2, 3e-3, 1e-3, 1e-6])
        mono = bool(np.all(np.diff(w[::-1]) >= -1e-12))
        # concavity on the grid (eps decreasing order): slopes nonincreasing in eps
        e_sorted = eg[::-1]; w_sorted = w[::-1]; sl = np.diff(w_sorted) / np.diff(e_sorted)
        conc = bool(np.all(np.diff(sl) <= 1e-6 * max(1, abs(sl).max())))
        rows.append(dict(in_row_space=inrow, leakage=float(np.sqrt(np.trace(Q))), w_eps_1e6=float(w[-1]), w0=float(w0),
                         monotone=mono, concave=conc))
    ok = all((r['leakage'] < 1e-9) == r['in_row_space'] for r in rows) and \
        all((r['w_eps_1e6'] < 1e-4) if r['in_row_space'] else (abs(r['w_eps_1e6'] - r['w0']) < 1e-4 and r['w0'] > 1e-3) for r in rows) and \
        all(r['monotone'] and r['concave'] for r in rows)
    must(ok, 'CB')
    R['CB'] = dict(claim='Q = 0 iff tau in the row space iff the width vanishes with eps; else it tends to the box width over '
                         'the kernel; width concave nondecreasing in eps', seed=1102, cases=rows)


# ------------------------------------------------------------------ CC
def group_CC():
    rng = np.random.default_rng(1103); viol = []; ratio_ok = True; fisher_err = 0.0
    for k in range(30):
        m, n = 6, 3; A = rng.normal(size=(m, n)); eps = np.full(m, 0.05)
        w = lambda t: (lambda r: r[1] - r[0])(K.width(A, t, eps))
        t1, t2 = rng.normal(size=n), rng.normal(size=n)
        lhs = w(t1 + t2) ** 2 + w(t1 - t2) ** 2; rhs = 2 * w(t1) ** 2 + 2 * w(t2) ** 2
        viol.append(abs(lhs - rhs) / rhs)
        tri = w(t1 + t2) <= w(t1) + w(t2) + 1e-12; hom = abs(w(2.5 * t1) - 2.5 * w(t1)) < 1e-9 * w(t1)
        fw = K.fisher_width(A, t1, eps)
        ratio_ok &= bool(tri and hom and fw <= w(t1) + 1e-12 and w(t1) <= np.sqrt(m) * fw + 1e-12)
        # ellipsoidal error set: max tau.v over sum (a_k v)^2 / eps^2 <= 1 by SLSQP-free closed check (sampling the sphere)
        I = A.T @ A / 0.05 ** 2; L = np.linalg.cholesky(I); z = rng.normal(size=(40000, n)); z /= np.linalg.norm(z, axis=1)[:, None]
        v = np.linalg.solve(L.T, z.T).T; fisher_err = max(fisher_err, abs(2 * np.max(v @ t1) - fw) / fw)
    maxviol = float(max(viol))
    must(maxviol > 0.05 and ratio_ok and fisher_err < 1e-3, 'CC')
    R['CC'] = dict(claim='Per-record bounds give a norm that is not a quadratic form; the ellipsoidal set gives Fisher; '
                         'Fisher <= l_inf <= sqrt(m) Fisher', seed=1103, largest_parallelogram_violation=maxviol,
                   median_parallelogram_violation=float(np.median(viol)), norm_and_bounds_hold=ratio_ok,
                   fisher_sampling_error=fisher_err)


# ------------------------------------------------------------------ CD
def group_CD():
    rng = np.random.default_rng(1104); out = dict(); shares_ok = True
    for k in range(20):
        A = rng.normal(size=(3, 5)); tau = rng.normal(size=5); b = np.ones(5)
        r = K.resolve(A, tau, 0.01, bl=-b, bu=b)
        s = r['declaration_share']
        shares_ok &= bool(-1e-9 <= s[0] <= s[1] <= 1 + 1e-9 and abs(r['record_cost'] + r['declaration_cost'] - r['width']) < 1e-9 * r['width']
                          and s[0] > 0.01)
    out['leaking_tasks_have_positive_share'] = shares_ok
    A = rng.normal(size=(3, 5)); tau = A.T @ rng.normal(size=3)
    r = K.resolve(A, tau, 0.01, bl=-10 * np.ones(5), bu=10 * np.ones(5)); out['forced_task_loose_box_share'] = r['declaration_share']
    r = K.resolve(A, tau, 0.01, bl=-1e-4 * np.ones(5), bu=1e-4 * np.ones(5)); out['forced_task_tight_box_share'] = r['declaration_share']
    r = K.resolve(np.array([[1.0, 0.0]]), np.array([1.0, 0.0]), 1.0, bl=np.array([-1.0, -1.0]), bu=np.array([1.0, 1.0]))
    out['degenerate_share'] = r['declaration_share']; out['degenerate_width'] = r['width']
    ok = shares_ok and out['forced_task_loose_box_share'][1] < 1e-6 and out['forced_task_tight_box_share'][0] > 0.5 and \
        out['degenerate_share'][0] < 1e-6 and out['degenerate_share'][1] > 1 - 1e-6 and abs(out['degenerate_width'] - 2) < 1e-9
    must(ok, 'CD')
    R['CD'] = dict(claim='Load split: costs add to the width; leakage forces a positive declaration share; loose box -> 0, '
                         'tight box -> positive; degenerate dual -> [0, 1]', seed=1104, **out)


# ------------------------------------------------------------------ CE
def group_CE():
    x0, eps = 0.7, 1e-3
    A = np.array([[2 * x0]]); tau = np.array([1.0])
    loc = K.resolve(A, tau, eps, tol=0.02)
    fibre = np.array([-np.sqrt(x0 ** 2), np.sqrt(x0 ** 2)])        # exact records F = x0^2: both signs, plus eps
    glob_width = float(np.sqrt(x0 ** 2 + eps) - (-np.sqrt(x0 ** 2 + eps)))
    out = dict(x2_local_status=loc['status'], x2_local_width=loc['width'], x2_global_width=glob_width,
               x2_global_status='LOCKED' if glob_width <= 0.04 else 'CORRESPONDENCE', exact_fibre=fibre.tolist())
    bad = K.resolve(np.array([[1.0, 0.0], [1.0, 0.0]]), np.array([0.0, 1.0]), 0.01, d=np.array([0.0, 0.05]),
                    bl=-np.ones(2), bu=np.ones(2))
    out['inconsistent_records_status'] = bad['status']
    pend = None
    if (HERE / 'rg_pendulum.py').exists():
        import rg_pendulum as P
        C = P.load_class(HERE / 'class_default.json'); tr = np.array([0.15, 0.2, 3.12, 0.02])
        r, rt, _ = P.simulate_records(tr, C, 8, np.random.default_rng(1105))
        th, S = P.integrate(tr[None], np.r_[rt, C['tF']]); res = K.resolve(S[0, :8], S[0, 8], P.eps_total(C))
        enc = P.analyse(r, rt, C)
        pend = dict(records=8, kernel_dim=res['kernel_dim'], leakage=res['leakage'], enclosure_status=enc['status'],
                    enclosure_diameter=enc['diameter'])
    out['pendulum_q_blind'] = pend
    ok = loc['status'] == 'LOCKED-FIRST-ORDER' and out['x2_global_status'] == 'CORRESPONDENCE' and \
        out['inconsistent_records_status'] == 'INCONSISTENT' and pend is not None and pend['kernel_dim'] == 0 and \
        pend['leakage'] == 0.0 and pend['enclosure_status'] == 'CORRESPONDENCE'
    must(ok, 'CE')
    R['CE'] = dict(claim='First order is not the fibre: x^2 is forced locally and not globally; Q is blind to the pendulum '
                         'near-kernel; out-of-bound records are INCONSISTENT', seed=1105, **out)


# ------------------------------------------------------------------ CF
def group_CF():
    import rg_pendulum as P
    C = P.load_class(HERE / 'class_default.json'); E = P.eps_total(C)
    lo0 = np.array([-C['A'], -C['V'], C['omega'][0], C['gamma'][0]]); hi0 = np.array([C['A'], C['V'], C['omega'][1], C['gamma'][1]])

    def local(p, r, rt):
        m = len(r); th, S = P.integrate(p[None], np.r_[rt, C['tF']])
        x = K.width(S[0, :m], S[0, m], E, r - th[0, :m], lo0 - p, hi0 - p)
        return None if x is None else x[1] - x[0]
    rng = np.random.default_rng(42); ratios = []
    trs = [P.sample_truth(C, rng) for _ in range(4)]
    for tr in trs:
        r, rt, _ = P.simulate_records(tr, C, 19, np.random.default_rng(1))
        wl = local(tr, r, rt); ratios.append(np.nan if wl is None else wl / P.analyse(r, rt, C)['diameter'])
    rng = np.random.default_rng(7); pairs = []
    for k in range(8):
        tr = P.sample_truth(C, rng); r, rt, _ = P.simulate_records(tr, C, 25, rng)
        dg, _ = P.lock_depth(r, rt, C); dl = None
        for m in range(6, 26):
            p = np.clip(P.nls(r[:m], rt[:m], C)['params'], lo0, hi0); w = local(p, r[:m], rt[:m])
            if w is not None and w <= 2 * C['tol']:
                dl = m; break
        pairs.append([dg, dl])
    eq = sum(a == b for a, b in pairs); never_late = all(b is not None and a is not None and b <= a for a, b in pairs)
    within2 = all(b is not None and a - b <= 2 for a, b in pairs)
    ok = all(0.80 <= x <= 1.0 for x in ratios) and never_late and within2 and eq >= 6 and eq < 8
    must(ok, 'CF')
    R['CF'] = dict(claim='Pendulum: realized first-order width 0.80-1.0 of the enclosure diameter at 19 records; first-order '
                         'lock depth never later, equal in >= 6 of 8, earlier by at most two (a first-order lock is not a lock)',
                   seeds=[42, 1, 7], width_ratio_at_19=[float(x) for x in ratios], lock_depth_enclosure_vs_first_order=pairs,
                   equal=int(eq))


# ------------------------------------------------------------------ CG
GM = 3.986004418e14; RE = 6.771e6


def _rel_orbit(offsets, vrel, t_eval):
    """Reference on a circular orbit of radius RE and probes at offsets with relative velocities; returns relative
    positions (len(t), N, 3), integrated as relative motion (no cancellation)."""
    vc = np.sqrt(GM / RE); N = len(offsets)

    def f(t, y):
        x = y[:3]; vx = y[3:6]; xi = y[6:6 + 3 * N].reshape(N, 3); vxi = y[6 + 3 * N:].reshape(N, 3)
        g0 = -GM * x / np.linalg.norm(x) ** 3
        gi = np.array([-GM * (x + q) / np.linalg.norm(x + q) ** 3 for q in xi]) - g0
        return np.r_[vx, g0, vxi.ravel(), gi.ravel()]
    y0 = np.r_[RE, 0, 0, 0, vc, 0, np.asarray(offsets, float).ravel(), np.asarray(vrel, float).ravel()]
    s = solve_ivp(f, (0, max(t_eval)), y0, t_eval=t_eval, rtol=1e-13, atol=1e-14, method='DOP853')
    return s.y[6:6 + 3 * N].T.reshape(len(t_eval), N, 3)


def group_CG():
    Hs = GM / RE ** 3 * np.diag([-2.0, 1.0, 1.0])

    def Jt(t, h=1e-3):
        out = np.zeros((3, 3))
        for i in range(3):
            dv = np.zeros(3); dv[i] = h
            yp = _rel_orbit([[0, 0, 0]], [dv], [0, t])[-1, 0]; ym = _rel_orbit([[0, 0, 0]], [-dv], [0, t])[-1, 0]
            out[:, i] = (yp - ym) / (2 * h)
        return out
    Es = {}
    for t in (20.0, 10.0):
        J = Jt(t); Q = J.T @ J; Es[t] = -3 * (Q - t * t * np.eye(3)) / t ** 4
    Erich = 2 * Es[10.0] - Es[20.0]
    err = rel(Erich, Hs)
    # tensor behaviour: rotate the velocity basis
    th = 0.7; S = np.array([[np.cos(th), -np.sin(th), 0], [np.sin(th), np.cos(th), 0], [0, 0, 1]]) @ np.diag([1, 2, 0.5])
    J = Jt(10.0); Q = J.T @ J; Q2 = (J @ S).T @ (J @ S)
    tens = rel(Q2, S.T @ Q @ S)
    must(err < 0.01 and abs(np.trace(Erich)) < 0.01 * GM / RE ** 3 and tens < 1e-12, 'CG')
    R['CG'] = dict(claim='Velocity-ignorance transfer tensor of exact Kepler orbits: Q_t = t^2 I - t^4 E / 3 + O(t^5) gives '
                         'the tidal tensor within 1%', GM_over_r3=GM / RE ** 3,
                   E_over_GMr3=(Erich / (GM / RE ** 3)).round(5).tolist(), relative_error=err, tensor_covariance_error=tens)


# ------------------------------------------------------------------ CH
def group_CH():
    out = {}; bounds = lambda N: (np.r_[-1e-2 * np.ones(3 * N), -1e-2 * np.ones(3 * N), -1e-3 * np.ones(6)],)
    layouts = {'two_epochs': (np.eye(3), [0, 1.0]), 'three_epochs': (np.eye(3), [0, 0.5, 1.0]),
               'coplanar': (np.array([[1, 0, 0], [0, 1, 0], [1, 1, 0.0]]), [0, 0.5, 1.0])}
    for name, (X, ep) in layouts.items():
        N = len(X); A, tr, comps = K.compass_design(X, ep); bl = bounds(N)[0]
        r = K.resolve(A, tr, 1e-6, bl=bl, bu=-bl)
        out[name] = dict(kernel_dim=r['kernel_dim'], leakage=r['leakage'], width=r['width'], share=r['declaration_share'])
    A, tr, _ = K.compass_design(np.eye(3), [0, 0.5, 1.0]); bl = bounds(3)[0]; w1 = K.resolve(A, tr, 1e-6, bl=bl, bu=-bl)['width']
    A, tr, _ = K.compass_design(np.eye(3), [0, 1.0, 2.0]); w2 = K.resolve(A, tr, 1e-6, bl=bl, bu=-bl)['width']
    A, tr, _ = K.compass_design(10 * np.eye(3), [0, 0.5, 1.0]); w3 = K.resolve(A, tr, 1e-6, bl=bl, bu=-bl)['width']
    out['scaling_t2'] = w1 / w2; out['scaling_xi10'] = w1 / w3
    # exact orbit records: 4 probes, 10 m, released at rest relative to the reference, epochs 0, 2, 4 s
    X = 10 * np.array([[1, 0, 0], [0, 1, 0], [0, 0, 1], [-1, -1, -1.0]]) / np.array([1, 1, 1, np.sqrt(3)])[:, None]
    ep = [0.0, 2.0, 4.0]; eps = 1e-6; eta = 2e-7                    # eta: neglected orbital-rotation and t^4 terms
    xi = _rel_orbit(X, np.zeros_like(X), ep).reshape(-1)
    rng = np.random.default_rng(1108); rec = xi + rng.uniform(-eps, eps, xi.size)
    A, trc, comps = K.compass_design(X, ep); N = len(X)
    bl = np.r_[-1e-4 * np.ones(3 * N), -1e-3 * np.ones(3 * N), -1e-4 * np.ones(6)]
    nominal = np.r_[X.ravel(), np.zeros(3 * N), np.zeros(6)]
    d = rec - K.compass_model(X, np.zeros((N, 3)), np.zeros((3, 3)), ep)
    rtr = K.resolve(A, trc, eps + eta, d=d, bl=bl, bu=-bl)
    rxx = K.resolve(A, comps[0], eps + eta, d=d, bl=bl, bu=-bl)
    E_rr = -2 * GM / RE ** 3
    out['vacuum_trace_interval'] = rtr['range']; out['radial_interval'] = rxx['range']; out['radial_true'] = E_rr
    rho_water = 4 * np.pi * 6.674e-11 * 1000.0
    out['trace_half_width_over_4piG_rho_water'] = rtr['width'] / 2 / rho_water
    # inside a uniform body: E = (4 pi G rho / 3) I exactly; release at rest: xi(t) = xi0 cos(sqrt(k) t)
    res_rho = {}
    for rho in (2700.0, 300.0):
        k = 4 * np.pi * 6.674e-11 * rho / 3
        xi = np.array([[x * np.cos(np.sqrt(k) * t) for x in X] for t in ep]).reshape(-1)
        rec = xi + rng.uniform(-eps, eps, xi.size); d = rec - K.compass_model(X, np.zeros((N, 3)), np.zeros((3, 3)), ep)
        rr = K.resolve(A, trc, eps + eta, d=d, bl=bl, bu=-bl)
        res_rho[str(int(rho))] = dict(interval=rr['range'], true=3 * k, excludes_zero=bool(rr['range'][0] > 0))
    out['uniform_body'] = res_rho
    ok = out['two_epochs']['kernel_dim'] == 6 and out['two_epochs']['leakage'] > 0.1 and out['two_epochs']['share'][0] > 1 - 1e-6 and \
        out['three_epochs']['kernel_dim'] == 0 and out['three_epochs']['share'][1] < 1e-6 and \
        out['coplanar']['kernel_dim'] == 1 and out['coplanar']['leakage'] > 0.5 and \
        abs(out['scaling_t2'] - 4) < 1e-6 and abs(out['scaling_xi10'] - 10) < 1e-6 and \
        rtr['range'][0] <= 0 <= rtr['range'][1] and rxx['range'][0] <= E_rr <= rxx['range'][1] and \
        res_rho['2700']['excludes_zero'] and res_rho['2700']['interval'][0] <= res_rho['2700']['true'] <= res_rho['2700']['interval'][1] and \
        not res_rho['300']['excludes_zero']
    must(ok, 'CH')
    R['CH'] = dict(claim='Compass: curvature leaves the ignorance bundle at three epochs with non-coplanar probes; vacuum and '
                         'matter on exact records', seed=1108, **out)


# ------------------------------------------------------------------ CI
def group_CI():
    B = K.curvature_basis(); u0 = np.array([1.0, 0, 0, 0])
    ric_uu = lambda Rm: u0 @ K.ricci(Rm) @ u0; G_uu = lambda Rm: u0 @ K.einstein(Rm) @ u0
    ranks = {n: set() for n in range(1, 7)}; ric_det = {n: set() for n in range(1, 7)}; g_det = {n: set() for n in range(1, 7)}
    for trial in range(30):
        r2 = np.random.default_rng(1109 + trial); Ls = [np.eye(4)] + [K.boost(r2.uniform(-0.6, 0.6, 3)) for _ in range(5)]
        for n in range(1, 7):
            rk, det = K.observation_rank(Ls[:n], B, (ric_uu, G_uu))
            ranks[n].add(rk); ric_det[n].add(det[0]); g_det[n].add(det[1])
    ranks = {n: sorted(v) for n, v in ranks.items()}; ric_det = {n: sorted(v) for n, v in ric_det.items()}; g_det = {n: sorted(v) for n, v in g_det.items()}
    # Schwarzschild, static orthonormal frame, M = 1, r = 6: nonzero R_abab
    M, r = 1.0, 6.0; Rs = np.zeros((4, 4, 4, 4)); q = M / r ** 3
    for (a, b), val in {(0, 1): -2 * q, (0, 2): q, (0, 3): q, (2, 3): 2 * q, (1, 2): -q, (1, 3): -q}.items():
        Rs[a, b, a, b] = val; Rs[b, a, b, a] = val; Rs[a, b, b, a] = -val; Rs[b, a, a, b] = -val
    rng = np.random.default_rng(1110); Ls = [np.eye(4)] + [K.boost(rng.uniform(-0.6, 0.6, 3)) for _ in range(4)]
    Rr, rk, resid = K.riemann_from_tidal([K.tidal(Rs, L) for L in Ls], Ls, B)
    kretsch = float(np.einsum('abcd,ae,bf,cg,dh,efgh', Rr, K.ETA, K.ETA, K.ETA, K.ETA, Rr))
    schw = dict(rank=rk, reconstruction_error=rel(Rr, Rs), max_abs_einstein=float(np.abs(K.einstein(Rr)).max()),
                kretschmann=kretsch, kretschmann_expected=48 * M ** 2 / r ** 6, E_static=K.tidal(Rs, np.eye(4)).round(6).tolist())
    # FLRW dust: Weyl = 0, R = Schouten wedge g, Ric = 4 pi rho (g + 2 u u)  (G = 8 pi T, T = rho u u)
    rho = 0.37; uu = np.outer(u0, u0); Ric = 4 * np.pi * rho * (K.ETA + 2 * uu); s = np.einsum('ab,ab', K.ETA, Ric)
    Psch = 0.5 * (Ric - s / 6 * K.ETA); Rf = K.kulkarni_nomizu(Psch, K.ETA)
    Rr2, rk2, _ = K.riemann_from_tidal([K.tidal(Rf, L) for L in Ls], Ls, B)
    flrw = dict(G_uu=float(u0 @ K.einstein(Rr2) @ u0), eight_pi_rho=8 * np.pi * rho, Ric_uu=float(u0 @ K.ricci(Rr2) @ u0),
                four_pi_rho=4 * np.pi * rho, input_ricci_reproduced=rel(K.ricci(Rf), Ric))
    lorentz = max(float(np.abs(L.T @ K.ETA @ L - K.ETA).max()) for L in Ls)
    E_anchor = rel(K.tidal(Rs, np.eye(4)), q * np.diag([-2.0, 1.0, 1.0]))          # Newtonian radial stretching (CG)
    ok = lorentz < 1e-12 and E_anchor < 1e-12 and ranks == {1: [6], 2: [11], 3: [15], 4: [18], 5: [20], 6: [20]} and all(v == [True] for v in ric_det.values()) and \
        g_det == {1: [False], 2: [False], 3: [False], 4: [False], 5: [True], 6: [True]} and \
        schw['rank'] == 20 and schw['reconstruction_error'] < 1e-10 and schw['max_abs_einstein'] < 1e-12 and \
        abs(kretsch - 48 * M ** 2 / r ** 6) < 1e-10 * 48 / r ** 6 and \
        abs(flrw['G_uu'] - flrw['eight_pi_rho']) < 1e-10 and abs(flrw['Ric_uu'] - flrw['four_pi_rho']) < 1e-10 and flrw['input_ricci_reproduced'] < 1e-12
    must(ok, 'CI')
    R['CI'] = dict(claim='Observer tidal tensors: ranks 6, 11, 15, 18, 20; Ric(u,u) from one observer, G(u,u) only from five; '
                         'Schwarzschild and FLRW dust reconstructed', seed=1109,
                   ranks={str(k): v for k, v in ranks.items()}, ric_uu_determined={str(k): v for k, v in ric_det.items()},
                   G_uu_determined={str(k): v for k, v in g_det.items()}, schwarzschild=schw, flrw_dust=flrw,
                   boosts_lorentz_error=lorentz, static_tidal_anchor_error=E_anchor)


# ------------------------------------------------------------------ CJ
def group_CJ():
    rng = np.random.default_rng(1111); A = rng.normal(size=(3, 5)); tau = rng.normal(size=5)
    J, Q, V, _ = K.transfer(A, tau); S = rng.normal(size=(5, 5))
    J2, Q2, V2, _ = K.transfer(A @ S, tau @ S)
    v = V @ rng.normal(size=V.shape[1]); w = np.linalg.solve(S, v)              # same tangent vector in new coordinates
    qf1 = float((tau @ v) ** 2); qf2 = float((tau @ S @ w) ** 2)
    coord_free = abs(qf1 - qf2) < 1e-10 * max(qf1, 1) and abs(np.linalg.matrix_rank(Q2) - np.linalg.matrix_rank(Q)) == 0
    tau_r = A.T @ rng.normal(size=3); eps = np.array([0.01, 0.02, 0.03])
    w0 = (lambda x: x[1] - x[0])(K.width(A, tau_r, eps))
    wS = (lambda x: x[1] - x[0])(K.width(A @ S, tau_r @ S, eps))
    perm = [2, 0, 1]; sg = np.array([1, -1, 1.0])
    wP = (lambda x: x[1] - x[0])(K.width(sg[:, None] * A[perm], tau_r, eps[perm]))
    Mx = np.array([[1, 1, 0], [1, -1, 0], [0, 0, 1.0]])
    wM = (lambda x: x[1] - x[0])(K.width(Mx @ A, tau_r, eps))
    ok = coord_free and abs(wS - w0) < 1e-9 and abs(wP - w0) < 1e-9 and abs(wM - w0) > 1e-3
    must(ok, 'CJ')
    R['CJ'] = dict(claim='Q is coordinate-free on V; the width is invariant under reparametrization, record permutation and '
                         'sign, not under record mixing', seed=1111, quadratic_form_values=[qf1, qf2], width=w0,
                   width_reparametrized=wS, width_permuted=wP, width_mixed_records=wM)


# ------------------------------------------------------------------ CK
def group_CK():
    rng = np.random.default_rng(1112); n = 4
    X = rng.normal(size=(n, n)); Q = X @ X.T; Y = rng.normal(size=(n, n)); g = Y @ Y.T + n * np.eye(n); e2 = 1e-2
    S = rng.normal(size=(n, n)) + 2 * np.eye(n)
    Qs, gs = S.T @ Q @ S, S.T @ g @ S
    naive = rel(logm(Qs + e2 * np.eye(n)).real, S.T @ logm(Q + e2 * np.eye(n)).real @ S)
    L = logm(np.linalg.solve(g, Q) + e2 * np.eye(n)).real / 2; Ls = logm(np.linalg.solve(gs, Qs) + e2 * np.eye(n)).real / 2
    good = rel(Ls, np.linalg.solve(S, L @ S))
    lam1 = eigh(Q, g, eigvals_only=True); lam2 = eigh(Qs, gs, eigvals_only=True)
    # congruence from equal spectra: build T with T^T g T = I, T^T Q T = diag(lam), compose
    def frame(Qm, gm):
        w, U = eigh(Qm, gm); return U, w
    U1, w1 = frame(Q, g); U2, w2 = frame(Qs, gs); Tm = U1 @ np.linalg.inv(U2)    # maps the (Qs, gs) frame to the (Q, g) frame
    congr = rel(Tm.T @ Q @ Tm, Qs) + rel(Tm.T @ g @ Tm, gs)
    Q3 = Q + 0.1 * np.eye(n); lam3 = eigh(Q3, g, eigvals_only=True)
    ok = naive > 0.3 and good < 1e-10 and rel(lam1, lam2) < 1e-10 and congr < 1e-9 and rel(lam3, lam1) > 1e-3
    must(ok, 'CK')
    R['CK'] = dict(claim='Attachment re-checked: log(Q + eps^2 I) is not covariant, log(g^-1 Q + eps^2) is; first-order '
                         'invariants of (g, Q) are the generalized eigenvalues (classical)', seed=1112,
                   naive_log_covariance_error=naive, endomorphism_log_error=good, generalized_eigenvalues=lam1.tolist(),
                   congruence_from_equal_spectra_error=congr, perturbed_spectrum_differs=rel(lam3, lam1))


GROUPS = dict(CA=group_CA, CB=group_CB, CC=group_CC, CD=group_CD, CE=group_CE, CF=group_CF, CG=group_CG, CH=group_CH,
              CI=group_CI, CJ=group_CJ, CK=group_CK)


def main():
    want = os.environ.get('RG_CON_GROUPS'); sel = want.split(',') if want else list(GROUPS)
    for g in sel:
        GROUPS[g]()                                               # a crash writes no results: never a pass, never a catch
        print(g, 'done', flush=True)
    R['failures'] = FAILS; R['groups_run'] = sel
    R['source_sha256'] = {f: hashlib.sha256((HERE / f).read_bytes()).hexdigest()
                          for f in ('rg_construct.py', 'rg_construct_battery.py', 'rg_pendulum.py', 'class_default.json')}
    (HERE / 'rg_construct_battery_results.json').write_text(json.dumps(R, indent=1, sort_keys=True, default=float))
    print(json.dumps({k: v for k, v in R.items() if k not in ('CI',)}, indent=1, sort_keys=True, default=float)[:7000])
    return 1 if FAILS else 0


if __name__ == '__main__':
    sys.exit(main())
