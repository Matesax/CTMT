# Resolution Geometry: The Forcing Construction

RG's own construction as computation, attacked claim by claim. Paper: `RG - The Forcing Construction.pdf`
(source `RG_Forcing_Construction.tex`). The programme's main print and README are in `Resolution Geometry.pdf` and `README.md`.

## What is here

| File | What it is |
|---|---|
| `rg_construct.py` | the library: `resolve`, `width`, `load_split`, `kernel`, `transfer`, `fisher_width`; `tidal`, `riemann_from_tidal`, `observation_rank`, `ricci`, `einstein`; `compass_design`, `compass_model` |
| `rg_construct_battery.py` | hostile battery, groups CA–CK; writes `rg_construct_battery_results.json` |
| `rg_construct_battery_mutations.py` | seventeen one-line falsifications; each must fail its target group |
| `rg_pendulum.py`, `class_default.json` | the pendulum tool and class, used by groups CE and CF |

```
pip install -r requirements.txt            # numpy, scipy
python3 -I rg_construct_battery.py          # about 80 s; byte-identical on rerun
python3 -I rg_construct_battery_mutations.py --jobs 2
```

## Use

```python
import numpy as np, rg_construct as K
r = K.resolve(A, tau, eps, d=offsets, bl=box_lo, bu=box_hi, tol=0.02)
# r['kernel_dim'], r['leakage'] (sqrt tr Q), r['range'], r['width'],
# r['record_cost'], r['declaration_cost'], r['declaration_share'], r['status']
```

Statuses: `INCONSISTENT`, `LEAKS` (no box and the task leaks into the kernel), `CORRESPONDENCE`,
`LOCKED-FIRST-ORDER`. A first-order lock is planning: issue `LOCKED` only from the global fibre (the pendulum
enclosure, or an exact representation on linear models).

## What it shows

- No new tensor formula: the transfer Q is a restricted pullback with classical invariants. With bounded records the
  native local object is a norm (the width), not a tensor; Fisher is its ellipsoidal shadow.
- Q is blind to resolution: on the pendulum Q is 0 from four records while the fibre locks only at 13–22.
- Gravity: the tidal tensor is the transfer tensor of velocity ignorance; a compass forces Ric(u,u) only with three
  epochs and non-coplanar probes; five observers fix the Riemann tensor, one observer fixes Ric(u,u) but not G(u,u).
  Einstein's equation is not built here.

Author: Matěj Rada, MatejRada@email.cz. License: CC BY-NC-ND 4.0.
