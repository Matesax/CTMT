#!/usr/bin/env python3
"""Resolution Geometry - the forcing construction as computation.

Input at a point of a declared class: record covectors A (m x n: the derivatives of the m records with respect to the n
class coordinates), per-record error bounds eps (m), the offsets d = r - F(p) of the actual records at the
linearization point p (zero for a pre-data plan), the declared class as a box [bl, bu] around p, and a task covector tau
(n), the derivative of the target.

Output, all first order (they are advisory; LOCKED is issued only by a global fibre audit):
  ignorance bundle   V = ker A at a stated resolution (singular values below rank_tol * largest are kernel)
  transfer           J = tau restricted to V and Q = J^T J (the exact-kernel leakage of the task)
  width              w = max - min of tau.v over the linearized fibre {v : |A v - d| <= eps, bl <= v <= bu}
  load split         by LP duality w = record cost + declaration cost; the declaration share D in [0, 1] is reported as
                     the interval [D_min, D_max] over the optimal dual face
  Fisher shadow      2 sqrt(tau I^+ tau) with I = A^T diag(eps^-2) A: the width of the ellipsoidal (l2) error set
  status             INCONSISTENT (no v meets the records), LEAKS (Q != 0 and no box: unbounded), CORRESPONDENCE or
                     LOCKED-FIRST-ORDER (w <= 2 tol)

Also: observer-frame tidal tensors E(u) of an algebraic curvature tensor, reconstruction of the Riemann tensor from the
tidal tensors of several observers, Ricci and Einstein tensors; the linearized gravitational compass (probes released
at known offsets, positions recorded at epochs).

numpy, scipy. Deterministic.
"""
import itertools
import numpy as np
from scipy.optimize import linprog

__all__ = ['resolve', 'width', 'load_split', 'kernel', 'transfer', 'fisher_width', 'curvature_basis', 'tidal',
           'riemann_from_tidal', 'ricci', 'einstein', 'compass_design']


# ------------------------------------------------------------------ first-order construction
def kernel(A, rank_tol=1e-9):
    """Orthonormal basis of ker A at resolution rank_tol (relative to the largest singular value), and the singular
    values. A singular value between rank_tol and 1e3 * rank_tol is a rank wall: reported, not decided."""
    A = np.atleast_2d(np.asarray(A, float)); n = A.shape[1]
    if A.shape[0] == 0:
        return np.eye(n), np.zeros(0), False
    U, s, Vt = np.linalg.svd(A)
    smax = s[0] if len(s) and s[0] > 0 else 1.0
    r = int(np.sum(s > rank_tol * smax))
    wall = bool(np.any((s > rank_tol * smax) & (s < 1e3 * rank_tol * smax)))
    return Vt[r:].T, s, wall


def transfer(A, tau, rank_tol=1e-9):
    """J = tau|_V in an orthonormal basis of V, and Q = J^T J (a tensor on V: Q -> S^T Q S under v = S w)."""
    V, s, wall = kernel(A, rank_tol)
    J = np.atleast_2d(np.asarray(tau, float)) @ V
    return J, J.T @ J, V, wall


def _lp(c, A_ub, b_ub, bounds):
    res = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method='highs')
    return res


def width(A, tau, eps, d=None, bl=None, bu=None):
    """Range of tau.v over {v : |A v - d| <= eps, bl <= v <= bu}. Returns (min, max) or None if empty; +-inf if unbounded."""
    A = np.atleast_2d(np.asarray(A, float)); m, n = A.shape; tau = np.asarray(tau, float)
    eps = np.broadcast_to(np.asarray(eps, float), (m,)); d = np.zeros(m) if d is None else np.asarray(d, float)
    bounds = [(None if bl is None else bl[i], None if bu is None else bu[i]) for i in range(n)]
    G = np.vstack([A, -A]) if m else None; h = np.r_[d + eps, eps - d] if m else None
    hi = _lp(-tau, G, h, bounds); lo = _lp(tau, G, h, bounds)
    if hi.status == 2 or lo.status == 2:
        return None
    up = np.inf if hi.status == 3 else -hi.fun; dn = -np.inf if lo.status == 3 else lo.fun
    if hi.status not in (0, 3) or lo.status not in (0, 3):
        raise RuntimeError('linear programme failed')
    return dn, up


def _dual_cost(A, tau, up, lo, bu, bl, share_sense=None, opt=None):
    """min over splits tau = A^T lam + mu of  sum(up_k lam+_k - lo_k lam-_k) + sum(bu_i mu+_i - bl_i mu-_i).
    With share_sense = +1 / -1 and the optimum opt, minimize / maximize the declaration part on the optimal face."""
    m, n = A.shape
    # variables: lam+ (m), lam- (m), mu+ (n), mu- (n), all >= 0
    c_rec = np.r_[up, -lo, np.zeros(2 * n)]; c_dec = np.r_[np.zeros(2 * m), bu, -bl]
    Aeq = np.hstack([A.T, -A.T, np.eye(n), -np.eye(n)])
    if share_sense is None:
        res = linprog(c_rec + c_dec, A_eq=Aeq, b_eq=tau, bounds=[(0, None)] * (2 * m + 2 * n), method='highs')
        return res.fun, float(c_rec @ res.x), float(c_dec @ res.x)
    res = linprog(share_sense * c_dec, A_ub=(c_rec + c_dec)[None, :], b_ub=[opt * (1 + 1e-9) + 1e-12], A_eq=Aeq, b_eq=tau,
                  bounds=[(0, None)] * (2 * m + 2 * n), method='highs')
    return float(c_dec @ res.x)


def load_split(A, tau, eps, d, bl, bu):
    """Width of the linearized fibre split by duality into the cost carried by records and the cost carried by the
    declared box. Requires the origin to be feasible (the tool re-centres first). Returns dict."""
    A = np.atleast_2d(np.asarray(A, float)); m, n = A.shape; tau = np.asarray(tau, float)
    eps = np.broadcast_to(np.asarray(eps, float), (m,)); d = np.asarray(d, float)
    up, lo = d + eps, d - eps; bl = np.asarray(bl, float); bu = np.asarray(bu, float)
    tot = rec = dec = 0.0; dmin = dmax = 0.0
    for s in (1, -1):                                             # max of tau.v  and  max of -tau.v
        val, r_, d_ = _dual_cost(A, s * tau, up, lo, bu, bl)
        tot += val; rec += r_; dec += d_
        dmin += _dual_cost(A, s * tau, up, lo, bu, bl, +1, val)
        dmax += _dual_cost(A, s * tau, up, lo, bu, bl, -1, val)
    w = tot
    return dict(width=w, record_cost=rec, declaration_cost=dec,
                declaration_share=[dmin / w if w > 0 else 0.0, dmax / w if w > 0 else 0.0])


def fisher_width(A, tau, eps, rank_tol=1e-9):
    """Width of tau.v over the ellipsoid v^T I v <= 1, I = A^T diag(eps^-2) A: 2 sqrt(tau I^+ tau) when tau is in the
    row space, +inf otherwise."""
    A = np.atleast_2d(np.asarray(A, float)); eps = np.broadcast_to(np.asarray(eps, float), (A.shape[0],))
    I = A.T @ (A / eps[:, None] ** 2); J, Q, V, _ = transfer(A, tau, rank_tol)
    if np.linalg.norm(J) > 1e-9 * max(1.0, np.linalg.norm(tau)):
        return np.inf
    return float(2 * np.sqrt(max(tau @ np.linalg.pinv(I) @ tau, 0.0)))


def resolve(A, tau, eps, d=None, bl=None, bu=None, tol=None, rank_tol=1e-9):
    """The typed first-order construction. Returns a dict (see module docstring)."""
    A = np.atleast_2d(np.asarray(A, float)); m, n = A.shape; tau = np.asarray(tau, float)
    eps = np.broadcast_to(np.asarray(eps, float), (m,)).copy(); d = np.zeros(m) if d is None else np.asarray(d, float)
    J, Q, V, wall = transfer(A, tau, rank_tol)
    out = dict(rank=n - V.shape[1], kernel_dim=V.shape[1], rank_wall=wall, leakage=float(np.sqrt(np.trace(Q))) if Q.size else 0.0,
               fisher_width=fisher_width(A, tau, eps, rank_tol))
    boxed = bl is not None and bu is not None
    # re-centre: the point of the linearized fibre with the smallest l_inf record violation
    bounds = [(bl[i], bu[i]) if boxed else (None, None) for i in range(n)] + [(0, None)]
    c = np.r_[np.zeros(n), 1.0]
    G = np.vstack([np.hstack([A, -np.ones((m, 1))]), np.hstack([-A, -np.ones((m, 1))])]) if m else np.zeros((0, n + 1))
    h = np.r_[d, -d] if m else np.zeros(0)
    cen = linprog(c, A_ub=G if m else None, b_ub=h if m else None, bounds=bounds, method='highs')
    viol = float(cen.x[n]) if (m and cen.status == 0) else (0.0 if not m else np.inf)
    out['linf_violation'] = viol
    rng = width(A, tau, eps, d, bl, bu)
    if (m and np.any(viol > eps * (1 + 1e-9) + 1e-12)) or rng is None:
        out['status'] = 'INCONSISTENT'
        return out
    v0 = cen.x[:n]
    out['range'] = [float(rng[0]), float(rng[1])]
    out['width'] = float(rng[1] - rng[0])
    if not np.isfinite(out['width']):
        out['status'] = 'LEAKS'
        return out
    if boxed:
        dd = d - A @ v0; bl2 = np.asarray(bl) - v0; bu2 = np.asarray(bu) - v0
        ls = load_split(A, tau, eps, dd, bl2, bu2)
        out.update(record_cost=ls['record_cost'], declaration_cost=ls['declaration_cost'], declaration_share=ls['declaration_share'])
    if tol is not None:
        out['status'] = 'LOCKED-FIRST-ORDER' if out['width'] <= 2 * tol else 'CORRESPONDENCE'
    else:
        out['status'] = 'CORRESPONDENCE'
    return out


# ------------------------------------------------------------------ curvature from tidal records
ETA = np.diag([-1.0, 1.0, 1.0, 1.0])


def kulkarni_nomizu(h, k):
    R = np.zeros((4, 4, 4, 4))
    for a, b, c, e in itertools.product(range(4), repeat=4):
        R[a, b, c, e] = h[a, c] * k[b, e] + h[b, e] * k[a, c] - h[a, e] * k[b, c] - h[b, c] * k[a, e]
    return R


def curvature_basis(seed=0):
    """Orthonormal basis (20 x 256) of algebraic curvature tensors in 4 dimensions (spanned by Kulkarni-Nomizu products)."""
    rng = np.random.default_rng(seed); rows = []
    for _ in range(60):
        h = rng.normal(size=(4, 4)); h = h + h.T; k = rng.normal(size=(4, 4)); k = k + k.T
        rows.append(kulkarni_nomizu(h, k).ravel())
    U, s, Vt = np.linalg.svd(np.array(rows)); r = int(np.sum(s > 1e-9 * s[0]))
    return Vt[:r]


def boost(beta):
    beta = np.asarray(beta, float); b = np.linalg.norm(beta); L = np.eye(4)
    if b == 0:
        return L
    g = 1 / np.sqrt(1 - b * b); n = beta / b
    L[0, 0] = g; L[0, 1:] = g * beta; L[1:, 0] = g * beta; L[1:, 1:] += (g - 1) * np.outer(n, n)
    return L


def tidal(R, L):
    """Tidal (electric) tensor E_ij = R(e_i, u, e_j, u) of the observer whose orthonormal frame is the columns of L
    (u = L[:, 0]); indices of R are all down, in an orthonormal frame with metric diag(-1, 1, 1, 1)."""
    return np.einsum('abcd,ai,b,cj,d->ij', R, L[:, 1:], L[:, 0], L[:, 1:], L[:, 0])


def riemann_from_tidal(Es, Ls, basis=None):
    """Least-squares reconstruction of R from observer tidal tensors. Returns (R, rank of the observation map, residual)."""
    B = curvature_basis() if basis is None else basis
    iu = np.triu_indices(3)
    M = np.array([np.concatenate([tidal(b.reshape(4, 4, 4, 4), L)[iu] for L in Ls]) for b in B]).T
    y = np.concatenate([E[iu] for E in Es]); coef, *_ = np.linalg.lstsq(M, y, rcond=None)
    rank = int(np.linalg.matrix_rank(M, 1e-9 * np.linalg.norm(M, 2)))
    return (coef @ B).reshape(4, 4, 4, 4), rank, float(np.linalg.norm(M @ coef - y))


def ricci(R):
    return np.einsum('ac,abcd->bd', ETA, R)


def einstein(R):
    Ric = ricci(R); s = np.einsum('ab,ab', ETA, Ric)
    return Ric - 0.5 * s * ETA


def observation_rank(Ls, basis=None, functionals=()):
    """Rank of R -> (E(u))_u over the curvature space, and for each functional (a function R -> scalar) whether it is
    determined (lies in the row space)."""
    B = curvature_basis() if basis is None else basis; iu = np.triu_indices(3)
    M = np.array([np.concatenate([tidal(b.reshape(4, 4, 4, 4), L)[iu] for L in Ls]) for b in B]).T
    tolr = 1e-9 * max(np.linalg.norm(M, 2), 1.0); rk = int(np.linalg.matrix_rank(M, tolr))
    det = []
    for f in functionals:
        g = np.array([f(b.reshape(4, 4, 4, 4)) for b in B])
        det.append(int(np.linalg.matrix_rank(np.vstack([M, g]), tolr)) == rk)
    return rk, det


# ------------------------------------------------------------------ the linearized gravitational compass
SYM = [(0, 0), (1, 1), (2, 2), (0, 1), (0, 2), (1, 2)]


def compass_design(offsets, epochs, E_nominal=None):
    """Probes released at offsets xi0_j (N x 3) from a freely falling reference with unknown relative velocities v_j;
    positions recorded at the given epochs. Model xi_j(t) = xi0_j + t v_j - (t^2 / 2) E xi0_j. Coordinates:
    (xi0 (3N), v (3N), E (6: xx, yy, zz, xy, xz, yz)). Returns the record matrix A (3N len(epochs) x (6N + 6)) and the
    task covectors trace (Ric(u,u)) and the six components."""
    X = np.asarray(offsets, float); N = len(X); En = np.zeros((3, 3)) if E_nominal is None else np.asarray(E_nominal, float)
    rows = []
    for t in epochs:
        for j in range(N):
            for i in range(3):
                a = np.zeros(6 * N + 6)
                a[3 * j:3 * j + 3] = np.eye(3)[i] - 0.5 * t * t * En[i]          # d xi_i / d xi0_j
                a[3 * N + 3 * j + i] = t                                       # d xi_i / d v_j
                for s, (p, q) in enumerate(SYM):                               # d xi_i / d E_pq
                    if p == q:
                        a[6 * N + s] = -0.5 * t * t * (X[j, q] if i == p else 0.0)
                    else:
                        a[6 * N + s] = -0.5 * t * t * ((X[j, q] if i == p else 0.0) + (X[j, p] if i == q else 0.0))
                rows.append(a)
    A = np.array(rows); tr = np.zeros(6 * N + 6); tr[6 * N:6 * N + 3] = 1.0
    comps = []
    for s in range(6):
        c = np.zeros(6 * N + 6); c[6 * N + s] = 1.0; comps.append(c)
    return A, tr, comps


def compass_model(offsets, v, E, epochs):
    X = np.asarray(offsets, float)
    return np.array([[X[j] + t * v[j] - 0.5 * t * t * (E @ X[j]) for j in range(len(X))] for t in epochs]).reshape(-1)
