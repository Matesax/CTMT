#!/usr/bin/env python3
"""Mutation suite for rg_construct_battery.py.

Each mutation changes one line of the library (or of the battery's reference computation) so that a claim of the
construction paper becomes false. It is caught only when the targeted group fails; the battery is run on that group
alone. A survivor is a defect of the battery; a crash is a defect of the suite, not a catch. Runs in temporary copies.

    python3 -I rg_construct_battery_mutations.py [--jobs 2] [--only CA,CB]
"""
import argparse, json, os, shutil, subprocess, sys, tempfile
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
NAME = 'rg_construct_battery'
LIB = 'rg_construct.py'
BAT = NAME + '.py'
MUTATIONS = [  # (group, description, file, old, new)
    ('CA', 'record bounds shifted the wrong way', LIB, 'h = np.r_[d + eps, eps - d] if m else None', 'h = np.r_[d + eps, eps + d] if m else None'),
    ('CB', 'full column rank claimed', LIB, 'r = int(np.sum(s > rank_tol * smax))', 'r = A.shape[1]'),
    ('CB', 'transfer computed as zero', LIB, 'J = np.atleast_2d(np.asarray(tau, float)) @ V', 'J = np.atleast_2d(np.asarray(tau, float)) @ V * 0'),
    ('CC', 'Fisher width without the factor 2', LIB, 'return float(2 * np.sqrt(max(tau @ np.linalg.pinv(I) @ tau, 0.0)))',
     'return float(np.sqrt(max(tau @ np.linalg.pinv(I) @ tau, 0.0)))'),
    ('CD', 'declaration cost dropped from the dual', LIB, 'c_dec = np.r_[np.zeros(2 * m), bu, -bl]', 'c_dec = np.r_[np.zeros(2 * m), 0 * bu, -0 * bl]'),
    ('CE', 'empty fibre reported as a range', LIB, "out['status'] = 'INCONSISTENT'", "out['status'] = 'CORRESPONDENCE'"),
    ('CE', 'first-order lock threshold 1000 times stricter', LIB, "'LOCKED-FIRST-ORDER' if out['width'] <= 2 * tol", "'LOCKED-FIRST-ORDER' if out['width'] <= 0.002 * tol"),
    ('CF', 'record bound halved in the width', LIB,
     "eps = np.broadcast_to(np.asarray(eps, float), (m,)); d = np.zeros(m) if d is None else np.asarray(d, float)\n    bounds",
     "eps = 0.5 * np.broadcast_to(np.asarray(eps, float), (m,)); d = np.zeros(m) if d is None else np.asarray(d, float)\n    bounds"),
    ('CG', 'transfer-tensor coefficient 1/6 instead of 1/3', BAT, 'Es[t] = -3 * (Q - t * t * np.eye(3)) / t ** 4', 'Es[t] = -6 * (Q - t * t * np.eye(3)) / t ** 4'),
    ('CH', 'velocity entering at t^2', LIB, 'a[3 * N + 3 * j + i] = t ', 'a[3 * N + 3 * j + i] = t * t '),
    ('CH', 'off-diagonal tidal term counted once', LIB,
     'a[6 * N + s] = -0.5 * t * t * ((X[j, q] if i == p else 0.0) + (X[j, p] if i == q else 0.0))',
     'a[6 * N + s] = -0.5 * t * t * ((X[j, q] if i == p else 0.0))'),
    ('CI', 'tidal tensor contracted on swapped slots (sign)', LIB, "np.einsum('abcd,ai,b,cj,d->ij'", "np.einsum('abcd,ai,b,dj,c->ij'"),
    ('CI', 'Einstein tensor without the factor 1/2', LIB, 'return Ric - 0.5 * s * ETA', 'return Ric - s * ETA'),
    ('CI', 'Kulkarni-Nomizu sign error', LIB, '- h[a, e] * k[b, c] - h[b, c] * k[a, e]', '- h[a, e] * k[b, c] + h[b, c] * k[a, e]'),
    ('CI', 'boost without the transverse correction', LIB, 'L[1:, 1:] += (g - 1) * np.outer(n, n)', 'L[1:, 1:] += 0 * np.outer(n, n)'),
    ('CJ', 'record mixing replaced by the identity', BAT, 'Mx = np.array([[1, 1, 0], [1, -1, 0], [0, 0, 1.0]])', 'Mx = np.eye(3)'),
    ('CK', 'only orthogonal coordinate changes tested', BAT, 'S = rng.normal(size=(n, n)) + 2 * np.eye(n)', 'S = np.linalg.qr(rng.normal(size=(n, n)))[0]'),
]


def run(mut):
    group, desc, rel, old, new = mut
    base = open(os.path.join(HERE, rel)).read()
    if base.count(old) != 1:
        return group, desc, 'anchor not found exactly once -> SUITE DEFECT', False
    with tempfile.TemporaryDirectory() as tmp:
        work = os.path.join(tmp, 'b')
        shutil.copytree(HERE, work, ignore=shutil.ignore_patterns('__pycache__', NAME + '_results.json', NAME + '_mutations.py',
                                                                  '*.log', 'paper', '*.zip', 'r*.json', 'proto*.py', 'bundle*'))
        open(os.path.join(work, rel), 'w').write(base.replace(old, new))
        env = dict(os.environ, RG_CON_GROUPS=group)
        subprocess.run([sys.executable, '-I', NAME + '.py'], cwd=work, capture_output=True, text=True, env=env)
        try:
            fails = json.load(open(os.path.join(work, NAME + '_results.json')))['failures']
        except Exception:
            fails = ['CRASHED']
    ok = group in fails
    return group, desc, ('caught ' if ok else 'SURVIVED ') + str(fails), ok


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--jobs', type=int, default=2); ap.add_argument('--only', default='')
    a = ap.parse_args(); sel = [m for m in MUTATIONS if not a.only or m[0] in a.only.split(',')]
    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(run, sel))
    for g, d, msg, _ in res:
        print(f'{g}  {d}: {msg}', flush=True)
    caught = sum(r[3] for r in res)
    print(f'{caught} / {len(sel)} caught')
    return 0 if caught == len(sel) else 1


if __name__ == '__main__':
    sys.exit(main())
