# RG - Presentation and Thresholds: battery DF01-DF07

    python3 rg_defense_attack.py            # seed 20261023
    python3 rg_defense_attack.py --canary   # presentation leak; threshold-dependent noise

7/7 on seeds 20261023, 1, 42, 777, 2026; canary 2/2. DF03 and DF07 are signature checks; DF01, DF02, DF04-DF06 are substantive.
