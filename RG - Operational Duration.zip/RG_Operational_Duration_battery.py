import numpy as np
np.set_printoptions(precision=4, suppress=True)
rng=np.random.default_rng(20260920)

print("="*72)
print("DECISIVE NARROWING: the universal-coordinate loophole")
print("  A global coordinate t CAN coexist with path-dependent clock rates.")
print("  So DeltaT_A != DeltaT_B does NOT prove 'no universal coordinate'.")
print("="*72)
t=np.linspace(0,1,2000)
def path(vf,Uf):
    v=vf(t); U=Uf(t); rate=41*np.sqrt(1-v**2)*(1+U)     # dT/dt = r(v,U), same t
    return np.trapezoid(rate,t)
TA=path(lambda s:0.2+0.0*s, lambda s:0.1+0.0*s)
TB=path(lambda s:0.6*np.sin(np.pi*s)**2, lambda s:0.3*s)
print("  same coordinate interval [0,1]; T_A=%.4f  T_B=%.4f  -> DeltaT differs while t EXISTS"%(TA,TB))
print("  => strong theorem 'no universal scalar coordinate' is FALSE (loophole holds).")
print("  Survivable claim: no PATH-INDEPENDENT universal elapsed duration for identical clocks.")

print("\n"+"="*72)
print("K2: three-clock held-out affine calibration + cocycle closure")
print("="*72)
n=200; lat=rng.uniform(0,10,n)                          # latent operational duration
QA=1.0*lat+0.0+rng.normal(0,1e-3,n)
QB=2.7*lat-4.0+rng.normal(0,1e-3,n)
QC=0.43*lat+9.0+rng.normal(0,1e-3,n)
tr=slice(0,120); te=slice(120,None)
def fit(x,y): 
    A=np.c_[x,np.ones_like(x)]; b=np.linalg.lstsq(A[tr],y[tr],rcond=None)[0]; return b
def rmse(x,y,b): return float(np.sqrt(np.mean((b[0]*x[te]+b[1]-y[te])**2)))
bAB=fit(QA,QB); bAC=fit(QA,QC); bBC=fit(QB,QC)
print("  held-out RMSE A->B %.2e  A->C %.2e  B->C %.2e (~ clock noise)"%(rmse(QA,QB,bAB),rmse(QA,QC,bAC),rmse(QB,QC,bBC)))
comp=np.array([bBC[0]*bAB[0], bBC[0]*bAB[1]+bBC[1]])    # composed A->B->C
print("  cocycle: direct A->C %s vs composed %s  err=%.2e"%(np.round(bAC,4),np.round(comp,4),np.linalg.norm(bAC-comp)))

print("\n"+"="*72)
print("K4: path-dependent contrast D_AB (affine-gauge invariant sign) rejects H_PI")
print("="*72)
DTA, DTB = TA, TB
a_AB=bAB[0]
D=DTA - (1/1.0)*DTB                                     # gauge-invariant elapsed contrast (same clock units here)
print("  D_AB = %.4f != 0 -> reject path-independent accumulation H_PI"%D)
# gauge invariance: rescale T -> aT+b, sign of contrast preserved
for a,b in [(3.0,5.0),(0.2,-1.0)]:
    Dg=(a*DTA+b)-(a*DTB+b)
    print("  under T->%.1f T+%.1f : sign(D)=%d (invariant)"%(a,b,np.sign(Dg)))

print("\n"+"="*72)
print("K5: species-by-path gate (residual must NOT correlate with path variables)")
print("="*72)
v2=rng.uniform(0,0.5,n)
QB_dev=2.7*lat-4.0+0.8*v2+rng.normal(0,1e-3,n)          # species-specific v^2 sensitivity
resid=QB_dev-(bAB[0]*QA+bAB[1])
print("  residual corr with v^2 = %.3f  -> if large, path dependence is DEVICE drift, not shared duration"%np.corrcoef(resid,v2)[0,1])

print("\n"+"="*72)
print("Orientation no-go + conditional GR realization")
print("="*72)
print("  unsigned duration under path reversal: integral of sqrt(...) same forwards/backwards -> orientation NOT fixed")
# GR realization vs competitors (synthetic Lorentzian truth)
paths=[(rng.uniform(0,0.7),rng.uniform(0,0.5)) for _ in range(80)]
tau=np.array([np.sqrt(1-v**2)*(1+U) for v,U in paths])   # frozen Lorentzian-ish proper time
Tobs=41*tau+rng.normal(0,1e-3,len(paths))
trn=slice(0,53); tst=slice(53,None)
bg=np.linalg.lstsq(np.c_[tau[trn],np.ones(53)],Tobs[trn],rcond=None)[0]
gr=np.sqrt(np.mean((bg[0]*tau[tst]+bg[1]-Tobs[tst])**2))
pi=np.sqrt(np.mean((Tobs[tst].mean()-Tobs[tst])**2))     # path-independent null
print("  held-out RMSE: GR %.2e  vs path-independent-null %.2f -> GR realization CONDITIONALLY supported"%(gr,pi))
