# Cross-Clock Path-Dependence: hostile attack

Seed: `20260920`

**Paper status: LOCKABLE_AFTER_NARROWING**

## 1. three_clock_heldout_affine_closure: SURVIVES
Three clock families can define charts of one affine operational-duration object without fitting GR.

```json
{
  "A->B": {
    "beta": [
      2.699990162661101,
      -3.9997545963840047
    ],
    "heldout_rmse": 0.0025804669579606956
  },
  "A->C": {
    "beta": [
      0.4300032027680083,
      8.999815925402428
    ],
    "heldout_rmse": 0.0011640238197379769
  },
  "B->C": {
    "beta": [
      0.15926102562998917,
      9.636820955592407
    ],
    "heldout_rmse": 0.001072515453173167
  }
}
```

## 2. affine_cocycle_closure: SURVIVES
Pairwise agreement is insufficient; the three-clock transition graph must close on cycles.

```json
{
  "direct_A_to_C": [
    0.4300032027680083,
    8.999815925402428
  ],
  "composed_A_to_B_to_C": [
    0.43000320249628826,
    8.999815936304028
  ],
  "parameter_error": 1.0904985379099152e-08
}
```

## 3. restricted_absolute_clock_null: FALSIFIED_IN_SYNTHETIC_WITNESS
This rejects the restricted null that identically prepared ideal clocks accumulate the same duration for equal coordinate intervals independently of path.

```json
{
  "mean_identical_clock_difference": 8.846614277262168,
  "standard_error": 0.3864437346921867,
  "z_score": 22.89237341189849
}
```

## 4. universal_coordinate_loophole: BREAKS_STRONG_THEOREM
Unequal clock readings do not by themselves prove that no universal scalar coordinate exists. They disprove only a universal path-independent clock law or an operationally privileged absolute duration.

```json
{
  "common_coordinate_intervals": true,
  "path_dependent_rate_law": "dT/dt = 41 sqrt(1-v^2)(1+U)",
  "max_reconstruction_error": 1.4210854715202004e-14
}
```

## 5. species_by_path_systematic: GATE_REQUIRED
Cross-clock agreement must be tested for species-by-path interactions; otherwise environmental or device sensitivity can imitate non-universal duration.

```json
{
  "A->B": {
    "heldout_rmse": 0.07448930390963583,
    "residual_corr_v2": 0.9613969247532053
  },
  "A->C": {
    "heldout_rmse": 0.04695814243600314,
    "residual_corr_v2": -0.9618003792632885
  }
}
```

## 6. heldout_model_comparison: CONDITIONAL_GR_REALIZATION
Held-out superiority over a path-independent null supports path dependence. Proper-time realization additionally requires a declared Lorentzian competitor class and comparison against alternative path laws.

```json
{
  "GR_benchmark_rmse": 0.0009364608999347015,
  "path_independent_absolute_rmse": 6.728763452019609,
  "non_GR_flexible_path_model_rmse": 0.4886480121180785,
  "frozen_GR_affine_map": [
    41.00006007400821,
    -2.5368795418612485e-05
  ]
}
```

## 7. orientation_and_synchronization: GATE_REQUIRED
Unsigned elapsed duration does not determine time orientation, and reunion differences require explicit synchronization and transport-offset controls.

```json
{
  "unsigned_duration_invariant_under_reversal": true,
  "sync_offset_sd": 0.021658755964163716,
  "apparent_difference_shift": -0.0006444282745885488
}
```

## 8. affine_gauge_invariant_contrast: SURVIVES
Elapsed differences and dimensionless ratios can state path dependence without choosing an origin; absolute magnitude still needs one unit calibration.

```json
{
  "normalized_difference_error": 1.3988810110276972e-14,
  "sign_preserved": true
}
```

## Locked K0-K7 ladder

- **K0:** Each clock supplies phase or count data and a locally declared operational duration. This is not yet GR proper time.
- **K1:** At least three independent clock families are trained only on a co-located calibration domain.
- **K2:** Frozen positive-affine transition maps predict held-out clocks and satisfy cycle/cocycle closure.
- **K3:** Identical clocks are separated and reunited across preregistered path ensembles with complete nuisance and synchronization controls.
- **K4:** The restricted path-independent ideal-clock null is rejected using affine-gauge-invariant elapsed contrasts.
- **K5:** Species-by-path interactions are absent within uncertainty, establishing a shared path-dependent operational duration rather than device-specific drift.
- **K6:** Only after K4-K5, Lorentzian proper time and explicit alternative path laws are fitted on training paths and frozen.
- **K7:** A proper-time realization is supported only when one affine calibration predicts all held-out species and paths better than preregistered competitors.
- **nonclaim:** The result does not prove nonexistence of every global scalar coordinate. It proves failure of path-independent universal clock accumulation and, conditionally, realizes the shared duration by Lorentzian proper time.

## Locked theorem
On a tested domain, suppose three or more independent clock families define a held-out, cocycle-consistent affine clock; identically prepared clocks separated along distinct controlled histories exhibit reproducible affine-gauge-invariant elapsed differences; species-by-path interactions and synchronization/systematic explanations are excluded within the declared uncertainty model; and one frozen Lorentzian proper-time functional with one global affine calibration predicts all held-out clocks and paths against declared alternatives. Then the experiment rejects path-independent universal clock accumulation on that domain and supports Lorentzian proper time as an empirical representation of the common operational duration. It does not exclude the mathematical existence of an auxiliary global coordinate with path-dependent clock-rate laws.