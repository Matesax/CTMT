#!/usr/bin/env python3
"""RG physical-time lock attack.

Attacks candidate objects that might host time or accumulate scale into physical time.
The battery distinguishes:
  - order carriers,
  - additive duration carriers,
  - scale carriers,
  - path/geometry carriers,
  - physical calibration/validation.

Synthetic counterexamples can close no-go claims and test sufficiency of a proposed bridge,
but cannot empirically establish that an RG clock equals physical proper time.
"""
from __future__ import annotations
import json, math
from dataclasses import dataclass, asdict
from pathlib import Path
import numpy as np

SEEDS=[20260825,20260807,314159]
TOL=1e-10

@dataclass
class Result:
    object:str
    role:str
    status:str
    witness:dict
    verdict:str


def fit_affine(x,y):
    X=np.column_stack([x,np.ones_like(x)])
    beta=np.linalg.lstsq(X,y,rcond=None)[0]
    pred=X@beta
    return beta,pred,float(np.sqrt(np.mean((y-pred)**2)))


def rank(A,tol=1e-10): return int(np.linalg.matrix_rank(np.asarray(A,float),tol))


def main():
    R=[]

    # 1 causal order: invariant under arbitrary increasing reparameterization
    t=np.linspace(0,3,9); f=t**3+7*t
    same_order=bool(np.all(np.diff(t)>0) and np.all(np.diff(f)>0))
    ratio=(f[-1]-f[0])/(t[-1]-t[0])
    R.append(Result('causal/preorder','orientation and order','NO_SCALE',
        {'same_order':same_order,'non_affine_reparameterization':'f(t)=t^3+7t','endpoint_duration_ratio':ratio},
        'Order survives arbitrary monotone reparameterization, so it cannot fix elapsed-time scale or interval ratios.'))

    # 2 raw delay decomposition non-identifiability
    raw=0.030
    decomps=[(0.001,0.004,0.020,0.003,0.002),(0.003,0.002,0.015,0.006,0.004),(0.0005,0.0075,0.018,0.002,0.002)]
    sums=[sum(x) for x in decomps]
    R.append(Result('raw wall-tap delay','composite latency','COMPOSITE_ONLY',
        {'raw_seconds':raw,'decompositions':decomps,'sums':sums,'all_equal_raw':all(abs(s-raw)<1e-12 for s in sums)},
        'A measured 30 ms can host an ordered interval, but without controls it does not identify propagation, detector, source, or memory time.'))

    # 3 single exponential decay: scale gauge lambda*t
    grid=np.linspace(0,4,50); lam=2.3; C=np.exp(-lam*grid)
    a=11.0; grid2=grid/a; lam2=lam*a
    invariant=float(np.max(np.abs(C-np.exp(-lam2*grid2))))
    R.append(Result('single decay C','dimensionless progress / semigroup coordinate','UNIT_GAUGE',
        {'lambda':lam,'rescaled_lambda':lam2,'time_rescale':a,'max_curve_error':invariant},
        'C determines T=-log C=lambda*t, but cannot separate physical time t from the rate/unit lambda.'))

    # 4 multiscale decay: even several rates retain common time gauge
    rates=np.array([0.7,1.9,4.2]); M=np.exp(-np.outer(grid,rates))
    rates2=rates*a; M2=np.exp(-np.outer(grid/a,rates2))
    R.append(Result('multiscale decay family','relative rate spectrum','COMMON_UNIT_GAUGE',
        {'rates':rates.tolist(),'rescaled_rates':rates2.tolist(),'max_family_error':float(np.max(np.abs(M-M2)))},
        'Multiple decay channels identify rate ratios and shared progress, but retain one common positive scale gauge.'))

    # 5 entropy: same entropy path under time reparameterization
    p=0.5*(1+np.exp(-grid))
    pc=np.clip(p,1e-15,1-1e-15); H=-(pc*np.log(pc)+(1-pc)*np.log(1-pc))
    u=grid**2+grid
    # Same ordered entropy samples labelled by another clock coordinate.
    R.append(Result('entropy trajectory','state functional / arrow candidate','NO_DURATION',
        {'entropy_start':float(H[0]),'entropy_end':float(H[-1]),'alternative_labels_first_last':[float(u[0]),float(u[-1])]},
        'Entropy values can order a restricted irreversible branch, but state entropy does not determine interval duration or calibration.'))

    # 6 Fisher arc length: parameterization invariant and covariance dependent
    s=np.linspace(0,1,2001); theta=s**3
    dtheta=3*s*s
    fisher_const=4.0
    L=float(np.trapz(np.sqrt(fisher_const)*np.abs(dtheta),s))
    # Same curve traversed with physical duration 1 or 100.
    R.append(Result('Fisher/statistical arc length','distinguishability length','NO_PHYSICAL_RATE',
        {'arc_length':L,'same_path_physical_durations':[1.0,100.0]},
        'Fisher length measures distinguishability along a path; traversal speed and physical elapsed time remain free.'))

    # 7 oscillator phase: cycle count requires frequency calibration and unwrapping
    phi=13.7; candidates=[(phi+2*math.pi*k)/w for w in (1.0,10.0) for k in range(3)]
    R.append(Result('oscillator phase','clock representation','CALIBRATION_REQUIRED',
        {'observed_phase_mod_2pi':phi%(2*math.pi),'candidate_times':candidates},
        'Phase becomes a clock only after frequency calibration, orientation, and integer-cycle unwrapping.'))

    # 8 memory kernel: same equal-time decay with different two-time memory defect
    C01=C12=0.8; C02_markov=C01*C12; C02_memory=0.72
    T=lambda c:-math.log(c)
    defects=[T(C02_markov)-T(C01)-T(C12),T(C02_memory)-T(C01)-T(C12)]
    R.append(Result('memory / multitime process','composition and transport obstruction','NECESSARY_NOT_CLOCK',
        {'same_adjacent_coherences':[C01,C12],'C02':[C02_markov,C02_memory],'duration_defects':defects},
        'Memory data can distinguish histories that equal-time decay misses, but do not alone set a physical unit.'))

    # 9 affine clock atlas: closure leaves global positive scale
    tau=np.linspace(0,5,20); R1=3*tau+2; R2=0.4*R1-7
    beta,pred,rmse=fit_affine(R1,R2)
    R.append(Result('compatible clock atlas','common one-dimensional clock object','AFFINE_GAUGE',
        {'recovered_transition':beta.tolist(),'rmse':rmse},
        'Compatible clocks glue to one affine duration coordinate, but elapsed time retains one global positive scale.'))

    # 10 cone/conformal metric: conformal factor invisible to null cone
    eta=np.diag([-1.,1.,1.,1.]); Omega=7.3; gp=Omega**2*eta
    nulls=np.array([[1,1,0,0],[1,0,1,0],[1,0,0,1]],float)
    q1=np.einsum('ni,ij,nj->n',nulls,eta,nulls)
    q2=np.einsum('ni,ij,nj->n',nulls,gp,nulls)
    R.append(Result('causal cone / conformal class','null directions','CONFORMAL_ONLY',
        {'null_eta':q1.tolist(),'null_scaled_metric':q2.tolist(),'Omega':Omega},
        'The cone fixes null directions but not the conformal factor, so it cannot supply clock size.'))

    # 11 finite path proper times: rank attack for symmetric 1+1 metric (3 coeffs)
    V_under=np.array([[1,0],[1,1]],float)
    D_under=np.array([[v[0]**2,2*v[0]*v[1],v[1]**2] for v in V_under])
    V_full=np.array([[1,0],[0,1],[1,1],[1,-0.4]],float)
    D_full=np.array([[v[0]**2,2*v[0]*v[1],v[1]**2] for v in V_full])
    R.append(Result('multi-path quadratic durations','metric coefficient reconstruction','RANK_GATED',
        {'under_rank':rank(D_under),'unknowns':3,'full_rank':rank(D_full),'full_design_condition':float(np.linalg.cond(D_full))},
        'Path durations reconstruct local metric coefficients only with sufficient independent path rank, gauge control, and stable signature.'))

    # 12 physical lock positive synthetic bridge: common RG duration -> proper time by one scale,
    # held-out across clocks and paths. Then attack a false nonlinear clock.
    rng=np.random.default_rng(SEEDS[0]); n=80
    velocity=rng.uniform(-0.75,0.75,n)
    coord_dt=rng.uniform(0.02,0.20,n)
    tau_gr=coord_dt*np.sqrt(1-velocity**2) # c=1 Minkowski proper time
    unit=37.0
    T_rg=unit*tau_gr
    train=np.arange(n)%3!=0; test=~train
    beta,_,_=fit_affine(tau_gr[train],T_rg[train])
    pred=beta[0]*tau_gr[test]+beta[1]
    held_rmse=float(np.sqrt(np.mean((T_rg[test]-pred)**2)))
    # independent clock with affine calibration
    clock2=2.4*T_rg-5.0
    b2,p2,e2=fit_affine(T_rg[train],clock2[train])
    e2test=float(np.sqrt(np.mean((clock2[test]-(b2[0]*T_rg[test]+b2[1]))**2)))
    # false candidate agrees locally after affine fit but fails held-out due quadratic distortion
    false=T_rg+0.12*T_rg**2
    bf,_,_=fit_affine(tau_gr[train],false[train])
    false_test=float(np.sqrt(np.mean((false[test]-(bf[0]*tau_gr[test]+bf[1]))**2)))
    R.append(Result('joint RG-to-GR realization','physical proper-time representation','CONDITIONAL_LOCK',
        {'seed':SEEDS[0],'train_n':int(train.sum()),'heldout_n':int(test.sum()),'recovered_RG_per_GR_unit':beta.tolist(),'heldout_rmse_true':held_rmse,'cross_clock_heldout_rmse':e2test,'false_nonlinear_heldout_rmse':false_test},
        'A physical-time lock is operationally possible only as a held-out, cross-clock, multi-path affine identification with an independently identified Lorentzian proper-time model.'))

    # 13 QM-to-GR no automatic crossing: density operators carry no spacetime scale.
    # Identical qubit evolution indexed by dimensionless s can be assigned arbitrary seconds/unit.
    s=np.linspace(0,2*np.pi,100); pop=np.cos(s/2)**2
    sec_per_s=[1e-9,1.0,86400.0]
    R.append(Result('quantum state/process alone','dimensionless evolution law','NO_GR_BRIDGE',
        {'same_population_curve':True,'admissible_seconds_per_dimensionless_unit':sec_per_s},
        'A quantum trajectory or process parameter does not select Lorentzian metric scale, path geometry, or seconds. Those must enter through an external realization bridge.'))

    counts={}
    for x in R: counts[x.status]=counts.get(x.status,0)+1
    hard_lock=[x for x in R if x.object=='joint RG-to-GR realization'][0]
    report={
      'title':'RG physical-time lock attack',
      'seeds':SEEDS,
      'results':[asdict(x) for x in R],
      'status_counts':counts,
      'locked_architecture':{
        'pretime':'Exact event relation and quotient establish distinguishability/order, not duration size.',
        'duration_host':'On the admissible divisible semigroup stratum, T=-log C is the additive operator-duration host.',
        'memory_gate':'Multitime composition defects must vanish or be retained as cocycle/memory data before global duration is asserted.',
        'clock_object':'A compatible multi-clock atlas turns duration representations into one affine clock, still up to positive scale.',
        'geometry_gate':'Causal order supplies a conformal class; sufficiently rich path/source data, gauge, boundary conditions and signature stability identify an observable Lorentzian metric class.',
        'physical_lock':'One calibration constant plus held-out cross-clock and multi-path prediction identifies the affine RG clock with GR proper time on the tested class.',
        'no_reverse_arrow':'The validated representation does not imply primitive time, a unique latent ontology, or a QM-to-GR derivation.'
      },
      'verdict':'No single RG object contains physical time. Physical time is locked only by a composite bridge: order -> admissible composable process -> additive duration -> affine cross-clock object -> path-rich Lorentzian reconstruction -> one-unit calibration -> held-out validation. Synthetic code locks the logical necessity and exposes counterexamples; empirical data are required to lock nature.'
    }
    Path('/mnt/data/rg_physical_time_lock_results.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    md=['# RG physical-time lock attack','',f"Seeds: `{SEEDS}`",'',f"Candidate objects attacked: **{len(R)}**",'']
    for i,x in enumerate(R,1):
        md += [f"## {i}. {x.object} | {x.status}",f"**Role:** {x.role}",x.verdict,'','```json',json.dumps(x.witness,indent=2),'```','']
    md += ['## Locked architecture','']+[f"- **{k}:** {v}" for k,v in report['locked_architecture'].items()]
    md += ['','## Final verdict',report['verdict']]
    Path('/mnt/data/rg_physical_time_lock_report.md').write_text('\n'.join(md),encoding='utf-8')
    print(json.dumps({'objects':len(R),'status_counts':counts},indent=2))
    print('true bridge heldout RMSE',hard_lock.witness['heldout_rmse_true'])
    print('false nonlinear heldout RMSE',hard_lock.witness['false_nonlinear_heldout_rmse'])

if __name__=='__main__': main()
