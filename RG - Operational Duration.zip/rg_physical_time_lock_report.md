# RG physical-time lock attack

Seeds: `[20260825, 20260807, 314159]`

Candidate objects attacked: **13**

## 1. causal/preorder | NO_SCALE
**Role:** orientation and order
Order survives arbitrary monotone reparameterization, so it cannot fix elapsed-time scale or interval ratios.

```json
{
  "same_order": true,
  "non_affine_reparameterization": "f(t)=t^3+7t",
  "endpoint_duration_ratio": 16.0
}
```

## 2. raw wall-tap delay | COMPOSITE_ONLY
**Role:** composite latency
A measured 30 ms can host an ordered interval, but without controls it does not identify propagation, detector, source, or memory time.

```json
{
  "raw_seconds": 0.03,
  "decompositions": [
    [
      0.001,
      0.004,
      0.02,
      0.003,
      0.002
    ],
    [
      0.003,
      0.002,
      0.015,
      0.006,
      0.004
    ],
    [
      0.0005,
      0.0075,
      0.018,
      0.002,
      0.002
    ]
  ],
  "sums": [
    0.03,
    0.03,
    0.03
  ],
  "all_equal_raw": true
}
```

## 3. single decay C | UNIT_GAUGE
**Role:** dimensionless progress / semigroup coordinate
C determines T=-log C=lambda*t, but cannot separate physical time t from the rate/unit lambda.

```json
{
  "lambda": 2.3,
  "rescaled_lambda": 25.299999999999997,
  "time_rescale": 11.0,
  "max_curve_error": 1.1102230246251565e-16
}
```

## 4. multiscale decay family | COMMON_UNIT_GAUGE
**Role:** relative rate spectrum
Multiple decay channels identify rate ratios and shared progress, but retain one common positive scale gauge.

```json
{
  "rates": [
    0.7,
    1.9,
    4.2
  ],
  "rescaled_rates": [
    7.699999999999999,
    20.9,
    46.2
  ],
  "max_family_error": 1.1102230246251565e-16
}
```

## 5. entropy trajectory | NO_DURATION
**Role:** state functional / arrow candidate
Entropy values can order a restricted irreversible branch, but state entropy does not determine interval duration or calibration.

```json
{
  "entropy_start": 3.551116999690106e-14,
  "entropy_end": 0.6929794398668042,
  "alternative_labels_first_last": [
    0.0,
    20.0
  ]
}
```

## 6. Fisher/statistical arc length | NO_PHYSICAL_RATE
**Role:** distinguishability length
Fisher length measures distinguishability along a path; traversal speed and physical elapsed time remain free.

```json
{
  "arc_length": 2.0000002500000003,
  "same_path_physical_durations": [
    1.0,
    100.0
  ]
}
```

## 7. oscillator phase | CALIBRATION_REQUIRED
**Role:** clock representation
Phase becomes a clock only after frequency calibration, orientation, and integer-cycle unwrapping.

```json
{
  "observed_phase_mod_2pi": 1.1336293856408268,
  "candidate_times": [
    13.7,
    19.983185307179586,
    26.26637061435917,
    1.3699999999999999,
    1.9983185307179585,
    2.6266370614359174
  ]
}
```

## 8. memory / multitime process | NECESSARY_NOT_CLOCK
**Role:** composition and transport obstruction
Memory data can distinguish histories that equal-time decay misses, but do not alone set a physical unit.

```json
{
  "same_adjacent_coherences": [
    0.8,
    0.8
  ],
  "C02": [
    0.6400000000000001,
    0.72
  ],
  "duration_defects": [
    -1.1102230246251565e-16,
    -0.11778303565638332
  ]
}
```

## 9. compatible clock atlas | AFFINE_GAUGE
**Role:** common one-dimensional clock object
Compatible clocks glue to one affine duration coordinate, but elapsed time retains one global positive scale.

```json
{
  "recovered_transition": [
    0.4000000000000002,
    -7.000000000000003
  ],
  "rmse": 1.1339095338133984e-15
}
```

## 10. causal cone / conformal class | CONFORMAL_ONLY
**Role:** null directions
The cone fixes null directions but not the conformal factor, so it cannot supply clock size.

```json
{
  "null_eta": [
    0.0,
    0.0,
    0.0
  ],
  "null_scaled_metric": [
    0.0,
    0.0,
    0.0
  ],
  "Omega": 7.3
}
```

## 11. multi-path quadratic durations | RANK_GATED
**Role:** metric coefficient reconstruction
Path durations reconstruct local metric coefficients only with sufficient independent path rank, gauge control, and stable signature.

```json
{
  "under_rank": 2,
  "unknowns": 3,
  "full_rank": 3,
  "full_design_condition": 2.6558773477038207
}
```

## 12. joint RG-to-GR realization | CONDITIONAL_LOCK
**Role:** physical proper-time representation
A physical-time lock is operationally possible only as a held-out, cross-clock, multi-path affine identification with an independently identified Lorentzian proper-time model.

```json
{
  "seed": 20260825,
  "train_n": 53,
  "heldout_n": 27,
  "recovered_RG_per_GR_unit": [
    37.00000000000002,
    2.2276158614381168e-15
  ],
  "heldout_rmse_true": 4.745809653876141e-15,
  "cross_clock_heldout_rmse": 2.2384654568881807e-15,
  "false_nonlinear_heldout_rmse": 0.3423635336668615
}
```

## 13. quantum state/process alone | NO_GR_BRIDGE
**Role:** dimensionless evolution law
A quantum trajectory or process parameter does not select Lorentzian metric scale, path geometry, or seconds. Those must enter through an external realization bridge.

```json
{
  "same_population_curve": true,
  "admissible_seconds_per_dimensionless_unit": [
    1e-09,
    1.0,
    86400.0
  ]
}
```

## Locked architecture

- **pretime:** Exact event relation and quotient establish distinguishability/order, not duration size.
- **duration_host:** On the admissible divisible semigroup stratum, T=-log C is the additive operator-duration host.
- **memory_gate:** Multitime composition defects must vanish or be retained as cocycle/memory data before global duration is asserted.
- **clock_object:** A compatible multi-clock atlas turns duration representations into one affine clock, still up to positive scale.
- **geometry_gate:** Causal order supplies a conformal class; sufficiently rich path/source data, gauge, boundary conditions and signature stability identify an observable Lorentzian metric class.
- **physical_lock:** One calibration constant plus held-out cross-clock and multi-path prediction identifies the affine RG clock with GR proper time on the tested class.
- **no_reverse_arrow:** The validated representation does not imply primitive time, a unique latent ontology, or a QM-to-GR derivation.

## Final verdict
No single RG object contains physical time. Physical time is locked only by a composite bridge: order -> admissible composable process -> additive duration -> affine cross-clock object -> path-rich Lorentzian reconstruction -> one-unit calibration -> held-out validation. Synthetic code locks the logical necessity and exposes counterexamples; empirical data are required to lock nature.