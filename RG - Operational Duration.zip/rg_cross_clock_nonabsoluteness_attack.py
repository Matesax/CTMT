#!/usr/bin/env python3
"""Hostile attack on the proposed Cross-Clock Path-Dependence theorem.

The attack separates:
A. cross-clock calibration closure,
B. falsification of the *restricted* path-independent clock-law null,
C. failure to falsify every universal-coordinate theory,
D. conditional held-out proper-time realization.

No external empirical data are simulated as evidence. Synthetic data provide logical
counterexamples and implementation tests only.
"""
from __future__ import annotations
import json
from dataclasses import dataclass, asdict
from pathlib import Path
import numpy as np

SEED=20260920
RNG=np.random.default_rng(SEED)

@dataclass
class Attack:
    name:str
    status:str
    evidence:dict
    consequence:str


def affine_fit(x,y):
    X=np.c_[x,np.ones(len(x))]
    b=np.linalg.lstsq(X,y,rcond=None)[0]
    return b, X@b


def rmse(a,b): return float(np.sqrt(np.mean((np.asarray(a)-np.asarray(b))**2)))


def main():
    A=[]
    # Path ensemble with an independently specified Lorentzian benchmark for model testing.
    n=360
    dt=RNG.uniform(.2,2.0,n)
    v=RNG.uniform(-.82,.82,n)
    potential=RNG.uniform(-3e-3,3e-3,n)
    # Weak-field plus SR benchmark, used only as synthetic competitor data generator.
    tau=dt*np.sqrt(1-v*v)*(1+potential)
    split=np.arange(n)%4 != 0
    test=~split

    # Three independent clock families, different units/origins, small independent noise.
    latent=41.0*tau
    params={'A':(1.0,0.0,8e-4),'B':(2.7,-4.0,1.2e-3),'C':(.43,9.0,1.0e-3)}
    clocks={k:a*latent+b+RNG.normal(0,s,n) for k,(a,b,s) in params.items()}

    # 1. Pairwise held-out affine calibration.
    pair={}
    for src,dst in [('A','B'),('A','C'),('B','C')]:
        beta,_=affine_fit(clocks[src][split],clocks[dst][split])
        pred=beta[0]*clocks[src][test]+beta[1]
        pair[src+'->'+dst]={'beta':beta.tolist(),'heldout_rmse':rmse(pred,clocks[dst][test])}
    A.append(Attack('three_clock_heldout_affine_closure','SURVIVES',pair,
      'Three clock families can define charts of one affine operational-duration object without fitting GR.'))

    # 2. Cocycle closure is an independent anti-circularity gate.
    bBA,_=affine_fit(clocks['A'][split],clocks['B'][split])
    bCB,_=affine_fit(clocks['B'][split],clocks['C'][split])
    bCA,_=affine_fit(clocks['A'][split],clocks['C'][split])
    composed=np.array([bCB[0]*bBA[0], bCB[0]*bBA[1]+bCB[1]])
    cocycle_error=float(np.linalg.norm(composed-bCA))
    A.append(Attack('affine_cocycle_closure','SURVIVES',
      {'direct_A_to_C':bCA.tolist(),'composed_A_to_B_to_C':composed.tolist(),'parameter_error':cocycle_error},
      'Pairwise agreement is insufficient; the three-clock transition graph must close on cycles.'))

    # 3. Identical reunited clocks falsify only path-independent identical-clock accumulation.
    # Paired paths share coordinate dt but differ in v/potential.
    m=120
    dtp=RNG.uniform(.5,1.5,m)
    v1=RNG.uniform(-.1,.1,m); v2=RNG.uniform(.45,.8,m)
    u1=RNG.uniform(-3e-3,-1e-3,m); u2=RNG.uniform(1e-3,3e-3,m)
    tau1=dtp*np.sqrt(1-v1*v1)*(1+u1)
    tau2=dtp*np.sqrt(1-v2*v2)*(1+u2)
    diff=41*(tau1-tau2)+RNG.normal(0,1e-3,m)
    z=float(abs(np.mean(diff))/(np.std(diff,ddof=1)/np.sqrt(m)))
    A.append(Attack('restricted_absolute_clock_null','FALSIFIED_IN_SYNTHETIC_WITNESS',
      {'mean_identical_clock_difference':float(np.mean(diff)),'standard_error':float(np.std(diff,ddof=1)/np.sqrt(m)),'z_score':z},
      'This rejects the restricted null that identically prepared ideal clocks accumulate the same duration for equal coordinate intervals independently of path.'))

    # 4. Decisive counterattack: a universal coordinate t can coexist with path-dependent rates.
    # dT_i/dt = r(v,U), so different readings do not logically disprove existence of t.
    rate1=np.sqrt(1-v1*v1)*(1+u1); rate2=np.sqrt(1-v2*v2)*(1+u2)
    reconstructed1=41*dtp*rate1; reconstructed2=41*dtp*rate2
    err=float(max(np.max(abs(reconstructed1-41*tau1)),np.max(abs(reconstructed2-41*tau2))))
    A.append(Attack('universal_coordinate_loophole','BREAKS_STRONG_THEOREM',
      {'common_coordinate_intervals':True,'path_dependent_rate_law':'dT/dt = 41 sqrt(1-v^2)(1+U)','max_reconstruction_error':err},
      'Unequal clock readings do not by themselves prove that no universal scalar coordinate exists. They disprove only a universal path-independent clock law or an operationally privileged absolute duration.'))

    # 5. Species/path interaction attack: environmental sensitivities can mimic path dependence.
    # Add species-dependent path sensitivity; one affine calibration no longer transfers.
    sens={'A':0.0,'B':.35,'C':-.22}
    contaminated={k:clocks[k]+sens[k]*v*v for k in clocks}
    interaction={}
    for src,dst in [('A','B'),('A','C')]:
        beta,_=affine_fit(contaminated[src][split],contaminated[dst][split])
        resid=contaminated[dst][test]-(beta[0]*contaminated[src][test]+beta[1])
        corr=float(np.corrcoef(resid,v[test]**2)[0,1])
        interaction[src+'->'+dst]={'heldout_rmse':float(np.sqrt(np.mean(resid**2))),'residual_corr_v2':corr}
    A.append(Attack('species_by_path_systematic','GATE_REQUIRED',interaction,
      'Cross-clock agreement must be tested for species-by-path interactions; otherwise environmental or device sensitivity can imitate non-universal duration.'))

    # 6. GR competitor fit follows falsification and is frozen before held-out testing.
    beta,_=affine_fit(tau[split],clocks['A'][split])
    gr_pred=beta[0]*tau[test]+beta[1]
    gr_rmse=rmse(gr_pred,clocks['A'][test])
    # Absolute equal-coordinate-duration competitor ignores v,U.
    beta_abs,_=affine_fit(dt[split],clocks['A'][split])
    abs_pred=beta_abs[0]*dt[test]+beta_abs[1]
    abs_rmse=rmse(abs_pred,clocks['A'][test])
    # Flexible path model can also fit, proving GR is not selected without competitor restrictions.
    X=np.c_[dt[split],dt[split]*v[split]**2,dt[split]*potential[split],np.ones(split.sum())]
    coef=np.linalg.lstsq(X,clocks['A'][split],rcond=None)[0]
    Xtest=np.c_[dt[test],dt[test]*v[test]**2,dt[test]*potential[test],np.ones(test.sum())]
    flex_rmse=rmse(Xtest@coef,clocks['A'][test])
    A.append(Attack('heldout_model_comparison','CONDITIONAL_GR_REALIZATION',
      {'GR_benchmark_rmse':gr_rmse,'path_independent_absolute_rmse':abs_rmse,'non_GR_flexible_path_model_rmse':flex_rmse,'frozen_GR_affine_map':beta.tolist()},
      'Held-out superiority over a path-independent null supports path dependence. Proper-time realization additionally requires a declared Lorentzian competitor class and comparison against alternative path laws.'))

    # 7. Orientation and synchronization attacks.
    reversed_tau=-tau
    unsigned_same=bool(np.allclose(abs(reversed_tau),abs(tau)))
    sync_offsets=RNG.normal(0,.02,m)
    apparent=diff+sync_offsets
    A.append(Attack('orientation_and_synchronization','GATE_REQUIRED',
      {'unsigned_duration_invariant_under_reversal':unsigned_same,'sync_offset_sd':float(np.std(sync_offsets)),'apparent_difference_shift':float(np.mean(apparent)-np.mean(diff))},
      'Unsigned elapsed duration does not determine time orientation, and reunion differences require explicit synchronization and transport-offset controls.'))

    # 8. Affine-gauge invariant observable.
    # Difference ratios remove offset but retain positive common scale; sign invariant for a>0.
    d1=clocks['A'][test][:30]-clocks['A'][test][30:60]
    transformed=7.2*clocks['A']-31
    d2=transformed[test][:30]-transformed[test][30:60]
    ratio_err=float(np.max(abs(d2/(7.2*d1)-1)))
    A.append(Attack('affine_gauge_invariant_contrast','SURVIVES',
      {'normalized_difference_error':ratio_err,'sign_preserved':bool(np.all(np.sign(d1)==np.sign(d2)))},
      'Elapsed differences and dimensionless ratios can state path dependence without choosing an origin; absolute magnitude still needs one unit calibration.'))

    summary={x.name:x.status for x in A}
    locked={
      'K0':'Each clock supplies phase or count data and a locally declared operational duration. This is not yet GR proper time.',
      'K1':'At least three independent clock families are trained only on a co-located calibration domain.',
      'K2':'Frozen positive-affine transition maps predict held-out clocks and satisfy cycle/cocycle closure.',
      'K3':'Identical clocks are separated and reunited across preregistered path ensembles with complete nuisance and synchronization controls.',
      'K4':'The restricted path-independent ideal-clock null is rejected using affine-gauge-invariant elapsed contrasts.',
      'K5':'Species-by-path interactions are absent within uncertainty, establishing a shared path-dependent operational duration rather than device-specific drift.',
      'K6':'Only after K4-K5, Lorentzian proper time and explicit alternative path laws are fitted on training paths and frozen.',
      'K7':'A proper-time realization is supported only when one affine calibration predicts all held-out species and paths better than preregistered competitors.',
      'nonclaim':'The result does not prove nonexistence of every global scalar coordinate. It proves failure of path-independent universal clock accumulation and, conditionally, realizes the shared duration by Lorentzian proper time.'
    }
    theorem=(
      'On a tested domain, suppose three or more independent clock families define a held-out, cocycle-consistent affine clock; '
      'identically prepared clocks separated along distinct controlled histories exhibit reproducible affine-gauge-invariant elapsed differences; '
      'species-by-path interactions and synchronization/systematic explanations are excluded within the declared uncertainty model; and one frozen Lorentzian proper-time functional with one global affine calibration predicts all held-out clocks and paths against declared alternatives. '
      'Then the experiment rejects path-independent universal clock accumulation on that domain and supports Lorentzian proper time as an empirical representation of the common operational duration. '
      'It does not exclude the mathematical existence of an auxiliary global coordinate with path-dependent clock-rate laws.'
    )
    report={'title':'Cross-Clock Path-Dependence hostile attack','seed':SEED,'attacks':[asdict(x) for x in A],
            'summary':summary,'locked_ladder':locked,'locked_theorem':theorem,
            'paper_status':'LOCKABLE_AFTER_NARROWING'}
    Path('/mnt/data/rg_cross_clock_nonabsoluteness_results.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    md=['# Cross-Clock Path-Dependence: hostile attack','',f'Seed: `{SEED}`','',f'**Paper status: {report["paper_status"]}**','']
    for i,x in enumerate(A,1):
        md += [f'## {i}. {x.name}: {x.status}',x.consequence,'','```json',json.dumps(x.evidence,indent=2),'```','']
    md += ['## Locked K0-K7 ladder','']+[f'- **{k}:** {v}' for k,v in locked.items()]
    md += ['','## Locked theorem',theorem]
    Path('/mnt/data/rg_cross_clock_nonabsoluteness_report.md').write_text('\n'.join(md),encoding='utf-8')
    print(json.dumps({'paper_status':report['paper_status'],'attacks':summary},indent=2))

if __name__=='__main__': main()
