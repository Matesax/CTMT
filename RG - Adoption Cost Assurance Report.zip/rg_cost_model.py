"""
rg_cost_model.py -- three-point, correlated Monte Carlo cost estimate for an RG adoption package.

What it does (and why, with the battery test that motivates each step):
  * three-point (low / most likely / high) estimates per work item, triangular   [GAO-20-195G]
  * Gaussian-copula correlation within and between groups of items              [T18]
  * reports P10 / P50 / P80 / P90 and the probability that the sum of
    most-likely values is met (usually close to zero)                           [T18]
  * optional optimism-bias uplift on the base estimate, starting from the
    HM Treasury upper bound for equipment/development and reduced only by a
    documented mitigation fraction (use as a ceiling check, not on top of a
    Monte Carlo that already models the same risks)                             [Green Book]
  * compares the simulated range with the AACE class band declared by the user
    and warns if the simulated range is tighter than the benchmark              [AACE 18R-97]
  * break-even number of avoided events as a distribution, not C / mean(v)      [T17]

Usage:
    python rg_cost_model.py inputs/example_pilot_inputs.json  [--out results/cost_summary.md]

All numbers in the example input are ILLUSTRATIVE placeholders. Replace them with local data.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from scipy import stats

AACE_BANDS = {  # typical expected accuracy ranges, AACE RP 18R-97 (process industries), low/high %
    5: ((-50, -20), (30, 100)),
    4: ((-30, -15), (20, 50)),
    3: ((-20, -10), (10, 30)),
    2: ((-15, -5), (5, 20)),
    1: ((-10, -3), (3, 15)),
}


def correlated_uniforms(n, groups, rho_in, rho_between, rng):
    labels = sorted(set(groups))
    g_index = {g: i for i, g in enumerate(labels)}
    k = len(groups)
    C = np.full((k, k), rho_between)
    for i in range(k):
        for j in range(k):
            if groups[i] == groups[j]:
                C[i, j] = rho_in
    np.fill_diagonal(C, 1.0)
    w, V = np.linalg.eigh(C)
    if w.min() < 0:
        raise ValueError("correlation settings are not a valid correlation matrix")
    Z = rng.standard_normal((n, k)) @ (V * np.sqrt(w)).T
    return stats.norm.cdf(Z)


def run(cfg: dict) -> dict:
    rng = np.random.default_rng(cfg.get("seed", 20261021))
    n = int(cfg.get("n_draws", 200_000))
    items = cfg["components"]
    lo = np.array([c["low"] for c in items], float)
    mo = np.array([c["mode"] for c in items], float)
    hi = np.array([c["high"] for c in items], float)
    if np.any(lo > mo) or np.any(mo > hi) or np.any(hi <= lo):
        raise ValueError("each component needs low <= mode <= high and high > low")
    U = correlated_uniforms(n, [c.get("group", "default") for c in items],
                            cfg.get("correlation_within_group", 0.6),
                            cfg.get("correlation_between_groups", 0.2), rng)
    shape = (mo - lo) / (hi - lo)
    draws = stats.triang.ppf(U, shape, loc=lo, scale=hi - lo)
    total = draws.sum(1)
    rate = float(cfg.get("rate_per_unit", 1.0))
    total_money = total * rate
    sum_modes = float(mo.sum())
    q = lambda p: float(np.quantile(total, p))
    out = {
        "unit": cfg.get("unit", "person-days"),
        "sum_of_most_likely": sum_modes,
        "mean": float(total.mean()),
        "P10": q(0.10), "P50": q(0.50), "P80": q(0.80), "P90": q(0.90),
        "prob_sum_of_most_likely_is_met": float(np.mean(total <= sum_modes)),
    }
    if rate != 1.0:
        out["money"] = {"currency": cfg.get("currency", ""), "P50": float(np.quantile(total_money, 0.5)),
                        "P80": float(np.quantile(total_money, 0.8))}
    ob = cfg.get("optimism_bias")
    if ob:
        up = float(ob.get("upper_bound_pct", 200.0))
        mit = float(ob.get("mitigation_fraction", 0.0))
        applied = up * (1.0 - mit)
        out["optimism_bias"] = {"upper_bound_pct": up, "mitigation_fraction": mit,
                                "applied_pct": applied,
                                "base_times_uplift": sum_modes * (1 + applied / 100.0),
                                "note": "ceiling check on the base estimate; do not stack on the Monte Carlo"}
    cls = cfg.get("aace_class")
    if cls in AACE_BANDS:
        (l1, l2), (h1, h2) = AACE_BANDS[cls]
        point = out["P50"]
        sim_low = 100 * (out["P10"] / point - 1)
        sim_high = 100 * (out["P90"] / point - 1)
        out["aace"] = {"class": cls, "benchmark_low_pct": [l1, l2], "benchmark_high_pct": [h1, h2],
                       "simulated_low_pct_P10": sim_low, "simulated_high_pct_P90": sim_high,
                       "warning": (sim_high < h1 or sim_low > l2)}
    ben = cfg.get("benefit_per_event")
    if ben:
        v = float(ben["median"]) * np.exp(float(ben["log_sd"]) * rng.standard_normal(n))
        events = total / v
        out["break_even_events"] = {
            "naive_C_over_mean_v": float(total.mean() / v.mean()),
            "P50": float(np.median(events)), "P80": float(np.quantile(events, 0.8)),
            "prob_more_than_naive": float(np.mean(events > total.mean() / v.mean())),
        }
    return out


def to_markdown(cfg, res):
    u = res["unit"]
    lines = [f"# Cost estimate summary: {cfg.get('title', 'RG adoption package')}", ""]
    if cfg.get("illustrative", False):
        lines += ["**ILLUSTRATIVE INPUTS -- NOT AN ESTIMATE.** Replace every number with local data.", ""]
    lines += [f"- Sum of most-likely values: {res['sum_of_most_likely']:.1f} {u} "
              f"(met with probability {res['prob_sum_of_most_likely_is_met']:.3f})",
              f"- P10 / P50 / P80 / P90: {res['P10']:.1f} / {res['P50']:.1f} / {res['P80']:.1f} / {res['P90']:.1f} {u}",
              f"- Mean: {res['mean']:.1f} {u}"]
    if "optimism_bias" in res:
        ob = res["optimism_bias"]
        lines.append(f"- Optimism-bias ceiling check: base x (1 + {ob['applied_pct']:.0f}%) = "
                     f"{ob['base_times_uplift']:.1f} {u} ({ob['note']})")
    if "aace" in res:
        a = res["aace"]
        lines.append(f"- AACE class {a['class']}: simulated P10/P90 around P50 = {a['simulated_low_pct_P10']:.0f}% / "
                     f"+{a['simulated_high_pct_P90']:.0f}%; benchmark low {a['benchmark_low_pct']}%, "
                     f"high {a['benchmark_high_pct']}%" + ("  **WARNING: simulated range tighter than benchmark -- justify or widen.**" if a['warning'] else ""))
    if "break_even_events" in res:
        b = res["break_even_events"]
        lines.append(f"- Break-even avoided events: naive {b['naive_C_over_mean_v']:.2f}; P50 {b['P50']:.2f}; "
                     f"P80 {b['P80']:.2f}; probability that more than the naive number is needed {b['prob_more_than_naive']:.2f}")
    return "\n".join(lines) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    cfg = json.loads(Path(a.input).read_text(encoding="utf-8"))
    res = run(cfg)
    md = to_markdown(cfg, res)
    print(md)
    if a.out:
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text(md, encoding="utf-8")
        Path(a.out).with_suffix(".json").write_text(json.dumps(res, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
