"""
rg_attacks.py -- hostile adversarial battery for the RG Adoption Cost Assurance Report.

Every function attacks one claim that the report relies on.  The rule of the battery:

  * The claim AS DRAFTED is attacked first.  If a counterexample exists, the battery must
    find it (otherwise the attack has no teeth and the test FAILS).
  * The claim AS SHARPENED in the report is then checked on the same seed.  It must hold.
  * Verdicts:  HOLDS      -- an identity/floor: no counterexample can exist; verified numerically
               CONFIRMED  -- the draft claim survived; the battery exhibits and quantifies the
                             counterexample to the practice the claim warns against
               SHARPENED  -- the draft claim was too broad, incomplete or missing; an explicit
                             counterexample forced the corrected claim used in the report
               FAILED     -- the corrected claim itself failed: the report is wrong

Nothing here proves a theorem.  Batteries test implementations, assumptions and the
boundaries of claims; theorem status comes from the corpus proofs (RG - Corpus.md, item 8).

Dependencies: numpy, scipy, mpmath.  Deterministic given the seed.
"""
from __future__ import annotations

import itertools
import math
import time

import mpmath as mp
import numpy as np
from scipy import stats
from scipy.optimize import minimize_scalar

# --------------------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------------------

# Draft claims that survived: the battery confirms them and quantifies the counterexample
# against the practice they warn about.  All other teeth-bearing tests corrected the draft.
DRAFT_HOLDS = {"T01", "T03", "T07", "T12", "T19", "T20", "T21", "T22", "T23"}


def _result(tid, title, rung, corpus, draft, attack, sharpened, checks, metrics,
            counterexample=None, teeth=None):
    """Assemble a uniform result record.

    teeth: name of the check that proves the attack found a counterexample to the draft
           claim (None if the draft claim is expected to HOLD).
    """
    passed = all(bool(v) for v in checks.values())
    if not passed:
        verdict = "FAILED"
    elif teeth is not None:
        verdict = "CONFIRMED" if tid in DRAFT_HOLDS else "SHARPENED"
    else:
        verdict = "HOLDS"
    return {
        "id": tid, "title": title, "ladder_rung": rung, "corpus": corpus,
        "draft_claim": draft, "attack": attack, "counterexample": counterexample,
        "sharpened_claim": sharpened, "verdict": verdict, "passed": passed,
        "checks": {k: bool(v) for k, v in checks.items()},
        "metrics": {k: (float(v) if isinstance(v, (int, float, np.floating, np.integer)) else v)
                    for k, v in metrics.items()},
    }


def efficient_info(F, target_idx):
    """Efficient (nuisance-profiled) Fisher information for one target coordinate.

    Schur complement F_tt - F_tn F_nn^+ F_nt.  Valid for PSD F (F_nt lies in range(F_nn)).
    """
    F = np.asarray(F, float)
    n = F.shape[0]
    t = target_idx
    rest = [i for i in range(n) if i != t]
    if not rest:
        return float(F[t, t])
    Fnn = F[np.ix_(rest, rest)]
    Fnt = F[np.ix_(rest, [t])]
    return float(F[t, t] - (Fnt.T @ np.linalg.pinv(Fnn, rcond=1e-13) @ Fnt)[0, 0])


def identifiable(J, target_idx, tol=1e-10):
    """Local structural identifiability of one coordinate: e_t in row space of J."""
    J = np.atleast_2d(np.asarray(J, float))
    e = np.zeros((1, J.shape[1])); e[0, target_idx] = 1.0
    r1 = np.linalg.matrix_rank(J, tol=tol)
    r2 = np.linalg.matrix_rank(np.vstack([J, e]), tol=tol)
    return r1 == r2


# --------------------------------------------------------------------------------------
# T01  product ambiguity, repetition, silent nuisance, polarimetry
# --------------------------------------------------------------------------------------

def t01_product_ambiguity(seed):
    rng = np.random.default_rng(seed)
    g, r, sigma = 1.3, 0.7, 0.05
    a = np.array([r, g])                       # d(gr)/d(g, r)
    rows = {}
    ranks, eff_fracs = [], []
    for N in (10, 1_000, 100_000):
        F = N / sigma**2 * np.outer(a, a)
        ev = np.linalg.eigvalsh(F)
        ranks.append(int(np.sum(ev > 1e-9 * ev.max())))
        eff_fracs.append(efficient_info(F, 1) / F[1, 1])
    # independent gain reference: M readings z ~ N(g, sg^2)
    N, M, sg = 1_000, 1_000, 0.04
    Fref = N / sigma**2 * np.outer(a, a) + M / sg**2 * np.outer([1, 0], [1, 0])
    ref_frac = efficient_info(Fref, 1) / Fref[1, 1]

    # silent gain: analyst fixes g at a value 1% too high
    g_assumed = 1.01 * g
    cover_r, width_r, cover_p = {}, {}, {}
    for N in (10, 100, 1_000, 10_000):
        ybar = g * r + sigma / math.sqrt(N) * rng.standard_normal(4000)
        r_hat = ybar / g_assumed
        se_r = sigma / (math.sqrt(N) * g_assumed)
        cover_r[N] = np.mean(np.abs(r_hat - r) <= 1.96 * se_r)
        width_r[N] = 2 * 1.96 * se_r
        se_p = sigma / math.sqrt(N)
        cover_p[N] = np.mean(np.abs(ybar - g * r) <= 1.96 * se_p)

    # dispatcher canary: a certifier that silently fixes g uses F_rr, not efficient info
    target_sd = 0.01
    F = 1_000 / sigma**2 * np.outer(a, a)
    silent_sd = 1 / math.sqrt(F[1, 1])
    eff = efficient_info(F, 1)
    honest_sd = math.inf if eff <= 1e-12 * F[1, 1] else 1 / math.sqrt(eff)
    silent_status = "LOCKED" if silent_sd <= target_sd else "STRUCTURAL WALL"
    honest_status = "LOCKED" if honest_sd <= target_sd else "CORRESPONDENCE"

    # polarimetry alpha = k L c (RG - Admissible Observable Sectors in Optical Measurement Systems)
    k, L, c = 66.5, 1.0, 0.12
    Jp = np.array([[L * c, k * c, k * L]])
    null_dim = 3 - np.linalg.matrix_rank(Jp)
    Jp_ctrl = np.vstack([Jp, [1, 0, 0], [0, 1, 0]])       # calibrated k, measured L
    ctrl_ok = identifiable(Jp_ctrl, 2)

    checks = {
        "rank_one_at_every_N": all(x == 1 for x in ranks),
        "efficient_info_on_r_zero_at_every_N": all(f < 1e-10 for f in eff_fracs),
        "independent_gain_reference_restores_r": ref_frac > 0.3,
        "teeth_silent_gain_coverage_collapses": cover_r[10] > 0.8 and cover_r[10_000] < 0.05 and width_r[10_000] < width_r[10],
        "product_gr_is_honestly_reported": all(0.93 <= v <= 0.97 for v in cover_p.values()),
        "teeth_silent_certifier_false_lock": silent_status == "LOCKED",
        "honest_certifier_refuses_lock": honest_status != "LOCKED",
        "polarimetry_two_dim_null": null_dim == 2,
        "polarimetry_controls_restore_c": ctrl_ok,
    }
    metrics = {"efficient_fraction_r_no_reference": max(eff_fracs),
               "efficient_fraction_r_with_reference": ref_frac,
               "coverage_r_silent_gain_N10": cover_r[10], "coverage_r_silent_gain_N100": cover_r[100],
               "coverage_r_silent_gain_N10000": cover_r[10_000],
               "ci_width_r_N10": width_r[10], "ci_width_r_N10000": width_r[10_000],
               "coverage_product_N10000": cover_p[10_000],
               "silent_certifier_status": silent_status, "honest_certifier_status": honest_status,
               "polarimetry_null_dim": int(null_dim)}
    return _result(
        "T01", "Product ambiguity: repeats, silent nuisance, independent reference",
        "R1-R2 forced; R12-R13 gated (sensor wall)",
        ["RG - Wall-Tap Delay - Global.pdf (WT08, WT16)",
         "RG - Admissible Observable Sectors in Optical Measurement Systems.pdf"],
        "More repeats do not resolve an exact product ambiguity; an independent reference restores it.",
        "Increase N by 10^4; fix the nuisance silently; certify with the non-efficient metric.",
        "For y = g r, information on r after accounting for g is exactly zero at every N; only an "
        "independent gain reference opens it. Silently fixing g gives intervals that shrink while "
        "coverage falls to zero, and a certifier using the non-efficient metric falsely LOCKS. "
        "Report g r (identified) or a set for r; never a point r without the reference.",
        checks, metrics,
        counterexample=f"Gain fixed 1% off: the 95% interval for r covers the truth {cover_r[10]:.2f} of the "
                       f"time at N=10, {cover_r[100]:.2f} at N=100 and {cover_r[10_000]:.3f} at N=10000, "
                       f"while its width fell {width_r[10]/width_r[10_000]:.0f}x.",
        teeth="teeth_silent_gain_coverage_collapses")


# --------------------------------------------------------------------------------------
# T02  three kinds of null: structural, precision, representation
# --------------------------------------------------------------------------------------

def t02_null_trichotomy(seed):
    rng = np.random.default_rng(seed)
    mp.mp.dps = 60
    # random orthogonal frame in high precision
    A = mp.matrix(3, 3)
    for i in range(3):
        for j in range(3):
            A[i, j] = mp.mpf(rng.standard_normal())
    Q, _ = mp.qr(A)
    D = mp.diag([mp.mpf(1), mp.mpf("1e-20"), mp.mpf(0)])
    Fm = Q * D * Q.T
    F64 = np.array([[float(Fm[i, j]) for j in range(3)] for i in range(3)])
    ev64 = np.sort(np.abs(np.linalg.eigvalsh(F64)))
    evmp, _ = mp.eigsy(Fm)
    evmp = sorted([abs(x) for x in evmp])
    float64_cannot_separate = ev64[0] < 1e-12 and ev64[1] < 1e-12
    mp_separates = abs(evmp[1] / mp.mpf("1e-20") - 1) < 1e-6 and evmp[0] < mp.mpf("1e-45")

    # repeats: CRB of a precision-null direction falls 1/N; structural stays infinite
    lam = 1e-20
    crb_ratio = (1 / (1e3 * lam)) / (1 / (1e4 * lam))
    structural_crb = [math.inf for _ in (1e3, 1e4)]

    # representation null: quadratic signal invisible to a linear model
    x = rng.uniform(-1, 1, 2000)
    y = x**2 + 0.01 * rng.standard_normal(2000)
    X1 = np.column_stack([np.ones_like(x), x])
    X2 = np.column_stack([np.ones_like(x), x, x**2])
    def r2(X):
        beta, *_ = np.linalg.lstsq(X, y, rcond=None)
        res = y - X @ beta
        return 1 - res.var() / y.var()
    r2_lin, r2_quad = r2(X1), r2(X2)

    # structural null is invariant under every downstream construction of the data
    def simulate(t1, t2, s):
        rr = np.random.default_rng(s)
        return np.tanh(t1 + t2) + 0.1 * rr.standard_normal(500)
    d1, d2 = simulate(0.2, 0.5, seed), simulate(0.6, 0.1, seed)
    feats = [lambda v: v, np.sin, lambda v: v**3, lambda v: np.sort(v)]
    max_feature_gap = max(float(np.max(np.abs(f(d1) - f(d2)))) for f in feats)

    checks = {
        "teeth_float64_reads_precision_null_as_zero": float64_cannot_separate,
        "high_precision_separates_precision_from_structural": mp_separates,
        "teeth_repeats_help_precision_null_10x": abs(crb_ratio - 10) < 1e-9,
        "repeats_never_help_structural_null": all(math.isinf(v) for v in structural_crb),
        "teeth_linear_model_misses_quadratic": r2_lin < 0.05,
        "richer_model_recovers_it": r2_quad > 0.99,
        "structural_null_invariant_under_features": max_feature_gap < 1e-12,
    }
    metrics = {"float64_two_smallest_eigs": f"{ev64[0]:.2e}, {ev64[1]:.2e}",
               "mp60_two_smallest_eigs": f"{mp.nstr(evmp[0],3)}, {mp.nstr(evmp[1],6)}",
               "crb_ratio_N1e3_over_N1e4": crb_ratio, "R2_linear": r2_lin, "R2_quadratic": r2_quad,
               "structural_feature_gap": max_feature_gap}
    return _result(
        "T02", "Null trichotomy: when more data helps and when it cannot",
        "R12-R13 forced typing; R11 gated",
        ["RG - Null Resolution Depth.pdf", "RG - Observation Limit.pdf"],
        "Buy the missing task-relevant information, not more measurements.",
        "Find nulls where repeats DO help, where a better model helps, and where nothing helps.",
        "Classify every null before spending: structural (no data, precision or model removes it -> new "
        "sensor/reference or set-valued answer), precision-limited (more data or arithmetic removes it, "
        "CRB falls as 1/N), representation-limited (a richer model removes it with no new data).",
        checks, metrics,
        counterexample=f"Precision null: CRB falls exactly {crb_ratio:.0f}x for 10x repeats, so "
                       "'more measurements do not help' is false there; a linear model reads a "
                       f"quadratic signal as null (R2 {r2_lin:.3f}) that a quadratic model recovers "
                       f"(R2 {r2_quad:.4f}).",
        teeth="teeth_repeats_help_precision_null_10x")


# --------------------------------------------------------------------------------------
# T03  local full rank does not give global identification (fold)
# --------------------------------------------------------------------------------------

def t03_fold(seed):
    rng = np.random.default_rng(seed)
    d, s, n = 0.28, 0.01, 200
    h = lambda b: (b - d) ** 2
    bs = rng.uniform(0, 1, 100_000)
    partner = 2 * d - bs
    frac_partner = float(np.mean((partner >= 0) & (partner <= 1) & (np.abs(bs - d) > 1e-9)))
    bpts = rng.uniform(0, 1, 200)
    bpts = bpts[np.abs(bpts - d) > 1e-3]
    full_rank = bool(np.all(np.abs(2 * (bpts - d)) > 0))
    law_gap = float(np.max(np.abs(h(bpts) - h(2 * d - bpts))))
    fold_slope = abs(2 * (d - d))

    b_true = 0.10
    cover_point, cover_set, branch_hits = 0, 0, 0
    reps = 300
    for _ in range(reps):
        y = h(b_true) + s * rng.standard_normal(n)
        nll = lambda b: np.sum((y - h(b)) ** 2)
        start = rng.uniform(0, 1)
        lo, hi = (0.0, d) if start < d else (d, 1.0)
        b_hat = minimize_scalar(nll, bounds=(lo, hi), method="bounded").x
        info = n * (2 * (b_hat - d)) ** 2 / s**2
        se = 1 / math.sqrt(info)
        cover_point += abs(b_hat - b_true) <= 1.96 * se
        cands = [b_hat, 2 * d - b_hat]
        cover_set += any(abs(cnd - b_true) <= 1.96 * se for cnd in cands)
        branch_hits += b_hat > d
    cp, cs = cover_point / reps, cover_set / reps
    checks = {
        "full_rank_off_fold": full_rank,
        "partner_has_identical_law": law_gap < 1e-15,
        "fold_is_a_rank_wall": fold_slope == 0,
        "partner_fraction_matches_geometry": abs(frac_partner - 0.56) < 0.01,
        "teeth_local_interval_undercovers": cp < 0.7,
        "set_valued_report_covers": cs > 0.9,
    }
    metrics = {"partner_fraction": frac_partner, "coverage_point_estimate": cp,
               "coverage_set_valued": cs, "fraction_on_wrong_branch": branch_hits / reps}
    return _result(
        "T03", "Full local rank is not global identification",
        "R10 gated (regularity); R2 forced",
        ["RG - Wall-Tap Delay - Global.pdf (WT02, WT03)", "Resolution Geometry.pdf (L10)"],
        "Do not substitute rank for global identification.",
        "Fit a model whose Jacobian is full rank everywhere off a fold; report Wald intervals.",
        "Full rank everywhere except a fold still leaves exact partners with identical law on "
        f"{frac_partner:.0%} of the domain. Local intervals then cover ~{cp:.0%}, not 95%. Search "
        "for equal-law partners (T04) and report a set when they exist.",
        checks, metrics,
        counterexample=f"Wald 95% interval from the locally full-rank Fisher covers the truth {cp:.2f} "
                       "of the time; the set {b, 2d-b} covers it "
                       f"{cs:.2f}.",
        teeth="teeth_local_interval_undercovers")


# --------------------------------------------------------------------------------------
# T04  a sound but incomplete declared ambiguity list; equality-of-law search finds the fold
# --------------------------------------------------------------------------------------

def t04_completeness(seed):
    rng = np.random.default_rng(seed)
    d, s, K = 0.28, 0.05, 60
    grid = np.round(np.arange(0, 1.0000001, 0.01), 10)
    o = np.arange(K + 1) / K
    def law(b):
        w = np.exp(-(o - (b - d) ** 2 * 3) ** 2 / (2 * s**2))
        return w / w.sum()
    order = rng.permutation(len(grid))           # hostile: shuffle, no ordering help
    classes = {}
    for idx in order:
        key = np.round(law(grid[idx]), 12).tobytes()
        classes.setdefault(key, []).append(float(grid[idx]))
    found = [sorted(v) for v in classes.values() if len(v) > 1]
    all_on_fold = all(abs(p[0] + p[1] - 2 * d) < 1e-9 for p in found)
    declared_quotient = len(grid)                 # declared group = identity (sound, incomplete)
    true_quotient = len(classes)
    checks = {
        "teeth_declared_list_incomplete": true_quotient < declared_quotient,
        "search_recovers_exactly_the_fold": len(found) == 28 and all_on_fold,
    }
    metrics = {"declared_quotient_size": declared_quotient, "true_quotient_size": true_quotient,
               "equal_law_pairs_found": len(found)}
    return _result(
        "T04", "Declared ambiguities are sound but need not be complete",
        "R5 gated (soundness); R6 gated (completeness)",
        ["RG - Theorem Ladder.pdf (R5-R6)", "RG - Wall-Tap Delay - Global.pdf (corrections 1-3)",
         "RG - The Groupoid of Resolution.pdf"],
        "Keep an explicit nuisance and assumption register.",
        "Declare only the known ambiguities (here: none) and let an equality-of-law search look for more.",
        "A register of known ambiguities is necessary but not sufficient. Add a cheap equality-of-law "
        "search over the declared domain; it found all 28 hidden partner pairs here.",
        checks, metrics,
        counterexample=f"Declared quotient {declared_quotient} classes; true quotient {true_quotient}.",
        teeth="teeth_declared_list_incomplete")


# --------------------------------------------------------------------------------------
# T05  exact layer is cheap for exact law tables; with estimated laws equality is a test
# --------------------------------------------------------------------------------------

def t05_exact_layer_cost(seed):
    rng = np.random.default_rng(seed)
    def classes(table):
        cl = {}
        for i, row in enumerate(table):
            cl.setdefault(row.tobytes(), []).append(i)
        return cl
    small = rng.integers(0, 3, size=(300, 6)).astype(np.int8)
    fast = sorted(sorted(v) for v in classes(small).values())
    brute = []
    seen = set()
    for i in range(len(small)):
        if i in seen:
            continue
        grp = [j for j in range(len(small)) if np.array_equal(small[i], small[j])]
        seen.update(grp); brute.append(grp)
    correct = fast == sorted(brute)
    times = []
    sizes = (5_000, 50_000, 500_000)
    for n in sizes:
        tab = rng.integers(0, 4, size=(n, 12)).astype(np.int8)
        best = math.inf
        for _ in range(3):
            t0 = time.perf_counter(); classes(tab); best = min(best, time.perf_counter() - t0)
        times.append(best)
    slope = float(np.polyfit(np.log(sizes), np.log(times), 1)[0])

    # estimated laws: two samples of the SAME law hash differently; tolerance is not transitive
    p = np.array([0.2, 0.3, 0.5])
    e1 = rng.multinomial(1000, p) / 1000
    e2 = rng.multinomial(1000, p) / 1000
    exact_hash_split = np.round(e1, 3).tobytes() != np.round(e2, 3).tobytes()
    tol = 0.05
    A = np.array([0.20, 0.30, 0.50]); B = A + np.array([0.03, 0, -0.03]); C = B + np.array([0.03, 0, -0.03])
    tv = lambda u, v: 0.5 * np.abs(u - v).sum()
    chain = tv(A, B) <= tol and tv(B, C) <= tol and tv(A, C) > tol
    checks = {
        "hash_classes_match_bruteforce": correct,
        "exact_layer_scales_near_linearly": slope < 1.6,
        "teeth_estimated_laws_break_exact_equality": exact_hash_split,
        "teeth_tolerance_not_transitive": chain,
    }
    metrics = {"scaling_exponent": slope, "seconds_at_500k_rows": times[-1],
               "tv_AB": tv(A, B), "tv_BC": tv(B, C), "tv_AC": tv(A, C)}
    return _result(
        "T05", "The exact layer is cheap -- for exact law tables only",
        "R1-R3 forced; finite-data boundary (Resolution Geometry.pdf sections 8-9, 17)",
        ["Resolution Geometry.pdf (section 17)", "RG - Theorem Ladder.pdf (R1-R3)"],
        "Exactness is cheap at the exact layer.",
        "Time the kernel computation; then feed it estimated laws instead of exact ones.",
        "Grouping exact (model or symbolic) law tables is near-linear and cheap. With measured data, "
        "equality of law becomes a statistical test with tolerance classes that are not transitive; "
        "cost and report it as a test (confidence correspondence), never as exact grouping.",
        checks, metrics,
        counterexample=f"Two samples of one law hash differently; TV(A,B)={tv(A,B):.2f}, "
                       f"TV(B,C)={tv(B,C):.2f} pass tolerance {tol}, TV(A,C)={tv(A,C):.2f} fails.",
        teeth="teeth_tolerance_not_transitive")


# --------------------------------------------------------------------------------------
# T06  adding channels: nullity never increases on a FIXED parameter set; new nuisances
# --------------------------------------------------------------------------------------

def t06_adding_channels(seed):
    rng = np.random.default_rng(seed)
    viol = 0
    for _ in range(2000):
        p = int(rng.integers(3, 9))
        Js = [rng.standard_normal((int(rng.integers(1, p)), p)) @
              np.diag(rng.random(p) > 0.3) for _ in range(int(rng.integers(2, 4)))]
        null_each = [p - np.linalg.matrix_rank(J) for J in Js]
        null_stack = p - np.linalg.matrix_rank(np.vstack(Js))
        viol += null_stack > min(null_each)
    # a new channel that brings two new nuisances: y3 = theta + g3 + h3
    J_old = np.array([[1.0, 0.3], [0.2, 1.0]])            # (theta, eta), full rank
    J_new = np.block([[J_old, np.zeros((2, 2))], [np.array([[1.0, 0.0, 1.0, 1.0]])]])
    null_old = 2 - np.linalg.matrix_rank(J_old)
    null_new = 4 - np.linalg.matrix_rank(J_new)
    # efficient info on the old target never decreases
    eff_viol = 0
    for _ in range(2000):
        p_old, p_new = int(rng.integers(2, 5)), int(rng.integers(1, 4))
        B1 = rng.standard_normal((int(rng.integers(1, 6)), p_old))
        F1 = np.zeros((p_old + p_new,) * 2); F1[:p_old, :p_old] = B1.T @ B1
        B2 = rng.standard_normal((int(rng.integers(1, 6)), p_old + p_new))
        B2[:, : p_old] *= rng.random(p_old) > 0.5
        F2 = B2.T @ B2
        e_old = efficient_info(B1.T @ B1, 0)
        e_new = efficient_info(F1 + F2, 0)
        eff_viol += e_new < e_old - 1e-8 * (1 + abs(e_old))
    checks = {
        "nullity_never_increases_fixed_parameters": viol == 0,
        "teeth_new_nuisances_raise_nullity": null_new > null_old,
        "efficient_info_on_target_never_decreases": eff_viol == 0,
    }
    metrics = {"nullity_violations_2000": viol, "nullity_old": int(null_old),
               "nullity_after_channel_with_new_nuisances": int(null_new),
               "efficient_info_violations_2000": eff_viol}
    return _result(
        "T06", "Adding a channel: what can and cannot get worse",
        "R12 gated (compatible sensor family); R8 imported (Schur)",
        ["RG - Wall-Tap Delay - Global.pdf (WT01, saturation by kernel intersection)",
         "RG - Observation Limit.pdf"],
        "Adding channels can only reduce what is unresolved.",
        "Add channels that bring their own unknown gains/offsets.",
        "On a fixed parameter set, stacking channels never increases the unresolved dimension, and "
        "the efficient information on an existing target never decreases even when the new channel "
        "brings new nuisances. But the new nuisances themselves can be unresolved: total unknowns "
        "can grow, and if they are silently fixed the result falsely locks (see T01).",
        checks, metrics,
        counterexample=f"Channel y3 = theta + g3 + h3 raises nullity from {null_old} to {null_new}.",
        teeth="teeth_new_nuisances_raise_nullity")


# --------------------------------------------------------------------------------------
# T07  shared systematic error: agreement is not accuracy
# --------------------------------------------------------------------------------------

def t07_shared_bias(seed):
    rng = np.random.default_rng(seed)
    truth, sig, sb, reps = 10.0, 0.1, 0.5, 4000
    out = {}
    for M in (1, 4, 16, 64):
        bs = sb * rng.standard_normal((reps, 1))
        x_sh = truth + bs + sig * rng.standard_normal((reps, M))
        bi = sb * rng.standard_normal((reps, M))
        x_in = truth + bi + sig * rng.standard_normal((reps, M))
        out[M] = (np.sqrt(np.mean((x_sh.mean(1) - truth) ** 2)),
                  np.sqrt(np.mean((x_in.mean(1) - truth) ** 2)),
                  float(np.mean(x_sh.std(1, ddof=1))) if M > 1 else float("nan"))
    floor_ratio = out[64][0] / out[1][0]
    indep_ratio = out[64][1] / out[1][1]
    checks = {
        "teeth_shared_bias_floors_error": floor_ratio > 0.9,
        "teeth_channels_agree_while_wrong": out[64][2] < 0.25 * out[64][0],
        "independent_calibrations_reduce_error": abs(indep_ratio - 1 / 8) < 0.03,
    }
    metrics = {"rmse_shared_M1": out[1][0], "rmse_shared_M64": out[64][0],
               "spread_between_channels_M64": out[64][2],
               "rmse_independent_M1": out[1][1], "rmse_independent_M64": out[64][1]}
    return _result(
        "T07", "Common calibration: more channels, same error",
        "R12-R13 (common-mode bias is a persistent null of the channel family)",
        ["RG - Observation Limit.pdf", "JCGM 100:2008 (correlated input quantities)"],
        "Adding more correlated channels without new information does not help.",
        "Average 64 channels that share one calibration; look at how well they agree.",
        "Channels sharing one calibration agree closely while the error stays at the calibration "
        "uncertainty; averaging removes only the independent part. Only an independent reference "
        "chain reduces it (here as 1/sqrt(M)). Inter-channel agreement is not evidence of accuracy.",
        checks, metrics,
        counterexample=f"64 shared-calibration channels: spread {out[64][2]:.3f}, error {out[64][0]:.3f}.",
        teeth="teeth_channels_agree_while_wrong")


# --------------------------------------------------------------------------------------
# T08  scale-free certificates are blind; R^2 and condition number accept targets in the hole
# --------------------------------------------------------------------------------------

def t08_declared_units(seed):
    rng = np.random.default_rng(seed)
    A = np.array([[2.0, 0.6], [0.6, 1.0]])
    target_sd = 0.1
    false_locks, rows = 0, []
    for eps in (1.0, 0.3, 0.1, 0.03, 0.01):
        F = (eps ** 2) * 400 * A
        Dm = np.diag(1 / np.sqrt(np.diag(F)))
        cond_norm = np.linalg.cond(Dm @ F @ Dm)
        crb_sd = np.sqrt(np.diag(np.linalg.inv(F))).max()
        scale_free = cond_norm < 100
        declared = crb_sd <= target_sd
        false_locks += scale_free and not declared
        rows.append((eps, cond_norm, crb_sd))
    # Monte Carlo: at eps = 0.03 the estimator's actual sd exceeds the target
    eps = 0.03
    F = (eps ** 2) * 400 * A
    draws = rng.multivariate_normal(np.zeros(2), np.linalg.inv(F), 5000)
    mc_sd = draws.std(0).max()
    # R^2 trap: duplicated regressor, target in the null of X
    n = 200
    x1, x2 = rng.standard_normal(n), rng.standard_normal(n)
    X = np.column_stack([x1, x1, x2])
    y = X @ np.array([1.0, 1.0, 0.5]) + 0.3 * rng.standard_normal(n)
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    r2 = 1 - np.var(y - X @ beta) / np.var(y)
    U, S, Vt = np.linalg.svd(X, full_matrices=False)
    Vr = Vt[S > 1e-10 * S.max()].T
    health = lambda c: np.linalg.norm(Vr @ (Vr.T @ c)) / np.linalg.norm(c)
    h_bad, h_good = health(np.array([1.0, -1.0, 0])), health(np.array([1.0, 1.0, 0]))
    checks = {
        "teeth_scale_free_certificate_false_locks": false_locks >= 2,
        "declared_unit_certificate_matches_mc": mc_sd > target_sd,
        "teeth_high_R2_with_target_in_hole": r2 > 0.9 and h_bad < 1e-10,
        "per_target_health_flags_it": h_good > 0.999,
    }
    metrics = {"false_locks_scale_free": false_locks, "normalized_condition_number": rows[-1][1],
               "crb_sd_at_eps_0.01": rows[-1][2], "mc_sd_at_eps_0.03": mc_sd,
               "R2": r2, "health_target_in_hole": h_bad, "health_target_resolved": h_good}
    return _result(
        "T08", "Certificates must be stated in declared units",
        "R11 gated; walls are window-indexed (Resolution Geometry.pdf Prop. 16.4)",
        ["RG - Wall-Tap Delay - Global.pdf (remark: certificates in declared units)",
         "RG - Hole Rejection.pdf"],
        "Use rank/conditioning margins on the operating domain.",
        "Let information collapse uniformly; certify with a normalized (scale-free) matrix; use R^2.",
        "Conditioning and rank margins are meaningful only in declared precision units of the target. "
        "A normalized matrix stays perfectly conditioned while the achievable uncertainty grows 100x; a "
        "fit with R^2 > 0.9 can carry a target with zero support. Certify per target, in units.",
        checks, metrics,
        counterexample=f"Normalized condition number {rows[-1][1]:.2f} at every scale; actual CRB sd "
                       f"{rows[-1][2]:.2f} vs target {target_sd}. R^2 {r2:.3f} with target health {h_bad:.1e}.",
        teeth="teeth_scale_free_certificate_false_locks")


# --------------------------------------------------------------------------------------
# T09  Fisher insufficiency: the information matrix cannot validate the noise model
# --------------------------------------------------------------------------------------

def t09_fisher_insufficiency(seed):
    rng = np.random.default_rng(seed)
    J = np.vstack([np.eye(2), np.zeros((2, 2))])          # resolved sector = first two coords
    SR = np.array([[1.0, 0.2], [0.2, 0.8]])
    SN1 = np.array([[1.0, 0.1], [0.1, 1.5]])
    C1 = np.array([[0.3, 0.1], [0.0, 0.2]])
    a = 1.8
    C2, SN2 = a * C1, a**2 * SN1                           # same Schur complement
    S1 = np.block([[SR, C1], [C1.T, SN1]])
    S2 = np.block([[SR + (C2 @ np.linalg.inv(SN2) @ C2.T) - (C1 @ np.linalg.inv(SN1) @ C1.T), C2],
                   [C2.T, SN2]])
    F1 = J.T @ np.linalg.inv(S1) @ J
    F2 = J.T @ np.linalg.inv(S2) @ J
    fisher_gap = float(np.max(np.abs(F1 - F2)))
    cov_gap = float(np.max(np.abs(S1 - S2)))
    pd = np.all(np.linalg.eigvalsh(S2) > 0)
    n = 2000
    X = rng.multivariate_normal(np.zeros(4), S1, n)
    ll = lambda S: stats.multivariate_normal(np.zeros(4), S).logpdf(X)
    llr = ll(S1) - ll(S2)
    z = llr.sum() / (llr.std(ddof=1) * math.sqrt(n))
    checks = {
        "teeth_two_noise_models_same_fisher": fisher_gap < 1e-10 and cov_gap > 0.1 and pd,
        "full_residuals_distinguish_them": z > 5,
    }
    metrics = {"fisher_gap": fisher_gap, "covariance_gap": cov_gap, "llr_z_score_n2000": z}
    return _result(
        "T09", "The information matrix cannot validate the noise model",
        "R8 imported; R9 no-go (Fisher insufficiency)",
        ["RG - Reconstruction Identifiability.pdf", "RG - Covariance Geometry.pdf", "RG - Blind Sector.pdf"],
        "Use a baseline uncertainty/identifiability check.",
        "Build two different noise covariances with identical Fisher information.",
        "Two different noise models can give identical parameter information. An uncertainty budget "
        "checked only through parameter uncertainties cannot validate the noise model; check the full "
        "residual covariance (all observed directions) against the declared one.",
        checks, metrics,
        counterexample=f"Fisher difference {fisher_gap:.1e}; covariance difference {cov_gap:.2f}.",
        teeth="teeth_two_noise_models_same_fisher")


# --------------------------------------------------------------------------------------
# T10  equal identifiability is not equal value (Blackwell)
# --------------------------------------------------------------------------------------

def t10_blackwell(seed):
    p1, p2 = 0.1, 0.3
    q = (p2 - p1) / (1 - 2 * p1)                          # BSC(p1) then BSC(q) = BSC(p2)
    composed = p1 * (1 - q) + (1 - p1) * q
    q_rev = (p1 - p2) / (1 - 2 * p2)                       # would be needed to go back
    both_injective = (p1 != 0.5) and (p2 != 0.5)
    risk = lambda p: min(p, 1 - p)
    # asymmetric loss: theta=0 is a bad lot; accepting it costs 3, rejecting a good lot costs 1
    def bayes_risk(p, la=3.0, lr=1.0):
        tot = 0.0
        for y in (0, 1):
            p_y_bad = (1 - p) if y == 0 else p           # P(y | theta=0)
            p_y_good = p if y == 0 else (1 - p)          # P(y | theta=1)
            tot += min(0.5 * p_y_bad * la, 0.5 * p_y_good * lr)
        return tot
    checks = {
        "same_identifiability_kernel_pair": both_injective,
        "teeth_values_differ": risk(p2) - risk(p1) > 0.15 and bayes_risk(p2) > bayes_risk(p1),
        "weaker_is_garbling_of_stronger": abs(composed - p2) < 1e-15 and 0 <= q <= 1,
        "no_garbling_back": not (0 <= q_rev <= 1),
    }
    metrics = {"bayes_error_E1": risk(p1), "bayes_error_E2": risk(p2), "garbling_q": q,
               "asym_risk_E1": bayes_risk(p1), "asym_risk_E2": bayes_risk(p2)}
    return _result(
        "T10", "Two instruments that both 'can measure it' are not interchangeable",
        "R14 no-go (kernel-pair order differs from Blackwell order)",
        ["RG - Theorem Ladder.pdf (R14)", "RG - Axioms.pdf (information order)"],
        "Compare packages by whether they make the target identifiable.",
        "Two experiments with identical identifiability but different noise.",
        "Identifiability (can it be told apart at all) is necessary but does not rank instruments. "
        "Compare candidate instruments by decision risk or efficient information in declared units "
        "for the actual decision, not by a capability checklist.",
        checks, metrics,
        counterexample=f"Both identify theta; Bayes error {risk(p1):.2f} vs {risk(p2):.2f}.",
        teeth="teeth_values_differ")


# --------------------------------------------------------------------------------------
# T11  pairwise checks pass, the loop does not close; tolerance chains
# --------------------------------------------------------------------------------------

def _rot_to(a, b):
    v = np.cross(a, b); s = np.linalg.norm(v); c = float(np.dot(a, b))
    if s < 1e-15:
        return np.eye(3)
    vx = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    return np.eye(3) + vx + vx @ vx * ((1 - c) / s**2)


def t11_loop_closure(seed):
    rng = np.random.default_rng(seed)
    th0 = 0.6 + 0.05 * rng.random()
    K = 2000
    phis = np.linspace(0, 2 * np.pi, K + 1)
    normals = np.stack([np.sin(th0) * np.cos(phis), np.sin(th0) * np.sin(phis),
                        np.cos(th0) * np.ones_like(phis)], 1)
    v0 = np.array([np.cos(th0), 0.0, -np.sin(th0)])        # tangent at phi=0
    v = v0.copy(); min_overlap = 1.0
    for k in range(K):
        min_overlap = min(min_overlap, float(normals[k] @ normals[k + 1]))
        v = _rot_to(normals[k], normals[k + 1]) @ v
    hol = math.atan2(float(np.cross(v0, v) @ normals[0]), float(v0 @ v))
    expected = 2 * np.pi * (1 - np.cos(th0))
    expected = (expected + np.pi) % (2 * np.pi) - np.pi
    # flat control: go out and back along a meridian (zero enclosed area)
    ts = np.concatenate([np.linspace(th0, th0 + 0.5, 500), np.linspace(th0 + 0.5, th0, 500)])
    nn = np.stack([np.sin(ts), np.zeros_like(ts), np.cos(ts)], 1)
    w0 = np.array([0.0, 1.0, 0.0]); w = w0.copy()
    for k in range(len(ts) - 1):
        w = _rot_to(nn[k], nn[k + 1]) @ w
    flat = float(np.linalg.norm(w - w0))
    checks = {
        "every_adjacent_check_passes": min_overlap > 0.9999,
        "teeth_loop_does_not_close": abs(hol) > 0.3,
        "loop_defect_equals_enclosed_geometry": abs(hol - expected) < 0.02 * abs(expected),
        "flat_control_closes": flat < 1e-9,
    }
    metrics = {"min_adjacent_overlap": min_overlap, "loop_holonomy_rad": hol,
               "predicted_rad": expected, "flat_control_defect": flat}
    return _result(
        "T11", "Chained pairwise calibrations: every step passes, the loop does not close",
        "R23 gated (cocycle / zero holonomy); R25 imported (transport)",
        ["RG - Necessity.pdf (consistency across a cycle)", "RG - Atlas Globalization.pdf",
         "Global RG.md (local admissibility vs cocycle)"],
        "Do not copy one site's certificate to another without checking its domain.",
        "Chain 2000 pairwise alignments around a closed cycle of conditions.",
        "Pairwise agreement between adjacent sites or conditions does not make a chain of calibrations "
        "globally consistent. Close every cycle (A->B->C->A) and check the loop defect; it is cheap "
        "(one product per loop). A nonzero defect means no single global calibration exists.",
        checks, metrics,
        counterexample=f"Adjacent overlap >= {min_overlap:.7f}; reference returns rotated by {hol:.3f} rad.",
        teeth="teeth_loop_does_not_close")


# --------------------------------------------------------------------------------------
# T12  a reused holdout is development data
# --------------------------------------------------------------------------------------

def t12_holdout_reuse(seed):
    rng = np.random.default_rng(seed)
    n, reps = 200, 300
    res = {}
    for K in (1, 10, 100, 1000):
        best_acc, fresh_acc = [], []
        for _ in range(reps):
            y = rng.integers(0, 2, n)
            P = rng.integers(0, 2, (K, n))
            acc = (P == y).mean(1)
            k = int(np.argmax(acc))
            best_acc.append(acc[k])
            y2 = rng.integers(0, 2, n)
            fresh_acc.append(np.mean(rng.integers(0, 2, n) == y2))   # chosen model has no skill
        res[K] = (np.mean(best_acc), np.mean(fresh_acc))
    checks = {
        "single_use_holdout_unbiased": abs(res[1][0] - 0.5) < 0.02,
        "teeth_reuse_inflates": res[100][0] - 0.5 > 0.05,
        "fresh_holdout_reveals_no_skill": abs(res[100][1] - 0.5) < 0.02,
    }
    metrics = {f"holdout_acc_best_of_{K}": res[K][0] for K in res}
    metrics.update({f"fresh_acc_best_of_{K}": res[K][1] for K in res})
    return _result(
        "T12", "A reused holdout becomes development evidence",
        "external (validation practice); Resolution Geometry.pdf procedure step 14",
        ["Resolution Geometry.pdf (section 19, step 14)", "RG - Corpus.md (benchmark framework)"],
        "Repeated use of a holdout for tuning turns it into development evidence.",
        "Select the best of K skill-free models on one holdout.",
        "Holds, and is quantified: selecting among 100 skill-free candidates on one 200-case holdout "
        f"reports {res[100][0]:.2f} accuracy for a model with none. Budget a genuinely fresh "
        "evaluation source and record how many candidates touched the holdout.",
        checks, metrics,
        counterexample=f"Best of 100 skill-free models scores {res[100][0]:.3f} on the reused holdout, "
                       f"{res[100][1]:.3f} on a fresh one.",
        teeth="teeth_reuse_inflates")


# --------------------------------------------------------------------------------------
# T13  false-lock budget: union bound holds only for a conjunctive dispatcher, as used
# --------------------------------------------------------------------------------------

def t13_false_lock_budget(seed):
    rng = np.random.default_rng(seed)
    alphas = np.array([0.02, 0.03, 0.01, 0.04])
    G, n, power = len(alphas), 400_000, 0.95
    truth_ok = rng.random((n, G)) < 0.7
    u = rng.random((n, G))
    shared = rng.random((n, 1))
    def gate_pass(uu):
        return np.where(truth_ok, uu < power, uu < alphas)
    passes_ind = gate_pass(u)
    passes_cor = gate_pass(np.repeat(shared, G, 1))        # comonotone errors
    bad = ~truth_ok.all(1)
    bound = alphas.sum()
    fl = lambda lock: np.mean(lock & bad)
    conj_ind = fl(passes_ind.all(1)); conj_cor = fl(passes_cor.all(1))
    majority = fl(passes_ind.sum(1) >= 3)
    # retry attack on a single gate whose truth always fails, claimed alpha 0.02
    a1 = 0.02
    no_retry = np.mean(rng.random(n) < a1)
    retried = np.zeros(n, bool)
    for _ in range(5):
        retried |= rng.random(n) < a1
    retry = float(np.mean(retried))
    se = math.sqrt(bound * (1 - bound) / n)
    checks = {
        "conjunctive_within_bound_independent": conj_ind <= bound + 3 * se,
        "conjunctive_within_bound_correlated": conj_cor <= bound + 3 * se,
        "teeth_majority_dispatcher_breaks_bound": majority > bound,
        "single_gate_without_retry_within_alpha": no_retry <= a1 + 3 * math.sqrt(a1 * (1 - a1) / n),
        "teeth_retry_until_pass_breaks_bound": retry > a1 + 3 * math.sqrt(a1 * (1 - a1) / n),
    }
    metrics = {"bound_sum_alpha": bound, "false_lock_conjunctive": conj_ind,
               "false_lock_conjunctive_correlated": conj_cor, "false_lock_majority": majority,
               "single_gate_claimed_alpha": a1, "single_gate_no_retry": no_retry,
               "single_gate_retry5": retry}
    return _result(
        "T13", "False-acceptance budget across checks",
        "external to R-ladder; Resolution Geometry.pdf Thm 16.3 (composite soundness)",
        ["Resolution Geometry.pdf (section 16)", "RG - Wall-Tap Delay - Global.pdf (sabotaged certificates)"],
        "The false-lock probability is bounded by the sum of gate errors.",
        "Correlate gate errors; use a majority dispatcher; retry a gate until it passes.",
        "The bound Pr(false LOCKED) <= sum of gate false-pass rates holds for any dependence between "
        "gates, but only if LOCKED requires every gate and each rate is the one actually used. "
        "A majority rule or 'retry until pass' breaks it. Log every gate attempt.",
        checks, metrics,
        counterexample=f"Bound {bound:.3f}; majority dispatcher {majority:.3f}. Single gate claimed "
                       f"alpha {a1}; retry-until-pass gives {retry:.3f}.",
        teeth="teeth_majority_dispatcher_breaks_bound")


# --------------------------------------------------------------------------------------
# T14  stricter thresholds can only shrink the accepted set -- with fixed data
# --------------------------------------------------------------------------------------

def t14_threshold_monotone(seed):
    rng = np.random.default_rng(seed)
    taus = np.linspace(0.5, 4, 20)
    viol = 0
    for _ in range(200):
        x = rng.standard_normal(40) + rng.normal(0, 0.6)
        z = abs(x.mean()) / (x.std(ddof=1) / math.sqrt(len(x)))
        passes = [z >= t for t in taus]
        viol += any(passes[i + 1] and not passes[i] for i in range(len(taus) - 1))
    # gate whose stringency also changes the data (stricter -> trims more outliers)
    x = np.concatenate([np.full(30, 0.5) + 0.05 * rng.standard_normal(30), [-12.0, -11.0]])
    def trimmed_gate(s):
        keep = np.abs(x - np.median(x)) <= 30 / s
        xs = x[keep]
        zz = abs(xs.mean()) / (xs.std(ddof=1) / math.sqrt(len(xs)))
        return zz >= s
    lo_s, hi_s = 1.5, 3.0
    nonmono = (not trimmed_gate(lo_s)) and trimmed_gate(hi_s)
    checks = {
        "fixed_data_gate_is_monotone": viol == 0,
        "teeth_data_dependent_stringency_breaks_monotonicity": nonmono,
    }
    metrics = {"violations_fixed_data": viol, "trimmed_gate_lo": trimmed_gate(lo_s),
               "trimmed_gate_hi": trimmed_gate(hi_s)}
    return _result(
        "T14", "Thresholds behave monotonically only when they do not change the data",
        "external to R-ladder; Resolution Geometry.pdf Prop. 16.5",
        ["Resolution Geometry.pdf (section 16)"],
        "Accepted results can only shrink when thresholds are tightened.",
        "Tie outlier trimming to the stringency level.",
        "With fixed data and threshold-monotone gates, tightening can only remove LOCKED results, so "
        "each certificate can be reported as its critical margin. If stringency also changes which "
        "data are used (trimming, re-selection), a result can fail at a lax threshold and pass at a "
        "strict one. Freeze the data rule before varying thresholds.",
        checks, metrics,
        counterexample="Trimmed gate fails at stringency 1.5 and passes at 3.0.",
        teeth="teeth_data_dependent_stringency_breaks_monotonicity")


# --------------------------------------------------------------------------------------
# T15  Le Cam floor and the acquisition cost law
# --------------------------------------------------------------------------------------

def t15_lecam_cost_law(seed):
    rng = np.random.default_rng(seed)
    worst, scaling = 0.0, []
    for delta in (0.1, 0.2, 0.4):
        for n in (25, 100, 400):
            theory = stats.norm.cdf(-math.sqrt(n) * delta / 2)
            tv = 2 * stats.norm.cdf(math.sqrt(n) * delta / 2) - 1
            m0 = rng.normal(0, 1 / math.sqrt(n), 20000)
            m1 = rng.normal(delta, 1 / math.sqrt(n), 20000)
            mc = 0.5 * np.mean(m0 > delta / 2) + 0.5 * np.mean(m1 <= delta / 2)
            worst = max(worst, abs(mc - theory), abs((1 - tv) / 2 - theory))
    n_req = lambda d, e: (2 * stats.norm.ppf(1 - e) / d) ** 2
    ratio = n_req(0.1, 0.05) / n_req(0.2, 0.05)
    m0 = rng.normal(0, 0.01, 20000); m1 = rng.normal(0, 0.01, 20000)
    wall_err = 0.5 * np.mean(m0 > 0) + 0.5 * np.mean(m1 <= 0)
    checks = {
        "optimal_error_equals_lecam_floor": worst < 0.01,
        "halving_detectable_difference_quadruples_samples": abs(ratio - 4) < 1e-9,
        "at_a_wall_no_budget_helps": abs(wall_err - 0.5) < 0.01,
    }
    metrics = {"max_abs_deviation": worst, "n_ratio_half_delta": ratio,
               "n_required_delta0.1_err0.05": n_req(0.1, 0.05), "error_at_wall": wall_err}
    return _result(
        "T15", "No pipeline beats the data's distinguishability; what samples cost",
        "imported (Le Cam); Resolution Geometry.pdf Prop. 16.5",
        ["Resolution Geometry.pdf (section 16)", "RG - Uncertainty Geometry.pdf"],
        "Decision error can be driven down by better analysis.",
        "Compare the best possible test with the Le Cam floor; scale the target difference.",
        "Holds as a floor: the best decision rule's error equals (1 - TV)/2, so software cannot beat "
        "the data. Samples needed scale as (noise / detectable difference)^2 -- halving the difference "
        "quadruples acquisition cost -- and at a structural wall the error stays 1/2 at any budget.",
        checks, metrics)


# --------------------------------------------------------------------------------------
# T16  a prior is never forgotten along the blind direction
# --------------------------------------------------------------------------------------

def t16_prior_not_forgotten(seed):
    s, ta, tb = 0.05, 0.2, 10.0
    sd_b, sd_sum = {}, {}
    for N in (10, 1_000, 100_000, 10_000_000):
        P = np.diag([1 / ta**2, 1 / tb**2]) + N / s**2 * np.ones((2, 2))
        Cov = np.linalg.inv(P)
        sd_b[N] = math.sqrt(Cov[1, 1])
        sd_sum[N] = math.sqrt(np.ones(2) @ Cov @ np.ones(2))
    limit = math.sqrt(ta**2 * tb**2 / (ta**2 + tb**2))
    # posterior mean of log r follows the prior mean of log g one for one
    N = 10_000_000; ubar = 0.3
    def post_mean_b(mu_a):
        P = np.diag([1 / ta**2, 1 / tb**2]) + N / s**2 * np.ones((2, 2))
        rhs = np.array([mu_a / ta**2, 0.0]) + N / s**2 * ubar * np.ones(2)
        return np.linalg.solve(P, rhs)[1]
    shift = post_mean_b(0.5) - post_mean_b(0.0)
    checks = {
        "teeth_posterior_on_blind_direction_does_not_shrink": sd_b[10_000_000] > 0.99 * sd_b[1_000],
        "it_converges_to_the_prior_width": abs(sd_b[10_000_000] / limit - 1) < 0.02,
        "answer_moves_with_the_assumption": abs(shift + 0.5) < 0.01,
        "identified_combination_does_shrink": sd_sum[10_000_000] < 0.01 * sd_sum[10],
    }
    metrics = {"posterior_sd_log_r_N1e3": sd_b[1_000], "posterior_sd_log_r_N1e7": sd_b[10_000_000],
               "prior_limit": limit, "shift_of_answer_per_0.5_prior_shift": shift,
               "posterior_sd_log_gr_N1e7": sd_sum[10_000_000]}
    return _result(
        "T16", "A prior is never forgotten along a blind direction",
        "R2-R3 forced (only quotient functions are learned); RG - Uncertainty Geometry.pdf (BvM on quotient)",
        ["RG - Uncertainty Geometry.pdf", "RG - Ignorance.pdf"],
        "(missing in draft) Bayesian priors can resolve ambiguities with enough data.",
        "Give the blind parameter a prior and let N grow by 10^6.",
        "Along a structural null the posterior equals the prior however much data arrives: the "
        "answer moves one-for-one with the assumption. Label such outputs as assumption-driven; they "
        "are not measurements.",
        checks, metrics,
        counterexample=f"Posterior sd of log r: {sd_b[1_000]:.4f} at N=1e3, {sd_b[10_000_000]:.4f} at N=1e7; "
                       f"shifting the gain prior by 0.5 shifts the answer by {shift:.3f}.",
        teeth="teeth_posterior_on_blind_direction_does_not_shrink")


# --------------------------------------------------------------------------------------
# T17  break-even under uncertain value per event (Jensen)
# --------------------------------------------------------------------------------------

def t17_break_even_jensen(seed):
    rng = np.random.default_rng(seed)
    C, med, sl = 100.0, 10.0, 0.8
    v = med * np.exp(sl * rng.standard_normal(400_000))
    point = C / v.mean()
    ev = C / v
    p_exceed = np.mean(ev > point)
    analytic = stats.norm.cdf(sl / 2)
    checks = {
        "teeth_mean_of_ratio_exceeds_ratio_of_mean": ev.mean() > 1.2 * point,
        "point_break_even_is_optimistic": p_exceed > 0.5,
        "matches_analytic": abs(p_exceed - analytic) < 0.005,
    }
    metrics = {"break_even_at_mean_value": point, "median_events_needed": float(np.median(ev)),
               "p80_events_needed": float(np.quantile(ev, 0.8)), "prob_need_more_than_point": p_exceed}
    return _result(
        "T17", "Break-even computed at the average value is optimistic",
        "external (decision analysis, imported)",
        ["GAO-20-195G (risk and uncertainty analysis)"],
        "BreakEvenAvoidedEvents = C / v.",
        "Let v be uncertain (log-normal, as most cost and loss figures are).",
        "C / v at the mean value of v understates the events needed: here the true number exceeds it "
        f"with probability {p_exceed:.2f}. Report break-even as a distribution (median and P80).",
        checks, metrics,
        counterexample=f"C/E[v] = {point:.2f} events; median {np.median(ev):.2f}; P80 {np.quantile(ev,0.8):.2f}.",
        teeth="teeth_mean_of_ratio_exceeds_ratio_of_mean")


# --------------------------------------------------------------------------------------
# T18  adding most-likely values understates the total; correlation fattens the tail
# --------------------------------------------------------------------------------------

def t18_cost_aggregation(seed):
    rng = np.random.default_rng(seed)
    k, lo, mo, hi = 10, 1.0, 2.0, 6.0
    c = (mo - lo) / (hi - lo)
    def draw(rho, n=200_000):
        Z = rng.standard_normal((n, 1)) * math.sqrt(rho) + rng.standard_normal((n, k)) * math.sqrt(1 - rho)
        U = stats.norm.cdf(Z)
        return stats.triang.ppf(U, c, loc=lo, scale=hi - lo).sum(1)
    ind, cor = draw(0.0), draw(0.6)
    sum_modes = k * mo
    checks = {
        "teeth_sum_of_modes_below_median": np.median(ind) > 1.3 * sum_modes,
        "correlation_raises_P80": np.quantile(cor, 0.8) > np.quantile(ind, 0.8),
        "sum_of_modes_almost_never_met": np.mean(ind <= sum_modes) < 0.01,
    }
    metrics = {"sum_of_modes": sum_modes, "P50_independent": float(np.median(ind)),
               "P80_independent": float(np.quantile(ind, 0.8)), "P80_correlated": float(np.quantile(cor, 0.8)),
               "prob_total_within_sum_of_modes": float(np.mean(ind <= sum_modes))}
    return _result(
        "T18", "Adding 'most likely' costs understates the total",
        "external (cost estimating practice, imported)",
        ["GAO-20-195G", "AACE RP 18R-97"],
        "(missing in draft) Estimate each cost item and add them.",
        "Ten right-skewed items; independent and correlated.",
        "Summing most-likely values gives a total that is met less than 1% of the time. Use three-point "
        "estimates, a correlated Monte Carlo, and report P50 and P80 (tool: rg_cost_model.py).",
        checks, metrics,
        counterexample=f"Sum of modes {sum_modes:.0f}; P50 {np.median(ind):.1f}; P80 correlated "
                       f"{np.quantile(cor,0.8):.1f}.",
        teeth="teeth_sum_of_modes_below_median")


# --------------------------------------------------------------------------------------
# T19  ranking packages by benefit/cost fails under complementarity and redundancy
# --------------------------------------------------------------------------------------

def t19_package_interaction(seed):
    # parameters (x, c, L, k): delays in clock units tau1 = 2xk/c, tau2 = 2Lk/c
    x, c, L, k = 1.7, 343.0, 3.0, 1.0
    base = np.array([[2 * k / c, -2 * x * k / c**2, 0, 2 * x / c],
                     [0, -2 * L * k / c**2, 2 * k / c, 2 * L / c]])
    pk = {"rod": (5.0, np.array([[0, 0, 1, 0]])),
          "thermometer": (2.0, np.array([[0, 1, 0, 0]])),
          "counted_clock": (2.0, np.array([[0, 0, 0, 1]])),
          "repeat_delays": (1.0, base.copy()),
          "second_rod": (5.0, np.array([[0, 0, 1, 0]]))}
    def value(S):
        J = np.vstack([base] + [pk[s][1] for s in S])
        return 1.0 if identifiable(J, 0) else 0.0
    names = list(pk)
    alone = {s: value([s]) for s in names}
    best = None
    for r in range(len(names) + 1):
        for S in itertools.combinations(names, r):
            if value(S) == 1.0:
                cost = sum(pk[s][0] for s in S)
                if best is None or cost < best[0]:
                    best = (cost, S)
    order = sorted(names, key=lambda s: (-alone[s] / pk[s][0], pk[s][0]))
    def greedy(budget):
        chosen, spent = [], 0.0
        for s in order:
            if spent + pk[s][0] <= budget and alone[s] > 0:
                chosen.append(s); spent += pk[s][0]
        return chosen, spent, value(chosen)
    g4 = greedy(4.0); g_inf = greedy(1e9)
    redundancy = value(["rod", "second_rod"]) == value(["rod"])
    checks = {
        "teeth_complementary_pair_worthless_alone": alone["thermometer"] == 0 and alone["counted_clock"] == 0,
        "pair_is_cheapest_solution": best[1] == ("thermometer", "counted_clock") and best[0] == 4.0,
        "teeth_greedy_fails_within_budget": g4[2] == 0.0,
        "greedy_unbudgeted_overspends": g_inf[1] > best[0],
        "duplicate_adds_nothing": redundancy,
    }
    metrics = {"optimal_cost": best[0], "optimal_set": "+".join(best[1]),
               "greedy_budget4_value": g4[2], "greedy_unbudgeted_cost": g_inf[1]}
    return _result(
        "T19", "Do not rank packages one by one",
        "external (portfolio selection) on R12 kernel intersection",
        ["RG - Wall-Tap Delay - Global.pdf (WT09: anchors)", "Resolution Geometry.pdf (section 17)"],
        "Do not use a simple benefit/cost ranking when packages interact.",
        "Two anchors each worthless alone; one expensive anchor that works alone; a duplicate.",
        "Holds, with a worked counterexample: thermometry and a counted clock are each worthless for "
        "distance but jointly the cheapest fix (4 vs 5). Evaluate combinations (small candidate sets "
        "can be enumerated exactly).",
        checks, metrics,
        counterexample="Greedy benefit/cost with budget 4 buys nothing useful; the optimum within "
                       "budget 4 resolves the target.",
        teeth="teeth_greedy_fails_within_budget")


# --------------------------------------------------------------------------------------
# T20  a weighted score can hide the only option meeting both floors
# --------------------------------------------------------------------------------------

def t20_pareto_vs_weights(seed):
    opts = {"A": (1.0, 10.0), "B": (10.0, 1.0), "U": (5.8, 5.8), "D": (7.0, 7.0)}
    def dominated(a):
        return any(all(o[i] <= opts[a][i] for i in range(2)) and o != opts[a] for o in opts.values())
    pareto = {a for a in opts if not dominated(a)}
    chosen = set()
    for w in np.linspace(0, 1, 1001):
        chosen.add(min(opts, key=lambda a: w * opts[a][0] + (1 - w) * opts[a][1]))
    floors = [a for a in opts if opts[a][0] <= 6 and opts[a][1] <= 6]
    checks = {
        "weighted_optima_are_nondominated": chosen <= pareto,
        "teeth_nondominated_option_never_chosen_by_weights": "U" in pareto and "U" not in chosen,
        "floors_select_it": floors == ["U"],
    }
    metrics = {"pareto_set": ",".join(sorted(pareto)), "weight_choices": ",".join(sorted(chosen))}
    return _result(
        "T20", "A single weighted score can hide the only acceptable option",
        "external (multi-criteria decision, imported)",
        ["HM Treasury Green Book 2026 (no mechanistic ranking)"],
        "Do not hide multiple assurance measures inside an arbitrary single score.",
        "Sweep every weighting of cost vs assurance gap.",
        "Holds and is sharper: no weighting ever selects option U, yet U is nondominated and is the "
        "only option meeting both floors. Apply floors first, then show the whole nondominated set.",
        checks, metrics,
        counterexample="Option U (5.8, 5.8) is never chosen for any of 1001 weightings.",
        teeth="teeth_nondominated_option_never_chosen_by_weights")


# --------------------------------------------------------------------------------------
# T21  value of information: when to stop buying measurements
# --------------------------------------------------------------------------------------

def t21_value_of_information(seed):
    rng = np.random.default_rng(seed)
    T, s = 0.0, 1.0
    def evpi(m, n=400_000):
        # exact identity: EVPI = E[regret of the prior-optimal action]
        mu = m + s * rng.standard_normal(n)
        return np.mean(np.maximum(T - mu, 0)) if m >= T else np.mean(np.maximum(mu - T, 0))
    far, near = evpi(5.0), evpi(0.0)
    # EVSI of a noisy measurement y = mu + e, sd 0.5 (Gaussian preposterior)
    se, m, n = 0.5, 0.0, 400_000
    mu = m + s * rng.standard_normal(n)
    y = mu + se * rng.standard_normal(n)
    post_mean = m + s**2 / (s**2 + se**2) * (y - m)
    evsi = np.mean(np.where(post_mean > T, mu - T, 0.0)) - max(m - T, 0)
    # blind experiment: observes t1 + t2 while the decision depends on t1 - t2
    t1, t2 = rng.standard_normal(n), rng.standard_normal(n)
    q = t1 - t2; obs = t1 + t2 + 0.1 * rng.standard_normal(n)
    # Gaussian preposterior: slope = cov(q, obs)/var(obs) from the declared model (var t1 = var t2 = 1)
    slope_model = (1.0 - 1.0) / (1.0 + 1.0 + 0.1**2)
    post_q = slope_model * obs
    evsi_blind = np.mean(np.where(post_q > T, q - T, 0.0)) - max(0 - T, 0)
    corr = abs(np.corrcoef(q, obs)[0, 1])
    checks = {
        "no_value_when_decision_is_settled": far < 1e-4,
        "value_when_uncertainty_straddles": abs(near - s * stats.norm.pdf(0)) < 0.01,
        "sample_info_never_exceeds_perfect_info": evsi <= near + 0.01,
        "teeth_blind_experiment_has_zero_value_at_any_precision": abs(evsi_blind) < 1e-12 and corr < 0.01,
    }
    metrics = {"EVPI_settled": far, "EVPI_straddling": near, "EVSI_noisy_measurement": evsi,
               "EVSI_blind": evsi_blind, "corr_decision_quantity_vs_blind_obs": corr}
    return _result(
        "T21", "Stop buying measurements that cannot change the decision",
        "external (value of information) on R12-R13",
        ["Resolution Geometry.pdf (section 16, CORRESPONDENCE)", "HM Treasury Green Book 2026"],
        "Stop when no additional package has supported incremental benefit above its cost.",
        "Compute the most a measurement could ever be worth, for a settled decision, a straddling one, "
        "and a blind experiment.",
        "Holds and becomes computable: never pay more for a measurement than its expected value of "
        "information (bounded by EVPI); when the decision is the same over the whole plausible range "
        "the value is zero; an experiment blind to the decision quantity is worth zero at any precision.",
        checks, metrics,
        counterexample="A precise experiment on t1+t2 (noise 0.1) is worth exactly 0 for a decision on t1-t2.",
        teeth="teeth_blind_experiment_has_zero_value_at_any_precision")


# --------------------------------------------------------------------------------------
# T22  forecasting cost: each step of horizon costs a fixed number of bits
# --------------------------------------------------------------------------------------

def t22_chaos_cost(seed):
    rng = np.random.default_rng(seed)
    mp.mp.dps = 120
    ks = list(range(10, 61, 10))
    eps = mp.mpf("0.1")
    horizons = []
    x0s = [mp.mpf(rng.uniform(0.05, 0.95)) for _ in range(16)]
    for kbits in ks:
        hs = []
        for x0 in x0s:
            a, b = x0, x0 + mp.mpf(2) ** (-kbits)
            for n in range(1, 400):
                a, b = 4 * a * (1 - a), 4 * b * (1 - b)
                if abs(a - b) > eps:
                    hs.append(n); break
        horizons.append(float(np.mean(hs)))
    slope = float(np.polyfit(ks, horizons, 1)[0])
    # float64 "truth" itself diverges from 120-digit truth
    x = 0.3; xm = mp.mpf("0.3")
    div = None
    for n in range(1, 200):
        x = 4 * x * (1 - x); xm = 4 * xm * (1 - xm)
        if abs(x - float(xm)) > 0.1:
            div = n; break
    checks = {
        "one_bit_per_step_at_lambda_ln2": abs(slope - 1.0) < 0.12,
        "teeth_float64_reference_trajectory_fails_near_52_steps": div is not None and 40 <= div <= 65,
    }
    metrics = {"horizon_steps_per_bit": slope, "float64_divergence_step": div,
               "horizon_at_10_bits": horizons[0], "horizon_at_60_bits": horizons[-1]}
    return _result(
        "T22", "Forecast horizon is bought with precision, linearly in bits",
        "Resolution Geometry.pdf sections 13 and 17 (chaos cost lambda/ln2 bits per step)",
        ["RG - Chaos Is Not Hidden.pdf", "Resolution Geometry.pdf (section 17)"],
        "Do not promise to remove chaotic information cost.",
        "Measure the reliable horizon of the logistic map at 6 initial precisions with 120-digit truth.",
        "Holds and is priced: each additional step of reliable forecast costs lambda/ln2 bits of "
        "initial precision (here 1 bit). Ten more steps need ~1000x better initial data. Even a "
        "float64 reference model fails after ~50 steps.",
        checks, metrics,
        counterexample=f"Float64 reference trajectory departs from the 120-digit one at step {div}.",
        teeth="teeth_float64_reference_trajectory_fails_near_52_steps")


# --------------------------------------------------------------------------------------
# T23  choosing the smallest measurement panel: greedy is not optimal
# --------------------------------------------------------------------------------------

def t23_panel_selection(seed):
    rng = np.random.default_rng(seed)
    def sep(items, tests):
        out = set()
        for t in tests:
            for i, j in itertools.combinations(range(items), 2):
                if (i in t) != (j in t):
                    out.add((i, j))
        return out
    def greedy(items, T):
        allp = set(itertools.combinations(range(items), 2)); cov = set(); ch = []
        while cov != allp:
            b = max(range(len(T)), key=lambda q: (len(sep(items, [T[q]]) - cov), -q))
            gain = sep(items, [T[b]]) - cov
            if not gain:
                return None
            ch.append(b); cov |= gain
        return ch
    def optimum(items, T):
        allp = set(itertools.combinations(range(items), 2))
        for r in range(1, len(T) + 1):
            for cmb in itertools.combinations(range(len(T)), r):
                if sep(items, [T[q] for q in cmb]) == allp:
                    return list(cmb)
        return None
    found = None
    for _ in range(400):
        T = [frozenset(np.flatnonzero(rng.random(6) < 0.5).tolist()) for _ in range(7)]
        g, o = greedy(6, T), optimum(6, T)
        if g and o and len(g) > len(o):
            found = (T, g, o); break
    if found is None:   # registered fallback instance (found offline, seed 0)
        T = [frozenset(s) for s in ([1, 2, 3], [5], [1, 3], [0, 1, 2, 3], [1], [1, 2, 5], [0, 3, 5])]
        found = (T, greedy(6, T), optimum(6, T))
    T, g, o = found
    checks = {"teeth_greedy_panel_larger_than_optimum": len(g) > len(o),
              "optimum_verified_by_exhaustion": o is not None}
    metrics = {"greedy_panel_size": len(g), "optimal_panel_size": len(o)}
    return _result(
        "T23", "Picking the minimal measurement panel is genuinely hard",
        "Resolution Geometry.pdf section 17 (minimum panels NP-complete; imported)",
        ["Resolution Geometry.pdf (section 17)"],
        "Use a bounded candidate set and a task-specific stopping condition.",
        "Search for instances where the natural greedy choice of measurements is not minimal.",
        "Holds: greedy panel selection can need more measurements than necessary, and exact minimum "
        "selection is NP-complete. Keep candidate sets small enough to enumerate, or accept and "
        "report a greedy panel as an upper bound.",
        checks, metrics,
        counterexample=f"Greedy needs {len(g)} tests; exhaustive optimum {len(o)}.",
        teeth="teeth_greedy_panel_larger_than_optimum")


ALL_TESTS = [t01_product_ambiguity, t02_null_trichotomy, t03_fold, t04_completeness,
             t05_exact_layer_cost, t06_adding_channels, t07_shared_bias, t08_declared_units,
             t09_fisher_insufficiency, t10_blackwell, t11_loop_closure, t12_holdout_reuse,
             t13_false_lock_budget, t14_threshold_monotone, t15_lecam_cost_law,
             t16_prior_not_forgotten, t17_break_even_jensen, t18_cost_aggregation,
             t19_package_interaction, t20_pareto_vs_weights, t21_value_of_information,
             t22_chaos_cost, t23_panel_selection]
