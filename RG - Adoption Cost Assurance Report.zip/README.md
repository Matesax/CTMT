# RG Adoption Assurance Battery (v1.0, 21 October 2026)

Companion bundle to `report/RG_Adoption_Cost_Assurance_Report.md`.

The battery does not try to prove Resolution Geometry. It attacks every claim the adoption
report relies on, looks for counterexamples, records the boundary where a claim stops
holding, and checks that the corrected claim used in the report survives on five seeds.

## Contents

| File | Purpose |
|---|---|
| `report/RG_Adoption_Cost_Assurance_Report.md` | The report (v1.0) |
| `rg_attacks.py` | 23 hostile attacks T01-T23; each returns draft claim, attack, counterexample, verdict, corrected claim, checks, metrics |
| `run_battery.py` | Runs all attacks on seeds 20261021, 1, 42, 777, 2026 plus meta-tests M01-M04 on the claims register and the report |
| `mutation_check.py` | Breaks four core ingredients on purpose; the battery must fail on each |
| `rg_cost_model.py` | Three-point correlated Monte Carlo cost estimate, AACE band check, optimism-bias ceiling, break-even distribution |
| `inputs/example_pilot_inputs.json` | ILLUSTRATIVE input for a P1+P2 pilot (placeholders, not an estimate) |
| `claims_register.json` | Claim -> Theorem Ladder rung and type -> corpus source -> tests |
| `corpus_manifest.txt` | Standard titles of the corpus files; every citation in the report must resolve here |
| `results/` | `battery_results.json`, `summary.md`, `cost_summary_example.md` from the reference run |

## Run

```
pip install numpy scipy mpmath
python run_battery.py            # exit status 0 only if all attacks and meta-tests pass
python mutation_check.py         # exit status 0 only if every mutant is caught
python rg_cost_model.py inputs/example_pilot_inputs.json --out results/cost_summary_example.md
```

Reference environment: Python 3.12, numpy 2.4, scipy 1.17, mpmath 1.3. Runtime about 30 s.
Timing-based metrics in T05 (scaling exponent) vary by machine; the check threshold is 1.6.

## Verdicts

- HOLDS: identity or floor; no counterexample can exist; verified numerically.
- CONFIRMED: draft claim survived; the counterexample to the practice it warns against is exhibited and quantified.
- SHARPENED: draft claim was too broad, incomplete or missing; a counterexample forced the corrected claim.
- FAILED: the corrected claim failed. The report would then be wrong; treat as a blocking defect.

## Adding a local attack

Write a function in `rg_attacks.py` returning `_result(...)`, add it to `ALL_TESTS`, name any
counterexample-finding check with the prefix `teeth_`, and register the claim it backs in
`claims_register.json`. Run `run_battery.py`; M01 refuses claims without passing tests.

## Limits

Batteries test implementations, assumptions and boundaries of claims. They do not replace the
proofs in the corpus and they do not measure economic benefit. All cost inputs in `inputs/` are
illustrative placeholders.
