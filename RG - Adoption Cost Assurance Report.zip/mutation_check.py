"""
mutation_check.py -- attack the battery itself.

Each mutant deliberately breaks one ingredient the way a careless implementation would.
A battery with teeth must FAIL on every mutant.  Exit status 0 only if every mutant is caught.

    python mutation_check.py
"""
import importlib
import sys

import numpy as np

SEED = 20261021


def run_all(mod):
    failed = []
    for t in mod.ALL_TESTS:
        r = t(SEED)
        if not r["passed"]:
            failed.append(r["id"])
    return failed


def mutant_silent_nuisance(A):
    # efficient information computed without profiling the nuisances (the "silent gain" error)
    A.efficient_info = lambda F, t: float(np.asarray(F, float)[t, t])


def mutant_everything_identifiable(A):
    A.identifiable = lambda J, t, tol=1e-10: True


def mutant_flat_transport(A):
    # pretend chained alignments are exact identity transports
    A._rot_to = lambda a, b: np.eye(3)


def mutant_scale_free_rank(A):
    # rank test on a normalized matrix: tolerance relative to the largest eigenvalue, no units
    orig = np.linalg.matrix_rank
    A.np.linalg.matrix_rank = lambda M, tol=None: orig(M / (np.abs(M).max() + 1e-300), tol=1e-3)


MUTANTS = [mutant_silent_nuisance, mutant_everything_identifiable, mutant_flat_transport,
           mutant_scale_free_rank]


def main():
    ok = True
    for m in MUTANTS:
        import rg_attacks
        A = importlib.reload(rg_attacks)
        saved = np.linalg.matrix_rank
        try:
            m(A)
            failed = run_all(A)
        finally:
            np.linalg.matrix_rank = saved
        caught = bool(failed)
        ok &= caught
        print(f"{m.__name__:34s} caught={caught}  failing tests: {', '.join(failed) or '-'}")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
