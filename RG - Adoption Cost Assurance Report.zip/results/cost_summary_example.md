# Cost estimate summary: P1 evidence wrapper + P2 diagnostic check on ONE measurement decision

**ILLUSTRATIVE INPUTS -- NOT AN ESTIMATE.** Replace every number with local data.

- Sum of most-likely values: 38.0 person-days (met with probability 0.052)
- P10 / P50 / P80 / P90: 41.4 / 57.3 / 69.8 / 76.4 person-days
- Mean: 58.3 person-days
- Optimism-bias ceiling check: base x (1 + 200%) = 114.0 person-days (ceiling check on the base estimate; do not stack on the Monte Carlo)
- AACE class 5: simulated P10/P90 around P50 = -28% / +33%; benchmark low [-50, -20]%, high [30, 100]%
- Break-even avoided events: naive 7.06; P50 9.45; P80 19.03; probability that more than the naive number is needed 0.64
