# Battery summary

Seeds: 20261021, 1, 42, 777, 2026 (primary 20261021)

| ID | Title | Verdict | Passed on all seeds | Counterexample (primary seed) |
|---|---|---|---|---|
| T01 | Product ambiguity: repeats, silent nuisance, independent reference | CONFIRMED | yes | Gain fixed 1% off: the 95% interval for r covers the truth 0.91 of the time at N=10, 0.55 at N=100 and 0.000 at N=10000, while its width fell 32x. |
| T02 | Null trichotomy: when more data helps and when it cannot | SHARPENED | yes | Precision null: CRB falls exactly 10x for 10x repeats, so 'more measurements do not help' is false there; a linear model reads a quadratic signal as null (R2 0.000) that a quadratic model recovers (R2 0.9989). |
| T03 | Full local rank is not global identification | CONFIRMED | yes | Wald 95% interval from the locally full-rank Fisher covers the truth 0.26 of the time; the set {b, 2d-b} covers it 0.96. |
| T04 | Declared ambiguities are sound but need not be complete | SHARPENED | yes | Declared quotient 101 classes; true quotient 73. |
| T05 | The exact layer is cheap -- for exact law tables only | SHARPENED | yes | Two samples of one law hash differently; TV(A,B)=0.03, TV(B,C)=0.03 pass tolerance 0.05, TV(A,C)=0.06 fails. |
| T06 | Adding a channel: what can and cannot get worse | SHARPENED | yes | Channel y3 = theta + g3 + h3 raises nullity from 0 to 1. |
| T07 | Common calibration: more channels, same error | CONFIRMED | yes | 64 shared-calibration channels: spread 0.100, error 0.503. |
| T08 | Certificates must be stated in declared units | SHARPENED | yes | Normalized condition number 2.47 at every scale; actual CRB sd 5.52 vs target 0.1. R^2 0.983 with target health 2.4e-16. |
| T09 | The information matrix cannot validate the noise model | SHARPENED | yes | Fisher difference 5.6e-17; covariance difference 3.36. |
| T10 | Two instruments that both 'can measure it' are not interchangeable | SHARPENED | yes | Both identify theta; Bayes error 0.10 vs 0.30. |
| T11 | Chained pairwise calibrations: every step passes, the loop does not close | SHARPENED | yes | Adjacent overlap >= 0.9999984; reference returns rotated by 1.136 rad. |
| T12 | A reused holdout becomes development evidence | CONFIRMED | yes | Best of 100 skill-free models scores 0.587 on the reused holdout, 0.501 on a fresh one. |
| T13 | False-acceptance budget across checks | SHARPENED | yes | Bound 0.100; majority dispatcher 0.366. Single gate claimed alpha 0.02; retry-until-pass gives 0.096. |
| T14 | Thresholds behave monotonically only when they do not change the data | SHARPENED | yes | Trimmed gate fails at stringency 1.5 and passes at 3.0. |
| T15 | No pipeline beats the data's distinguishability; what samples cost | HOLDS | yes | - |
| T16 | A prior is never forgotten along a blind direction | SHARPENED | yes | Posterior sd of log r: 0.2000 at N=1e3, 0.2000 at N=1e7; shifting the gain prior by 0.5 shifts the answer by -0.500. |
| T17 | Break-even computed at the average value is optimistic | SHARPENED | yes | C/E[v] = 7.28 events; median 10.02; P80 19.63. |
| T18 | Adding 'most likely' costs understates the total | SHARPENED | yes | Sum of modes 20; P50 29.9; P80 correlated 37.6. |
| T19 | Do not rank packages one by one | CONFIRMED | yes | Greedy benefit/cost with budget 4 buys nothing useful; the optimum within budget 4 resolves the target. |
| T20 | A single weighted score can hide the only acceptable option | CONFIRMED | yes | Option U (5.8, 5.8) is never chosen for any of 1001 weightings. |
| T21 | Stop buying measurements that cannot change the decision | CONFIRMED | yes | A precise experiment on t1+t2 (noise 0.1) is worth exactly 0 for a decision on t1-t2. |
| T22 | Forecast horizon is bought with precision, linearly in bits | CONFIRMED | yes | Float64 reference trajectory departs from the 120-digit one at step 52. |
| T23 | Picking the minimal measurement panel is genuinely hard | CONFIRMED | yes | Greedy needs 4 tests; exhaustive optimum 3. |

| Meta | Title | Passed | Problems |
|---|---|---|---|
| M01 | Claims register integrity | yes | - |
| M02 | Report citations and claims | yes | - |
| M03 | Determinism under fixed seed | yes | - |
| M04 | Every SHARPENED/CONFIRMED verdict has a counterexample | yes | - |
