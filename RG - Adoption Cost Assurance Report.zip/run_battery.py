"""
run_battery.py -- run the hostile battery for the RG Adoption Cost Assurance Report.

    python run_battery.py                 # all seeds, all tests, meta-tests; writes results/
    python run_battery.py --seeds 1 42    # custom seeds
    python run_battery.py --quick         # primary seed only

Exit status 0 only if every attack and every meta-test passes on every seed.

Meta-tests attack the report itself:
  M01  every claim in claims_register.json is backed by >= 1 test that passed on every seed,
       and every corpus citation in the register exists in corpus_manifest.txt
  M02  every corpus file cited in the report exists in the manifest; every test ID appears in
       the report; stale citations and affirmative over-claims are absent
  M03  determinism: re-running tests with the same seed reproduces identical metrics
  M04  teeth: every SHARPENED or CONFIRMED verdict is backed by a check that found a counterexample
"""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
import re
import sys
import time
from pathlib import Path

import numpy as np
import scipy
import mpmath

import rg_attacks as A

HERE = Path(__file__).resolve().parent
PRIMARY_SEED = 20261021
SEEDS = [PRIMARY_SEED, 1, 42, 777, 2026]
REPORT = HERE / "report" / "RG_Adoption_Cost_Assurance_Report.md"

STALE = ["rg_geometry_comparison_paper.pdf", "Wall_Tap_Delay_Final_Print.pdf",
         "Web search is disabled", "current only through December 2025"]
# affirmative over-claims; the report may only use them negated, so match common affirmative forms
OVERCLAIM_PATTERNS = [r"(?<!not )(?<!no )\bguarantee[sd]? (accuracy|savings|compliance)",
                      r"(?<!not )(?<!never )\bRG[- ]certified\b",
                      r"\bROI of \d", r"(?<!not )\bproves? (that )?RG (is|works)\b",
                      r"(?<!not )(?<!no )\bregulatory(ly)? (approved|accepted)\b"]
TIMING_KEYS = {"seconds_at_500k_rows", "scaling_exponent"}


def norm(name: str) -> str:
    name = re.sub(r"\(.*?\)", "", name).strip()
    name = name.replace("\u2013", "-").replace("\u2014", "-")
    return re.sub(r"[^a-z0-9]", "", name.lower())


def manifest():
    return {norm(x) for x in (HERE / "corpus_manifest.txt").read_text(encoding="utf-8").splitlines() if x.strip()}


def is_corpus_ref(ref: str) -> bool:
    core = re.sub(r"\(.*?\)", "", ref).strip()
    return core.endswith(".pdf") or core.endswith(".md") or core.endswith(".tex")


def run_tests(seeds):
    runs = {}
    for seed in seeds:
        runs[seed] = []
        for t in A.ALL_TESTS:
            t0 = time.perf_counter()
            r = t(seed)
            r["seconds"] = round(time.perf_counter() - t0, 3)
            r["seed"] = seed
            runs[seed].append(r)
    return runs


def meta_tests(runs):
    man = manifest()
    results = []
    by_id = {}
    for seed, rs in runs.items():
        for r in rs:
            by_id.setdefault(r["id"], []).append(r)

    # M01
    reg = json.loads((HERE / "claims_register.json").read_text(encoding="utf-8"))
    problems = []
    for c in reg["claims"]:
        if not c["tests"]:
            problems.append(f"{c['id']}: no test")
        for t in c["tests"]:
            if t not in by_id:
                problems.append(f"{c['id']}: unknown test {t}")
            elif not all(r["passed"] for r in by_id[t]):
                problems.append(f"{c['id']}: test {t} failed on some seed")
        for ref in c["corpus"]:
            if norm(ref) not in man:
                problems.append(f"{c['id']}: corpus ref not in manifest: {ref}")
    for tid, rs in by_id.items():
        for ref in rs[0]["corpus"]:
            if is_corpus_ref(ref) and norm(ref) not in man:
                problems.append(f"{tid}: corpus ref not in manifest: {ref}")
    results.append({"id": "M01", "title": "Claims register integrity", "passed": not problems,
                    "problems": problems, "claims": len(reg["claims"])})

    # M02
    problems = []
    if not REPORT.exists():
        problems.append("report missing")
    else:
        txt = REPORT.read_text(encoding="utf-8")
        cited = set(re.findall(r"`([^`]+?\.(?:pdf|md|tex))`", txt))
        own = {"RG_Adoption_Cost_Assurance_Report.md", "README.md", "cost_summary_example.md", "summary.md"}
        for c in sorted(cited):
            if c in own or c.startswith("results/"):
                continue
            if norm(c) not in man:
                problems.append(f"cited but not in corpus manifest: {c}")
        for tid in by_id:
            if not re.search(rf"\b{tid}\b", txt):
                problems.append(f"test {tid} not referenced in report")
        for s in STALE:
            if s.lower() in txt.lower():
                problems.append(f"stale statement present: {s}")
        for pat in OVERCLAIM_PATTERNS:
            m = re.search(pat, txt, flags=re.IGNORECASE)
            if m:
                problems.append(f"over-claim pattern: '{m.group(0)}'")
        results.append({"id": "M02", "title": "Report citations and claims", "passed": not problems,
                        "problems": problems, "corpus_files_cited": len(cited)})
    if not REPORT.exists():
        results.append({"id": "M02", "title": "Report citations and claims", "passed": False, "problems": problems})

    # M03
    problems = []
    for t in (A.t01_product_ambiguity, A.t13_false_lock_budget, A.t16_prior_not_forgotten, A.t21_value_of_information):
        a, b = t(PRIMARY_SEED), t(PRIMARY_SEED)
        ma = {k: v for k, v in a["metrics"].items() if k not in TIMING_KEYS}
        mb = {k: v for k, v in b["metrics"].items() if k not in TIMING_KEYS}
        if json.dumps(ma, sort_keys=True) != json.dumps(mb, sort_keys=True):
            problems.append(f"{a['id']} not deterministic")
    results.append({"id": "M03", "title": "Determinism under fixed seed", "passed": not problems, "problems": problems})

    # M04
    problems = []
    for tid, rs in by_id.items():
        for r in rs:
            teeth = [k for k in r["checks"] if k.startswith("teeth_")]
            if r["verdict"] in ("SHARPENED", "CONFIRMED") and not any(r["checks"][k] for k in teeth):
                problems.append(f"{tid} seed {r['seed']}: {r['verdict']} without a counterexample")
            if r["verdict"] == "HOLDS" and teeth:
                problems.append(f"{tid}: has teeth checks but verdict HOLDS")
    results.append({"id": "M04", "title": "Every SHARPENED/CONFIRMED verdict has a counterexample", "passed": not problems,
                    "problems": problems})
    return results


def summarize(runs, metas):
    lines = ["# Battery summary", "",
             f"Seeds: {', '.join(str(s) for s in runs)} (primary {PRIMARY_SEED})", "",
             "| ID | Title | Verdict | Passed on all seeds | Counterexample (primary seed) |",
             "|---|---|---|---|---|"]
    first = runs[next(iter(runs))]
    for i, r in enumerate(first):
        allp = all(runs[s][i]["passed"] for s in runs)
        verdicts = {runs[s][i]["verdict"] for s in runs}
        v = "/".join(sorted(verdicts))
        ce = (r["counterexample"] or "-").replace("|", "/")
        lines.append(f"| {r['id']} | {r['title']} | {v} | {'yes' if allp else 'NO'} | {ce} |")
    lines += ["", "| Meta | Title | Passed | Problems |", "|---|---|---|---|"]
    for m in metas:
        lines.append(f"| {m['id']} | {m['title']} | {'yes' if m['passed'] else 'NO'} | "
                     f"{'; '.join(m.get('problems', [])) or '-'} |")
    return "\n".join(lines) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, nargs="*", default=None)
    ap.add_argument("--quick", action="store_true")
    a = ap.parse_args()
    seeds = [PRIMARY_SEED] if a.quick else (a.seeds or SEEDS)
    runs = run_tests(seeds)
    metas = meta_tests(runs)
    out = HERE / "results"; out.mkdir(exist_ok=True)
    payload = {
        "battery": "RG Adoption Cost Assurance -- hostile battery", "version": "1.0",
        "environment": {"python": platform.python_version(), "numpy": np.__version__,
                        "scipy": scipy.__version__, "mpmath": mpmath.__version__},
        "seeds": seeds, "tests": {str(s): runs[s] for s in runs}, "meta": metas,
    }
    raw = json.dumps(payload, indent=2, default=str)
    (out / "battery_results.json").write_text(raw, encoding="utf-8")
    (out / "summary.md").write_text(summarize(runs, metas), encoding="utf-8")
    all_ok = all(r["passed"] for rs in runs.values() for r in rs) and all(m["passed"] for m in metas)
    n_tests = sum(len(rs) for rs in runs.values())
    n_pass = sum(r["passed"] for rs in runs.values() for r in rs)
    print(f"attacks passed {n_pass}/{n_tests} across {len(seeds)} seed(s); "
          f"meta {sum(m['passed'] for m in metas)}/{len(metas)}")
    for m in metas:
        if not m["passed"]:
            print(m["id"], m["problems"])
    print("results sha256:", hashlib.sha256(raw.encode()).hexdigest()[:16])
    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
