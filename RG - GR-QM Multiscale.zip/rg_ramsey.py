"""Synthetic shot-noise Ramsey ladder, nuisance offset and abstention gates.
Run python rg_ramsey.py. No laboratory records are generated or claimed.
"""
from pathlib import Path
import json,csv,hashlib
import numpy as np
from scipy.optimize import least_squares
from scipy.constants import c
OUT=Path(__file__).resolve().parent
rng=np.random.default_rng(20261032)
C=.8; alpha_true=.01; b_true=.03; rate=2*np.pi*429e12*9.81/c**2
records=[]; designs=[]
for height in [.01,.1,1,10]:
 for t in [.1,1,10]:
  for shots in [100,1000,10000]:
   z=height*np.array([-2,-1,0,1,2.]); x=rate*t*z
   def prob(a,b): return .5*(1+C*np.sin(x*a+b))
   pp=prob(alpha_true,b_true); D=.5*C*np.cos(x*alpha_true+b_true)[:,None]*np.column_stack([x,np.ones(5)])
   F=shots*D.T@(D/(pp*(1-pp))[:,None]); cov=np.linalg.inv(F); se=np.sqrt(cov[0,0]); cond=np.linalg.cond(F)
   admitted=bool(se<.02 and cond<1e8 and max(abs(x))*.1<np.pi)
   zs=[]; covered=[]; boundary=0
   for trial in range(200):
    counts=rng.binomial(shots,pp); yy=counts/shots
    if admitted:
     def resid(v): return (prob(*v)-yy)*np.sqrt(shots/(pp*(1-pp)))
     fit=least_squares(resid,[0,0],bounds=([-.1,-.2],[.1,.2]),xtol=1e-11,ftol=1e-11,gtol=1e-11)
     a,b=fit.x; zz=(a-alpha_true)/se; zs.append(float(zz)); covered.append(abs(zz)<1.959963984540054)
     boundary+=int(abs(a)>.0999 or abs(b)>.1999)
     records.append(dict(height_m=height,time_s=t,shots=shots,trial=trial,status='ADMITTED',alpha_hat=float(a),offset_hat=float(b),fisher_se=float(se),z=float(zz)))
    else:
     records.append(dict(height_m=height,time_s=t,shots=shots,trial=trial,status='ABSTAIN',alpha_hat='',offset_hat='',fisher_se=float(se),z=''))
   designs.append(dict(height_m=height,time_s=t,shots=shots,admitted=admitted,fisher_se=float(se),fisher_condition=float(cond),phase_bandwidth=float(max(abs(x))*.1),coverage=float(np.mean(covered)) if covered else None,standardized_bias=float(np.mean(zs)) if zs else None,boundary_fits=boundary))
with (OUT/'rg_ramsey_runs.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0])); w.writeheader(); w.writerows(records)
ad=[v for v in designs if v['admitted']]
res=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),seed=20261032,synthetic_trials=len(records),designs=designs,admitted_designs=len(ad),abstained_designs=len(designs)-len(ad),checks=[dict(name='R01 finite Fisher variances',passed=all(np.isfinite(v['fisher_se']) and v['fisher_se']>0 for v in designs)),dict(name='R02 nonvacuous admission and abstention',passed=0<len(ad)<len(designs)),dict(name='R03 admitted fits stay interior',passed=sum(v['boundary_fits'] for v in ad)==0)],scope='Known contrast and shot noise; local alpha band [-0.1,0.1]; nominal phase actively compensated; offset fitted. Fisher weights evaluated at synthetic truth for calibration.')
res['passed']=sum(v['passed'] for v in res['checks']); res['total_checks']=len(res['checks'])
(OUT/'rg_ramsey_results.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n')
print(json.dumps(res,indent=2)); assert res['passed']==res['total_checks']
