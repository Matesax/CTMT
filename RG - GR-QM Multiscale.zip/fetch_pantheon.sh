#!/bin/sh
# Downloads the public Pantheon+ distance and covariance files used by rg_gr_naturality_data.py
mkdir -p data
B="https://raw.githubusercontent.com/PantheonPlusSH0ES/DataRelease/main/Pantheon%2B_Data/4_DISTANCES_AND_COVAR"
curl -sSfL -o data/pantheon.dat "$B/Pantheon%2BSH0ES.dat"
curl -sSfL -o data/pantheon.cov "$B/Pantheon%2BSH0ES_STAT%2BSYS.cov"
sha256sum data/pantheon.dat data/pantheon.cov
# expected:
# 1cb0fc379ef066afdc2ffd1857681cc478024570d8a3eba284fb645775198cf8  data/pantheon.dat
# abf806d966485e64afdb359c87bffc0ecc00d05eff0a31ced66f247385df0fdc  data/pantheon.cov
