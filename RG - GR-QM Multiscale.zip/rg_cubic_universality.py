"""Cubic-vertex universality lock for a single massless spin-2 field (declared class).
Method: nontrivial local cubic vertices modulo total derivatives and field redefinitions correspond to gauge-invariant
on-shell three-point structures (imported equivalence). On-shell massless 3-point kinematics: k_i^2 = k_i.k_j = 0,
polarizations eps_i = e_i e_i with e_i.k_i = e_i.e_i = 0, momentum conservation. Independent invariants:
  e1.e2, e2.e3, e3.e1, x1 = e1.k2, x2 = e2.k3, x3 = e3.k1   (e1.k3 = -x1, e2.k1 = -x2, e3.k2 = -x3).
U1  complete parity-even Bose-symmetric ansatz with n momenta (n = 0..8), degree 2 in each e_i; impose linearized gauge
    invariance e_i -> e_i + lam k_i on every leg; nullspace dimension per n.
U2  identify the solutions: n=2 = (YM)^2 (Einstein-Hilbert), n=4 = YM*F3 (Gauss-Bonnet), n=6 = (F3)^2 (R^3).
U3  four dimensions: explicit complex spinor-helicity kinematics, all helicity configurations: the n=4 structure vanishes
    identically (Gauss-Bonnet is topological in 4D); n=2 and n=6 do not.
U4  coupling normalization: the n=2 space is one-dimensional, so the vertex is unique up to the coupling scale.
Run: python rg_cubic_universality.py   (sympy, numpy)
"""
import itertools, json, hashlib, pathlib
import sympy as sp
import numpy as np

e12, e23, e31, x1, x2, x3 = sp.symbols("e12 e23 e31 x1 x2 x3")
lam = sp.Symbol("lam")
RES = {}
def must(c, m):
    if not c: raise AssertionError(m)

def monomials(n):
    out = []
    for a, b, c in itertools.product(range(3), repeat=3):
        xa, xb, xc = 2 - a - c, 2 - a - b, 2 - b - c            # degrees of x1, x2, x3 fixed by e-degrees
        if min(xa, xb, xc) < 0 or xa + xb + xc != n: continue
        out.append(e12 ** a * e23 ** b * e31 ** c * x1 ** xa * x2 ** xb * x3 ** xc)
    return out

# leg-1 gauge variation: e1 -> e1 + lam k1. Effects on invariants (first order in lam):
#   e12 = e1.e2 -> + lam k1.e2 = -lam x2 ; e31 = e3.e1 -> + lam e3.k1 = + lam x3 ; x1 = e1.k2 -> + lam k1.k2 = 0
#   and the e1.k3 = -x1 relation is preserved. Analogous cyclic rules for legs 2 and 3.
gauge = {
    1: {e12: e12 - lam * x2, e31: e31 + lam * x3},
    2: {e23: e23 - lam * x3, e12: e12 + lam * x1},
    3: {e31: e31 - lam * x1, e23: e23 + lam * x2},
}
# Bose symmetry generators: cyclic (1->2->3) and transposition (1<->2) with momentum relabelling:
cyc = {e12: e23, e23: e31, e31: e12, x1: x2, x2: x3, x3: x1}
# swap 1<->2: e12->e12, e23->e31, e31->e23; x1 = e1.k2 -> e2.k1 = -x2 ; x2 = e2.k3 -> e1.k3 = -x1 ; x3 = e3.k1 -> e3.k2 = -x3
swp = {e12: e12, e23: e31, e31: e23, x1: -x2, x2: -x1, x3: -x3}
def act(expr, rule): return sp.expand(expr.subs(rule, simultaneous=True))

def solve(n):
    mons = monomials(n)
    if not mons: return 0, [], mons
    cs = sp.symbols(f"c0:{len(mons)}"); V = sum(c * m for c, m in zip(cs, mons))
    eqs = []
    for leg in (1, 2, 3):
        dV = sp.diff(sp.expand(V.subs(gauge[leg], simultaneous=True)), lam).subs(lam, 0)
        eqs += sp.Poly(sp.expand(dV), e12, e23, e31, x1, x2, x3).coeffs()
    for rule in (cyc, swp):
        eqs += sp.Poly(sp.expand(act(V, rule) - V), e12, e23, e31, x1, x2, x3).coeffs()
    A = sp.Matrix([[sp.diff(q, c) for c in cs] for q in eqs]) if eqs else sp.zeros(0, len(cs))
    ns = A.nullspace()
    sols = [sp.factor(sum(v[i] * mons[i] for i in range(len(mons)))) for v in ns]
    return len(ns), sols, mons

YM = e12 * x3 + e23 * x1 + e31 * x2          # Yang-Mills 3-point (gauge-invariant, antisymmetric up to sign)
F3 = x1 * x2 * x3
targets = {2: sp.expand(YM ** 2), 4: sp.expand(YM * F3), 6: sp.expand(F3 ** 2)}
table = {}
for n in range(0, 9):
    dim, sols, mons = solve(n)
    match = None
    if dim == 1 and n in targets:
        ratio = sp.simplify(sp.expand(sols[0]) / targets[n]); match = str(ratio) if ratio.is_number else None
    table[n] = dict(ansatz_size=len(mons), gauge_invariant_symmetric_dim=dim, solution=str(sols[0]) if sols else None,
                    proportional_to_target=match)
expected = {0: 0, 1: 0, 2: 1, 3: 0, 4: 1, 5: 0, 6: 1, 7: 0, 8: 0}
must(all(table[n]["gauge_invariant_symmetric_dim"] == expected[n] for n in expected), f"U1 dims {table}")
must(all(table[n]["proportional_to_target"] is not None for n in (2, 4, 6)), "U2 identification")
RES["U1_U2"] = dict(claim="Complete parity-even on-shell cubic ansatz: gauge-invariant, Bose-symmetric spin-2 vertices",
                    status="LOCKED: exactly one vertex at 2, 4 and 6 derivatives, none otherwise (n <= 8)",
                    table={str(k): v for k, v in table.items()},
                    identification={"2": "Einstein-Hilbert = (YM)^2", "4": "Gauss-Bonnet = YM * F3", "6": "R^3 = (F3)^2"})

# ------------------------------------------------ U3 four-dimensional kinematics (complex spinor helicity)
rng = np.random.default_rng(20261107)
sig = [np.eye(2), np.array([[0, 1], [1, 0]]), np.array([[0, -1j], [1j, 0]]), np.diag([1, -1])]
def vec(lam_, lt):
    """p_mu from p_{a adot} = lam_a lt_adot with mostly-minus metric conventions folded into the dot product below"""
    M = np.outer(lam_, lt); return np.array([0.5 * np.trace(M @ s) for s in sig])
def dot(a, b): return a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3]
def kinematics(degenerate):
    """three complex massless momenta summing to zero; degenerate='lt' makes all tilde-spinors proportional"""
    if degenerate == "lt":
        lt0 = rng.normal(size=2) + 1j * rng.normal(size=2)
        l1, l2 = rng.normal(size=2) + 1j * rng.normal(size=2), rng.normal(size=2) + 1j * rng.normal(size=2)
        c1, c2 = rng.normal() + 1j * rng.normal(), rng.normal() + 1j * rng.normal()
        l3 = -(c1 * l1 + c2 * l2); lts = [c1 * lt0, c2 * lt0, lt0]; lams = [l1, l2, l3]
    else:
        l0 = rng.normal(size=2) + 1j * rng.normal(size=2)
        t1, t2 = rng.normal(size=2) + 1j * rng.normal(size=2), rng.normal(size=2) + 1j * rng.normal(size=2)
        c1, c2 = rng.normal() + 1j * rng.normal(), rng.normal() + 1j * rng.normal()
        t3 = -(c1 * t1 + c2 * t2); lams = [c1 * l0, c2 * l0, l0]; lts = [t1, t2, t3]
    return lams, lts
def pol(lam_, lt, h, ref_l, ref_lt):
    if h > 0: return vec(ref_l, lt) / (ref_l[0] * lam_[1] - ref_l[1] * lam_[0])
    return vec(lam_, ref_lt) / (lt[0] * ref_lt[1] - lt[1] * ref_lt[0])
vals = {}
for degenerate in ("lt", "l"):
    for hel in itertools.product((1, -1), repeat=3):
        lams, lts = kinematics(degenerate)
        ks = [vec(l, t) for l, t in zip(lams, lts)]
        mom = np.max(np.abs(sum(ks)))
        rl, rlt = rng.normal(size=2) + 1j * rng.normal(size=2), rng.normal(size=2) + 1j * rng.normal(size=2)
        es = [pol(l, t, h, rl, rlt) for l, t, h in zip(lams, lts, hel)]
        sub = {e12: dot(es[0], es[1]), e23: dot(es[1], es[2]), e31: dot(es[2], es[0]),
               x1: dot(es[0], ks[1]), x2: dot(es[1], ks[2]), x3: dot(es[2], ks[0])}
        scale = max(abs(complex(v)) for v in sub.values()) or 1
        ev = {n: abs(complex(targets[n].subs(sub))) / scale ** (3 if n == 2 else (4 if n == 4 else 3)) for n in (2, 4, 6)}
        vals[f"{degenerate}:{''.join('+' if h > 0 else '-' for h in hel)}"] = dict(momentum_residual=float(mom), **{str(k): float(v) for k, v in ev.items()})
gb_max = max(v["4"] for v in vals.values())
gr_max = max(v["2"] for v in vals.values()); r3_max = max(v["6"] for v in vals.values())
must(gb_max < 1e-9 and gr_max > 1e-3 and r3_max > 1e-3, f"U3 {gb_max} {gr_max} {r3_max}")
RES["U3"] = dict(claim="In four dimensions the 4-derivative (Gauss-Bonnet) cubic structure vanishes on every helicity configuration",
                 status="LOCKED (complex spinor-helicity kinematics, both degenerate branches, all 8 helicity choices)",
                 max_normalized={"GR (n=2)": gr_max, "GB (n=4)": gb_max, "R^3 (n=6)": r3_max}, samples=vals)
RES["U4"] = dict(claim="At two derivatives the vertex is unique up to the coupling scale",
                 status="LOCKED (dimension 1 at n = 2; the scale is the unit anchor kappa = sqrt(32 pi G))")
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_cubic_universality_results.json").write_text(json.dumps(RES, indent=1, default=str))
for n, v in table.items(): print(n, v["ansatz_size"], v["gauge_invariant_symmetric_dim"], v["proportional_to_target"])
print("4D:", RES["U3"]["max_normalized"])
