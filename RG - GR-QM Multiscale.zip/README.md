# Resolution Geometry: Multi-Scale GR-QM Experimental Protocols

Full standalone paper and executed numerical research bundle. All generated outcomes are synthetic. Published summary values are transcribed from the supplied manuscript, not independently fetched or reanalysed.

## Deliverables
- rg_grqm_multiscale.tex and rg_grqm_multiscale.pdf: complete paper, not a change log.
- rg_multiscale.py: 13 numerical families, 1,415 exported rows, 24 aggregate checks.
- rg_stress.py: 600 randomized cases across five seeds and dimensions 2/3/4; eight aggregate checks, including eight mutation witnesses; 60,000 standardized power draws.
- rg_ramsey.py: 36 binomial designs, 200 trials each, 7,200 records; nine admitted designs, 27 abstentions; three structural checks.
- JSON results, CSV records, figure, protocol specification, development audit, reproduction check, and verification script.
- rg_cubic_universality.py and its result/log: supplied supporting battery, executed unmodified; not included in the 35 new aggregate checks.
- rg_rigidity.py and fetch_pantheon.sh: supplied reference scripts. Rigidity was NOT rerun because its frozen C0 JSON and hash were absent. Pantheon data were NOT downloaded or refitted.

## Reproduce
Use Python with packages listed in requirements.txt. The delivered environment versions are pinned for reference; no automatic package installation or network access is performed.

    python run_all.py

Or run each script separately. The main script supports --out DIRECTORY; the two supplemental scripts write beside their source. Verification without rerunning:

    python verify_results.py

Typeset the paper with standard pdfLaTeX packages and the supplied PNG beside the TEX:

    pdflatex -interaction=nonstopmode rg_grqm_multiscale.tex
    pdflatex -interaction=nonstopmode rg_grqm_multiscale.tex

The provided PDF has already been compiled and visually checked. Main/stress JSON and CSV outputs were repeated and byte-compared in this environment. Cross-platform byte identity and Ramsey repeat-byte identity were not asserted.

## Interpret correctly
35/35 refers to aggregate software checks, not 35 independent experiments or empirical confirmations. Some checks confirm non-identifiability or failed recovery. Ramsey coverage is reported, not assumed exact: admitted design coverages range 0.915-0.965 with 200 trials each. Known contrast, truth-based Fisher weights, and a local parameter band limit the calibration.

The six-row summary audit Q=3.3714156, df=6, p=0.7609912 is conditional on fixed anchors, independent Gaussian errors, and the selected supplied summaries. It is not a validated global likelihood. Neutron ratio/scale covariance is retained conceptually; the shape row is not double-counted. Cosmology is a separate conditional contrast, not a raw-data fit. No empirical RG-versus-GR discrimination follows from using the same physical predictions.

The paper separates joint unitary reversal, sufficient-family Petz recovery, and generic reduced-channel information loss. A missing revival is not fundamental irreversibility. No quantum-gravity derivation or contemporary experimental-status claim is made.

## Provenance
The main specification and every executable source have SHA-256 provenance in results. SHA256SUMS.txt covers the delivered bundle files. Hash freezing is not independent preregistration. Development corrections are documented in rg_execution_audit.txt and the paper. Supplied reference files remain unmodified.
