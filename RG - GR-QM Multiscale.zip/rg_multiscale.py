"""RG GR-QM multiscale protocol battery. All generated records are SYNTHETIC.
Published summary inputs are transcribed from the supplied manuscript, not fetched.
Run: python rg_multiscale.py --out .  (NumPy, SciPy, Matplotlib)
"""
import argparse, csv, hashlib, json, math, platform, sys
from pathlib import Path
import numpy as np
import scipy
from scipy.constants import c,h,hbar,k as kB, neutron_mass, electron_volt
from scipy.special import ai_zeros
from scipy.linalg import eigh_tridiagonal
from scipy.integrate import quad, cumulative_trapezoid
from scipy.stats import chi2
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
SEED=20261030
SPEC={
 'seed':SEED,'data_policy':'Synthetic simulations and supplied summary inputs only; no new physical observations.',
 'clock_heights_m':[1e-3,0.01,0.33,1,10,100,1000],
 'airy_g_m_s2':[0.1,1,9.805,100], 'airy_grids':[200,400,800,1600],
 'decoherence_N':[1,2,10,100,10000,100000000],
 'frequency_samples':[6,7,12,24,48,96], 'frequency_separations':[0.001,0.01,0.1,0.5],
 'noise_sigma':[0.001,0.01,0.05], 'monte_carlo_trials':1000,
 'thresholds':{'unitary':1e-11,'choi_min':-1e-11,'trace':1e-11,'airy_finest_relative':1e-4,'recovery':1e-11},
 'status':'Design frozen before executing the numerical families; not an independent preregistration.'}

def main(out):
 out=Path(out); out.mkdir(parents=True,exist_ok=True)
 specbytes=(json.dumps(SPEC,sort_keys=True,indent=2)+'\n').encode(); (out/'rg_protocol_spec.json').write_bytes(specbytes)
 rng=np.random.default_rng(SEED); rows=[]; tests=[]; summary={}
 def row(b,**kw): rows.append(dict(battery=b,**kw))
 def check(name,condition,value=None):
  tests.append(dict(name=name,passed=bool(condition),value=value))
 def herm(A): return (A+A.conj().T)/2
 def trnorm(A): return float(np.abs(np.linalg.eigvalsh(herm(A))).sum())
 # B01: stable exact Schwarzschild redshift, weak-field and time-normalization invariance.
 mu=3.986004418e14; R=6378137.; g=9.796
 errs=[]; inv=[]
 for z in SPEC['clock_heights_m']:
  a=2*mu/(c*c*R); b=2*mu/(c*c*(R+z))
  # sqrt((1-b)/(1-a))-1 evaluated without cancellation.
  d=(2*mu*z/(c*c*R*(R+z)))/(1-a); exact=d/(np.sqrt(1+d)+1)
  weak=mu*z/(c*c*R*(R+z)); local=mu*z/(c*c*R*R)
  errs.append(abs(exact/weak-1))
  for scale in [0.01,1,100]:
   N0=np.sqrt(1-a)/scale; N1=np.sqrt(1-b)/scale
   # ratio alone is only accurate to absolute machine precision.
   inv.append(abs((N1/N0-1)-exact))
  row('B01',height_m=z,exact_fraction=exact,weak_fraction=weak,constant_g_fraction=local)
 check('B01 relational lapse invariance',max(inv)<1e-14,max(inv))
 check('B01 weak-field truncation',max(errs)<2e-9,max(errs))
 summary['B01']={'max_ratio_absolute_error':max(inv),'max_weak_relative_error':max(errs)}
 # B02: independent finite-difference Airy solver in dimensionless x=z/z0.
 aa=-ai_zeros(4)[0]; fd=[]
 for n in SPEC['airy_grids']:
  L=30.; dx=L/(n+1); x=dx*np.arange(1,n+1)
  eig=eigh_tridiagonal(2/dx**2+x,-np.ones(n-1)/dx**2,select='i',select_range=(0,3))[0]
  er=float(np.max(abs(eig/aa-1))); fd.append(er)
  for gg in SPEC['airy_g_m_s2']:
   E0=(hbar*hbar*neutron_mass*gg*gg/2)**(1/3)
   row('B02',grid=n,g_m_s2=gg,max_relative_error=er,f13_Hz=(eig[2]-eig[0])*E0/h,shape=(eig[3]-eig[0])/(eig[2]-eig[0]))
 check('B02 grid convergence',all(np.diff(fd)<0),fd)
 check('B02 finest-grid tolerance',fd[-1]<SPEC['thresholds']['airy_finest_relative'],fd[-1])
 order=float(np.polyfit(np.log(np.array(SPEC['airy_grids'])+1),np.log(fd),1)[0])
 E0=(hbar*hbar*neutron_mass*9.805**2/2)**(1/3)
 f13=float((aa[2]-aa[0])*E0/h); f14=float((aa[3]-aa[0])*E0/h)
 summary['B02']={'airy_zeros':aa.tolist(),'errors':fd,'convergence_slope':order,'f13_Hz':f13,'f14_Hz':f14,'ratio':float((aa[3]-aa[0])/(aa[2]-aa[0])),'levels_peV':(aa*E0/electron_volt*1e12).tolist()}
 # B03: spectrum scale degeneracy in g, gravitational mass and inertial mass.
 J=np.tile([2/3,2/3,-1/3],(3,1)); singular=np.linalg.svd(J,compute_uv=False)
 scale=[]
 for q in [0.5,0.8,1,1.2,2]:
  # g -> q g, mg -> mg/q preserves all levels.
  s=((q*9.805)**2*(neutron_mass/q)**2/neutron_mass)**(1/3)
  scale.append(s)
  row('B03',q=q,relative_scale=s/scale[0])
 check('B03 mass-gravity degeneracy',np.linalg.matrix_rank(J)==1 and np.ptp(scale)/scale[0]<1e-12,float(np.ptp(scale)/scale[0]))
 summary['B03']={'log_parameter_jacobian_rank':int(np.linalg.matrix_rank(J)),'singular_values':singular.tolist(),'identified_combination':'(mg*g)^2/mi'}
 # B04: local two-tone identifiability and exact Nyquist aliases.
 conditions=[]; ranks={}
 for n in SPEC['frequency_samples']:
  t=np.arange(n,dtype=float)
  for sep in SPEC['frequency_separations']:
   w1=.7; w2=.7+sep; A1=.8; B1=.2; A2=.5; B2=-.3
   J=np.column_stack([np.ones(n),np.cos(w1*t),np.sin(w1*t),np.cos(w2*t),np.sin(w2*t),t*(-A1*np.sin(w1*t)+B1*np.cos(w1*t)),t*(-A2*np.sin(w2*t)+B2*np.cos(w2*t))])
   sv=np.linalg.svd(J,compute_uv=False); rank=int(np.linalg.matrix_rank(J)); cond=float(sv[0]/sv[-1])
   row('B04',samples=n,separation_rad=sep,rank=rank,condition=cond)
   ranks[f'{n}:{sep}']=rank; conditions.append(cond)
 t=np.arange(24); alias=float(np.max(abs(np.cos(.7*t)-np.cos((2*np.pi-.7)*t))))
 check('B04 six samples underdetermined',all(ranks[f'6:{s}']<=6 for s in SPEC['frequency_separations']))
 check('B04 seven separated samples full local rank',ranks['7:0.5']==7,ranks['7:0.5'])
 check('B04 unrestricted-frequency alias',alias<1e-12,alias)
 summary['B04']={'max_condition':max(conditions),'alias_error':alias,'warning':'Full local rank is not global uniqueness or noise robustness; bandwidth and separation gates required.'}
 # B05: controlled clock unitary, Choi positivity and reversal with accessible clock.
 plus=np.ones(2)/np.sqrt(2); rho=np.outer(plus,plus); rjoint=np.kron(rho,rho)
 cpmins=[]; rev=[]; reduced=[]
 for phi in np.linspace(0,4*np.pi,101):
  U=np.diag([1,1,1,np.exp(-1j*phi)])
  joint=U@rjoint@U.conj().T
  reducedrho=np.trace(joint.reshape(2,2,2,2),axis1=1,axis2=3)
  kap=(1+np.exp(1j*phi))/2
  choi=np.array([[1,0,0,kap],[0,0,0,0],[0,0,0,0],[kap.conjugate(),0,0,1]],complex)/2
  cpmins.append(float(np.linalg.eigvalsh(choi).min()))
  rev.append(trnorm(U.conj().T@joint@U-rjoint))
  reduced.append(float(2*abs(reducedrho[0,1])))
  row('B05',phase=phi,visibility=reduced[-1],choi_min=cpmins[-1],joint_reversal_error=rev[-1])
 # At pi, |+> and |-> path states have identical reduced outputs.
 check('B05 reduced channel CP',min(cpmins)>-1e-11,min(cpmins))
 check('B05 joint reversal',max(rev)<1e-11,max(rev))
 check('B05 complete reduced dephasing',reduced[25]<1e-12,reduced[25])
 summary['B05']={'choi_min':min(cpmins),'max_joint_reversal_error':max(rev),'reduced_visibility_at_pi':reduced[25],'reduced_universal_recovery':'impossible at complete dephasing: distinct inputs coincide'}
 # B06: identical-clock multiscale visibility and Gaussian limit.
 rel=[]
 for N in SPEC['decoherence_N']:
  for u in np.linspace(0,3,61):
   phase=u/np.sqrt(N)
   logv=N*np.log1p(-2*np.sin(phase/4)**2)
   gauss=-u*u/8
   err=abs(np.exp(logv)-np.exp(gauss))
   if N>=10000: rel.append(err)
   row('B06',N=N,scaled_time=u,visibility=np.exp(logv),gaussian=np.exp(gauss),absolute_error=err)
 omega=2*np.pi*429e12*9.81/c**2
 tau=np.sqrt(2)*hbar*c*c/(np.sqrt(1e23)*kB*300*9.81*1e-6)
 check('B06 large-N Gaussian convergence',max(rel)<1e-4,max(rel))
 summary['B06']={'Sr_1m_revival_s':float(2*np.pi/omega),'toy_macro_tau_s':float(tau),'large_N_max_absolute_error':max(rel),'model':'macro estimate assumes DeltaH=sqrt(N)*kBT, not a material prediction'}
 # B07: heterogeneous clock modes, thermal populations, and echo.
 n=64; detuning=rng.normal(0,.05,n); omega_modes=1+detuning
 vals=[]
 for beta in [0,1,5]:
  excited=1/(1+np.exp(beta*omega_modes))
  for tt in np.linspace(0,4*np.pi,201):
   fac=(1-excited)+excited*np.exp(-1j*omega_modes*tt)
   logv=np.log(np.maximum(abs(fac),1e-300)).sum(); v=float(np.exp(logv))
   row('B07',beta_gap=beta,time=tt,visibility=v)
  free=float(np.prod(abs((1-excited)+excited*np.exp(-1j*omega_modes*2*np.pi))))
  # Path swap changes sign of conditional coupling in second half.
  echo=float(np.prod(abs(np.exp(-1j*omega_modes*np.pi)*np.exp(1j*omega_modes*np.pi))))
  vals.append(dict(beta=beta,free_revival_visibility=free,ideal_echo_visibility=echo))
 check('B07 heterogeneous revival suppression',vals[0]['free_revival_visibility']<.9,vals[0]['free_revival_visibility'])
 check('B07 ideal echo restores coherence',min(v['ideal_echo_visibility'] for v in vals)>1-1e-12)
 summary['B07']={'modes':n,'relative_detuning_sigma':.05,'values':vals,'note':'Ideal static-noise echo; not an experimentally demonstrated gravity reversal.'}
 # B08: two-speed panel with nuisance profiling and rank failure controls.
 # dimensionless parameters alpha (lapse violation), delta_gamma (structure).
 for eps in [1e-16,1e-12,1e-8,1e-4]:
  slow=np.array([[1,eps],[2,2*eps],[3,3*eps]],float)
  full=np.vstack([slow,[1,1]])
  row('B08',v2_over_c2=eps,slow_rank=int(np.linalg.matrix_rank(slow)),panel_rank=int(np.linalg.matrix_rank(full)),panel_condition=float(np.linalg.cond(full)))
 check('B08 slow-only degeneracy',np.linalg.matrix_rank(slow)==1)
 check('B08 light restores panel rank',np.linalg.matrix_rank(full)==2)
 # Offset versus redshift slope: one height fails, symmetric ladder succeeds.
 Xbad=np.column_stack([np.ones(4),np.ones(4)]); Xgood=np.column_stack([np.ones(5),[-2,-1,0,1,2]])
 check('B08 height reversal removes offset degeneracy',np.linalg.matrix_rank(Xbad)==1 and np.linalg.matrix_rank(Xgood)==2)
 summary['B08']={'slow_rank':1,'combined_rank':2,'scope':'Declared linear response model, not a universal PPN inference.'}
 # B09: GPS design and eccentricity sweep, not empirical rows.
 W0=62636856.; r=26560000.; offset=(W0-1.5*mu/r)/c**2
 for e in [0,.001,.01,.02,.1]:
  amp=2*e*np.sqrt(mu*r)/c**2
  row('B09',eccentricity=e,amplitude_ns=amp*1e9)
 check('B09 GPS design scale',abs(offset-4.4647e-10)<1e-13,float(offset))
 summary['B09']={'r_m':r,'W0_m2_s2':W0,'offset':float(offset),'us_per_day':float(offset*86400*1e6),'eccentricity_002_ns':float(2*.02*np.sqrt(mu*r)/c**2*1e9)}
 # B10: synthetic clock-ladder estimator calibration and coverage.
 x=np.array([-2,-1,0,1,2.]); X=np.column_stack([np.ones(5),x]); inv=np.linalg.inv(X.T@X)
 mc=[]
 for sigma in SPEC['noise_sigma']:
  truth=np.array([.3,1.]); Y=X@truth[:,None]+rng.normal(0,sigma,(5,SPEC['monte_carlo_trials']))
  fit=inv@X.T@Y; se=sigma*np.sqrt(inv[1,1]); zz=(fit[1]-1)/se
  coverage=float(np.mean(abs(zz)<=1.959963984540054)); bias=float(np.mean(zz))
  mc.append(dict(sigma=sigma,coverage=coverage,standardized_bias=bias))
  row('B10',sigma=sigma,coverage=coverage,standardized_bias=bias,trials=SPEC['monte_carlo_trials'])
 check('B10 synthetic interval calibration',all(.92<v['coverage']<.98 and abs(v['standardized_bias'])<.12 for v in mc),mc)
 summary['B10']={'results':mc,'known_noise':True,'truth':'synthetic offset 0.3, slope 1; normalized height response'}
 # B11: FLRW distance quadrature and exact H0/absolute-magnitude degeneracy.
 om=.3153; zs=np.array([.01,.1,.5,1,2]); errs=[]
 for n in [100,400,1600,6400]:
  grid=np.linspace(0,2,n+1); integral=cumulative_trapezoid(1/np.sqrt(om*(1+grid)**3+1-om),grid,initial=0)
  for z in zs:
   ref=quad(lambda zz:1/np.sqrt(om*(1+zz)**3+1-om),0,z,epsabs=1e-13)[0]
   calc=np.interp(z,grid,integral); err=abs(calc/ref-1)
   row('B11',grid=n,z=z,relative_distance_error=err)
   if n==6400: errs.append(err)
 check('B11 FLRW quadrature convergence',max(errs)<1e-6,max(errs))
 H0a,H0b=70.,75.; M=-19.3; Mb=M+5*np.log10(H0b/H0a)
 deg=abs((Mb-5*np.log10(H0b))-(M-5*np.log10(H0a)))
 check('B11 H0-magnitude degeneracy',deg<1e-12,deg)
 summary['B11']={'finest_max_distance_relative_error':max(errs),'magnitude_degeneracy_error':float(deg),'raw_Pantheon_fit':'NOT RUN: raw data and covariance absent'}
 # B12: two-mass controlled-phase entanglement and dephasing threshold.
 def ptB(r): return r.reshape(2,2,2,2).transpose(0,3,2,1).reshape(4,4)
 def neg(r): return float(max(0,-np.minimum(np.linalg.eigvalsh(herm(ptB(r))),0).sum()))
 maxerr=0.; maxclass=0.; values=[]
 for phi in np.linspace(0,np.pi,51):
  v=np.array([1,1,1,np.exp(1j*phi)])/2; rr=np.outer(v,v.conj())
  for eta in [0,.25,.5,.75,1]:
   damp=np.array([[eta**((i//2!=j//2)+(i%2!=j%2)) for j in range(4)] for i in range(4)])
   nr=neg(rr*damp); row('B12',phase=phi,local_coherence=eta,negativity=nr)
   if eta==1: maxerr=max(maxerr,abs(nr-abs(np.sin(phi/2))/2))
   if phi==np.pi: values.append(dict(eta=eta,negativity=nr))
  # Explicit shared-randomness mixture of product phase rotations.
  classical=np.zeros((4,4),complex)
  for theta in [phi,-phi]:
   a=np.array([1,np.exp(1j*theta)])/np.sqrt(2); b=np.array([1,np.exp(-1j*theta)])/np.sqrt(2)
   v=np.kron(a,b); classical+=np.outer(v,v.conj())/2
  maxclass=max(maxclass,neg(classical))
 check('B12 controlled-phase analytic negativity',maxerr<1e-12,maxerr)
 check('B12 shared-randomness control separable',maxclass<1e-12,maxclass)
 summary['B12']={'analytic_error':maxerr,'classical_max_negativity':maxclass,'pi_phase_dephasing_sweep':values,'status':'Synthetic feasibility model; no mediator quantization claim from simulation.'}
 # B13: supplied summary-data audit; no claim of fresh source verification.
 observed=[('clock33cm',4.1e-17,1.6e-17,9.796*.33/c**2),('Galileo_alpha',.19e-5,2.48e-5,0),('neutron_f13',464.1,1.2,f13),('Cassini_gamma_minus_1',2.1e-5,2.3e-5,0),('B1913_ratio',.9983,.0016,1),('J0737_ratio',.999963,.000063,1)]
 z=[]
 for name,y,s,m in observed:
  zz=(y-m)/s; z.append(zz); row('B13',observable=name,observed=y,sigma=s,prediction=m,z=zz)
 q=float(np.dot(z,z)); pv=float(chi2.sf(q,6))
 # Summary ratio and scale share f13. Demonstrate delta-method covariance with explicit assumed f14 uncertainty.
 x=464.1; y=648.8; sx=1.2; sy=1.8 # sy is an ASSUMPTION for sensitivity, not sourced uncertainty.
 J=np.array([[1,0],[-y/x**2,1/x]]); C=J@np.diag([sx*sx,sy*sy])@J.T
 rho=float(C[0,1]/np.sqrt(C[0,0]*C[1,1]))
 # covariance-aware equivalent quadratic form in original vs transformed coordinates, first-order residuals.
 d=np.array([x-f13,y-f14]); raw=float(d@np.diag([1/sx**2,1/sy**2])@d); transformed=float((J@d)@np.linalg.inv(C)@(J@d))
 check('B13 covariance transform invariance',abs(raw-transformed)<1e-12,abs(raw-transformed))
 # Cosmology contrast is conditional on independence and quoted uncertainties.
 cosmoz=(.3326-.3153)/np.hypot(.019,.0073)
 summary['B13']={'conditional_six_row_chi2':q,'conditional_df':6,'conditional_p':pv,'max_abs_z':float(max(abs(np.array(z)))),'z':z,'cosmology_independent_fit_z':float(cosmoz),'assumed_f14_sigma_Hz':sy,'shape_scale_correlation_sensitivity':rho,'neutron_covariance_invariance_error':abs(raw-transformed),'qualification':'Conditional summary audit, not a validated joint likelihood; g uncertainty and cross-study covariance not supplied.'}
 # Export all rows with a union schema, deterministic ordering and no timestamps.
 keys=['battery']+sorted(set().union(*(r.keys() for r in rows))-{'battery'})
 with (out/'rg_multiscale_runs.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=keys); w.writeheader(); w.writerows(rows)
 result={'spec_sha256':hashlib.sha256(specbytes).hexdigest(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'seed':SEED,'environment':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__},'run_rows':len(rows),'checks':tests,'passed':sum(t['passed'] for t in tests),'total_checks':len(tests),'summary':summary}
 (out/'rg_multiscale_results.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
 # Quantitative plots, no custom styling.
 fig,ax=plt.subplots(2,2,figsize=(12,8))
 ns=np.array(SPEC['airy_grids']); ax[0,0].loglog(ns,fd,'o-'); ax[0,0].set(xlabel='Interior grid points',ylabel='Maximum relative level error',title='Airy convergence')
 for N in [1,10,10000]:
  rr=[r for r in rows if r['battery']=='B06' and r['N']==N]; ax[0,1].plot([r['scaled_time'] for r in rr],[r['visibility'] for r in rr],label=f'N={N}')
 ax[0,1].set(xlabel='Scaled phase u = sqrt(N) omega t',ylabel='Visibility',title='Finite-clock visibility'); ax[0,1].legend()
 for beta in [0,1,5]:
  rr=[r for r in rows if r['battery']=='B07' and r['beta_gap']==beta]; ax[1,0].plot([r['time'] for r in rr],[r['visibility'] for r in rr],label=f'beta gap={beta}')
 ax[1,0].set(xlabel='Dimensionless time',ylabel='Visibility',title='Heterogeneous clock modes'); ax[1,0].legend()
 for eta in [0,.5,.75,1]:
  rr=[r for r in rows if r['battery']=='B12' and r['local_coherence']==eta]; ax[1,1].plot([r['phase'] for r in rr],[r['negativity'] for r in rr],label=f'eta={eta}')
 ax[1,1].set(xlabel='Controlled phase (rad)',ylabel='Negativity',title='Entanglement and dephasing'); ax[1,1].legend()
 ax[0,0].set_xticks(ns, labels=[str(n) for n in ns]); ax[0,0].minorticks_off()
 fig.tight_layout(pad=1.5); fig.savefig(out/'rg_multiscale_overview.png',dpi=160); plt.close(fig)
 print(json.dumps({'passed':result['passed'],'total':len(tests),'rows':len(rows),'failed':[t for t in tests if not t['passed']],'summary':summary},indent=2))
 if result['passed']!=len(tests): sys.exit(1)
if __name__=='__main__':
 ap=argparse.ArgumentParser(); ap.add_argument('--out',default='.'); main(ap.parse_args().out)
