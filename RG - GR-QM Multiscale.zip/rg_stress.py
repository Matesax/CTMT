"""Independent randomized and adversarial GR-QM checks. Synthetic records only."""
import json,hashlib,csv,sys
from pathlib import Path
import numpy as np
from scipy.linalg import expm
from scipy.stats import norm
from scipy.constants import c,hbar
OUT=Path(__file__).resolve().parent
rng=np.random.default_rng(20261031)
rows=[]; checks=[]
def check(name,ok,value): checks.append(dict(name=name,passed=bool(ok),value=value))
def state(d):
 A=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d)); r=A@A.conj().T+.1*np.eye(d); return r/np.trace(r)
def fun(A,f):
 w,v=np.linalg.eigh((A+A.conj().T)/2); return (v*f(w))@v.conj().T
def entropy(r,s): return float(np.trace(r@(fun(r,np.log)-fun(s,np.log))).real)
def tn(A): return float(abs(np.linalg.eigvalsh((A+A.conj().T)/2)).sum())
unit=[]; cov=[]; petz=[]; gaps=[]; errs=[]; choi=[]
for seed in [101,202,303,404,505]:
 rng=np.random.default_rng(seed)
 for d in [2,3,4]:
  for trial in range(40):
   A=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d)); H=(A+A.conj().T)/2
   t=float(rng.uniform(-3,3)); lapse=float(rng.uniform(.1,2)); scale=float(10**rng.uniform(-2,2))
   U=expm(-1j*H*lapse*t); V=expm(-1j*H*(lapse/scale)*(scale*t))
   ue=float(np.linalg.norm(U.conj().T@U-np.eye(d))); ce=float(np.linalg.norm(U-V))
   unit.append(ue); cov.append(ce)
   # Exact Petz recovery for partial trace with a common product environment.
   rho=state(d); sigma=state(d); tau=state(2); X=np.kron(rho,tau); S=np.kron(sigma,tau)
   # N^*(Y)=Y tensor I; N(S)=sigma.
   Sh=fun(S,np.sqrt); sm=fun(sigma,lambda x:x**-.5)
   recovered=Sh@np.kron(sm@rho@sm,np.eye(2))@Sh
   pe=tn(recovered-X); petz.append(pe)
   # A dephasing channel is nonsufficient for generic noncommuting pairs.
   nr=np.diag(np.diag(rho)); ns=np.diag(np.diag(sigma)); sh=fun(sigma,np.sqrt); nsm=fun(ns,lambda x:x**-.5)
   rec=sh@np.diag(np.diag(nsm@nr@nsm))@sh
   gap=entropy(rho,sigma)-entropy(nr,ns); er=tn(rec-rho)
   gaps.append(gap); errs.append(er)
   rows.append(dict(seed=seed,d=d,trial=trial,unitary_error=ue,time_rescaling_error=ce,product_Petz_error=pe,dephasing_entropy_gap=gap,plain_Petz_error=er))
check('S01 randomized proper-time unitarity',max(unit)<1e-11,max(unit))
check('S02 time-normalization covariance',max(cov)<1e-11,max(cov))
check('S03 exact sufficient product Petz',max(petz)<1e-11,max(petz))
check('S04 data processing for dephasing',min(gaps)>-1e-11,min(gaps))
check('S05 generic reduced recovery not exact',max(errs)>.1,max(errs))
# Detection power, with the same known-noise slope estimator as B10.
rng=np.random.default_rng(20261031); power=[]
for effect in [0,.5,1,2,3,5]:
 z=rng.normal(effect,1,10000); rate=float(np.mean(abs(z)>norm.ppf(.975)))
 analytic=float(norm.cdf(-norm.ppf(.975)-effect)+norm.sf(norm.ppf(.975)-effect))
 power.append(dict(effect_standard_errors=effect,rejection_rate=rate,analytic_power=analytic))
check('S06 false-positive calibration',abs(power[0]['rejection_rate']-.05)<.015,power[0]['rejection_rate'])
check('S07 analytic power calibration',max(abs(v['rejection_rate']-v['analytic_power']) for v in power)<.02,max(abs(v['rejection_rate']-v['analytic_power']) for v in power))
# Eight intentionally wrong implementations / inference rules.
mut=[]
def mutation(name,detected,witness): mut.append(dict(name=name,detected=bool(detected),witness=witness))
# Proper-time phase with physical H= hbar*diag(0,omega).
omega=3.; t=.7; good=np.exp(-1j*omega*t); wrong=np.exp(-1j*hbar*omega*t)
mutation('omit_hbar_in_physical_phase',abs(good-wrong)>.1,float(abs(good-wrong)))
correct=9.81/c**2; wrong=9.81
mutation('omit_c_squared_in_redshift',abs(wrong/correct-1)>1e10,float(wrong/correct))
mu=3.986004418e14; r=26560000.; W=62636856.; good=(W-1.5*mu/r)/c**2; wrong=(W-mu/r)/c**2
mutation('omit_GPS_kinematic_term',abs(wrong-good)>1e-11,float(wrong-good))
# Partial transpose on a maximally entangled state.
b=np.array([1,0,0,1])/np.sqrt(2); bell=np.outer(b,b); pt=bell.reshape(2,2,2,2).transpose(0,3,2,1).reshape(4,4); mine=float(np.linalg.eigvalsh(pt).min())
mutation('positive_but_not_CP_transpose',mine<-.4,mine)
rp=np.array([[1,1],[1,1]])/2; rm=np.array([[1,-1],[-1,1]])/2
collision=float(np.linalg.norm(np.diag(np.diag(rp))-np.diag(np.diag(rm))))
mutation('claim_universal_reduced_recovery',collision<1e-12 and np.linalg.norm(rp-rm)>1,collision)
J=np.tile([2/3,2/3,-1/3],(3,1)); rank=int(np.linalg.matrix_rank(J))
mutation('infer_g_mg_mi_separately_from_spectrum',rank<3,rank)
x=464.1; y=648.8; sx=1.2; sy=1.8; A=np.array([[1,0],[-y/x**2,1/x]]); C=A@np.diag([sx*sx,sy*sy])@A.T
mutation('drop_shape_scale_covariance',abs(C[0,1])>1e-4,float(C[0,1]))
t=np.arange(7); er=float(np.max(abs(np.cos(.7*t)-np.cos((2*np.pi-.7)*t))))
mutation('seven_samples_imply_unrestricted_global_uniqueness',er<1e-12,er)
check('S08 mutation canaries',all(v['detected'] for v in mut),sum(v['detected'] for v in mut))
res=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),random_cases=len(rows),checks=checks,passed=sum(v['passed'] for v in checks),total_checks=len(checks),power=power,mutations=mut,max_unitary_error=max(unit),max_covariance_error=max(cov),max_sufficient_Petz_error=max(petz),min_entropy_gap=min(gaps),max_plain_Petz_error=max(errs))
(OUT/'rg_stress_results.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n')
with (OUT/'rg_stress_runs.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
print(json.dumps(res,indent=2)); sys.exit(0 if res['passed']==len(checks) else 1)
