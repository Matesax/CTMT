"""GR conditional naturality: light real-data tests of the declarations left by the universality lock.
D1  Pantheon+ supernovae (real public data, STAT+SYS covariance): Lambda measured; Lambda = 0 rejected; w; flat DGP vs LCDM.
D2  binary pulsars (published timing parameters): Peters-Mathews prediction of the orbital decay vs the measured intrinsic
    decay -> bound on any extra radiative channel (hidden radiating modes beyond the two TT modes).
D3  GW170817 / GRB 170817A (published delay, conservative distance): tensor speed bound; implied graviton-mass bound.
D4  Cassini (published gamma): structure channel; Brans-Dicke omega bound.
Run: python rg_gr_naturality_data.py   (numpy, scipy); data in ./data (downloaded from the Pantheon+ public release)
"""
import json, math, hashlib, pathlib
import numpy as np
from scipy.integrate import cumulative_trapezoid
from scipy.optimize import minimize_scalar, minimize
RES = {}
def must(c, m):
    if not c: raise AssertionError(m)

# ------------------------------------------------------------------ D1 Pantheon+
dat = pathlib.Path("data/pantheon.dat"); covf = pathlib.Path("data/pantheon.cov")
hdr = dat.read_text().splitlines()[0].split()
rows = [l.split() for l in dat.read_text().splitlines()[1:]]
col = {k: i for i, k in enumerate(hdr)}
z = np.array([float(r[col["zHD"]]) for r in rows]); zhel = np.array([float(r[col["zHEL"]]) for r in rows])
mb = np.array([float(r[col["m_b_corr"]]) for r in rows]); calib = np.array([int(r[col["IS_CALIBRATOR"]]) for r in rows])
raw = np.loadtxt(covf); n = int(raw[0]); C = raw[1:].reshape(n, n)
sel = (z > 0.01) & (calib == 0)
zs, zh, ms = z[sel], zhel[sel], mb[sel]; Cs = C[np.ix_(sel, sel)]
L = np.linalg.cholesky(Cs); Ci = np.linalg.inv(Cs); one = np.ones(len(zs)); s1 = one @ Ci @ one
zgrid = np.concatenate([[0.0], np.geomspace(1e-4, 2.5, 4000)])
def dl(Ez):
    """luminosity distance in units of c/H0 for E(z) evaluated on zgrid"""
    Dc = cumulative_trapezoid(1 / Ez, zgrid, initial=0.0)
    return np.interp(zs, zgrid, Dc)
def chi2_from_Dc(Dc, ok=0.0):
    if ok > 1e-8: Dm = np.sinh(math.sqrt(ok) * Dc) / math.sqrt(ok)
    elif ok < -1e-8: Dm = np.sin(math.sqrt(-ok) * Dc) / math.sqrt(-ok)
    else: Dm = Dc
    mu = 5 * np.log10((1 + zh) * Dm)
    d = ms - mu; a = one @ Ci @ d
    return float(d @ Ci @ d - a * a / s1)                     # offset (M + H0) marginalized analytically
def E_lcdm(om, ol=None):
    ol = 1 - om if ol is None else ol; ok = 1 - om - ol
    return np.sqrt(om * (1 + zgrid) ** 3 + ok * (1 + zgrid) ** 2 + ol), ok
def chi2_lcdm(om, ol=None):
    E, ok = E_lcdm(om, ol)
    if np.any(~np.isfinite(E)) or np.any(E <= 0): return 1e12
    return chi2_from_Dc(dl(E), ok)
def chi2_wcdm(om, w):
    E = np.sqrt(om * (1 + zgrid) ** 3 + (1 - om) * (1 + zgrid) ** (3 * (1 + w))); return chi2_from_Dc(dl(E))
def chi2_dgp(om):
    orc = ((1 - om) / 2) ** 2
    E = math.sqrt(orc) + np.sqrt(orc + om * (1 + zgrid) ** 3); return chi2_from_Dc(dl(E))
f_l = minimize_scalar(chi2_lcdm, bounds=(0.05, 0.7), method="bounded")
f_d = minimize_scalar(chi2_dgp, bounds=(0.01, 0.7), method="bounded")
chi_eds = chi2_lcdm(1.0, 0.0)
f_open = minimize_scalar(lambda om: chi2_lcdm(om, 0.0), bounds=(0.0, 1.5), method="bounded")    # Lambda = 0, curvature free
w_fit = minimize(lambda p: chi2_wcdm(*p), x0=[0.3, -1.0], method="Nelder-Mead", options=dict(xatol=1e-5, fatol=1e-6))
# profile 1-sigma for Omega_m (flat LCDM) and w
oms = np.linspace(0.2, 0.45, 251); prof = np.array([chi2_lcdm(o) for o in oms])
ci_om = oms[prof <= f_l.fun + 1].min(), oms[prof <= f_l.fun + 1].max()
ws = np.linspace(-1.4, -0.6, 161)
profw = np.array([minimize_scalar(lambda om: chi2_wcdm(om, w), bounds=(0.05, 0.7), method="bounded").fun for w in ws])
ci_w = ws[profw <= w_fit.fun + 1].min(), ws[profw <= w_fit.fun + 1].max()
must(f_open.fun - f_l.fun > 25 and ci_w[0] < -1 < ci_w[1] + 0.2, "D1 sanity")
RES["D1"] = dict(data="Pantheon+ (public release; z_HD > 0.01, calibrators excluded; STAT+SYS covariance; offset marginalized)",
                 N=int(sel.sum()), sha256_dat=hashlib.sha256(dat.read_bytes()).hexdigest(),
                 flat_LCDM=dict(Omega_m=f_l.x, ci68=ci_om, Omega_Lambda=1 - f_l.x, chi2=f_l.fun),
                 Lambda_zero_flat_EdS=dict(chi2=chi_eds, dchi2=chi_eds - f_l.fun),
                 Lambda_zero_curvature_free=dict(Omega_m=f_open.x, chi2=f_open.fun, dchi2=f_open.fun - f_l.fun),
                 flat_wCDM=dict(Omega_m=w_fit.x[0], w=w_fit.x[1], w_ci68=ci_w, chi2=w_fit.fun),
                 flat_DGP=dict(Omega_m=f_d.x, chi2=f_d.fun, dchi2_vs_LCDM=f_d.fun - f_l.fun),
                 status="MEASURED")

# ------------------------------------------------------------------ D2 binary pulsars
Tsun = 4.925490947e-6; day = 86400.0
def pbdot_gr(Pb_d, e, m1, m2):
    Pb = Pb_d * day; fe = (1 + 73 / 24 * e ** 2 + 37 / 96 * e ** 4) / (1 - e ** 2) ** 3.5
    return -(192 * math.pi / 5) * (Pb / (2 * math.pi)) ** (-5 / 3) * fe * Tsun ** (5 / 3) * m1 * m2 * (m1 + m2) ** (-1 / 3)
ht = pbdot_gr(0.322997448918, 0.6171340, 1.438, 1.390)
dp = pbdot_gr(0.1022515592973, 0.087777023, 1.338185, 1.248868)
ht_obs, ht_err = -2.398e-12, 0.004e-12
ratio_ht = ht_obs / ht; err_ht = ht_err / abs(ht)
must(abs(ht / -2.40263e-12 - 1) < 2e-3, "HT GR prediction reproduced")
dp_ratio, dp_err = 0.999963, 0.000063
RES["D2"] = dict(data="published timing parameters: B1913+16 (Weisberg & Huang 2016), J0737-3039A/B (Kramer et al. 2021)",
                 B1913=dict(Pbdot_GR_computed=ht, Pbdot_GR_published=-2.40263e-12, Pbdot_intrinsic=ht_obs, ratio=ratio_ht, sigma=err_ht,
                            extra_channel_bound_2sigma=abs(ratio_ht - 1) + 2 * err_ht),
                 J0737=dict(Pbdot_GR_computed=dp, ratio_published=dp_ratio, sigma=dp_err,
                            extra_channel_bound_2sigma=abs(dp_ratio - 1) + 2 * dp_err),
                 status="MEASURED (orbital energy loss = quadrupole TT radiation; extra radiative channels < 1.6e-4 of it)")

# ------------------------------------------------------------------ D3 GW170817
c = 299792458.0; Mpc = 3.0856775814913673e22
D = 26 * Mpc; dt_obs = 1.74; lag_max = 10.0
upper = c * dt_obs / D; lower = c * (dt_obs - lag_max) / D
hP_eVs = 4.135667696e-15; f = 100.0
mg_bound = hP_eVs * f * math.sqrt(2 * max(abs(upper), abs(lower)))
must(abs(upper - 7e-16) < 1e-16 and abs(lower + 3e-15) < 2e-16, "D3 reproduction")
RES["D3"] = dict(data="GW170817 / GRB 170817A: delay 1.74 s, conservative distance 26 Mpc, emission lag 0-10 s (Abbott et al. 2017)",
                 tensor_speed_bounds=[lower, upper], implied_graviton_mass_eV_at_100Hz=mg_bound,
                 status="MEASURED (luminal massless spin-2 to ~1e-15; the speed-implied mass bound is weak, dispersion bounds are stronger)")

# ------------------------------------------------------------------ D4 Cassini
g_m1, g_s = 2.1e-5, 2.3e-5
lower_gm1 = g_m1 - 2 * g_s
omega_bd = 1 / abs(lower_gm1) - 2
RES["D4"] = dict(data="Cassini: gamma - 1 = (2.1 +- 2.3)e-5 (Bertotti, Iess & Tortora 2003)",
                 brans_dicke_omega_lower_2sigma=omega_bd,
                 status="MEASURED (structure channel gamma = 1 to ~2e-5; Brans-Dicke region omega < 4e4 excluded, omega -> infinity survives)")
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_gr_naturality_results.json").write_text(json.dumps(RES, indent=1, default=float))
print(json.dumps({k: {kk: vv for kk, vv in v.items() if kk not in ("data", "sha256_dat")} for k, v in RES.items() if isinstance(v, dict)}, indent=1, default=float))
