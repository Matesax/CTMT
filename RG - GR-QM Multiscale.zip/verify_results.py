"""Verify delivered result/source consistency without rerunning experiments."""
from pathlib import Path
import hashlib,json,csv
P=Path(__file__).resolve().parent
suites=[('rg_multiscale.py','rg_multiscale_results.json','rg_multiscale_runs.csv',1415),('rg_stress.py','rg_stress_results.json','rg_stress_runs.csv',600),('rg_ramsey.py','rg_ramsey_results.json','rg_ramsey_runs.csv',7200)]
checks=0
for src,res,data,n in suites:
 d=json.loads((P/res).read_text())
 assert d['source_sha256']==hashlib.sha256((P/src).read_bytes()).hexdigest(),src
 assert all(v['passed'] for v in d['checks']),res
 assert d['passed']==d['total_checks']==len(d['checks'])
 with (P/data).open(newline='') as f: assert sum(1 for _ in csv.DictReader(f))==n,data
 checks+=len(d['checks'])
assert checks==35
main=json.loads((P/'rg_multiscale_results.json').read_text())
assert main['spec_sha256']==hashlib.sha256((P/'rg_protocol_spec.json').read_bytes()).hexdigest()
stress=json.loads((P/'rg_stress_results.json').read_text()); assert len(stress['mutations'])==8 and all(v['detected'] for v in stress['mutations'])
ramsey=json.loads((P/'rg_ramsey_results.json').read_text()); assert ramsey['admitted_designs']==9 and ramsey['abstained_designs']==27
out=dict(aggregate_checks=checks,all_passed=True,source_hashes_match=True,csv_rows_match=True,mutations_detected=8,ramsey_admitted_designs=9,ramsey_abstained_designs=27,scope='Consistency verification, not new physical evidence.')
(P/'rg_verification.json').write_text(json.dumps(out,indent=2)+'\n'); print(json.dumps(out,indent=2))
