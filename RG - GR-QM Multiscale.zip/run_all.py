"""Run the three new batteries and the supplied cubic supporting battery."""
from pathlib import Path
import subprocess,sys
p=Path(__file__).resolve().parent
for name in ['rg_multiscale.py','rg_stress.py','rg_ramsey.py','rg_cubic_universality.py','verify_results.py']:
    subprocess.run([sys.executable,str(p/name)],cwd=p,check=True)
