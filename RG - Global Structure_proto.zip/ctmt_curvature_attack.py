import numpy as np, json, math
import matplotlib.pyplot as plt

# CTMT curvature attack: flatness failure as resolution curvature.
# Structure group Aut(G) with nontrivial compact stabilizer:
# O=R+N, dim R=r, dim N=q, C=lambda[I_r 0], SigmaR=I, SigmaN=I.

n=32; r=8; q=n-r; lam=0.06699
Sigma_R=np.eye(r); Sigma_N=np.eye(q)
C=np.zeros((r,q)); C[:,:r]=lam*np.eye(r)
Sigma=np.block([[Sigma_R,C],[C.T,Sigma_N]])
I=np.eye(n)

L=8  # lattice size, plaquettes (L-1)x(L-1)

# ---------- group utilities ----------
def rot2(t):
    return np.array([[math.cos(t),-math.sin(t)],[math.sin(t),math.cos(t)]])

def embed_A(theta):
    A=np.eye(r)
    # use four independent 2D blocks, same angle for simplicity
    for k in range(0,r,2):
        A[np.ix_([k,k+1],[k,k+1])] = rot2(theta)
    return A

def block_diag(A,B):
    return np.block([[A,np.zeros((A.shape[0],B.shape[1]))],[np.zeros((B.shape[0],A.shape[1])),B]])

def aut(theta):
    A=embed_A(theta)
    K=np.eye(q-r)
    B=block_diag(A,K)
    return block_diag(A,B)

def null_inflation(eps):
    return block_diag(np.eye(r),(1+eps)*np.eye(q))

def residual(M):
    return float(np.linalg.norm(M@Sigma@M.T-Sigma,'fro')/np.linalg.norm(Sigma,'fro'))

def sector_mix(M):
    return float(np.linalg.norm(M[:r,r:],'fro')+np.linalg.norm(M[r:,:r],'fro'))

def in_aut(M,tol=1e-9):
    return residual(M)<tol and sector_mix(M)<tol

def theta_from_aut(M):
    # Extract approximate rotation angle from first resolved 2-block.
    A=M[:r,:r]
    return math.atan2(A[1,0], A[0,0])

def plaquette(Ux,Uy,i,j):
    # P = Ux(i,j) Uy(i+1,j) Ux(i,j+1)^-1 Uy(i,j)^-1
    return Ux[i][j] @ Uy[i+1][j] @ np.linalg.inv(Ux[i][j+1]) @ np.linalg.inv(Uy[i][j])

# ---------- case 1: pure gauge flat ----------
def build_flat(alpha=0.11,beta=-0.07):
    g=[[aut(alpha*i+beta*j) for j in range(L)] for i in range(L)]
    Ux=[[None for j in range(L)] for i in range(L-1)]
    Uy=[[None for j in range(L-1)] for i in range(L)]
    for i in range(L-1):
        for j in range(L):
            Ux[i][j]=g[i+1][j] @ np.linalg.inv(g[i][j])
    for i in range(L):
        for j in range(L-1):
            Uy[i][j]=g[i][j+1] @ np.linalg.inv(g[i][j])
    return Ux,Uy

# ---------- case 2: curved but admissible compact connection ----------
def build_curved(F=0.09):
    # Lattice Landau gauge: Ux(i,j)=R(-F*j), Uy=I -> plaquette R(-F) in Aut(G)
    Ux=[[aut(-F*j) for j in range(L)] for i in range(L-1)]
    Uy=[[aut(0.0) for j in range(L-1)] for i in range(L)]
    return Ux,Uy

# ---------- case 3: defective non-Aut curvature ----------
def build_defective(F=0.09,eps=0.03):
    Ux,Uy=build_curved(F)
    # Insert one non-compact null inflation link; this creates non-Aut plaquettes near it.
    Ux[3][3]=null_inflation(eps) @ Ux[3][3]
    return Ux,Uy

# ---------- evaluate battery ----------
def eval_case(name,Ux,Uy):
    curv_angles=[]; aut_flags=[]; residuals=[]; id_dists=[]; sector_mixes=[]
    Ps=[]
    for i in range(L-1):
        row=[]
        for j in range(L-1):
            P=plaquette(Ux,Uy,i,j)
            row.append(P)
            curv_angles.append(theta_from_aut(P))
            aut_flags.append(in_aut(P))
            residuals.append(residual(P))
            id_dists.append(float(np.linalg.norm(P-I,'fro')))
            sector_mixes.append(sector_mix(P))
        Ps.append(row)
    return {
        'case':name,
        'plaquettes':(L-1)*(L-1),
        'max_identity_distance':max(id_dists),
        'mean_identity_distance':float(np.mean(id_dists)),
        'max_aut_residual':max(residuals),
        'mean_aut_residual':float(np.mean(residuals)),
        'max_sector_mixing':max(sector_mixes),
        'all_plaquettes_in_AutG':bool(all(aut_flags)),
        'num_non_aut_plaquettes':int(sum(1 for x in aut_flags if not x)),
        'mean_curvature_angle':float(np.mean(curv_angles)),
        'std_curvature_angle':float(np.std(curv_angles)),
        'P_sample':Ps[0][0],
        'curv_grid':np.array(curv_angles).reshape(L-1,L-1),
        'resid_grid':np.array(residuals).reshape(L-1,L-1)
    }

cases={
    'flat_pure_gauge': build_flat(),
    'curved_admissible_compact': build_curved(),
    'defective_noncompact': build_defective()
}

evals=[]
for name,(Ux,Uy) in cases.items():
    ev=eval_case(name,Ux,Uy)
    evals.append(ev)

# Amplification: compare plaquette power for admissible curved vs defective plaquette.
P_curved=evals[1]['P_sample']
# choose worst residual plaquette from defective
UxD,UyD=cases['defective_noncompact']
worstP=None; worstR=-1
for i in range(L-1):
    for j in range(L-1):
        P=plaquette(UxD,UyD,i,j)
        rr=residual(P)
        if rr>worstR: worstR=rr; worstP=P
powers=[1,2,4,8,16,32,64]
def amp(P):
    return {
        'powers':powers,
        'fro_norms':[round(float(np.linalg.norm(np.linalg.matrix_power(P,k),'fro')),6) for k in powers],
        'aut_residuals':[round(residual(np.linalg.matrix_power(P,k)),6) for k in powers],
        'identity_distances':[round(float(np.linalg.norm(np.linalg.matrix_power(P,k)-I,'fro')),6) for k in powers]
    }

summary={
    'system':'CTMT curvature / flatness failure synthetic battery',
    'base_geometry':{
        'dim_O':n,'rank_R':r,'dim_N':q,'dimensional_closure':bool(n==r+q),
        'coupling_model':'C=lambda[I_r 0]','lambda':lam,
        'Sigma_positive_definite':bool(np.linalg.eigvalsh(Sigma).min()>0)
    },
    'interpretation':{
        'flat':'plaquette products P_ij approximately identity',
        'curved_admissible':'plaquette products nonidentity but remain in Aut(G); this is resolution curvature inside compact structure group',
        'defective':'plaquette products leave Aut(G); this is not curvature of a CTMT connection but inadmissible transport defect'
    },
    'cases':[],
    'amplification':{
        'admissible_curvature_plaquette':amp(P_curved),
        'defective_noncompact_plaquette':amp(worstP)
    },
    'verdict':'Flatness failure splits into admissible curvature versus inadmissible defect. Nonidentity plaquette is acceptable curvature only when the plaquette remains in Aut(G); leaving Aut(G) is a broken CTMT transport gate.'
}

for ev in evals:
    summary['cases'].append({k:(round(float(v),12) if isinstance(v,(float,np.floating)) else v) for k,v in ev.items() if k not in ['P_sample','curv_grid','resid_grid']})

with open('/mnt/data/ctmt_curvature_attack_results.json','w') as f:
    json.dump(summary,f,indent=2)

# Figures
for ev in evals:
    plt.figure(figsize=(5.2,4.3))
    plt.imshow(ev['curv_grid'], cmap='coolwarm', aspect='equal')
    plt.colorbar(label='plaquette angle proxy')
    plt.title(ev['case']+' curvature grid')
    plt.tight_layout()
    plt.savefig(f"/mnt/data/ctmt_curvature_{ev['case']}.png",dpi=180)
    plt.close()

plt.figure(figsize=(8,4.5))
labels=[ev['case'] for ev in evals]
ids=[ev['max_identity_distance'] for ev in evals]
res=[ev['max_aut_residual'] for ev in evals]
x=np.arange(len(labels))
plt.bar(x-0.18,ids,width=0.36,label='max identity distance')
plt.bar(x+0.18,res,width=0.36,label='max Aut(G) residual')
plt.xticks(x,labels,rotation=25,ha='right')
plt.yscale('symlog',linthresh=1e-12)
plt.title('Flatness failure vs admissibility defect')
plt.legend(); plt.tight_layout(); plt.savefig('/mnt/data/ctmt_curvature_summary.png',dpi=180); plt.close()

plt.figure(figsize=(7.5,4.5))
plt.plot(powers,summary['amplification']['admissible_curvature_plaquette']['fro_norms'],marker='o',label='admissible curvature plaquette')
plt.plot(powers,summary['amplification']['defective_noncompact_plaquette']['fro_norms'],marker='o',label='defective noncompact plaquette')
plt.xlabel('plaquette repetitions'); plt.ylabel('Frobenius norm')
plt.grid(alpha=0.3); plt.legend(); plt.title('Curvature amplification: compact vs defect')
plt.tight_layout(); plt.savefig('/mnt/data/ctmt_curvature_amplification.png',dpi=180); plt.close()

print(json.dumps(summary,indent=2))
