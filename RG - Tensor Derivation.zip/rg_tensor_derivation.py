"""RG Tensor Derivation -- standalone battery for the print 'RG - Tensor Derivation'.

Every group either constructs a step of the chain or destroys the alternatives to it, and every group carries a
canary (something that must fail, or a freedom that must survive).

  Part I    records and continuity       C1 observation metric, non-selection   C2 descent criterion
                                         C3 predictive metric (exact)           C4 completion / destructor
                                         C5 walls: rank fold, waiting time, zero support   C6 chart crossing
  Part II   balance before geometry      B1 cut theorem on graphs   B2 refinement chain map   B3 consistency + stability
  Part III  realization gate             R1 cut-flux linearity      R2 source-convergence defects   R3 interface admissibility
  Part IV   source tensor                S1 relabeling response = Hilbert tensor (off shell)   S2 alternative sources destroyed
                                         S3 symmetry (Lie vs translation transport), torque     S4 improvement freedom
  Part V    universality                 U1 one relabeling; hub; active/passive destructor
  Part VI   mediator content             M1 compensator rank
  Part VII  transport                    L1 Koszul uniqueness   L2 Noether II identity + detectable deformations
                                         L3 totally antisymmetric torsion is null for bosonic and point-particle records
  Part VIII linear response              E1 five-coefficient selection, mass forbidden, Ricci canary
  Part IX   nonlinear completion         N1 field carries momentum   N2 Gauss-Bonnet 4-D vs 5-D, R^2 order
  Part X    destructors                  D1 mediator table   D2 orbits   D3 ghost, Euclidean   D4 R + alpha R^2 embedding
                                         D5 weak field, gamma(r), bounds
  Part XI   lattice witness              Q1 momentum O(a^2)   Q2 effective cone: Bessel tails, not a strict front

Run: python rg_tensor_derivation.py  (numpy, scipy, sympy; rg_curv.py alongside). Seed 20261110. Deterministic.
"""
import hashlib, json, sys, itertools
from fractions import Fraction as Fr
from math import factorial
from pathlib import Path
import numpy as np
import sympy as s
from scipy.integrate import solve_ivp
from scipy.special import jv
from sympy.calculus.euler import euler_equations

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rg_curv import curvature, invariants  # noqa: E402
SEED = 20261110
rng = np.random.default_rng(SEED)
R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        FAILS.append(tag)
        print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.12g}')


# =====================================================================================================  PART I
def C1():
    # finite truncations of d_obs = sum 2^-k |f_k(x) - f_k(y)| on random profiles: metric axioms, coordinate continuity
    K = 30
    prof = rng.random((60, K))
    w = 2.0 ** -np.arange(1, K + 1)
    D = np.abs(prof[:, None, :] - prof[None, :, :]) @ w
    tri = float(np.max(D[:, :, None] - D[:, None, :] - D.T[None, :, :]))
    coord = max(float(np.max(np.abs(prof[:, None, k] - prof[None, :, k]) - 2 ** (k + 1) * D)) for k in range(K))
    must(tri <= 1e-12 and coord <= 1e-12 and np.allclose(D, D.T) and np.all(np.diag(D) == 0), 'C1 metric')
    # non-selection: f_k = rho(x, a_k)/(1 + rho(x, a_k)) realizes interval, circle and Cantor set injectively
    def profile(pts, dense, rho):
        return np.array([[rho(p, a) / (1 + rho(p, a)) for a in dense] for p in pts])
    spaces = {}
    xs = np.linspace(0, 1, 41)
    spaces['interval'] = (xs, xs[::3], lambda p, a: abs(p - a))
    th = np.linspace(0, 2 * np.pi, 40, endpoint=False)
    spaces['circle'] = (th, th[::3], lambda p, a: min(abs(p - a), 2 * np.pi - abs(p - a)))
    cant = np.array([sum(d * 2 * 3.0 ** -(i + 1) for i, d in enumerate(bits)) for bits in itertools.product([0, 1], repeat=6)])
    spaces['cantor'] = (cant, cant[::4], lambda p, a: abs(p - a))
    out = {}
    for name, (pts, dense, rho) in spaces.items():
        P = profile(pts, dense, rho)
        Dp = np.abs(P[:, None, :] - P[None, :, :]).sum(-1)
        Dr = np.array([[rho(p, q) for q in pts] for p in pts])
        off = ~np.eye(len(pts), dtype=bool)
        out[name] = dict(points=len(pts), min_profile_separation=fl(Dp[off].min()), profile_over_rho_max=fl((Dp[off] / Dr[off]).max()))
    must(all(v['min_profile_separation'] > 0 for v in out.values()), 'C1 non-selection')
    R['C1'] = dict(claim='d_obs is a metric whose topology makes every protocol probability continuous (|f_k(x)-f_k(y)| <= 2^k d_obs); '
                         'the same construction realizes an interval, a circle and a Cantor set injectively: operational continuity '
                         'does not select a manifold, a dimension or a metric tensor',
                   status='PROVED (elementary) + executed', max_triangle_violation=fl(tri), max_coordinate_bound_violation=fl(coord),
                   non_selection=out)


def finite_system(n=14):
    U = [int(v) for v in rng.integers(0, n, size=n)]
    obs = [int(v) for v in rng.integers(0, 3, size=n)]
    return U, obs


def C2():
    U, obs = finite_system()
    n = len(U)
    # present quotient: x ~ y iff obs equal ; it descends iff obs(x)=obs(y) => obs(Ux)=obs(Uy)
    def descends(cls):
        return all(cls[U[x]] == cls[U[y]] for x in range(n) for y in range(n) if cls[x] == cls[y])
    present = obs[:]
    # coarsest dynamically closed refinement: iterate x~y iff obs and successor classes agree (Moore partition refinement)
    cls = obs[:]
    while True:
        new = [hash((cls[x], cls[U[x]])) for x in range(n)]
        lab = {v: i for i, v in enumerate(dict.fromkeys(new))}
        new = [lab[v] for v in new]
        if len(set(new)) == len(set(cls)):
            break
        cls = new
    must((not descends(present)) and descends(cls), 'C2')
    R['C2'] = dict(claim='U descends to X/~ iff x~y implies Ux~Uy. The present-observation quotient of a seeded 14-state system fails '
                         'this (hidden information changes a future prediction); its coarsest predictive refinement satisfies it',
                   status='PROVED (elementary) + executed', present_classes=len(set(present)), predictive_classes=len(set(cls)),
                   present_descends=descends(present), predictive_descends=descends(cls))
    return U, obs, cls


def C3(U, obs, cls):
    n = len(U)
    beta = Fr(2, 3)
    d0 = lambda x, y: Fr(1) if obs[x] != obs[y] else Fr(0)
    pairs = [(x, y) for x in range(n) for y in range(n)]

    def dbeta(p):
        seen, seq = {}, []
        while p not in seen:
            seen[p] = len(seq); seq.append(p); p = (U[p[0]], U[p[1]])
        pre, per = seen[p], len(seq) - seen[p]
        head = sum((beta ** k * d0(*seq[k]) for k in range(pre)), Fr(0))
        cyc = sum((beta ** (k - pre) * d0(*seq[k]) for k in range(pre, len(seq))), Fr(0))
        return (1 - beta) * (head + beta ** pre * cyc / (1 - beta ** per))
    Dbf = {p: dbeta(p) for p in pairs}
    Db = {p: s.Rational(v.numerator, v.denominator) for p, v in Dbf.items()}
    bet = s.Rational(2, 3)
    ident = all(Db[(U[x], U[y])] == (Db[(x, y)] - (1 - bet) * int(d0(x, y))) / bet for x, y in pairs)
    lip = all(Db[(U[x], U[y])] <= Db[(x, y)] / bet for x, y in pairs)
    hidden = [(x, y) for x, y in pairs if d0(x, y) == 0 and Db[(x, y)] > 0]
    zero_cls = all((Db[(x, y)] == 0) == (cls[x] == cls[y]) for x, y in pairs)
    must(ident and lip and len(hidden) > 0 and zero_cls, 'C3')
    R['C3'] = dict(claim='d_beta(x,y) = (1-beta) sum beta^n d_0(U^n x, U^n y) satisfies d_beta(Ux,Uy) = (d_beta - (1-beta) d_0)/beta exactly, '
                         'so U is 1/beta-Lipschitz; d_beta separates states that the present observation merges, and its zero set is '
                         'exactly the predictive quotient (computed exactly by rational linear algebra, beta = 2/3)',
                   status='PROVED (exact identity) + exact computation', pairs=len(pairs), hidden_pairs_separated=len(hidden),
                   zero_set_equals_predictive_quotient=zero_cls)


def C4():
    a = np.array([1 / (np.pi / 2 + 2 * np.pi * k) for k in range(100, 110)])
    b = np.array([1 / (3 * np.pi / 2 + 2 * np.pi * k) for k in range(100, 110)])
    lim = (float(np.sin(1 / a).mean()), float(np.sin(1 / b).mean()))
    must(abs(lim[0] - 1) < 1e-9 and abs(lim[1] + 1) < 1e-9, 'C4')
    R['C4'] = dict(claim='A Lipschitz update maps Cauchy sequences to Cauchy sequences and extends uniquely to the completion. Canary: '
                         'sin(1/x) is continuous on (0,1] but two sequences converging to 0 have image limits +1 and -1: '
                         'continuity without uniform control does not extend',
                   status='PROVED (elementary) + destructor', image_limits=[fl(v) for v in lim])


def C5():
    x, t, tau = s.symbols('x t tau', real=True)
    fold = s.expand((x + t) ** 2 - (-x + t) ** 2)
    q = (t - tau) ** 2
    branch_ok = s.simplify(s.diff(q, t) - 2 * (t - tau)) == 0
    junction = s.diff(q, t).subs(t, tau) == 0 and q.subs(t, tau) == 0
    # zero-support conditioning: P, Q differ only on a rare branch of mass eps
    out = []
    for eps in [Fr(1, 10), Fr(1, 100), Fr(1, 1000)]:
        P = {('rare', 'a'): eps, ('common', 'a'): (1 - eps) / 2, ('common', 'b'): (1 - eps) / 2}
        Q = {('rare', 'b'): eps, ('common', 'a'): (1 - eps) / 2, ('common', 'b'): (1 - eps) / 2}
        keys = set(P) | set(Q)
        tv = sum(abs(P.get(k, 0) - Q.get(k, 0)) for k in keys) / 2
        cP = {k[1]: v / eps for k, v in P.items() if k[0] == 'rare'}
        cQ = {k[1]: v / eps for k, v in Q.items() if k[0] == 'rare'}
        ctv = sum(abs(cP.get(o, 0) - cQ.get(o, 0)) for o in 'ab') / 2
        out.append(dict(eps=str(eps), joint_TV=str(tv), conditional_TV=str(ctv)))
    # the 2 delta / eps bound on random finite laws (event conditioning, sup over events)
    worst = 0.0
    for _ in range(2000):
        P = rng.dirichlet(np.ones(8)); Q = rng.dirichlet(np.ones(8))
        Y = rng.random(8) < 0.5
        if not Y.any():
            continue
        delta = 0.5 * np.abs(P - Q).sum(); e = min(P[Y].sum(), Q[Y].sum())
        ctv = 0.5 * np.abs(P[Y] / P[Y].sum() - Q[Y] / Q[Y].sum()).sum()
        worst = max(worst, ctv / (2 * delta / e))
    must(fold == 4 * x * t and branch_ok and junction and all(o['conditional_TV'] == '1' for o in out) and worst <= 1 + 1e-12, 'C5')
    R['C5'] = dict(claim='Walls a quotient cannot cross by continuity alone: (a) the fold q = x^2 merges x and -x whose futures differ by '
                         '4xt; (b) qdot = 2 sqrt(q), q(0) = 0 has every waiting-time solution (t - tau)^2, tau >= 0 (C^1 junction); '
                         '(c) conditioning: TV(P(.|Y), Q(.|Y)) <= 2 delta / eps, but at vanishing support joint TV -> 0 while '
                         'conditional TV = 1',
                   status='PROVED (exact) + 2000 seeded bound checks', fold_split=str(fold), zero_support=out,
                   max_ratio_to_bound=fl(worst))


def C6():
    z = s.Symbol('z')
    w = 1 / z
    zdot = (1 + z ** 2) / 2
    wdot_from_z = s.diff(w, z) * zdot
    ok = s.simplify(wdot_from_z + (1 + w ** 2) / 2) == 0
    must(ok, 'C6')
    R['C6'] = dict(claim='Chart failure is crossable: z = tan(theta/2), w = cot(theta/2), w = 1/z; zdot = (1+z^2)/2 transports to '
                         'wdot = -(1+w^2)/2. At theta = pi, z diverges while w = 0 and the profile (cos, sin) is regular',
                   status='PROVED (symbolic)')


# =====================================================================================================  PART II
def incidence(nodes, edges):
    B = np.zeros((nodes, len(edges)), dtype=np.int64)
    for e, (i, j) in enumerate(edges):
        B[i, e] = 1; B[j, e] = -1          # outflow positive at the tail
    return B


def B1():
    n = 9
    edges = [(i, j) for i in range(n) for j in range(i + 1, n) if rng.random() < 0.45]
    B = incidence(n, edges)
    checks = 0; bad = 0
    for _ in range(200):
        J = rng.integers(-5, 6, size=len(edges))
        dP = -(B @ J)                       # node balance: storage change = - net outflow
        Rm = rng.random(n) < 0.5
        bflux = sum(J[e] * (int(Rm[i]) - int(Rm[j])) for e, (i, j) in enumerate(edges))
        bad += int(dP[Rm].sum() + bflux != 0); checks += 1
    must(bad == 0, 'B1')
    R['B1'] = dict(claim='Node balance on any oriented graph gives Delta P_R + sum_e (1_R(i) - 1_R(j)) J_e = 0 for every region R: internal '
                         'edges cancel, no metric or embedding used', status='PROVED (elementary) + exact integer checks',
                   regions_checked=checks, edges=len(edges))


def B2():
    # coarse graph: clusters of fine nodes; R0 sums nodes, R1 maps inter-cluster fine edges to coarse edges with sign
    clusters = [[0, 1, 2], [3, 4], [5, 6, 7], [8]]
    owner = {v: c for c, cl in enumerate(clusters) for v in cl}
    fine_edges = [(0, 1), (1, 2), (0, 2), (3, 4), (5, 6), (6, 7), (2, 3), (1, 4), (4, 5), (7, 8), (0, 8), (2, 6)]
    coarse_edges = []
    for i, j in fine_edges:
        a, b = owner[i], owner[j]
        if a != b and (a, b) not in coarse_edges and (b, a) not in coarse_edges:
            coarse_edges.append((a, b))
    Bf = incidence(9, fine_edges); Bc = incidence(4, coarse_edges)
    R0 = np.zeros((4, 9), dtype=np.int64)
    for v, c in owner.items():
        R0[c, v] = 1
    R1 = np.zeros((len(coarse_edges), len(fine_edges)), dtype=np.int64)
    for e, (i, j) in enumerate(fine_edges):
        a, b = owner[i], owner[j]
        if a == b:
            continue
        if (a, b) in coarse_edges:
            R1[coarse_edges.index((a, b)), e] = 1
        else:
            R1[coarse_edges.index((b, a)), e] = -1
    chain = np.array_equal(Bc @ R1, R0 @ Bf)
    ok = all(np.array_equal(Bc @ (R1 @ J), R0 @ (Bf @ J)) for J in rng.integers(-4, 5, size=(100, len(fine_edges))))
    R1bad = R1.copy(); R1bad[0, 0] = 1     # keep one internal edge: canary
    must(chain and ok and not np.array_equal(Bc @ R1bad, R0 @ Bf), 'B2')
    R['B2'] = dict(claim='If aggregation maps satisfy B_h R_1 = R_0 B_h\' (a chain map), balance at the fine level implies balance at the '
                         'coarse level without embedding, normals or manifold; counting an internal edge breaks the chain map',
                   status='PROVED (algebra) + exact checks', chain_map=bool(chain), balance_transfers=bool(ok))


def B3():
    L = 1.05; eps = 1e-3
    F = lambda x: L * np.sin(x)                    # limit update, Lipschitz constant L
    Fh = lambda x: L * np.sin(x) + eps * np.cos(3 * x)   # micro step, consistency defect <= eps
    x = y = 0.7; e = [0.0]; viol = 0
    for k in range(1, 61):
        x, y = Fh(x), F(y); e.append(abs(x - y))
        bound = eps * sum(L ** j for j in range(k))
        viol += int(e[-1] > bound + 1e-15)
    acc = sum(Fr(1, 1000) for _ in range(1000))
    must(viol == 0 and acc == 1, 'B3')
    R['B3'] = dict(claim='Consistency d(R_h F_h x, F R_h x) <= eps_h plus L-Lipschitz limit give e_k <= L^k e_0 + eps_h sum_{j<k} L^j. '
                         'Canary: defects h accumulated over 1/h steps give error 1 (closure holds only on bounded windows)',
                   status='PROVED (induction) + executed', steps=60, bound_violations=viol, accumulated_unit_error=str(acc))


# =====================================================================================================  PART III
def R1_():
    def faces(P):
        return [0.5 * np.cross(P[j] - P[i], P[k] - P[i]) for i, j, k in [(1, 2, 3), (0, 3, 2), (0, 1, 3), (0, 2, 1)]]
    M = rng.normal(size=(3, 3))
    laws = {'linear': lambda a: M @ a, 'norm': lambda a: np.array([np.linalg.norm(a), 0, 0]),
            'odd_quadratic': lambda a: np.array([a[0] * abs(a[0]), a[1], a[2]]),
            'linear_plus_cubic': lambda a: M @ a + np.array([a[0] ** 3, 0, 0])}
    res = {}
    for name, f in laws.items():
        worst = 0.0
        for _ in range(200):
            fs = faces(rng.normal(size=(4, 3)))
            worst = max(worst, np.linalg.norm(sum(f(a) for a in fs)) / max(np.linalg.norm(f(fs[0])), 1e-12))
        res[name] = fl(worst)
    must(res['linear'] < 1e-12 and all(v > 1e-3 for k, v in res.items() if k != 'linear'), 'R1')
    R['R1'] = dict(claim='Under the realization gate (oriented smooth realization, additive odd local flux, bounded bulk) the shrinking-'
                         'simplex balance forces flux linear in the area covector; nonlinear odd laws are destroyed',
                   status='PROVED (Cauchy) + destructor on 200 tetrahedra per law', worst_relative_imbalance=res)


def R2_():
    xg = np.linspace(0, 2 * np.pi, 20001)[:-1]
    rows = []
    for nn in [5, 50, 500]:
        u = np.sin(nn * xg) / nn; du = np.cos(nn * xg)
        rows.append(dict(n=nn, sup_u=fl(np.abs(u).max()), mean_stress=fl(np.mean(0.5 * du ** 2))))
    errs = []
    for _ in range(50):
        a = rng.normal(size=500); b = a + 1e-3 * rng.normal(size=500)
        lhs = np.abs(np.outer(b, b) - np.outer(a, a)).sum() / 500 ** 2
        rhs = (np.sqrt(np.mean(b ** 2)) + np.sqrt(np.mean(a ** 2))) * np.sqrt(np.mean((b - a) ** 2))
        errs.append(lhs - rhs)
    h, q = s.symbols('h q', positive=True)
    Sh = h * s.sin(q / h ** 2)
    must(all(abs(r['mean_stress'] - 0.25) < 1e-12 for r in rows) and max(errs) <= 0 and s.simplify(s.diff(Sh, q).subs(q, 0) - 1 / h) == 0, 'R2')
    R['R2'] = dict(claim='Field convergence does not give source convergence: u_n = sin(nx)/n -> 0 uniformly while (1/2) u_n\'^2 has mean '
                         '1/4; strong L^2 convergence controls quadratic sources (|a_n a_n - a a|_1 <= (|a_n| + |a|)|a_n - a|); action '
                         'values S_h = h sin(q/h^2) -> 0 with S_h\'(0) = 1/h. The source gate must control first variations',
                   status='PROVED (exact) + executed', stress_defect=rows, quadratic_bound_max_slack=fl(max(errs)))


def R3_():
    u, ux, uxx, eps = s.symbols('u u_x u_xx epsilon')
    x, t = s.symbols('x t')
    # Riemann data uL = -1, uR = 1: stationary expansion shock vs rarefaction
    uL, uR = -1, 1
    sp_ = s.Rational(uL + uR, 2)
    rh = sp_ * (uR - uL) - (s.Rational(uR ** 2, 2) - s.Rational(uL ** 2, 2)) == 0
    prod = -sp_ * (s.Rational(uR ** 2, 2) - s.Rational(uL ** 2, 2)) + (s.Rational(uR ** 3, 3) - s.Rational(uL ** 3, 3))
    rare = x / t
    rare_ok = s.simplify(s.diff(rare, t) + rare * s.diff(rare, x)) == 0
    U = s.Function('U')(x, t)
    ut = -U * s.diff(U, x) + eps * s.diff(U, x, 2)
    lhs = U * ut + s.diff(U ** 3 / 3, x)
    rhs = eps * s.diff(U * s.diff(U, x), x) - eps * s.diff(U, x) ** 2
    visc = s.simplify(lhs - rhs) == 0
    must(rh and prod == s.Rational(2, 3) and rare_ok and visc, 'R3')
    R['R3'] = dict(claim='Weak balance crosses interfaces (n_mu [T^{mu nu}] = 0) but does not select: for Burgers with states -1 | +1 the '
                         'stationary shock and the rarefaction both balance; the shock produces entropy +2/3 (inadmissible). Viscosity '
                         'gives eta_t + q_x = eps (u u_x)_x - eps u_x^2: admissibility is derived from the microscopic rule',
                   status='PROVED (symbolic)', shock_entropy_production=str(prod))


# =====================================================================================================  PART IV (flat 4-D)
X = s.symbols('t x y z', real=True)
N4 = 4
eta = s.diag(-1, 1, 1, 1)
etai = eta.inv()
XI = [s.Function(f'xi{m}')(*X) for m in range(N4)]
EP = s.Symbol('ep')


def hilbert(Lfun):
    e = s.Symbol('e')
    Sm = s.Matrix(N4, N4, lambda i, j: s.Symbol(f's{min(i, j)}{max(i, j)}'))
    F = s.sqrt(-(eta - e * eta * Sm * eta).det()) * Lfun(etai + e * Sm)
    dF = s.diff(F, e).subs(e, 0)
    return s.Matrix(N4, N4, lambda i, j: s.expand(-2 * s.diff(dF, Sm[i, j]) * (1 if i == j else s.Rational(1, 2))))


def response_residual(L, Tlow, dL):
    Tmix = etai * Tlow
    return s.expand(dL + sum(s.diff(XI[l] * L, X[l]) for l in range(N4))
                    - sum(Tmix[m, v] * s.diff(XI[v], X[m]) for m in range(N4) for v in range(N4)))


def divergence(Tup):
    return [s.expand(sum(s.diff(Tup[m, v], X[m]) for m in range(N4))) for v in range(N4)]


def probe(exprs, funcs, nprobe=3):
    vals = []
    for _ in range(nprobe):
        sub = {}
        for f in funcs:
            cf = rng.integers(-3, 4, size=6)
            sub[f] = cf[0] + cf[1] * X[0] + cf[2] * X[1] ** 2 + cf[3] * X[2] * X[0] + cf[4] * X[3] ** 2 * X[1] + cf[5] * X[0] ** 2 * X[3]
        pt = {X[k]: s.Rational(int(rng.integers(-5, 6)), 3) for k in range(N4)}
        vals.append([s.nsimplify(ex.subs(sub).doit().subs(pt)) for ex in exprs])
    return vals


PHI = s.Function('phi')(*X)
VF = s.Function('V')
DPHI = [s.diff(PHI, c) for c in X]


def S1():
    out = {}
    Ls = lambda G: -s.Rational(1, 2) * sum(G[i, j] * DPHI[i] * DPHI[j] for i in range(N4) for j in range(N4)) - VF(PHI)
    L = Ls(etai); T = hilbert(Ls)
    var = -sum(XI[l] * DPHI[l] for l in range(N4))
    dL = s.expand(s.diff(L.subs(PHI, PHI + EP * var).doit(), EP).subs(EP, 0).doit())
    out['scalar'] = str(response_residual(L, T, dL))
    chi = s.Function('chi')(*X); dchi = [s.diff(chi, c) for c in X]; lam = s.Symbol('lam')
    L2f = lambda G: (-s.Rational(1, 2) * sum(G[i, j] * (DPHI[i] * DPHI[j] + dchi[i] * dchi[j]) for i in range(N4) for j in range(N4))
                     - lam * PHI ** 2 * chi ** 2)
    L2 = L2f(etai); T2 = hilbert(L2f)
    varc = -sum(XI[l] * dchi[l] for l in range(N4))
    dL2 = s.expand(s.diff(L2.subs({PHI: PHI + EP * var, chi: chi + EP * varc}).doit(), EP).subs(EP, 0).doit())
    out['interacting'] = str(response_residual(L2, T2, dL2))
    A = [s.Function(f'A{m}')(*X) for m in range(N4)]
    Fm = lambda Aa: s.Matrix(N4, N4, lambda i, j: s.diff(Aa[j], X[i]) - s.diff(Aa[i], X[j]))
    F = Fm(A)
    LMf = lambda G: -s.Rational(1, 4) * sum(G[a, c] * G[b, d] * F[a, b] * F[c, d] for a in range(N4) for b in range(N4)
                                           for c in range(N4) for d in range(N4) if F[a, b] != 0 and F[c, d] != 0)
    LM = LMf(etai); TM = hilbert(LMf)
    lie = [-(sum(XI[l] * s.diff(A[v], X[l]) for l in range(N4)) + sum(A[l] * s.diff(XI[l], X[v]) for l in range(N4))) for v in range(N4)]
    Fd = Fm(lie)
    dLM = s.expand(-s.Rational(1, 2) * sum(etai[a, a] * etai[b, b] * F[a, b] * Fd[a, b] for a in range(N4) for b in range(N4)))
    out['maxwell'] = str(response_residual(LM, TM, dLM))
    out['maxwell_symmetric'] = bool(s.simplify(TM - TM.T) == s.zeros(N4))
    must(out['scalar'] == '0' and out['interacting'] == '0' and out['maxwell'] == '0' and out['maxwell_symmetric'], 'S1')
    R['S1'] = dict(claim='delta_xi L = -d_l(xi^l L) + T^mu_nu d_mu xi^nu off shell, with delta_xi = -(Lie derivative) on every field and T '
                         'the metric-variation tensor computed independently: scalar with arbitrary V, two scalars with lambda phi^2 chi^2, '
                         'Maxwell. Generic functions of four variables; zero residual', status='PROVED (symbolic, off shell)', residuals=out)
    return T


def S2(T):
    Tup = etai * T * etai
    trace = sum(etai[i, i] * T[i, i] for i in range(N4))
    psi = s.Function('psi')(*X)
    J = [PHI * s.diff(psi, X[m]) - psi * s.diff(PHI, X[m]) for m in range(N4)]
    Jup = [sum(etai[m, k] * J[k] for k in range(N4)) for m in range(N4)]
    Xf = PHI ** 2
    boxX = sum(etai[i, i] * s.diff(Xf, X[i], 2) for i in range(N4))
    improve = s.Matrix(N4, N4, lambda i, j: etai[i, j] * boxX - sum(etai[i, a] * etai[j, b] * s.diff(Xf, X[a], X[b]) for a in range(N4) for b in range(N4)))
    cands = {'2T': 2 * Tup, 'T + eta trT': Tup + etai * trace,
             'J n (internal current)': s.Matrix(N4, N4, lambda i, j: Jup[i] * (1 if j == 0 else 0)),
             'T + (eta box - dd) phi^2': Tup + improve}
    Vsub = {VF(PHI): s.Rational(1, 2) * PHI ** 2 + PHI ** 4}
    dest = {}
    for name, Sx in cands.items():
        resid = divergence((Sx - Tup).subs(Vsub).doit())
        pr = probe(resid, [PHI, psi])
        dest[name] = dict(identically_conserved_difference=not any(v != 0 for row in pr for v in row), probe=[str(v) for v in pr[0]])
    must(all(not d['identically_conserved_difference'] for k, d in dest.items() if not k.startswith('T + (eta'))
         and dest['T + (eta box - dd) phi^2']['identically_conserved_difference'], 'S2')
    R['S2'] = dict(claim='A source S coupled through (1/2) int h S with delta h = d xi + d xi keeps the action invariant under the single '
                         'relabeling iff d_mu (S - T)^{mu nu} = 0 identically: 2T, T + eta trT and an internal current J n are destroyed; '
                         'the improvement (eta box - dd) phi^2 survives', status='PROVED + seeded probes', destructors=dest)


def S3():
    A = [s.Function(f'A{m}')(*X) for m in range(N4)]
    F = s.Matrix(N4, N4, lambda i, j: s.diff(A[j], X[i]) - s.diff(A[i], X[j]))
    Fu = etai * F * etai
    L = -s.Rational(1, 4) * sum(F[a, b] * Fu[a, b] for a in range(N4) for b in range(N4))
    Tc = s.Matrix(N4, N4, lambda a, l: sum(Fu[a, b] * s.diff(A[b], X[l]) for b in range(N4)) + (L if a == l else 0))
    TB = s.Matrix(N4, N4, lambda a, l: sum(Fu[a, b] * F[l, b] for b in range(N4)) + (L if a == l else 0))
    rel = s.Matrix(N4, N4, lambda a, l: s.expand(Tc[a, l] - TB[a, l] - sum(s.diff(Fu[a, b] * A[l], X[b]) for b in range(N4))
                                                 + sum(s.diff(Fu[a, b], X[b]) for b in range(N4)) * A[l]))
    # translation-only transport generates Tc: check the response identity with Tc
    lie_t = [-sum(XI[l] * s.diff(A[v], X[l]) for l in range(N4)) for v in range(N4)]
    Fd = s.Matrix(N4, N4, lambda i, j: s.diff(lie_t[j], X[i]) - s.diff(lie_t[i], X[j]))
    dL = s.expand(-s.Rational(1, 2) * sum(etai[a, a] * etai[b, b] * F[a, b] * Fd[a, b] for a in range(N4) for b in range(N4)))
    tr_resp = s.expand(dL + sum(s.diff(XI[l] * L, X[l]) for l in range(N4)) - sum(Tc[m, v] * s.diff(XI[v], X[m]) for m in range(N4) for v in range(N4)))
    Tcu, TBu = Tc * etai, TB * etai
    lamg = s.Function('lam')(*X)
    gauge = {A[m]: A[m] + s.diff(lamg, X[m]) for m in range(N4)}
    flags = dict(canonical_response_identity=tr_resp == 0,
                 canonical_nonsymmetric=s.simplify(Tcu - Tcu.T) != s.zeros(N4),
                 canonical_gauge_dependent=s.simplify(Tc.subs(gauge).doit() - Tc) != s.zeros(N4),
                 belinfante_symmetric=s.simplify(TBu - TBu.T) == s.zeros(N4),
                 belinfante_gauge_invariant=s.simplify(TB.subs(gauge).doit() - TB) == s.zeros(N4),
                 belinfante_relation=rel == s.zeros(N4))
    Aas = s.Matrix(4, 4, lambda i, j: s.Symbol(f'w{min(i, j)}{max(i, j)}') * (1 if i < j else -1 if i > j else 0))
    Tsym = s.Matrix(4, 4, lambda i, j: s.Symbol(f'q{min(i, j)}{max(i, j)}'))
    Ttot = Tsym + Aas
    Mrate = s.Matrix(4, 4, lambda i, j: sum(s.diff(X[i] * Ttot[l, j] - X[j] * Ttot[l, i], X[l]) for l in range(4)))
    flags['torque_rate_equals_2w'] = s.simplify(Mrate - 2 * Aas) == s.zeros(4)
    must(all(flags.values()), 'S3')
    R['S3'] = dict(claim='Translation-only transport (components carried, not rotated) generates the canonical Maxwell tensor: '
                         'non-symmetric, U(1)-dependent, differing from the Lie-transport (Belinfante = Hilbert) tensor by '
                         'd_b(F^{ab} A_l) - (d_b F^{ab}) A_l off shell. A constant antisymmetric stress drives angular momentum at rate 2w',
                   status='PROVED (symbolic, off shell)', **{k: bool(v) for k, v in flags.items()})


def S4():
    Xs = s.Function('Xs')(*X)
    al, be = s.symbols('al be')
    boxX = sum(etai[i, i] * s.diff(Xs, X[i], 2) for i in range(N4))
    ddX = s.Matrix(N4, N4, lambda i, j: sum(etai[i, a] * etai[j, b] * s.diff(Xs, X[a], X[b]) for a in range(N4) for b in range(N4)))
    I = al * etai * boxX + be * ddX
    sol = s.solve([s.expand(e) for e in divergence(I)], [be], dict=True)
    If = I.subs(be, -al)
    t00 = s.simplify(If[0, 0] + al * sum(s.diff(Xs, X[k], 2) for k in range(1, 4)))
    t0i = [s.simplify(If[0, k] - al * s.diff(Xs, X[0], X[k])) for k in range(1, 4)]
    ops = [('R phi_i phi_j', 4, True), ('R A^2', 4, False), ('R_mn A^m A^n', 4, False), ('R psibar psi', 5, True),
           ('R F F', 6, True)]
    allowed = [o[0] for o in ops if o[1] <= 4 and o[2]]
    must(sol == [{be: -al}] and t00 == 0 and all(v == 0 for v in t0i) and allowed == ['R phi_i phi_j'], 'S4')
    R['S4'] = dict(claim='alpha eta box X + beta dd X is identically conserved iff beta = -alpha; Delta T^{00} = -alpha lap X, '
                         'Delta T^{0i} = alpha d_t d_i X are spatial divergences (no total charge). With internal gauge invariance and '
                         'dimension <= 4 the only non-minimal coupling is xi_ij R phi_i phi_j', status='PROVED (symbolic) + enumeration',
                   family=str(sol), allowed=allowed)


# =====================================================================================================  PART V
def U1():
    chi = s.Function('chi')(*X)
    m1, m2, c1, c2 = s.symbols('m1 m2 c1 c2')

    def scalarT(f, m):
        d = [s.diff(f, q) for q in X]
        du = [sum(etai[i, j] * d[j] for j in range(N4)) for i in range(N4)]
        Lf = -s.Rational(1, 2) * sum(d[i] * du[i] for i in range(N4)) - m ** 2 * f ** 2 / 2
        return s.Matrix(N4, N4, lambda i, j: du[i] * du[j] + etai[i, j] * Lf)
    resid = [(c1 - 1) * a + (c2 - 1) * b for a, b in zip(divergence(scalarT(PHI, m1)), divergence(scalarT(chi, m2)))]
    eqs = []
    for _ in range(4):
        sub = {PHI: X[0] ** 2 + X[1] * X[2] + int(rng.integers(1, 4)) * X[3], chi: X[1] ** 3 - X[0] * X[3] + int(rng.integers(1, 4)) * X[2]}
        pt = {X[k]: s.Rational(int(rng.integers(1, 6)), 2) for k in range(N4)}
        for r_ in resid:
            e = s.expand(r_.subs(sub).doit().subs(pt).subs({m1: 1, m2: 2}))
            if e != 0:
                eqs.append(e)
    sol = s.solve(eqs, [c1, c2], dict=True)
    cA, ch = s.symbols('c_A c_h')
    hub = s.solve(cA * (cA - ch), cA)
    Bm = s.Matrix([[-1, 0, 1], [0, -1, 1]])
    ns = Bm.nullspace()

    def drift(rA, rB):
        mA, mB = 1.0, 0.3

        def rhs(t, y):
            d = y[2:4] - y[0:2]; r3 = np.linalg.norm(d) ** 3
            return np.r_[y[4:6], y[6:8], (rB * mB) * d / r3, -(rA * mA) * d / r3]
        so = solve_ivp(rhs, (0, 20), np.r_[0, 0, 1, 0, 0, -0.25, 0, 0.9], rtol=1e-11, atol=1e-12, dense_output=True)
        Y = so.sol(np.linspace(0, 20, 201)); P = mA * Y[4:6] + mB * Y[6:8]
        return float(np.max(np.linalg.norm(P - P[:, :1], axis=0)))
    dr = {f'{a}_{b}': fl(drift(a, b)) for a, b in [(1, 1), (1.0, 1.01), (1.0, 1.1), (1.2, 1.2)]}
    must(sol == [{c1: 1, c2: 1}] and set(hub) == {0, ch} and len(ns) == 1 and len(set(ns[0])) == 1
         and dr['1_1'] < 1e-8 and dr['1.2_1.2'] < 1e-8 and dr['1.0_1.1'] > 5 * dr['1.0_1.01'] > 1e-4, 'U1')
    R['U1'] = dict(claim='One coincidence-preserving relabeling acts on every sector located by the record protocol; off-shell invariance '
                         'forces c_A = kappa for two non-interacting sectors (disconnected). Hub: f_A proportional to c_A gives '
                         'c_A (c_A - c_h) = 0. Unequal active/passive ratios make an isolated pair self-accelerate (drift linear in mismatch)',
                   status='PROVED (symbolic) + dynamic destructor', relabeling_solution=str(sol), hub=[str(v) for v in hub],
                   momentum_drift=dr,
                   data={'MICROSCOPE': 'eta(Ti,Pt) = (-1.5 +- 2.3 stat +- 1.5 syst) e-15', 'LLR': 'active/passive Al-Fe < 3.9e-14'})


# =====================================================================================================  PART VI
def M1():
    sym_basis = []
    for i in range(4):
        for j in range(i, 4):
            M = np.zeros((4, 4)); M[i, j] = M[j, i] = 1.0; sym_basis.append(M)
    etaN = np.diag([-1., 1, 1, 1])
    comps = {'scalar': lambda T: (np.sum(etaN * T) * np.linalg.inv(etaN)).reshape(-1),
             'two_form': lambda T: (0.5 * (T - T.T)).reshape(-1),
             'scalar_plus_two_form': lambda T: (np.sum(etaN * T) * np.linalg.inv(etaN) + 0.5 * (T - T.T)).reshape(-1),
             'symmetric_rank2': lambda T: (0.5 * (T + T.T)).reshape(-1)}
    cover = {k: int(np.linalg.matrix_rank(np.array([f(T) for T in sym_basis]), tol=1e-10)) for k, f in comps.items()}
    cover['vector'] = 0
    must(cover == {'scalar': 1, 'two_form': 0, 'scalar_plus_two_form': 1, 'symmetric_rank2': 10, 'vector': 0}, 'M1')
    R['M1'] = dict(claim='The relabeling residual int T^{mu nu} d_mu xi_nu has 10 independent symmetric components. Local covariant '
                         'gauge terms linear in d xi absorb: scalar (d.xi) 1, 2-form (d_[mu xi_nu]) 0, scalar + 2-form 1, vector none '
                         '(no one-index first-derivative term), symmetric rank-2 (d_(mu xi_nu)) 10',
                   status='PROVED (exhaustive within the stated class)', absorbed_rank=cover)


# =====================================================================================================  PART VII
def L1():
    n = 3
    g = s.Matrix(3, 3, lambda i, j: 0)
    A = s.Matrix(3, 3, lambda i, j: s.Rational(int(rng.integers(-3, 4)), 2))
    g = A * A.T + 3 * s.eye(3)
    dg = [[[s.Rational(int(rng.integers(-5, 6)), 3) for _ in range(n)] for _ in range(n)] for _ in range(n)]
    for k in range(n):
        for i in range(n):
            for j in range(i):
                dg[k][i][j] = dg[k][j][i]
    G = [[[s.Symbol(f'G{l}{i}{j}') for j in range(n)] for i in range(n)] for l in range(n)]
    unk = [G[l][i][j] for l in range(n) for i in range(n) for j in range(n)]
    compat = [dg[k][i][j] - sum(G[l][k][i] * g[l, j] + G[l][k][j] * g[i, l] for l in range(n)) for k in range(n) for i in range(n) for j in range(i, n)]
    tors = [G[l][i][j] - G[l][j][i] for l in range(n) for i in range(n) for j in range(i + 1, n)]
    sol = s.solve(compat + tors, unk, dict=True)
    gi = g.inv()
    chris = {G[l][i][j]: sum(gi[l, k] * (dg[j][k][i] + dg[i][k][j] - dg[k][i][j]) for k in range(n)) / 2 for l in range(n) for i in range(n) for j in range(n)}
    unique = len(sol) == 1 and all(s.simplify(sol[0][v] - chris[v]) == 0 for v in unk)
    Mc, _ = s.linear_eq_to_matrix(compat, unk)
    free_compat = len(unk) - Mc.rank()
    must(unique and free_compat == n * n * (n - 1) // 2, 'L1')
    R['L1'] = dict(claim='Metric compatibility plus torsion-freeness determine the connection uniquely (Koszul): at a random point with '
                         'random metric and first derivatives the 27 unknowns are fixed and equal the Christoffel symbols. Without '
                         'torsion-freeness, metric-compatible connections leave n^2(n-1)/2 = 9 free components (contorsion)',
                   status='PROVED (exact linear algebra)', compatible_freedom=int(free_compat))


def L2():
    t, x = s.symbols('t x'); C2 = (t, x); n = 2
    a = s.Function('a')(t, x); b = s.Function('b')(t, x); c = s.Function('c')(t, x)
    g = s.Matrix([[-s.exp(a), b], [b, s.exp(c)]]); gi = g.inv(); sq = s.sqrt(-g.det())
    phi = s.Function('phi')(t, x); V = s.Function('V')
    d = [s.diff(phi, q) for q in C2]
    Lg = -s.Rational(1, 2) * sum(gi[i, j] * d[i] * d[j] for i in range(n) for j in range(n)) - V(phi)
    T = s.Matrix(n, n, lambda i, j: d[i] * d[j] + g[i, j] * Lg)
    Tm = gi * T
    Gam = [[[sum(gi[l, k] * (s.diff(g[k, i], C2[j]) + s.diff(g[k, j], C2[i]) - s.diff(g[i, j], C2[k])) for k in range(n)) / 2
             for j in range(n)] for i in range(n)] for l in range(n)]

    def div(Gm):
        return [sum(s.diff(Tm[m, v], C2[m]) for m in range(n)) + sum(Gm[m][m][l] * Tm[l, v] for m in range(n) for l in range(n))
                - sum(Gm[l][m][v] * Tm[m, l] for m in range(n) for l in range(n)) for v in range(n)]
    box = sum(s.diff(sq * gi[i, j] * d[j], C2[i]) for i in range(n) for j in range(n)) / sq
    eom = box - s.diff(V(phi), phi)
    lc = [s.simplify(dv - eom * d[v]) for v, dv in enumerate(div(Gam))]
    f = s.Function('f')(t, x); df = [s.diff(f, q) for q in C2]
    Ks = {'weyl_nonmetric': lambda l, i, j: ((1 if l == i else 0) * df[j] + (1 if l == j else 0) * df[i] - g[i, j] * sum(gi[l, k] * df[k] for k in range(n))),
          'vector_torsion': lambda l, i, j: (1 if l == i else 0) * df[j] - (1 if l == j else 0) * df[i]}
    dests = {}
    uu = s.Symbol('uu')
    sub = {a: t * x / 5, b: (t - x) / 7, c: x ** 2 / 9, phi: s.sin(t) + x ** 2, f: t + 2 * x + t * x ** 2}
    pt = {t: s.Rational(1, 3), x: s.Rational(1, 2)}
    for name, K in Ks.items():
        G2 = [[[Gam[l][i][j] + K(l, i, j) for j in range(n)] for i in range(n)] for l in range(n)]
        r_ = [dv - eom * d[v] for v, dv in enumerate(div(G2))]
        dests[name] = [fl(s.N(ri.subs(V, s.Lambda(uu, uu ** 2 / 2)).subs(sub).doit().subs(pt), 15)) for ri in r_]
    must(lc == [0, 0] and all(any(abs(v) > 1e-6 for v in vs) for vs in dests.values()), 'L2')
    R['L2'] = dict(claim='Noether II: for a relabeling-invariant scalar action on a generic 2-D metric (three free functions, arbitrary V), '
                         'nabla_mu T^mu_nu = (box phi - V\') d_nu phi with Levi-Civita. Weyl non-metricity and vector torsion change the '
                         'identity (they are resolvable by scalar records); in 2-D both change it by the same term 2 d_l f T^l_nu - T^l_l d_nu f, '
                         'which the identical probe values reflect', status='PROVED (symbolic) + probes',
                   levi_civita_residual=[str(v) for v in lc], deformation_residuals=dests)


def L3():
    n = 4
    Hc = {c: s.Function(f'H{"".join(map(str, c))}')(*X) for c in itertools.combinations(range(4), 3)}

    def H(i, j, k):
        idx = (i, j, k)
        if len(set(idx)) < 3:
            return 0
        srt = tuple(sorted(idx))
        perm = [srt.index(v) for v in idx]
        sign = 1
        for a_ in range(3):
            for b_ in range(a_ + 1, 3):
                if perm[a_] > perm[b_]:
                    sign = -sign
        return sign * Hc[srt]
    K = [[[sum(etai[r, q] * H(q, m, v) for q in range(n)) for v in range(n)] for m in range(n)] for r in range(n)]
    Tg = s.Matrix(n, n, lambda i, j: s.Function(f'T{min(i, j)}{max(i, j)}')(*X))
    dT = [s.expand(sum(K[m][m][l] * Tg[l, v] for m in range(n) for l in range(n)) + sum(K[v][m][l] * Tg[m, l] for m in range(n) for l in range(n)))
          for v in range(n)]
    trK = [s.expand(sum(etai[m, v] * K[r][m][v] for m in range(n) for v in range(n))) for r in range(n)]
    u = s.symbols('u0:4')
    auto = [s.expand(sum(K[r][m][v] * u[m] * u[v] for m in range(n) for v in range(n))) for r in range(n)]
    # metric compatibility of Gamma_LC + K on flat background: K_{r m v} antisymmetric in (r, v)
    compat = all(s.expand(sum(eta[r, q] * K[q][m][v] for q in range(n)) + sum(eta[v, q] * K[q][m][r] for q in range(n))) == 0
                 for r in range(n) for m in range(n) for v in range(n))
    torsion_nonzero = any(s.expand(K[r][m][v] - K[r][v][m]) != 0 for r in range(n) for m in range(n) for v in range(n))
    # scalar commutator sees it: [nabla_m, nabla_v] phi = -2 K^r_{m v} d_r phi
    comm = s.expand(sum((K[r][0][1] - K[r][1][0]) * DPHI[r] for r in range(n)))
    ok = compat and torsion_nonzero and all(v == 0 for v in dT + trK + auto) and comm != 0
    must(ok, 'L3')
    R['L3'] = dict(claim='Correction: contorsion K^r_{mv} = H^r_{mv} from an arbitrary 3-form H is metric compatible with nonzero torsion '
                         '2K, yet leaves the divergence of every symmetric T, the scalar box and every autoparallel unchanged. Scalar, '
                         'Maxwell (F = dA) and point-particle records cannot resolve it; it appears only in the antisymmetrized second '
                         'derivative [nabla, nabla] phi = -2 K d phi, which no minimally coupled bosonic Lagrangian contains. By the '
                         'descent criterion (C2) it is null for those protocols and is quotiented; spinor (axial) protocols resolve it',
                   status='PROVED (symbolic, generic H and T)', metric_compatible=bool(compat), torsion_nonzero=bool(torsion_nonzero),
                   stress_divergence_change=[str(v) for v in dT], box_change=[str(v) for v in trK], autoparallel_change=[str(v) for v in auto])


# =====================================================================================================  PART VIII
def E1():
    Xs = s.symbols('x0:4')
    A, Bc, C, D, E, a0, b0 = s.symbols('A B C D E a0 b0')
    dd = lambda f, i: s.diff(f, Xs[i]); up = lambda i: eta[i, i]
    box = lambda f: sum(up(a) * dd(dd(f, a), a) for a in range(4))

    def op(h, mass=False):
        tr = sum(up(a) * h[a, a] for a in range(4))
        v = [sum(up(a) * dd(h[a, n], a) for a in range(4)) for n in range(4)]
        dv = sum(up(a) * dd(v[a], a) for a in range(4))
        M = s.Matrix(4, 4, lambda m, n: A * box(h[m, n]) + Bc * (dd(v[n], m) + dd(v[m], n)) + C * dd(dd(tr, m), n) + eta[m, n] * (D * dv + E * box(tr)))
        if mass:
            M = M + s.Matrix(4, 4, lambda m, n: a0 * h[m, n] + b0 * eta[m, n] * tr)
        return M

    def coeff_eqs(exprs):
        out = set()
        for ex in exprs:
            ex = s.expand(ex)
            for dv_ in ex.atoms(s.Derivative):
                cc = ex.coeff(dv_)
                if cc != 0:
                    out.add(s.simplify(cc))
        return out
    xi = [s.Function(f'k{i}')(*Xs) for i in range(4)]; xil = [eta[i, i] * xi[i] for i in range(4)]
    hg = s.Matrix(4, 4, lambda i, j: dd(xil[i], j) + dd(xil[j], i))
    gauge = coeff_eqs([op(hg)[i, j] for i in range(4) for j in range(i, 4)])
    Hh = [[None] * 4 for _ in range(4)]
    for i in range(4):
        for j in range(i, 4):
            Hh[i][j] = Hh[j][i] = s.Function(f'h{i}{j}')(*Xs)
    h = s.Matrix(4, 4, lambda i, j: Hh[i][j])
    Eh = op(h)
    div = coeff_eqs([sum(up(m) * dd(Eh[m, n], m) for m in range(4)) for n in range(4)])
    p = s.symbols('p0:4')
    basis = [(i, j) for i in range(4) for j in range(i, 4)]

    def unit(i, j):
        hh = s.zeros(4); hh[i, j] = 1; hh[j, i] = 1; return hh

    def sym_op(i, j):
        hh = unit(i, j)
        tr = sum(up(a) * hh[a, a] for a in range(4)); pu = [up(a) * p[a] for a in range(4)]
        v = [sum(pu[a] * hh[a, n] for a in range(4)) for n in range(4)]; p2 = sum(pu[a] * p[a] for a in range(4)); dv = sum(pu[a] * v[a] for a in range(4))
        return s.Matrix(4, 4, lambda m, n: -(A * p2 * hh[m, n] + Bc * (p[m] * v[n] + p[n] * v[m]) + C * p[m] * p[n] * tr + eta[m, n] * (D * dv + E * p2 * tr)))
    pair = lambda k, hh: sum(up(m) * up(n) * k[m, n] * hh[m, n] for m in range(4) for n in range(4))
    sa = set()
    for (i, j) in basis:
        for (k, l) in basis:
            ex = s.expand(pair(unit(k, l), sym_op(i, j)) - pair(sym_op(k, l), unit(i, j)))
            if ex != 0:
                for _, cc in s.Poly(ex, *p).terms():
                    if cc != 0:
                        sa.add(s.simplify(cc))
    sol = lambda eqs: s.solve(list(eqs), [Bc, C, D, E], dict=True)
    fam = dict(gauge=sol(gauge), divergence=sol(div), self_adjoint=sol(sa), gauge_div=sol(gauge | div), gauge_sa=sol(gauge | sa), div_sa=sol(div | sa))
    target = {Bc: -A, C: A, D: A, E: -A}
    trh = sum(up(a) * h[a, a] for a in range(4))
    Ric1 = s.Matrix(4, 4, lambda m, n: s.Rational(1, 2) * (sum(up(a) * (dd(dd(h[a, n], a), m) + dd(dd(h[a, m], a), n)) for a in range(4)) - box(h[m, n]) - dd(dd(trh, m), n)))
    R1 = sum(up(a) * Ric1[a, a] for a in range(4))
    G1 = Ric1 - eta * R1 / 2
    Esel = op(h).subs(target)
    isG = all(s.expand(Esel[i, j] + 2 * A * G1[i, j]) == 0 for i in range(4) for j in range(4))
    gm = coeff_eqs([op(hg, mass=True)[i, j] for i in range(4) for j in range(i, 4)])
    msol = s.solve(list(gm), [Bc, C, D, E, a0, b0], dict=True)
    ric_g = [s.expand(Ric1.subs({Hh[i][j]: hg[i, j] for i in range(4) for j in range(4)}).doit()[i, j]) for i in range(4) for j in range(4)]
    ric_div = [s.expand(sum(up(m) * dd(Ric1[m, n], m) for m in range(4))) for n in range(4)]
    ok = (all(fam[k] == [target] for k in ('gauge_div', 'gauge_sa', 'div_sa')) and fam['gauge'] == [{Bc: -A, C: A, D: -E}]
          and fam['divergence'] == [{Bc: -A, C: -E, D: A}] and isG and msol[0][a0] == 0 and msol[0][b0] == 0
          and all(s.simplify(e) == 0 for e in ric_g) and any(e != 0 for e in ric_div))
    must(ok, 'E1')
    R['E1'] = dict(claim='General local, Lorentz-covariant, parity-even, two-derivative operator on symmetric h: A box h + B(dv + dv) + '
                         'C dd trh + eta(D d.v + E box trh). Gauge alone: B=-A, C=A, D=-E; identical divergence-freeness alone: '
                         'B=-A, C=-E, D=A; any two of {gauge, divergence-free, self-adjoint}: -2A G^(1). Mass terms forbidden by gauge; '
                         'linearized Ricci gauge invariant but not divergence-free', status='PROVED (symbolic, generic functions)',
                   families={k: str(v) for k, v in fam.items()})


# =====================================================================================================  PART IX
def N1():
    x, y, z, G = s.symbols('x y z G', positive=True)
    Ph = s.Function('Phi')(x, y, z); Cc = (x, y, z)
    grad = [s.diff(Ph, c) for c in Cc]
    t = s.Matrix(3, 3, lambda i, j: (grad[i] * grad[j] - (1 if i == j else 0) * sum(g_ * g_ for g_ in grad) / 2) / (4 * s.pi * G))
    rho = sum(s.diff(Ph, c, 2) for c in Cc) / (4 * s.pi * G)
    res = [s.simplify(sum(s.diff(t[i, j], Cc[j]) for j in range(3)) - rho * grad[i]) for i in range(3)]
    must(res == [0, 0, 0], 'N1')
    R['N1'] = dict(claim='The mediator carries momentum: d_j t^{ij} = rho d_i Phi exactly (Poisson), balancing the force -rho d_i Phi on '
                         'matter. Bound matter has d T_m = f != 0, which an identically divergence-free linear response cannot equal: '
                         'the mediator enters its own source', status='PROVED (symbolic)')


def N2():
    def flrw(dim):
        t = s.symbols('t'); xs = s.symbols(f'y0:{dim - 1}')
        N = s.Function('N')(t); a = s.Function('a')(t)
        g = s.diag(*([-N ** 2] + [a ** 2] * (dim - 1)))
        Rs, Ric2, Riem2, Ric, gi, Gam = invariants(g, [t] + list(xs))
        sq = N * a ** (dim - 1); GB = s.simplify(Riem2 - 4 * Ric2 + Rs ** 2)
        out = {}
        for name, Lag in (('R', sq * Rs), ('GB', sq * GB), ('R2', sq * Rs ** 2)):
            el = [s.simplify(e_.lhs) for e_ in euler_equations(s.simplify(Lag), [N, a], t)]
            order = max([max([dv_.derivative_count for dv_ in s.sympify(ex).atoms(s.Derivative)] + [0]) for ex in el])
            out[name] = dict(EL_identically_zero=all(ex == 0 for ex in el), max_derivative_order=int(order))
        return out
    f4, f5 = flrw(4), flrw(5)
    must(f4['GB']['EL_identically_zero'] and not f5['GB']['EL_identically_zero'] and f5['GB']['max_derivative_order'] == 2
         and f4['R']['max_derivative_order'] == 2 and f4['R2']['max_derivative_order'] == 4, 'N2')
    R['N2'] = dict(claim='Gauss-Bonnet has identically vanishing Euler-Lagrange equations in 4-D (topological) and second-order ones in 5-D; '
                         'R gives second order, R^2 fourth order (FLRW minisuperspace with lapse)', status='PROVED (symbolic, minisuperspace)',
                   D4=f4, D5=f5)


# =====================================================================================================  PART X
def D1():
    def eD(D):
        return np.diag([-1.] + [1.] * (D - 1))

    def Nsp2(T1, T2, D, beta):
        e = eD(D)
        return float(np.sum((e @ T1 @ e) * T2) - beta * np.sum(e * T1) * np.sum(e * T2))
    table = {}
    for D in [4, 5, 6]:
        Ms = np.zeros((D, D)); Ms[0, 0] = 1
        k = np.zeros(D); k[:2] = 1; Ph = np.outer(k, k)
        for lab, beta in [('massless_spin2', 1 / (D - 2)), ('massive_spin2', 1 / (D - 1))]:
            st, ph = Nsp2(Ms, Ms, D, beta), Nsp2(Ms, Ph, D, beta)
            table[f'{lab}_D{D}'] = dict(static=fl(st), gamma=fl(ph / st - 1), attractive=st > 0)
        e = eD(D)
        st, ph = float(np.sum(e * Ms) ** 2), float(np.sum(e * Ms) * np.sum(e * Ph))
        table[f'spin0_D{D}'] = dict(static=fl(st), gamma=fl(ph / st - 1), attractive=st > 0)
    e4 = eD(4); Ms = np.zeros((4, 4)); Ms[0, 0] = 1; J = -(Ms @ e4 @ np.array([1., 0, 0, 0]))
    table['spin1_D4'] = dict(static=fl(J @ e4 @ J), attractive=bool(J @ e4 @ J > 0))
    lo, hi = 2.1e-5 - 2 * 2.3e-5, 2.1e-5 + 2 * 2.3e-5
    surv = [k for k, v in table.items() if 'gamma' in v and v['attractive'] and lo <= v['gamma'] - 1 <= hi]
    must(surv == ['massless_spin2_D4'] and not table['spin1_D4']['attractive'], 'D1')
    R['D1'] = dict(claim='gamma = N(mass,photon)/N(mass,mass) - 1 from exact propagator numerators: massless spin 2 gamma = 1/(D-3), '
                         'massive spin 2 (Fierz-Pauli) 1/2 in D=4, spin 0 on trace -1, spin 1 repels like energies; Cassini 2 sigma '
                         'leaves only massless spin 2 in D=4; Brans-Dicke needs omega >= %.0f' % (-1 / lo - 2),
                   status='COMPUTED + data', table=table, survivors=surv)


def D2():
    r, Lm, k = s.symbols('r L k', positive=True)
    res = {}
    for nsp in [3, 4, 5, 6]:
        U = Lm ** 2 / (2 * r ** 2) - k / r ** (nsp - 2)
        rc = [v for v in s.solve(s.diff(U, r), r) if v.is_positive]
        stable = bool(rc) and bool(s.sign(s.simplify(s.diff(U, r, 2).subs(r, rc[0])).subs({Lm: 1, k: 1})) > 0)
        res[str(nsp)] = stable
    must(res == {'3': True, '4': False, '5': False, '6': False}, 'D2')
    R['D2'] = dict(claim='Green-function potential 1/r^(n-2): stable circular orbits only for n = 3 space dimensions',
                   status='PROVED (symbolic)', stable=res)


def D3():
    t, a1, a2, w1, w2 = s.symbols('t a1 a2 w1 w2', positive=True)
    q = a1 * s.cos(w1 * t) + a2 * s.cos(w2 * t)
    qd, qdd, qddd = [s.diff(q, t, k) for k in (1, 2, 3)]
    L = -qdd ** 2 / 2 + (w1 ** 2 + w2 ** 2) * qd ** 2 / 2 - w1 ** 2 * w2 ** 2 * q ** 2 / 2
    H = s.simplify(((w1 ** 2 + w2 ** 2) * qd + qddd) * qd - qdd * qdd - L)
    ok = s.simplify(H + (w1 ** 2 - w2 ** 2) * (w1 ** 2 * a1 ** 2 - w2 ** 2 * a2 ** 2) / 2) == 0
    amp = {str(kk): fl(np.exp(kk)) for kk in [1, 10, 50]}
    must(ok and amp['50'] > 1e20, 'D3')
    R['D3'] = dict(claim='Fourth-order (Pais-Uhlenbeck) energy -(w1^2-w2^2)(w1^2 a1^2 - w2^2 a2^2)/2: opposite-sign modes (ghost). '
                         'Euclidean mediator d_t^2 u + lap u = 0: amplification e^{k t} unbounded in k (Hadamard ill-posed)',
                   status='PROVED (symbolic) + exact', ostrogradsky=str(H), euclidean_amplification_t1=amp)


def D4():
    t, rr, th, ph = s.symbols('t r theta phi'); M_, Lam, al = s.symbols('M Lambda alpha', positive=True)
    Xc = [t, rr, th, ph]

    def fR(g, Lam_eff):
        gi, Gam, Rm, Ric, Rs = curvature(g, Xc)
        fp = 1 + 2 * al * Rs; f = Rs - 2 * Lam_eff + al * Rs ** 2
        Hs = s.Matrix(4, 4, lambda a, b: s.diff(fp, Xc[a], Xc[b]) - sum(Gam[cc][a][b] * s.diff(fp, Xc[cc]) for cc in range(4)))
        bx = sum(gi[a, b] * Hs[a, b] for a in range(4) for b in range(4))
        return (fp * Ric - f * g / 2 + g * bx - Hs).applyfunc(s.simplify), Rs
    Af = 1 - 2 * M_ / rr - Lam * rr ** 2 / 3
    g = s.diag(-Af, 1 / Af, rr ** 2, rr ** 2 * s.sin(th) ** 2)
    Eq, Rs = fR(g, Lam); EqW, _ = fR(g, 2 * Lam)
    kre = s.simplify(invariants(g, Xc)[2] - s.Rational(8, 3) * Lam ** 2)
    must(Eq == s.zeros(4, 4) and EqW != s.zeros(4, 4) and s.simplify(Rs - 4 * Lam) == 0 and s.simplify(kre - 48 * M_ ** 2 / rr ** 6) == 0, 'D4')
    R['D4'] = dict(claim='Every vacuum Einstein metric solves R + alpha R^2 - 2 Lambda for every alpha; Schwarzschild-de Sitter witness '
                         '(Kretschmann - 8 Lambda^2/3 = 48 M^2/r^6), wrong-Lambda canary fails', status='PROVED (symbolic)')


def D5():
    tt, r7, th7, ph7, eps, al7, GM = s.symbols('t r theta phi epsilon alpha GM', positive=True)
    m7 = 1 / s.sqrt(6 * al7)
    Psi = -GM / r7 * (1 + s.exp(-m7 * r7) / 3); Phi = -GM / r7 * (1 - s.exp(-m7 * r7) / 3)
    P_ = s.Function('P')(r7); Q_ = s.Function('Q')(r7)
    X7 = [tt, r7, th7, ph7]
    g7 = s.diag(-(1 + 2 * eps * P_), (1 - 2 * eps * Q_), (1 - 2 * eps * Q_) * r7 ** 2, (1 - 2 * eps * Q_) * r7 ** 2 * s.sin(th7) ** 2)
    gi7, Gam7, Rm7, Ric7, Rs7 = curvature(g7, X7)
    Ric1 = Ric7.applyfunc(lambda e_: s.simplify(s.diff(e_, eps).subs(eps, 0))); R1 = s.simplify(s.diff(Rs7, eps).subs(eps, 0))
    g0 = g7.subs(eps, 0); gi0 = g0.inv(); Gam0 = [[[s.simplify(c_.subs(eps, 0)) for c_ in row] for row in mat] for mat in Gam7]
    Hs = s.Matrix(4, 4, lambda a, b: s.diff(R1, X7[a], X7[b]) - sum(Gam0[cc][a][b] * s.diff(R1, X7[cc]) for cc in range(4)))
    bx = s.simplify(sum(gi0[a, b] * Hs[a, b] for a in range(4) for b in range(4)))
    Eq = s.Matrix(4, 4, lambda a, b: Ric1[a, b] - g0[a, b] * R1 / 2 + 2 * al7 * (g0[a, b] * bx - Hs[a, b])).subs({P_: Psi, Q_: Phi}).doit()
    vac = all(s.simplify(Eq[i, j]) == 0 for i in range(4) for j in range(4))
    R1y = s.simplify(R1.subs({P_: Psi, Q_: Phi}).doit())
    xx = s.Symbol('x', positive=True)
    lower = 2.1e-5 - 2 * 2.3e-5
    x_min = float(s.nsolve(2 * s.exp(-xx) / (3 + s.exp(-xx)) - abs(lower), xx, 10))
    b = 1.6 * 6.957e8
    must(vac and s.simplify(R1y / (2 * GM * m7 ** 2 * s.exp(-m7 * r7) / r7)) == 1, 'D5')
    R['D5'] = dict(claim='Weak field of R + alpha R^2: Psi, Phi = -GM/r (1 +- e^{-mr}/3), m = 1/sqrt(6 alpha), R1 = 2 GM m^2 e^{-mr}/r; '
                         'gamma(r) = (3 - e^{-mr})/(3 + e^{-mr}); Cassini bounds the range, torsion balances push it below the sub-mm scale',
                   status='PROVED (symbolic) + bounds', cassini_min_mb=fl(x_min), cassini_max_range_m=fl(b / x_min),
                   cassini_max_alpha_m2=fl((b / x_min) ** 2 / 6), lab='|alpha_Y| = 1 Yukawa excluded beyond 38.6 um (95%)')


# =====================================================================================================  PART XI
def Q1():
    Lbox = 2 * np.pi; Tend = 4.0

    def run(N, lam):
        a = Lbox / N; xg = np.arange(N) * a
        p0 = 0.6 * np.cos(xg) + 0.3 * np.sin(2 * xg + 0.4); v0 = 0.5 * np.sin(xg) - 0.2 * np.cos(3 * xg)

        def rhs(t, y):
            p = y[:N]; v = y[N:]
            return np.r_[v, (np.roll(p, -1) - 2 * p + np.roll(p, 1)) / a ** 2 - p - lam * p ** 3]
        P = lambda y: -np.sum(y[N:] * (np.roll(y[:N], -1) - np.roll(y[:N], 1)) / (2 * a)) * a
        E = lambda y: np.sum(0.5 * y[N:] ** 2 + 0.5 * ((np.roll(y[:N], -1) - y[:N]) / a) ** 2 + 0.5 * y[:N] ** 2 + 0.25 * lam * y[:N] ** 4) * a
        so = solve_ivp(rhs, (0, Tend), np.r_[p0, v0], method='DOP853', rtol=1e-12, atol=1e-13, dense_output=True)
        Y = so.sol(np.linspace(0, Tend, 401))
        Ps = np.array([P(Y[:, k]) for k in range(Y.shape[1])]); Es = np.array([E(Y[:, k]) for k in range(Y.shape[1])])
        return float(np.max(np.abs(Ps - Ps[0]))), float(np.max(np.abs(Es - Es[0])) / Es[0])
    Ns = [16, 32, 64, 128]
    nl = [run(N, 1.0) for N in Ns]; li = [run(N, 0.0) for N in Ns]
    slope = float(np.polyfit(np.log(Ns), np.log([d for d, _ in nl]), 1)[0])
    must(abs(slope + 2) < 0.1 and max(e for _, e in nl) < 1e-10 and max(d for d, _ in li) < 1e-9, 'Q1')
    R['Q1'] = dict(claim='Continuous-time phi^4 chain: energy conserved; label-translation momentum exactly conserved for linear dynamics '
                         'and broken by on-site nonlinearity at O(a^2); restored only in the continuum limit',
                   status='EXECUTED (deterministic)', nonlinear_drift={str(N): fl(d) for N, (d, _) in zip(Ns, nl)}, slope=fl(slope),
                   linear_drift_max=fl(max(d for d, _ in li)), energy_rel_error_max=fl(max(e for _, e in nl)))


def Q2():
    t = s.Symbol('t')
    coeffs = []
    for r in range(1, 7):
        ser = s.series(s.besselj(2 * r, 2 * t), t, 0, 2 * r + 3).removeO()
        coeffs.append(str(s.Poly(ser, t).coeff_monomial(t ** (2 * r))))
    lead_ok = all(s.Rational(cf) == s.Rational(1, factorial(2 * r)) for r, cf in zip(range(1, 7), coeffs))
    # numerical lattice response vs Bessel, and leakage outside the group-velocity cone r > t
    N = 81; c0 = 40
    def rhs(tt, y):
        p = y[:N]; v = y[N:]
        return np.r_[v, np.roll(p, -1) - 2 * p + np.roll(p, 1)]
    y0 = np.zeros(2 * N); y0[c0] = 1
    so = solve_ivp(rhs, (0, 10), y0, method='DOP853', rtol=1e-12, atol=1e-15, dense_output=True)
    Tt = 10.0; Y = so.sol(Tt)[:N]
    errs = max(abs(Y[c0 + r] - jv(2 * r, 2 * Tt)) for r in range(0, 30))
    leak = {}
    for fac in [1.0, 1.5, 2.0, 3.0]:
        r = int(np.ceil(fac * Tt)); leak[str(fac)] = dict(r=r, J=fl(abs(jv(2 * r, 2 * Tt))), bound=fl(Tt ** (2 * r) / factorial(2 * r)))
    nonzero = all(abs(jv(2 * r, 2 * 0.1)) > 0 for r in range(1, 7))
    must(lead_ok and errs < 1e-8 and nonzero and leak['3.0']['J'] < 1e-15 and leak['3.0']['J'] <= leak['3.0']['bound'], 'Q2')
    R['Q2'] = dict(claim='Correction: the continuous-time harmonic chain has no strict front. The response to a unit displacement is '
                         'u_r(t) = J_{2r}(2t) with leading term t^{2r}/(2r)! (verified r = 1..6), nonzero at every distance for t > 0. '
                         'Outside the maximal group velocity (r > t) leakage is bounded by t^{2r}/(2r)! and falls super-exponentially: '
                         'an effective cone, not a causal front. A strict cone requires a domain-of-dependence limit',
                   status='PROVED (series) + executed', leading_coefficients=coeffs, lattice_vs_bessel_max_error=fl(errs), leakage_t10=leak)


if __name__ == '__main__':
    U, obs, cls = C2(); C1(); C3(U, obs, cls)
    for f in [C4, C5, C6, B1, B2, B3, R1_, R2_, R3_]:
        f(); print(f.__name__, flush=True)
    T = S1(); S2(T); print('S1 S2', flush=True)
    for f in [S3, S4, U1, M1, L1, L2, L3, E1, N1, N2, D1, D2, D3, D4, D5, Q1, Q2]:
        f(); print(f.__name__, flush=True)
    R['source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    R['helper_sha256'] = hashlib.sha256((HERE / 'rg_curv.py').read_bytes()).hexdigest()
    R['seed'] = SEED
    R['groups'] = len([k for k in R if k[0] in 'CBRSUMLENDQ' and k[1:].isdigit()])
    R['failures'] = FAILS
    (HERE / 'rg_tensor_derivation_results.json').write_text(json.dumps(R, indent=1, sort_keys=True, default=str) + '\n')
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}', R['groups'])
    sys.exit(1 if FAILS else 0)
