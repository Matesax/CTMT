"""Finite-alphabet Cencov-surrounding theorem battery. Synthetic mathematical examples.
Run: python rg_cencov_battery.py --out .
No numerical pass is used as a proof of a universal theorem.
"""
import argparse,csv,hashlib,json,platform
from pathlib import Path
import numpy as np
import scipy
from scipy.integrate import quad
from scipy.linalg import null_space
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
SEEDS=[101,202,303,404,505]
SPEC={'seeds':SEEDS,'dimensions':[2,3,5,8],'trials_per_seed_dimension':40,'mixture_quadrature_cases':100,'path_cases':100,'rational_splitting_cases':200,'approximate_symmetry_cases':200,'spectral_cases':200,'tolerance':1e-9,'scope':'Finite alphabets, positive laws, parameter-independent stochastic channels; synthetic examples only.','design_status':'Source-defined development battery, not external preregistration.'}
def main(out):
 out=Path(out); out.mkdir(parents=True,exist_ok=True)
 rows=[]; checks=[]; summary={}; metrics={}
 def record(family,**kw): rows.append(dict(family=family,**kw))
 def check(name,ok,value): checks.append(dict(name=name,passed=bool(ok),value=value))
 def law(rng,n): return rng.dirichlet(np.full(n,2.))
 def channel(rng,m,n): return np.column_stack([rng.dirichlet(np.full(m,2.)) for _ in range(n)])
 def F(p,v): return float(np.sum(v*v/p))
 def KL(p,q): return float(np.sum(p*np.log(p/q)))
 def TV(p,q): return float(np.sum(abs(p-q))/2)
 def bayes(q,K): return (q[:,None]*K.T)/(K@q)[None,:]
 def defect(p,v,K): return F(p,v)-F(K@p,K@v)
 errs={k:[] for k in ['variance','chi_identity','chi_recovery','kl_conditional','kl_recovery','pinsker','fisher_cocycle','kl_cocycle','bayes_composition','fr_contraction','tensor_KL']}
 for seed in SEEDS:
  rng=np.random.default_rng(seed)
  for n in SPEC['dimensions']:
   for trial in range(40):
    m=max(2,n-1); K=channel(rng,m,n); L=channel(rng,max(2,m-1),m)
    q=law(rng,n); pp=law(rng,n); v=rng.normal(size=n); v-=v.mean(); v/=np.linalg.norm(v)
    y=K@q; score=v/q; sy=(K@v)/y
    var=float(np.sum(q[None,:]*K*(score[None,:]-sy[:,None])**2)); delta=defect(q,v,K)
    ev=abs(delta-var)/(1+abs(delta)); errs['variance'].append(ev)
    R=bayes(q,K); f=pp/q-1; chis=F(q,pp-q)-F(y,K@(pp-q)); jointvar=float(np.sum(q[None,:]*K*(f[None,:]-((K@(pp-q))/y)[:,None])**2))
    rec=R@(K@pp); recchi=F(q,pp-rec)
    errs['chi_identity'].append(abs(chis-jointvar)/(1+abs(chis)))
    errs['chi_recovery'].append(recchi-chis)
    gap=KL(pp,q)-KL(K@pp,y)
    postp=bayes(pp,K); postq=R
    cond=float(np.sum((K@pp)*np.sum(postp*np.log(postp/postq),axis=0)))
    errs['kl_conditional'].append(abs(gap-cond)/(1+abs(gap)))
    errs['kl_recovery'].append(KL(pp,rec)-gap); errs['pinsker'].append(2*TV(pp,rec)**2-gap)
    coc=defect(q,v,L@K)-delta-defect(y,K@v,L)
    errs['fisher_cocycle'].append(abs(coc)/(1+F(q,v)))
    errs['kl_cocycle'].append(abs((KL(pp,q)-KL(L@K@pp,L@y))-gap-(KL(K@pp,y)-KL(L@K@pp,L@y))))
    errs['bayes_composition'].append(float(np.max(abs(bayes(q,L@K)-R@bayes(y,L)))))
    aff=float(np.sqrt(pp*q).sum()); affout=float(np.sqrt((K@pp)*y).sum())
    errs['fr_contraction'].append(aff-affout)
    # Independent-product KL-loss additivity.
    q2=law(rng,2); p2=law(rng,2); K2=channel(rng,2,2)
    g2=KL(p2,q2)-KL(K2@p2,K2@q2)
    gt=KL(np.kron(pp,p2),np.kron(q,q2))-KL(np.kron(K@pp,K2@p2),np.kron(y,K2@q2))
    errs['tensor_KL'].append(abs(gt-gap-g2))
    record('C01_random_channels',seed=seed,n=n,trial=trial,fisher_defect=delta,variance_relative_error=ev,chi_loss=chis,chi_recovery_error=recchi,KL_loss=gap,recovery_TV=TV(pp,rec))
 for key in ['variance','chi_identity','kl_conditional','fisher_cocycle','kl_cocycle','bayes_composition','tensor_KL']:
  check(key,max(errs[key])<1e-9,float(max(errs[key])))
 for key in ['chi_recovery','kl_recovery','pinsker','fr_contraction']:
  check(key,max(errs[key])<1e-9,float(max(errs[key])))
 summary['random_cases']=800
 # Integrated Fisher defect equals KL loss on affine mixture paths.
 rng=np.random.default_rng(606); integ=[]; bounds=[]
 for i in range(100):
  n=int(rng.choice([2,3,5,8])); K=channel(rng,max(2,n-1),n); q=law(rng,n); pp=law(rng,n); v=pp-q
  val,qe=quad(lambda t:(1-t)*defect(q+t*v,v,K),0,1,epsabs=1e-11,epsrel=1e-11)
  gap=KL(pp,q)-KL(K@pp,K@q); er=abs(val-gap); integ.append(er)
  bound=np.sqrt(max(0,val)/2); actual=TV(pp,bayes(q,K)@(K@pp)); bounds.append(actual-bound)
  record('C02_integrated_loss',case=i,n=n,integral=val,KL_loss=gap,error=er,recovery_TV=actual,bound=bound)
 check('mixture_Fisher_integral',max(integ)<1e-9,float(max(integ)))
 check('integrated_recovery_bound',max(bounds)<1e-9,float(max(bounds)))
 # Arbitrary smooth positive path, fixed base recovery and endpoint-output overlap.
 path_errors=[]; ratios=[]
 for i in range(100):
  n=4; K=channel(rng,3,n); q=law(rng,n); a=rng.normal(size=n); b=rng.normal(size=n)*.3
  def path(t):
   logits=np.log(q)+a*t+b*np.sin(np.pi*t); logits-=max(logits); pp=np.exp(logits); pp/=pp.sum()
   dlog=a+b*np.pi*np.cos(np.pi*t); v=pp*(dlog-np.dot(pp,dlog)); return pp,v
  end,_=path(1); w=K@end
  def integrand(t):
   pp,v=path(t); dd=max(0,defect(pp,v,K)); overlap=np.sum(w*w/(K@pp)); return .5*np.sqrt(dd*overlap)
  bound=quad(integrand,0,1,epsabs=1e-10)[0]; actual=TV(end,bayes(q,K)@(K@end)); path_errors.append(actual-bound); ratios.append(actual/bound if bound>0 else 0)
  record('C03_path_recovery',case=i,recovery_TV=actual,bound=bound,ratio=ratios[-1])
 check('path_recovery_bound',max(path_errors)<1e-9,float(max(path_errors)))
 summary['max_path_bound_ratio']=float(max(ratios))
 # Approximate Cencov selection, explicit admissible conformal family.
 # h_n(p)=exp(eps*sum(p_i^2))*F; all splitting log distortions <=eps.
 splitting=[]; robust=[]; equalities=[]
 for i in range(200):
  n=int(rng.choice([2,3,5,8])); counts=rng.integers(1,6,n); N=int(counts.sum()); pp=counts/N; v=rng.normal(size=n); v-=v.mean()
  E=np.zeros((2*N,n)); off=0
  for j,k in enumerate(counts): E[off:off+2*k,j]=1/(2*k); off+=2*k
  U=np.zeros((2*N,2)); U[:N,0]=1/N; U[N:,1]=1/N
  eps=float(rng.choice([0,.001,.01,.1])); h=lambda p,v:np.exp(eps*np.dot(p,p))*F(p,v)
  ep=E@pp; vv=E@v; distortion=abs(np.log(h(ep,vv)/h(pp,v))) if F(pp,v)>0 else 0
  normalized=abs(np.log(h(pp,v)/(np.exp(eps/2)*F(pp,v))))
  splitting.append(distortion-eps); robust.append(normalized-2*eps)
  # Exact rational splitting calculation used in the proof.
  er=abs(F(ep,vv)-F(pp,v))/(1+F(pp,v)); equalities.append(er)
  record('C04_robust_selection',case=i,n=n,N=N,epsilon=eps,embedding_log_distortion=distortion,normalized_log_deviation=normalized,rational_Fisher_error=er)
 check('rational_splitting_identity',max(equalities)<1e-10,float(max(equalities)))
 check('approx_embedding_example',max(splitting)<1e-10,float(max(splitting)))
 check('robust_Cencov_envelope_example',max(robust)<1e-10,float(max(robust)))
 saved_rng_state=rng.bit_generator.state
 # Non-symmetric family: h_n=sum(exp(eps*b_i)*v_i^2/p_i), b_i in [0,1].
 # Fisher-preserving splittings imply log distortion <=eps without exact symmetry.
 asym=[]; asymbound=[]
 for i in range(200):
  n=int(rng.choice([2,3,5,8])); pp=law(rng,n); v=rng.normal(size=n); v-=v.mean()
  E=np.zeros((2*n,n))
  for j in range(n):
   z=float(rng.uniform(.1,.9)); E[2*j,j]=z; E[2*j+1,j]=1-z
  eps=float(rng.choice([.001,.01,.1])); h=lambda p,v:float(np.sum(np.exp(eps*np.linspace(0,1,len(p)))*v*v/p))
  distortion=abs(np.log(h(E@pp,E@v)/h(pp,v))); c=(1+np.exp(eps))/2
  dev=abs(np.log(h(pp,v)/(c*F(pp,v)))); asym.append(distortion-eps); asymbound.append(dev-4*eps)
  record('C04b_approximate_symmetry',case=i,n=n,epsilon=eps,embedding_log_distortion=distortion,normalized_log_deviation=dev)
 check('approximate_embedding_without_exact_symmetry',max(asym)<1e-10,float(max(asym)))
 check('symmetry_free_Cencov_envelope_example',max(asymbound)<1e-10,float(max(asymbound)))
 rng.bit_generator.state=saved_rng_state
 # Exact sufficiency family with nontrivial hidden conditional and rank-1 model.
 R=np.array([[.7,0],[.3,0],[0,.2],[0,.8]]); K=np.array([[1,1,0,0],[0,0,1,1.]])
 suff=[]; dvals=[]
 for t in np.linspace(.05,.95,91):
  pp=R@np.array([t,1-t]); v=R@np.array([1.,-1.]); suff.append(float(np.max(abs(bayes(R@np.array([.4,.6]),K)@(K@pp)-pp))))
  dvals.append(abs(defect(pp,v,K)))
  record('C05_exact_family',theta=t,recovery_error=suff[-1],fisher_defect=dvals[-1])
 check('connected_sufficient_family',max(suff)<1e-12,float(max(suff)))
 check('sufficient_family_Fisher_equality',max(dvals)<1e-10,float(max(dvals)))
 # Sharp exponent: deterministic merge loses the first two components.
 q=np.array([.25,.25,.5]); K=np.array([[1.,1,0],[0,0,1.]])
 ex=[]
 for eps in np.logspace(-6,-1,21):
  pp=q+eps*np.array([1,-1,0]); gap=F(q,pp-q)-F(K@q,K@(pp-q)); tv=TV(pp,bayes(q,K)@(K@pp))
  ex.append((gap,tv)); record('C06_sharp_exponent',epsilon=eps,chi_loss=gap,recovery_TV=tv)
 slope=float(np.polyfit(np.log([v[0] for v in ex]),np.log([v[1] for v in ex]),1)[0])
 check('square_root_exponent_witness',abs(slope-.5)<1e-10,slope); summary['recovery_exponent']=slope
 # Fisher-equal finite experiments, different Hellinger affinities.
 t0,t1=.4,1.4; d=t1-t0
 aff1=np.cos(d/2); aff2=np.cos(d/(2*np.sqrt(2)))**2
 check('same_Fisher_different_experiments',abs(aff1-aff2)>.001,float(abs(aff1-aff2)))
 summary['same_Fisher_affinities']=[float(aff1),float(aff2)]
 # Deficiency/Hellinger-small oscillatory families can have divergent Fisher.
 oscill=[]
 for n in [4,8,16,32,64,128]:
  amp=1/n; f0=4*n*n; oscill.append((n,amp,f0)); record('C07_oscillatory',n=n,uniform_TV_bound=amp,Fisher_at_zero=f0)
 check('deficiency_not_derivative_control',oscill[-1][1]<oscill[0][1] and oscill[-1][2]>oscill[0][2],oscill[-1][2])
 # Spectral projector perturbation bound, with fixed Euclidean comparison metric.
 serr=[]; srat=[]
 for i in range(200):
  n=6; r=3; gamma=.2; tau=1.; Q,_=np.linalg.qr(rng.normal(size=(n,n)))
  vals=np.array([.2,.4,.8,1.2,1.7,2.]); A=(Q*vals)@Q.T
  D=rng.normal(size=(n,n)); D=(D+D.T)/2; D*=.05/np.linalg.norm(D,2); B=A+D
  wa,va=np.linalg.eigh(A); wb,vb=np.linalg.eigh(B); P=va[:,wa>tau]@va[:,wa>tau].T; PP=vb[:,wb>tau]@vb[:,wb>tau].T
  eta=float(np.linalg.norm(D,2)); er=float(np.linalg.norm(P-PP,'fro')); bound=np.sqrt(2*r)*eta/(2*gamma-eta)
  serr.append(er-bound); srat.append(er/bound)
  record('C08_spectral_stability',case=i,error=er,bound=bound,ratio=er/bound)
 check('spectral_projector_bound',max(serr)<1e-10,float(max(serr))); summary['max_spectral_bound_ratio']=float(max(srat))
 # Efficient information contraction under a random contraction of score coordinates.
 ne=[]
 for i in range(100):
  X=rng.normal(size=(7,4)); T=rng.normal(size=(7,7)); T/=max(1,np.linalg.norm(T,2)); A=X.T@X; B=X.T@T.T@T@X
  def efficient(M): return M[:2,:2]-M[:2,2:]@np.linalg.solve(M[2:,2:],M[2:,:2])
  mine=float(np.linalg.eigvalsh(efficient(A)-efficient(B)).min()); ne.append(mine)
  record('C09_nuisance',case=i,efficient_difference_min_eigenvalue=mine)
 check('efficient_information_contracts',min(ne)>-1e-10,float(min(ne)))
 # Derivative perturbation inequality for square-root density Jacobians.
 de=[]
 for i in range(100):
  J=rng.normal(size=(6,3)); E=rng.normal(size=(6,3))*.01; eta=np.linalg.norm(E,2); M=np.linalg.norm(J,2)
  actual=np.linalg.norm(4*((J+E).T@(J+E)-J.T@J),2); bound=4*eta*(2*M+eta); de.append(actual-bound)
  record('C10_derivative_stability',case=i,error=actual,bound=bound)
 check('square_root_derivative_bound',max(de)<1e-10,float(max(de)))
 # Negative examples / mutation canaries, each computed rather than hard-coded success.
 can=[]
 def canary(name,ok,witness): can.append(dict(name=name,detected=bool(ok),witness=witness))
 q=np.array([.25,.25,.5]); v=np.array([1.,-1,0]); K=np.array([[1.,1,0],[0,0,1.]])
 canary('declare_zero_defect_after_destructive_merge',defect(q,v,K)>1,defect(q,v,K))
 Rwrong=np.ones((3,2))/3; Rgood=bayes(q,K)
 canary('replace_reference_Bayes_by_uniform_decoder',np.max(abs(Rwrong@(K@q)-q))>.1,float(np.max(abs(Rwrong@(K@q)-q))))
 # First-order isometry at one point need not give sufficiency.
 def family(t): return np.array([.25+t/4+t*t/8,.25+t/4-t*t/8,.5-t/2])
 def velocity(t): return np.array([.25+t/4,.25-t/4,-.5])
 d0=defect(family(0),velocity(0),K); d1=defect(family(.5),velocity(.5),K)
 canary('pointwise_Fisher_equality_implies_global_sufficiency',abs(d0)<1e-12 and d1>.01,[d0,d1])
 canary('Fisher_tensor_identifies_global_experiment',abs(aff1-aff2)>.001,[float(aff1),float(aff2)])
 canary('small_deficiency_controls_Fisher',oscill[-1][1]<.01 and oscill[-1][2]>1e4,list(oscill[-1]))
 A=np.diag([0.,2.]); u=np.array([1.,1.])/np.sqrt(2); w=np.array([1.,-1.])/np.sqrt(2)
 canary('all_Rayleigh_admissible_subspaces_have_greatest_member',u@A@u<1+1e-12 and w@A@w<1+1e-12 and np.linalg.eigvalsh(A).max()>1,[float(u@A@u),float(w@A@w),2.])
 theta=.4; joint=np.array([1+theta,1-theta,1-theta,1+theta])/4; vj=np.array([1,-1,-1,1])/4
 marginal=np.array([[1,1,0,0],[0,0,1,1.]])
 canary('sum_marginal_information_without_joint_law',F(joint,vj)>1 and F(marginal@joint,marginal@vj)==0,F(joint,vj))
 # normalized f-divergences have same Hessian, distinct finite values.
 pp=np.array([.8,.2]); qq=np.array([.3,.7]); divs=[KL(pp,qq),F(qq,pp-qq)/2,2*np.sum((np.sqrt(pp)-np.sqrt(qq))**2)]
 canary('local_Fisher_selects_unique_finite_divergence',max(divs)-min(divs)>.01,divs)
 canary('finite_recovery_error_is_linear_in_quadratic_defect',ex[0][1]/ex[0][0]>1e4,ex[0][1]/ex[0][0])
 # Parameter-dependent channel can create Fisher from a constant input.
 qconst=np.array([.5,.5]); Khalf=np.array([[.5,.5],[.5,.5]]); Kprime=np.array([[1.,1.],[-1.,-1.]])
 created=F(Khalf@qconst,Kprime@qconst)
 canary('allow_parameter_dependent_garbling',created>1,{'constant_input_Fisher':0.,'output_Bernoulli_Fisher_at_half':created})
 # Remove a positive gap at a threshold: arbitrarily small perturbations flip rank.
 a=np.diag([.5,1-1e-8]); b=np.diag([.5,1+1e-8]); ranks=[int(np.sum(np.linalg.eigvalsh(x)>1)) for x in [a,b]]
 canary('projector_stability_without_spectral_margin',ranks==[0,1],ranks)
 # Singular parameter theta^2 has zero Fisher at zero but different laws off zero.
 theta=.1; singular_tv=theta*theta
 canary('zero_tangent_means_exact_gauge',singular_tv>0,{'Fisher_at_zero':0.,'TV_to_zero_at_point1':singular_tv})
 # Disconnected constant families: zero tangent loss but erasure cannot recover both laws.
 pa=np.array([.2,.8]); pb=np.array([.8,.2]); erase=np.ones((1,2))
 canary('drop_connectedness_in_global_sufficiency',np.max(abs(erase@pa-erase@pb))==0 and TV(pa,pb)>.5,TV(pa,pb))
 # Boundary Fisher diverges while its intrinsic distance to the boundary tends to zero.
 eps=1e-8; boundaryF=1/(eps*(1-eps)); boundaryd=2*np.arcsin(np.sqrt(eps))
 canary('divergent_coordinate_Fisher_means_infinite_distance',boundaryF>1e7 and boundaryd<.001,[boundaryF,boundaryd])
 # Quantum commuting agreement does not select a noncommuting metric.
 sld=4.; bkm=2*np.log(.8/.2)/(.8-.2)
 canary('classical_uniqueness_selects_quantum_metric',bkm>sld+.1,[sld,float(bkm)])
 check('mutation_canaries',all(v['detected'] for v in can),sum(v['detected'] for v in can))
 summary.update({'random_max_errors':{k:float(max(v)) for k,v in errs.items()},'max_integral_error':float(max(integ)),'max_path_violation':float(max(path_errors)),'canaries':can,'finite_divergence_values':divs,'pointwise_equality_defects':[d0,d1]})
 # Plot computed quantities only, default Matplotlib style.
 fig,ax=plt.subplots(2,2,figsize=(11,8))
 ax[0,0].loglog([v[0] for v in ex],[v[1] for v in ex],'o-'); ax[0,0].set(xlabel='Chi-square information loss',ylabel='Recovery total variation',title='Sharp square-root scaling')
 ax[0,1].loglog([v[1] for v in oscill],[v[2] for v in oscill],'o-'); ax[0,1].set(xlabel='Uniform total-variation bound',ylabel='Fisher information at zero',title='Small deficiency, large derivative')
 ax[1,0].plot(sorted(ratios)); ax[1,0].set(xlabel='Sorted path case',ylabel='Actual TV / proved bound',title='Pathwise recovery certificate')
 ax[1,1].plot(sorted(srat)); ax[1,1].set(xlabel='Sorted perturbation case',ylabel='Projector error / proved bound',title='Spectral-margin stability')
 fig.tight_layout(pad=1.5); fig.savefig(out/'rg_cencov_overview.png',dpi=160); plt.close(fig)
 keys=['family']+sorted(set().union(*(r.keys() for r in rows))-{'family'})
 with (out/'rg_cencov_runs.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=keys); w.writeheader(); w.writerows(rows)
 specbytes=(json.dumps(SPEC,sort_keys=True,indent=2)+'\n').encode(); (out/'rg_cencov_spec.json').write_bytes(specbytes)
 result={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'spec_sha256':hashlib.sha256(specbytes).hexdigest(),'environment':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__},'rows':len(rows),'checks':checks,'passed':sum(v['passed'] for v in checks),'total_checks':len(checks),'summary':summary}
 (out/'rg_cencov_results.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
 print(json.dumps(result,indent=2)); assert result['passed']==result['total_checks']
if __name__=='__main__':
 ap=argparse.ArgumentParser(); ap.add_argument('--out',default='.'); main(ap.parse_args().out)
