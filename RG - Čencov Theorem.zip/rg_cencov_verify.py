"""Artifact consistency and optional fresh-process reproduction. Not proof verification."""
import argparse,csv,hashlib,json,shutil,subprocess,sys,tempfile
from pathlib import Path
P=Path(__file__).resolve().parent
ap=argparse.ArgumentParser(); ap.add_argument('--rerun',action='store_true'); args=ap.parse_args()
reports=[]
def chk(name,ok):
 reports.append(dict(name=name,passed=bool(ok)))
 if not ok: raise AssertionError(name)
def read(name): return json.loads((P/name).read_text())
files=[('rg_cencov_battery.py','rg_cencov_results.json',28),('rg_cencov_exact.py','rg_cencov_exact_results.json',8),('rg_cencov_quantum.py','rg_cencov_quantum_results.json',3)]
for source,result,count in files:
 d=read(result); chk(source+' hash',hashlib.sha256((P/source).read_bytes()).hexdigest()==d['source_sha256'])
 chk(result+' assertions',d['passed']==d['total_checks']==count and all(v['passed'] for v in d['checks']))
d=read('rg_cencov_results.json'); rows=list(csv.DictReader((P/'rg_cencov_runs.csv').open()))
chk('classical row count',len(rows)==d['rows']==1918)
chk('spec hash',hashlib.sha256((P/'rg_cencov_spec.json').read_bytes()).hexdigest()==d['spec_sha256'])
chk('mutation canaries',len(d['summary']['canaries'])==15 and all(v['detected'] for v in d['summary']['canaries']))
get=lambda family:[v for v in rows if v['family']==family]
pathmax=max(float(v['ratio']) for v in get('C03_path_recovery'))
specmax=max(float(v['ratio']) for v in get('C08_spectral_stability'))
intmax=max(abs(float(v['integral'])-float(v['KL_loss'])) for v in get('C02_integrated_loss'))
varmax=max(float(v['variance_relative_error']) for v in get('C01_random_channels'))
chk('independent CSV path maximum',pathmax==d['summary']['max_path_bound_ratio'])
chk('independent CSV spectral maximum',specmax==d['summary']['max_spectral_bound_ratio'])
chk('independent CSV integral maximum',intmax==d['summary']['max_integral_error'])
chk('independent CSV variance maximum',varmax==d['summary']['random_max_errors']['variance'])
chk('all path certificates',all(float(v['recovery_TV'])<=float(v['bound'])+1e-10 for v in get('C03_path_recovery')))
chk('all spectral certificates',all(float(v['error'])<=float(v['bound'])+1e-10 for v in get('C08_spectral_stability')))
qrows=list(csv.DictReader((P/'rg_cencov_quantum_runs.csv').open())); q=read('rg_cencov_quantum_results.json')
chk('quantum row count',len(qrows)==q['cases']==60)
chk('quantum residual maximum',max(float(v['error']) for v in qrows)==q['checks'][0]['value'])
e=read('rg_cencov_exact_results.json'); chk('exact partition count',e['exact_cases']==222 and sum(e['partition_counts'].values())==74)
if args.rerun:
 with tempfile.TemporaryDirectory(prefix='rg_cencov_reproduction_') as tmp:
  root=Path(tmp)
  for source,result,count in files:
   shutil.copy2(P/source,root/source)
   cmd=[sys.executable,str(root/source)]
   if source=='rg_cencov_battery.py': cmd+=['--out',str(root)]
   r=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
   chk(source+' fresh process exit',r.returncode==0)
   fresh=json.loads((root/result).read_text()); chk(result+' exact fresh JSON agreement',fresh==read(result))
  for name in ['rg_cencov_runs.csv','rg_cencov_quantum_runs.csv','rg_cencov_spec.json']:
   chk(name+' fresh byte agreement',(root/name).read_bytes()==(P/name).read_bytes())
result=dict(checks=reports,passed=sum(v['passed'] for v in reports),total=len(reports),fresh_rerun=args.rerun,scope='Artifact consistency and same-environment reproducibility, not independent proof or novelty verification.')
(P/'rg_cencov_verification.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n'); print(json.dumps(result,indent=2))
