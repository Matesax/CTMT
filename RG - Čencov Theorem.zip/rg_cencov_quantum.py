"""Quantum BKM mixture identity and nonuniqueness checks; synthetic matrices only."""
from pathlib import Path
import hashlib,json,csv
import numpy as np
from scipy.integrate import quad
P=Path(__file__).resolve().parent
rng=np.random.default_rng(707)
def state(d):
 A=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d)); X=A@A.conj().T+.3*np.eye(d); return X/np.trace(X)
def logm(X):
 w,v=np.linalg.eigh(X); return (v*np.log(w))@v.conj().T
def D(r,s): return float(np.trace(r@(logm(r)-logm(s))).real)
def bkm(r,A):
 w,v=np.linalg.eigh(r); B=v.conj().T@A@v; C=np.empty((len(w),len(w)))
 for i,x in enumerate(w):
  for j,y in enumerate(w): C[i,j]=1/x if abs(x-y)<1e-12 else (np.log(x)-np.log(y))/(x-y)
 return float(np.sum(abs(B)**2*C))
rows=[]
for d in [2,3,4]:
 for trial in range(20):
  r=state(d); s=state(d); A=r-s; eta=float(rng.uniform(.1,.9)); Phi=lambda X:(1-eta)*X+eta*np.eye(d)*np.trace(X)/d
  gap=D(r,s)-D(Phi(r),Phi(s))
  integral=quad(lambda t:(1-t)*(bkm(s+t*A,A)-bkm(Phi(s+t*A),Phi(A))),0,1,epsabs=1e-10,epsrel=1e-10)[0]
  rows.append(dict(d=d,trial=trial,depolarizing_weight=eta,relative_entropy_loss=gap,integrated_BKM_loss=integral,error=abs(gap-integral)))
checks=[dict(name='Q01 integrated_BKM_loss',passed=max(v['error'] for v in rows)<1e-9,value=max(v['error'] for v in rows)),dict(name='Q02 nonnegative_relative_entropy_loss',passed=min(v['relative_entropy_loss'] for v in rows)>-1e-10,value=min(v['relative_entropy_loss'] for v in rows))]
r=np.diag([.8,.2]); A=np.array([[0,1],[1,0.]])
checks.append(dict(name='Q03 noncommuting_metric_separation',passed=bkm(r,A)>4.1,value={'SLD':4.,'BKM':bkm(r,A)}))
res=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),seed=707,cases=len(rows),checks=checks,passed=sum(v['passed'] for v in checks),total_checks=len(checks),scope='BKM entropy Hessian identity only; no universal quantum recovery theorem proved by these runs.')
(P/'rg_cencov_quantum_results.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n')
with (P/'rg_cencov_quantum_runs.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
print(json.dumps(res,indent=2)); assert res['passed']==len(checks)
