"""Exact rational and symbolic checks, not a machine-checked universal proof."""
from pathlib import Path
from fractions import Fraction as Q
import hashlib,json
import sympy as s
P=Path(__file__).resolve().parent
checks=[]
def check(name,ok,value): checks.append(dict(name=name,passed=bool(ok),value=value))
def partitions(n):
 def go(a):
  if len(a)==n: yield a; return
  for x in range(max(a)+2): yield from go(a+[x])
 yield from go([0])
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def fisher(p,v): return sum(x*x/y for x,y in zip(v,p))
cases=0; errors=[]; recovery=[]; positivity=[]; counts={}
for n in range(2,6):
 parts=list(partitions(n)); counts[n]=len(parts)
 q=[Q(i+1,n*(n+1)//2) for i in range(n)]
 for part in parts:
  m=max(part)+1; y=[sum(q[x] for x in range(n) if part[x]==j) for j in range(m)]
  for p in [list(reversed(q)),[Q(1,n)]*n,q[1:]+q[:1]]:
   v=[p[i]-q[i] for i in range(n)]; w=[sum(v[x] for x in range(n) if part[x]==j) for j in range(m)]
   delta=fisher(q,v)-fisher(y,w)
   score=[v[x]/q[x] for x in range(n)]; sy=[w[j]/y[j] for j in range(m)]
   var=sum(q[x]*(score[x]-sy[part[x]])**2 for x in range(n))
   py=[sum(p[x] for x in range(n) if part[x]==j) for j in range(m)]
   rec=[q[x]*py[part[x]]/y[part[x]] for x in range(n)]
   er=fisher(q,[p[x]-rec[x] for x in range(n)])
   errors.append(delta-var); recovery.append(er-delta); positivity.append(delta>=0); cases+=1
check('E01 all_partition_variance_identity',all(v==0 for v in errors),cases)
check('E02 deterministic_projection_recovery_identity',all(v==0 for v in recovery),cases)
check('E03 exact_nonnegative_defect',all(positivity),cases)
x=s.symbols('x',positive=True)
fs=[x*s.log(x)-x+1,(x-1)**2/2,2*(s.sqrt(x)-1)**2]
vals=[s.simplify(s.diff(f,x,2).subs(x,1)) for f in fs]
check('E04 common_f_divergence_Hessian',all(v==1 for v in vals),[str(v) for v in vals])
t=s.symbols('t',real=True); prob=s.Rational(1,2)+t*t
fi=s.simplify(s.diff(prob,t)**2/(prob*(1-prob)))
check('E05 singular_Fisher_formula',s.simplify(fi-16*t*t/(1-4*t**4))==0,str(fi))
a,b,u=s.symbols('a b u',positive=True)
z=a+u*b
H=z*s.log(z)
check('E06 mixture_entropy_Hessian',s.simplify(s.diff(H,u,2)-b*b/z)==0,str(s.diff(H,u,2)))
ident=[]
for n in range(2,7):
 k=s.symbols('k0:'+str(n),positive=True); v=s.symbols('v0:'+str(n)); N=sum(k)
 left=2*N*sum(v[i]**2/(2*k[i]) for i in range(n)); right=sum(v[i]**2/(k[i]/N) for i in range(n))
 ident.append(s.simplify(left-right)==0)
check('E07 rational_splitting_coefficients',all(ident),len(ident))
q=s.Matrix([s.Rational(1,5),s.Rational(3,10),s.Rational(1,2)])
K=s.Matrix([[s.Rational(1,4),s.Rational(1,2),s.Rational(3,4)],[s.Rational(3,4),s.Rational(1,2),s.Rational(1,4)]])
L=s.Matrix([[s.Rational(2,3),s.Rational(1,3)],[s.Rational(1,3),s.Rational(2,3)]])
def bayes(q,K): return s.diag(*q)*K.T*s.diag(*[1/x for x in K*q])
err=bayes(q,L*K)-bayes(q,K)*bayes(K*q,L)
check('E08 exact_reference_Bayes_composition',err==s.zeros(3,2),str(err))
res=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),sympy=s.__version__,partition_counts=counts,exact_cases=cases,checks=checks,passed=sum(v['passed'] for v in checks),total_checks=len(checks),scope='Exact finite examples and symbolic identities; universal proofs are in the paper.')
(P/'rg_cencov_exact_results.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n'); print(json.dumps(res,indent=2)); assert res['passed']==len(checks)
