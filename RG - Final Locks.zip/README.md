# RG - Final Locks: battery FL01-FL08 (print edition of Resolution Geometry)

    python3 rg_final_locks_attack.py            # seed 20261020
    python3 rg_final_locks_attack.py --canary   # BV overclaim 2^-(n+3) must fail

8/8 on seeds 20261020, 1, 42, 777, 2026; canary caught.
FL01 sharp BV mixing lock (exact rationals) | FL02 contextual protocols: Fine's theorem by LP | FL03 non-dominated stratum |
FL04 Feldman-Hajek / Cameron-Martin | FL05 Brudno-Pesin information cost of chaos | FL06 exponential selector antichain (Shamir) |
FL07 non-stationary slices (FLRW) | FL08 class-based non-circularity.
