"""Mature joint-law blind selector and bottom-up climb, finite reference implementation.
No early placement algorithm. No generated or reconstructed empirical rows.
Exact rational tables below are mathematical countermodels, not simulated detector data.
Run: python rg_observable_climb.py --out-dir .
"""
from pathlib import Path
from fractions import Fraction as Q
import argparse, itertools, json, hashlib, platform
import numpy as np

JOINT_REPORTED=[1.,.645627123647268,.05848059659343348,.02407118928850125,.01977712097008573,.015717547967564343,.013292056480487214,.009822857076608186,.007814992531765234,.004674982501336529,.004252422672637674,.0038667086193082713,.0033694035170657617,.0012576518758553462,.0011961094907674498,.0007028035941871089,.0001167857211017301,.00010214518991475165]
ECG_REPORTED=[1.,.4560,.1072,.03573,.02280,.007261,.003810,.0008264,.00003251]

def kernel(rows):
    return np.array([[a==b for b in rows] for a in rows],dtype=bool)

def closure(n,edges):
    parent=list(range(n))
    def root(i):
        while parent[i]!=i:
            parent[i]=parent[parent[i]];i=parent[i]
        return i
    for a,b in edges:parent[root(a)]=root(b)
    return np.array([[root(i)==root(j) for j in range(n)] for i in range(n)],dtype=bool)

def blocks(k):
    todo=set(range(len(k)));out=[]
    while todo:
        i=min(todo);b=[j for j in sorted(todo) if k[i,j]];out.append(b);todo.difference_update(b)
    return out

def partitions(n):
    def rec(a):
        if len(a)==n:yield tuple(a);return
        for v in range(max(a)+2):yield from rec(a+[v])
    yield from rec([0])

def descends(k,target):
    return all(not k[i,j] or target[i]==target[j] for i in range(len(k)) for j in range(len(k)))

def robust_kernel(kernels,mutation=False):
    if mutation:return np.logical_and.reduce(kernels)
    union=np.logical_or.reduce(kernels)
    return closure(len(union),[(i,j) for i in range(len(union)) for j in range(i) if union[i,j]])

def common_decoder_kernel(models):
    """Common codomain, unknown model: include cross-model law collisions."""
    n=len(models[0]);edges=[]
    for i in range(n):
        for j in range(i):
            if any(m[i]==v[j] for m in models for v in models):edges.append((i,j))
    return closure(n,edges)

def bottom_up(rows,edges=()):
    """Exact law oracle; no numerical near-equality. Adds only certified kernel arrows."""
    k=kernel(rows);n=len(k)
    if any(not k[i,j] for i,j in edges):
        return {'status':'INCONSISTENT','reason':'declared generator changes the law'}
    edges=list(edges);a=closure(n,edges);trace=[len(blocks(a))]
    for i in range(n):
        for j in range(i):
            if k[i,j] and not a[i,j]:
                edges.append((i,j));a=closure(n,edges);trace.append(len(blocks(a)))
    complete=np.array_equal(a,k)
    return {'status':'LOCKED' if complete else 'CORRESPONDENCE',
            'scope':'exact finite declared law only','sound':bool(np.all(~a|k)),
            'complete':bool(complete),'orbits':blocks(a),'trace_orbit_counts':trace,
            'arrows_added':len(edges)}

def joint_rows(protocols,chosen):
    n=len(next(iter(protocols.values())))
    return [tuple(protocols[name][i] for name in chosen) for i in range(n)]

def minimal_protocols(protocols,target,mutation=False):
    """Returns the whole inclusion-minimal antichain, never an arbitrary tied winner."""
    names=list(protocols);sufficient=[]
    for size in range(len(names)+1):
        for ss in itertools.combinations(names,size):
            rows=joint_rows(protocols,ss)
            if descends(kernel(rows),target):sufficient.append(frozenset(ss))
    mins=[s for s in sufficient if not any(t<s for t in sufficient)]
    if mutation and mins:mins=mins[:1]
    return [sorted(s) for s in mins]

def finite_model():
    states=list(itertools.product(range(2),repeat=3));H=[];L=[];C=[]
    for a,b,h in states:
        pa=Q(1+2*a,4);pb=Q(1+2*b,4);c=Q(1 if h else -1,32)
        H.append((1-pa,pa));L.append((1-pb,pb))
        row=((1-pa)*(1-pb)+c,(1-pa)*pb-c,pa*(1-pb)-c,pa*pb+c)
        assert sum(row)==1 and min(row)>0
        C.append(row)
    return states,{'H':H,'L':L,'C':C}

def spectral_intervals(e,eps,delta,mutation=False):
    e=np.array(e,float)
    if not (len(e)>0 and np.isfinite(e).all() and np.all(e>=0) and np.all(np.diff(e)<=0) and eps>0 and e[0]>delta>=0):
        return {'status':'OUTSIDE_DOMAIN'}
    if mutation:
        r=int(sum(e>eps*e[0]));return {'status':'LOCKED','rank_lower':r,'rank_upper':r}
    lo=int(sum(e-delta>eps*(e[0]+delta)))
    hi=int(sum(e+delta>eps*(e[0]-delta)))
    return {'status':'LOCKED' if lo==hi else 'STRUCTURAL_WALL','rank_lower':lo,'rank_upper':hi}

def energy_dim(e,eta):
    return int(np.searchsorted(np.cumsum(e)/sum(e),eta)+1)

def climb(certificates):
    # This is a DAG, not a rule that a successful sibling unlocks all later rungs.
    specs=[('law_domain',[]),('kernel',['law_domain']),('assembly_sound',['kernel']),
           ('assembly_complete',['assembly_sound']),('task_descent',['kernel']),
           ('regularity',['kernel']),('fisher',['regularity']),
           ('observable_connection',['fisher']),('latent_lift',['regularity','latent_covariance']),
           ('physical_scale',['fisher','anchor'])]
    out={}
    for name,deps in specs:
        failed=[d for d in deps if out.get(d,{}).get('status',certificates.get(d))!='LOCKED']
        own=certificates.get(name,'MISSING')
        out[name]={'status':'LOCKED' if not failed and own=='LOCKED' else ('INCONSISTENT' if own=='FAIL' else 'OUTSIDE_DOMAIN'),
                   'blocked_by':failed,'certificate':own}
    return out

def run_tests():
    tests=[]
    def add(name,ok,mut,details):
        tests.append({'name':name,'passed':bool(ok),'mutation_caught':bool(mut),'details':details})
    ps=list(partitions(4));targets=list(itertools.product(range(2),repeat=4))
    # Exhaustive quotient algebra identity over every pair of partitions and binary task.
    total=0;good=True;mutation_witness=None
    for p in ps:
        for q in ps:
            kp,kq=kernel(p),kernel(q);kr=robust_kernel([kp,kq]);bad=robust_kernel([kp,kq],True)
            for t in targets:
                oracle=descends(kp,t) and descends(kq,t)
                good &= descends(kr,t)==oracle;total+=1
                if mutation_witness is None and descends(bad,t)!=oracle:
                    mutation_witness={'p':p,'q':q,'task':t}
    add('T01 robust observable quotient',good,mutation_witness is not None,{'cases':total,'intersection_mutation_witness':mutation_witness})
    # Exhaustively verify bottom-up soundness/completeness for every edge subset.
    edges=list(itertools.combinations(range(4),2));cases=0;good=True;bad_witness=False
    for p in ps:
        k=kernel(p)
        for mask in range(64):
            es=[e for j,e in enumerate(edges) if mask&(1<<j)]
            a=closure(4,es);sound=all(k[i,j] for i,j in es)
            res=bottom_up(p,es)
            good &= (res['status']=='LOCKED')==sound
            if sound:good &= res['orbits']==blocks(k)
            else:bad_witness=True
            cases+=1
    add('T02 bottom-up exact assembly',good,bad_witness,{'cases':cases,'mutation':'accept a generator joining unequal law rows'})
    # Soundness alone is insufficient: identity groupoid, constant law.
    k=kernel([0,0,0,0]);identity=np.eye(4,dtype=bool)
    add('T03 completeness is separate',np.all(~identity|k) and not np.array_equal(identity,k),
        len(blocks(identity))!=len(blocks(k)),{'known_orbits':4,'law_fibres':1,'mutation':'promote soundness to completeness'})
    states,pro=finite_model();km=kernel(joint_rows(pro,['H','L']));kc=kernel(pro['C'])
    add('T04 coupled law refinement',np.all(~kc|km) and not np.array_equal(km,kc),
        not np.array_equal(km,kc),{'marginal_fibres':len(blocks(km)),'coupled_fibres':len(blocks(kc)),'mutation':'replace full coupling by marginal tuple'})
    # Permute states and outcomes; quotient pair relation must transform, not change.
    rng=np.random.default_rng(20261016);maxerr=0;cases=0
    for _ in range(100):
        ix=rng.permutation(8);oy=rng.permutation(4)
        rows=[tuple(pro['C'][i][j] for j in oy) for i in ix]
        maxerr=max(maxerr,int(np.any(kernel(rows)!=kc[np.ix_(ix,ix)])));cases+=1
    # Noninjective outcome merge deliberately changes the kernel.
    merged=[(sum(r),) for r in pro['C']]
    add('T05 label-blind quotient equivariance',maxerr==0,not np.array_equal(kernel(merged),kc),{'permutations':cases,'mutation':'treat a nonbijective outcome merge as a relabeling'})
    # Explicit tied protocols with same law.
    tied={'P':pro['H'],'Q':pro['H']};target=[s[0] for s in states]
    ans=minimal_protocols(tied,target);bad=minimal_protocols(tied,target,True)
    add('T06 blind selector retains ties',len(ans)==2,len(bad)!=len(ans),{'minimal_protocol_antichain':ans})
    # Task-dependent minimality; exact source task labels are declared, not observed clinical labels.
    ta=[s[0] for s in states];tb=[s[1] for s in states];th=[s[2] for s in states]
    a=minimal_protocols(pro,ta);b=minimal_protocols(pro,tb);h=minimal_protocols(pro,th)
    add('T07 no task-free protocol winner',a!=b and h==[['C']],a!=b,{'task_a':a,'task_b':b,'task_h':h,'mutation':'reuse a winner across different tasks'})
    # Known h-flip sound for marginals but unsound for coupled law.
    flips=[(i,i^1) for i in range(8)]
    a=bottom_up(joint_rows(pro,['H','L']),flips);b=bottom_up(pro['C'],flips)
    add('T08 protocol-relative gauge',a['status']=='LOCKED' and b['status']=='INCONSISTENT',
        a['status']!=b['status'],{'marginal_assembly':a,'coupled_assembly':b})
    # Exact data processing on every deterministic garbling of 4 outcomes to 2.
    good=True;strict=0
    for g in itertools.product(range(2),repeat=4):
        rr=[tuple(sum(r[j] for j in range(4) if g[j]==v) for v in range(2)) for r in pro['C']]
        kg=kernel(rr);good &= bool(np.all(~kc|kg));strict+=not np.array_equal(kc,kg)
    add('T09 garbling order',good,strict>0,{'garblings':16,'strict_kernel_enlargements':strict,'mutation':'reverse kernel inclusion'})
    # Isospectral covariance counterexample: same eigenvalues, different leading projector.
    theta=np.pi/4;U=np.array([[np.cos(theta),-np.sin(theta)],[np.sin(theta),np.cos(theta)]])
    D=np.diag([2.,1.]);E=U@D@U.T
    P=np.diag([1.,0.]);P2=U@P@U.T;dist=float(np.linalg.norm(P-P2,2))
    add('T10 spectra do not identify a sector',np.allclose(np.linalg.eigvalsh(D),np.linalg.eigvalsh(E)) and dist>.7,
        dist>.7,{'projector_distance':dist,'mutation':'report a common projector from eigenvalues alone'})
    # Weyl rank interval: actual rotated perturbations within a declared deterministic bound.
    e=np.array([1.,.2,.0101,.001]);eps=.01;delta=.0002
    interval=spectral_intervals(e,eps,delta);good=True;ranks=[]
    for v in np.linspace(-delta,delta,101):
        ev=e.copy();ev[2]+=v;r=int(sum(ev>eps*ev[0]));ranks.append(r)
        good &= interval['rank_lower']<=r<=interval['rank_upper']
    mutant=spectral_intervals(e,eps,delta,True)
    add('T11 certified-bound spectral interval',good and interval['status']=='STRUCTURAL_WALL',
        any(not mutant['rank_lower']<=r<=mutant['rank_upper'] for r in ranks),{'interval':interval,'realized_ranks':sorted(set(ranks))})
    # A blind spectral selector cannot choose a proper subspace inside a tied eigenspace.
    C=np.eye(2);v=np.array([1.,0.]);rot=U@v
    add('T12 isotropy obstruction',np.allclose(U@C@U.T,C) and not np.allclose(v[:,None]@v[None,:],rot[:,None]@rot[None,:]),
        not np.allclose(v[:,None]@v[None,:],rot[:,None]@rot[None,:]),{'mutation':'choose the first coordinate in an isotropic eigenspace'})
    # Positive/negative threshold relation need not be transitive.
    d=np.array([0.,.75,1.5]);near=np.abs(d[:,None]-d[None,:])<=1
    closed=closure(3,[(0,1),(1,2)])
    add('T13 no tolerance groupoid',near[0,1] and near[1,2] and not near[0,2],not np.array_equal(near,closed),{'mutation':'transitive-close approximate equality without error growth'})
    # Dependency propagation must not promote exact kernel to metric/transport.
    cert={'law_domain':'LOCKED','kernel':'LOCKED','assembly_sound':'LOCKED','assembly_complete':'LOCKED','task_descent':'LOCKED'}
    ledger=climb(cert)
    add('T14 ladder dependency discipline',ledger['kernel']['status']=='LOCKED' and ledger['fisher']['status']!='LOCKED',
        ledger['fisher']['status']!='LOCKED',{'ledger':ledger,'mutation':'lock every descendant after a kernel pass'})
    # Exact sample/model distinction: finite sample cannot exclude any positive Bernoulli law.
    p1,p2=Q(1,4),Q(3,4);n=10
    add('T15 sample cannot be an exact law oracle',(1-p1)**n>0 and (1-p2)**n>0,
        p1!=p2,{'all_zero_sample_probability_law1':str((1-p1)**n),'all_zero_sample_probability_law2':str((1-p2)**n),'mutation':'identify exact Bernoulli law from one finite all-zero record'})
    # Nonlinear feature variance does not imply extra source tangent dimension.
    x=np.array([-2.,-1.,0.,1.,2.]);z=np.column_stack([x,x*x]);rank=int(np.linalg.matrix_rank(np.cov(z,rowvar=False)))
    add('T16 covariance rank is not tangent rank',rank==2,rank!=1,{'exact_feature_map':'t -> (t,t^2)','feature_covariance_rank':rank,'regular_tangent_rank':1,'mutation':'call covariance rank source dimension'})
    # Common blind decoder is stronger than separate factorization for each model.
    cases=0;good=True
    maps=list(itertools.product(range(3),repeat=3))
    for f in maps:
        for g in maps:
            kr=common_decoder_kernel([f,g])
            for t in itertools.product(range(2),repeat=3):
                exists=any(all(d[f[i]]==t[i] and d[g[i]]==t[i] for i in range(3))
                           for d in itertools.product(range(2),repeat=3))
                good &= descends(kr,t)==exists;cases+=1
    f=(0,1);g=(1,0);t=(0,1)
    weak=robust_kernel([kernel(f),kernel(g)])
    strong=common_decoder_kernel([f,g])
    add('T17 model-blind common decoder',good,descends(weak,t) and not descends(strong,t),
        {'exhaustive_cases':cases,'counterexample':{'model1':f,'model2':g,'target':t},
         'mutation':'use same-model kernel join when one common decoder is required'})
    # Every sufficient panel contains an inclusion-minimal sufficient panel.
    names=list(pro);good=True;cases=0
    for target in [ta,tb,th,[s[:2] for s in states],states]:
        mins=[set(v) for v in minimal_protocols(pro,target)]
        for size in range(4):
            for ss in itertools.combinations(names,size):
                sufficient=descends(kernel(joint_rows(pro,ss)),target)
                good &= sufficient==any(m<=set(ss) for m in mins);cases+=1
    add('T18 minimal antichain completeness',good,len(ans)>len(bad),{'panel_task_cases':cases})
    # Euclidean covariance sectors change under a general invertible feature chart.
    C=np.diag([100.,1.]);A=np.diag([.1,1.]);white=A@C@A.T
    add('T19 covariance-sector metric declaration',energy_dim([100.,1.],.95)==1 and np.allclose(white,np.eye(2)),
        energy_dim([100.,1.],.95)!=energy_dim([1.,1.],.95),
        {'raw_95_dimension':1,'whitened_95_dimension':2,
         'mutation':'call a Euclidean covariance-energy selector invariant under all invertible feature charts'})
    return tests

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out-dir',default='.');args=ap.parse_args();out=Path(args.out_dir);out.mkdir(parents=True,exist_ok=True)
    states,pro=finite_model()
    tasks={'a':[s[0] for s in states],'b':[s[1] for s in states],'h':[s[2] for s in states],
           'ab':[s[:2] for s in states],'abh':states}
    selection={t:minimal_protocols(pro,v) for t,v in tasks.items()}
    traces={}
    for names in [('H',),('H','L'),('C',)]:
        traces['+'.join(names)]=bottom_up(joint_rows(pro,names))
    # New summary arithmetic only; no row-level experiment is implied.
    summaries={}
    for name,e in [('H1_L1_paired_reported',JOINT_REPORTED),('ECG_reported',ECG_REPORTED)]:
        summaries[name]={'provenance':'reported spectrum; not recomputed from rows in this run',
            'relative_eigenvalues':e,'threshold_ranks':{str(t):int(sum(np.array(e)>t)) for t in [.01,.001,.0001]},
            'variance_dimensions':{str(t):energy_dim(e,t) for t in [.95,.99,.999]},
            'deterministic_sensitivity_NOT_confidence':{str(d):spectral_intervals(e,.001,d) for d in [0.,1e-5,1e-4,1e-3,.01,.05]},
            'projector_status':'CORRESPONDENCE: eigenvectors unavailable',
            'statistical_rank_certificate':'MISSING: no operator-error bound or row-level data'}
    tests=run_tests()
    available={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('/mnt/data').glob('*.pdf') if p.name in ['Resolution Geometry.pdf','RG - The Groupoid of Resolution.pdf','RG_Source_Automation 2.pdf','RG - GR Placement Bridge - Gauge-Aware Wobs ECG.pdf']}
    results={'schema':'mature-observable-climb-v1','environment':{'python':platform.python_version(),'numpy':np.__version__},
        'data_availability':{'H1_L1_rows':'NOT_RECOVERED','ECG_rows':'NOT_RECOVERED','HDF5_binaries':'NOT_AVAILABLE_THIS_RUN',
                             'new_empirical_row_level_runs':0,'reported_spectra_reanalysed':2,
                             'early_placement_methodology_used':False,'source_pdf_sha256':available},
        'finite_model':{'scope':'exact rational mathematical countermodel; NOT detector or ECG data',
                        'states':states,'protocols':{k:[[str(x) for x in row] for row in v] for k,v in pro.items()},
                        'minimal_task_protocols':selection,'bottom_up_traces':traces,
                        'ladder':climb({'law_domain':'LOCKED','kernel':'LOCKED','assembly_sound':'LOCKED','assembly_complete':'LOCKED','task_descent':'LOCKED'}),
                        'unknown_model_example':{'models':[[0,1],[1,0]],'separate_observability_quotient':blocks(robust_kernel([kernel([0,1]),kernel([1,0])])),
                         'common_blind_decoder_quotient':blocks(common_decoder_kernel([[0,1],[1,0]]))}},
        'summary_arithmetic':summaries,'tests':tests,
        'all_checks_pass':all(t['passed'] and t['mutation_caught'] for t in tests),
        'empirical_ladder':{'reported_spectrum_arithmetic':'LOCKED (scope: supplied numbers only)',
            'empirical_blind_selector':'OUTSIDE_DOMAIN (row tables unavailable)',
            'source_joint_law_kernel':'OUTSIDE_DOMAIN (source law unspecified)',
            'regularity_Fisher':'OUTSIDE_DOMAIN (no law derivative or likelihood)',
            'observable_projector':'CORRESPONDENCE (spectra alone insufficient)',
            'observable_connection':'OUTSIDE_DOMAIN (no regular metric field)',
            'latent_lift':'OUTSIDE_DOMAIN (no declared latent covariance)',
            'physical_scale':'OUTSIDE_DOMAIN (no anchor)'},
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (out/'rg_observable_climb_results.json').write_text(json.dumps(results,indent=2))
    print(json.dumps({'all_checks_pass':results['all_checks_pass'],'test_count':len(tests),'selection':selection,'traces':traces,'summaries':summaries},indent=2))
    assert results['all_checks_pass']
if __name__=='__main__':main()
