THE OBSERVABLE SECTOR FROM JOINT LAWS
Blind Selection, Bottom-Up Assembly, and a Certificate-Driven Ladder

SCOPE FIRST
This is a new finite reference implementation of the mature joint-law contract.
It is NOT a recovered historical selector and NOT an empirical H1/L1/ECG rerun.
The row-level feature tables and original HDF5 binaries were not recovered in
this execution. No empirical rows were reconstructed from summary spectra.
The early placement methodology is not used. The ECG attachment supplies only
its printed spectrum as a numerical input, not its placement/transport claims.

EXECUTED
19 theorem/counterexample/control-flow modules pass their stated checks and
sensitivity conditions. Not all sensitivity checks are code-level mutations.
Exact finite rational models are mathematical fixtures, not simulated sensor data.
3600 robust-algebra cases, 960 assembly cases, 5832 common-decoder cases.
Full minimal sufficient-panel antichains and bottom-up traces are in the JSON.
A missing regular law, metric field, covariance or anchor blocks the relevant rung.

NEW SUMMARY ARITHMETIC ONLY
Paired H1/L1 ranks at 1e-2,1e-3,1e-4: 7,15,18.
ECG ranks at 1e-2,1e-3,1e-4: 5,7,8.
95%,99%,99.9% variance dimensions: H1/L1 4,10,15; ECG 3,5,7.
These use different feature metric conventions and are not source dimensions.
No eigenvectors, projector orientations, empirical confidence or transport inferred.
Operator-error sweeps are deterministic sensitivity, not statistical confidence.

REPRODUCE
python rg_observable_climb.py --out-dir .
python rg_observable_plot.py
pdflatex RG_Observable_Sector.tex
pdflatex RG_Observable_Sector.tex

Dependencies: Python, NumPy; Matplotlib for the plot; LaTeX for the paper.
Versions, PDF input hashes, script hash and data-availability ledger are in JSON.
The PDF has 10 pages. The archive does not duplicate source PDFs or raw records.

KEY MATHEMATICAL DISTINCTION
Adding protocols intersects kernels. Requiring separate task observability under
all models takes the equivalence closure of their union. A single unknown-model
blind decoder needs the stronger cross-model collision closure. Separate decoders
for each model do not imply a common blind decoder.
