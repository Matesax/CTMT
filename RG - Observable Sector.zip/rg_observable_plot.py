"""Replot reported summaries only; does not reconstruct empirical observations."""
import json
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
r=json.loads(Path('rg_observable_climb_results.json').read_text())
fig,axes=plt.subplots(1,2,figsize=(10,4))
for name,v in r['summary_arithmetic'].items():
    e=np.array(v['relative_eigenvalues'])
    label='Paired H1/L1 (reported)' if name.startswith('H1') else 'ECG (reported)'
    axes[0].semilogy(np.arange(1,len(e)+1),e,'o-',label=label)
    axes[1].plot(np.arange(1,len(e)+1),np.cumsum(e)/sum(e),'o-',label=label)
axes[0].axhline(.001,linestyle='--')
axes[0].set_xlabel('Eigenvalue index');axes[0].set_ylabel('Relative eigenvalue')
axes[1].axhline(.95,linestyle='--')
axes[1].set_xlabel('Retained dimension');axes[1].set_ylabel('Cumulative variance fraction')
for ax in axes:ax.legend()
fig.suptitle('Reported-summary arithmetic only: no new row-level validation')
fig.tight_layout();fig.savefig('rg_observable_summary.png',dpi=160)
