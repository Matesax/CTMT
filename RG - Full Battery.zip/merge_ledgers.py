#!/usr/bin/env python3
"""Merge partial ledgers (from run_all.py --only ...) into one ledger, in registry order.

    python3 -I merge_ledgers.py ledger_mutations.json ledger_mutations_partial.json -o ledger_mutations.json

Later files override earlier ones battery by battery. The summary is recomputed. Every registered battery must be
present in the merged ledger.
"""
import argparse, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('ledgers', nargs='+'); ap.add_argument('-o', required=True)
    a = ap.parse_args()
    reg = json.load(open(os.path.join(HERE, 'registry.json')))
    by = {}
    mut = False
    for f in a.ledgers:
        d = json.load(open(f))
        for r in d['batteries']:
            by[r['key']] = r; mut = mut or 'mutation_suite' in r
    missing = [e['key'] for e in reg if e['key'] not in by]
    if missing:
        print('missing batteries:', missing); return 1
    ledger = [dict(by[e['key']], title=e['title'], kind=e['kind'], rungs=e['rungs']) for e in reg]   # registry is authoritative
    ok = all(r['status'] == 'PASS' for r in ledger) and (not mut or all(r.get('mutation_suite', {}).get('status') in ('ALL CAUGHT', 'no suite') for r in ledger))
    summary = dict(batteries=len(ledger), passed=sum(r['status'] == 'PASS' for r in ledger),
                   groups=sum(len(r.get('groups', [])) for r in ledger), byte_identical=sum(bool(r.get('byte_identical')) for r in ledger))
    if mut:
        summary['mutations_caught'] = sum(r.get('mutation_suite', {}).get('caught', 0) for r in ledger)
        summary['mutations_total'] = sum(r.get('mutation_suite', {}).get('total') or 0 for r in ledger)
    summary['verdict'] = 'PASS' if ok else 'FAIL'
    json.dump(dict(summary=summary, batteries=ledger), open(a.o, 'w'), indent=1)
    md = os.path.splitext(a.o)[0] + '.md'
    with open(md, 'w') as f:
        f.write('# Resolution Geometry: full battery ledger\n\n' + ' | '.join(f'{k}: {v}' for k, v in summary.items()) + '\n\n')
        f.write('| battery | kind | rungs | groups | status | identical | runtime s' + (' | mutations' if mut else '') + ' |\n')
        f.write('|---|---|---|---|---|---|---' + ('|---' if mut else '') + '|\n')
        for r in ledger:
            row = f"| {r['title']} | {r['kind']} | {r['rungs']} | {len(r.get('groups', []))} | {r['status']} | {r.get('byte_identical')} | {r.get('runtime_s')}"
            if mut:
                ms = r.get('mutation_suite', {}); row += f" | {ms.get('caught', '-')}/{ms.get('total', '-')}"
            f.write(row + ' |\n')
    print(json.dumps(summary))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
