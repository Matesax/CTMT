#!/usr/bin/env python3
"""Mutation suite for rg_information_protection.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. Under a minute.

    python3 -I rg_information_protection_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('IA', 'the which-path record made to read coherence', "path = lambda r: np.array([(1 + r[2]) / 2, (1 - r[2]) / 2])", "path = lambda r: np.array([(1 + r[2]) / 2, (1 - r[2] + r[0]) / 2])"),
    ('IB', 'the overlap left out of the visibility', "V = 2 * abs(amp0 * np.conj(amp1) * np.vdot(m1, m0))", "V = 2 * abs(amp0 * np.conj(amp1))"),
    ('IC', 'the eraser basis set to the marker basis itself', "u = (m0 + m1) / np.linalg.norm(m0 + m1); v = (m0 - m1) / np.linalg.norm(m0 - m1)", "u = np.array([1.0, 0.0]); v = np.array([0.0, 1.0])"),
    ('ID', 'the recombination left out', "H = (X + Z) / math.sqrt(2)", "H = I2"),
    ('IE', 'local tomography broken by one extra parameter', "loc_tom = all(ks[r][2] * ks[r][2] == (2 * 2) ** r for r in (1, 2, 3))", "loc_tom = all(ks[r][2] * ks[r][2] + 1 == (2 * 2) ** r for r in (1, 2, 3))"),
]


def main():
    base = open(os.path.join(HERE, 'rg_information_protection.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_information_protection.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_information_protection.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_information_protection_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
