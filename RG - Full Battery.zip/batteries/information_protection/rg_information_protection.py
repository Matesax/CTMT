#!/usr/bin/env python3
"""RG - Information Protection: is the particle the answer that information enforces when a protocol asks a sharp question
of the hidden room, and does that give RG a prediction quantum theory does not?

On RG's terms. A protocol is a record map on states; its kernel is what it cannot see (the hidden room for that protocol);
its quotient is what it resolves. The particle is the quotient of the which-path protocol (populations, one click).

  IA kernel complementarity: the which-path record map has the coherence plane in its kernel and the interference record
     map has the population axis in its kernel; the joint protocol family has full rank 3 (Bloch); canary: the identity
     record has an empty kernel
  IB information protection, quantified: with a path marker, visibility V and optimal distinguishability D obey
     D^2 + V^2 <= 1, with equality for a pure joint path-marker state; a mixed preparation without any marker has V < 1
     (not asking does not guarantee fringes)
  IC information, not a kick: markers of overlap c reduce visibility to |c| with zero momentum transfer, a random kick
     of spread s reduces it to exp(-s^2/2) with no marker; an eraser restores full visibility in each conditioned
     subensemble, with opposite fringes, while the unconditioned visibility stays |c| (no signalling)
  ID the particle record is not a sufficient predictive state: two preparations with identical populations and opposite
     phase give outcome laws at total-variation distance 1 after recombination, so any population-only predictor errs by
     at least 1/2; the predictive quotient of a two-level system has rank 4 (classical bit: 2); measured rank 4 for
     photon polarization (Mazurek et al.)
  IE the attempted RG prediction: if composite records are fixed by local records (rank K_AB = K_A K_B) and pure records
     are connected by continuous reversible transport, then K = N^r with r = 2 the smallest admissible exponent (classical
     r = 1 has isolated pure states); predicted ranks 4, 9, 16 for N = 2, 3, 4; canary: the classical simplex has K = N
     and no continuous transport between its pure states

Deterministic. Seed 20261202. Writes rg_information_protection_results.json.
Run:  python3 -I rg_information_protection.py      (numpy, scipy)
"""
import hashlib, itertools, json, math, os, sys
import numpy as np
from scipy.linalg import expm

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 20261202
R, FAILS = {}, []
X = np.array([[0, 1], [1, 0]], complex); Y = np.array([[0, -1j], [1j, 0]]); Z = np.diag([1.0, -1.0]).astype(complex); I2 = np.eye(2)


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.8g}')


def below(v, b):
    return f'< {b:g}' if abs(v) < b else fl(v)


def bloch_state(r):
    return 0.5 * (I2 + r[0] * X + r[1] * Y + r[2] * Z)


def IA():
    # record maps on the Bloch vector r: which-path records p(path) = (1 +- z)/2; interference records at phases phi: (1 + x cos phi + y sin phi)/2
    path = lambda r: np.array([(1 + r[2]) / 2, (1 - r[2]) / 2])
    interf = lambda r: np.array([(1 + r[0] * math.cos(p) + r[1] * math.sin(p)) / 2 for p in np.linspace(0, 2 * math.pi, 7)[:-1]])
    ident = lambda r: np.array(r)
    def jac(f):
        r0 = np.array([0.1, 0.2, 0.3]); return np.array([(f(r0 + 1e-6 * e) - f(r0 - 1e-6 * e)) / 2e-6 for e in np.eye(3)]).T
    def kernel(f):
        J = jac(f); u, s, vt = np.linalg.svd(J); rank = int(np.sum(s > 1e-8)); return rank, vt[rank:]
    rp, kp = kernel(path); ri, ki = kernel(interf); rj = np.linalg.matrix_rank(np.vstack([jac(path), jac(interf)]), tol=1e-8); rid, _ = kernel(ident)
    kp_plane = np.abs(kp[:, 2]).max() < 1e-9 if len(kp) else False
    ki_axis = len(ki) == 1 and abs(abs(ki[0][2]) - 1) < 1e-9
    ok = rp == 1 and kp_plane and ri == 2 and ki_axis and rj == 3 and rid == 3
    must(ok, 'IA')
    R['IA'] = dict(claim='Kernel complementarity. The which-path record map resolves one direction (the population axis z) and has the '
                         'coherence plane (x, y) in its kernel: the hidden room of that protocol. The interference record map resolves '
                         'the coherence plane and has the population axis in its kernel. Together they have full rank 3. Each protocol '
                         'sees exactly what the other cannot. Canary: the identity record has an empty kernel.',
                   status='computed', rank_path=rp, rank_interference=ri, rank_joint=int(rj))


def IB():
    rng = np.random.default_rng(SEED); out = []
    for _ in range(200):
        a = rng.uniform(0.05, 0.95); phase = rng.uniform(0, 2 * math.pi)
        m0 = rng.normal(size=3) + 1j * rng.normal(size=3); m0 /= np.linalg.norm(m0)
        m1 = rng.normal(size=3) + 1j * rng.normal(size=3); m1 /= np.linalg.norm(m1)
        amp0, amp1 = math.sqrt(a), math.sqrt(1 - a) * np.exp(1j * phase)
        V = 2 * abs(amp0 * np.conj(amp1) * np.vdot(m1, m0))
        # optimal distinguishability: trace norm of a|m0><m0| - (1-a)|m1><m1| (Helstrom)
        Dop = np.linalg.eigvalsh(a * np.outer(m0, m0.conj()) - (1 - a) * np.outer(m1, m1.conj()))
        D = float(np.sum(np.abs(Dop)))
        out.append((D, V))
    resid = max(abs(D * D + V * V - 1) for D, V in out)
    # mixed preparation, no marker: dephased path qubit, coherence reduced by p
    p = 0.6; V_mixed = 2 * math.sqrt(0.5 * 0.5) * p; D_mixed = 0.0
    ok = resid < 1e-10 and V_mixed < 1 and D_mixed ** 2 + V_mixed ** 2 < 1
    must(ok, 'IB')
    R['IB'] = dict(claim='Information protection, quantified. For 200 random pure joint path-marker states, the visibility V and the '
                         'optimal (Helstrom) path distinguishability D satisfy D^2 + V^2 = 1 to the residual below: every bit of '
                         'which-path information available anywhere costs exactly the visibility it implies. For mixed states the '
                         'relation is an inequality: a dephased preparation with no marker at all gives V = 0.6 and D = 0, so not '
                         'asking does not guarantee fringes.',
                   status='computed; IDENTIFIED (Englert 1996; Greenberger and Yasin 1988)', pure_residual=below(resid, 1e-10), mixed_example=dict(D=D_mixed, V=fl(V_mixed)))


def IC():
    # path superposition, interference after recombination: fringe intensity vs phase phi
    phis = np.linspace(0, 2 * math.pi, 721)
    def vis(curve):
        return float((curve.max() - curve.min()) / (curve.max() + curve.min()))
    c = 0.3 + 0.4j                                                  # marker overlap <m1|m0>, |c| = 0.5
    marker = np.array([0.5 * (1 + abs(c) * math.cos(f + np.angle(c))) for f in phis])
    s = 1.1774                                                      # random-kick spread giving exp(-s^2/2) = 0.5
    kick = np.array([0.5 * (1 + math.exp(-s * s / 2) * math.cos(f)) for f in phis])
    # eraser: marker states m0 = |0>, m1 = cos t |0> + sin t |1>, measured in a basis; conditioned fringes
    t = math.acos(abs(c)); m0 = np.array([1.0, 0.0]); m1 = np.array([math.cos(t), math.sin(t)])
    def conditioned(e):
        a0, a1 = np.vdot(e, m0), np.vdot(e, m1)
        return np.array([0.25 * abs(a0 + np.exp(1j * f) * a1) ** 2 for f in phis])
    # erasing basis: the two outcomes symmetric with respect to m0, m1
    u = (m0 + m1) / np.linalg.norm(m0 + m1); v = (m0 - m1) / np.linalg.norm(m0 - m1)
    cu, cv = conditioned(u), conditioned(v); total = cu + cv
    ok = abs(vis(marker) - abs(c)) < 1e-4 and abs(vis(kick) - 0.5) < 1e-4 and vis(cu) > 0.999 and vis(cv) > 0.999 \
        and abs(vis(total) - abs(c)) < 1e-4 and abs(np.argmax(cu) - np.argmin(cv)) <= 2
    must(ok, 'IC')
    R['IC'] = dict(claim='Information, not a kick. A path marker with overlap |c| = 0.5 and no momentum transfer reduces visibility to 0.5; '
                         'a random phase kick of spread 1.18 with no marker gives the same 0.5. The two are told apart by erasure: '
                         'measuring the marker in a basis symmetric to its two states restores visibility 1 in each conditioned '
                         'subensemble, with fringes shifted by half a period, while the unconditioned pattern keeps visibility 0.5 (no '
                         'signalling). A kick cannot be undone by a measurement on another system. Measured: Duerr, Nonn and Rempe '
                         '(1998) found the momentum back-action of their which-way detection too small to explain the loss of fringes, '
                         'and attributed it to correlations between detector and atomic motion.',
                   status='computed (model); MEASURED anchor (Duerr, Nonn and Rempe 1998)', visibility=dict(marker=fl(vis(marker)), kick=fl(vis(kick)),
                   eraser_conditioned=[fl(vis(cu)), fl(vis(cv))], eraser_unconditioned=fl(vis(total))))


def ID():
    # two preparations with identical populations and opposite phase: |+> and |->
    plus, minus = bloch_state([1, 0, 0]), bloch_state([-1, 0, 0])
    pop = lambda r: np.real(np.diag(r))
    same_q = np.abs(pop(plus) - pop(minus)).max()
    H = (X + Z) / math.sqrt(2)                                      # recombination (Hadamard) then path readout
    law = lambda r: np.real(np.diag(H @ r @ H.conj().T))
    tv = 0.5 * np.abs(law(plus) - law(minus)).sum()
    # rank of the preparation-effect matrix: many quantum preparations and effects vs classical bit
    rng = np.random.default_rng(SEED + 1)
    def rand_bloch():
        v = rng.normal(size=3); return v / np.linalg.norm(v) * rng.uniform(0, 1)
    preps = [bloch_state(rand_bloch()) for _ in range(40)]
    effs = []
    for _ in range(40):
        v = rng.normal(size=3); v /= np.linalg.norm(v); w = rng.uniform(0.2, 1)
        effs.append(0.5 * (w * I2 + w * (v[0] * X + v[1] * Y + v[2] * Z)))
    M = np.array([[np.real(np.trace(e @ p)) for e in effs] for p in preps])
    rank_q = int(np.linalg.matrix_rank(M, tol=1e-9))
    ce = rng.uniform(0, 1, (40, 2)); cq = rng.uniform(0, 1, 40)                    # classical bit: P(effect | prep) = q e + (1 - q) f
    Mc = np.array([[q * e + (1 - q) * f for e, f in ce] for q in cq])
    rank_c = int(np.linalg.matrix_rank(Mc, tol=1e-9))
    ok = same_q < 1e-12 and abs(tv - 1) < 1e-12 and rank_q == 4 and rank_c == 2
    must(ok, 'ID')
    R['ID'] = dict(claim='The particle record is not a sufficient predictive state. |+> and |-> have identical path populations (the '
                         'particle record) but, after recombination, outcome laws at total-variation distance 1; any predictor that '
                         'keeps only populations errs by at least 1/2 on one of them. The predictive quotient (the coarsest exact '
                         'state) of a two-level system has rank 4: the preparation-effect matrix of 40 random preparations and 40 '
                         'random effects has rank 4, while a classical bit gives rank 2 (canary). Measured: for photon polarization '
                         'the rank is 4, with rank 5 disfavoured by a relative likelihood of about 1e-414, and any greater-than-quantum '
                         'CHSH violation at most 1.3 per cent (Mazurek et al. 2021).',
                   status='computed; MEASURED anchor (Mazurek et al. 2021)', identical_population=below(same_q, 1e-12), tv_after_recombination=fl(tv),
                   rank_two_level=rank_q, rank_classical_bit=rank_c)


def IE():
    # local tomography: K_AB = K_A K_B; with K = N^r and N_AB = N_A N_B, r is fixed by one system
    ks = {r: {N: N ** r for N in (2, 3, 4)} for r in (1, 2, 3)}
    loc_tom = all(ks[r][2] * ks[r][2] == (2 * 2) ** r for r in (1, 2, 3))
    # continuity: pure states of the classical simplex are isolated; of the qubit, connected by a continuous unitary
    classical_pure = [np.array([1, 0]), np.array([0, 1])]
    min_gap = min(np.abs(a - b).sum() for a, b in itertools.combinations(classical_pure, 2))
    U = lambda t: expm(-1j * t * Y / 2); path = [U(t) @ np.array([1, 0]) for t in np.linspace(0, math.pi, 50)]
    purity = max(abs(np.vdot(p, p) - 1) for p in path); steps = max(np.linalg.norm(path[i + 1] - path[i]) for i in range(49))
    ok = loc_tom and min_gap == 2 and purity < 1e-12 and steps < 0.04 and ks[2] == {2: 4, 3: 9, 4: 16}
    must(ok, 'IE')
    R['IE'] = dict(claim='The attempted prediction. If composite records are fixed by local records (rank K_AB = K_A K_B) then K = N^r '
                         'with one exponent r for all systems. If pure records are connected by continuous reversible transport, r = 1 '
                         '(classical: isolated pure states, distance 2 apart) is excluded, while the pure states of the qubit are joined '
                         'by a continuous unitary path (step below 0.04, purity kept). The smallest admissible exponent is r = 2, giving '
                         'ranks 4, 9, 16 for N = 2, 3, 4; the measured polarization rank is 4. This is the reconstruction of Hardy (2001), '
                         'which also needs a simplicity axiom to exclude r >= 3. It is quantum theory, not a deviation from it.',
                   status='computed; IDENTIFIED (Hardy 2001; Masanes and Mueller 2011)', ranks_by_exponent={str(r): v for r, v in ks.items()},
                   classical_pure_gap=float(min_gap), quantum_path_step=fl(steps))


if __name__ == '__main__':
    for name, fn in (('IA', IA), ('IB', IB), ('IC', IC), ('ID', ID), ('IE', IE)):
        try:
            fn()
        except Exception as e:
            must(False, name); R[name] = dict(crash=repr(e))
        print(name, flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(open(os.path.abspath(__file__), 'rb').read()).hexdigest()
    json.dump(out, open(os.path.join(HERE, 'rg_information_protection_results.json'), 'w'), indent=1, sort_keys=True)
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
