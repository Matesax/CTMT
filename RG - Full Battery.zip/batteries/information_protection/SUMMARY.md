# RG – Information Protection: does "information protects the hidden room" give RG its own prediction?

**Verdict: the reading holds on RG's terms and is backed by measurement. No RG-specific prediction locks, so no print is built.** Every quantitative law that comes out is already quantum theory, and the attempted RG prediction reproduces Hardy's reconstruction. The supplied critique's corrections are accepted; they are listed at the end.

## What holds, on RG's terms

A protocol is a record map. Its kernel is that protocol's hidden room, and its quotient is what it resolves. The particle is the quotient of the which-path protocol: populations, one click.

| Group | Finding |
|---|---|
| IA, kernel complementarity | The which-path record map has rank 1. Its kernel is the coherence plane. The interference record map has rank 2, and its kernel is the population axis. Together they have rank 3. Each protocol's hidden room is exactly what the other resolves. Canary: the identity record has an empty kernel |
| IB, protection quantified | For 200 random pure joint path–marker states, D² + V² = 1 to 10⁻¹⁰, with D the optimal (Helstrom) distinguishability. Any which-path information available anywhere costs exactly the visibility it implies. Mixed states give an inequality: a dephased preparation with no marker has V = 0.6 and D = 0, so not asking does not guarantee fringes |
| IC, information, not a kick | A marker with overlap 0.5 and no momentum transfer gives V = 0.5. A random kick with no marker also gives V = 0.5. Erasure separates them: each conditioned subensemble returns to V = 1, with fringes shifted by half a period, while the unconditioned pattern stays at 0.5 (no signalling). A kick cannot be undone by measuring another system. Measured: Dürr, Nonn and Rempe (1998) found the momentum back-action too small to explain the loss of fringes and attributed it to detector–atom correlations |
| ID, the particle record is insufficient | \|+⟩ and \|−⟩ have identical populations, yet after recombination their outcome laws differ by total-variation distance 1. Any population-only predictor errs by at least ½ on one of them. The predictive quotient of a two-level system has rank 4; the classical-bit canary has rank 2. Measured: photon polarization has rank 4, rank 5 is disfavoured by a likelihood ratio of about 10⁻⁴¹⁴, and any super-quantum CHSH violation is at most 1.3 % (Mazurek et al. 2021) |
| IE, the attempted RG prediction | Suppose composite records are fixed by local records (K_AB = K_A K_B), and pure records are joined by continuous reversible transport. Then K = N^r, the classical exponent r = 1 is excluded (its pure states are isolated, a distance 2 apart), and r = 2 is the smallest admissible exponent: K = 4, 9, 16 for N = 2, 3, 4. The measured rank is 4 |

Battery: `rg_information_protection.py`, seed 20261202. It reruns byte-identically, and the battery's own checks catch all 5 deliberate mutations.

## Why the prediction does not lock

1. **IE is quantum theory, not a deviation.** It is Hardy's reconstruction (2001) and that of Masanes and Müller (2011). It also needs a simplicity axiom to exclude r ≥ 3, and RG has no rung that supplies it. A positive test (rank 4 for a qubit, 9 for a qutrit) confirms quantum theory and gives RG no credit.
2. **RG adds no observable bound in the tested domain.** Wherever RG reproduces quantum mechanics, it cannot also predict a different visibility, rank or correlation unless it adds a physical premise. That premise would need independent motivation: a collapse rate, a resolution scale or a memory limit chosen for convenience would be a model to test, not a consequence of RG.
3. **What RG contributes is a typing.** Particle = the quotient of the which-path protocol. Hidden room = its kernel. Protection = the duality relation. One World = one state reproducing both quotients. This is a correct and useful reading, but not a new number.

## The route that remains

The supplied critique names a candidate that RG could own: a certificate of minimal predictive structure. For a declared protocol family, find:
- the smallest predictive state that every successful model must keep (RG's coarsest exact quotient);
- the unavoidable error of any smaller description (at least half the largest total-variation distance between preparations that agree on that description);
- the intervention that reveals the missing distinction.

ID is the elementary case. Its novelty would require a sharp physical application with realistic nuisance parameters, compared against existing dimension-witness and GPT-tomography methods. That is not yet done, and Mazurek et al. is the bar to beat.

## Corrections accepted from the supplied critique

- Not asking which path does not guarantee V = 1 (IB, mixed case).
- Which-path information matters as a physical correlation, whether or not anyone reads it.
- An eraser restores fringes only in conditioned subensembles. The unconditioned pattern does not change (IC).
- D² + V² = 1 holds for a pure joint path–marker state with optimal D. In general it is an inequality.
- Information causality does not by itself characterize the whole quantum correlation set.

## Sources

- B.-G. Englert, Fringe visibility and which-way information: an inequality, Phys. Rev. Lett. 77 (1996) 2154; D. M. Greenberger, A. Yasin, Phys. Lett. A 128 (1988) 391.
- S. Dürr, T. Nonn, G. Rempe, Origin of quantum-mechanical complementarity probed by a 'which-way' experiment in an atom interferometer, Nature 395 (1998) 33.
- M. D. Mazurek, M. F. Pusey, K. J. Resch, R. W. Spekkens, Experimentally bounding deviations from quantum theory in the landscape of generalized probabilistic theories, PRX Quantum 2 (2021) 020302; arXiv:1710.05948.
- L. Hardy, Quantum theory from five reasonable axioms, arXiv:quant-ph/0101012 (2001); Ll. Masanes, M. P. Müller, A derivation of quantum theory from physical requirements, New J. Phys. 13 (2011) 063001.
