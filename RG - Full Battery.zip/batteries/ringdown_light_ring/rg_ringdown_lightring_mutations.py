#!/usr/bin/env python3
"""Mutation suite for rg_ringdown_lightring.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. About one minute.

    python3 -I rg_ringdown_lightring_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('KA', 'the retrograde orbit computed as the prograde one', "s = 1.0 if prograde else -1.0", "s = 1.0"),
    ('KB', 'the orbital frequency taken 5 per cent high', "off = np.array([w.real - Om * Lx for w, Lx in zip(W, L)])", "off = np.array([w.real - 1.05 * Om * Lx for w, Lx in zip(W, L)])"),
    ('KC', 'Richardson without the 1/L term', "A = np.array([[L, 1.0, 1 / L] for L in Ls]); return float(np.linalg.solve(A, np.array([w.real for w in ws]))[0])", "A = np.array([[L, 1.0] for L in Ls]); return float(np.linalg.lstsq(A, np.array([w.real for w in ws]), rcond=None)[0][0])"),
    ('KC', 'the exponent ladder written with a 1/L correction', "return 2 * (L2 ** 2 * (-w2.imag) - L1 ** 2 * (-w1.imag)) / (L2 ** 2 - L1 ** 2)", "return 2 * (L2 * (-w2.imag) - L1 * (-w1.imag)) / (L2 - L1)"),
    ('KD', 'solar time unit off by ten', "Tsun = 4.925490947641e-6", "Tsun = 4.925490947641e-5"),
    ('KD', 'the (4,4,0) damping time read as the (2,2,0) one', "lam_hat = 2 * (4.5 ** 2 / T4 - 2.5 ** 2 / T2)", "lam_hat = 2 * (4.5 ** 2 / T2 - 2.5 ** 2 / T2)"),
    ('KE', 'Fisher matrix scaled by rho instead of rho^2', "C = np.linalg.inv(F); return", "F = F / rho; C = np.linalg.inv(F); return"),
    ('KG', 'the collision polynomial missing one observed mode', "q = lambda x: np.prod(1 - L / np.asarray(x, float)[..., None], axis=-1)", "q = lambda x: np.prod(1 - L[:2] / np.asarray(x, float)[..., None], axis=-1)"),
    ('KF', 'the reference family reduced to one parameter', "Qi = float(np.interp(q, qf, grid)); M =", "Qi = 0.0; M ="),
]


def main():
    base = open(os.path.join(HERE, 'rg_ringdown_lightring.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_ringdown_lightring.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_ringdown_lightring.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_ringdown_lightring_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
