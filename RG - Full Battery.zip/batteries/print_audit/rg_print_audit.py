#!/usr/bin/env python3
"""Resolution Geometry - audit of the print itself.

  PL ladder integrity: 134 rungs L0-L133, contiguous, dependencies point backward only, the open rungs are L132 and L133
     and nothing depends on them, every rung reference resolves to a label
  PW the Lorentzian boundary witness of L127: the plane wave with profile A(u)(x^2 - y^2) is Ricci-flat with vanishing
     Kretschmann scalar and nonzero curvature; an observer's tidal tensor scales with the boost (sympy)
  PR references: every citation has exactly one bibliography entry, every bibliography key is unique, every \\ref has a
     label, every label is unique
  PC companions: 55 rows, 5 attached to all rungs, names unique, every attach rung exists, every row cites an entry
  PH hypothesis ledger: 25 hypotheses with classes 5 D, 10 T, 1 A, 9 I, as the native section states; a rung marked
     "D: x" discharges only a hypothesis marked D; no rung still conditions on a hypothesis marked D unless the rung
     names the scope of the discharge
  PB every battery in the registry appears in the battery appendix, and every appendix row is a registered battery

Deterministic (no randomness). Writes rg_print_audit_results.json.
Run:  python3 -I rg_print_audit.py      (sympy)
"""
import hashlib, json, re, sys
from pathlib import Path
import sympy as sp

HERE = Path(__file__).resolve().parent
TEX = HERE / 'Resolution_Geometry.tex'
REG = HERE / 'registry.json'
R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def ladder_rows(s):
    body = s[s.index(r"\itshape Exact layer"):]; body = body[:body.index(r"\bottomrule")]
    return [m.groups() for m in (re.match(r"^L(\d+) & (.*) & (.*?) & (.*?) & \\ref\{(.*?)\}\\\\$", l.strip())
                                 for l in body.splitlines()) if m]


def deps(raw):
    out = []
    if raw.strip() == '---':
        return out
    for part in raw.split(','):
        part = part.strip()
        if '--' in part:
            a, b = part.split('--'); out += list(range(int(a.lstrip('L')), int(b.lstrip('L')) + 1))
        else:
            out.append(int(part.lstrip('L')))
    return out


def group_PL(s):
    rows = ladder_rows(s); ids = [int(r[0]) for r in rows]
    opens = [int(r[0]) for r in rows if r[2].strip() == 'O']
    labels = set(re.findall(r"\\label\{(.*?)\}", s))
    res = dict(rungs=len(rows), contiguous=ids == list(range(len(rows))),
               backward_only=all(d < int(r[0]) for r in rows for d in deps(r[3])), open_rungs=opens,
               nothing_depends_on_open=not any(d in opens for r in rows for d in deps(r[3])),
               refs_resolve=all(r[4] in labels for r in rows))
    ok = res['rungs'] == 134 and res['contiguous'] and res['backward_only'] and res['open_rungs'] == [132, 133] \
        and res['nothing_depends_on_open'] and res['refs_resolve']
    must(ok, 'PL')
    R['PL'] = dict(claim='Ladder integrity: 134 rungs, contiguous, backward-only, open rungs L132 and L133 with no '
                         'dependants, every rung reference resolves', **res)


def group_PW():
    u, v, x, y = sp.symbols('u v x y', real=True); A = sp.Function('A')(u); X = (u, v, x, y); n = 4
    g = sp.Matrix([[A * (x ** 2 - y ** 2), 1, 0, 0], [1, 0, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]); gi = g.inv()
    Gm = [[[sp.simplify(sum(gi[a, d] * (sp.diff(g[d, b], X[c]) + sp.diff(g[d, c], X[b]) - sp.diff(g[b, c], X[d])) for d in range(n)) / 2)
            for c in range(n)] for b in range(n)] for a in range(n)]
    Rm = {(a, b, c, d): sp.simplify(sp.diff(Gm[a][b][d], X[c]) - sp.diff(Gm[a][b][c], X[d])
                                    + sum(Gm[a][c][e] * Gm[e][b][d] - Gm[a][d][e] * Gm[e][b][c] for e in range(n)))
          for a in range(n) for b in range(n) for c in range(n) for d in range(n)}
    Ric = sp.Matrix(4, 4, lambda b, d: sp.simplify(sum(Rm[a, b, a, d] for a in range(n))))
    Rl = {k: sp.simplify(sum(g[k[0], e] * Rm[e, k[1], k[2], k[3]] for e in range(n))) for k in Rm}
    K = sp.simplify(sum(Rl[k] * sum(gi[k[0], a] * gi[k[1], b] * gi[k[2], c] * gi[k[3], d] * Rl[a, b, c, d]
                                     for a in range(n) for b in range(n) for c in range(n) for d in range(n))
                        for k in Rl if Rl[k] != 0))
    al = sp.symbols('a', positive=True); U = [al, -1 / (2 * al), 0, 0]
    E = sp.Matrix(2, 2, lambda i, j: sp.simplify(sum(Rl[(p, i + 2, q, j + 2)] * U[p] * U[q] for p in range(4) for q in range(4))))
    nz = sum(1 for k in Rl if Rl[k] != 0)
    ok = all(e == 0 for e in Ric) and sp.simplify(K) == 0 and nz > 0 and sp.simplify(E[0, 0] / al ** 2).has(al) is False
    must(ok, 'PW')
    R['PW'] = dict(claim='L127 witness: the plane wave is Ricci-flat, its Kretschmann scalar vanishes, its curvature does '
                         'not, and the tidal tensor of an observer scales as the square of the boost', ricci_zero=all(e == 0 for e in Ric),
                   kretschmann=str(K), riemann_nonzero_components=nz, observer_tidal=str(E))


def group_PR(s):
    body, bib = s[:s.index(r'\begin{thebibliography}')], s[s.index(r'\begin{thebibliography}'):]
    cites = set()
    for m in re.finditer(r"\\cite\{([^}]*)\}", s):
        cites |= {k.strip() for k in m.group(1).split(',')}
    keys = re.findall(r"\\bibitem\{([^}]*)\}", bib)
    refs = set(re.findall(r"\\ref\{([^}]*)\}", s)); labels = re.findall(r"\\label\{([^}]*)\}", s)
    missing = sorted(cites - set(keys)); dup_keys = sorted({k for k in keys if keys.count(k) > 1})
    unres = sorted(refs - set(labels)); dup_labels = sorted({k for k in labels if labels.count(k) > 1})
    uncited = sorted(set(keys) - cites)
    ok = not missing and not dup_keys and not unres and not dup_labels
    must(ok, 'PR')
    R['PR'] = dict(claim='Every citation has one bibliography entry, keys and labels are unique, every reference resolves',
                   citations=len(cites), entries=len(keys), missing=missing, duplicate_keys=dup_keys,
                   unresolved_refs=unres, duplicate_labels=dup_labels, uncited_entries=uncited)


def companion_rows(s):
    i = s.index(r'Companion & Attaches at & Content and status'); j = s.index(r'\end{longtable}', i)
    out = []
    for line in s[i:j].splitlines()[1:]:
        parts = line.strip().split(' & ', 2)
        if len(parts) == 3:
            out.append(parts)
    return out


def group_PC(s):
    rows = companion_rows(s); names = [r[0] for r in rows]
    keys = set(re.findall(r"\\bibitem\{([^}]*)\}", s))
    meta = [r[0] for r in rows if r[1].strip().startswith('all')]
    bad_rung = []
    for n_, raw, _ in rows:
        rs = [int(a) for a in re.findall(r"L(\d+)", raw)]
        if any(r_ > 133 for r_ in rs):
            bad_rung.append(n_)
    uncited = [r[0] for r in rows if not any(k in keys for m in re.finditer(r"\\cite\{([^}]*)\}", r[2]) for k in m.group(1).split(','))]
    ok = len(rows) == 55 and len(meta) == 5 and len(set(names)) == len(names) and not bad_rung and not uncited
    must(ok, 'PC')
    R['PC'] = dict(claim='Companion map: 55 rows, 5 attached to all rungs, unique names, attach rungs exist, every row '
                         'cites an entry', rows=len(rows), meta=meta, duplicates=sorted({n_ for n_ in names if names.count(n_) > 1}),
                   bad_attach=bad_rung, uncited_rows=uncited)


def group_PH(s):
    i = s.index(r'\paragraph{Hypotheses used in this paper.}'); j = s.index(r'\end{tabular}', i)
    rows = re.findall(r"^\\h\{H-([^}]*)\} & .* & ([DTAI])\\\\", s[i:j], re.M)
    cls = {h: c for h, c in rows}
    count = {c: sum(1 for v in cls.values() if v == c) for c in 'DTAI'}
    stated = re.search(r"Of the twenty-five hypotheses of the hypothesis table, (\w+) are discharged, (\w+) are record tests, "
                       r"(\w+) is an anchor and\s+(\w+) are irreducible", s)
    words = dict(one=1, five=5, nine=9, ten=10, eight=8, eleven=11)
    stated_counts = None if not stated else [words.get(w, -1) for w in stated.groups()]
    ladder = ladder_rows(s)
    d_marks = [(int(r[0]), h) for r in ladder for h in re.findall(r"D:\s*([A-Za-z]+)", r[2])]
    bad_d = [(rid, h) for rid, h in d_marks if cls.get(h) != 'D']
    still = [(int(r[0]), h) for r in ladder for m in re.finditer(r"H:\s*([^)]*)", r[2]) for seg in m.group(1).split(';')
             if not seg.strip().startswith('D:') for h in re.split(r"[,\s]+", seg) if cls.get(h) == 'D' and '(D' not in r[2]]
    ok = len(cls) == 25 and count == dict(D=5, T=10, A=1, I=9) and stated_counts == [5, 10, 1, 9] and not bad_d and not still
    must(ok, 'PH')
    R['PH'] = dict(claim='Hypothesis ledger: 25 hypotheses, 5 D, 10 T, 1 A, 9 I, as stated in the native section; D marks '
                         'on rungs only for D hypotheses; no rung conditions on a discharged hypothesis without naming the scope',
                   classes=cls, counts=count, stated=stated_counts, rung_discharges=d_marks, bad_discharges=bad_d, still_conditioned=still)


def group_PB(s):
    reg = json.loads(REG.read_text())
    i = s.index(r'\label{app:battery}'); app = s[i:s.index(r'\begin{thebibliography}')]
    rows = [r_.replace('\\_', '_') for r_ in re.findall(r"^\\texttt\{([a-z\\_]+)\} & ", app, re.M)]
    want = [e['key'] for e in reg]
    ok = sorted(rows) == sorted(want) and len(rows) == len(set(rows))
    must(ok, 'PB')
    R['PB'] = dict(claim='The battery appendix lists exactly the registered batteries', registered=len(want), listed=len(rows),
                   missing=sorted(set(want) - set(rows)), extra=sorted(set(rows) - set(want)))


def main():
    s = TEX.read_text()
    group_PL(s); group_PW(); group_PR(s); group_PC(s); group_PH(s); group_PB(s)
    R['failures'] = FAILS; R['seed'] = 'none (deterministic)'
    R['print_sha256'] = hashlib.sha256(TEX.read_bytes()).hexdigest()
    R['source_sha256'] = hashlib.sha256((HERE / 'rg_print_audit.py').read_bytes()).hexdigest()
    (HERE / 'rg_print_audit_results.json').write_text(json.dumps(R, indent=1, sort_keys=True))
    print(json.dumps({k: v for k, v in R.items() if k not in ('PW',)}, indent=1)[:5000])
    return 1 if FAILS else 0


if __name__ == '__main__':
    sys.exit(main())
