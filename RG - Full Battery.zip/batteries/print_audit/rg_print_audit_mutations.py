#!/usr/bin/env python3
"""Mutation suite for rg_print_audit.py.

Each mutation changes one line of the print (or, for PW, of the audit) so that the print states something false or
inconsistent. The audit must then report the targeted group as failed. A mutation that survives is a defect of the
audit; a crash is a defect of the suite, not a catch. Runs in a temporary directory; shipped files are not modified.

    python3 -I rg_print_audit_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [  # (group, description, file, old, new)
    ('PL', 'a dependency pointing forward', 'tex', r'& N / D: mono & L19, L28 &', r'& N / D: mono & L19, L30 &'),
    ('PL', 'an open rung closed', 'tex', "(Hilbert's sixteenth problem; external) & O & L69", "(Hilbert's sixteenth problem; external) & F & L69"),
    ('PW', 'plane-wave profile made non-harmonic', 'py', '[A * (x ** 2 - y ** 2), 1, 0, 0]', '[A * (x ** 2 + y ** 2), 1, 0, 0]'),
    ('PR', 'a cited entry renamed', 'tex', r'\bibitem{Lovelock}', r'\bibitem{LovelockX}'),
    ('PR', 'a label duplicated', 'tex', r'\label{cor:regtest}', r'\label{thm:derivedmfd}'),
    ('PC', 'a companion duplicated', 'tex', r'Spectral Identifiability & L122', r'Information Loss & L122'),
    ('PC', 'a companion row without citation', 'tex', r'source-remainder no-go for gravity~\cite{RadaPP}\\', r'source-remainder no-go for gravity\\'),
    ('PH', 'H-mono reclassified as irreducible', 'tex', r'a theorem for the record width (Rem.~\ref{rem:recordwidth}) & D\\', r'a theorem for the record width (Rem.~\ref{rem:recordwidth}) & I\\'),
    ('PH', 'a rung still conditioned on a discharged hypothesis', 'tex', r'(order of limits) & D: task & L38', r'(order of limits) & H: task & L38'),
    ('PH', 'stated counts disagree with the table', 'tex', r'hypothesis table, five are discharged, ten are', r'hypothesis table, five are discharged, nine are'),
    ('PB', 'a battery missing from the appendix', 'tex', r'\texttt{one\_world} & ', r'\texttt{one\_world\_x} & '),
]


def main():
    tex = open(os.path.join(HERE, 'Resolution_Geometry.tex')).read()
    py = open(os.path.join(HERE, 'rg_print_audit.py')).read()
    caught = 0
    for group, name, which, old, new in MUTATIONS:
        base = tex if which == 'tex' else py
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            shutil.copy(os.path.join(HERE, 'registry.json'), tmp)
            open(os.path.join(tmp, 'Resolution_Geometry.tex'), 'w').write(base.replace(old, new) if which == 'tex' else tex)
            open(os.path.join(tmp, 'rg_print_audit.py'), 'w').write(base.replace(old, new) if which == 'py' else py)
            subprocess.run([sys.executable, '-I', 'rg_print_audit.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_print_audit_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
