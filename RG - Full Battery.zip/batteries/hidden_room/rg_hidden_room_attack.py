#!/usr/bin/env python3
"""RG - Hidden Room at GR Crashes: can RG's principles fill the continuation room with a law that differs from GR?

Supplied model (supplied/rg_singular_boundary_attack.py): x'' = (a''/a) x away from t = 0, a = 1 + 0.4|t|^0.6.
Solutions x = a (C + D J), J = int_0^t a^-2, flux p = a x' - a' x = a^2 (x/a)' = D on each side. Continuous, linear,
symplectic interface maps are (C, D) -> (C, D + kappa C), with kappa free.

  HA reproduction of the supplied result
  HB balance fixes the room: the weak form of the equation, (a^2 y')' = 0, has residual -kappa C phi(0) for every test
     function, so RG's balance (no unrecorded source) forces kappa = 0; a nonzero kappa is a source at the interface,
     a thin shell, whose GR law is Israel's junction condition. Canary: kappa = 0 has zero residual
  HC degenerate crash (a(0) = 0): records collapse (x -> 0 for every state), a jump of C passes the weak form with zero
     residual, and balance no longer selects: the room is a correspondence that no principle fills. Canary: the same
     jump in the nondegenerate case is rejected
  HD the GR crashes are of these kinds: Schwarzschild r -> 0 is Kasner (-1/3, 2/3, 2/3), a degenerate collapse of two
     directions (C^0-inextendible, Sbierski); weak null singularities are continuous but generically without square-
     integrable Christoffel symbols, so no weak form exists in which balance can act (Christodoulou's formulation;
     proved in spherical Einstein-Maxwell-scalar models); thin shells are Geroch-Traschen regular and GR continues them
  HE the number a nonzero kappa would need: kappa = jump of flux / C is a surface source; with no matter record at the
     interface it violates balance, with one it is GR's shell

Deterministic. Seed 20261123 (no random draws beyond supplied seeds). Writes rg_hidden_room_attack_results.json.
Run:  python3 -I rg_hidden_room_attack.py
"""
import hashlib, json, math, os, subprocess, sys
import numpy as np
import sympy as sp
from scipy.integrate import quad

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 20261123
R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.8g}')


def below(v, b):
    return f'< {b:g}' if abs(v) < b else fl(v)


# ------------------------------------------------------------------------------------------ the supplied model
B, Q = 0.4, 0.6
a_nd = lambda t: 1 + B * abs(t) ** Q                                    # nondegenerate: a(0) = 1
a_dg = lambda t: abs(t) ** Q                                            # degenerate: a(0) = 0


def J(a, t):
    return math.copysign(quad(lambda s: 1 / a(s) ** 2, 0, abs(t), limit=300, epsabs=1e-12)[0], t) if t != 0 else 0.0


def phi(t, w=0.5):
    return math.exp(-1 / (1 - (t / w) ** 2)) if abs(t) < w else 0.0     # smooth bump, phi(0) = e^-1


def dphi(t, w=0.5):
    if abs(t) >= w:
        return 0.0
    u = t / w
    return phi(t, w) * (-2 * u / w) / (1 - u * u) ** 2


def weak_residual(a, ym, yp, ypm, ypp):
    """int a^2 y' phi' dt for y = ym (t<0), yp (t>0), with derivatives ypm, ypp, plus the jump term a(0)^2 [y] phi'(0).
    For (a^2 y')' = 0 in weak form this must vanish for every test function."""
    left = quad(lambda t: a(t) ** 2 * ypm(t) * dphi(t), -0.5, 0, limit=400, epsabs=1e-13, points=[0])[0]
    right = quad(lambda t: a(t) ** 2 * ypp(t) * dphi(t), 0, 0.5, limit=400, epsabs=1e-13, points=[0])[0]
    jump = a(0.0) ** 2 * (yp(0.0) - ym(0.0)) * dphi(0.0)
    # dphi(0) = 0 for the symmetric bump: use an asymmetric test function for the jump term
    return left + right + jump


def HA():
    sup = os.path.join(HERE, 'supplied')
    r = subprocess.run([sys.executable, '-I', 'rg_singular_boundary_attack.py'], cwd=sup, capture_output=True, text=True, timeout=600)
    got = json.load(open(os.path.join(sup, 'rg_singular_boundary_results.json')))
    ref = json.load(open(os.path.join(sup, 'rg_singular_boundary_results_as_supplied.json')))
    same = all(abs(got['future_records'][k] - ref['future_records'][k]) < 1e-12 for k in ref['future_records']) and got['all_pass'] and r.returncode == 0
    ok = same and abs(got['identified_kappa'] - 0.7) < 1e-12 and got['novel_dynamics_locked'] is False
    must(ok, 'HA')
    R['HA'] = dict(claim='The supplied run is reproduced: identical past records, futures 0.5253, 1.2572, 1.9891 for kappa = -1, 0, 1, '
                         'kappa recovered from a flux record, and the supplied verdict "novel dynamics not locked".',
                   status='computed', future_records={k: fl(v) for k, v in got['future_records'].items()}, supplied_all_pass=bool(got['all_pass']))


def HB():
    a = a_nd; C, D = 0.8, 0.15; res = {}
    for kappa in (-1.0, 0.0, 0.7, 1.0):
        # y = C + D_side J, y' = D_side / a^2: a^2 y' = D_side (the flux)
        ypm = lambda t: D / a(t) ** 2; ypp = lambda t, k=kappa: (D + k * C) / a(t) ** 2
        ym = lambda t: C + D * J(a, t); yp = lambda t, k=kappa: C + (D + k * C) * J(a, t)
        # residual with the bump: int flux phi' = D(phi(0) - 0) + (D + kC)(0 - phi(0)) = -kappa C phi(0)
        r = weak_residual(a, ym, yp, ypm, ypp)
        res[kappa] = dict(residual=r, predicted=-kappa * C * phi(0.0))
    ok = all(abs(v['residual'] - v['predicted']) < 1e-9 for v in res.values()) and abs(res[0.0]['residual']) < 1e-12 and abs(res[1.0]['residual']) > 0.1
    must(ok, 'HB')
    R['HB'] = dict(claim='Balance fixes the room where it exists. In weak form the equation is (a^2 y\')\' = 0, the conservation of the '
                         'flux p = a^2 y\'. For the interface family the weak residual against a smooth test function is exactly '
                         '-kappa C phi(0) (matched to 1e-9 for kappa = -1, 0.7, 1). A nonzero kappa is therefore a source sitting at '
                         'the interface. RG\'s balance admits no source without a record, so with no matter recorded there kappa = 0, '
                         'the unique continuation, and it is the weak continuation GR itself uses. With matter recorded there, the '
                         'jump is fixed by that matter: in GR this is Israel\'s junction condition for a thin shell. Either way RG and '
                         'GR agree. Canary: kappa = 0 has zero residual.',
                   status='PROVED (integration by parts) + computed; IDENTIFIED (Israel 1966)', residuals={str(k): dict(residual=fl(v['residual']), predicted=fl(v['predicted'])) for k, v in res.items()})


def HC():
    # degenerate weight: a(0) = 0. Solutions with D = 0 are y = C, x = a C -> 0 at the crash for every C
    out = {}
    for name, a in (('degenerate a = |t|^0.6', a_dg), ('nondegenerate a = 1 + 0.4|t|^0.6', a_nd)):
        Cm, Cp = 0.8, -0.5                                              # a jump of the record C across the crash
        # weak residual of y = Cm (t<0), Cp (t>0): y' = [C] delta, so int a^2 y' psi' = a(0)^2 [C] psi'(0)
        psi_d0 = 1.0                                                    # test function with psi'(0) = 1 (e.g. t phi(t)/phi(0))
        out[name] = dict(jump_residual=a(0.0) ** 2 * (Cp - Cm) * psi_d0, record_at_crash_spread=abs(a(1e-12) * Cm - a(1e-12) * Cp))
    # records collapse: two states differing only in C have records closer than |t|^0.6 near the crash
    collapse = max(abs(a_dg(t) * 0.8 - a_dg(t) * (-0.5)) for t in (1e-6, 1e-9, 1e-12))
    ok = out['degenerate a = |t|^0.6']['jump_residual'] == 0.0 and abs(out['nondegenerate a = 1 + 0.4|t|^0.6']['jump_residual']) > 1.0 and collapse < 1e-3
    must(ok, 'HC')
    R['HC'] = dict(claim='Where the crash is degenerate, nothing fills the room. With a(0) = 0 every state has x -> 0 at the crash: the '
                         'records of states that differ in C come together (closer than 1e-3 by t = 1e-6). A jump of C across the '
                         'crash has weak residual a(0)^2 [C] psi\'(0) = 0, so it passes the weak equation and balance: the continuation '
                         'is a correspondence with a free parameter, and no RG principle selects one branch. RG abstains, as it does '
                         'beyond a Cauchy horizon (GR Equivalence). Canary: the same jump in the nondegenerate case has residual 1.3 '
                         'and is rejected.',
                   status='PROVED + computed', cases={k: {a_: fl(b) for a_, b in v.items()} for k, v in out.items()}, record_collapse=fl(collapse))


def HD():
    # Schwarzschild interior near r = 0: proper time tau ~ r^(3/2); the metric approaches Kasner
    r, M, tau = sp.symbols('r M tau', positive=True)
    tau_of_r = sp.integrate(1 / sp.sqrt(2 * M / r), (r, 0, r))               # leading order of dtau = dr/sqrt(2M/r - 1)
    r_of_tau = sp.solve(sp.Eq(tau, tau_of_r), r)[0]
    # exponents from the power laws: angular scale r ~ tau^(2/3); the t-direction scale sqrt(2M/r) ~ tau^(-1/3)
    ang = sp.simplify(sp.diff(sp.log(r_of_tau), tau) * tau)
    rad = sp.simplify(sp.diff(sp.log(sp.sqrt(2 * M / r_of_tau)), tau) * tau)
    ps = [rad, ang, ang]
    kasner = sp.simplify(sum(ps)) == 1 and sp.simplify(sum(p ** 2 for p in ps)) == 1
    # tidal blow-up: the radial tidal eigenvalue of Schwarzschild is 2M/r^3
    tidal = [fl(2 * 1.0 / rr ** 3) for rr in (1e-1, 1e-2, 1e-3)]
    ok = kasner and ang == sp.Rational(2, 3) and rad == -sp.Rational(1, 3) and tidal[-1] > 1e8
    must(ok, 'HD')
    R['HD'] = dict(claim='Schwarzschild\'s crash is the degenerate kind. Near r = 0 the proper time is tau ~ r^(3/2); the angular scale '
                         'goes as tau^(2/3) and the remaining direction as tau^(-1/3): Kasner exponents (-1/3, 2/3, 2/3), with sum and '
                         'sum of squares 1 (symbolic). Two directions collapse, as in HC, and the radial tide grows as 2M/r^3. The '
                         'metric is C^0-inextendible there (Sbierski), so the records end and there is no room to fill. At weak null '
                         'singularities inside rotating or charged black holes the metric continues continuously, but generically no '
                         'extension has square-integrable Christoffel symbols (Christodoulou\'s formulation; proved in spherical '
                         'Einstein-Maxwell-scalar models, conjectured for Kerr), so no weak form exists in which balance could act: '
                         'the HC situation. Thin shells and impulsive waves are regular in the sense of Geroch and Traschen, and GR '
                         'continues them uniquely: the HB situation.',
                   status='computed; classification IMPORTED (Sbierski 2018; Dafermos-Luk; Christodoulou; Geroch-Traschen 1987)',
                   kasner_exponents=[str(p) for p in ps], radial_tide_M1=tidal)


def HE():
    # a nonzero kappa is a surface source: flux jump [p] = kappa C. Express as an equivalent shell density in the toy:
    # (a^2 y')' = kappa y(0) delta. With no recorded source, balance fails by exactly kappa C.
    C = 0.8; ledger = {k: k * C for k in (-1.0, 0.0, 0.7, 1.0)}
    ok = ledger[0.0] == 0 and all(abs(v) > 0 for k, v in ledger.items() if k != 0)
    must(ok, 'HE')
    R['HE'] = dict(claim='What a nonzero kappa costs. The flux jumps by kappa C at the interface, so the record ledger must contain a '
                         'source of exactly that size there. If it does not, balance fails; if it does, the source is matter at the '
                         'interface and GR already describes it (Israel). No assignment of kappa is both source-free and different '
                         'from GR. Canary: kappa = 0 has an empty ledger.',
                   status='PROVED', flux_jump_for_C_0_8={str(k): fl(v) for k, v in ledger.items()})


if __name__ == '__main__':
    for name, fn in (('HA', HA), ('HB', HB), ('HC', HC), ('HD', HD), ('HE', HE)):
        fn(); print(name, flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(open(os.path.abspath(__file__), 'rb').read()).hexdigest()
    json.dump(out, open(os.path.join(HERE, 'rg_hidden_room_attack_results.json'), 'w'), indent=1, sort_keys=True)
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
