#!/usr/bin/env python3
"""Singular-boundary hidden-room attack. Synthetic Jacobi model, NOT a new GR solution.
Requires numpy, scipy. Run python rg_singular_boundary_attack.py
Outputs JSON beside this file. No external data or network access.
"""
import json
from pathlib import Path
import numpy as np
from scipy.integrate import quad, solve_ivp
OUT=Path(__file__).resolve().parent
Q=.6
B=.4
T=1.
def a(t,e=0.):
    if e==0: return 1+B*abs(t)**Q
    return 1+B*((t*t+e*e)**(Q/2)-e**Q)
def ap(t,e=0.):
    if e==0: return B*Q*np.sign(t)*abs(t)**(Q-1)
    return B*Q*t*(t*t+e*e)**(Q/2-1)
def app(t,e=0.):
    if e==0: return B*Q*(Q-1)*abs(t)**(Q-2)
    return B*Q*(t*t+e*e)**(Q/2-2)*(e*e+(Q-1)*t*t)
def J(t,e=0.):
    if t==0:return 0.
    return np.sign(t)*quad(lambda s:1/a(s,e)**2,0,abs(t),epsabs=1e-11,epsrel=1e-11,limit=250)[0]
def F(t,e=0.):
    aa=a(t,e); v=ap(t,e); jj=J(t,e)
    return np.array([[aa,aa*jj],[v,v*jj+1/aa]])
def K(k):return np.array([[1.,0.],[k,1.]])
def transfer(k,e=0.):return F(T,e)@K(k)@np.linalg.inv(F(-T,e))
def x(t,C,D,k=0.,e=0.):return a(t,e)*(C+(D+(k*C if t>=0 else 0))*J(t,e))
def momentum(t,C,D,k=0.):return D+(k*C if t>=0 else 0)
def safe(o):
    if isinstance(o,np.bool_):return bool(o)
    if isinstance(o,np.integer):return int(o)
    if isinstance(o,np.floating):return float(o)
    raise TypeError(type(o).__name__)
def main():
    rng=np.random.default_rng(63179)
    ks=[-1.,0.,1.]
    # Identical punctured Jacobi coefficient E=-a''/a for every k.
    # q<1 => divergent ordinary velocity but finite x and renormalized momentum.
    approach=[]
    for t in [1e-2,1e-4,1e-6,1e-8]:
        C,D=1.,.2
        xx=x(t,C,D)
        vv=ap(t)*(C+D*J(t))+D/a(t)
        approach.append({'t':t,'x':xx,'ordinary_velocity':vv,'renormalized_momentum':a(t)*vv-ap(t)*xx,'tidal_E':-app(t)/a(t)})
    # Check exact solution away from interface using analytic derivatives.
    residual=[]
    for k in ks:
        for t in np.r_[-np.geomspace(1e-3,1,30),np.geomspace(1e-3,1,30)]:
            C,D=.7,-.3; De=D+(k*C if t>0 else 0)
            aa=a(t); av=ap(t); jj=J(t)
            # x'' = a''(C+D J)+2a'D/a^2 + a D*(-2a'/a^3)
            xpp=app(t)*(C+De*jj)+2*av*De/aa**2-2*av*De/aa**2
            residual.append(abs(xpp-app(t)/aa*x(t,C,D,k))/max(1,abs(xpp)))
    Omega=np.array([[0.,1.],[-1.,0.]])
    symplectic=max(float(np.linalg.norm(transfer(k).T@Omega@transfer(k)-Omega)) for k in ks)
    compose=float(np.linalg.norm(K(.3)@K(-.8)-K(-.5)))
    # Training-only records on t<0 cannot identify k. Identical C,D fixed before boundary.
    C,D=.8,.15
    train=np.linspace(-1,-.01,80)
    training_gap=max(float(np.max(np.abs([x(t,C,D,k)-x(t,C,D,0) for t in train]))) for k in ks)
    futures={str(k):x(T,C,D,k) for k in ks}
    # Blind conditional predictor: x_k-x_0 = k a(t)J(t) C.
    pred_errors=[]
    for _ in range(120):
        c,d=rng.normal(size=2); k=rng.uniform(-2,2); t=rng.uniform(.01,1)
        pred_errors.append(abs((x(t,c,d,k)-x(t,c,d,0))-k*a(t)*J(t)*c))
    # Independent shell record p_plus-p_minus=k C fixes k when C !=0.
    inferred=(momentum(.01,C,D,.7)-momentum(-.01,C,D,.7))/C
    # Smooth metric regularization: no interface shell selects k=0 in this family.
    convergence=[]
    for e in [1e-2,1e-3,1e-4,1e-5,1e-6]:
        convergence.append({'epsilon':e,'no_shell_error':float(np.linalg.norm(transfer(0,e)-transfer(0))),
          'shell_k1_error':float(np.linalg.norm(transfer(1,e)-transfer(1))),
          'a_uniform_error_bound':B*e**Q})
    # All k pass weak record gates, so these gates cannot select a dynamics.
    finite_positions=all(np.isfinite(x(t,1,.2,k)) for k in ks for t in [0,1e-10,1])
    # Mutation checks use fixed identities, not external source-mutation harness.
    bad=np.diag([2.,1.])
    controls={
      'nonsymplectic_map_rejected':np.linalg.norm(bad.T@Omega@bad-Omega)>.1,
      'wrong_sign_prediction_rejected':abs((x(1,C,D,1)-x(1,C,D,0))+a(1)*J(1)*C)>.1,
      'false_unique_continuation_rejected':abs(futures['1.0']-futures['0.0'])>.1,
      'zero_boundary_displacement_hides_k':abs(x(1,0,D,1)-x(1,0,D,-1))<1e-12,
      'smooth_no_shell_is_not_all_extensions':np.linalg.norm(transfer(1)-transfer(0))>.1}
    independent=[]
    for e in [.02,.01,.005]:
        def rhs(t,z):
            Z=z.reshape(2,2)
            return (np.array([[0.,1.],[app(t,e)/a(t,e),0.]])@Z).ravel()
        sol=solve_ivp(rhs,[-T,T],np.eye(2).ravel(),rtol=1e-10,atol=1e-11,max_step=e/3)
        independent.append({'epsilon':e,'success':bool(sol.success),'transfer_error':float(np.linalg.norm(sol.y[:,-1].reshape(2,2)-transfer(0,e)))})
    gates={
      'punctured_equation':max(residual)<1e-10,
      'finite_record':finite_positions,
      'symplectic':symplectic<1e-11,
      'composition':compose<1e-12,
      'identical_past':training_gap==0,
      'different_futures':abs(futures['1.0']-futures['-1.0'])>.5,
      'conditional_predictor':max(pred_errors)<1e-12,
      'interface_identification':abs(inferred-.7)<1e-12,
      'regularization_converges':convergence[-1]['no_shell_error']<convergence[0]['no_shell_error']/20,
      'attack_controls':all(controls.values()),
      'independent_ode':all(z['success'] and z['transfer_error']<1e-7 for z in independent)}
    R={'model':'x_double_prime=(a_double_prime/a)x away from t=0; a=1+0.4|t|^0.6',
      'scope':'One-dimensional Jacobi toy; not a verified spacetime extension or full Einstein solution.',
      'interface':'x_plus=x_minus=C; p_plus=p_minus+kappa*C; p=a*x_prime-a_prime*x',
      'seed':63179,'approach':approach,'max_equation_residual':max(residual),
      'symplectic_error':symplectic,'training_gap':training_gap,'future_records':futures,
      'max_conditional_prediction_error':max(pred_errors),'identified_kappa':inferred,
      'independent_ode':independent,'regularization':convergence,'controls':controls,'gates':gates,'all_pass':all(gates.values()),
      'novel_dynamics_locked':False,
      'reason':'Weak record gates admit all kappa. kappa!=0 adds interface data; smooth metric Jacobi regularization without shell selects zero in this model.'}
    (OUT/'rg_singular_boundary_results.json').write_text(json.dumps(R,indent=2,default=safe))
    print(json.dumps(R,indent=2,default=safe))
    return R
if __name__=='__main__':
    r=main();raise SystemExit(0 if r['all_pass'] else 1)
