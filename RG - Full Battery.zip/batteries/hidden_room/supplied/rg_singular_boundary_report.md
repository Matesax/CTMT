# RG singular-boundary hidden-room attack

## Status
Synthetic scalar Jacobi model. Not a Kerr calculation, not a constructed full Einstein solution, and not a novel physical law. No external literature was retrieved or verified. The supplied a_room.py was inspected but not executed: it requires common.py and a Node harness not supplied here.

## Exact model and theorem
Let a(t)=1+0.4 |t|^0.6. It is positive and continuous; a' and a'' diverge at zero. Away from zero, consider x''=(a''/a)x. Put y=x/a and p=a*x'-a'*x=a^2*y'. Then p'=0 and y'=p/a^2 on either side. Write J(t)=integral_0^t a(s)^(-2) ds. All solutions have x=a(C+D J) on each side.

Requiring continuity of x, a linear interface map, and preservation of the two-dimensional symplectic form forces the interface map to be (C,D)->(C,D+kappa*C). Proof: continuity fixes the first row to (1,0); determinant one fixes the second diagonal entry to one. The remaining lower-left entry kappa is arbitrary. This theorem classifies ONLY this scalar, linear, continuous-position, symplectic interface class, not all possible singular continuations.

Thus finite position, linearity, symplecticity and interface composition do not select kappa. Every pre-interface record is identical for fixed C,D. Future records differ by Delta x(t)=kappa*a(t)*J(t)*C. At C=0 the parameter is invisible to this probe.

## Source-free completion theorem
For the transformed equation (a^2 y')'=0 understood weakly across zero, p is constant and kappa=0. This equation is well defined for continuous positive a using its divergence form, without forming the singular product (a''/a)x at zero.

If positive smooth a_e converge uniformly to a and have a common lower bound m>0, then 1/a_e^2 converges uniformly to 1/a^2, and the canonical transfers converge. Specifically |J_e(t)-J(t)| <= 2 |t| ||a_e-a||_infinity / m^3. Therefore all such source-free regularizations select the same canonical continuation. Endpoint physical (x,x') transfer convergence additionally requires endpoint a_e' convergence. The numerical family has that property.

For nonzero kappa the transformed equation instead is (a^2 y')'=kappa*y(0)*delta_0. It introduces an interface source, or equivalently a boundary action term kappa*y(0)^2/2 in addition to the bulk action integral a^2*y'^2/2. It is not a second source-free solution of the same weak equation.

## What the battery checks
Punctured equation, finite positions with divergent ordinary velocity, symplectic transfer, additive composition K(k1)K(k2)=K(k1+k2), identical past/different futures, exact conditional predictor, recovery from a boundary momentum record, regularization convergence, independent solve_ivp integration for smooth cases, and five invariant attack/negative controls. The analytic equation residual is an identity check; the solve_ivp comparison is an independent numerical integration check. No source-code mutation harness is claimed.

## Relevance and limits
The hidden room is continuation data. Without a selection law, it yields a correspondence, not a unique prediction. With source-free divergence-form closure, it yields kappa=0 and an exact predictor, but no deviation from the chosen geometric completion. A nonzero prediction needs an independently justified interface source law. This does not establish the existence of a gravitational shell compatible with the Einstein constraints, energy conditions, or any chosen synthetic Ricci bound.

A causal order and clock records alone do not automatically meet all Lorentzian pre-length-space axioms. A Fisher determinant identity alone does not establish an optimal-transport formulation of Einstein's equation. Neither identification was proved here.

Run python rg_singular_boundary_attack.py. Requires NumPy and SciPy. See JSON for seed, all numerical values, and gate outcomes.
