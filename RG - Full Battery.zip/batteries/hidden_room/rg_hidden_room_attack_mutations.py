#!/usr/bin/env python3
"""Mutation suite for rg_hidden_room_attack.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. Under one minute.

    python3 -I rg_hidden_room_attack_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('HB', 'the jump of the flux given the wrong sign', "ypp = lambda t, k=kappa: (D + k * C) / a(t) ** 2", "ypp = lambda t, k=kappa: (D - k * C) / a(t) ** 2"),
    ('HC', 'a degenerate crash presented with a nonzero weight at the crash', "a_dg = lambda t: abs(t) ** Q", "a_dg = lambda t: 0.1 + abs(t) ** Q"),
    ('HD', 'the angular scale given the wrong power of the proper time', "tau_of_r = sp.integrate(1 / sp.sqrt(2 * M / r), (r, 0, r))", "tau_of_r = sp.integrate(1 / sp.sqrt(2 * M), (r, 0, r))"),
    ('HE', 'a nonzero interface source claimed source-free', "ok = ledger[0.0] == 0 and all(abs(v) > 0 for k, v in ledger.items() if k != 0)", "ok = ledger[0.7] == 0 and all(abs(v) > 0 for k, v in ledger.items() if k != 0)"),
]


def main():
    base = open(os.path.join(HERE, 'rg_hidden_room_attack.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_hidden_room_attack.py'), 'w').write(base.replace(old, new))
            shutil.copytree(os.path.join(HERE, 'supplied'), os.path.join(tmp, 'supplied'))
            run = subprocess.run([sys.executable, '-I', 'rg_hidden_room_attack.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_hidden_room_attack_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
