# RG – Hidden Room at GR Crashes: can RG fill the continuation room with a law that differs from GR?

**Verdict: no novelty locks.** The room is real: where GR's equation stops, continuous records can survive, and the continuation is not fixed by records, linearity, symplecticity or composition (the supplied κ family). But RG's own balance principle either fills the room exactly as GR's weak continuation does, or cannot act at all. There is no crash type where RG selects a continuation that GR does not. The novelty print was not built, because its condition failed.

Battery: `rg_hidden_room_attack.py`, 5 groups (HA–HE), each with a canary; byte-identical on rerun; 4/4 mutations caught by the battery's own checks (crashes counted as defects). The supplied programme, results and report are under `supplied/` and are reproduced (HA).

## The three kinds of crash

| Kind | What happens to the room | GR example | Group |
|---|---|---|---|
| Regular enough for a weak form (weight bounded away from zero) | The weak equation (a²y′)′ = 0 is flux conservation. Its residual for the κ family is exactly −κ C φ(0) (matched to 10⁻⁹), so κ ≠ 0 is a source sitting at the interface. Balance admits no source without a record, so κ = 0, which is GR's own weak continuation. With matter recorded there, the jump is fixed by that matter: Israel's junction condition | thin shells, impulsive waves (Geroch–Traschen regular metrics) | HB, HE |
| Degenerate (weight vanishes at the crash) | Records collapse: every state has x → 0, and states differing in C agree to 3×10⁻⁴ by t = 10⁻⁶. A jump of C has zero weak residual, so it passes the weak equation and balance. The continuation is a correspondence that no principle fills, and RG abstains. Canary: the same jump in the nondegenerate case has residual 1.3 and is rejected | Schwarzschild r → 0: Kasner exponents (−1/3, 2/3, 2/3) computed symbolically; C⁰-inextendible (Sbierski), so the records end | HC, HD |
| Continuous metric, but no square-integrable Christoffel symbols | No weak form exists in which balance could act: the HC situation. The continuation is not determined by the data | weak null singularities inside charged and rotating black holes: C⁰-extendible (Dafermos–Luk), generically without L² Christoffel symbols (Christodoulou's formulation; proved in spherical Einstein–Maxwell–scalar models, conjectured for Kerr) | HD |

## Why nothing is left over

Every κ ≠ 0 is a flux jump of exactly κC (HE). Either the record ledger contains a source of that size at the interface, and then it is matter that GR already describes, or it does not, and then balance fails. No assignment of κ is both source-free and different from GR. Where balance cannot be stated, no RG principle selects a branch, so RG returns a correspondence: an abstention, not a prediction.

## What a novelty claim would need

A law for the interface response that comes from somewhere other than balance: for example, hidden dynamics with its own records, whose effective κ is fixed, survives admissible coarse-graining, and satisfies the gravitational constraints. The supplied report says the same. RG's present principles do not contain such a law.

## Sources

- J. Sbierski, The C⁰-inextendibility of the Schwarzschild spacetime and the spacelike diameter in Lorentzian geometry, J. Differential Geom. 108 (2018) 319; arXiv:1507.00601.
- M. Dafermos, J. Luk, The interior of dynamical vacuum black holes I: The C⁰-stability of the Kerr Cauchy horizon, Ann. of Math. 202 (2025); arXiv:1710.01722.
- M. Dafermos, strong cosmic censorship overview (formulations and status), Princeton research page.
- P. Cameron, J. Sbierski, Spherically symmetric inextendibility of weak null singularities with Christoffel symbols in L^s_loc, arXiv:2609.05167 (2026).
- R. Geroch, J. Traschen, Strings and other distributional sources in general relativity, Phys. Rev. D 36 (1987) 1017.
- W. Israel, Singular hypersurfaces and thin shells in general relativity, Nuovo Cimento B 44 (1966) 1.
