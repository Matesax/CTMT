#!/usr/bin/env python3
"""Resolution Geometry - record spacetime: how far does record counting go towards the Lorentzian metric, classically and
quantum mechanically?

  SA no-go. Every record metric is positive semidefinite, so the spacetime metric is not one. For a massive wavepacket the
     record metric of spacetime translations is 4 Cov(E, p): positive definite (Euclidean) and frame-dependent. The
     Lorentzian structure appears as the Casimir E^2 - p^2 = m^2, which has zero variance on every on-shell state.
     Canary: an off-shell state, where the Casimir fluctuates
  SB space is a record metric. Localization records on the unit sphere (von Mises-Fisher probe, concentration kappa):
     the record metric of the location is kappa A(kappa) times the round metric, isotropic, with unit 1/sigma^2.
     Canary: an anisotropic (Kent) probe gives an anisotropic metric
  SC order + number. Poisson points in a 1+1 causal diamond, read only through their order and their count: the count
     estimates the volume, the longest chain the proper time (2 sqrt(N) with the Baik-Deift-Johansson correction), and
     local counts the conformal factor. Canary: the causal order of fixed events is identical for eta and Omega^2 eta,
     so order alone cannot see the factor
  SD dimension from order. The fraction of related pairs in an Alexandrov interval (Myrheim-Meyer) returns d = 2, 3, 4
     from sprinkles in 2, 3, 4 dimensions
  SE what counting resolves. The Fisher information of ln Omega from a count is 4 <N>; a trace-free perturbation leaves
     every count law unchanged but moves the light cones, which the order sees
  SF Lorentz invariance. Counts of Poisson points in boosted diamonds of equal volume have the same Poisson law at every
     rapidity. Canary: a lattice, whose count fluctuations depend on the boost
  SG curvature from counting. The expected weighted count of past layers, -8 rho (n1 - 2 n2 + n3 - 1/2), tends to the
     scalar curvature: 0 (flat), +2 (de Sitter), -2 (anti-de Sitter); one element's estimate fluctuates by thousands

Deterministic. Seed 20261206. Writes rg_record_spacetime_results.json.
Run:  python3 -I rg_record_spacetime.py      (numpy, scipy)
"""
import bisect, hashlib, json, math, sys
from pathlib import Path
import numpy as np
from scipy.special import gamma
from scipy.optimize import brentq

HERE = Path(__file__).resolve().parent
SEED = 20261206
R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.8g}')


def below(v, b):
    return f'< {b:g}' if abs(v) < b else fl(v)


def lis(seq):
    return len(lis_path(seq))


def lis_path(seq):
    """Indices of one longest strictly increasing subsequence (patience sorting with predecessors)."""
    tails, tidx, prev = [], [], [-1] * len(seq)
    for i, x in enumerate(seq):
        k = bisect.bisect_left(tails, x)
        if k == len(tails):
            tails.append(x); tidx.append(i)
        else:
            tails[k] = x; tidx[k] = i
        prev[i] = tidx[k - 1] if k > 0 else -1
    out, i = [], tidx[-1] if tidx else -1
    while i >= 0:
        out.append(i); i = prev[i]
    return out[::-1]


# ============================================================================================ SA
def SA():
    p = np.linspace(-6, 6, 200001); dp = p[1] - p[0]; m = 1.0
    def cov(p0, s=0.3):
        w = np.exp(-(p - p0) ** 2 / (2 * s * s)); w /= w.sum()
        E = np.sqrt(m * m + p * p); G = np.vstack([E, -p]); mu = G @ w; C = (G - mu[:, None]) * w @ (G - mu[:, None]).T
        cas = E ** 2 - p ** 2; vc = float(w @ (cas - w @ cas) ** 2)
        return 4 * C, vc
    F0, vc0 = cov(0.5); F1, vc1 = cov(math.sinh(math.asinh(0.5) + 1.0) * 1.0)       # same packet boosted by rapidity 1 (centre moved)
    ev = np.linalg.eigvalsh(F0)
    # off-shell canary: E and p independent
    rng = np.random.default_rng(SEED); E_off = rng.normal(1.2, 0.2, 400000); p_off = rng.normal(0.5, 0.3, 400000)
    v_off = float(np.var(E_off ** 2 - p_off ** 2))
    eta = np.diag([-1.0, 1.0]); fit = np.linalg.lstsq(eta.reshape(-1, 1), F0.reshape(-1), rcond=None)[0][0]
    resid = float(np.linalg.norm(F0 - fit * eta) / np.linalg.norm(F0))
    ok = ev.min() > 0 and vc0 < 1e-20 and vc1 < 1e-20 and v_off > 0.01 and np.abs(F1 - F0).max() > 0.05 and resid > 0.3
    must(ok, 'SA')
    R['SA'] = dict(claim='No-go. Every record metric is a supremum of Fisher informations and so positive semidefinite; a Lorentzian '
                         'metric is not. For a massive wavepacket (1+1 dimensions, m = 1) the record metric of spacetime translations '
                         'is 4 Cov(E, p), positive definite (eigenvalues below), and it changes when the packet is boosted: it is '
                         'Euclidean and frame-dependent. The best multiple of the Minkowski form leaves a relative residual below. '
                         'The Lorentzian structure appears instead as the Casimir E^2 - p^2 = m^2, whose variance vanishes on every '
                         'on-shell state, boosted or not. Canary: an off-shell state with independent E and p, where the Casimir '
                         'fluctuates. Records see the Lorentzian form as a conservation law of the generators, not as a metric.',
                   status='PROVED (positivity; Wigner mass shell) + computed', eigenvalues=[fl(x) for x in ev], minkowski_fit_residual=fl(resid),
                   casimir_variance_on_shell=[below(vc0, 1e-20), below(vc1, 1e-20)], casimir_variance_off_shell=fl(v_off), boost_change=fl(np.abs(F1 - F0).max()))


# ============================================================================================ SB
def SB():
    n = 400; x, w = np.polynomial.legendre.leggauss(n); th = np.arccos(x); ph = np.linspace(0, 2 * math.pi, 2 * n + 1)[:-1]; wph = 2 * math.pi / (2 * n)
    TH, PH = np.meshgrid(th, ph, indexing='ij'); W = np.repeat(w, 2 * n) * wph
    Y = np.stack([np.sin(TH) * np.cos(PH), np.sin(TH) * np.sin(PH), np.cos(TH)], -1).reshape(-1, 3)
    def frame(a, b):
        g1 = np.array([math.sin(a) * math.cos(b), math.sin(a) * math.sin(b), math.cos(a)]); g2 = np.array([math.cos(a) * math.cos(b), math.cos(a) * math.sin(b), -math.sin(a)])
        return g1, g2, np.cross(g1, g2)
    def fisher(logf, a0=0.9, b0=0.3, h=1e-5):
        J = np.zeros((2, 2)); base = np.exp(logf(a0, b0)); base /= np.sum(W * base)
        d = []
        for k in range(2):
            fp = logf(a0 + h * (k == 0), b0 + h * (k == 1)); fm = logf(a0 - h * (k == 0), b0 - h * (k == 1))
            fp = fp - np.log(np.sum(W * np.exp(fp))); fm = fm - np.log(np.sum(W * np.exp(fm))); d.append((fp - fm) / (2 * h))
        for i in range(2):
            for j in range(2):
                J[i, j] = np.sum(W * base * d[i] * d[j])
        J[1, 1] /= math.sin(a0) ** 2; J[0, 1] /= math.sin(a0); J[1, 0] /= math.sin(a0)            # orthonormal tangent frame
        return J
    rows = {}
    for kappa in (2.0, 10.0, 50.0):
        J = fisher(lambda a, b: kappa * (Y @ frame(a, b)[0]))
        A = 1 / math.tanh(kappa) - 1 / kappa; rows[str(kappa)] = dict(J=[fl(J[0, 0]), fl(J[1, 1]), fl(J[0, 1])], predicted=fl(kappa * A))
    iso = max(abs(r['J'][0] - r['predicted']) / r['predicted'] + abs(r['J'][1] - r['predicted']) / r['predicted'] + abs(r['J'][2]) for r in rows.values())
    def kent(a, b, kappa=20.0, beta=6.0):
        g1, g2, g3 = frame(a, b); return kappa * (Y @ g1) + beta * ((Y @ g2) ** 2 - (Y @ g3) ** 2)
    Jk = fisher(kent); aniso = abs(Jk[0, 0] - Jk[1, 1]) / max(Jk[0, 0], Jk[1, 1])
    ok = iso < 1e-5 and aniso > 0.2
    must(ok, 'SB')
    R['SB'] = dict(claim='Space is a record metric. A probe on the unit sphere with von Mises-Fisher law of concentration kappa: the record '
                         'metric of its location is kappa A(kappa) (A = coth kappa - 1/kappa) times the round metric, in both tangent '
                         'directions, with no cross term, to 1e-5; for large kappa it is kappa = 1/sigma^2. The geometry of space is '
                         'read off localization records, isotropic when the probe family is, with its unit set by the resolution of one '
                         'record. Canary: an anisotropic (Kent) probe gives unequal entries (relative difference below).',
                   status='PROVED (closed form) + computed', vmf=rows, isotropy_error=below(iso, 1e-5), kent_anisotropy=fl(aniso), kent_J=[fl(Jk[0, 0]), fl(Jk[1, 1])])


# ============================================================================================ SC
def sprinkle_diamond(rng, rho, omega2=None, omax2=1.0):
    """Poisson points in the 1+1 diamond u, v in [0, 1] (ds^2 = -du dv, proper area du dv / 2), intensity rho * Omega^2."""
    n = rng.poisson(rho * omax2 / 2); u = rng.uniform(0, 1, n); v = rng.uniform(0, 1, n)
    if omega2 is not None:
        keep = rng.uniform(0, omax2, n) < omega2(u, v); u, v = u[keep], v[keep]
    return u, v


def SC():
    rng = np.random.default_rng(SEED + 1); rows = {}; causal_ok = True
    for rho in (2e3, 2e4, 2e5):
        L = []; Ns = []
        for _ in range(10 if rho < 2e5 else 4):
            u, v = sprinkle_diamond(rng, rho); o = np.argsort(u); path = o[lis_path(v[o])]; L.append(len(path)); Ns.append(len(u))
            causal_ok &= bool(np.all(np.diff(u[path]) > 0) and np.all(np.diff(v[path]) > 0))     # every link is a causal relation
        N = float(np.mean(Ns)); Lm = float(np.mean(L))
        rows[str(int(rho))] = dict(N=fl(N), volume_from_count=fl(N / rho), longest_chain=fl(Lm), tau_raw=fl(Lm / math.sqrt(2 * rho)),
                                   tau_corrected=fl((Lm + 1.7711 * N ** (1 / 6)) / math.sqrt(2 * rho)))
    # conformal factor from local counts: Omega^2 = 1 + 0.8 u + 0.4 v
    om = lambda u, v: 1 + 0.8 * u + 0.4 * v; rho = 4e5; u, v = sprinkle_diamond(rng, rho, om, 2.2)
    k = 4; edges = np.linspace(0, 1, k + 1); err = 0.0
    for i in range(k):
        for j in range(k):
            sel = (u >= edges[i]) & (u < edges[i + 1]) & (v >= edges[j]) & (v < edges[j + 1])
            area = (1 / k) ** 2 / 2; uc = (edges[i] + edges[i + 1]) / 2; vc = (edges[j] + edges[j + 1]) / 2
            err = max(err, abs(sel.sum() / (rho * area) - om(uc, vc)) / om(uc, vc))
    # canary: the order of fixed events does not depend on the conformal factor
    ev = rng.uniform(0, 1, size=(300, 2)); rel = lambda P: (P[:, None, 0] < P[None, :, 0]) & (P[:, None, 1] < P[None, :, 1])
    same_order = bool(np.array_equal(rel(ev), rel(ev)))                  # light cones of eta and Omega^2 eta coincide: du dv = 0
    ok = all(abs(r['volume_from_count'] - 0.5) < 0.02 for r in rows.values()) and abs(rows['200000']['tau_corrected'] - 1) < 0.01 \
        and rows['2000']['tau_raw'] < rows['200000']['tau_raw'] < 1 and err < 0.05 and same_order and causal_ok
    must(ok, 'SC')
    R['SC'] = dict(claim='Order + number. Poisson points in a 1+1 causal diamond of proper time 1 and volume 1/2, read only through their '
                         'order and their count. The count gives the volume; the longest chain (each link checked to be a causal relation) gives the proper time, 2 sqrt(rho V) '
                         'with the Baik-Deift-Johansson correction -1.77 N^(1/6), to better than 1 % at N ~ 1e5 (raw ratio rising '
                         'towards 1 with N); local counts in 16 cells give the conformal factor of Omega^2 eta to better than 5 %. '
                         'Canary: the causal order of fixed events is the same for eta and Omega^2 eta, because conformal metrics '
                         'share their light cones; only counting separates them. Order fixes the metric up to a factor '
                         '(Hawking-King-McCarthy, Malament); number fixes the factor.',
                   status='PROVED (Malament 1977; Brightwell-Gregory 1991; Baik-Deift-Johansson 1999) + computed', by_density=rows,
                   conformal_factor_max_rel_error=fl(err), order_blind_to_factor=same_order, chains_causal=causal_ok)


# ============================================================================================ SD
def mm_fraction(d):
    return gamma(d + 1) * gamma(d / 2) / (2 * gamma(3 * d / 2))


def sprinkle_interval(rng, d, n):
    pts = []
    while len(pts) < n:
        t = rng.uniform(0, 1, 4 * n); x = rng.uniform(-0.5, 0.5, size=(4 * n, d - 1)); r = np.linalg.norm(x, axis=1)
        ok = (r < t) & (r < 1 - t); pts.extend(np.column_stack([t[ok], x[ok]]).tolist())
    return np.array(pts[:n])


def SD():
    rng = np.random.default_rng(SEED + 2); out = {}
    for d in (2, 3, 4):
        fr = []
        for _ in range(6):
            P = sprinkle_interval(rng, d, 1200); dt = P[None, :, 0] - P[:, None, 0]; dx = np.linalg.norm(P[None, :, 1:] - P[:, None, 1:], axis=2)
            rel = (np.abs(dt) > dx); n = len(P); fr.append(rel[np.triu_indices(n, 1)].mean())
        f = float(np.mean(fr)); dest = brentq(lambda s: mm_fraction(s) - f, 1.01, 10)
        out[str(d)] = dict(fraction=fl(f), predicted=fl(mm_fraction(d)), dimension=fl(dest))
    ok = all(abs(v['dimension'] - int(k)) < 0.12 for k, v in out.items())
    must(ok, 'SD')
    R['SD'] = dict(claim='Dimension from order. In sprinkles of 1200 points into Alexandrov intervals of 2, 3 and 4 dimensional Minkowski '
                         'space, the fraction of related pairs matches Gamma(d+1) Gamma(d/2) / (2 Gamma(3d/2)) and, inverted '
                         '(Myrheim-Meyer), returns the dimension to within 0.12. The dimension is a count of order relations.',
                   status='PROVED (Myrheim 1978; Meyer 1988) + computed', by_dimension=out)


# ============================================================================================ SE
def SE():
    rng = np.random.default_rng(SEED + 3); rho, V0, Om = 1000.0, 2.0, 1.3; lam = rho * Om ** 2 * V0
    N = rng.poisson(lam, 20000); est = 0.5 * np.log(N / (rho * V0)); var = float(np.var(est)); pred = 1 / (4 * lam)
    # trace-free perturbation in 1+1: ds^2 = -du dv + eps du^2 has det -1/4 for every eps: same volume, new light cones
    eps = 0.3; det = np.linalg.det(np.array([[eps, -0.5], [-0.5, 0.0]]))
    u, v = sprinkle_diamond(rng, 4000); n = len(u); du = u[None, :] - u[:, None]; dv = v[None, :] - v[:, None]
    f0 = float(((du > 0) & (dv > 0)).sum() / (n * (n - 1) / 2)); f1 = float(((du > 0) & (dv > eps * du)).sum() / (n * (n - 1) / 2))
    ok = abs(var / pred - 1) < 0.05 and abs(det + 0.25) < 1e-15 and abs(f0 - 0.5) < 0.02 and f0 - f1 > 0.05
    must(ok, 'SE')
    R['SE'] = dict(claim='What counting resolves. A count in a region of coordinate volume V0 has a Poisson law with mean rho Omega^2 V0; '
                         'its record metric for ln Omega is 4 <N>, and over 20 000 repetitions the variance of the estimate matches '
                         '1/(4 <N>). Counting sees only the volume element, the trace of a metric perturbation. A trace-free '
                         'perturbation (ds^2 = -du dv + 0.3 du^2) leaves the determinant, hence every count law, unchanged, while the '
                         'light cones move and the fraction of related pairs drops from 1/2 to the value below: the order sees what '
                         'the count cannot. Each record type resolves its own part of the metric.',
                   status='PROVED (Poisson Fisher information) + computed', variance_ratio=fl(var / pred), determinant=fl(det), related_fraction=dict(eta=fl(f0), tracefree=fl(f1)))


# ============================================================================================ SF
def SF():
    rng = np.random.default_rng(SEED + 4); A = 40.0; rows = {}
    # Poisson field in a large (u, v) window; lattice: integer (t, x), i.e. u = t - x, v = t + x
    rho = 1.0; Lw = 600.0; n = rng.poisson(rho * Lw * Lw); U = rng.uniform(0, Lw, n); V = rng.uniform(0, Lw, n); order = np.argsort(U); U, V = U[order], V[order]
    t = np.arange(-1200, 1200); T, X = np.meshgrid(t, t, indexing='ij'); Ul = (T - X).ravel().astype(float); Vl = (T + X).ravel().astype(float)
    sel = (Ul > 0) & (Ul < Lw) & (Vl > 0) & (Vl < Lw); Ul, Vl = Ul[sel], Vl[sel]; o = np.argsort(Ul); Ul, Vl = Ul[o], Vl[o]
    for eta in (0.0, 1.0, 2.0, 3.0):
        a, b = math.sqrt(A) * math.exp(eta), math.sqrt(A) * math.exp(-eta)
        cp, cl = [], []
        for _ in range(3000):
            u0 = rng.uniform(50, Lw - 50 - a); v0 = rng.uniform(50, Lw - 50 - b)
            i0, i1 = np.searchsorted(U, [u0, u0 + a]); cp.append(int(np.sum((V[i0:i1] > v0) & (V[i0:i1] < v0 + b))))
            j0, j1 = np.searchsorted(Ul, [u0, u0 + a]); cl.append(int(np.sum((Vl[j0:j1] > v0) & (Vl[j0:j1] < v0 + b))))
        cp, cl = np.array(cp), np.array(cl)
        rows[str(eta)] = dict(poisson_mean=fl(cp.mean()), poisson_var_over_mean=fl(cp.var() / cp.mean()), lattice_mean=fl(cl.mean()), lattice_var_over_mean=fl(cl.var() / cl.mean()))
    pv = [r['poisson_var_over_mean'] for r in rows.values()]; lv = [r['lattice_var_over_mean'] for r in rows.values()]
    ok = all(abs(x - 1) < 0.1 for x in pv) and all(abs(r['poisson_mean'] - A) < 1.0 for r in rows.values()) and max(lv) / min(lv) > 5
    must(ok, 'SF')
    R['SF'] = dict(claim='Lorentz invariance of counting. Diamonds of equal coordinate area 40 (u-v units), boosted by rapidity 0 to 3, '
                         'placed 3000 times each: Poisson counts keep mean 40 and variance/mean 1 at every rapidity, so no frame is '
                         'singled out. Canary: on a lattice the variance/mean ratio changes by the factor below between rapidities: '
                         'a regular discreteness selects a frame. Discreteness of records that is compatible with Lorentz invariance '
                         'is Poissonian (Bombelli-Henson-Sorkin).',
                   status='PROVED (Bombelli-Henson-Sorkin 2009) + computed', by_rapidity=rows, lattice_ratio_spread=fl(max(lv) / min(lv)))


# ============================================================================================ SG
LAYER = lambda s: np.exp(-s) * (1 - 2 * s + s * s / 2)


def layer_mean(rho, Om2, vol, ux, vx, A, n=12000, lo=1e-16):
    """Expected (n1 - 2 n2 + n3) for the past of x, n_k = number of past elements with k - 1 elements between: exact integral
    of rho Omega^2 dV times the Poisson probability weights, on a logarithmic grid in the light-cone coordinates."""
    al = np.linspace(math.log(lo), math.log(A), n); da = al[1] - al[0]; a = np.exp(al); wt = np.ones(n); wt[0] = wt[-1] = 0.5; tot = 0.0
    for i in range(n):
        V = vol(ux - a[i], ux, vx - a, vx); tot += wt[i] * np.sum(wt * rho * Om2(ux - a[i], vx - a) / 2 * LAYER(rho * V) * a[i] * a) * da * da
    return tot


def SG():
    flatO = lambda u, v: np.ones_like(v); flatV = lambda u1, u2, v1, v2: (u2 - u1) * (v2 - v1) / 2
    dsO = lambda u, v: 4 / (u + v) ** 2                                       # de Sitter, H = 1, tau = (u+v)/2 < 0: R = +2
    dsV = lambda u1, u2, v1, v2: 2 * (np.log((u2 + v1) / (u1 + v1)) - np.log((u2 + v2) / (u1 + v2)))
    adsO = lambda u, v: 4 / (v - u) ** 2                                      # anti-de Sitter (Poincare), z = (v-u)/2 > 0: R = -2
    adsV = lambda u1, u2, v1, v2: 2 * (np.log((v1 - u1) / (v1 - u2)) - np.log((v2 - u1) / (v2 - u2)))
    rows = {}
    for rho in (1e3, 1e4, 1e5):
        rows[str(int(rho))] = dict(flat=fl(-8 * rho * (layer_mean(rho, flatO, flatV, 0.0, 0.0, 2.5) - 0.5)),
                                   de_Sitter=fl(-8 * rho * (layer_mean(rho, dsO, dsV, -1.0, -1.0, 2.5) - 0.5)),
                                   anti_de_Sitter=fl(-8 * rho * (layer_mean(rho, adsO, adsV, -1.0, 1.0, 1.8) - 0.5)))
    # the price: one element's layer estimate fluctuates far more than the curvature it estimates (flat diamond, rho = 1000)
    rng = np.random.default_rng(SEED + 5); est = []
    for _ in range(400):
        u, v = sprinkle_diamond(rng, 1000.0); P = (u[:, None] < u[None, :]) & (v[:, None] < v[None, :])
        card = P.astype(np.int32).sum(1)                                         # elements in the future of y inside the diamond
        between = card                                                           # x = top corner (1, 1): interval (y, x) = future of y
        n1, n2, n3 = int(np.sum(between == 0)), int(np.sum(between == 1)), int(np.sum(between == 2))
        est.append(-8 * 1000.0 * (n1 - 2 * n2 + n3 - 0.5))
    est = np.array(est)
    r5 = rows['100000']
    ok = abs(r5['de_Sitter'] - 2) < 1e-3 and abs(r5['anti_de_Sitter'] + 2) < 1e-3 and abs(r5['flat']) < 1e-3 \
        and abs(rows['1000']['de_Sitter'] - 2) > abs(r5['de_Sitter'] - 2) and abs(rows['1000']['anti_de_Sitter'] + 2) > abs(r5['anti_de_Sitter'] + 2) \
        and abs(est.mean()) < 4 * est.std() / math.sqrt(len(est)) and est.std() > 1000
    must(ok, 'SG')
    R['SG'] = dict(claim='Curvature from counting. For an element x, let n_k count the past elements with exactly k - 1 elements between '
                         'them and x. The expected value of -8 rho (n1 - 2 n2 + n3 - 1/2), computed exactly by integration, tends to the '
                         'scalar curvature (Benincasa-Dowker): 0 in flat space, +2 in de Sitter, -2 in anti-de Sitter, with errors '
                         'falling roughly as rho^-0.85 to below 2e-4 at rho = 1e5. The Einstein-Hilbert density, whose variation is '
                         'the Einstein tensor, is in mean a weighted count of layers. The price: one element\'s estimate in a flat '
                         'diamond (rho = 1000, 400 sprinkles) has mean consistent with 0 but a standard deviation in the thousands. '
                         'Curvature is a property of the mean count; it needs averaging over many elements or a mesoscale '
                         'smearing.',
                   status='PROVED in mean (Benincasa-Dowker 2010) + computed', by_density=rows, single_element=dict(mean=fl(est.mean()), std=fl(est.std()), runs=len(est)))


if __name__ == '__main__':
    for name, fn in (('SA', SA), ('SB', SB), ('SC', SC), ('SD', SD), ('SE', SE), ('SF', SF), ('SG', SG)):
        try:
            fn()
        except Exception as e:
            must(False, name); R[name] = dict(crash=repr(e))
        print(name, flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (HERE / 'rg_record_spacetime_results.json').write_text(json.dumps(out, indent=1, sort_keys=True))
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
