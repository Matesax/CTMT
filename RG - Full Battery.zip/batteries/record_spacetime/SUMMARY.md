# RG – Record Spacetime: does record counting give the Lorentzian metric, and quantum gravity?

**Verdict, three parts.**
1. **The record metric does not give spacetime.** Every record metric is positive definite. For matter, the Lorentzian form appears only as a conservation law of the generators (the mass shell), never as a metric of records.
2. **Order and number do give it, from finitely many records, with explicit rates:**
   - volume, proper time, dimension and the conformal factor;
   - in mean, the scalar curvature, whose action varies to the Einstein tensor.

   This bridges the Realization premise of the GR derivation in the direction continuum → records. The converse (which finite record sets come from a continuum) stays open.
3. **Quantum gravity does not lock.** What records force is listed below. No dynamics for superposed geometries follows.

## What locks

| Group | Statement | Control |
|---|---|---|
| SA, no-go | Record metric of spacetime translations of a massive packet = 4 Cov(E, p): eigenvalues 0.007 and 0.423, Euclidean, changes under a boost. Best Minkowski fit leaves 87 % residual. Lorentzian structure = Casimir E² − p² = m², variance < 10⁻²⁰ on shell, boosted or not. | off-shell: Casimir variance 0.34 |
| SB, space | Localization records on the sphere: record metric κA(κ) × round metric, isotropic to 10⁻⁵ (κ = 2, 10, 50); unit 1/σ². | anisotropic Kent probe: 9.3 vs 29.8 |
| SC, order + number | 1+1 causal diamond read only by order and count: volume 0.500 from count; proper time from longest chain, 2√N with Baik–Deift–Johansson correction, 1.006 at N ≈ 10⁵ (raw 0.914 → 0.962 → 0.987); every chain link verified causal; conformal factor from local counts to 1.6 %. | order of fixed events identical for η and Ω²η: only counting sees the factor |
| SD, dimension | Myrheim–Meyer: fraction of related pairs gives d = 2.01, 2.98, 4.01 for sprinkles in 2, 3, 4 dimensions. | — |
| SE, what counting resolves | Fisher of ln Ω from a count = 4⟨N⟩ (variance ratio 1.013). Counting sees only the trace of a metric perturbation. A trace-free one leaves every count law unchanged and moves the light cones: the fraction of related pairs falls from 0.502 to 0.410. | determinant fixed at −1/4 |
| SF, Lorentz invariance | Poisson counts in boosted equal-volume diamonds: mean 40, variance/mean 0.95–1.04 at rapidity 0–3. | lattice: variance/mean from 0.23 to 44 (factor 196); a regular discreteness picks a frame |
| SG, curvature from counting | Expected −8ρ(n₁ − 2n₂ + n₃ − ½) over past layers → scalar curvature: flat 0; de Sitter 1.990 → 1.9986 → 1.9998; anti-de Sitter −2.015 → −2.002 → −2.0002 (ρ = 10³, 10⁴, 10⁵). The Einstein–Hilbert density is, in mean, a weighted count. | one element's estimate (flat, ρ = 1000): mean 1960, consistent with 0 at ±2400 standard error, but standard deviation 48 000 |

Battery: `rg_record_spacetime.py`, seed 20261206, 7 groups (SA–SG), each with a control. Byte-identical on rerun; 9 of 9 mutations caught.

The chain-length mutation survived at first. For independent uniform points, an unsorted longest increasing run has the same distribution as the true longest chain. The battery now reconstructs the chain and checks that every link is a causal relation.

## How this connects the two record theorems

- **Two kinds of record, one unit.** States are read statistically: the record metric, positive definite, quantum SLD. Spacetime is read structurally: causal order fixes the conformal class, and counting fixes the volume. In both, the unit is a count: one record or one element.
- **Each record type sees one part of the metric.** Counting sees the volume element (the trace part, with resolution δ ln Ω = 1/(2√N)). Order sees the light cones (the trace-free part). Neither alone is the metric.
- **Lorentz invariance constrains the discreteness.** If records are discrete and no frame is to be singled out, the discreteness must be Poissonian, not a lattice.
- **Dynamics.** Layer counts give R in mean. The GR derivation's unit lemma and balance then fix the response to αG_ab + Λg_ab. Every step from records to the field equation is now a count, a mean of counts, or a theorem about smooth natural laws.

## What does not lock

1. **The converse of realization.** Sprinkling a continuum gives records that reproduce its geometry, as above. Not every finite order with a count looks like a manifold; typical large orders (Kleitman–Rothschild) are three-layered and not manifold-like. Which record sets come from a continuum, and why physical ones do, needs a dynamics. The Realization premise is narrowed, not removed.
2. **Curvature only in mean.** A single element's layer count fluctuates by thousands of curvature units at ρ = 1000. Physical use needs averaging or a mesoscale smearing (a nonlocality scale), which is an additional parameter.
3. **Quantum gravity:**
   - The record metric of matter is quantum (SLD), and the Lorentzian form is its Casimir constraint. That is Wigner's classification, not quantum gravity.
   - Counting gives the geometry an intrinsic resolution: volume known to √N. Sorkin's argument turns this into Λ ~ V^(−1/2) in Planck units, about 10⁻¹²² for the observable universe. It needs volume and Λ to be conjugate (unimodular gravity) as an extra premise; it is a heuristic, prior art, and not tested here.
   - Superposed causal orders exist in the laboratory (the quantum switch). Their outcome records alone are known to satisfy causal inequalities, so device-independent records keep a definite order. That is cited, not simulated.
   - No sum over orders, and no quantum dynamics of geometry, follows from anything here.
4. **Prior art.** Every group is an established result of causal-set theory or measurement theory: Malament; Hawking–King–McCarthy; Myrheim; Meyer; Brightwell–Gregory; Baik–Deift–Johansson; Bombelli–Henson–Sorkin; Benincasa–Dowker; Wigner. RG contributes:
   - the no-go (SA);
   - reading both record theorems with one counting unit;
   - the placement of each piece against a premise of the GR derivation.

## Recommendation

This strengthens the existing GR derivation rather than making a new paper. Proposed: a section "From finitely many records" placed where the Realization premise currently stands, containing:
- SC–SG with their rates;
- the converse as the precise remaining limit;
- SA as the reason the record metric of states is not the spacetime metric.

Quantum gravity stays in the limits ledger, with the three forced statements above and no claimed dynamics.

## Sources

- D. B. Malament, J. Math. Phys. 18 (1977) 1399; S. W. Hawking, A. R. King, P. J. McCarthy, J. Math. Phys. 17 (1976) 174.
- J. Myrheim, CERN preprint TH-2538 (1978); D. A. Meyer, PhD thesis, MIT (1988).
- G. Brightwell, R. Gregory, Phys. Rev. Lett. 66 (1991) 260; J. Baik, P. Deift, K. Johansson, J. Amer. Math. Soc. 12 (1999) 1119.
- L. Bombelli, J. Henson, R. D. Sorkin, Mod. Phys. Lett. A 24 (2009) 2579.
- D. M. T. Benincasa, F. Dowker, Phys. Rev. Lett. 104 (2010) 181301.
- D. J. Kleitman, B. L. Rothschild, Trans. Amer. Math. Soc. 205 (1975) 205.
- M. Ahmed, S. Dodelson, P. B. Greene, R. Sorkin, Phys. Rev. D 69 (2004) 103523.
- M. Araújo et al., Witnessing causal nonseparability, New J. Phys. 17 (2015) 102001.
