#!/usr/bin/env python3
"""Mutation suite for rg_record_spacetime.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. A few minutes.

    python3 -I rg_record_spacetime_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('SA', 'Casimir with the Euclidean sign', "cas = E ** 2 - p ** 2;", "cas = E ** 2 + p ** 2;"),
    ('SB', 'von Mises-Fisher factor without its 1/kappa', "A = 1 / math.tanh(kappa) - 1 / kappa;", "A = 1 / math.tanh(kappa);"),
    ('SC', 'chain read without ordering by u', "o = np.argsort(u); path = o[lis_path(v[o])]", "o = np.arange(len(u)); path = o[lis_path(v[o])]"),
    ('SC', 'proper area of a cell without the factor 1/2', "area = (1 / k) ** 2 / 2;", "area = (1 / k) ** 2;"),
    ('SD', 'relation with a halved light cone', "rel = (np.abs(dt) > dx);", "rel = (np.abs(dt) > dx / 2);"),
    ('SE', 'perturbation that changes the volume', "det = np.linalg.det(np.array([[eps, -0.5], [-0.5, 0.0]]))", "det = np.linalg.det(np.array([[eps, -0.5], [-0.5, eps]]))"),
    ('SF', 'boosted diamond not volume-preserving', "a, b = math.sqrt(A) * math.exp(eta), math.sqrt(A) * math.exp(-eta)", "a, b = math.sqrt(A) * math.exp(eta), math.sqrt(A)"),
    ('SG', 'layer weights (1, -2, 1) replaced by (1, -2, 2)', "LAYER = lambda s: np.exp(-s) * (1 - 2 * s + s * s / 2)", "LAYER = lambda s: np.exp(-s) * (1 - 2 * s + s * s)"),
    ('SG', 'anti-de Sitter given the de Sitter volume', "anti_de_Sitter=fl(-8 * rho * (layer_mean(rho, adsO, adsV,", "anti_de_Sitter=fl(-8 * rho * (layer_mean(rho, adsO, dsV,"),
]


def main():
    base = open(os.path.join(HERE, 'rg_record_spacetime.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_record_spacetime.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_record_spacetime.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_record_spacetime_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
