#!/usr/bin/env python3
"""Mutation suite for rg_tower_attack.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. Under one minute.

    python3 -I rg_tower_attack_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('TA', 'a grid with a different upper rate', "rates = np.geomspace(1 / (30 * T) if lo is None else lo, 30, d)", "rates = np.geomspace(1 / (30 * T) if lo is None else lo, 40, d)"),
    ('TB', 'births claimed on a bank fixed at the largest horizon', "bank = {T: mindim(T, lo=1 / (30 * 2e5))", "bank = {T: mindim(T, lo=1 / (30 * T))"),
    ('TB', 'free rates frozen at the grid', "r = np.sort(np.exp(s.x)); e, c = fit(T, kern, r)", "r = np.sort(np.exp(x0)); e, c = fit(T, kern, r)"),
    ('TC', 'restriction of a completion fitted to a shorter horizon', "T2 = 200000.0; d2 = mindim(T2)", "T2 = 20.0; d2 = mindim(T2)"),
    ('TD', 'the grid budget presented as the number of hidden modes', "d_debye_free = freedim(T, debye)", "d_debye_free = mindim(T, debye)"),
    ('TE', 'rates transported with the wrong power of the scale', "At = np.exp(-np.outer(t, rates / s));", "At = np.exp(-np.outer(t, rates / s ** 1.01));"),
]


def main():
    base = open(os.path.join(HERE, 'rg_tower_attack.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_tower_attack.py'), 'w').write(base.replace(old, new))
            shutil.copytree(os.path.join(HERE, 'supplied'), os.path.join(tmp, 'supplied'))
            run = subprocess.run([sys.executable, '-I', 'rg_tower_attack.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_tower_attack_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
