# RG – Completion Tower: attack on the assumption-discovery programme

**Verdict: no novelty locks, and nothing here can be backed by measurement as a new physical statement.** The four surviving hypotheses fall into three kinds:
- **H1** (ordered mode births) is the rate grid filling up.
- **H2** (inherited spectrum) and **H5** (scale-covariant transport) are automatic: a restriction and a change of variables.
- **H4** (subadditive composition) uses an overlap that reports shared dynamics for mechanisms with nothing in common.

The programme also counts 37 hidden modes for a kernel that has exactly two. Its budgets measure the grid, not the system.

Battery: `rg_tower_attack.py`, 5 groups (TA–TE), each with a canary; byte-identical on rerun; 6/6 mutations caught by the battery's own failure reports, with crashes counted as defects. The supplied script and results are under `supplied/`, and all 90 supplied budgets and 9 births are recomputed exactly (TA).

## Hypothesis by hypothesis

| Hypothesis | Finding | Group |
|---|---|---|
| H1: discrete, geometric mode births; no mode death | The supplied grid puts d nodes over ln(900T). A fit passes once the node spacing ln(900T)/(d−1) falls below a threshold s. At the nine births s = 1.04–1.07, so births sit at T_d ≈ e^(s(d−1))/900, within a factor 1.4. The "walls" are the grid filling up. With free rates the budget is 3 at T = 10 and 4 from T = 100 to 10⁶: no births after T = 100, and 4 modes where the grid needs 20. On one bank fixed at the largest horizon the budget is 18 at every horizon: no births at all | TB |
| H2: one inherited relaxation spectrum across horizons | Automatic. The completion fitted at T = 2×10⁵ is a completion at every shorter horizon without a refit. In the supplied norm the optimal T = 100 completion serves every longer horizon unchanged: no pole is ever added, so inheritance holds trivially. In the pointwise relative norm, where the tail counts, freezing the six T = 100 poles and adding slow ones always succeeds. In this search it costs 3–6 poles over a refit (11/16/16 against 8/10/12), so minimal completions move their poles. In no norm can freeze-and-extend fail for a completely monotone kernel, so the proposed data test does not discriminate | TC |
| H4: subadditive composition; overlap I = d_a + d_b − d_ab reveals shared hidden dynamics | The overlap is 11–35 for a power law paired with two Debye processes or with a Kohlrausch relaxation, mechanisms with nothing in common. The test uses the pointwise product of kernels, which is not a composition of channels. For real compositions the inequality is automatic: in parallel (sum) the union of completions completes the sum; in series (convolution) the cascade has dimension d_a + d_b. The grid assigns 37 modes to the two-Debye kernel, which free rates recover as exactly 2 | TD |
| H5: scale-covariant transport λ ↦ λ/s | A change of variables. In a scale-invariant norm the transported completion has exactly the original error (difference below 10⁻¹⁴). The supplied 3–7×10⁻⁴ differences come from weighting by log(1+t). In measured data this is time–temperature superposition (Williams, Landel and Ferry 1955), and its failure is known as thermorheological complexity | TE |
| H3, H6 | Rejected by the supplied run itself; not re-attacked | — |

## Why the programme cannot reach measurable novelty

Every hypothesis is a property of a fitting protocol applied to a completely monotone kernel, not of the system producing the kernel. The object that is horizon-independent, scale-covariant under a shift factor and measured over many decades already exists: the continuous relaxation spectrum of linear response, with discrete Prony (generalized Maxwell) fits on fixed relaxation-time grids as standard practice. A new physical prediction would need a premise about the system that linear-response theory does not already contain. None of these hypotheses supplies one.

## Sources

- M. L. Williams, R. F. Landel, J. D. Ferry, The temperature dependence of relaxation mechanisms in amorphous polymers and other glass-forming liquids, J. Am. Chem. Soc. 77 (1955) 3701.
- N. W. Tschoegl, *The Phenomenological Theory of Linear Viscoelastic Behavior*, Springer, 1989 (continuous and discrete relaxation spectra).
- W. McLean, Exponential sum approximations for t^(−β), Springer, 2018; arXiv:1606.00123.
- D. Braess, W. Hackbusch, Approximation of 1/x by exponential sums in [1, ∞), IMA J. Numer. Anal. 25 (2005) 685.
