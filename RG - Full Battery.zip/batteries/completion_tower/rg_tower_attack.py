#!/usr/bin/env python3
"""RG - Completion Tower: hostile attack on the supplied assumption-discovery programme.

The supplied programme (supplied/rg_assumption_discovery.py) fits K(t) = (1 + t)^(-1.5) by nonnegative exponential
sums on the grid geomspace(1/(30T), 30, d), in a log-time weighted relative L2 norm, and reports four surviving
hypotheses: H1 ordered mode births, H2 an inherited spectrum, H4 subadditive composition, H5 scale-covariant transport.
Each group below carries a canary.

  TA reproduction of the 90 supplied budgets and the nine birth horizons
  TB H1 is the grid: births follow from the grid spacing alone, T_d = exp(s (d - 1))/900; with free rates the births
     stop; with a fixed bank they never happen
  TC H2 is automatic: any completion fitted to the longest horizon is a completion at every shorter one without a
     refit; optimal poles do move with the horizon; frozen short-horizon poles plus new slow poles always succeed for a
     completely monotone kernel, so the inheritance test cannot fail on the class it is posed for
  TD H4 does not detect shared dynamics: two physically unrelated mechanisms show the same overlap; series composition
     (convolution) and parallel composition (sum) obey d <= d_a + d_b for any channels, by construction
  TE H5 is a change of variables: in a scale-invariant norm the transported completion has exactly the original error;
     the supplied differences come from log(1 + t), which is not scale invariant

Deterministic. Seed 20261120 (no random draws). Writes rg_tower_attack_results.json.
Run:  python3 -I rg_tower_attack.py
"""
import hashlib, json, math, os, sys
import numpy as np
from scipy.optimize import least_squares, nnls

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 20261120
R, FAILS = {}, []
ALPHA, EPS = 1.5, 1e-3


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.6g}')


def below(v, b):
    return f'< {b:g}' if abs(v) < b else fl(v)


# ------------------------------------------------------------------------------------ the supplied construction
def grid(T, n=900):
    return np.r_[0., np.geomspace(1e-6, T, n - 1)]


def weights(t):
    w = np.ones_like(t); w[1:] = np.sqrt(np.gradient(np.log1p(t[1:]))); return w


def fit(T, y_of_t, rates):
    t = grid(T); y = y_of_t(t); w = weights(t); A = np.exp(-np.outer(t, rates)); c, _ = nnls(A * w[:, None], y * w, maxiter=20000)
    return float(np.linalg.norm((A @ c - y) * w) / np.linalg.norm(y * w)), c


K = lambda t, a=ALPHA: (1 + t) ** (-a)


def mindim(T, kern=K, lo=None, dmax=100):
    for d in range(1, dmax + 1):
        rates = np.geomspace(1 / (30 * T) if lo is None else lo, 30, d)
        if fit(T, kern, rates)[0] <= EPS:
            return d
    return dmax


def free(T, d, kern=K, x0=None):
    t = grid(T); y = kern(t); w = weights(t)
    x0 = np.log(np.geomspace(1 / (30 * T), 30, d)) if x0 is None else x0
    def res(x):
        A = np.exp(-np.outer(t, np.exp(x))) * w[:, None]; c, _ = nnls(A, y * w, maxiter=20000); return A @ c - y * w
    s = least_squares(res, x0, method='trf', bounds=(math.log(1e-9), math.log(1e4)), max_nfev=60 * len(x0), xtol=1e-10, ftol=1e-12)
    r = np.sort(np.exp(s.x)); e, c = fit(T, kern, r)
    return e, r, c


def freedim(T, kern=K, dmax=12):
    for d in range(1, dmax + 1):
        if free(T, d, kern)[0] <= EPS:
            return d
    return 99


# ================================================================================================ TA
def TA():
    sup = json.load(open(os.path.join(HERE, 'supplied', 'rg_assumption_discovery_results_as_supplied.json')))
    recs = sup['records']; ds = [mindim(r['T']) for r in recs]
    same = ds == [r['d'] for r in recs]
    births = sup['hypotheses'][0]['diagnostic']['births']
    ok = same and len(recs) == 90 and len(births) == 9
    must(ok, 'TA')
    R['TA'] = dict(claim='The 90 supplied budgets (alpha = 1.5, eps = 1e-3, T from 8 to 2e5) are recomputed exactly, with the nine '
                         'birth horizons 12.6 to 90 183.', status='computed', records=len(recs), match=bool(same), births=[[b[0], fl(b[1])] for b in births])
    return recs, births


# ================================================================================================ TB
def TB(births):
    # the grid has d nodes over ln(900 T); the fit passes once the node spacing ln(900 T)/(d - 1) is below a threshold s
    spacing_at_birth = [math.log(900 * T) / (d - 1) for d, T in births]
    s = float(np.mean(spacing_at_birth)); pred = [math.exp(s * (d - 1)) / 900 for d, _ in births]
    err = max(abs(math.log(p / T)) for p, (_, T) in zip(pred, births)); q = math.exp(s)
    # free rates: the budget stops growing
    Ts = [10, 100, 1000, 10000, 100000, 1000000]; fr = {T: freedim(T) for T in Ts}
    # a fixed bank spanning the largest horizon: no births at all
    bank = {T: mindim(T, lo=1 / (30 * 2e5)) for T in (30, 1000, 30000, 200000)}
    ok = err < 0.35 and max(spacing_at_birth) / min(spacing_at_birth) < 1.25 and fr[10000] == fr[100000] == fr[1000000] and fr[1000000] < 0.5 * mindim(1000000) \
        and max(bank.values()) - min(bank.values()) <= 1
    must(ok, 'TB')
    R['TB'] = dict(claim='H1 is the grid. The supplied grid puts d nodes over ln(900 T), so a fit passes once the spacing ln(900 T)/(d-1) '
                         'falls below a threshold s that depends on the kernel and eps. Births then follow at T_d = exp(s(d-1))/900, '
                         'a geometric sequence with ratio about e^s. At the nine supplied births the spacing is 0.96 to 1.15 '
                         '(mean 1.05, e^s = 2.9), and the formula with that one constant places every birth within a factor 1.4. '
                         'The ordered walls are the grid filling up. With '
                         'free rates the budget is the same at T = 1e4, 1e5 and 1e6 (no births after 1e4), and less than half '
                         'the grid budget at 1e6. On a fixed bank that spans the largest horizon, the budget is the same at every '
                         'horizon to within one mode: no births at all. Canary: the T-tied grid keeps adding modes.',
                   status='PROVED (spacing argument) + computed', spacing_threshold=fl(s), q=fl(q), spacing_at_births=[fl(x) for x in spacing_at_birth], worst_log_error_of_birth_formula=fl(err),
                   free_rate_budget={str(k): v for k, v in fr.items()}, grid_budget_1e6=mindim(1000000), fixed_bank_budget={str(k): v for k, v in bank.items()})


# ================================================================================================ TC
def TC():
    # (i) restriction: the completion fitted at T2 is a completion at T1 without any refit
    T2 = 200000.0; d2 = mindim(T2); rates = np.geomspace(1 / (30 * T2), 30, d2); _, c2 = fit(T2, K, rates)
    restr = {}
    for T1 in (10.0, 100.0, 1000.0, 10000.0):
        t = grid(T1); w = weights(t); y = K(t); restr[T1] = float(np.linalg.norm((np.exp(-np.outer(t, rates)) @ c2 - y) * w) / np.linalg.norm(y * w))
    # (ii) in the supplied norm the optimal short-horizon completion serves every longer horizon unchanged
    _, r_a, c_a = free(100.0, 4); _, r_b, c_b = free(10000.0, 4)
    shift = float(np.max(np.abs(np.log(r_a) - np.log(r_b))))
    # (iv) pointwise relative norm, where the tail counts: freeze the short-horizon poles, add slow poles only
    def rel_fit(T, r):
        t = np.geomspace(1e-4, T, 900); y = K(t); A = np.exp(-np.outer(t, r)) / y[:, None]; c, _ = nnls(A, np.ones_like(t), maxiter=20000)
        return float(np.max(np.abs(A @ c - 1))), c
    def rel_opt(T, r0, frozen=np.array([])):
        t = np.geomspace(1e-4, T, 900); y = K(t)
        def res(x):
            r = np.r_[frozen, np.exp(x)]; A = np.exp(-np.outer(t, r)) / y[:, None]; c, _ = nnls(A, np.ones_like(t), maxiter=20000); return A @ c - 1
        s_ = least_squares(res, np.log(r0), method='trf', bounds=(math.log(1e-9), math.log(1e4)), max_nfev=80 * len(r0), xtol=1e-10, ftol=1e-12)
        return rel_fit(T, np.r_[frozen, np.exp(s_.x)])[0], np.r_[frozen, np.exp(s_.x)]
    E2 = 1e-2
    def rel_min(T, frozen=np.array([])):
        for k in range(0 if len(frozen) else 1, 16):
            if k == 0:
                if rel_fit(T, frozen)[0] <= E2:
                    return 0, frozen
                continue
            e, r = rel_opt(T, np.geomspace(1 / (3 * T), 30 if not len(frozen) else max(1 / (3 * T) * 2, frozen.min() / 2), k), frozen)
            if e <= E2:
                return k, r
        return 99, None
    k100, r100 = rel_min(100.0)
    relinh = {}
    for T in (1000.0, 10000.0, 100000.0):
        k_new, _ = rel_min(T, r100); k_free, _ = rel_min(T); relinh[T] = dict(frozen=k100, added_slow_poles=k_new, unconstrained=k_free)
    # (iii) inheritance always succeeds: freeze the short-horizon poles, add slow poles only
    _, r_s, _ = free(100.0, freedim(100.0))
    def inherited(T, k):
        x_new = np.log(np.geomspace(1 / (30 * T), 1 / 100.0, k)) if k > 0 else np.array([])
        t = grid(T); y = K(t); w = weights(t)
        def res(x):
            r = np.r_[r_s, np.exp(x)]; A = np.exp(-np.outer(t, r)) * w[:, None]; c, _ = nnls(A, y * w, maxiter=20000); return A @ c - y * w
        if k == 0:
            return float(np.linalg.norm(res(np.array([]))) / np.linalg.norm(y * w))
        s = least_squares(res, x_new, method='trf', bounds=(math.log(1e-9), math.log(1e4)), max_nfev=200, xtol=1e-10, ftol=1e-12)
        return float(np.linalg.norm(res(s.x)) / np.linalg.norm(y * w))
    inh = {}
    for T in (1000.0, 10000.0, 100000.0):
        k = next((k for k in range(0, 6) if inherited(T, k) <= EPS), 99); inh[T] = dict(added_slow_poles=k, total=len(r_s) + k, unconstrained=freedim(T))
    grows = relinh[100000.0]['unconstrained'] > k100
    ok = max(restr.values()) <= EPS and shift < 0.1 and all(v['added_slow_poles'] == 0 for v in inh.values()) and grows \
        and all(v['added_slow_poles'] < 99 for v in relinh.values()) and min(v['frozen'] + v['added_slow_poles'] - v['unconstrained'] for v in relinh.values()) >= 2
    must(ok, 'TC')
    R['TC'] = dict(claim='H2 is automatic. (i) The completion fitted at T = 2e5 is, without any refit, a completion at T = 10, 100, '
                         '1000 and 1e4: restriction never fails, because the error on a shorter horizon is controlled by the error on '
                         'the longer one; one fixed bank for all horizons is then a consequence, not a constraint. (ii) In the '
                         'supplied norm the four-pole optimum at T = 100 and at T = 1e4 are the same poles to a log-shift of 0.03, '
                         'and (iii) the frozen T = 100 completion needs no new pole at all up to T = 1e5: the norm ignores the '
                         'tail, so inheritance is satisfied because nothing is ever added. (iv) In the pointwise relative norm '
                         '(eps = 1e-2), where the tail counts and the unconstrained budget grows (6 at T = 100; 8, 10, 12 at 1e3, '
                         '1e4, 1e5), freezing the six T = 100 poles and adding slow poles always succeeds, but needs 11, 16 and 16 '
                         'poles in this search: inheritance costs 3 to 6 poles over a refit, so minimal completions move their '
                         'poles (the overhead is found, not proved minimal). Freeze-and-extend therefore never fails for a '
                         'completely monotone kernel: in one norm it is free because nothing is added, in the other it is paid '
                         'for in modes. Either way it is a property of the fitting protocol, not of the system, and the proposed '
                         'test cannot fail on the class it is posed for. The horizon-independent object is the '
                         'continuous relaxation spectrum of linear response, which is standard; discrete poles of a fit are not '
                         'material constants.',
                   status='computed', restriction_error={str(k): fl(v) for k, v in restr.items()}, optimal_pole_log_shift=fl(shift),
                   poles_T100=[fl(x) for x in r_a], poles_T1e4=[fl(x) for x in r_b], inherited_supplied_norm={str(k): v for k, v in inh.items()},
                   inherited_relative_norm={str(k): v for k, v in relinh.items()})


# ================================================================================================ TD
def TD():
    T = 1000.0
    debye = lambda t: 0.5 * np.exp(-t) + 0.5 * np.exp(-t / 300.0)            # two Debye processes: an unrelated mechanism
    stretched = lambda t: np.exp(-(t / 30.0) ** 0.5)                          # Kohlrausch relaxation: another unrelated mechanism
    pairs = {'power law and power law (supplied)': (lambda t: K(t, 1.0), lambda t: K(t, 1.5)),
             'power law and two Debye processes': (lambda t: K(t, 1.0), debye),
             'power law and stretched exponential': (lambda t: K(t, 1.0), stretched)}
    over = {}
    for name, (fa, fb) in pairs.items():
        da, db = mindim(T, fa), mindim(T, fb); dab = mindim(T, lambda t, fa=fa, fb=fb: fa(t) * fb(t)); over[name] = dict(da=da, db=db, d_product=dab, overlap=da + db - dab)
    # parallel composition: the union of two completions completes the sum
    ra = np.geomspace(1 / (30 * T), 30, mindim(T, lambda t: K(t, 1.0))); rb = np.geomspace(1 / (30 * T), 30, mindim(T, debye))
    e_union = fit(T, lambda t: K(t, 1.0) + debye(t), np.r_[ra, rb])[0]
    d_debye_free = freedim(T, debye)
    ok = all(v['overlap'] > 0 for v in over.values()) and over['power law and two Debye processes']['overlap'] >= 2 and e_union <= EPS \
        and d_debye_free == 2 and over['power law and two Debye processes']['db'] > 10
    must(ok, 'TD')
    R['TD'] = dict(claim='H4 does not detect shared dynamics. The overlap d_a + d_b - d(K_a K_b) is positive for a power law paired '
                         'with two Debye processes and with a Kohlrausch relaxation, mechanisms with nothing in common, as it is for '
                         'two power laws. It measures that smooth kernels need similar budgets on one grid. The inequality itself is '
                         'automatic for the compositions a physicist would use: in parallel (sum of responses) the union of the '
                         'two completions completes the sum (checked), and in series (convolution) the cascade of two realizations '
                         'has dimension d_a + d_b. The pointwise product of two kernels, used in the supplied test, is not a '
                         'composition of channels. Canary: none of the overlaps is zero. A further defect: the supplied grid '
                         'assigns 37 hidden modes to the two Debye processes, which are exactly two modes (recovered with free '
                         'rates); budgets on that grid do not count hidden modes.',
                   status='computed; cascade dimension IMPORTED (realization theory)', overlaps=over, union_completes_sum_error=below(e_union, 1e-3), debye_pair_free_rate_budget=d_debye_free)


# ================================================================================================ TE
def TE():
    T = 1000.0; d = mindim(T); rates = np.geomspace(1 / (30 * T), 30, d)
    res = {}
    for s in (0.1, 0.3, 3.0, 10.0):
        u = np.r_[0., np.geomspace(1e-6, T, 899)]; t = s * u                    # the same sample points, rescaled
        w = np.ones_like(u); w[1:] = np.sqrt(np.gradient(np.log(u[1:])))      # log-measure: invariant under t -> s t
        A = np.exp(-np.outer(u, rates)); c, _ = nnls(A * w[:, None], K(u) * w, maxiter=20000)
        e0 = float(np.linalg.norm((A @ c - K(u)) * w) / np.linalg.norm(K(u) * w))
        At = np.exp(-np.outer(t, rates / s)); es = float(np.linalg.norm((At @ c - K(t / s)) * w) / np.linalg.norm(K(t / s) * w))
        res[s] = abs(es - e0)
    ok = max(res.values()) < 1e-14
    must(ok, 'TE')
    R['TE'] = dict(claim='H5 is a change of variables. With the samples and the weights carried along by t -> s t, the transported '
                         'completion (w_j, lambda_j/s) of K(t/s) has exactly the error of the original completion of K(t), to '
                         'rounding. The supplied differences (3e-4 to 7e-4) come from weighting by log(1 + t), which is not '
                         'invariant under rescaling. In measured data the same statement is time-temperature superposition '
                         '(Williams, Landel and Ferry 1955), and its failure is known as thermorheological complexity.',
                   status='PROVED (substitution); IDENTIFIED (time-temperature superposition)', error_difference={str(k): below(v, 1e-14) for k, v in res.items()})


if __name__ == '__main__':
    recs, births = TA(); print('TA', flush=True)
    TB(births); print('TB', flush=True)
    TC(); print('TC', flush=True)
    TD(); print('TD', flush=True)
    TE(); print('TE', flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(open(os.path.abspath(__file__), 'rb').read()).hexdigest()
    json.dump(out, open(os.path.join(HERE, 'rg_tower_attack_results.json'), 'w'), indent=1, sort_keys=True)
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
