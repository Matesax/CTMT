#!/usr/bin/env python3
import numpy as np, json, csv
from pathlib import Path
from scipy.optimize import nnls
OUT=Path(__file__).resolve().parent

def kernel(t,a=1.5): return (1+t)**(-a)
def grid(T,n=900): return np.r_[0.,np.geomspace(1e-6,T,n-1)]
def weighted_fit(T,a,d,eps=None,rates=None):
 t=grid(T); y=kernel(t,a); w=np.ones_like(t); w[1:]=np.sqrt(np.gradient(np.log1p(t[1:])))
 if rates is None: rates=np.geomspace(1/(30*T),30,d)
 A=np.exp(-np.outer(t,rates)); c,_=nnls(A*w[:,None],y*w,maxiter=20000)
 e=np.linalg.norm((A@c-y)*w)/np.linalg.norm(y*w)
 return e,c,rates

def mindim(T,a,eps,dmax=100):
 for d in range(1,dmax+1):
  e,c,r=weighted_fit(T,a,d)
  if e<=eps:return d,e,c,r
 return dmax,e,c,r

alpha=1.5; eps=1e-3
Ts=np.geomspace(8,2e5,90)
records=[]
for T in Ts:
 d,e,c,r=mindim(float(T),alpha,eps)
 active=r[c>1e-10]
 records.append({'T':float(T),'logT':float(np.log(T)),'d':int(d),'error':float(e),'active':int(len(active))})

# H1: refinement monotonicity / no complexity decrease with horizon.
ds=np.array([x['d'] for x in records]); monotone=np.all(np.diff(ds)>=0)
# mode-birth horizons and log spacing
birth=[]
last=ds[0]
for x in records[1:]:
 if x['d']>last:
  for k in range(last+1,x['d']+1): birth.append((k,x['T']))
  last=x['d']
logbirth=np.log([x[1] for x in birth])
spacing=np.diff(logbirth)
spacing_cv=float(np.std(spacing)/np.mean(spacing)) if len(spacing)>1 else np.nan

# H2: shared pole atlas across horizons. Fit one global logarithmic pole bank, truncate weights per horizon.
# The RG hypothesis is that composability/refinement favors an inherited spectrum versus re-identification.
maxT=float(Ts[-1]); bank=np.geomspace(1/(30*maxT),30,48)
shared=[]
for T in Ts[::6]:
 e,c,r=weighted_fit(float(T),alpha,len(bank),rates=bank)
 active=int(np.sum(c>1e-9))
 shared.append({'T':float(T),'error':float(e),'active':active})
shared_pass=max(x['error'] for x in shared)<eps*1.4

# H3: pole geometry. Independently optimized minimal grids should have approximately uniform log-rate spacing.
pole_stats=[]
for T in [30,100,300,1000,3000,10000,30000,100000]:
 d,e,c,r=mindim(T,alpha,eps); rr=r[c>1e-10]
 gaps=np.diff(np.log(rr))
 pole_stats.append({'T':T,'d':d,'active':len(rr),'gap_cv':float(np.std(gaps)/np.mean(np.abs(gaps))) if len(gaps)>1 else 0.,'error':e})
log_uniform=max(x['gap_cv'] for x in pole_stats)<0.05

# H4: tensor/composition law. For product channel K_a*K_b in Laplace spectral sense,
# tail exponents add in time-domain product K_a(t)K_b(t)=K_{a+b}(t).
# Test whether completion budget is subadditive: d(a+b) <= d(a)+d(b).
compositions=[]
for T in [100,1000,10000]:
 for a,b in [(0.5,0.75),(0.75,1.0),(1.0,1.5)]:
  da,*_=mindim(T,a,eps); db,*_=mindim(T,b,eps); dab,*_=mindim(T,a+b,eps)
  compositions.append({'T':T,'a':a,'b':b,'da':da,'db':db,'dab':dab,'margin':da+db-dab})
subadd=all(x['margin']>=0 for x in compositions)

# H5: coarse-graining covariance: rescaling t -> s t should shift pole rates by 1/s and not change d
cov=[]
for s in [0.1,0.3,3,10]:
 T=1000
 d,e,c,r=mindim(T,alpha,eps)
 # directly fit scaled kernel (1+t/s)^-a on [0,sT], transformed rates predicted r/s
 t=grid(s*T); y=(1+t/s)**(-alpha); w=np.ones_like(t); w[1:]=np.sqrt(np.gradient(np.log1p(t[1:])))
 A=np.exp(-np.outer(t,r/s)); cc,_=nnls(A*w[:,None],y*w,maxiter=20000)
 er=np.linalg.norm((A@cc-y)*w)/np.linalg.norm(y*w)
 cov.append({'scale':s,'base_d':d,'transformed_error':float(er),'weight_rel_change':float(np.linalg.norm(cc-c)/np.linalg.norm(c))})
cov_pass=max(x['transformed_error'] for x in cov)<eps*1.2

# Attack: tempered algebraic kernel should terminate horizon growth after T exceeds tempering scale.
def fit_custom(T,d,fun):
 t=grid(T); y=fun(t);w=np.ones_like(t);w[1:]=np.sqrt(np.gradient(np.log1p(t[1:])))
 r=np.geomspace(1/(30*T),30,d);A=np.exp(-np.outer(t,r));c,_=nnls(A*w[:,None],y*w,maxiter=20000)
 return np.linalg.norm((A@c-y)*w)/np.linalg.norm(y*w)
def md_custom(T,fun):
 for d in range(1,101):
  if fit_custom(T,d,fun)<=eps:return d
 return 100
temp=[]
for T in [30,100,300,1000,3000,10000,30000,100000]:
 temp.append({'T':T,'pure':mindim(T,alpha,eps)[0],'tempered':md_custom(T,lambda t:(1+t)**(-alpha)*np.exp(-t/500))})
# saturation evidence: last 3 tempered dimensions range <=1 while pure still grows
saturation=(max(x['tempered'] for x in temp[-3:])-min(x['tempered'] for x in temp[-3:])<=1 and temp[-1]['pure']>temp[-3]['pure'])

hypotheses=[
 {'name':'H1 Resolution monotonicity and discrete mode births','supported':bool(monotone),'strength':'structural','novel_predictor':'New hidden modes appear only at ordered horizon thresholds; no mode death under refinement.','diagnostic':{'births':birth,'log_spacing_cv':spacing_cv}},
 {'name':'H2 Projectively inherited relaxation spectrum','supported':bool(shared_pass),'strength':'strong synthetic','novel_predictor':'One pole atlas should transfer across forecast horizons; only weights/activity change.','diagnostic':shared},
 {'name':'H3 Logarithmic pole geometry','supported':bool(log_uniform),'strength':'construction-dependent','novel_predictor':'Admissible hidden relaxation times are approximately geometrically spaced.','diagnostic':pole_stats},
 {'name':'H4 Subadditive completion under channel composition','supported':bool(subadd),'strength':'strong synthetic','novel_predictor':'Combined channel complexity is no greater than the sum of component budgets.','diagnostic':compositions},
 {'name':'H5 Scale-covariant completion transport','supported':bool(cov_pass),'strength':'structural','novel_predictor':'Changing the record time scale transports poles inversely without changing completion dimension.','diagnostic':cov},
 {'name':'H6 Tempering creates complexity saturation wall','supported':bool(saturation),'strength':'strong synthetic','novel_predictor':'A finite tempering time stops mode births, unlike a pure algebraic tail.','diagnostic':temp}
]
score=sum(h['supported'] for h in hypotheses)
res={'alpha':alpha,'epsilon':eps,'hypotheses':hypotheses,'supported_count':score,'total':len(hypotheses),'records':records}
(OUT/'rg_assumption_discovery_results.json').write_text(json.dumps(res,indent=2))
with open(OUT/'rg_assumption_discovery_records.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['T','logT','d','error','active']);w.writeheader();w.writerows(records)
print(json.dumps({'supported_count':score,'total':len(hypotheses),'hypotheses':hypotheses},indent=2))
