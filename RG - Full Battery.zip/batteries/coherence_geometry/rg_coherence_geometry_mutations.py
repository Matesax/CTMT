#!/usr/bin/env python3
"""Mutation suite for rg_coherence_geometry.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. A few minutes.

    python3 -I rg_coherence_geometry_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('K2', 'Peirce gap off by one', "v['gap'] == v['peirce']", "v['gap'] == v['peirce'] + 1"),
    ('K5', 'wrong maximal coherence at phase 0', "abs(out['0']['c_max'] - 1 / 3) < 1e-12", "abs(out['0']['c_max'] - 1 / 4) < 1e-12"),
    ('K6', 'wrong group order', 'order == 300', 'order == 299'),
    ('K8', 'Chern number 2 claimed', 'abs(abs(chern) - 1) < 1e-4', 'abs(abs(chern) - 2) < 1e-4'),
    ('K12', 'MUB entropy off', 'max(abs(np.array(mub) - np.log2(d))) < 1e-10', 'max(abs(np.array(mub) - np.log2(d + 1))) < 1e-10'),
    ('K13', 'wrong roots of composition', 'roots == [0, 2]', 'roots == [0, 1]'),
    ('K15', 'collapse sign flipped', 'collapse < 0', 'collapse > 0'),
]


def main():
    base = open(os.path.join(HERE, 'rg_coherence_geometry.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            for f in os.listdir(HERE):                                  # helpers and supplied data
                if f not in ('rg_coherence_geometry.py', 'rg_coherence_geometry_mutations.py', 'rg_coherence_geometry_results.json'):
                    (shutil.copytree if os.path.isdir(os.path.join(HERE, f)) else shutil.copy)(os.path.join(HERE, f), os.path.join(tmp, f))
            open(os.path.join(tmp, 'rg_coherence_geometry.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_coherence_geometry.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_coherence_geometry_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
