# RG – Forced Metric: can "what records can force" select the quantum metric without a task?

**Verdict: partly yes. What locks and what does not:**
- **The task can be removed.** It is replaced by the target, which is the variable of the metric rather than a premise.
- **What remains is the envelope.** Define the metric as the envelope of what record protocols can force. That envelope is the SLD (Bures) metric, the minimal Petz monotone metric.
- **The rest of the Petz family is falsified.** Every other monotone metric forecasts certificates that no protocol delivers, and frozen forecasts from them fail.
- **No exactness without a direction.** No single committed protocol attains the envelope in all directions unless the model is locally classical. So "QM without task, exact on one channel" is a sharp no-go, not a theorem.
- **Beyond finite dimension.** Exact forcing is the weak-* closure of the record span. Certification at a rate needs a source condition, and the physical cone is what supplies it.

## The chain

| Step | Statement | Status | Group |
|---|---|---|---|
| 1. Orders on protocols | Exact forcing order = kernel inclusion. Asymptotic order = Loewner order of classical Fisher. Blackwell garbling ⇒ Fisher order ⇒ kernel order. | proved; strictness computed | QA |
| 2. Record side | Classical Fisher is contracted by Markov maps and invariant under outcome splitting, hence unique up to scale (Čencov). N-shot width z/√(NF) covers at the nominal rate. | Čencov 1982 + computed | QB |
| 3. Selection | sup over all POVMs of the classical Fisher = SLD quantum Fisher, attained by the SLD eigenbasis. SLD is the minimal monotone metric. WY, KM and RLD are monotone but exceed the envelope in every coherent direction. | Braunstein–Caves 1994, Petz 1996 + computed | QC |
| 4. Frozen falsification | Forecast widths are committed first, then the best protocol is run 4000 times. Coverage: SLD 0.954; WY 0.917; KM 0.889; RLD 0.618; 1.5× SLD 0.998 (not tight). | computed | QD |
| 5. Joint exactness | Single-copy qubit: Tr(J_S⁻¹J_M) ≤ 1, equal to 1 for every rank-one POVM. Two rotation directions would need 2; the best of 3000 POVMs reaches 0.99999. Weak commutativity fails (\|tr ρ[L₁,L₂]\| = 1.6), so collective measurements do not attain it jointly either. | Gill–Massar 2000, Ragy et al. 2016 + computed | QE |
| 6. Infinite dimension | ℓ² with A = diag(1/k): every target is exactly forced. Certified width ω(δ) has slope 0.98 for targets in range(A*) and 0.50 for targets only in its closure. Without the ball the closure target's width grows as δ√n with the truncation n. | bipolar theorem, Micchelli–Rivlin + computed | QF |

## What this gives the descent chain

- **Task → target.** Earlier, the SLD metric was reached by choosing an estimation task. Here no task is chosen. The metric is defined by forceability (the narrowest width that records can certify for a direction), which is RG-native: everything enters through records.
  - The selection is then forced: the SLD metric is the envelope.
  - Every larger monotone metric is an over-claim that a frozen forecast exposes (QD).
  - Nothing below SLD is monotone, by Petz minimality.
- **The monotonicity chain is now graded.** Each level is monotone under channels applied before the record:
  - kernel inclusion (exact, coarsest);
  - Fisher–Loewner order (asymptotic);
  - Blackwell garbling (finest).
  - QA shows the levels differ. A noisy informationally complete POVM forces everything exactly but is Fisher-incomparable with a projective measurement and is no garbling of it. The linear map that kernel order guarantees exists, but needs entries up to 3.39: forcing composes through amplifying signed maps, Blackwell only through stochastic ones.
- **The limit of naturality, located exactly.** The direction cannot be removed. The task-free object is the convex body of Fisher matrices that single protocols can attain, and the SLD metric is its envelope direction by direction. One channel descends the whole metric exactly iff the SLD operators commute (single copy). With many copies the condition is weak commutativity, and the remaining gap is the Holevo bound.
- **Reach beyond finite channels.** In infinite dimension the three notions separate:
  - *forced*: in the weak-* closure of the record span;
  - *certifiable at linear rate*: in the range of A\*;
  - *certifiable at all*: needs a physical bound, such as the unit ball, or an energy bound for an oscillator.

  This is the infinite-dimensional counterpart of the boundary law in *Forced Predictions*: the cone does real work.

## What does not lock

- No single task-free quantum metric is attained by records (step 5). "Prove exactness on a channel" holds only for locally classical models.
- The selection in step 3 is Braunstein–Caves plus Petz minimality. RG's contribution is the framing: forceability as the definition, and frozen forecasts as the falsifier. The equality itself is not new.
- QF uses the unit ball of ℓ² as a stand-in for a physical cone. A genuine oscillator example (an energy-bounded set of states, with records such as homodyne quadratures) is not built.
- Collective (many-copy) attainability is cited, not simulated.

## Battery

`rg_forced_metric.py`, seed 20261204, 6 groups (QA–QF), each with a canary. The rerun is byte-identical. The mutation suite catches 9 of 9 deliberate errors, and a crash would count as a defect, not a catch.

One mutation survived at first and sharpened QA: allowing signed entries bounded by ±1 still gave no factorization. The gap between kernel order and Blackwell is magnitude, not only sign.

## Sources

- N. N. Čencov, *Statistical Decision Rules and Optimal Inference*, AMS (1982).
- S. L. Braunstein, C. M. Caves, Statistical distance and the geometry of quantum states, Phys. Rev. Lett. 72 (1994) 3439.
- D. Petz, Monotone metrics on matrix spaces, Linear Algebra Appl. 244 (1996) 81.
- R. D. Gill, S. Massar, State estimation for large ensembles, Phys. Rev. A 61 (2000) 042312.
- S. Ragy, M. Jarzyna, R. Demkowicz-Dobrzański, Compatibility in multiparameter quantum metrology, Phys. Rev. A 94 (2016) 052108.
- D. Blackwell, Equivalent comparisons of experiments, Ann. Math. Statist. 24 (1953) 265.
- C. A. Micchelli, T. J. Rivlin, A survey of optimal recovery, in *Optimal Estimation in Approximation Theory*, Plenum (1977) 1.
