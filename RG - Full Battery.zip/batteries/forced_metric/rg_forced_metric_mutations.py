#!/usr/bin/env python3
"""Mutation suite for rg_forced_metric.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. A few minutes.

    python3 -I rg_forced_metric_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('QA', 'signed (non-stochastic) garbling allowed', "bounds=[(0, 1)] * 8, method='highs'", "bounds=[(None, None)] * 8, method='highs'"),
    ('QB', 'Euclidean metric in place of Fisher', "fish = lambda p, dp: float(np.sum(dp ** 2 / p))", "fish = lambda p, dp: float(np.sum(dp ** 2))"),
    ('QC', 'RLD function replaced by the SLD one', "    'RLD': lambda x: 2 * x / (1 + x),", "    'RLD': lambda x: (1 + x) / 2,"),
    ('QC', 'POVM left unnormalised', "    return [Si @ np.outer(v, v.conj()) @ Si for v in V]", "    return [np.outer(v, v.conj()) for v in V]"),
    ('QD', 'one-sided quantile', "    r0 = 0.9; theta0 = 0.4; N = 2000; runs = 4000; z = norm.ppf(0.975)", "    r0 = 0.9; theta0 = 0.4; N = 2000; runs = 4000; z = norm.ppf(0.95)"),
    ('QE', 'canary measured in a rotated basis', "comp = [np.diag(e).astype(complex) for e in np.eye(3)]", "Fq = np.exp(2j * np.pi * np.outer(np.arange(3), np.arange(3)) / 3) / math.sqrt(3); comp = [np.outer(Fq[:, i], Fq[:, i].conj()) for i in range(3)]"),
    ('QE', 'Gill-Massar weight dropped', "JSi = np.linalg.inv(JS)", "JSi = np.eye(3) / np.trace(JS)"),
    ('QF', 'dual missing its factor 4', "return float(np.sum(c2 / (4 * (lam * s2 + mu))) + lam * delta ** 2 + mu)", "return float(np.sum(c2 / (lam * s2 + mu)) + lam * delta ** 2 + mu)"),
    ('QF', 'kernel direction removed from the canary', "s_ker = s.copy(); s_ker[0] = 0.0;", "s_ker = s.copy();"),
]


def main():
    base = open(os.path.join(HERE, 'rg_forced_metric.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_forced_metric.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_forced_metric.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_forced_metric_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
