#!/usr/bin/env python3
"""Resolution Geometry - the forced metric: does 'what records can force' select the quantum metric without a task?

A metric on states is read as a forecast: the width to which a direction of change can be certified from N records.
The selection rule tested here: the metric is the envelope, over all record protocols, of what records can force.

  QA three orders on protocols. Exact forcing order = kernel inclusion; asymptotic order = Loewner order of classical
     Fisher; Blackwell garbling implies both. Canary: a noisy informationally complete POVM and a projective measurement
     are kernel-ordered, Fisher-incomparable, and not related by any garbling (LP infeasible)
  QB record side (Cencov). Classical Fisher is contracted by random Markov maps and invariant under outcome splitting;
     N-shot Wald intervals at width z/sqrt(N F) cover at the nominal rate. Canary: the Euclidean metric on probabilities
     changes under outcome splitting
  QC the envelope. Over all POVMs the classical Fisher never exceeds the SLD quantum Fisher and the SLD eigenbasis attains
     it. The other Petz monotone metrics (Wigner-Yanase, Kubo-Mori, RLD) are all contracted by random channels, but exceed
     the envelope whenever the direction has a coherent part: they forecast certificates no record protocol delivers.
     Canary: in a classical (commuting) direction all four coincide
  QD frozen selection. Commit interval widths from each metric, then run the best protocol many times: SLD widths cover
     at the nominal rate; WY, KM and RLD widths undercover; a 1.5x SLD width overcovers (not tight)
  QE no joint exactness (Gill-Massar). For a qubit, Tr(J_S^-1 J_M) <= 1 for every single-copy POVM; projective measurements
     attain 1; attaining the SLD metric in two directions at once needs 2. Canary: commuting (diagonal) qutrit family,
     where one measurement attains the SLD matrix exactly. Weak commutativity tr(rho [L1, L2]) reported
  QF beyond finite dimension (optimal recovery). In l2 with a compact injective record map A = diag(1/k): every target
     is exactly forced, but the certifiable width omega(delta) is linear only for targets in the range of A*; a target
     in the closure but not the range has rate delta^(1/2), and without a physical bound (the ball) its width is
     infinite. Canary: a target with a kernel component has omega(0) > 0

Deterministic. Seed 20261204. Writes rg_forced_metric_results.json.
Run:  python3 -I rg_forced_metric.py      (numpy, scipy)
"""
import hashlib, json, math, sys
from pathlib import Path
import numpy as np
from scipy.optimize import linprog, minimize
from scipy.stats import norm

HERE = Path(__file__).resolve().parent
SEED = 20261204
R, FAILS = {}, []
SX = np.array([[0, 1], [1, 0]], complex); SY = np.array([[0, -1j], [1j, 0]]); SZ = np.array([[1, 0], [0, -1]], complex); I2 = np.eye(2)
PAULI = (SX, SY, SZ)


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.8g}')


def below(v, b):
    return f'< {b:g}' if abs(v) < b else fl(v)


def bloch(r):
    return (I2 + sum(c * P for c, P in zip(r, PAULI))) / 2


# ------------------------------------------------------------------------------------------ Petz metrics
F_PETZ = {
    'SLD': lambda x: (1 + x) / 2,
    'WY': lambda x: ((1 + np.sqrt(x)) / 2) ** 2,
    'KM': lambda x: np.where(np.abs(x - 1) < 1e-12, 1.0, (x - 1) / np.log(np.where(np.abs(x - 1) < 1e-12, 2.0, x))),
    'RLD': lambda x: 2 * x / (1 + x),
}


def petz_fisher(rho, d1, d2=None, kind='SLD'):
    """g_f(d1, d2) = sum_ij conj(d1_ij) d2_ij c_f(l_i, l_j), c_f(x, y) = 1 / (y f(x/y)), in the eigenbasis of rho."""
    d2 = d1 if d2 is None else d2
    lam, U = np.linalg.eigh(rho); a = U.conj().T @ d1 @ U; b = U.conj().T @ d2 @ U
    X, Y = np.meshgrid(lam, lam, indexing='ij'); c = 1.0 / (Y * F_PETZ[kind](X / Y))
    return float(np.real(np.sum(np.conj(a) * b * c)))


def sld_operator(rho, d):
    lam, U = np.linalg.eigh(rho); a = U.conj().T @ d @ U
    L = 2 * a / (lam[:, None] + lam[None, :]); return U @ L @ U.conj().T


def classical_fisher(povm, rho, ds):
    """Fisher matrix of the outcome law for derivative directions ds."""
    p = np.array([np.real(np.trace(E @ rho)) for E in povm]); keep = p > 1e-14
    dp = np.array([[np.real(np.trace(E @ d)) for E in povm] for d in ds])[:, keep]
    return (dp / p[keep]) @ dp.T


def random_povm(rng, dim, k):
    V = rng.normal(size=(k, dim)) + 1j * rng.normal(size=(k, dim)); S = sum(np.outer(v, v.conj()) for v in V)
    w, Q = np.linalg.eigh(S); Si = Q @ np.diag(w ** -0.5) @ Q.conj().T
    return [Si @ np.outer(v, v.conj()) @ Si for v in V]


def projective(n):
    n = np.asarray(n, float); n = n / np.linalg.norm(n); P = (I2 + sum(c * S for c, S in zip(n, PAULI))) / 2
    return [P, I2 - P]


def random_channel(rng, dim, nk):
    G = rng.normal(size=(nk * dim, dim)) + 1j * rng.normal(size=(nk * dim, dim)); Q, _ = np.linalg.qr(G)
    return [Q[i * dim:(i + 1) * dim, :] for i in range(nk)]


def apply(K, X):
    return sum(k @ X @ k.conj().T for k in K)


def random_state(rng, dim, purity_floor=0.05):
    G = rng.normal(size=(dim, dim)) + 1j * rng.normal(size=(dim, dim)); rho = G @ G.conj().T; rho /= np.trace(rho).real
    return (1 - purity_floor) * rho + purity_floor * np.eye(dim) / dim


def random_traceless(rng, dim):
    H = rng.normal(size=(dim, dim)) + 1j * rng.normal(size=(dim, dim)); H = (H + H.conj().T) / 2
    return H - np.trace(H) / dim * np.eye(dim)


# ============================================================================================ QA
def QA():
    eta = 0.3; t = np.array([[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]]) / math.sqrt(3)
    A = [(I2 + eta * sum(c * S for c, S in zip(ti, PAULI))) / 4 for ti in t]          # noisy tetrahedral POVM
    B = projective([0, 0, 1])
    # linear record maps on Bloch coordinates (affine part dropped): rows d p_k / d r
    rowsA = np.array([[np.real(np.trace(E @ S)) / 2 for S in PAULI] for E in A]); rowsB = np.array([[np.real(np.trace(E @ S)) / 2 for S in PAULI] for E in B])
    kerA = 3 - np.linalg.matrix_rank(rowsA); kerB = 3 - np.linalg.matrix_rank(rowsB)
    kernel_order = np.linalg.matrix_rank(np.vstack([rowsA, rowsB])) == np.linalg.matrix_rank(rowsA)    # rows of B in span of A: ker A in ker B
    # garbling LP: find column-stochastic M (2x4) with M p_A(rho) = p_B(rho) for all rho
    # p_A = a0 + rowsA r, p_B = b0 + rowsB r: need M a0 = b0 and M rowsA = rowsB
    a0 = np.full(4, 0.25); b0 = np.full(2, 0.5)
    Aeq = []; beq = []
    for i in range(2):                                     # M rowsA = rowsB, M a0 = b0
        for j in range(3):
            row = np.zeros(8); row[i * 4:(i + 1) * 4] = rowsA[:, j]; Aeq.append(row); beq.append(rowsB[i, j])
        row = np.zeros(8); row[i * 4:(i + 1) * 4] = a0; Aeq.append(row); beq.append(b0[i])
    for k in range(4):                                     # columns sum to one
        row = np.zeros(8); row[k] = 1; row[4 + k] = 1; Aeq.append(row); beq.append(1.0)
    lp = linprog(np.zeros(8), A_eq=np.array(Aeq), b_eq=np.array(beq), bounds=[(0, 1)] * 8, method='highs')
    garbling_exists = lp.status == 0
    # kernel order guarantees a linear (signed, unbounded) factorisation; find the one with the smallest largest entry
    nv = 8; c = np.zeros(nv + 1); c[-1] = 1.0
    Aub = []; bub = []
    for i in range(nv):
        for sg in (1, -1):
            row = np.zeros(nv + 1); row[i] = sg; row[-1] = -1; Aub.append(row); bub.append(0.0)
    lin = linprog(c, A_ub=np.array(Aub), b_ub=np.array(bub), A_eq=np.hstack([np.array(Aeq), np.zeros((len(Aeq), 1))]), b_eq=np.array(beq),
                  bounds=[(None, None)] * (nv + 1), method='highs')
    linear_exists = lin.status == 0; linear_max_entry = float(lin.fun) if linear_exists else math.inf
    rho = bloch([0.3, 0.2, 0.4]); dz = SZ / 2; dx = SX / 2
    FA_z = classical_fisher(A, rho, [dz])[0, 0]; FB_z = classical_fisher(B, rho, [dz])[0, 0]
    FA_x = classical_fisher(A, rho, [dx])[0, 0]; FB_x = classical_fisher(B, rho, [dx])[0, 0]
    # Blackwell implies Fisher order: garble A by a random stochastic map and compare Fisher matrices
    rng = np.random.default_rng(SEED); worst = -1.0
    for _ in range(200):
        M = rng.uniform(size=(3, 4)); M /= M.sum(0)
        G = [sum(M[i, k] * A[k] for k in range(4)) for i in range(3)]
        st = random_state(rng, 2); ds = [S / 2 for S in PAULI]
        diff = classical_fisher(G, st, ds) - classical_fisher(A, st, ds); worst = max(worst, float(np.linalg.eigvalsh(diff).max()))
    ok = kerA == 0 and kerB == 2 and kernel_order and not garbling_exists and linear_exists and linear_max_entry > 1 and FA_z < FB_z and FA_x > FB_x and worst < 1e-10
    must(ok, 'QA')
    R['QA'] = dict(claim='Three orders on protocols. Exact forcing order: A forces every target B forces iff ker A is in ker B. '
                         'Asymptotic order: Loewner order of the classical Fisher matrices. Blackwell garbling implies both (200 '
                         'random garblings never increase the Fisher matrix). Canary: a noisy tetrahedral POVM (eta = 0.3) has '
                         'empty kernel, so it forces every target exactly, including all that a projective z measurement forces; '
                         'yet its z Fisher information is smaller, its x Fisher information larger, and no garbling maps it to the '
                         'z measurement (LP infeasible). A linear map does exist, as kernel order guarantees, but its smallest possible largest '
                         'entry is the value below: forcing composes through signed, amplifying maps, Blackwell only through '
                         'stochastic ones. Exact forcing is coarser than Blackwell; the Fisher order lies between.',
                   status='computed', kernel_dims=dict(tetra=int(kerA), proj_z=int(kerB)), kernel_order=bool(kernel_order), garbling_exists=bool(garbling_exists), linear_map_max_entry=fl(linear_max_entry),
                   fisher_z=dict(tetra=fl(FA_z), proj=fl(FB_z)), fisher_x=dict(tetra=fl(FA_x), proj=fl(FB_x)), garbling_max_eig_increase=below(worst, 1e-10))


# ============================================================================================ QB
def QB():
    rng = np.random.default_rng(SEED + 1)
    fish = lambda p, dp: float(np.sum(dp ** 2 / p)); eucl = lambda p, dp: float(np.sum(dp ** 2))
    worst = -1.0
    for _ in range(500):
        k = int(rng.integers(2, 7)); p = rng.dirichlet(np.ones(k)); dp = rng.normal(size=k); dp -= dp.mean()
        M = rng.uniform(size=(int(rng.integers(2, 7)), k)); M /= M.sum(0)
        worst = max(worst, fish(M @ p, M @ dp) - fish(p, dp))
    p = np.array([0.2, 0.5, 0.3]); dp = np.array([0.1, -0.3, 0.2])
    split = lambda v: np.array([v[0] * 0.3, v[0] * 0.7, v[1], v[2]])                 # congruent embedding: split outcome 0
    f_inv = abs(fish(split(p), split(dp)) - fish(p, dp)); e_change = abs(eucl(split(p), split(dp)) - eucl(p, dp))
    # N-shot Wald coverage at width z / sqrt(N F) for a Bernoulli parameter
    theta, N, runs = 0.3, 10000, 4000; z = norm.ppf(0.975); F = 1 / (theta * (1 - theta))
    est = rng.binomial(N, theta, runs) / N; cov = float(np.mean(np.abs(est - theta) <= z / math.sqrt(N * F)))
    ok = worst < 1e-10 and f_inv < 1e-12 and e_change > 1e-3 and abs(cov - 0.95) < 0.015
    must(ok, 'QB')
    R['QB'] = dict(claim='Record side. On 500 random families and Markov maps the classical Fisher information never increases, and it is '
                         'invariant under splitting an outcome in fixed proportions (congruent embedding): by Cencov this fixes it '
                         'uniquely, up to scale, among metrics on record laws. N-shot intervals at width z/sqrt(N F) cover at the '
                         'nominal rate. Canary: the Euclidean metric on probabilities changes under the same splitting, so it '
                         'cannot be a task-free metric on records.',
                   status='PROVED (Cencov 1982) + computed', max_fisher_increase=below(worst, 1e-10), fisher_split_change=below(f_inv, 1e-12),
                   euclid_split_change=fl(e_change), wald_coverage=fl(cov), nominal=0.95)


# ============================================================================================ QC
def QC():
    rng = np.random.default_rng(SEED + 2)
    over = 0; attain_err = 0.0; envelope_excess = -1.0; mono_worst = {k: -1.0 for k in F_PETZ}; order_ok = True; above = {k: 0 for k in F_PETZ}
    cases = 300
    for _ in range(cases):
        rho = random_state(rng, 2); d = random_traceless(rng, 2)
        g = {k: petz_fisher(rho, d, kind=k) for k in F_PETZ}
        order_ok &= g['SLD'] <= g['WY'] + 1e-12 <= g['KM'] + 2e-12 <= g['RLD'] + 3e-12
        L = sld_operator(rho, d); _, V = np.linalg.eigh(L); best = classical_fisher([np.outer(V[:, i], V[:, i].conj()) for i in range(2)], rho, [d])[0, 0]
        attain_err = max(attain_err, abs(best - g['SLD']) / g['SLD'])
        for _ in range(20):
            Jm = classical_fisher(random_povm(rng, 2, int(rng.integers(2, 7))), rho, [d])[0, 0]
            envelope_excess = max(envelope_excess, (Jm - g['SLD']) / g['SLD'])
        for k in F_PETZ:
            above[k] += int(g[k] > g['SLD'] * (1 + 1e-9))
        K = random_channel(rng, 2, int(rng.integers(1, 5)))
        for k in F_PETZ:
            mono_worst[k] = max(mono_worst[k], petz_fisher(apply(K, rho), apply(K, d), kind=k) - g[k])
    # dense projective search on one hard case: max over the Bloch sphere of measurement directions
    rho = bloch([0.0, 0.0, 0.9]); d = SX / 2
    th = np.linspace(0, math.pi, 181); ph = np.linspace(0, 2 * math.pi, 361)
    dense = max(classical_fisher(projective([math.sin(a) * math.cos(b), math.sin(a) * math.sin(b), math.cos(a)]), rho, [d])[0, 0] for a in th for b in ph)
    hard = {k: petz_fisher(rho, d, kind=k) for k in F_PETZ}
    # canary: classical direction (d commutes with rho): all metrics coincide
    dc = SZ / 2; classical_spread = max(petz_fisher(rho, dc, kind=k) for k in F_PETZ) - min(petz_fisher(rho, dc, kind=k) for k in F_PETZ)
    ok = attain_err < 1e-9 and envelope_excess < 1e-9 and all(v < 1e-10 for v in mono_worst.values()) and order_ok \
        and all(above[k] == cases for k in ('WY', 'KM', 'RLD')) and abs(dense - hard['SLD']) / hard['SLD'] < 1e-3 and dense <= hard['SLD'] * (1 + 1e-9) \
        and classical_spread < 1e-12 and hard['RLD'] / hard['SLD'] > 5
    must(ok, 'QC')
    R['QC'] = dict(claim='The envelope. For 300 random full-rank qubit states and directions: the projective measurement in the SLD '
                         'eigenbasis attains the SLD quantum Fisher information, and 6000 random POVMs (2 to 6 outcomes) never exceed '
                         'it. So the envelope of what records can force is the SLD metric, the minimal Petz monotone metric. The '
                         'Wigner-Yanase, Kubo-Mori and RLD metrics are all contracted by random channels (monotone), but exceed the '
                         'envelope in every random case: each forecasts certificates no record protocol delivers. On r = (0, 0, 0.9) '
                         'with a rotation direction a dense search over 65 000 projective directions matches SLD to 1e-3 while RLD is '
                         'the ratio below times larger. Canary: in a classical direction (commuting with the state) all four coincide.',
                   status='PROVED (Braunstein-Caves 1994; Petz 1996) + computed', sld_attainment_rel_error=below(attain_err, 1e-9),
                   povm_max_relative_excess=fl(envelope_excess), petz_monotone_worst_increase={k: below(v, 1e-10) for k, v in mono_worst.items()},
                   fraction_above_sld={k: above[k] / cases for k in F_PETZ}, hard_case={k: fl(v) for k, v in hard.items()}, hard_dense_projective=fl(dense),
                   rld_over_sld=fl(hard['RLD'] / hard['SLD']), classical_direction_spread=below(classical_spread, 1e-12))


# ============================================================================================ QD
def QD():
    rng = np.random.default_rng(SEED + 3)
    r0 = 0.9; theta0 = 0.4; N = 2000; runs = 4000; z = norm.ppf(0.975)
    # family: Bloch vector of length r0 at polar angle theta in the x-z plane; direction of change is a rotation
    rvec = lambda t: np.array([r0 * math.sin(t), 0.0, r0 * math.cos(t)])
    rho = bloch(rvec(theta0)); d = bloch(np.array([r0 * math.cos(theta0), 0.0, -r0 * math.sin(theta0)])) - I2 / 2
    g = {k: petz_fisher(rho, d, kind=k) for k in F_PETZ}
    # best protocol: projective measurement in the SLD eigenbasis at theta0 (locally optimal), MLE by inversion of the outcome law
    L = sld_operator(rho, d); w, V = np.linalg.eigh(L); n_vec = np.array([np.real(np.trace(np.outer(V[:, 1], V[:, 1].conj()) @ S)) for S in PAULI])
    p_of = lambda t: (1 + n_vec @ rvec(t)) / 2
    grid = np.linspace(theta0 - 0.5, theta0 + 0.5, 200001); pg = np.array([p_of(t) for t in grid[::1000]])
    pg_full = (1 + (n_vec[0] * r0 * np.sin(grid) + n_vec[2] * r0 * np.cos(grid))) / 2
    mono = np.all(np.diff(pg_full) > 0) or np.all(np.diff(pg_full) < 0)
    order = np.argsort(pg_full); counts = rng.binomial(N, p_of(theta0), runs) / N
    est = np.interp(counts, pg_full[order], grid[order])
    cov = {k: float(np.mean(np.abs(est - theta0) <= z / math.sqrt(N * g[k]))) for k in F_PETZ}
    cov['SLD_x1.5'] = float(np.mean(np.abs(est - theta0) <= 1.5 * z / math.sqrt(N * g['SLD'])))
    ok = mono and abs(cov['SLD'] - 0.95) < 0.015 and cov['WY'] < 0.93 and cov['KM'] < cov['WY'] and cov['RLD'] < cov['KM'] and cov['SLD_x1.5'] > 0.99
    must(ok, 'QD')
    R['QD'] = dict(claim='Frozen selection. Each metric is read as a forecast: the half-width z/sqrt(N g) to which a rotation of a mixed qubit '
                         '(|r| = 0.9) is certifiable from N = 2000 records. The forecasts are fixed first; then the best protocol '
                         '(SLD eigenbasis, maximum likelihood) is run 4000 times. The SLD forecast covers at the nominal 0.95; the '
                         'Wigner-Yanase, Kubo-Mori and RLD forecasts undercover, in that order; a forecast 1.5 times wider than SLD '
                         'overcovers. The narrowest forecast that never fails is the SLD one.',
                   status='computed', metric=dict((k, fl(v)) for k, v in g.items()), coverage={k: fl(v) for k, v in cov.items()}, N=N, runs=runs)


# ============================================================================================ QE
def QE():
    rng = np.random.default_rng(SEED + 4)
    rho = random_state(rng, 2, 0.2); ds = [S / 2 for S in PAULI]
    JS = np.array([[petz_fisher(rho, a, b, 'SLD') for b in ds] for a in ds]); JSi = np.linalg.inv(JS)
    worst = 0.0; proj_vals = []
    for _ in range(3000):
        JM = classical_fisher(random_povm(rng, 2, int(rng.integers(2, 7))), rho, ds); worst = max(worst, float(np.trace(JSi @ JM)))
    for _ in range(50):
        proj_vals.append(float(np.trace(JSi @ classical_fisher(projective(rng.normal(size=3)), rho, ds))))
    # two-direction rotation family on a z-polarized state: joint attainment needs trace 2
    rz = bloch([0, 0, 0.8]); d2 = [SX / 2, SY / 2]
    J2 = np.array([[petz_fisher(rz, a, b, 'SLD') for b in d2] for a in d2]); J2i = np.linalg.inv(J2)
    best2 = max(float(np.trace(J2i @ classical_fisher(random_povm(rng, 2, int(rng.integers(2, 7))), rz, d2))) for _ in range(3000))
    L1, L2 = sld_operator(rz, d2[0]), sld_operator(rz, d2[1]); weak = abs(np.trace(rz @ (L1 @ L2 - L2 @ L1)))
    # canary: commuting qutrit family (diagonal), computational basis attains the SLD matrix
    p = np.array([0.5, 0.3, 0.2]); rho3 = np.diag(p).astype(complex); d3 = [np.diag([1, -1, 0]).astype(complex), np.diag([1, 0, -1]).astype(complex)]
    J3 = np.array([[petz_fisher(rho3, a, b, 'SLD') for b in d3] for a in d3]); comp = [np.diag(e).astype(complex) for e in np.eye(3)]
    canary = float(np.abs(classical_fisher(comp, rho3, d3) - J3).max())
    ok = worst <= 1 + 1e-9 and min(proj_vals) > 1 - 1e-9 and best2 <= 1 + 1e-9 and canary < 1e-12 and weak > 0.1
    must(ok, 'QE')
    R['QE'] = dict(claim='No joint exactness. For a random mixed qubit, 3000 random POVMs satisfy Tr(J_S^-1 J_M) <= 1 (Gill-Massar), and '
                         'every projective measurement attains exactly 1. Attaining the SLD metric in all three directions would need '
                         '3; for a two-direction rotation family it would need 2, and the best of 3000 POVMs reaches the value below. '
                         'So no single committed protocol forces the SLD envelope in every direction: the task-free object is the '
                         'body of attainable Fisher matrices, not one metric. The SLD operators of the two rotations fail weak '
                         'commutativity, tr(rho[L1, L2]) as below, so even collective measurements on many copies do not attain it '
                         'jointly. Canary: a commuting (diagonal) qutrit family, where the computational-basis measurement attains '
                         'the full SLD matrix.',
                   status='PROVED (Gill-Massar 2000; Ragy et al. 2016) + computed', single_copy_max_trace=fl(worst), projective_trace_range=[fl(min(proj_vals)), fl(max(proj_vals))],
                   two_direction_best_trace=fl(best2), needed=2, weak_commutator=fl(weak), commuting_canary_error=below(canary, 1e-12))


# ============================================================================================ QF
def omega(c, s, delta, ball=True):
    """sup c.x subject to sum (s_k x_k)^2 <= delta^2 and (ball) sum x_k^2 <= 1, by the convex dual in (lam, mu)."""
    c2 = c ** 2; s2 = s ** 2
    if not ball:
        if np.any((s2 == 0) & (c2 > 0)):
            return math.inf
        return delta * math.sqrt(np.sum(c2 / s2))                                 # finite iff c in range of A*
    def dual(v):
        lam, mu = math.exp(v[0]), math.exp(v[1]); return float(np.sum(c2 / (4 * (lam * s2 + mu))) + lam * delta ** 2 + mu)
    best = math.inf
    for x0 in ((0.0, 0.0), (math.log(1 / max(delta, 1e-12)), -5.0), (5.0, -10.0), (-5.0, 0.0)):
        res = minimize(dual, x0, method='Nelder-Mead', options=dict(xatol=1e-10, fatol=1e-14, maxiter=4000))
        best = min(best, res.fun)
    return best


def QF():
    K = 1_000_000; k = np.arange(1, K + 1, dtype=float); s = 1 / k
    c_range = k ** -1.6; c_closure = 1 / k                                         # w = k c: k^-0.6 in l2; 1 not in l2
    deltas = np.array([1e-4, 3e-4, 1e-3, 3e-3, 1e-2])
    w_range = np.array([omega(c_range, s, d) for d in deltas]); w_clos = np.array([omega(c_closure, s, d) for d in deltas])
    slope = lambda w: float(np.polyfit(np.log(deltas), np.log(w), 1)[0])
    sr, sc = slope(w_range), slope(w_clos)
    no_ball_range = omega(c_range, s, 1e-3, ball=False); no_ball_closure_K = [omega(1 / np.arange(1, n + 1.0), 1 / np.arange(1, n + 1.0), 1e-3, ball=False) for n in (10 ** 3, 10 ** 4, 10 ** 5)]
    s_ker = s.copy(); s_ker[0] = 0.0; c_ker = np.zeros(K); c_ker[0] = 1.0
    w_ker = omega(c_ker, s_ker, 1e-9)
    bound_range = 1e-3 * math.sqrt(np.sum((c_range / s) ** 2))
    ok = abs(sr - 1) < 0.05 and abs(sc - 0.5) < 0.08 and no_ball_closure_K[2] > 3 * no_ball_closure_K[0] and abs(no_ball_range - bound_range) < 1e-12 \
        and w_range[2] <= bound_range * (1 + 1e-6) and w_ker > 0.99
    must(ok, 'QF')
    R['QF'] = dict(claim='Beyond finite dimension. In l2 (truncated at 1e6 coordinates) with the compact injective record map '
                         'A = diag(1/k), every target is exactly forced, yet the certifiable width omega(delta) at record precision delta '
                         'differs: a target in the range of A* (c_k = k^-1.6) is certified at rate delta^1; a target in the closure but '
                         'not the range (c_k = 1/k) only at rate delta^(1/2). Without a physical bound (the unit ball) the range target '
                         'keeps its linear width ||w|| delta, while the closure target has no finite certificate: its width grows as '
                         'delta sqrt(n) with the truncation n. Canary: a target with a kernel component is not forced, '
                         'omega(0) = 1. Exact forcing is the weak-* closure of the record span; certification at a rate needs a '
                         'source condition, and the cone is what supplies it.',
                   status='PROVED (bipolar theorem; Micchelli-Rivlin optimal recovery) + computed', slope_range=fl(sr), slope_closure=fl(sc),
                   omega_range=[fl(v) for v in w_range], omega_closure=[fl(v) for v in w_clos], deltas=deltas.tolist(),
                   no_ball_range=fl(no_ball_range), no_ball_closure_by_truncation={str(n): fl(v) for n, v in zip((1000, 10000, 100000), no_ball_closure_K)},
                   kernel_canary_omega=fl(w_ker))


if __name__ == '__main__':
    for name, fn in (('QA', QA), ('QB', QB), ('QC', QC), ('QD', QD), ('QE', QE), ('QF', QF)):
        try:
            fn()
        except Exception as e:
            must(False, name); R[name] = dict(crash=repr(e))
        print(name, flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (HERE / 'rg_forced_metric_results.json').write_text(json.dumps(out, indent=1, sort_keys=True))
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
