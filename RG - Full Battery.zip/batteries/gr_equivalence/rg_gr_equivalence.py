#!/usr/bin/env python3
"""RG - Where Resolution Geometry Equals General Relativity: structural equivalence battery.

The battery attacks a declared correspondence  Psi : (GR model, covariant protocol) -> observation system  from eight
sides (SE-1 ... SE-8). Every group carries a canary, i.e. a false variant that must fail.

  SA covariance (SE-2, SE-8): Schwarzschild in three radial charts, one of them random; six operational records and the
     Fisher information of the mass agree in all charts; canary: a coordinate record splits one solution into three
  SB holes (SE-4): two stars of equal mass and different radius are not isometric and give identical exterior records
     (a kernel class that is not a gauge orbit); a plane gravitational wave has vanishing scalar curvature invariants
     and a nonzero tidal tensor; canaries: the interior record and the tidal record separate
  SC walls and holes of the pointwise curvature protocol (SE-5): Weyl tensors as complex symmetric traceless matrices
     under complex rotations (Petrov types); rank of the two invariants against the dimension of the stabilizer;
     non-closed orbits; canary: the generic type has full rank
  SD the observer included (SE-7): with a four-velocity the group is the compact rotation group; the invariants then
     separate what the field invariants could not; a static observer near a spherical mass sits on a wall of rank 2
     of 7; canary: the observer invariant is not a field invariant (it changes under a boost)
  SE composition and filtration (SE-3, SE-1): finite model with gauge copies; garblings compose and are not
     invertible; total variation contracts; two filtrations over one moduli set; canary: a non-stochastic map expands
  SF transport (SE-6): Misner space; inside the domain of dependence two charts give one proper time; beyond the
     Cauchy horizon two flat extensions of the same data give opposite records; closed timelike curves beyond;
     canary: the chart coordinates of the reception event differ

Deterministic. Seed 20261117. Writes rg_gr_equivalence_results.json.
Run:  python3 -I rg_gr_equivalence.py
"""
import hashlib, itertools, json, math, os, sys
import numpy as np
import sympy as sp
from scipy.integrate import quad, solve_ivp
from scipy.linalg import expm
from scipy.optimize import brentq

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 20261117
R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.10g}')


def below(v, bound):
    """Rounding noise is reported as a bound, so that the results file does not depend on the last bits."""
    return f'< {bound:g}' if abs(v) < bound else fl(v)


# ================================================================================================ SA: covariance
def _charts(rng):
    """Schwarzschild of mass M as -A dt^2 + B dx^2 + C dOmega^2 in three radial charts. Each returns (A, B, C)(x, M)."""
    a = rng.uniform(-1, 1, 3); a = 0.6 * a / np.abs(a).sum(); c = rng.uniform(1.3, 1.6)     # h' >= 0.7: a valid radial chart
    h = lambda x: c * x + sum(a[k] * math.sin((k + 1) * x) / (k + 1) for k in range(3))
    dh = lambda x: c + sum(a[k] * math.cos((k + 1) * x) for k in range(3))
    areal = (lambda x, M: 1 - 2 * M / x, lambda x, M: 1 / (1 - 2 * M / x), lambda x, M: x * x)
    iso = (lambda x, M: ((1 - M / (2 * x)) / (1 + M / (2 * x))) ** 2, lambda x, M: (1 + M / (2 * x)) ** 4, lambda x, M: x * x * (1 + M / (2 * x)) ** 4)
    rnd = (lambda x, M: 1 - 2 * M / h(x), lambda x, M: dh(x) ** 2 / (1 - 2 * M / h(x)), lambda x, M: h(x) ** 2)
    return {'areal': (areal, 2.0), 'isotropic': (iso, 0.5), 'random': (rnd, brentq(lambda x: h(x) - 2.0, 0.5, 4.0))}


def _records(chart, xh, M=1.0):
    """Six operational records, computed from the metric functions alone, and the chart coordinate of the light ring."""
    A, B, C = (lambda x, f=f: f(x, M) for f in chart)
    lo = xh * M + 1e-3 if M != 1.0 else xh + 1e-3
    at = lambda rad: brentq(lambda x: math.sqrt(C(x)) - rad * M, lo, 80.0)          # sphere of given circumference / 2 pi M
    lnb = lambda x: math.log(C(x) / A(x)); xc = brentq(lambda x: lnb(x + 1e-6) - lnb(x - 1e-6), at(2.2), at(8.0), xtol=1e-14)
    x6, x10 = at(6.0), at(10.0); d = 1e-5
    freq = math.sqrt((A(x6 + d) - A(x6 - d)) / (C(x6 + d) - C(x6 - d)))
    rec = dict(shadow=math.sqrt(C(xc) / A(xc)), ring_circumference_radius=math.sqrt(C(xc)), proper_distance_ring_to_6=quad(lambda x: math.sqrt(B(x)), xc, x6, epsabs=1e-12)[0],
               redshift_6_to_10=math.sqrt(A(x10) / A(x6)), light_time_6_to_10=quad(lambda x: math.sqrt(B(x) / A(x)), x6, x10, epsabs=1e-12)[0],
               orbital_frequency_at_6=freq)
    return rec, xc


def SA():
    rng = np.random.default_rng(SEED); charts = _charts(rng); recs, coord = {}, {}
    for name, (chart, xh) in charts.items():
        recs[name], coord[name] = _records(chart, xh)
    keys = sorted(recs['areal']); spread = max(abs(recs[n][k] / recs['areal'][k] - 1) for n in recs for k in keys)
    exact = dict(shadow=3 * math.sqrt(3), ring_circumference_radius=3.0, redshift_6_to_10=math.sqrt(0.8 / (2 / 3)), orbital_frequency_at_6=6 ** -1.5)
    err = max(abs(recs['areal'][k] / v - 1) for k, v in exact.items())
    # Fisher information of the mass from three noisy records: a property of the solution, not of the chart
    sig = dict(shadow=0.05, redshift_6_abs=0.01, orbital_frequency_abs=0.002); fisher = {}
    for name, (chart, xh) in charts.items():
        if name == 'random':
            continue                                                       # the random chart is built for M = 1 only
        def y(M):
            A, B, C = (lambda x, f=f: f(x, M) for f in chart)
            lo = xh * M * 1.001; lnb = lambda x: math.log(C(x) / A(x)); xc = brentq(lambda x: lnb(x + 1e-6) - lnb(x - 1e-6), lo * 1.05, 20.0, xtol=1e-14)
            x6 = brentq(lambda x: math.sqrt(C(x)) - 6.0, lo, 80.0); d = 1e-5       # fixed circumference 2 pi 6, not 6 M
            return np.array([math.sqrt(C(xc) / A(xc)), math.sqrt(A(x6)), math.sqrt((A(x6 + d) - A(x6 - d)) / (C(x6 + d) - C(x6 - d)))])
        dy = (y(1 + 1e-4) - y(1 - 1e-4)) / 2e-4
        fisher[name] = float(sum(dy[i] ** 2 / s ** 2 for i, s in enumerate(sig.values())))
    fisher_spread = abs(fisher['isotropic'] / fisher['areal'] - 1)
    # canary: the chart coordinate of the light ring as a "record"
    cvals = sorted(coord.values()); split = min(cvals[i + 1] - cvals[i] for i in range(2))
    ok = spread < 1e-7 and err < 1e-7 and fisher_spread < 1e-5 and split > 0.05 and abs(coord['isotropic'] - (2 + math.sqrt(3)) / 2) < 1e-6
    must(ok, 'SA')
    R['SA'] = dict(claim='Covariance (H-sound). Schwarzschild in three radial charts, one of them a seeded random reparametrization: six '
                         'operational records (shadow, circumference radius of the light ring, proper distance from the ring to the '
                         'sphere of circumference 2 pi 6M, redshift and light time between two spheres, orbital frequency) agree to '
                         '1e-7, and the Fisher information of the mass from three noisy records agrees to 1e-5. The diffeomorphism '
                         'groupoid lies in the kernel of every such protocol. Canary: the chart coordinate of the light ring takes '
                         'three values (3, 1.866 and 2.142); taken as a record it splits one solution into three.',
                   status='PROVED (invariance) + computed', records={n: {k: fl(v) for k, v in r.items()} for n, r in recs.items()}, max_relative_spread=below(spread, 1e-8),
                   error_against_closed_form=below(err, 1e-8), fisher_information_of_mass={k: fl(v) for k, v in fisher.items()}, fisher_relative_spread=below(fisher_spread, 1e-6),
                   coordinate_of_light_ring={k: fl(v) for k, v in coord.items()}, coordinate_split=fl(split))


# ================================================================================================ SB: holes
def _star(Rs, M=1.0):
    """Constant-density star (interior Schwarzschild solution) joined to the exterior solution."""
    def A(r):
        return (1.5 * math.sqrt(1 - 2 * M / Rs) - 0.5 * math.sqrt(1 - 2 * M * r * r / Rs ** 3)) ** 2 if r < Rs else 1 - 2 * M / r
    def B(r):
        return 1 / (1 - 2 * M * r * r / Rs ** 3) if r < Rs else 1 / (1 - 2 * M / r)
    return A, B


def _deflection(A, B, b):
    """Total deflection of a light ray of impact parameter b; the ray stays outside the turning radius."""
    r0 = brentq(lambda r: r * r / A(r) - b * b, 7.0, 40.0)
    f = lambda w: math.sqrt(B(r0 / (1 - w * w))) / math.sqrt(max((r0 / (1 - w * w)) ** 2 / (A(r0 / (1 - w * w)) * b * b) - 1, 1e-300)) \
        / (r0 / (1 - w * w)) * 2 * w * r0 / (1 - w * w) ** 2
    return 2 * quad(f, 0, 1, epsabs=1e-11, limit=200)[0] - math.pi, r0


def _pp_wave():
    """Plane-fronted wave ds^2 = -2 du dv + f(u)(x^2 - y^2) du^2 + dx^2 + dy^2: curvature by sympy."""
    u, v, x, y = sp.symbols('u v x y'); f = sp.Function('f')(u); X = [u, v, x, y]; H = f * (x ** 2 - y ** 2)
    g = sp.Matrix([[H, -1, 0, 0], [-1, 0, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]); gi = g.inv()
    Gam = [[[sum(gi[a, d] * (sp.diff(g[d, b], X[c]) + sp.diff(g[d, c], X[b]) - sp.diff(g[b, c], X[d])) for d in range(4)) / 2 for c in range(4)] for b in range(4)] for a in range(4)]
    def riem(a, b, c, d):                                                  # R^a_{bcd}
        return sp.diff(Gam[a][b][d], X[c]) - sp.diff(Gam[a][b][c], X[d]) + sum(Gam[a][c][e] * Gam[e][b][d] - Gam[a][d][e] * Gam[e][b][c] for e in range(4))
    Rm = [[[[sp.simplify(riem(a, b, c, d)) for d in range(4)] for c in range(4)] for b in range(4)] for a in range(4)]
    low = [[[[sp.simplify(sum(g[a, e] * Rm[e][b][c][d] for e in range(4))) for d in range(4)] for c in range(4)] for b in range(4)] for a in range(4)]
    ric = sp.Matrix(4, 4, lambda b, d: sp.simplify(sum(Rm[a][b][a][d] for a in range(4))))
    idx = list(itertools.product(range(4), repeat=4))
    up = lambda T: [[[[sum(gi[a, p] * gi[b, q] * T[p][q][c][d] for p in range(4) for q in range(4)) for d in range(4)] for c in range(4)] for b in range(4)] for a in range(4)]
    mixed = up(low)                                                        # R^{ab}_{cd}
    kret = sp.simplify(sum(mixed[a][b][c][d] * mixed[c][d][a][b] for a, b, c, d in idx))
    cubic = sp.simplify(sum(mixed[a][b][c][d] * mixed[c][d][e][h] * mixed[e][h][a][b] for a, b, c, d in idx for e in range(4) for h in range(4)
                            if mixed[a][b][c][d] != 0))
    # observer at rest on the axis x = y = 0: k = (d_u + d_v) / sqrt 2 is unit timelike there
    k = [1 / sp.sqrt(2), 1 / sp.sqrt(2), 0, 0]
    tidal = sp.Matrix(2, 2, lambda i, j: sp.simplify(sum(low[2 + i][a][2 + j][b] * k[a] * k[b] for a in range(4) for b in range(4))))
    return ric, kret, cubic, sp.simplify(low[0][2][0][2]), tidal, f


def SB():
    stars = {Rs: _star(Rs) for Rs in (4.0, 6.0)}; ext, inn = {}, {}
    for Rs, (A, B) in stars.items():
        d = 1e-5; defl, r0 = _deflection(A, B, 12.0)
        ext[Rs] = dict(orbital_frequency_at_10=math.sqrt((A(10 + d) - A(10 - d)) / ((10 + d) ** 2 - (10 - d) ** 2)), redshift_8_to_20=math.sqrt(A(20.0) / A(8.0)),
                       deflection_b_12=defl, turning_radius=r0, light_time_8_to_20=quad(lambda r: math.sqrt(B(r) / A(r)), 8.0, 20.0, epsabs=1e-12)[0])
        inn[Rs] = dict(central_redshift=math.sqrt(A(0.0)), light_time_through_centre=2 * quad(lambda r: math.sqrt(B(r) / A(r)), 0.0, 8.0, points=[Rs], epsabs=1e-12)[0])
    same = max(abs(ext[4.0][k] / ext[6.0][k] - 1) for k in ext[4.0]); differ = min(abs(inn[4.0][k] / inn[6.0][k] - 1) for k in inn[4.0])
    weak = abs(ext[4.0]['deflection_b_12'] / (4 / 12.0 + 15 * math.pi / 4 / 144.0) - 1)   # second-order weak-field value, for orientation only
    ric, kret, cubic, comp, tidal, f = _pp_wave()
    vsi = ric == sp.zeros(4, 4) and kret == 0 and cubic == 0
    tid = sp.simplify(tidal[0, 0] + tidal[1, 1]) == 0 and sp.simplify(tidal[0, 0] ** 2 - f ** 2 / 4) == 0 and comp != 0
    ok = same < 1e-9 and differ > 0.15 and ext[4.0]['turning_radius'] > 6.0 and weak < 0.15 and vsi and tid
    must(ok, 'SB')
    R['SB'] = dict(claim='Holes (H-compl fails). (a) Two constant-density stars of equal mass and radii 4M and 6M are not isometric: '
                         'the central redshift and the light time through the centre differ by 23 and 20 per cent. Every '
                         'record of an exterior protocol (orbital frequency, redshift, light time, deflection of a ray that turns at '
                         '10.9M) is identical. The kernel class of the exterior protocol contains both: it is larger than a '
                         'gauge orbit, and the radius is a hole. (b) A plane-fronted gravitational wave has zero Ricci tensor and '
                         'zero quadratic and cubic curvature invariants (all scalar invariants vanish: imported), and a nonzero '
                         'tidal tensor diag(-f/2, f/2) for an observer on the axis. The scalar-invariant protocol cannot separate '
                         'the wave from flat space; the tidal protocol does. Canaries: the interior record and the tidal record.',
                   status='computed; vanishing of all scalar invariants IMPORTED', exterior_records={str(k): {a: fl(b) for a, b in v.items()} for k, v in ext.items()},
                   interior_records={str(k): {a: fl(b) for a, b in v.items()} for k, v in inn.items()}, exterior_relative_difference=below(same, 1e-10),
                   interior_relative_difference_min=fl(differ), wave=dict(ricci_zero=bool(ric == sp.zeros(4, 4)), kretschmann=str(kret), cubic_invariant=str(cubic),
                                                                           riemann_uxux=str(comp), tidal_xx=str(tidal[0, 0]), tidal_yy=str(tidal[1, 1])))


# ================================================================================================ SC: Petrov walls
NB = np.array([[1, 1j, 0], [1j, -1, 0], [0, 0, 0]])
TYPES = {'I': np.diag([1.0, 0.3 + 0.4j, -1.3 - 0.4j]), 'II': 0.7 * np.diag([1, 1, -2]) + NB, 'D': 0.7 * np.diag([1.0, 1, -2]) + 0j,
         'III': np.array([[0, 0, 1], [0, 0, 1j], [1, 1j, 0]]), 'N': NB.copy(), 'O': np.zeros((3, 3), complex)}
GEN = [np.array([[0, 0, 0], [0, 0, -1], [0, 1, 0]]), np.array([[0, 0, 1], [0, 0, 0], [-1, 0, 0]]), np.array([[0, -1, 0], [1, 0, 0], [0, 0, 0]])]


def _rank(vecs, tol=1e-9):
    s = np.linalg.svd(np.array([v.ravel() for v in vecs]), compute_uv=False); return int(np.sum(s > tol * max(1.0, s[0])))


def _field(Q):
    """Rank of the differentials of (tr Q^2, tr Q^3) and dimension of the stabilizer in the complex rotation group."""
    Q2 = Q @ Q; grad = [Q, Q2 - np.trace(Q2) / 3 * np.eye(3)]
    return _rank(grad), 3 - _rank([K @ Q - Q @ K for K in GEN]), np.trace(Q2), np.trace(Q2 @ Q)


def _boost(t):
    return np.array([[math.cosh(t), 1j * math.sinh(t), 0], [-1j * math.sinh(t), math.cosh(t), 0], [0, 0, 1]])


def SC():
    rng = np.random.default_rng(SEED + 1); table = {}; stable = True
    for name, Q in TYPES.items():
        base = _field(Q)
        for _ in range(20):                                                # rank and stabilizer are constant on the orbit
            Rc = expm(sum((rng.normal() + 1j * rng.normal()) * K for K in GEN)); Qr = Rc @ Q @ Rc.T; got = _field(Qr)
            stable &= got[:2] == base[:2] and abs(got[2] - base[2]) < 1e-7 * (1 + abs(base[2])) and abs(got[3] - base[3]) < 1e-7 * (1 + abs(base[3])) \
                and np.allclose(Rc.T @ Rc, np.eye(3), atol=1e-9)
        table[name] = dict(rank=base[0], stabilizer_dimension=base[1], orbit_dimension=3 - base[1], I=[fl(base[2].real), fl(base[2].imag)], J=[fl(base[3].real), fl(base[3].imag)])
    expect = {'I': (2, 0), 'II': (2, 0), 'D': (1, 1), 'III': (2, 0), 'N': (1, 1), 'O': (0, 3)}
    walls = all((table[k]['rank'], table[k]['stabilizer_dimension']) == v for k, v in expect.items())
    law = all((table[k]['rank'] < 2) == (table[k]['stabilizer_dimension'] > 0) for k in table)
    # holes: equal invariants on different orbits
    same_II_D = abs(_field(TYPES['II'])[2] - _field(TYPES['D'])[2]) + abs(_field(TYPES['II'])[3] - _field(TYPES['D'])[3])
    null = max(abs(_field(TYPES[k])[i]) for k in ('III', 'N', 'O') for i in (2, 3))
    # non-closed orbits: a boost carries II into D and N into O in the limit, never at finite rapidity
    dist = [float(np.linalg.norm(_boost(t) @ TYPES['II'] @ _boost(t).T - TYPES['D'])) for t in (1.0, 2.0, 3.0, 4.0)]
    ratio = [dist[i + 1] / dist[i] for i in range(3)]
    distN = [float(np.linalg.norm(_boost(t) @ TYPES['N'] @ _boost(t).T)) for t in (1.0, 2.0, 3.0, 4.0)]
    closure = all(abs(r - math.exp(-2)) < 1e-9 for r in ratio) and distN[-1] < 1e-3 * np.linalg.norm(TYPES['N']) and dist[-1] > 0
    ok = stable and walls and law and same_II_D < 1e-12 and null < 1e-12 and closure and table['I']['rank'] == 2
    must(ok, 'SC')
    R['SC'] = dict(claim='Walls and holes of the pointwise curvature-invariant protocol. Weyl tensors are complex symmetric traceless '
                         '3 x 3 matrices under complex rotations (the Lorentz group); the records are I = tr Q^2 and J = tr Q^3. Rank '
                         'of the record map and dimension of the stabilizer by Petrov type: I (2, 0), II (2, 0), D (1, 1), III (2, 0), '
                         'N (1, 1), O (0, 3). The rank drops exactly where the stabilizer is continuous: the walls of the protocol '
                         'are the symmetric strata D, N, O. Separately, the protocol has holes that are not walls: II and D have '
                         'equal records, and III, N and O all have records (0, 0). These orbits are not closed: a boost of rapidity '
                         't brings II within e^(-2t) of D and N within e^(-2t) of O, so no continuous invariant separates them. '
                         'Canary: the generic type has full rank and a discrete stabilizer.',
                   status='computed; PROVED for compact groups (slice argument)', types=table, rank_constant_on_orbits=bool(stable), wall_iff_continuous_stabilizer=bool(law),
                   distance_II_to_D_under_boost=[fl(v) for v in dist], contraction_per_unit_rapidity=[fl(v) for v in ratio], distance_N_to_O_under_boost=[fl(v) for v in distN])


# ================================================================================================ SD: observer included
def _sym0(p):
    return np.array([[p[0], p[2], p[3]], [p[2], p[1], p[4]], [p[3], p[4], -p[0] - p[1]]])


def _obs_inv(p):
    E, B = _sym0(p[:5]), _sym0(p[5:]); t = np.trace
    return np.array([t(E @ E), t(B @ B), t(E @ B), t(E @ E @ E), t(E @ E @ B), t(E @ B @ B), t(B @ B @ B), t(E @ E @ B @ B), t(E @ B @ E @ B)])


def _obs_rank(p, h=1e-5, tol=1e-6):
    J = np.array([(_obs_inv(p + h * e) - _obs_inv(p - h * e)) / (2 * h) for e in np.eye(10)]).T
    s = np.linalg.svd(J, compute_uv=False); return int(np.sum(s > tol * s[0])) if s[0] > 0 else 0


def _params(Q):
    E, B = Q.real, Q.imag
    return np.array([E[0, 0], E[1, 1], E[0, 1], E[0, 2], E[1, 2], B[0, 0], B[1, 1], B[0, 1], B[0, 2], B[1, 2]])


def _fixed_slice_dim(p, extra=()):
    """dim N^H at p: H = stabilizer in the rotation group (its Lie algebra, plus supplied discrete elements).
    N^H = V^H / (T^H), V = R^10, T = tangent of the orbit. This is the upper bound of the slice argument."""
    act = lambda K, q: np.concatenate([_params_real(K @ _sym0(q[:5]) - _sym0(q[:5]) @ K), _params_real(K @ _sym0(q[5:]) - _sym0(q[5:]) @ K)])
    tang = np.array([act(K, p) for K in GEN]); U, sv, _ = np.linalg.svd(tang)
    lie = [sum(U[i, k] * GEN[i] for i in range(3)) for k in range(3) if sv[k] < 1e-9]                          # stabilizer algebra
    ops = [np.array([act(K, e) for e in np.eye(10)]).T for K in lie]
    for Rd in extra:
        ops.append(np.array([np.concatenate([_params_real(Rd @ _sym0(e[:5]) @ Rd.T), _params_real(Rd @ _sym0(e[5:]) @ Rd.T)]) for e in np.eye(10)]).T - np.eye(10))
    if ops:
        _, sv2, vt2 = np.linalg.svd(np.vstack(ops)); VH = vt2[np.sum(sv2 > 1e-9):]
    else:
        VH = np.eye(10)
    rT = np.linalg.matrix_rank(tang, tol=1e-9); both = np.linalg.matrix_rank(np.vstack([tang, VH]), tol=1e-9) if len(VH) else rT
    return len(VH) - (rT + len(VH) - both), len(lie)


def _params_real(S):
    return np.array([S[0, 0], S[1, 1], S[0, 1], S[0, 2], S[1, 2]])


def SD():
    rng = np.random.default_rng(SEED + 2)
    generic = [_obs_rank(rng.normal(size=10)) for _ in range(12)]
    # invariance under real rotations; non-invariance of the observer invariants under a boost
    inv_err = 0.0
    for _ in range(12):
        p = rng.normal(size=10); Q = _sym0(p[:5]) + 1j * _sym0(p[5:]); Ro = expm(sum(rng.normal() * K for K in GEN)); Qr = Ro @ Q @ Ro.T
        inv_err = max(inv_err, float(np.max(np.abs(_obs_inv(_params(Qr)) - _obs_inv(p)))))
    inv = {k: _obs_inv(_params(Q)) for k, Q in TYPES.items()}
    sep = {f'{a} from {b}': float(np.max(np.abs(inv[a] - inv[b]))) for a, b in (('II', 'D'), ('III', 'N'), ('III', 'O'), ('N', 'O'))}
    energy = lambda Q: float(np.trace(Q @ Q.conj()).real)                   # tr E^2 + tr B^2
    boosted = [energy(_boost(t) @ TYPES['N'] @ _boost(t).T) for t in (0.0, 0.5, 1.0)]
    # walls of the observer protocol: rank of the nine invariants against the bound dim N^H of the slice argument
    half_turn = np.diag([-1.0, -1.0, 1.0])                                 # rotation by pi about the direction of propagation
    pts = {'generic': (rng.normal(size=10), ()), 'static observer near a spherical mass': (_params(np.diag([-2.0, 1.0, 1.0]) + 0j), ()),
           'plane wave': (_params(TYPES['N']), (half_turn,)), 'flat': (np.zeros(10), ())}
    table = {}
    for name, (p, extra) in pts.items():
        bound, cont = _fixed_slice_dim(p, extra)
        table[name] = dict(rank=_obs_rank(p), bound_from_slice=int(bound), stabilizer_dimension=int(cont), discrete_symmetry=bool(extra))
    wave_fixed = float(np.max(np.abs(half_turn @ TYPES['N'] @ half_turn.T - TYPES['N'])))
    ok = min(generic) == 7 and max(generic) == 7 and inv_err < 1e-9 and min(sep.values()) > 0.5 and abs(boosted[1] / boosted[0] - math.exp(-2.0)) < 1e-9 \
        and all(v['rank'] == v['bound_from_slice'] for v in table.values()) and [table[k]['rank'] for k in pts] == [7, 2, 5, 0] \
        and [table[k]['stabilizer_dimension'] for k in pts] == [0, 1, 0, 3] and wave_fixed < 1e-15
    must(ok, 'SD')
    R['SD'] = dict(claim='The observer included. With a four-velocity the field splits into E and B and the group is the compact '
                         'rotation group; nine rotation invariants of the pair have generic rank 7 = 10 - 3 and are invariant to 1e-9. '
                         'They separate what the field invariants could not: II from D, and III, N, O from one another. They are '
                         'records of the pair (field, observer): under a boost of rapidity 1/2 the value of tr E^2 + tr B^2 for the '
                         'wave changes by e^(-2), so it is not a field invariant (canary). Walls are the points with a nontrivial '
                         'stabilizer, and the rank equals the bound dim N^H of the slice argument in every case: generic 7; a static '
                         'observer near a spherical mass, E = diag(-2, 1, 1), B = 0, stabilizer of dimension 1, rank 2; a plane '
                         'wave, discrete stabilizer of order 2 (half turn about the direction of propagation), rank 5; flat space, '
                         'rank 0. A discrete symmetry is enough for a wall.',
                   status='PROVED (slice argument, compact group) + computed; separation of orbits by invariants of a compact group IMPORTED',
                   generic_rank=generic, invariance_error=below(inv_err, 1e-10), separation={k: fl(v) for k, v in sep.items()}, wave_energy_under_boost=[fl(v) for v in boosted], walls=table)


# ================================================================================================ SE: composition
def SE():
    rng = np.random.default_rng(SEED + 3)
    # 4 gauge orbits x 3 gauge copies; complete protocol with 6 outcomes. Orbits 0, 1 differ only inside outcomes {0, 1};
    # orbits 2, 3 differ only inside outcomes {4, 5}.
    b = rng.dirichlet(np.ones(6), size=2); p = np.array([b[0], b[0].copy(), b[1], b[1].copy()])
    p[1, 0], p[1, 1] = b[0, 0] * 0.3, b[0, 1] + b[0, 0] * 0.7; p[3, 4], p[3, 5] = b[1, 4] * 0.2, b[1, 5] + b[1, 4] * 0.8
    F = np.repeat(p, 3, axis=0)                                            # law of each of the 12 solutions
    K1 = np.zeros((5, 6)); K1[[0, 1, 2, 3, 4, 4], range(6)] = 1            # merge outcomes 4 and 5
    K2 = np.zeros((4, 5)); K2[[0, 0, 1, 2, 3], range(5)] = 1               # merge outcomes 0 and 1
    K3 = rng.dirichlet(np.ones(4), size=4).T                               # noise: a generic stochastic map, no merging
    def classes(L):
        lab, reps = [], []
        for row in L:
            for i, r in enumerate(reps):
                if np.max(np.abs(row - r)) < 1e-12:
                    lab.append(i); break
            else:
                reps.append(row); lab.append(len(reps) - 1)
        return lab
    L1 = F @ K1.T; L2 = L1 @ K2.T; L3 = L2 @ K3.T
    c0, c1, c2, c3 = classes(F), classes(L1), classes(L2), classes(L3)
    sound = all(len(set(c0[3 * i:3 * i + 3])) == 1 for i in range(4)); n = [len(set(c)) for c in (c0, c1, c2, c3)]
    refine = lambda a, c: all(len({c[i] for i in range(12) if a[i] == k}) == 1 for k in set(a))
    assoc = float(np.max(np.abs(L3 - F @ (K3 @ K2 @ K1).T)))
    stoch = all(abs(K.sum(0) - 1).max() < 1e-12 and K.min() >= 0 for K in (K1, K2, K3))
    tv = lambda x, y: 0.5 * np.abs(x - y).sum()
    pairs = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
    contr = max(max(tv(K1 @ p[i], K1 @ p[j]) - tv(p[i], p[j]), tv(K2 @ K1 @ p[i], K2 @ K1 @ p[j]) - tv(K1 @ p[i], K1 @ p[j]),
                    tv(K3 @ K2 @ K1 @ p[i], K3 @ K2 @ K1 @ p[j]) - tv(K2 @ K1 @ p[i], K2 @ K1 @ p[j])) for i, j in pairs)
    # noise loses information without changing the kernel
    noise_ratio = tv(K3 @ K2 @ K1 @ p[0], K3 @ K2 @ K1 @ p[2]) / tv(K2 @ K1 @ p[0], K2 @ K1 @ p[2])
    # canary: a map that is not stochastic expands total variation
    bad = np.array([[2.0, -1, 0, 0, 0, 0], [-1, 2, 0, 0, 0, 0], [0, 0, 1, 0, 0, 0], [0, 0, 0, 1, 0, 0], [0, 0, 0, 0, 1, 1]])
    expand = max(tv(bad @ p[i], bad @ p[j]) - tv(p[i], p[j]) for i, j in pairs)
    # gauge maps are invertible and act as the identity on every quotient
    perm = np.arange(12).reshape(4, 3)[:, [1, 2, 0]].ravel(); gauge_trivial = bool(np.max(np.abs(F[perm] - F)) < 1e-15)
    # two filtrations over the same moduli set {0, 1, 2, 3}: block profiles (2, 2) and (1, 3); no relabeling relates them
    profile = lambda part: tuple(sorted(len(blk) for blk in part))
    part_a, part_b = [{0, 1}, {2, 3}], [{0}, {1, 2, 3}]
    related = any(sorted(sorted(pm[i] for i in blk) for blk in part_a) == sorted(sorted(blk) for blk in part_b) for pm in itertools.permutations(range(4)))
    ok = sound and n == [4, 3, 2, 2] and refine(c0, c1) and refine(c1, c2) and not refine(c1, c0) and not refine(c2, c1) and c2 == c3 and assoc < 1e-15 and stoch \
        and contr < 1e-15 and noise_ratio < 0.9 and expand > 0.05 and gauge_trivial and not related and profile(part_a) != profile(part_b)
    must(ok, 'SE')
    R['SE'] = dict(claim='Composition and filtration. Twelve solutions in four gauge orbits; the complete protocol is constant on orbits and '
                         'separates them (quotient of 4 points, equal to the moduli set). Two garblings that merge outcomes give 3 and '
                         'then 2 points: kernels only grow, the specialization maps compose (associativity exact), and none has an '
                         'inverse because none is injective. A third garbling by generic noise leaves the quotient at 2 points and '
                         'still loses information: total variation, which never increases, drops to a fraction. Gauge maps are '
                         'invertible and act as the identity on every quotient. Hence the category with gauge maps only is a groupoid '
                         'and the category with garblings is not; they are not equivalent. Two chains of quotients over the same four '
                         'moduli points, with blocks (2, 2) and (1, 3), are related by none of the 24 relabelings: the filtration is '
                         'structure that the moduli set does not determine. Canary: a non-stochastic map expands total variation.',
                   status='PROVED + computed', quotient_sizes=n, complete_protocol_sound=bool(sound), composition_defect=below(assoc, 1e-14), max_total_variation_increase=below(contr, 1e-14),
                   noise_total_variation_ratio=fl(noise_ratio), non_stochastic_expansion=fl(expand), gauge_acts_trivially=gauge_trivial,
                   filtrations_related_by_relabeling=bool(related), filtration_profiles=[list(profile(part_a)), list(profile(part_b))])


# ================================================================================================ SF: transport
def _geo(chart, y0, s1, stop_T=None):
    """Geodesic in Misner space. Chart A: g = dT dpsi + T dpsi^2. Chart B: g = -dT dpsi + T dpsi^2. y = (T, psi, T', psi')."""
    sg = 1.0 if chart == 'A' else -1.0
    def rhs(s, y):
        T, ps, Td, pd = y; pdd = sg * pd * pd
        return [Td, pd, -sg * 2 * (Td * pd + T * pdd), pdd]
    ev = None
    if stop_T is not None:
        ev = lambda s, y: y[0] - stop_T; ev.terminal = True
    return solve_ivp(rhs, (0, s1), y0, rtol=1e-11, atol=1e-13, events=ev, dense_output=True)


def SF():
    a = 1.0                                                                # period of the Milne angle phi
    # the two charts are one metric on T > 0 (psi_B = psi_A + ln T), flat, and regular at T = 0
    T, ps = sp.symbols('T psi'); gA = sp.Matrix([[0, sp.Rational(1, 2)], [sp.Rational(1, 2), T]]); gB = sp.Matrix([[0, -sp.Rational(1, 2)], [-sp.Rational(1, 2), T]])
    Jm = sp.Matrix([[1, 0], [1 / T, 1]]); same = sp.simplify(Jm.T * gB * Jm - gA) == sp.zeros(2, 2)
    def gauss(g):
        X = [T, ps]; gi = g.inv()
        G = [[[sum(gi[i, l] * (sp.diff(g[l, j], X[k]) + sp.diff(g[l, k], X[j]) - sp.diff(g[j, k], X[l])) for l in range(2)) / 2 for k in range(2)] for j in range(2)] for i in range(2)]
        return sp.simplify(sum(g[0, i] * (sp.diff(G[i][1][1], X[0]) - sp.diff(G[i][1][0], X[1]) + sum(G[i][0][e] * G[e][1][1] - G[i][1][e] * G[e][1][0] for e in range(2))) for i in range(2)))
    flat = gauss(gA) == 0 and gauss(gB) == 0 and gA.det() == -sp.Rational(1, 4) and gB.det() == -sp.Rational(1, 4)
    # pulse P1 (psi_A = const) and pulse P2 (psi_B = const), emitted at T = 1, Milne angle 0, toward decreasing T
    init = {('A', 'P1'): [1.0, 0.0, -1.0, 0.0], ('B', 'P1'): [1.0, 0.0, -1.0, -1.0], ('A', 'P2'): [1.0, 0.0, -1.0, 1.0], ('B', 'P2'): [1.0, 0.0, -1.0, 0.0]}
    null = max(abs((1 if c == 'A' else -1) * y[2] * y[3] + y[0] * y[3] ** 2) for (c, _), y in init.items())
    # inside: the comoving observer (Milne angle 0) receives P1 after one circuit; proper time in both charts
    inside = {}
    for c in ('A', 'B'):
        sol = _geo(c, init[(c, 'P1')], 0.95); sg = 1 if c == 'A' else -1
        # Milne angle of the pulse: phi = psi_A + ln(T)/2 = psi_B - ln(T)/2; reception when phi = -a
        phi = lambda s: sol.sol(s)[1] + sg * 0.5 * math.log(sol.sol(s)[0]) + a
        if not (np.all(sol.sol(np.linspace(1e-6, 0.94, 200))[0] > 0) and phi(1e-6) * phi(0.94) < 0):
            inside[c] = dict(T_reception=float('nan'), proper_time=float('nan'), chart_coordinate_of_reception=float('nan'))
            continue                                                    # no reception inside: the claim fails, recorded below
        s_rec = brentq(phi, 1e-6, 0.94); T_rec = float(sol.sol(s_rec)[0])
        # observer worldline phi = 0: psi = -sg ln(T)/2; proper time by quadrature of sqrt(-g(x', x')) in the chart
        speed = lambda Tt: math.sqrt(max(-(sg * (-sg / (2 * Tt)) + Tt * (1 / (2 * Tt)) ** 2), 0.0))
        inside[c] = dict(T_reception=T_rec, proper_time=quad(speed, T_rec, 1.0, epsabs=1e-13)[0], chart_coordinate_of_reception=float(sol.sol(s_rec)[1]))
    exact = 1 - math.exp(-a)
    agree = abs(inside['A']['proper_time'] / inside['B']['proper_time'] - 1); coord_gap = abs(inside['A']['chart_coordinate_of_reception'] - inside['B']['chart_coordinate_of_reception'])
    # beyond: does the pulse reach T = -1/2 ?
    beyond = {}
    for (c, pz), y0 in init.items():
        sol = _geo(c, y0, 1.6, stop_T=-0.5) if abs(y0[3]) < 1e-15 else _geo(c, y0, 1 - 1e-6)
        Tend, pend = float(sol.y[0, -1]), float(sol.y[1, -1]); arrives = bool(sol.status == 1 and abs(Tend + 0.5) < 1e-9)
        beyond[f'{pz} in extension {c}'] = dict(arrives_at_T_minus_half=arrives, affine_parameter_at_end=float(sol.t[-1]), T_at_end=Tend, winding_at_end=abs(pend) / a,
                                                linear_T_defect=float(np.max(np.abs(sol.y[0] - (1 - sol.t)))), winding_minus_log=abs(abs(pend) - abs(math.log(max(abs(Tend), 1e-300)))))
    spiral = all((not v['arrives_at_T_minus_half']) and v['winding_at_end'] > 13 and v['T_at_end'] > 0 and v['affine_parameter_at_end'] < 1 for k, v in beyond.items()
                 if k in ('P1 in extension B', 'P2 in extension A'))
    cross = all(v['arrives_at_T_minus_half'] and v['winding_at_end'] < 1e-9 and abs(v['affine_parameter_at_end'] - 1.5) < 1e-8 for k, v in beyond.items()
                if k in ('P1 in extension A', 'P2 in extension B'))
    logdef = abs(beyond['P1 in extension B']['winding_at_end'] * a - abs(math.log(1e-6)))
    record = {pz: sorted({v['arrives_at_T_minus_half'] for k, v in beyond.items() if k.startswith(pz)}) for pz in ('P1', 'P2')}
    two_valued = all(v == [False, True] for v in record.values())
    # closed timelike curves beyond the horizon: the circle T = const has tangent norm T
    ctc = dict(norm_at_T_minus_half=-0.5, norm_at_T_plus_half=0.5)
    ok = same and flat and null < 1e-15 and abs(inside['A']['proper_time'] - exact) < 1e-8 and agree < 1e-8 and coord_gap > 0.5 and spiral and cross and logdef < 1e-3 \
        and two_valued and max(v['linear_T_defect'] for v in beyond.values()) < 1e-7 and ctc['norm_at_T_minus_half'] < 0 < ctc['norm_at_T_plus_half']
    must(ok, 'SF')
    R['SF'] = dict(claim='Transport. Misner space: the contracting Milne region with a periodic angle, in two charts that are one flat '
                         'metric there and are both regular across T = 0. Inside the domain of dependence the transport of records '
                         'is a function of the data: the proper time until a comoving observer receives a pulse after one circuit '
                         'is 1 - 1/e in both charts to 1e-9 (canary: the chart coordinate of the reception event differs by 2). '
                         'Beyond the Cauchy horizon the two charts are two different flat extensions of the same data. A pulse '
                         'that crosses in one extension and is received at T = -1/2 winds without bound in the other and ends at '
                         'finite affine parameter; for the opposite pulse the roles are exchanged. The record beyond the horizon '
                         'is therefore two-valued on one initial datum: the transport is a correspondence and not a map. Beyond the '
                         'horizon the circles T = const are closed timelike curves.',
                   status='computed; uniqueness inside the domain of dependence IMPORTED (Choquet-Bruhat, Geroch)', charts_agree_inside=bool(same), flat_and_regular=bool(flat),
                   inside={c: {k: fl(v) for k, v in d.items()} for c, d in inside.items()}, exact_proper_time=fl(exact), proper_time_relative_difference=below(agree, 1e-9),
                   chart_coordinate_gap=fl(coord_gap), beyond={k: {a_: (b if isinstance(b, bool) else below(b, 1e-6) if a_ in ('linear_T_defect', 'winding_minus_log', 'winding_at_end') else fl(round(b, 9))) for a_, b in v.items()} for k, v in beyond.items()},
                   record_values_per_pulse={k: v for k, v in record.items()}, closed_curve_tangent_norm=ctc)


if __name__ == '__main__':
    for name, fn in (('SA', SA), ('SB', SB), ('SC', SC), ('SD', SD), ('SE', SE), ('SF', SF)):
        fn(); print(name, flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(open(os.path.abspath(__file__), 'rb').read()).hexdigest()
    json.dump(out, open(os.path.join(HERE, 'rg_gr_equivalence_results.json'), 'w'), indent=1, sort_keys=True)
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
