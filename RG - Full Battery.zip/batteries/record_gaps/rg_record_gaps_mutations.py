#!/usr/bin/env python3
"""Mutation suite for rg_record_gaps.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. A few minutes.

    python3 -I rg_record_gaps_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('QA', 'Einstein time without the lapse factor', "at = -2 * (g / N) * (x * xd + y * yd) * td", "at = 0.0 * td"),
    ('QA', 'Newton in the Coulomb potential instead of Phi_kin', "dPhi = lambda r: (m / r ** 2) / Nf(r) ** 4", "dPhi = lambda r: (m / r ** 2)"),
    ('QB', 'effective potential without the angular term', "L2 = m * r * r / (r - 3 * m); V = lambda q: (1 - 2 * m / q) * (1 + L2 / q ** 2)", "L2 = m * r * r / (r - 3 * m); V = lambda q: (1 - 2 * m / q) * (1 + L2 / q ** 3 * r)"),
    ('QC', 'orbiting observer at rest', "u = np.array([ut, 0, 0, ut * Om]);", "u = np.array([1 / math.sqrt(1 - 2 / rv), 0, 0, 0]);"),
    ('QD', 'back-action at half the quantum value', "D = np.diag([0.0, hbar ** 2 * k if backaction else 0.0]);", "D = np.diag([0.0, 0.5 * hbar ** 2 * k if backaction else 0.0]);"),
    ('QE', 'tracking limit without the hyperbolic growth', "bound = hb * math.sinh(2 * lam * tau) / (2 * mm * lam)", "bound = hb * tau / mm"),
    ('QF', 'probe horizon dropped', "f = lambda lm: math.sqrt(hbar * L / (math.exp(lm) * C)) + 2 * G * math.exp(lm) / C ** 2", "f = lambda lm: math.sqrt(hbar * L / (math.exp(lm) * C)) + 2 * G * math.exp(lm) / C ** 2 * 0"),
]


def main():
    base = open(os.path.join(HERE, 'rg_record_gaps.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_record_gaps.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_record_gaps.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_record_gaps_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
