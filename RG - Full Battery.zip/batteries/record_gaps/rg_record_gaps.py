#!/usr/bin/env python3
"""Resolution Geometry - record gaps: where record dynamics separates Newton, Einstein and quantum mechanics.

Newton against Einstein
  QA timing lifts the single-speed no-go. On a static field with flat structure h and lapse N, Newton in
     Phi_kin = (1 - N^-2)/2 reproduces every trajectory exactly, so no single-speed deflection panel refutes him. The
     clock does: along the common path the Einstein coordinate speed is exactly N^2 times the Newtonian one. Checked by
     integrating the full geodesic equations and Newton's equations independently: paths agree, arrival times do not.
     Canary: N = 1, where both agree
  QB the orbit frontier. Newton's circular orbits are stable at every radius (epicyclic kappa^2 = m/r^3): forecasting
     them needs no record rate. Einstein's become unstable inside r = 6m, with exponent sqrt(-kappa^2), so they need
     records at sqrt(-kappa^2)/ln 2 bits per unit time
  QC the tidal frontier on orbits. On a circular geodesic of Schwarzschild the tidal tensor is
     (m/r^3) diag(-(2r - 3m)/(r - 3m), r/(r - 3m), 1) (computed from the Riemann tensor), against Newton's
     (m/r^3) diag(-2, 1, 1): the radial record rate exceeds Newton's by sqrt((2r - 3m)/(2(r - 3m))), which diverges at
     the light ring. Canary: a radially falling observer sees exactly Newton's tensor
Einstein against quantum mechanics
  QD the volume ceiling. Quantum records of position (strength k) carry back-action: record gain 4k on x forces
     ignorance inflow hbar^2 k on p. The record Hessian flow then keeps det V >= (hbar/2)^2, with equality for
     efficient records, for free, bound and unstable dynamics. Canary: records without back-action drive det V to 0
  QE the tracking limit. For position records without correlations, the forecast of an unstable (tidal) coordinate
     over a horizon tau has Var >= hbar sinh(2 lambda tau)/(2 m lambda) (hbar tau/m for a free mass). Canary: a
     correlated (squeezed) state beats it: the bound is a protocol limit, not a law
Both
  QF the geometry frontier. A probe that holds a length L over the light time pays sqrt(hbar L/(m c)) in quantum
     spread and 2Gm/c^2 in its own horizon: the best mass leaves delta L ~ (l_P^2 L)^(1/3). Canaries: without G or
     without hbar there is no floor. The one-loop quantum correction to the Newtonian potential moves the tidal record
     rate by about 3 (41/(10 pi)) l_P^2/r^2: 1e-69 at one metre

Deterministic. Seed 20261209. Writes rg_record_gaps_results.json.
Run:  python3 -I rg_record_gaps.py      (numpy, scipy, sympy)
"""
import hashlib, json, math, sys
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.integrate import solve_ivp
from scipy.optimize import minimize_scalar, brentq

HERE = Path(__file__).resolve().parent
SEED = 20261209
R, FAILS = {}, []
HBAR = 1.054571817e-34; G_N = 6.67430e-11; C = 299792458.0; LP = math.sqrt(HBAR * G_N / C ** 3)


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.8g}')


def below(v, b):
    return f'< {b:g}' if abs(v) < b else fl(v)


# ============================================================================================ QA
def QA(m=1.0, probes=((0.5, 30.0), (0.5, 12.0), (0.9, 15.0)), record=True):
    m = float(m); Nf = lambda r: math.sqrt(1 - 2 * m / r); dN = lambda r: (m / r ** 2) / math.sqrt(1 - 2 * m / r)     # flat h, N^2 = 1 - 2m/r
    out = {}
    for v, b in probes:
        x0, y0 = -4000.0, b
        # Einstein: geodesics of -N^2 dt^2 + dx^2 + dy^2 in an affine parameter; state (t, x, y, tdot, xdot, ydot)
        E = 1 / math.sqrt(1 - v * v); r0 = math.hypot(x0, y0); tdot0 = E / Nf(r0) ** 2
        sp_ = math.sqrt(E ** 2 / Nf(r0) ** 2 - 1)
        def geo(s, z):
            t, x, y, td, xd, yd = z; r = math.hypot(x, y); N = Nf(r); g = dN(r) / r
            ax = -N * g * x * td ** 2; ay = -N * g * y * td ** 2; at = -2 * (g / N) * (x * xd + y * yd) * td
            return [td, xd, yd, at, ax, ay]
        hit = lambda s, z: math.hypot(z[1], z[2]) - 4000.0
        hit.terminal = True; hit.direction = 1
        zg = solve_ivp(geo, (0, 1e6), [0.0, x0, y0, tdot0, sp_, 0.0], events=hit, rtol=1e-12, atol=1e-12, method='DOP853', max_step=50)
        tg, xg, yg, _, xdg, ydg = zg.y_events[0][0]
        # Newton in Phi_kin = (1 - N^-2)/2 = -m/(r - 2m): Newtonian time; initial speed from energy v^2/2
        Phi = lambda r: 0.5 * (1 - 1 / Nf(r) ** 2); dPhi = lambda r: (m / r ** 2) / Nf(r) ** 4
        u0 = math.sqrt(v * v - 2 * Phi(r0))
        def newt(s, z):
            x, y, xd, yd = z; r = math.hypot(x, y); g = dPhi(r) / r; return [xd, yd, -g * x, -g * y]
        hitn = lambda s, z: math.hypot(z[0], z[1]) - 4000.0
        hitn.terminal = True; hitn.direction = 1
        zn = solve_ivp(newt, (0, 1e6), [x0, y0, u0, 0.0], events=hitn, rtol=1e-12, atol=1e-12, method='DOP853', max_step=50)
        tn = zn.t_events[0][0]; xn, yn, xdn, ydn = zn.y_events[0][0]
        ang_g = math.atan2(ydg, xdg); ang_n = math.atan2(ydn, xdn)
        # pointwise speed ratio on the Einstein path: (|dx/dt|_E)/(Newton speed at the same radius) = N^2
        ss = np.linspace(zg.t[0], zg.t[-1], 400); zz = solve_ivp(geo, (0, zg.t[-1]), [0.0, x0, y0, tdot0, sp_, 0.0], t_eval=ss, rtol=1e-12, atol=1e-12, method='DOP853', max_step=50).y
        rr = np.hypot(zz[1], zz[2]); vE = np.hypot(zz[4], zz[5]) / zz[3]; vN = np.sqrt(v * v - 2 * np.array([Phi(q) for q in rr]))
        ratio_err = float(np.max(np.abs(vE / vN / (1 - 2 * m / rr) - 1)))
        out[f'v={v}, b={b}'] = dict(deflection=fl(ang_g), path_angle_difference=below(ang_g - ang_n, 1e-8), arrival_time_einstein=fl(tg), arrival_time_newton=fl(tn),
                                    time_difference=fl(tg - tn), speed_ratio_over_N2_max_error=below(ratio_err, 1e-7))
    if not record:
        return out
    flat = QA(m=1e-12, probes=((0.5, 12.0),), record=False)['v=0.5, b=12.0']     # canary: (almost) no field
    canary_dt = abs(flat['time_difference'])
    ok = canary_dt < 1e-6 and all(abs(float(v['deflection'])) > 0.01 for v in out.values()) and all(isinstance(v['path_angle_difference'], str) for v in out.values()) \
        and all(isinstance(v['speed_ratio_over_N2_max_error'], str) for v in out.values()) and all(v['time_difference'] > 1.0 for v in out.values())
    must(ok, 'QA')
    R['QA'] = dict(claim='Timing lifts the single-speed no-go. On a static field with flat spatial structure and N^2 = 1 - 2m/r, Newton in '
                         'Phi_kin = (1 - N^-2)/2 reproduces every trajectory exactly, so no deflection panel at one speed refutes him. '
                         'Integrating the full geodesic equations and Newton\'s equations independently, from 4000m in to 4000m out, the '
                         'exit directions agree to 1e-8 rad, while the Einstein coordinate speed is exactly N^2 times the Newtonian one '
                         'at every point (error below) and the arrival times differ by the amounts below (Einstein later). A clock '
                         'record resolves at one speed what no deflection record can: the single-speed no-go belongs to the static '
                         'quotient of shape records, and record dynamics removes it. Newton is refuted at one speed as soon as the '
                         'record includes time. Canary: with the field switched off the arrival times agree.',
                   status='PROVED (Jacobi metric; conserved energy) + computed', by_probe=out, no_field_canary_time_difference=below(canary_dt, 1e-6))


# ============================================================================================ QB
def QB():
    m = 1.0
    def kappa2(r):
        # radial epicyclic frequency squared in coordinate time, from the effective potential V = (1 - 2m/r)(1 + L^2/r^2)
        L2 = m * r * r / (r - 3 * m); V = lambda q: (1 - 2 * m / q) * (1 + L2 / q ** 2)
        h = 1e-4 * r; Vpp = (V(r + h) - 2 * V(r) + V(r - h)) / h ** 2; w2_tau = Vpp / 2; ut2 = r / (r - 3 * m)
        return w2_tau / ut2
    rows = {}
    for r in (20.0, 10.0, 7.0, 6.0, 5.0, 4.0, 3.5):
        k2 = kappa2(r); kN = m / r ** 3
        rows[str(r)] = dict(kappa2_einstein=fl(k2), kappa2_newton=fl(kN), formula=fl(m * (r - 6 * m) / r ** 4),
                            record_rate_per_m=fl(math.sqrt(-k2) / math.log(2)) if k2 < 0 else 0.0)
    isco = brentq(kappa2, 5.0, 7.0)
    # physical units for a 10 solar-mass black hole: time unit m/c
    tm = 10 * 1.32712440018e20 / C ** 3; rate_5m = math.sqrt(-kappa2(5.0)) / math.log(2) / tm
    form_err = max(abs(rows[k]['kappa2_einstein'] - rows[k]['formula']) / rows[k]['kappa2_newton'] for k in rows)
    ok = form_err < 1e-5 and abs(isco - 6.0) < 1e-3 and all(rows[k]['kappa2_newton'] > 0 for k in rows) and all((rows[k]['kappa2_einstein'] < 0) == (float(k) < 6) for k in rows if float(k) != 6.0)
    must(ok, 'QB')
    R['QB'] = dict(claim='The orbit frontier. Newton\'s circular orbits have epicyclic kappa^2 = m/r^3 > 0 at every radius: their forecast '
                         'needs no record rate. Einstein\'s (Schwarzschild, coordinate time) have kappa^2 = (m/r^3)(1 - 6m/r) (finite differences of the effective potential match it to 1e-5 of the Newtonian value), changing sign at r = 6m (found '
                         'at the value below): inside it a circular orbit is unstable with exponent sqrt(-kappa^2) and its forecast needs '
                         'records at sqrt(-kappa^2)/ln 2 bits per unit time. For a 10 solar-mass black hole, at r = 5m that is the rate '
                         'below in bits per second. The innermost stable circular orbit is, in record terms, the radius where orbits '
                         'start to cost records.',
                   status='PROVED (effective potential) + computed', by_radius={k: {a: b for a, b in v.items() if a != 'formula'} for k, v in rows.items()}, formula_error=fl(form_err),
                   isco=fl(isco), rate_at_5m_10Msun_bits_per_s=fl(rate_5m))


# ============================================================================================ QC
def QC():
    t, r, th, ph, m = sp.symbols('t r theta phi m', positive=True); x = [t, r, th, ph]; f = 1 - 2 * m / r
    g = sp.diag(-f, 1 / f, r ** 2, r ** 2 * sp.sin(th) ** 2); gi = g.inv()
    Gam = [[[sp.simplify(sum(gi[a, d] * (sp.diff(g[d, b], x[c]) + sp.diff(g[d, c], x[b]) - sp.diff(g[b, c], x[d])) for d in range(4)) / 2) for c in range(4)] for b in range(4)] for a in range(4)]
    Rup = {}
    for a in range(4):
        for b in range(4):
            for c in range(4):
                for d in range(c + 1, 4):
                    Rup[(a, b, c, d)] = sp.simplify(sp.diff(Gam[a][d][b], x[c]) - sp.diff(Gam[a][c][b], x[d]) + sum(Gam[a][c][e] * Gam[e][d][b] - Gam[a][d][e] * Gam[e][c][b] for e in range(4)))
    def Rl(a, b, c, d):
        if c == d:
            return sp.Integer(0)
        s = 1
        if c > d:
            c, d, s = d, c, -1
        return s * sum(g[a, e] * Rup[(e, b, c, d)] for e in range(4))
    rows = {}; worst = 0.0; radial_ok = 0.0
    for rv in (20.0, 10.0, 6.0, 4.0, 3.3, 3.05):
        sub = {m: 1.0, r: rv, th: sp.pi / 2}
        R4 = np.array([[[[float(Rl(a, b, c, d).subs(sub)) for d in range(4)] for c in range(4)] for b in range(4)] for a in range(4)])
        gn = np.diag([-(1 - 2 / rv), 1 / (1 - 2 / rv), rv ** 2, rv ** 2]); Om = math.sqrt(1 / rv ** 3); ut = 1 / math.sqrt(1 - 3 / rv)
        u = np.array([ut, 0, 0, ut * Om]); er = np.array([0, math.sqrt(1 - 2 / rv), 0, 0]); eth = np.array([0, 0, 1 / rv, 0])
        w = np.array([1.0, 0, 0, (1 - 2 / rv) / (rv ** 2 * Om)]); w = w / math.sqrt(w @ gn @ w)
        Ef = np.array([[np.einsum('abcd,a,b,c,d->', R4, p, u, q, u) for q in (er, eth, w)] for p in (er, eth, w)]) * rv ** 3
        pred = np.diag([-(2 * rv - 3) / (rv - 3), rv / (rv - 3), 1.0]); worst = max(worst, float(np.abs(Ef - pred).max() / np.abs(pred).max()))
        lam_ratio = math.sqrt((2 * rv - 3) / (2 * (rv - 3)))
        rows[str(rv)] = dict(E_times_r3=[fl(Ef[0, 0]), fl(Ef[1, 1]), fl(Ef[2, 2])], radial_rate_over_newton=fl(lam_ratio))
        # canary: radially falling observer from rest at infinity sees Newton's tensor exactly
        ur = np.array([1 / (1 - 2 / rv), -math.sqrt(2 / rv), 0, 0]); er2 = np.array([-math.sqrt(2 / rv) / (1 - 2 / rv), 1.0, 0, 0])
        er2 = er2 / math.sqrt(er2 @ gn @ er2); eph = np.array([0, 0, 0, 1 / rv])
        Er = np.array([[np.einsum('abcd,a,b,c,d->', R4, p, ur, q, ur) for q in (er2, eth, eph)] for p in (er2, eth, eph)]) * rv ** 3
        radial_ok = max(radial_ok, float(np.abs(Er - np.diag([-2.0, 1.0, 1.0])).max()))
    ok = worst < 1e-9 and radial_ok < 1e-9 and rows['3.05']['radial_rate_over_newton'] > 5 and abs(rows['20.0']['radial_rate_over_newton'] - 1) < 0.05
    must(ok, 'QC')
    R['QC'] = dict(claim='The tidal frontier on orbits. From the Riemann tensor of Schwarzschild (symbolic), projected on a circular geodesic, '
                         'the tidal tensor is (m/r^3) diag(-(2r - 3m)/(r - 3m), r/(r - 3m), 1) to the error below at six radii, '
                         'against Newton\'s (m/r^3) diag(-2, 1, 1). The radial record rate therefore exceeds Newton\'s by '
                         'sqrt((2r - 3m)/(2(r - 3m))): 1.02 at 20m, 1.22 at 6m, 5.2 at 3.05m, divergent at the light ring 3m. Canary: '
                         'an observer falling radially from rest sees exactly Newton\'s tensor at every radius. The Newton-Einstein '
                         'gap in the tidal record cost is carried by orbital motion, not by the field alone.',
                   status='PROVED (geodesic deviation; Marck 1983) + computed', by_radius=rows, formula_rel_error=below(worst, 1e-9), radial_infall_deviation=below(radial_ok, 1e-9))


# ============================================================================================ QD
def quantum_riccati(A, k, eta, V0, T, backaction=True, hbar=1.0):
    D = np.diag([0.0, hbar ** 2 * k if backaction else 0.0]); e1 = np.array([[1.0], [0.0]])
    def f(t, y):
        V = y.reshape(2, 2); dV = A @ V + V @ A.T + D - 4 * eta * k * V @ e1 @ e1.T @ V; return ((dV + dV.T) / 2).ravel()
    s = solve_ivp(f, (0, T), V0.ravel(), t_eval=np.linspace(0, T, 200), rtol=1e-11, atol=1e-14, method='DOP853')
    return s.y.T.reshape(-1, 2, 2)


def QD():
    rng = np.random.default_rng(SEED + 3); hb = 1.0; mm = 1.0
    flows = {'free': np.array([[0, 1 / mm], [0, 0]]), 'oscillator': np.array([[0, 1 / mm], [-mm * 1.0, 0]]), 'inverted (tidal)': np.array([[0, 1 / mm], [mm * 0.5, 0]])}
    rows = {}
    for name, A in flows.items():
        eq_dev, ineff_min, cl_min = 0.0, math.inf, math.inf
        for _ in range(20):
            k = 10 ** rng.uniform(-2, 2); a = 10 ** rng.uniform(-1, 1); V0 = np.diag([a, hb ** 2 / (4 * a)])
            Vs = quantum_riccati(A, k, 1.0, V0, 6.0); dets = np.array([np.linalg.det(V) for V in Vs]) / (hb ** 2 / 4)
            eq_dev = max(eq_dev, float(np.abs(dets - 1).max()))
            Vs2 = quantum_riccati(A, k, 0.5, V0, 6.0); ineff_min = min(ineff_min, float(min(np.linalg.det(V) for V in Vs2) / (hb ** 2 / 4)))
            Vs3 = quantum_riccati(A, k, 1.0, V0, 6.0, backaction=False); cl_min = min(cl_min, float(min(np.linalg.det(V) for V in Vs3) / (hb ** 2 / 4)))
        rows[name] = dict(efficient_det_deviation=below(eq_dev, 1e-7), inefficient_min_det_ratio=fl(ineff_min), no_backaction_min_det_ratio=fl(cl_min))
    ok = all(isinstance(r['efficient_det_deviation'], str) and r['inefficient_min_det_ratio'] >= 1 - 1e-9 and r['no_backaction_min_det_ratio'] < 0.5 for r in rows.values())
    must(ok, 'QD')
    R['QD'] = dict(claim='The volume ceiling. Continuous quantum records of position with strength k add record gain 4k on x and, by '
                         'back-action, ignorance inflow hbar^2 k on p: in quantum mechanics gain forces inflow, Q_pp = (hbar^2/4) G_xx. '
                         'Running the record Hessian flow with this tie for free, bound and unstable (tidal) dynamics, 20 random '
                         'strengths and pure initial states each: with efficient records det V stays exactly (hbar/2)^2 (deviation '
                         'below), and with half-efficient records it never falls below. The native tensor\'s volume has a ceiling, '
                         'det I <= (2/hbar)^2 per degree of freedom: one phase-space cell. Canary: the same records without back-action '
                         'drive det V far below (hbar/2)^2, which is the classical record dynamics, where I grows without bound.',
                   status='PROVED (Robertson-Schroedinger; purity of efficient Gaussian monitoring) + computed', by_flow=rows)


# ============================================================================================ QE
def QE():
    hb, mm, lam, tau = 1.0, 1.0, 0.7, 1.3
    ch, sh = math.cosh(lam * tau), math.sinh(lam * tau)
    var = lambda a: ch ** 2 * a + sh ** 2 * hb ** 2 / (4 * a * mm ** 2 * lam ** 2)          # uncorrelated pure state, V_xx = a
    best = minimize_scalar(lambda la: var(math.exp(la)), bounds=(-10, 10), method='bounded').fun
    bound = hb * math.sinh(2 * lam * tau) / (2 * mm * lam)
    free = hb * tau / mm; free_num = minimize_scalar(lambda la: math.exp(la) + tau ** 2 * hb ** 2 / (4 * math.exp(la) * mm ** 2), bounds=(-10, 10), method='bounded').fun
    # canary: a correlated pure state squeezed along the evolved coordinate beats the bound
    Phi = np.array([[ch, sh / (mm * lam)], [mm * lam * sh, ch]]); s = 1e-3; Vt = np.diag([s, hb ** 2 / (4 * s)])
    V0 = np.linalg.inv(Phi) @ Vt @ np.linalg.inv(Phi).T; squeezed = float((Phi @ V0 @ Phi.T)[0, 0]); pure = abs(np.linalg.det(V0) - hb ** 2 / 4)
    lamE = math.sqrt(2 * 3.986004418e14 / 6.371e6 ** 3); phys = {}
    for mass in (1.0, 1e-14):
        phys[f'{mass:g} kg'] = fl(math.sqrt(HBAR * math.sinh(2.0) / (2 * mass * lamE)))
    ok = abs(best - bound) / bound < 1e-8 and abs(free_num - free) / free < 1e-8 and squeezed < 0.01 * bound and pure < 1e-9
    must(ok, 'QE')
    R['QE'] = dict(claim='The tracking limit. For an unstable coordinate with exponent lambda, the forecast over a horizon tau from a pure '
                         'state without position-momentum correlation has Var >= hbar sinh(2 lambda tau)/(2 m lambda), attained at one '
                         'width (numerical minimum equal to the formula to 1e-8); for a free mass it is hbar tau/m. For two bodies in '
                         'free fall at the Earth\'s surface and a horizon of one e-folding, the standard deviation is at least the '
                         'value below. Canary: a correlated pure state squeezed along the evolved coordinate reaches 1e-3: the limit '
                         'belongs to the declared protocol (uncorrelated position records), as in gravitational-wave detectors, and '
                         'back-action-evading records beat it.',
                   status='PROVED (minimisation; standard quantum limit) + computed', bound=fl(bound), numeric_minimum=fl(best), squeezed_canary=fl(squeezed),
                   earth_freefall_one_efold_sd_m=phys)


# ============================================================================================ QF
def QF():
    def floor(L, hbar=HBAR, G=G_N):
        f = lambda lm: math.sqrt(hbar * L / (math.exp(lm) * C)) + 2 * G * math.exp(lm) / C ** 2
        res = minimize_scalar(f, bounds=(-120, 120), method='bounded', options=dict(xatol=1e-12)); return res.fun, math.exp(res.x)
    Ls = np.logspace(-10, 26, 13); vals = np.array([floor(L)[0] for L in Ls])
    slope = float(np.polyfit(np.log(Ls), np.log(vals), 1)[0])
    one_m, m_opt = floor(1.0); pred = 3 * 2 ** (-1 / 3) * (LP ** 2 * 1.0) ** (1 / 3)
    hubble = floor(1.3e26)[0]
    noG = floor(1.0, G=1e-300)[0]; nohbar = floor(1.0, hbar=1e-300)[0]
    # one-loop correction to the tidal record rate: Phi = -GM/r (1 + 41/(10 pi) l_P^2/r^2): radial second-derivative ratio
    corr = {}
    for r in (1.0, 1e-6, 1e-15):
        corr[f'{r:g} m'] = fl(3 * 41 / (10 * math.pi) * LP ** 2 / r ** 2)
    ok = abs(slope - 1 / 3) < 1e-3 and abs(one_m / pred - 1) < 1e-6 and noG < 1e-20 * one_m and nohbar < 1e-20 * one_m
    must(ok, 'QF')
    R['QF'] = dict(claim='The geometry frontier. A probe of mass m that holds a length L over the light time pays sqrt(hbar L/(m c)) in '
                         'quantum spread (the tracking limit of a free mass) and 2Gm/c^2 in its own horizon. The best mass leaves '
                         'delta L = 3 2^(-1/3) (l_P^2 L)^(1/3) (minimisation equal to the formula to 1e-6; slope 1/3 over 36 decades): '
                         'the values below at one metre and at the Hubble length. Canaries: with G or hbar removed the minimum falls by more than twenty orders of magnitude, limited only by the searched mass range: there is no floor. '
                         'This is the Salecker-Wigner / Ng-van Dam argument; it inherits the protocol status of the tracking limit '
                         '(QE). For comparison, the one-loop quantum correction to the Newtonian potential moves the tidal record rate '
                         'by about 3 (41/(10 pi)) l_P^2/r^2 (values below): the dynamical gap is negligible; the record gap is not.',
                   status='heuristic (Salecker-Wigner 1958; Ng-van Dam 1994; Bjerrum-Bohr et al. 2003) + computed', slope=fl(slope), at_1m=fl(one_m),
                   formula_1m=fl(pred), optimal_mass_1m_kg=fl(m_opt), at_hubble_length=fl(hubble), without_G=fl(noG), without_hbar=fl(nohbar), tidal_rate_correction=corr)


if __name__ == '__main__':
    for name, fn in (('QA', QA), ('QB', QB), ('QC', QC), ('QD', QD), ('QE', QE), ('QF', QF)):
        try:
            fn()
        except Exception as e:
            must(False, name); R[name] = dict(crash=repr(e))
        print(name, flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (HERE / 'rg_record_gaps_results.json').write_text(json.dumps(out, indent=1, sort_keys=True))
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
