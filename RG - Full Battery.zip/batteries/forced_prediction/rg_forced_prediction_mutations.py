#!/usr/bin/env python3
"""Mutation suite for rg_forced_prediction.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. A few minutes.

    python3 -I rg_forced_prediction_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('FA', 'every target declared forced (rank test disabled)', "forced = lambda v: np.linalg.matrix_rank(np.vstack([A, v])) == np.linalg.matrix_rank(A)", "forced = lambda v: True"),
    ('FB', 'ball ignored when the box maximiser lies outside it', "    if corner @ corner <= 1:\n        return float(nv @ corner)", "    if True:\n        return float(nv @ corner)"),
    ('FB', 'boundary formula uses the upper box corner', "z_exact = math.sqrt(max(0.0, 1 - lox ** 2 - loy ** 2))", "z_exact = math.sqrt(max(0.0, 1 - slabs[0][1] ** 2 - slabs[1][1] ** 2))"),
    ('FC', 'predictor reads the oracle', "    slabs = {int(k): v for k, v in cal['slabs'].items()}; D = np.array(json.loads((work / 'targets.json').read_bytes())['directions'])", "    slabs = {int(k): v for k, v in cal['slabs'].items()}; D = np.array(json.loads((work / 'targets.json').read_bytes())['directions']); _ = (work / 'oracle.json')"),
    ('FC', 'predictions left out of the commitment', "    names = ['spec.json', 'calibration.json', 'targets.json', 'predictions.json']", "    names = ['spec.json', 'calibration.json', 'targets.json']"),
    ('FC', 'certificate threshold loosened tenfold', "certified=bool((hi - lo) / 2 <= spec['eps'])", "certified=bool((hi - lo) / 2 <= 10 * spec['eps'])"),
    ('FD', 'Hoeffding radius shrunk tenfold', "    rad = math.sqrt(math.log(2 * len(axes) / alpha) / (2 * n)); slabs = {}", "    rad = math.sqrt(math.log(2 * len(axes) / alpha) / (2 * n)) / 10; slabs = {}"),
    ('FE', 'Bayesian prior centred on the truth', "z = rng.normal(0, 0.05, S)", "z = rng.normal(0.58, 0.05, S)"),
    ('FF', 'no drift between calibration and test', "th = 0.35;", "th = 0.0;"),
    ('FG', 'gap measured along a calibrated axis', "d = np.array([0.0, 0.0, 1.0]); mn, mx = extrema(d, slabs, True)", "d = np.array([1.0, 0.0, 0.0]); mn, mx = extrema(d, slabs, True)"),
    ('FH', 'decay Kraus operator dropped in the scorer', "K1 = np.array([[0, math.sqrt(gamma)], [0, 0]])", "K1 = np.zeros((2, 2))"),
    ('FH', 'Heisenberg offset with the wrong sign', "off = gamma * m[2]", "off = -gamma * m[2]"),
]


def main():
    base = open(os.path.join(HERE, 'rg_forced_prediction.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_forced_prediction.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_forced_prediction.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_forced_prediction_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
