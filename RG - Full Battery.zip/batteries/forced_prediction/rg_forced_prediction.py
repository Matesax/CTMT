#!/usr/bin/env python3
"""Resolution Geometry - Forced Predictions: what incomplete records already determine, certified before the measurement.

Setting. Calibration records D constrain the state to an admissible set C(D): the fibre of the record map over the
calibration confidence region, intersected with the physical cone (here the Bloch ball of a two-level system). A target T
(the outcome probability of a protocol never run during calibration) is forced to within eps when its range over C(D) is
at most 2 eps; the midpoint is then the minimax prediction and no other predictor does better in the worst case.

  FA theorem checks: the minimax error over an interval of admissible values is half its length (random intervals and a
     direct search over predictors); in the linear model without the cone a target is exactly forced iff its direction
     lies in the row space of the calibration map (exact rank); canary: a direction with a kernel component is not forced
  FB the cone forces more than the span: for a nearly pure state calibrated on two axes only, positivity pins the third
     coordinate, and targets along the unmeasured axis are certified; without the cone none of them is; extrema checked
     by an independent dense search
  FC the frozen pipeline: calibrate, then predict in a separate process that never sees the truth, commit a SHA-256 root,
     verify it, and only then generate held-out outcomes and score; every true probability lies in its interval, every
     empirical frequency in its shot-noise-expanded interval, every certified midpoint within eps; five tampering
     controls are rejected
  FD validity in repetition: 300 independent calibration-and-test runs; the fraction in which every target is covered is
     at least the nominal 1 - alpha
  FE against priors: a confident but wrong prior on the unmeasured coordinate certifies predictions that fail, while the
     admissible-set certificate never fails
  FF falsification monitor: if the state drifts between calibration and test (outside the declared model), scoring
     flags it; without drift nothing is flagged
  FH cross-protocol transfer: calibrate by direct measurement, predict a different protocol (a known amplitude-damping
     channel, then measurement along unused directions), scored independently with Kraus operators
  FG the limit: two states in one fibre give a target gap that no frozen predictor can halve below; hashing the inputs
     does not change that

Deterministic. Seed 20261203. Writes rg_forced_prediction_results.json.
Run:  python3 -I rg_forced_prediction.py      (numpy, scipy)
"""
import argparse, hashlib, json, math, os, subprocess, sys, tempfile
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
SEED = 20261203
R, FAILS = {}, []
EPS = 0.03


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.8g}')


def below(v, b):
    return f'< {b:g}' if abs(v) < b else fl(v)


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def sha(b):
    return hashlib.sha256(b).hexdigest()


# ============================================================================================ core
def calibrate(r_true, axes, n, alpha, rng):
    """Shots on each calibrated axis; simultaneous Hoeffding slabs for r_j = 2 p_j - 1."""
    rad = math.sqrt(math.log(2 * len(axes) / alpha) / (2 * n)); slabs = {}
    counts = {}
    for j in axes:
        k = int(rng.binomial(n, (1 + r_true[j]) / 2)); counts[j] = k
        p = k / n; slabs[j] = [max(-1.0, 2 * (p - rad) - 1), min(1.0, 2 * (p + rad) - 1)]
    return slabs, counts


def extrema(nv, slabs, cone=True):
    """min and max of n . r over {r in box(slabs)} intersected with the unit ball (cone) or not."""
    lo = np.array([slabs.get(j, [-1.0, 1.0])[0] for j in range(3)]); hi = np.array([slabs.get(j, [-1.0, 1.0])[1] for j in range(3)])
    if not cone:
        mn = float(np.sum(np.where(nv > 0, nv * lo, nv * hi))); mx = float(np.sum(np.where(nv > 0, nv * hi, nv * lo)))
        return mn, mx
    if np.any(lo > hi):
        raise RuntimeError('empty calibration box')
    if float(np.sum(np.clip(0.0, lo, hi) ** 2)) > 1 + 1e-12:
        raise RuntimeError('admissible set empty: box misses the ball')
    return -_ball_box_max(-nv, lo, hi), _ball_box_max(nv, lo, hi)


def _ball_box_max(nv, lo, hi):
    """Exact max of n.r over box ∩ unit ball by Lagrangian duality: r(lam) = clip(n/(2 lam), lo, hi), and |r(lam)| decreases
    in lam; lam = 0 is optimal when the box maximiser lies in the ball, else the optimum has |r(lam)| = 1 (bisection)."""
    corner = np.where(nv > 0, hi, np.where(nv < 0, lo, np.clip(0.0, lo, hi)))
    if corner @ corner <= 1:
        return float(nv @ corner)
    r_of = lambda lam: np.clip(nv / (2 * lam), lo, hi)
    a, b = 1e-15, 1.0
    while r_of(b) @ r_of(b) > 1:
        b *= 2
        if b > 1e15:
            raise RuntimeError('no feasible multiplier')
    for _ in range(200):
        m = math.sqrt(a * b) if b / a > 4 else (a + b) / 2
        if r_of(m) @ r_of(m) > 1:
            a = m
        else:
            b = m
    return float(nv @ r_of(b))


def prob_interval(nv, slabs, cone=True):
    mn, mx = extrema(nv, slabs, cone)
    return (1 + mn) / 2, (1 + mx) / 2


def random_dirs(rng, k):
    d = rng.normal(size=(k, 3)); return d / np.linalg.norm(d, axis=1)[:, None]


def target_mix(rng, k_plane=80, k_generic=120):
    """Declared before calibration: k_plane directions in the calibrated plane (blind to the unmeasured axis), k_generic generic."""
    t = rng.uniform(0, 2 * math.pi, k_plane); plane = np.stack([np.cos(t), np.sin(t), np.zeros(k_plane)], 1)
    return np.vstack([plane, random_dirs(rng, k_generic)])


# ============================================================================================ FA
def FA():
    rng = np.random.default_rng(SEED)
    worst = 0.0
    for _ in range(200):
        l, u = sorted(rng.uniform(-1, 1, 2)); grid = np.linspace(l - 0.5, u + 0.5, 4001)
        best = min(max(abs(a - l), abs(a - u)) for a in grid)
        worst = max(worst, abs(best - (u - l) / 2))
    # linear model without the cone: calibration map A (rows: measured directions)
    A = np.array([[1.0, 0, 0], [0, 1.0, 0]])
    in_span = np.array([0.6, -0.8, 0.0]); off_span = np.array([0.6, 0.0, 0.8])
    forced = lambda v: np.linalg.matrix_rank(np.vstack([A, v])) == np.linalg.matrix_rank(A)
    slabs = {0: [0.2, 0.2], 1: [-0.1, -0.1]}                         # exact calibration
    w_in = np.subtract(*reversed(extrema(in_span, slabs, cone=False))); w_off = np.subtract(*reversed(extrema(off_span, slabs, cone=False)))
    ok = worst < 1e-3 and forced(in_span) and not forced(off_span) and w_in < 1e-12 and abs(w_off - 1.6) < 1e-12
    must(ok, 'FA')
    R['FA'] = dict(claim='Theorem checks. For 200 random intervals of admissible values, the best worst-case error over a dense grid of '
                         'predictors equals half the interval length (to the grid resolution): the minimax prediction is the midpoint, '
                         'and an eps-certificate exists iff the range is at most 2 eps. In the linear model without the cone, with '
                         'exact calibration on two axes, a target in the row space of the calibration map has range 0 (exactly forced), '
                         'and a target with a component along the unmeasured axis has range 1.6 (canary).',
                   status='PROVED (Section 2) + computed', minimax_grid_error=fl(worst), range_in_span=below(w_in, 1e-12), range_off_span=fl(w_off))


# ============================================================================================ FB
def FB():
    rng = np.random.default_rng(SEED + 1)
    # (i) boundary: a pure state in the calibrated plane; positivity pins the unmeasured coordinate near 0
    r_pure = np.array([0.8, 0.6, 0.0]); slabs, _ = calibrate(r_pure, (0, 1), 40_000_000, 0.01, rng)
    zdirs = np.array([[math.sin(t), 0.0, math.cos(t)] for t in np.linspace(0, 0.3, 10)])
    cert = lambda D, sl, cone: int(sum((lambda iv: (iv[1] - iv[0]) / 2 <= EPS)(prob_interval(d, sl, cone)) for d in D))
    z_cone, z_box = cert(zdirs, slabs, True), cert(zdirs, slabs, False)
    mn, mx = extrema(np.array([0, 0, 1.0]), slabs, True)
    lox, loy = slabs[0][0], slabs[1][0]; z_exact = math.sqrt(max(0.0, 1 - lox ** 2 - loy ** 2))   # min of x^2+y^2 over the rectangle
    # (ii) canary: interior state; positivity bounds |z| but not its sign, so z-targets stay uncertified
    r_int = np.array([0.80, 0.55, 0.12]); sl_int, _ = calibrate(r_int, (0, 1), 40_000_000, 0.01, rng)
    z_int = extrema(np.array([0, 0, 1.0]), sl_int, True)
    z_int_cert = cert(zdirs, sl_int, True)
    # (iii) the quadratic price: z_max^2 ~ 2 |r_perp| delta, so eps-certification needs delta <~ 2 eps^2 / |r_perp|
    delta = 1 - math.hypot(lox, loy); law = math.sqrt(2 * delta)
    # (iv) solver cross-check against sampled feasible points, generic directions
    D = random_dirs(rng, 30); lo = np.array([sl_int[0][0], sl_int[1][0], -1.0]); hi = np.array([sl_int[0][1], sl_int[1][1], 1.0])
    P = rng.uniform(lo, hi, size=(400000, 3)); P = P[np.einsum('ij,ij->i', P, P) <= 1]
    gaps = [(extrema(d, sl_int, True)[1] - float((P @ d).max())) for d in D]
    ok = z_cone == len(zdirs) and z_box == 0 and abs(mx - z_exact) < 1e-9 and abs(mn + z_exact) < 1e-9 and z_int_cert == 0 \
        and abs(z_int[0] + z_int[1]) < 1e-9 and min(gaps) > -1e-9 and max(gaps) < 0.02 and abs(mx - law) / law < 0.05
    must(ok, 'FB')
    R['FB'] = dict(claim='Positivity forces more than the span, but only at the boundary. (i) A pure state in the calibrated plane, '
                         '4e7 shots on each of two axes: the Bloch ball confines the never-measured coordinate to |z| <= z_max, equal '
                         'to sqrt(1 - lo_x^2 - lo_y^2) to 1e-9, and all 10 targets near the unmeasured axis are certified at eps = 0.03; '
                         'without the cone none is. (ii) Canary: for an interior state (|r| = 0.978) the cone bounds |z| but not its '
                         'sign, the z-range is symmetric, and no z-target is certified, however many shots. (iii) The price is '
                         'quadratic: z_max ~ sqrt(2 delta), delta the radial deficit of the calibration box, so certification along '
                         'the unmeasured axis needs delta <~ 2 eps^2. (iv) On 30 generic directions the exact solver is never beaten '
                         'by 4e5 sampled admissible points and exceeds their maximum by less than 0.02.',
                   status='PROVED (Section 3) + computed', z_max_boundary=fl(mx), z_max_formula=fl(z_exact), sqrt_2delta=fl(law), radial_deficit=fl(delta),
                   z_targets_certified=dict(cone=z_cone, box=z_box, total=len(zdirs)), interior_z_range=[fl(z_int[0]), fl(z_int[1])],
                   interior_z_targets_certified=z_int_cert, solver_minus_sampled=[fl(min(gaps)), fl(max(gaps))])


# ============================================================================================ FC: the frozen pipeline
def stage_prepare(work):
    rng = np.random.default_rng(SEED + 2)
    r_true = np.array([0.42, -0.31, 0.58])
    spec = dict(model='two-level system, Bloch vector r in the unit ball; outcome probability of direction n is (1 + n.r)/2',
                calibration_axes=[0, 1], shots_per_axis=50000, alpha_cal=0.005, eps=EPS, test_shots=20000, alpha_test=0.005, targets=200)
    slabs, counts = calibrate(r_true, spec['calibration_axes'], spec['shots_per_axis'], spec['alpha_cal'], rng)
    targets = target_mix(rng).tolist()
    (work / 'spec.json').write_bytes(canonical(spec)); (work / 'calibration.json').write_bytes(canonical(dict(slabs={str(k): v for k, v in slabs.items()}, counts={str(k): v for k, v in counts.items()})))
    (work / 'targets.json').write_bytes(canonical(dict(directions=targets)))
    (work / 'oracle.json').write_bytes(canonical(dict(r=r_true.tolist(), test_seed=SEED + 99)))


def stage_predict(work):
    spec = json.loads((work / 'spec.json').read_bytes()); cal = json.loads((work / 'calibration.json').read_bytes())
    slabs = {int(k): v for k, v in cal['slabs'].items()}; D = np.array(json.loads((work / 'targets.json').read_bytes())['directions'])
    rows = []
    for d in D:
        lo, hi = prob_interval(d, slabs, True)
        rows.append(dict(lower=fl(lo), upper=fl(hi), midpoint=fl((lo + hi) / 2), certified=bool((hi - lo) / 2 <= spec['eps'])))
    (work / 'predictions.json').write_bytes(canonical(dict(rows=rows)))
    names = ['spec.json', 'calibration.json', 'targets.json', 'predictions.json']
    manifest = dict(files={nm: sha((work / nm).read_bytes()) for nm in names}, source=sha(Path(__file__).read_bytes()))
    (work / 'manifest.json').write_bytes(canonical(manifest)); (work / 'root.txt').write_text(sha((work / 'manifest.json').read_bytes()))


def verify(work, root):
    if sha((work / 'manifest.json').read_bytes()) != root:
        return False
    m = json.loads((work / 'manifest.json').read_bytes())
    return m['source'] == sha(Path(__file__).read_bytes()) and all(sha((work / nm).read_bytes()) == h for nm, h in m['files'].items())


def stage_score(work):
    root = (work / 'root.txt').read_text().strip()
    if not verify(work, root):
        raise RuntimeError('commitment broken before scoring')
    spec = json.loads((work / 'spec.json').read_bytes()); oracle = json.loads((work / 'oracle.json').read_bytes())
    D = np.array(json.loads((work / 'targets.json').read_bytes())['directions']); rows = json.loads((work / 'predictions.json').read_bytes())['rows']
    r = np.array(oracle['r']); p = (1 + D @ r) / 2                    # outcomes generated only now
    rng = np.random.default_rng(oracle['test_seed']); n = spec['test_shots']; emp = rng.binomial(n, p) / n
    rad = math.sqrt(math.log(2 * len(D) / spec['alpha_test']) / (2 * n))
    lo = np.array([x['lower'] for x in rows]); hi = np.array([x['upper'] for x in rows]); mid = np.array([x['midpoint'] for x in rows]); cert = np.array([x['certified'] for x in rows])
    res = dict(root=root, certified=int(cert.sum()), truth_in=int(np.sum((p >= lo - 1e-7) & (p <= hi + 1e-7))), emp_in=int(np.sum((emp >= lo - rad) & (emp <= hi + rad))),
               max_certified_error=float(np.max(np.abs(mid[cert] - p[cert]))) if cert.any() else 0.0, n_targets=len(D), shot_radius=rad,
               certified_plane=int(cert[:80].sum()), plane=80, certified_generic=int(cert[80:].sum()))
    (work / 'score.json').write_bytes(canonical(res))


def FC():
    with tempfile.TemporaryDirectory() as td:
        work = Path(td)
        with tempfile.TemporaryDirectory() as vault:                  # the oracle is absent while the predictor runs
            for st in ('prepare', 'predict', 'score'):
                if st == 'predict':
                    (work / 'oracle.json').rename(Path(vault) / 'oracle.json')
                if st == 'score':
                    (Path(vault) / 'oracle.json').rename(work / 'oracle.json')
                r = subprocess.run([sys.executable, '-I', str(Path(__file__).resolve()), '--stage', st, '--work', td], capture_output=True, text=True, timeout=900)
                if r.returncode:
                    raise RuntimeError(r.stderr[-400:])
        res = json.loads((work / 'score.json').read_bytes()); root = (work / 'root.txt').read_text().strip()
        tamper = {}
        for nm in ('spec.json', 'calibration.json', 'targets.json', 'predictions.json', 'manifest.json'):
            with tempfile.TemporaryDirectory() as t2:
                for f in work.iterdir():
                    (Path(t2) / f.name).write_bytes(f.read_bytes())
                (Path(t2) / nm).write_bytes((Path(t2) / nm).read_bytes() + b' ')
                tamper[nm] = not verify(Path(t2), root)
        predictor_reads_oracle = 'oracle.json' in Path(__file__).read_text().split('def stage_predict')[1].split('def verify')[0]
    ok = res['truth_in'] == res['n_targets'] and res['emp_in'] == res['n_targets'] and res['max_certified_error'] <= EPS and all(tamper.values()) \
        and not predictor_reads_oracle and res['certified_plane'] == res['plane']
    must(ok, 'FC')
    R['FC'] = dict(claim='The frozen pipeline. Three processes: prepare (calibration on two axes, 200 target protocols declared), predict '
                         '(reads only the specification, calibration and targets; computes intervals and certificates; writes a SHA-256 '
                         'root over the files and its own source), score (verifies the root, then generates the held-out outcomes, '
                         '2e4 shots per target). Every true probability lies in its frozen interval, every empirical frequency in its '
                         'interval widened by the simultaneous shot-noise radius, and every certified midpoint is within eps = 0.03. '
                         'Altering any of five committed files breaks the root. The predictor stage does not read the oracle file.',
                   status='computed', result={k: (fl(v) if isinstance(v, float) else v) for k, v in res.items()}, tamper_rejected=tamper)


# ============================================================================================ FD
def FD():
    rng = np.random.default_rng(SEED + 3); r_true = np.array([0.42, -0.31, 0.58]); alpha = 0.05; runs = 300
    cov_all = 0; cov_sel = 0; selected = 0
    for _ in range(runs):
        slabs, _ = calibrate(r_true, (0, 1), 2000, alpha, rng)
        D = random_dirs(rng, 60)                                     # targets drawn after the calibration is seen
        ok_all = True; ok_sel = True
        for d in D:
            mn, mx = extrema(d, slabs, True); p = (1 + d @ r_true) / 2; lo, hi = (1 + mn) / 2, (1 + mx) / 2
            inside = lo - 1e-7 <= p <= hi + 1e-7; ok_all &= inside
            if (hi - lo) / 2 <= 0.1:                                 # adaptive selection: keep only what came out certified
                selected += 1; ok_sel &= inside
        cov_all += int(ok_all); cov_sel += int(ok_sel)
    ok = cov_all / runs >= 1 - alpha and cov_sel / runs >= 1 - alpha and selected > 0
    must(ok, 'FD')
    R['FD'] = dict(claim='Validity in repetition, with targets chosen after the data. In 300 independent calibrations (2000 shots per '
                         'axis, alpha = 0.05), 60 target directions are drawn after the calibration is seen, and the certified ones are '
                         'selected adaptively. The fraction of runs in which every target interval contains its true probability, and '
                         'the fraction in which every selected one does, are both at least the nominal 0.95: on the calibration event '
                         'the coverage holds for all targets at once, so selecting targets after seeing the calibration costs nothing.',
                   status='PROVED (Section 2) + computed', joint_coverage_all=fl(cov_all / runs), joint_coverage_selected=fl(cov_sel / runs),
                   nominal=1 - alpha, runs=runs, selected_total=selected)


# ============================================================================================ FE
def FE():
    rng = np.random.default_rng(SEED + 4); r_true = np.array([0.42, -0.31, 0.58])
    slabs, counts = calibrate(r_true, (0, 1), 50000, 0.005, rng); n = 50000
    D = target_mix(rng)
    # Bayesian baseline: confident prior z ~ N(0, 0.05^2) (wrong: truth 0.58), x, y uniform; importance sampling on the ball
    S = 200000; x = rng.uniform(-1, 1, S); y = rng.uniform(-1, 1, S); z = rng.normal(0, 0.05, S); keep = x * x + y * y + z * z < 1
    x, y, z = x[keep], y[keep], z[keep]
    logw = sum(counts[j] * np.log((1 + v) / 2 + 1e-300) + (n - counts[j]) * np.log((1 - v) / 2 + 1e-300) for j, v in ((0, x), (1, y)))
    w = np.exp(logw - logw.max()); w /= w.sum()
    bayes_false = 0; set_false = 0; bayes_cert = 0; set_cert = 0
    for d in D:
        pv = (1 + d[0] * x + d[1] * y + d[2] * z) / 2; order = np.argsort(pv); cw = np.cumsum(w[order])
        q_lo, q_hi = pv[order][np.searchsorted(cw, 0.025)], pv[order][min(np.searchsorted(cw, 0.975), len(cw) - 1)]
        pt = (1 + d @ r_true) / 2; mean = float(np.sum(w * pv))
        if (q_hi - q_lo) / 2 <= EPS:
            bayes_cert += 1; bayes_false += int(abs(mean - pt) > EPS)
        lo, hi = prob_interval(d, slabs, True)
        if (hi - lo) / 2 <= EPS:
            set_cert += 1; set_false += int(abs((lo + hi) / 2 - pt) > EPS)
    ok = bayes_false > 20 and set_false == 0 and set_cert > 0
    must(ok, 'FE')
    R['FE'] = dict(claim='Against priors. With the same calibration, a Bayesian predictor with a confident prior on the unmeasured coordinate '
                         '(z ~ N(0, 0.05^2), truth 0.58) certifies many more targets, because its credible intervals are narrow, and the '
                         'number below of them are wrong by more than eps. The admissible-set certificate certifies fewer and none of '
                         'them is wrong. Certification by the range over the admissible set does not depend on a prior.',
                   status='computed', bayes=dict(certified=bayes_cert, false=bayes_false), admissible_set=dict(certified=set_cert, false=set_false))


# ============================================================================================ FF
def FF():
    rng = np.random.default_rng(SEED + 5); r0 = np.array([0.42, -0.31, 0.58])
    slabs, _ = calibrate(r0, (0, 1), 50000, 0.005, rng); D = target_mix(rng); n = 20000
    rad = math.sqrt(math.log(2 * len(D) / 0.005) / (2 * n))
    iv = [prob_interval(d, slabs, True) for d in D]
    def flags(r):
        p = (1 + D @ r) / 2; emp = rng.binomial(n, p) / n
        return int(sum(not (lo - rad <= e <= hi + rad) for (lo, hi), e in zip(iv, emp)))
    th = 0.35; Rz = np.array([[math.cos(th), -math.sin(th), 0], [math.sin(th), math.cos(th), 0], [0, 0, 1]])
    f_drift = flags(Rz @ r0); f_none = flags(r0)
    ok = f_drift > 0 and f_none == 0
    must(ok, 'FF')
    R['FF'] = dict(claim='Falsification monitor. If the state rotates by 0.35 rad between calibration and test (outside the declared model), '
                         'the number of targets below falls outside their shot-noise-expanded intervals and the declared model is '
                         'rejected; with no drift no target is flagged. A failed certificate is a measured wall, not a silent error.',
                   status='computed', flagged_with_drift=f_drift, flagged_without_drift=f_none)


# ============================================================================================ FG
def FG():
    rng = np.random.default_rng(SEED + 6); r0 = np.array([0.42, -0.31, 0.58])
    slabs, _ = calibrate(r0, (0, 1), 50000, 0.005, rng)
    d = np.array([0.0, 0.0, 1.0]); mn, mx = extrema(d, slabs, True)
    gap = (mx - mn) / 2                                              # probability gap between two admissible states
    ok = gap > 0.3
    must(ok, 'FG')
    R['FG'] = dict(claim='The limit. Two states in the same admissible set give outcome probabilities along the unmeasured axis that differ '
                         'by the value below; no predictor, however its inputs are frozen or hashed, has worst-case error below half '
                         'of it. Prediction power comes from the narrowness of the admissible range, not from the commitment.',
                   status='computed', probability_gap=fl(gap), minimax_floor=fl(gap / 2))


# ============================================================================================ FH: cross-protocol transfer
SX = np.array([[0, 1], [1, 0]], complex); SY = np.array([[0, -1j], [1j, 0]]); SZ = np.array([[1, 0], [0, -1]], complex); I2 = np.eye(2)


def kraus_score(r, gamma, m):
    """Independent scorer: density matrix, amplitude-damping Kraus operators, Born rule for the projector along m."""
    rho = (I2 + r[0] * SX + r[1] * SY + r[2] * SZ) / 2
    K0 = np.array([[1, 0], [0, math.sqrt(1 - gamma)]]); K1 = np.array([[0, math.sqrt(gamma)], [0, 0]])
    out = K0 @ rho @ K0.conj().T + K1 @ rho @ K1.conj().T
    P = (I2 + m[0] * SX + m[1] * SY + m[2] * SZ) / 2
    return float(np.real(np.trace(out @ P)))


def FH():
    rng = np.random.default_rng(SEED + 7); r_true = np.array([0.42, -0.31, 0.58])
    slabs, _ = calibrate(r_true, (0, 1), 50000, 0.005, rng); M = random_dirs(rng, 60)
    table = {}; all_in = True; worst = 0.0
    for gamma in (0.0, 0.5, 0.9, 0.99):
        s = math.sqrt(1 - gamma); c = 0
        for m in M:
            n_eff = np.array([s * m[0], s * m[1], (1 - gamma) * m[2]]); off = gamma * m[2]     # Heisenberg picture of the channel
            mn, mx = extrema(n_eff, slabs, True); lo, hi = (1 + off + mn) / 2, (1 + off + mx) / 2
            p = kraus_score(r_true, gamma, m); all_in &= lo - 1e-9 <= p <= hi + 1e-9
            if (hi - lo) / 2 <= EPS:
                c += 1; worst = max(worst, abs((lo + hi) / 2 - p))
        table[str(gamma)] = c
    counts = [table[k] for k in ('0.0', '0.5', '0.9', '0.99')]
    ok = all_in and worst <= EPS and counts == sorted(counts) and counts[-1] > counts[0] and counts[-1] == len(M)
    must(ok, 'FH')
    R['FH'] = dict(claim='Cross-protocol transfer. Calibration is taken by direct measurement on two axes; the targets are a different '
                         'protocol: amplitude damping of known strength gamma followed by measurement along 60 directions never used. '
                         'The predictor works in the Heisenberg picture (a linear functional plus offset over the same admissible set); '
                         'the scorer is independent (density matrix, Kraus operators, Born rule). Every true probability lies in its '
                         'interval. The number certified grows with gamma, and at gamma = 0.99 all 60 are, because the channel itself '
                         'erases the unresolved coordinate: a target is forced when its kernel absorbs what the records leave open.',
                   status='computed', certified_by_gamma=table, total=len(M), max_certified_error=fl(worst))


if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--stage'); ap.add_argument('--work'); a = ap.parse_args()
    if a.stage:
        {'prepare': stage_prepare, 'predict': stage_predict, 'score': stage_score}[a.stage](Path(a.work)); sys.exit(0)
    for name, fn in (('FA', FA), ('FB', FB), ('FC', FC), ('FD', FD), ('FE', FE), ('FF', FF), ('FG', FG), ('FH', FH)):
        try:
            fn()
        except Exception as e:
            must(False, name); R[name] = dict(crash=repr(e))
        print(name, flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = sha(Path(__file__).read_bytes())
    (HERE / 'rg_forced_prediction_results.json').write_text(json.dumps(out, indent=1, sort_keys=True))
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
