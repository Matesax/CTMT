#!/usr/bin/env python3
"""Mutation suite for rg_native_chain.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. A few minutes.

    python3 -I rg_native_chain_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('NA', 'record distance with the wrong factor', '    return 2.0 * math.acos(min(1.0, float(np.sum(np.sqrt(p * q)))))', '    return 1.0 * math.acos(min(1.0, float(np.sum(np.sqrt(p * q)))))'),
    ('NA', 'mixture path taken as the geodesic', 'L_great = fisher_len(great)', 'L_great = fisher_len(lambda t: (1 - t) * p + t * q)'),
    ('NB', 'tangent cone test too loose (cusp read as manifold)', "return ('manifold' if dot < -0.9 else 'cusp'), nc, dot", "return ('manifold' if dot < 0.95 else 'cusp'), nc, dot"),
    ('NB', 'link resolution too coarse (branches merge)', 'cls, nc, dot = classify(X, tree, q, r, r / 8)', 'cls, nc, dot = classify(X, tree, q, r, r)'),
    ('NC', 'deficient family made full rank', '        g = np.stack([g[:, 0] + g[:, 1], g[:, 2]], 1)', '        g = g'),
    ('NC', 'wrong exponent normalisation', 'dimension=fl(math.log2(Ns[2] / Ns[0]) / 2)', 'dimension=fl(math.log2(Ns[2] / Ns[0]) / 3)'),
    ('ND', 'only ends and crossings flagged', "        if cls != 'manifold':", "        if cls in ('end', 'crossing'):"),
    ('NE', 'Fisher volume replaced by area', 'f = lambda p2, p1: 1 / math.sqrt(p1 * p2 * (1 - p1 - p2))', 'f = lambda p2, p1: 1.0'),
    ('NE', 'counting in Euclidean coordinates', 'XA, XB = emb(region(*A)), emb(region(*B))', 'XA, XB = region(*A), region(*B)'),
    ('NF', 'presentation change removed', '        seg2 = lambda s: (-2 + 0 * s, ps(s))', '        seg2 = lambda s: (-2 + 0 * s, s)'),
    ('NF', 're-parametrization that changes the record set (cusp smoothed)', 'cusp = lambda w: (2 + 0.5 * (w ** 3) ** 2, 0.5 * (w ** 3) ** 3)', 'cusp = lambda w: (2 + 0.5 * (w ** 3) ** 2, 0.5 * (w ** 3) ** 1)'),
    ('NG', 'fine resolution coarsened above the loop', 'fine = classify(X, tree, q, kappa * 0.25 * s_, kappa * 0.25 * s_ / 8)', 'fine = classify(X, tree, q, kappa * 6 * s_, kappa * 6 * s_ / 8)'),
    ('NG', 'loop removed', 'XY = np.concatenate([left, loop, right])', 'XY = np.concatenate([left, right])'),
]


def main():
    base = open(os.path.join(HERE, 'rg_native_chain.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_native_chain.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_native_chain.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_native_chain_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
