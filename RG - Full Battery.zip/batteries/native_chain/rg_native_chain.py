#!/usr/bin/env python3
"""Resolution Geometry - the native chain: records, width, count, derived manifold, strata.

No latent manifold is assumed. The latent space is any set; what is studied is the record image Q (the set of laws the
protocols can produce) inside the record simplex, with the record width as metric.

  NA record width on the simplex. The Fisher metric of a law on k outcomes is the pullback of the Euclidean metric under
     p -> 2 sqrt(p) (exact on random tangent vectors), so the record distance is the great-circle distance
     2 arccos sum sqrt(p_i q_i): the Fisher length of the great-circle path equals it, the mixture path is longer, and
     the Euclidean distance on the simplex is not it (canary)
  NB presentation walls are not record walls. Three curves through one law: s -> c + e s^3 u has latent Fisher zero at
     s = 0 and a smooth image (a record manifold point); t -> c + e (t^2 u + t^3 v) has latent Fisher zero and a cusp; a
     figure eight has full latent Fisher rank everywhere and a crossing. The record tests (link components, tangent cone)
     classify all three correctly; the latent Fisher rank errs both ways (a false wall, a missed crossing)
  NC dimension by counting. The exponent of the record covering number N(eps) ~ eps^-d gives the dimension of Q:
     1, 2, 3 for record images of dimension 1, 2, 3 (tori of laws, no boundary); a three-angle latent family whose laws
     depend on two combinations gives 2 (the quotient, not the latent space, is measured)
  ND canonical strata. On a composite record set (figure eight, cusp arc, cubed segment) a scan of every sampled law flags
     exactly the six non-manifold points (one crossing, one cusp, four ends) and not the cubed presentation wall
  NE counting is volume. The ratio of covering numbers of two record regions tends to the ratio of their Fisher volumes
     (Richardson in eps, within 2 per cent), not to the ratio of their Euclidean areas (canary, larger by a factor above 2)
  NF presentation invariance. Re-parametrizing every piece of the composite set by other smooth maps, some of them not
     immersions, moves the latent Fisher zeros (2 -> 5) and leaves the record strata unchanged (same six points)
  NG the resolution boundary. A loop of size s on a line is a crossing at resolution s/4 and a manifold point at the
     resolution of ND: below the resolution of the protocol regularity is not a record, above it it is

Deterministic. Seed 20261210. Writes rg_native_chain_results.json.
Run:  python3 -I rg_native_chain.py      (numpy, scipy)
"""
import hashlib, json, math, sys
from pathlib import Path
import numpy as np
from scipy.integrate import quad
from scipy.sparse.csgraph import connected_components
from scipy.sparse import coo_matrix
from scipy.spatial import cKDTree

HERE = Path(__file__).resolve().parent
SEED = 20261210
R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.8g}')


# ------------------------------------------------------------------ record simplex
def emb(P):
    """Record embedding p -> 2 sqrt(p): the simplex becomes an orthant of the sphere of radius 2."""
    return 2.0 * np.sqrt(np.clip(P, 0, None))


def fr(p, q):
    return 2.0 * math.acos(min(1.0, float(np.sum(np.sqrt(p * q)))))


def chord_of(arc):
    return 4.0 * math.sin(arc / 4.0)


def fisher_len(path, a=0.0, b=1.0, n=20001):
    t = np.linspace(a, b, n); P = np.array([path(x) for x in t]); dP = np.gradient(P, t, axis=0, edge_order=2)
    integrand = np.sqrt(np.sum(dP ** 2 / P, axis=1))
    return float(np.trapezoid(integrand, t))


# ------------------------------------------------------------------ record tests on a sampled set
def cover(X, eps):
    """Greedy covering number of a point set at chord radius eps, in a canonical (lexicographic) order."""
    order = np.lexsort(X.T[::-1]); X = X[order]; tree = cKDTree(X); free = np.ones(len(X), bool); n = 0
    for i in range(len(X)):
        if free[i]:
            n += 1; free[tree.query_ball_point(X[i], eps)] = False
    return n


def link(X, tree, q, r, delta):
    """Components of the record link {x in Q : r <= |x - q| <= 2r} and their mean unit directions."""
    idx = np.array(tree.query_ball_point(q, 2 * r));
    if len(idx) == 0:
        return 0, []
    d = np.linalg.norm(X[idx] - q, axis=1); idx = idx[d >= r]
    if len(idx) == 0:
        return 0, []
    A = X[idx]; sub = cKDTree(A); pairs = sub.query_pairs(delta, output_type='ndarray')
    m = len(A)
    G = coo_matrix((np.ones(len(pairs)), (pairs[:, 0], pairs[:, 1])), shape=(m, m)) if len(pairs) else coo_matrix((m, m))
    nc, lab = connected_components(G, directed=False)
    dirs = []
    for c in range(nc):
        v = (A[lab == c] - q).mean(0); dirs.append(v / np.linalg.norm(v))
    return nc, dirs


def classify(X, tree, q, r, delta):
    nc, dirs = link(X, tree, q, r, delta)
    if nc == 2:
        dot = float(dirs[0] @ dirs[1])
        return ('manifold' if dot < -0.9 else 'cusp'), nc, dot
    return {1: 'end', 4: 'crossing'}.get(nc, f'link{nc}'), nc, None


# ------------------------------------------------------------------ a plane of laws on three outcomes
C3 = np.array([1 / 3, 1 / 3, 1 / 3])
U = np.array([1.0, -1.0, 0.0]) / math.sqrt(2); V = np.array([1.0, 1.0, -2.0]) / math.sqrt(6)
EPS = 0.06


def law(x, y):
    return C3 + EPS * (np.multiply.outer(x, U) + np.multiply.outer(y, V))


def latent_fisher(curve, t, h=1e-6):
    p = curve(t); dp = (curve(t + h) - curve(t - h)) / (2 * h); return float(np.sum(dp ** 2 / p))


def group_NA():
    rng = np.random.default_rng(SEED)
    worst = 0.0
    for _ in range(200):
        k = int(rng.integers(3, 9)); p = rng.dirichlet(np.ones(k)); v = rng.normal(size=k); v -= v.mean()
        g = float(np.sum(v ** 2 / p)); e = float(np.sum((v / np.sqrt(p)) ** 2))      # d(2 sqrt p) = dp / sqrt p
        worst = max(worst, abs(g - e) / g)
    p = np.array([0.90, 0.05, 0.05]); q = np.array([0.05, 0.15, 0.80])
    a, b = np.sqrt(p), np.sqrt(q); th = math.acos(float(a @ b)); w = (b - (a @ b) * a); w /= np.linalg.norm(w)
    great = lambda t: (math.cos(t * th) * a + math.sin(t * th) * w) ** 2
    L_great = fisher_len(great); L_mix = fisher_len(lambda t: (1 - t) * p + t * q); d = fr(p, q); eu = float(np.linalg.norm(p - q))
    ok = worst < 1e-12 and abs(L_great - d) < 1e-6 and L_mix > d + 1e-3 and abs(eu - d) > 0.3
    must(ok, 'NA')
    R['NA'] = dict(claim='Record width on the simplex is the pullback of the Euclidean metric under p -> 2 sqrt p (relative '
                         'error below 1e-12 on 200 random tangent vectors, k = 3..8); the record distance is 2 arccos '
                         'sum sqrt(p q), attained by the great-circle path; the mixture path is longer; the Euclidean '
                         'distance is not the record distance (canary)',
                   pullback_rel_error=fl(worst), fr_closed_form=fl(d), great_circle_fisher_length=fl(L_great),
                   mixture_fisher_length=fl(L_mix), euclidean=fl(eu))


# ------------------------------------------------------------------ three presentations through one law
def curve_pieces(kind):
    """Composite record set: figure eight (crossing at the origin), cusp arc at (2,0), segment at x = -2.
    kind 'base' and 'repar' differ only in the latent presentation of each piece."""
    if kind == 'base':
        eight = lambda t: (0.5 * np.sin(2 * t), np.sin(t))
        cusp = lambda t: (2 + 0.5 * t ** 2, 0.5 * t ** 3)
        seg = lambda s: (-2 + 0 * s, s ** 3)
        par = [(eight, 0, 2 * math.pi), (cusp, -1, 1), (seg, -1, 1)]
    else:
        ph = lambda u: u - np.sin(2 * u) / 2                                                     # monotone, stalls at pi
        eight = lambda u: (0.5 * np.sin(2 * ph(u)), np.sin(ph(u)))
        cusp = lambda w: (2 + 0.5 * (w ** 3) ** 2, 0.5 * (w ** 3) ** 3)                         # t = w^3
        ps = lambda s: s - np.sin(4 * math.pi * s) / (4 * math.pi)                               # stalls at -1/2, 0, 1/2
        seg2 = lambda s: (-2 + 0 * s, ps(s))
        par = [(eight, 0, 2 * math.pi), (cusp, -1, 1), (seg2, -1, 1)]
    return par


def sample(par, n_arc=0.0008):
    pts = []
    for f, a, b in par:
        t = np.linspace(a, b, 400001); x, y = f(t); P = np.stack([x, y], 1)
        s = np.concatenate([[0], np.cumsum(np.linalg.norm(np.diff(P, axis=0), axis=1))])
        keep = np.searchsorted(s, np.arange(0, s[-1], n_arc)); keep = np.unique(np.append(keep, len(t) - 1))
        pts.append(P[keep])
    XY = np.concatenate(pts); return emb(law(XY[:, 0], XY[:, 1])), XY


def latent_zeros(par):
    zs = 0
    for f, a, b in par:
        curve = lambda t: law(*[np.atleast_1d(c) for c in f(np.atleast_1d(t))])[0]
        t = np.linspace(a, b, 20001); I = np.array([latent_fisher(curve, x) for x in t])
        low = I < 1e-6 * I.max(); starts = np.where(low[1:] & ~low[:-1])[0] + 1; ends = np.where(low[:-1] & ~low[1:])[0]
        zs += int(sum(1 for s0 in starts if any(e0 >= s0 for e0 in ends)))    # interior runs of vanishing Fisher (not at an end)
    return zs


def group_NB():
    out = {}
    cases = dict(cubed_segment=(lambda s: (0 * s, s ** 3), 'manifold'), cusp=(lambda t: (t ** 2, t ** 3), 'cusp'),
                 figure_eight=(lambda t: (0.5 * np.sin(2 * t), np.sin(t)), 'crossing'))
    ok = True
    for name, (f, want) in cases.items():
        a, b = (0, 2 * math.pi) if name == 'figure_eight' else (-1, 1)
        X, _ = sample([(f, a, b)]); tree = cKDTree(X)
        q = emb(law(np.array([0.0]), np.array([0.0])))[0]
        r = 0.02 * EPS * 2; cls, nc, dot = classify(X, tree, q, r, r / 8)
        t0 = 0.0
        curve = lambda t: law(*[np.atleast_1d(c) for c in f(np.atleast_1d(t))])[0]
        I0 = latent_fisher(curve, t0)
        out[name] = dict(record_class=cls, link_components=nc, tangent_dot=None if dot is None else fl(dot), latent_fisher_at_0=fl(I0))
        ok &= cls == want
    latent_says = {k: ('wall' if v['latent_fisher_at_0'] < 1e-8 else 'regular') for k, v in out.items()}
    latent_right = sum((latent_says[k] == 'regular') == (out[k]['record_class'] == 'manifold') for k in out)
    ok &= latent_right == 1 and latent_says['cubed_segment'] == 'wall' and latent_says['figure_eight'] == 'regular'
    must(ok, 'NB')
    R['NB'] = dict(claim='Presentation walls are not record walls. s -> s^3: latent Fisher zero, record image a manifold. '
                         'Cusp: latent Fisher zero, record cusp (tangent cone a half-line). Figure eight: full latent rank, '
                         'record crossing (four link components). Record tests classify all three; the latent Fisher rank '
                         'errs both ways (a false wall at s = 0, a missed crossing)', cases=out, latent_rank_correct=latent_right)


def torus_family(rng, d, k, n, deficient=False):
    """Laws on k outcomes tracing a d-torus (no boundary); deficient: three latent angles, laws depend on two combinations."""
    a = np.linspace(0, 2 * np.pi, n, endpoint=False)
    g = np.stack(np.meshgrid(*([a] * d), indexing='ij'), -1).reshape(-1, d)
    if deficient:
        g = np.stack([g[:, 0] + g[:, 1], g[:, 2]], 1)
    q = g.shape[1]
    M = np.linalg.qr(np.vstack([np.ones(k), rng.normal(size=(2 * q, k))]).T)[0][:, 1:2 * q + 1].T   # sum-zero, orthonormal
    P = np.ones(k) / k
    for j in range(q):
        P = P + 0.04 * (np.cos(g[:, j])[:, None] * M[2 * j] + np.sin(g[:, j])[:, None] * M[2 * j + 1])
    return emb(P)


def group_NC():
    rng = np.random.default_rng(SEED + 1)
    est = {}
    for name, (d, k, n, de, e) in dict(d1=(1, 4, 40000, False, 0.02), d2=(2, 6, 700, False, 0.06), d3=(3, 8, 90, False, 0.12),
                                       latent3_rank2=(3, 8, 90, True, 0.06)).items():
        X = torus_family(rng, d, k, n, de); Ns = [cover(X, e / 2 ** j) for j in range(3)]
        est[name] = dict(latent_dimension=d, eps=e, N=Ns, dimension=fl(math.log2(Ns[2] / Ns[0]) / 2))
    want = dict(d1=1, d2=2, d3=3, latent3_rank2=2)
    ok = all(abs(est[k_]['dimension'] - v) < 0.1 for k_, v in want.items())
    must(ok, 'NC')
    R['NC'] = dict(claim='Dimension by counting: on record images without boundary (tori of laws), the covering exponent '
                         '(log2 N(eps/4)/N(eps))/2 gives 1, 2, 3 within 0.1; a three-angle latent family whose laws '
                         'depend on two combinations gives 2: the quotient is measured, not the latent space', estimates=est)


def scan(X, XY, r):
    tree = cKDTree(X); flags = []
    for i in range(0, len(X), 3):
        cls, nc, dot = classify(X, tree, X[i], r, r / 8)
        if cls != 'manifold':
            flags.append(XY[i])
    flags = np.array(flags)
    if len(flags) == 0:
        return []
    p = cKDTree(flags).query_pairs(0.2, output_type='ndarray'); m = len(flags)
    G = coo_matrix((np.ones(len(p)), (p[:, 0], p[:, 1])), shape=(m, m)) if len(p) else coo_matrix((m, m))
    nc, lab = connected_components(G, directed=False)
    return sorted([tuple(np.round(flags[lab == c].mean(0), 2)) for c in range(nc)])


TRUTH = [(-2.0, -1.0), (-2.0, 1.0), (0.0, 0.0), (2.0, 0.0), (2.5, -0.5), (2.5, 0.5)]


def near(found, truth, tol=0.12):
    return len(found) == len(truth) and all(min(math.dist(f, t) for f in found) < tol for t in truth)


def group_ND_NF():
    r = 0.02 * EPS * 2
    Xb, XYb = sample(curve_pieces('base')); fb = scan(Xb, XYb, r)
    Xr, XYr = sample(curve_pieces('repar')); fr_ = scan(Xr, XYr, r)
    zb, zr = latent_zeros(curve_pieces('base')), latent_zeros(curve_pieces('repar'))
    okd = near(fb, TRUTH) and not any(math.dist(f, (-2.0, 0.0)) < 0.12 for f in fb)
    must(okd, 'ND')
    R['ND'] = dict(claim='A scan of every third sampled law of a composite record set flags exactly six non-manifold points '
                         '(crossing, cusp, four ends) and not the cubed presentation wall at (-2, 0)',
                   flagged=[list(map(fl, f)) for f in fb], truth=[list(t) for t in TRUTH], samples=len(Xb))
    okf = near(fr_, TRUTH) and zb == 2 and zr == 5
    must(okf, 'NF')
    R['NF'] = dict(claim='Re-parametrizing every piece (some maps not immersions) moves the latent Fisher zeros and leaves '
                         'the record strata unchanged', latent_fisher_zeros_base=zb, latent_fisher_zeros_repar=zr,
                   flagged_repar=[list(map(fl, f)) for f in fr_])


def group_NE():
    def region(lo1, lo2, lo3, hi3, n=3001):
        a = np.linspace(0, 1, n); P1, P2 = np.meshgrid(a, a); P3 = 1 - P1 - P2
        m = (P1 >= lo1) & (P2 >= lo2) & (P3 >= lo3) & (P3 <= hi3)
        P = np.stack([P1[m], P2[m], P3[m]], 1); return P
    def fr_area(lo1, lo2, lo3, hi3):
        f = lambda p2, p1: 1 / math.sqrt(p1 * p2 * (1 - p1 - p2))
        val = 0.0
        from scipy.integrate import dblquad
        val, _ = dblquad(lambda p2, p1: f(p2, p1), lo1, 1, lambda p1: max(lo2, 1 - p1 - hi3), lambda p1: max(lo2, 1 - p1 - lo3),
                         epsabs=1e-10, epsrel=1e-10)
        return val
    def eu_area(lo1, lo2, lo3, hi3):
        from scipy.integrate import dblquad
        v, _ = dblquad(lambda p2, p1: 1.0, lo1, 1, lambda p1: max(lo2, 1 - p1 - hi3), lambda p1: max(lo2, 1 - p1 - lo3))
        return v
    A = (0.25, 0.25, 0.25, 1.0); B = (0.1, 0.1, 0.02, 0.07)
    XA, XB = emb(region(*A)), emb(region(*B))
    eps = [0.08, 0.04, 0.02]; ratios = [cover(XA, e) / cover(XB, e) for e in eps]
    rich = 2 * ratios[2] - ratios[1]
    fa = fr_area(*A) / fr_area(*B); ea = eu_area(*A) / eu_area(*B)
    ok = abs(rich - fa) / fa < 0.02 and ea / fa > 2
    must(ok, 'NE')
    R['NE'] = dict(claim='Counting is volume: covering-number ratios of two record regions tend (Richardson) to the ratio '
                         'of Fisher volumes; the Euclidean area ratio differs (canary)', eps=eps, covering_ratio=[fl(x) for x in ratios],
                   richardson=fl(rich), fisher_volume_ratio=fl(fa), euclidean_area_ratio=fl(ea))


def group_NG():
    """A loop of size s on a line: a crossing at resolution below s, a manifold point above it."""
    s_ = 0.002
    u = np.linspace(-math.pi, math.pi, 200001); loop = np.stack([s_ * (u - 2 * np.sin(u)), s_ * (1 - 2 * np.cos(u))], 1)
    xr = np.arange(math.pi * s_, 0.3, 1e-5); right = np.stack([xr, np.full_like(xr, 3 * s_)], 1); left = right[::-1] * [-1, 1]
    XY = np.concatenate([left, loop, right]); X = emb(law(XY[:, 0], XY[:, 1])); tree = cKDTree(X)
    u0 = 1.8954942670339809; node = np.array([[0.0, s_ * (1 - 2 * math.cos(u0))]])
    q = emb(law(node[:, 0], node[:, 1]))[0]; kappa = EPS * math.sqrt(3)
    fine = classify(X, tree, q, kappa * 0.25 * s_, kappa * 0.25 * s_ / 8)
    coarse = classify(X, tree, q, 0.02 * EPS * 2, 0.02 * EPS * 2 / 8)
    ok = fine[0] == 'crossing' and coarse[0] == 'manifold'
    must(ok, 'NG')
    R['NG'] = dict(claim='Resolution boundary: a loop of size s = 0.002 on a line is a crossing at resolution s/4 and a '
                         'manifold point at the resolution used in ND (about 12 s). Below the resolution of the protocol '
                         'regularity is not a record; above it, it is',
                   loop_size=s_, fine=dict(record_class=fine[0], link_components=fine[1]),
                   coarse=dict(record_class=coarse[0], link_components=coarse[1], tangent_dot=None if coarse[2] is None else fl(coarse[2])))


def main():
    for g in (group_NA, group_NB, group_NC, group_ND_NF, group_NE, group_NG):
        g(); print(g.__name__, 'done', flush=True)
    R['failures'] = FAILS; R['seed'] = SEED
    R['source_sha256'] = hashlib.sha256((HERE / 'rg_native_chain.py').read_bytes()).hexdigest()
    (HERE / 'rg_native_chain_results.json').write_text(json.dumps(R, indent=1, sort_keys=True))
    print(json.dumps({k: v for k, v in R.items() if k != 'source_sha256'}, indent=1)[:6000])
    return 1 if FAILS else 0


if __name__ == '__main__':
    sys.exit(main())
