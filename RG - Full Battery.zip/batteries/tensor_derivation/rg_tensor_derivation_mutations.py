#!/usr/bin/env python3
"""Mutation suite for rg_tensor_derivation.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. A few minutes.

    python3 -I rg_tensor_derivation_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('C4', 'wrong limit', 'abs(lim[0] - 1) < 1e-9', 'abs(lim[0] - 2) < 1e-9'),
    ('R2', 'wrong mean stress', "abs(r['mean_stress'] - 0.25) < 1e-12", "abs(r['mean_stress'] - 0.5) < 1e-12"),
    ('R3', 'wrong product', 'prod == s.Rational(2, 3)', 'prod == s.Rational(1, 3)'),
    ('M1', 'nine symmetric components', "'symmetric_rank2': 10", "'symmetric_rank2': 9"),
    ('D1', 'spin 1 survives', "surv == ['massless_spin2_D4']", "surv == ['massless_spin1_D4']"),
    ('D2', 'wrong set of dimensions with stable orbits', "res == {'3': True, '4': False, '5': False, '6': False}", "res == {'3': True, '4': True, '5': False, '6': False}"),
    ('X2', 'three polarizations in 4D', "out['4']['physical'] == 2", "out['4']['physical'] == 3"),
    ('L1', 'wrong compatible count', 'free_compat == n * n * (n - 1) // 2', 'free_compat == n * n * (n + 1) // 2'),
]


def main():
    base = open(os.path.join(HERE, 'rg_tensor_derivation.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            for f in os.listdir(HERE):                                  # helpers and supplied data
                if f not in ('rg_tensor_derivation.py', 'rg_tensor_derivation_mutations.py', 'rg_tensor_derivation_results.json'):
                    (shutil.copytree if os.path.isdir(os.path.join(HERE, f)) else shutil.copy)(os.path.join(HERE, f), os.path.join(tmp, f))
            open(os.path.join(tmp, 'rg_tensor_derivation.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_tensor_derivation.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_tensor_derivation_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
