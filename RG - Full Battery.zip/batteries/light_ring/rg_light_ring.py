#!/usr/bin/env python3
"""RG - Hearing and Seeing the Light Ring: hostile battery.

Groups (every group carries a canary, i.e. a false variant that must fail):
  LA seeing: critical impact parameter = 1/Omega; azimuth slope = Omega/lambda; subring factor exp(-pi lambda/Omega)
     for three geometries (Schwarzschild, Reissner-Nordstrom, Bardeen); Schwarzschild-factor canary
  LB hearing, Schwarzschild, spins 0, 1, 2 (Leaver): mode ladder; two-mode estimators of (Omega, lambda);
     carriers of different spin give one pair; single-mode canary; two-cone canary
  LC hearing on other geometries (time-domain evolution, test scalar): validation against Leaver; ladder against
     the geodesic pair; joint relation: subring exponent predicted from two ringdown modes against ray tracing
  LD causal cap: a small bump far away changes nothing before the crossing time; echo at the round-trip delay
  LE counts at finite sensitivity; forward numbers for Sgr A* and for the remnant of GW150914; eikonal-error canary

Deterministic. Seed 20261116 (no random draws are needed; the seed is recorded). Writes rg_light_ring_results.json.
Run:  python3 -I rg_light_ring.py
"""
import hashlib, json, math, os, sys
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq, fsolve

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 20261116
R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.12g}')


# ---------------------------------------------------------------------------------------------- geometries f(r), M = 1
Q2, GB = 0.64, 0.5
METRICS = {
    'Schwarzschild': (lambda r: 1 - 2 / r, lambda r: 2 / r ** 2, lambda r: -4 / r ** 3),
    'Reissner-Nordstrom Q=0.8': (lambda r: 1 - 2 / r + Q2 / r ** 2, lambda r: 2 / r ** 2 - 2 * Q2 / r ** 3, lambda r: -4 / r ** 3 + 6 * Q2 / r ** 4),
    'Bardeen g=0.5': (lambda r: 1 - 2 * r * r / (r * r + GB ** 2) ** 1.5, lambda r: -4 * r / (r * r + GB ** 2) ** 1.5 + 6 * r ** 3 / (r * r + GB ** 2) ** 2.5,
                      lambda r: -4 / (r * r + GB ** 2) ** 1.5 + 30 * r * r / (r * r + GB ** 2) ** 2.5 - 30 * r ** 4 / (r * r + GB ** 2) ** 3.5),
}


STABLE = []


def light_ring(f, fp, fpp):
    """Unstable circular null orbit: radius, angular frequency Omega, instability exponent lambda (per unit time)."""
    rc = brentq(lambda r: r * fp(r) - 2 * f(r), 1.2, 10.0)
    lam2 = f(rc) * (2 * f(rc) - rc * rc * fpp(rc)) / (2 * rc * rc)
    if lam2 <= 0:
        STABLE.append(rc)                                               # not an unstable orbit: recorded as a failure of LA
    return rc, math.sqrt(f(rc)) / rc, math.sqrt(abs(lam2))


def horizon(f):
    rs = np.linspace(10.0, 0.3, 20000); v = f(rs); i = int(np.argmax(v < 0))
    return brentq(f, rs[i], rs[i - 1])


# ============================================================================================ LA: seeing
def _ray(f, fp, b, uh):
    """Photon from infinity with impact parameter b. Returns ('scatter', total azimuth) or ('capture', None)."""
    def rhs(p, y):
        u = max(y[0], 1e-12); r = 1 / u
        return [y[1], -u * f(r) + 0.5 * fp(r)]
    turn = lambda p, y: y[1]; turn.terminal = True; turn.direction = -1
    cap = lambda p, y: y[0] - 0.98 * uh; cap.terminal = True; cap.direction = 1
    s = solve_ivp(rhs, (0, 400), [1e-9, 1 / b], events=[turn, cap], rtol=1e-12, atol=1e-14)
    return ('scatter', 2 * s.t_events[0][0]) if len(s.t_events[0]) else ('capture', None)


def LA():
    out = {}
    for name, (f, fp, fpp) in METRICS.items():
        rc, Om, lam = light_ring(f, fp, fpp); uh = 1 / horizon(f)
        lo, hi = 0.5 / Om, 2.0 / Om
        for _ in range(60):
            mid = 0.5 * (lo + hi)
            if _ray(f, fp, mid, uh)[0] == 'scatter':
                hi = mid
            else:
                lo = mid
        bc = 0.5 * (lo + hi)
        ds = [10.0 ** (-k) for k in range(3, 8)]; az = [_ray(f, fp, (1 / Om) * (1 + d), uh)[1] for d in ds]
        slope = float(np.polyfit(np.log(1 / np.array(ds[1:])), az[1:], 1)[0])
        out[name] = dict(ring_radius=rc, Omega=Om, exponent=lam, b_critical=bc, b_times_Omega=bc * Om, azimuth_slope=slope,
                         Omega_over_lambda=Om / lam, subring_exponent=math.pi * lam / Om, subring_factor=math.exp(-math.pi * lam / Om),
                         half_orbit_delay=math.pi / Om)
    s = out['Schwarzschild']; rn = out['Reissner-Nordstrom Q=0.8']
    canary = abs(rn['subring_factor'] - math.exp(-math.pi)) / math.exp(-math.pi)      # the Schwarzschild factor is wrong for another geometry
    ok = all(abs(v['b_times_Omega'] - 1) < 1e-7 and abs(v['azimuth_slope'] / v['Omega_over_lambda'] - 1) < 2e-3 for v in out.values()) \
        and abs(s['subring_exponent'] - math.pi) < 1e-9 and abs(s['b_critical'] - 3 * math.sqrt(3)) < 1e-6 and canary > 0.2 and not STABLE
    must(ok, 'LA')
    R['LA'] = dict(claim='Seeing. For three static geometries the critical impact parameter found by ray tracing equals 1/Omega of '
                         'the unstable circular null orbit, and the total azimuth of a ray at b = b_c (1 + delta) grows like '
                         '(Omega/lambda) ln(1/delta). Hence each further half orbit demagnifies by exp(-pi lambda/Omega) and is '
                         'delayed by pi/Omega: both are fixed by the pair (Omega, lambda) alone. Canary: the Schwarzschild factor '
                         'exp(-pi) = 0.0432 is wrong by 41 per cent for the charged geometry (0.0610).',
                   status='PROVED (return map of the orbit) + ray tracing', geometries={k: {a: fl(b) for a, b in v.items()} for k, v in out.items()},
                   schwarzschild_factor_error_on_RN=fl(canary))
    return out


# ============================================================================================ LB: hearing, Schwarzschild
def _leaver(l, s, nmax=600):
    eps_ = s * s - 1; lam_c = 1 / (3 * math.sqrt(3))
    def cf(w):
        rho = -1j * w                                               # units 2M = 1
        al = lambda n: n * n + (2 * rho + 2) * n + 2 * rho + 1
        be = lambda n: -(2 * n * n + (8 * rho + 2) * n + 8 * rho * rho + 4 * rho + l * (l + 1) - eps_)
        ga = lambda n: n * n + 4 * rho * n + 4 * rho * rho - eps_ - 1
        f = 0
        for n in range(nmax, 0, -1):
            f = al(n - 1) * ga(n) / (be(n) - f)
        return be(0) - f
    F = lambda v: [cf(complex(v[0], v[1])).real, cf(complex(v[0], v[1])).imag]
    sol = fsolve(F, [2 * (l + 0.5) * lam_c, -lam_c], xtol=1e-13)
    return complex(sol[0], sol[1]) / 2


def ladder(w1, l1, w2, l2):
    """Two fundamental modes -> (Omega, lambda): removes the 1/L term of Re and the 1/L^2 term of Im."""
    L1, L2 = l1 + 0.5, l2 + 0.5
    return (L2 * w2.real - L1 * w1.real) / (L2 ** 2 - L1 ** 2), 2 * (L2 ** 2 * (-w2.imag) - L1 ** 2 * (-w1.imag)) / (L2 ** 2 - L1 ** 2)


def LB():
    Om = lam = 1 / (3 * math.sqrt(3)); modes = {s: {l: _leaver(l, s) for l in range(2, 7)} for s in (0, 1, 2)}
    est, single = {}, {}
    for s in (0, 1, 2):
        est[s] = {f'{l},{l + 1}': ladder(modes[s][l], l, modes[s][l + 1], l + 1) for l in (2, 3, 5)}
        single[s] = (modes[s][2].real / 2.5 / Om - 1, 2 * (-modes[s][2].imag) / lam - 1)
    err = {s: {k: (v[0] / Om - 1, v[1] / lam - 1) for k, v in est[s].items()} for s in est}
    # carriers of different spin on one geometry give one pair: light (s = 1) against gravitational waves (s = 2)
    carrier = max(abs(est[1]['2,3'][i] / est[2]['2,3'][i] - 1) for i in (0, 1))
    # canary: two cones. Gravitational modes of Schwarzschild against the light ring of the charged geometry
    f, fp, fpp = METRICS['Reissner-Nordstrom Q=0.8']; _, Om_rn, lam_rn = light_ring(f, fp, fpp); two_cone = abs(est[2]['2,3'][0] / Om_rn - 1)
    known = abs(modes[2][2] - complex(0.37367, -0.08896)) < 2e-5 and abs(modes[0][2] - complex(0.48364, -0.09676)) < 2e-5
    # the claimed order of the error: relative error times L1^2 L2^2 is a bounded coefficient, constant for the frequency
    LL = {'2,3': (2.5 * 3.5) ** 2, '3,4': (3.5 * 4.5) ** 2, '5,6': (5.5 * 6.5) ** 2}
    coef = {s: {k: (err[s][k][0] * LL[k], err[s][k][1] * LL[k]) for k in LL} for s in err}
    spread = max(max(abs(c[0]) for c in coef[s].values()) / min(abs(c[0]) for c in coef[s].values()) for s in coef)
    bounded = max(abs(c[i]) for s in coef for c in coef[s].values() for i in (0, 1))
    # canary: the plain spacing of two modes has an error of the lower order 1/(L1 L2); its coefficient is not bounded
    plain = {k: ((modes[2][l + 1].real - modes[2][l].real) / Om - 1) * LL[k] for k, l in (('2,3', 2), ('5,6', 5))}
    scaling = spread < 1.12 and bounded < 0.65 and plain['5,6'] / plain['2,3'] > 3
    ok = known and scaling and all(abs(e[0]) < 0.012 and abs(e[1]) < 0.012 for s in err for e in err[s].values()) \
        and all(abs(err[s]['5,6'][0]) < abs(err[s]['2,3'][0]) for s in err) and abs(err[2]['3,4'][0]) < 0.003 \
        and abs(single[2][0]) > 0.2 and abs(single[2][1]) > 0.07 and carrier < 0.012 and two_cone > 0.1
    must(ok, 'LB')
    R['LB'] = dict(claim='Hearing. Fundamental quasinormal frequencies of Schwarzschild for spins 0, 1, 2 (Leaver). A single l = 2 '
                         'gravitational mode misses the orbit frequency by 22 per cent and the exponent by 8 per cent. Two modes '
                         'remove the leading correction, whatever its spin-dependent coefficient: from l = 2, 3 the pair (Omega, '
                         'lambda) is recovered to 0.8 and 0.4 per cent for gravitational waves, better for the other spins, and to '
                         '0.2 per cent from l = 3, 4. Light and gravitational waves give one pair to 1 per cent: hearing equals '
                         'seeing when both carriers share the cone. The claimed order holds: the error times L1^2 L2^2 is a '
                         'bounded coefficient (below 0.65), constant to 8 per cent for the frequency; for the exponent of '
                         'gravitational waves it rises from 0.30 to 0.50, so l = 2 is not yet asymptotic there. Canaries: against '
                         'the light ring of a different geometry the mismatch is 12 per cent; the plain spacing of two modes has '
                         'an unbounded coefficient (13 to 48).',
                   status='computed (Leaver) + asymptotic form of the mode ladder', modes={str(s): {str(l): [fl(w.real), fl(w.imag)] for l, w in modes[s].items()} for s in modes},
                   ladder_rel_err={str(s): {k: [fl(e[0]), fl(e[1])] for k, e in err[s].items()} for s in err},
                   single_mode_rel_err={str(s): [fl(v[0]), fl(v[1])] for s, v in single.items()}, error_coefficient={str(s): {k: [fl(c[0]), fl(c[1])] for k, c in coef[s].items()} for s in coef},
                   coefficient_spread_frequency=fl(spread), plain_spacing_coefficient={k: fl(v) for k, v in plain.items()}, light_vs_gravity=fl(carrier), two_cone_mismatch=fl(two_cone))
    return modes


# ============================================================================================ LC, LD: time domain
def _evolve(f, fp, rc, l, T=240.0, h=0.1, xobs=30.0, bump=None):
    """Scalar wave psi_tt = psi_xx - V psi in the tortoise coordinate x (x = 0 at the light ring); signal at xobs."""
    xmax = T / 2 + xobs + 40; n_pos = int(round(xmax / h)); n_neg = int(round((T / 2 + 40) / h))
    def rk(n, sgn):
        out = np.empty(n + 1); out[0] = r_ = rc; hh = sgn * h
        for i in range(n):
            k1 = f(r_); k2 = f(r_ + 0.5 * hh * k1); k3 = f(r_ + 0.5 * hh * k2); k4 = f(r_ + hh * k3); r_ = r_ + hh * (k1 + 2 * k2 + 2 * k3 + k4) / 6; out[i + 1] = r_
        return out
    r = np.concatenate([rk(n_neg, -1)[::-1], rk(n_pos, 1)[1:]]); x = (np.arange(len(r)) - n_neg) * h
    V = f(r) * (l * (l + 1) / r ** 2 + fp(r) / r)
    if bump is not None:
        V = V + bump(x)
    dt = h / 2; pulse = lambda y: np.where(np.abs(y - 20.0) < 12.0, np.cos(np.pi * (y - 20.0) / 24.0) ** 4, 0.0)     # compact, ingoing
    p0, p1 = pulse(x - dt), pulse(x); io = int(round(xobs / h)) + n_neg; nst = int(round(T / dt)); sig = np.empty(nst); c2 = (dt / h) ** 2
    for n in range(nst):
        p2 = np.zeros_like(p1); p2[1:-1] = 2 * p1[1:-1] - p0[1:-1] + c2 * (p1[2:] - 2 * p1[1:-1] + p1[:-2]) - dt * dt * V[1:-1] * p1[1:-1]
        p0, p1 = p1, p2; sig[n] = p1[io]
    return np.arange(1, nst + 1) * dt, sig


def _qnm(t, y, t0, t1, order=6, stride=8):
    """Dominant damped oscillation in a window, by linear prediction; selected by fitted amplitude, not by a target."""
    m = (t >= t0) & (t <= t1); tt = t[m][::stride]; yy = y[m][::stride]; d = tt[1] - tt[0]; N = len(yy)
    A = np.stack([yy[order - 1 - k:N - 1 - k] for k in range(order)], 1); c = np.linalg.lstsq(A, yy[order:], rcond=None)[0]
    w = 1j * np.log(np.roots(np.concatenate([[1], -c]))) / d
    amp = np.linalg.lstsq(np.exp(-1j * np.outer(tt - tt[0], w)), yy.astype(complex), rcond=None)[0]
    k = int(np.argmax(np.abs(amp) * (np.abs(w.real) > 0.05)))
    return complex(abs(w[k].real), w[k].imag)


def LC(seen):
    f, fp, fpp = METRICS['Schwarzschild']; val = {}
    for l in (2, 3, 4):
        t, y = _evolve(f, fp, 3.0, l); w = _qnm(t, y, 80, 170); ex = _leaver(l, 0)
        val[l] = (abs(w.real / ex.real - 1), abs(w.imag / ex.imag - 1), abs(w - _qnm(t, y, 90, 180)) / abs(w))
    out = {}
    for name in ('Reissner-Nordstrom Q=0.8', 'Bardeen g=0.5'):
        f, fp, fpp = METRICS[name]; rc, Om, lam = light_ring(f, fp, fpp); ws = {}
        for l in (2, 3, 4):
            t, y = _evolve(f, fp, rc, l); ws[l] = _qnm(t, y, 80, 170)
        Oe, le = ladder(ws[2], 2, ws[3], 3)
        gamma_heard = math.pi * le / Oe; gamma_seen = math.pi / seen[name]['azimuth_slope']       # from two ringdown modes / from ray tracing
        out[name] = dict(modes={str(l): [fl(w.real), fl(w.imag)] for l, w in ws.items()}, Omega_err=fl(Oe / Om - 1), lambda_err=fl(le / lam - 1),
                         shadow_from_ringdown=fl(1 / Oe), shadow_from_rays=fl(seen[name]['b_critical']), subring_exponent_from_ringdown=fl(gamma_heard),
                         subring_exponent_from_rays=fl(gamma_seen), joint_rel_diff=fl(gamma_heard / gamma_seen - 1),
                         shadow_rel_diff=fl((1 / Oe) / seen[name]['b_critical'] - 1))
    # canary: the ringdown of one geometry does not predict the image of the other
    cross = abs(out['Reissner-Nordstrom Q=0.8']['shadow_from_ringdown'] / out['Bardeen g=0.5']['shadow_from_rays'] - 1)
    ok = all(v[0] < 3e-4 and v[1] < 3e-3 and v[2] < 5e-4 for v in val.values()) and all(abs(v['Omega_err']) < 1e-3 and abs(v['lambda_err']) < 4e-3
                                                                                          and abs(v['joint_rel_diff']) < 4e-3 and abs(v['shadow_rel_diff']) < 1e-3 for v in out.values()) and cross > 0.05
    must(ok, 'LC')
    R['LC'] = dict(claim='Hearing and seeing on other geometries. Time-domain evolution of a test wave, with the dominant mode '
                         'selected by amplitude and not by a target, reproduces the Leaver values to 2e-4 in frequency and 2e-3 in '
                         'damping. On a charged and on a regular (non-vacuum) geometry two ringdown modes give the orbit frequency '
                         'to 3e-4 and the exponent to 2e-3; the shadow radius predicted from the ringdown equals the ray-traced one '
                         'to 3e-4, and the subring exponent predicted from the ringdown equals the ray-traced one to 2e-3. No field equation of the background is used. Canary: the '
                         'ringdown of one geometry misses the shadow of the other by 8 per cent.',
                   status='computed', validation_rel_err={str(l): [fl(v[0]), fl(v[1]), fl(v[2])] for l, v in val.items()}, geometries=out, cross_geometry_mismatch=fl(cross))


def LD():
    f, fp, fpp = METRICS['Schwarzschild']; xb, half, eps = 150.0, 6.0, 1e-3
    bump = lambda x: np.where(np.abs(x - xb) < half, eps * np.cos(np.pi * (x - xb) / (2 * half)) ** 4, 0.0)
    t, y0 = _evolve(f, fp, 3.0, 2, T=420.0); _, y1 = _evolve(f, fp, 3.0, 2, T=420.0, bump=bump); D = np.abs(y1 - y0); scale = float(np.max(np.abs(y0)))
    # numerical cone: the stencil moves two cells per unit time; physical cone: one. Paths: pulse edge (32) -> bump edge (144) -> observer (30)
    t_num, t_phys = (112 + 114) / 2, 112 + 114
    before_num = float(np.max(D[t < t_num - 1])); before_phys = float(np.max(D[t < t_phys - 2])) / scale; after = float(np.max(D[t > t_phys])) / scale
    w0, w1 = _qnm(t, y0, 80, 170), _qnm(t, y1, 80, 170); prompt = abs(w1 - w0) / abs(w0)
    # echo: round trip observer -> bump -> observer adds 2 (xb - xobs) to the arrival of the ringdown
    env0 = np.abs(y0); t_ring = float(t[np.argmax(env0 * (t > 40))]); t_echo = float(t[np.argmax(D)]); delay = t_echo - t_ring
    late0, late1 = float(np.max(np.abs(y0[t > 280]))) / scale, float(np.max(np.abs(y1[t > 280]))) / scale
    ok = before_num == 0.0 and before_phys < 1e-9 and after > 1e-6 and prompt < 1e-9 and abs(delay / 240.0 - 1) < 0.05 and late1 > 20 * late0
    must(ok, 'LD')
    R['LD'] = dict(claim='Causal cap for the ringdown. A bump of height 1e-3 in the potential at tortoise distance 150 changes the '
                         'signal at the observer by exactly zero before the numerical cone can connect them, by less than 1e-9 '
                         'before the physical crossing time 226, and the frequency fitted on the prompt window is unchanged. After '
                         'the crossing time an echo arrives, delayed by twice the distance from observer to bump (240), and the '
                         'late signal is larger by five orders of magnitude (1.2 per cent of the peak). The prompt ringdown is a record of the light ring; '
                         'the late signal, and with it the spectrum, is a record of the environment. Canary: the late windows differ.',
                   status='PROVED (finite propagation) + computed', diff_before_numerical_cone=fl(before_num), rel_diff_before_crossing=fl(before_phys),
                   rel_diff_after_crossing=fl(after), prompt_frequency_change=fl(prompt), echo_delay=fl(delay), predicted_delay=240.0,
                   late_amplitude_without_bump=fl(late0), late_amplitude_with_bump=fl(late1))


# ============================================================================================ LE: counts and forward numbers
def _kerr_light_ring(a, M=1.0):
    def conds(v):
        r, b = v; P = r * r + a * a - a * b
        return [P * P - (r * r - 2 * M * r + a * a) * (b - a) ** 2, 4 * r * P - (2 * r - 2 * M) * (b - a) ** 2]
    r, b = fsolve(conds, [2 * M * (1 + math.cos(2 / 3 * math.acos(-a / M))), 3 * math.sqrt(3) * M * (1 - 0.5 * a) + 1e-3], xtol=1e-12)
    P = r * r + a * a - a * b; D = r * r - 2 * M * r + a * a; Rpp = 4 * P + 8 * r * r - 2 * (b - a) ** 2
    tdot = -a * (a - b) + (r * r + a * a) * P / D; pdot = -(a - b) + a * P / D
    return float(b), float(pdot / tdot), float(math.sqrt(Rpp / 2) / tdot)


def LE(modes):
    Om = lam = 1 / (3 * math.sqrt(3)); w22 = modes[2][2]; Q = w22.real / (2 * -w22.imag)
    # counts: each further subring costs gamma e-folds of flux; the ringdown is above the noise for ln(SNR)/|omega_I|
    rings = {dr: math.floor(math.log(dr) / math.pi) for dr in (10.0, 1e2, 1e3, 1e6)}
    cycles = {snr: Q * math.log(snr) / math.pi for snr in (10.0, 30.0, 100.0)}
    # canary: the eikonal relations applied to the l = 2 mode alone
    naive = dict(shadow_times_frequency=w22.real / (2.5 * Om) - 1, exponent=math.pi * 2.5 / Q / math.pi - 1, delay_over_period=(math.pi / Om) / (2.5 * math.pi / w22.real) - 1)
    # Sgr A*: mass and distance from stellar orbits (VLTI): shadow, half-orbit delay, zero-spin ringdown
    G_c3 = 4.925490947e-6; G_c2 = 1476.625; pc = 3.0856775814913673e16; uas = math.degrees(1) * 3600e6
    Ms = 4.297e6; Tg = Ms * G_c3; theta = Ms * G_c2 / (8277.0 * pc) * uas
    sgr = dict(shadow_diameter_uas=6 * math.sqrt(3) * theta, half_orbit_delay_s=math.pi / Om * Tg, ringdown_mHz=w22.real / (2 * math.pi * Tg) * 1e3,
               ringdown_decay_s=Tg / -w22.imag, measured_over_predicted_shadow=0.92, measured_err=0.09)
    # remnant of GW150914 (68 solar masses, spin 0.67): prograde equatorial light ring
    b, Omk, lamk = _kerr_light_ring(0.67); Tr = 68 * G_c3
    gw = dict(impact_parameter_km=b * 68 * G_c2 / 1e3, Omega_times_b=Omk * b, subring_exponent=math.pi * lamk / Omk, subring_factor=math.exp(-math.pi * lamk / Omk),
              half_orbit_delay_ms=math.pi / Omk * Tr * 1e3, twice_efolding_ms=2 / lamk * Tr * 1e3)
    ok = rings == {10.0: 0, 1e2: 1, 1e3: 2, 1e6: 4} and abs(Q - 2.1002) < 1e-3 and abs(naive['shadow_times_frequency']) > 0.2 and abs(naive['exponent']) > 0.15 \
        and abs(sgr['shadow_diameter_uas'] - 53.25) < 0.05 and abs(sgr['measured_over_predicted_shadow'] - 1) < 2 * sgr['measured_err'] \
        and abs(gw['Omega_times_b'] - 1) < 1e-9 and abs(gw['twice_efolding_ms'] - 3.80) < 0.01 and 0.1 < gw['subring_factor'] < 0.15
    must(ok, 'LE')
    R['LE'] = dict(claim='Counts and forward numbers. An image of dynamic range 10, 100, 1000 shows 0, 1, 2 subrings beyond the direct '
                         'image (zero spin); a ringdown of signal-to-noise 10, 30, 100 stays above the noise for 1.5, 2.3, 3.1 '
                         'cycles. For Sgr A*, with mass and distance from stellar orbits: shadow 53.3 microarcseconds (measured '
                         '0.92 +- 0.09 of it), half-orbit delay 345 s, zero-spin ringdown 2.81 mHz decaying in 238 s. For the '
                         'remnant of GW150914: prograde impact parameter 366 km, subring factor 0.133, half-orbit delay 3.83 ms. '
                         'Canary: the eikonal relations applied to the single l = 2 mode fail by 22, 19 and 22 per cent.',
                   status='computed + published inputs', subrings_by_dynamic_range={str(k): v for k, v in rings.items()}, quality_factor=fl(Q),
                   cycles_by_snr={str(k): fl(v) for k, v in cycles.items()}, single_mode_relation_errors={k: fl(v) for k, v in naive.items()},
                   sgr_a=dict((k, fl(v)) for k, v in sgr.items()), gw150914_remnant=dict((k, fl(v)) for k, v in gw.items()))


if __name__ == '__main__':
    seen = LA(); print('LA', flush=True)
    modes = LB(); print('LB', flush=True)
    LC(seen); print('LC', flush=True)
    LD(); print('LD', flush=True)
    LE(modes); print('LE', flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(open(os.path.abspath(__file__), 'rb').read()).hexdigest()
    json.dump(out, open(os.path.join(HERE, 'rg_light_ring_results.json'), 'w'), indent=1, sort_keys=True)
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
