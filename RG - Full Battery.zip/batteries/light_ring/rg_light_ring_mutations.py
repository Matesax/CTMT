#!/usr/bin/env python3
"""Mutation suite for rg_light_ring.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. About one minute.

    python3 -I rg_light_ring_mutations.py
"""
import json, os, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('LA', 'wrong force term in the photon orbit', "return [y[1], -u * f(r) + 0.5 * fp(r)]", "return [y[1], -u * f(r) + 0.4 * fp(r)]"),
    ('LA', 'wrong sign in the instability exponent', "(2 * f(rc) - rc * rc * fpp(rc))", "(2 * f(rc) + rc * rc * fpp(rc))"),
    ('LB', 'plain mode spacing instead of the ladder estimator', "return (L2 * w2.real - L1 * w1.real) / (L2 ** 2 - L1 ** 2),", "return (w2.real - w1.real) / (L2 - L1),"),
    ('LB', 'wrong spin term in the continued fraction', "eps_ = s * s - 1; lam_c = 1 / (3 * math.sqrt(3))", "eps_ = s * s; lam_c = 1 / (3 * math.sqrt(3))"),
    ('LB', 'error of the ladder claimed at the wrong order', "LL = {'2,3': (2.5 * 3.5) ** 2,", "LL = {'2,3': (2.5 * 3.5) ** 1,"),
    ('LC', 'wrong sign of the curvature term in the wave potential', "V = f(r) * (l * (l + 1) / r ** 2 + fp(r) / r)", "V = f(r) * (l * (l + 1) / r ** 2 - fp(r) / r)"),
    ('LC', 'ringdown of the wrong geometry', "f, fp, fpp = METRICS[name]; rc, Om, lam = light_ring(f, fp, fpp); ws = {}", "f, fp, fpp = METRICS['Schwarzschild']; rc, Om, lam = light_ring(*METRICS[name]); rc = 3.0; ws = {}"),
    ('LD', 'environment inside the prompt window', "xb, half, eps = 150.0, 6.0, 1e-3", "xb, half, eps = 60.0, 6.0, 1e-3"),
    ('LE', 'mass of Sgr A* from the wrong estimate', "Ms = 4.297e6; Tg = Ms * G_c3", "Ms = 6.0e6; Tg = Ms * G_c3"),
    ('LE', 'remnant without spin', "b, Omk, lamk = _kerr_light_ring(0.67); Tr = 68 * G_c3", "b, Omk, lamk = _kerr_light_ring(0.0); Tr = 68 * G_c3"),
]


def main():
    base = open(os.path.join(HERE, 'rg_light_ring.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_light_ring.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_light_ring.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_light_ring_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
