#!/usr/bin/env python3
"""RG - One World Attack: can agreement of different experiments on the same numbers demote the atom to a gluing invariant?

Setting. Several protocols each give a law (a probability table or a number). "One World" says one state, on a declared
cone, has all of these laws as its images. On the classical cone the state is a joint distribution of all outcomes, that is
an object with pre-existing values ("the ball"). The battery asks where the two descriptions can be told apart by data.

  WA gluing criterion: for four two-outcome protocols (CHSH scenario) with consistent marginals, a classical global section
     exists exactly when all eight CHSH values are at most 2 (Fine); checked by linear programming on random no-signalling
     tables; canary: the PR box has none
  WB realism is free when gluing is classical: from every classical section the battery builds an explicit object model
     (weights on the 16 deterministic value assignments) that reproduces all four protocol laws; the two descriptions are
     then interchangeable, so agreement of protocols cannot demote the object
  WC where data decide: the singlet reaches 2 sqrt 2 (Tsirelson) with one quantum state, so there is a quantum section and no
     classical one; the loophole-free test of Hensen et al. (S = 2.42 +- 0.20, p = 0.039) excludes the classical section,
     i.e. objects with pre-existing, protocol-independent values; canary: a classical mixture stays at 2
  WD gluing of numbers in today's data: the inverse fine-structure constant from Cs recoil, Rb recoil and the electron
     magnetic moment; pairwise tensions, chi^2 and Birge ratio; the three do not glue (Cs-Rb 5.5 sigma); canary: a
     synthetic consistent set glues

Deterministic. Seed 20261130. Writes rg_one_world_attack_results.json.
Run:  python3 -I rg_one_world_attack.py      (numpy, scipy)
"""
import hashlib, itertools, json, math, os, sys
import numpy as np
from scipy.optimize import linprog

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 20261130
R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.8g}')


def below(v, b):
    return f'< {b:g}' if abs(v) < b else fl(v)


# Behaviour p[x, y, a, b]: protocol pair (x, y) in {0,1}^2, outcomes a, b in {0,1}
DET = list(itertools.product((0, 1), repeat=4))            # deterministic assignment (a0, a1, b0, b1): pre-existing values


def det_table(d):
    a0, a1, b0, b1 = d; p = np.zeros((2, 2, 2, 2))
    for x in (0, 1):
        for y in (0, 1):
            p[x, y, (a0, a1)[x], (b0, b1)[y]] = 1.0
    return p


DT = np.array([det_table(d).ravel() for d in DET]).T      # 16 x 16


def classical_section(p):
    """Weights w >= 0, sum w = 1, sum w_d table_d = p. Returns weights or None."""
    A = np.vstack([DT, np.ones((1, 16))]); b = np.r_[p.ravel(), 1.0]
    r = linprog(np.zeros(16), A_eq=A, b_eq=b, bounds=[(0, None)] * 16, method='highs')
    return r.x if r.status == 0 else None


def correl(p, x, y):
    return sum(p[x, y, a, b] * (1 if a == b else -1) for a in (0, 1) for b in (0, 1))


def chsh_all(p):
    E = [[correl(p, x, y) for y in (0, 1)] for x in (0, 1)]; out = []
    for s in itertools.product((1, -1), repeat=4):
        if s[0] * s[1] * s[2] * s[3] == -1:
            out.append(s[0] * E[0][0] + s[1] * E[0][1] + s[2] * E[1][0] + s[3] * E[1][1])
    return out


def random_no_signalling(rng):
    """Convex mixture of deterministic tables, PR boxes and noise: no-signalling by construction."""
    pr = np.zeros((2, 2, 2, 2))
    for x, y, a, b in itertools.product((0, 1), repeat=4):
        pr[x, y, a, b] = 0.5 if (a ^ b) == (x & y) else 0.0
    w = rng.dirichlet(np.ones(4)); prw = rng.uniform(0, 0.6)
    loc = sum(wi * det_table(DET[rng.integers(16)]) for wi in w)
    return (1 - prw) * loc + prw * pr, pr


def WA():
    rng = np.random.default_rng(SEED); agree = 0; n = 400; inside = 0
    for _ in range(n):
        p, pr = random_no_signalling(rng)
        has = classical_section(p) is not None; crit = max(chsh_all(p)) <= 2 + 1e-9
        agree += int(has == crit); inside += int(has)
    pr_has = classical_section(pr) is not None; pr_S = max(chsh_all(pr))
    ok = agree == n and 0 < inside < n and not pr_has and abs(pr_S - 4) < 1e-12
    must(ok, 'WA')
    R['WA'] = dict(claim='Gluing criterion. For four two-outcome protocols with consistent marginals, a classical global section (one '
                         'joint distribution whose marginals are all four observed laws) exists exactly when all eight CHSH values are '
                         'at most 2. Linear programming on 400 random no-signalling tables agrees with the inequality criterion in every '
                         'case; both outcomes occur. Canary: the PR box (CHSH = 4) has no section.',
                   status='computed; IDENTIFIED (Fine 1982; Abramsky-Brandenburger 2011)', tables=n, agreement=agree, with_section=inside, pr_box_chsh=fl(pr_S))


def WB():
    rng = np.random.default_rng(SEED + 1); worst, n = 0.0, 0
    for _ in range(300):
        p, _ = random_no_signalling(rng)
        w = classical_section(p)
        if w is None:
            continue
        n += 1; rec = sum(wi * det_table(d) for wi, d in zip(w, DET)); worst = max(worst, float(np.abs(rec - p).max()))
    ok = n > 50 and worst < 1e-9
    must(ok, 'WB')
    R['WB'] = dict(claim='Realism is free whenever gluing is classical. For every table with a classical section, the section is an '
                         'explicit object model: a probability over the 16 assignments of pre-existing values to the four protocols. '
                         'It reproduces every protocol law to the residual below. On such data the "gluing invariant" and the "object" '
                         'are two names for one mathematical structure; agreement between protocols cannot decide between them.',
                   status='computed', tables_with_section=n, reproduction_residual=below(worst, 1e-9))


def WC():
    # singlet with optimal settings: E(x, y) = -cos(theta_x - phi_y)
    th, ph = (0.0, np.pi / 2), (np.pi / 4, -np.pi / 4)
    p = np.zeros((2, 2, 2, 2))
    for x, y in itertools.product((0, 1), repeat=2):
        E = -math.cos(th[x] - ph[y])
        for a, b in itertools.product((0, 1), repeat=2):
            p[x, y, a, b] = (1 + (1 if a == b else -1) * E) / 4
    S = max(chsh_all(p)); has = classical_section(p) is not None
    # Tsirelson-Landau-Masanes criterion for correlations
    E = np.array([[correl(p, x, y) for y in (0, 1)] for x in (0, 1)])
    asn = lambda v: math.asin(max(-1.0, min(1.0, v)))
    tlm = abs(asn(E[0, 0]) + asn(E[0, 1]) + asn(E[1, 0]) - asn(E[1, 1])) / math.pi
    tlm = max(tlm, abs(asn(E[0, 0]) + asn(E[0, 1]) - asn(E[1, 0]) + asn(E[1, 1])) / math.pi, abs(asn(E[0, 0]) - asn(E[0, 1]) + asn(E[1, 0]) + asn(E[1, 1])) / math.pi,
              abs(-asn(E[0, 0]) + asn(E[0, 1]) + asn(E[1, 0]) + asn(E[1, 1])) / math.pi)
    # measured: Hensen et al. 2015
    S_m, dS, pval = 2.42, 0.20, 0.039
    # canary: a classical mixture cannot exceed 2
    rng = np.random.default_rng(SEED + 2); mix = sum(w * det_table(DET[i]) for w, i in zip(rng.dirichlet(np.ones(6)), rng.integers(0, 16, 6)))
    ok = abs(S - 2 * math.sqrt(2)) < 1e-12 and not has and abs(tlm - 1) < 1e-9 and max(chsh_all(mix)) <= 2 + 1e-12 and S_m - 2 > dS
    must(ok, 'WC')
    R['WC'] = dict(claim='Where data decide. The singlet with optimal settings reaches CHSH = 2 sqrt 2 = 2.828; one quantum state '
                         'reproduces all four laws (Tsirelson-Landau-Masanes criterion 1.000, on the boundary), and no classical '
                         'section exists. The loophole-free test of Hensen et al. measured S = 2.42 +- 0.20 in 245 trials and '
                         'rejected local realism at p = 0.039. So the picture of objects carrying pre-existing values for every '
                         'protocol is excluded by data, while a single quantum state survives. This is the one place where the '
                         'gluing reading and the naive object reading make different predictions. Canary: classical mixtures stay '
                         'at or below 2.',
                   status='computed; MEASURED anchor (Hensen et al. 2015)', chsh_singlet=fl(S), classical_section=bool(has),
                   tsirelson_landau_masanes=fl(tlm), hensen=dict(S=S_m, error=dS, p=pval))


def WD():
    base = 137.035999                                       # values below are 1e9 x (alpha^-1 - base)
    data = {'Cs recoil (Parker 2018)': (46.0, 27.0), 'Rb recoil (Morel 2020)': (206.0, 11.0), 'electron g-2 (Fan 2023)': (166.0, 15.0)}
    def glue(d):
        v = np.array([a for a, _ in d.values()]); s = np.array([b for _, b in d.values()]); w = 1 / s ** 2
        m = float(np.sum(w * v) / np.sum(w)); chi2 = float(np.sum(w * (v - m) ** 2)); dof = len(v) - 1
        pair = {f'{k1} vs {k2}': fl(abs(d[k1][0] - d[k2][0]) / math.hypot(d[k1][1], d[k2][1])) for k1, k2 in itertools.combinations(d, 2)}
        return m, chi2, dof, math.sqrt(chi2 / dof), pair
    m, chi2, dof, birge, pair = glue(data)
    rng = np.random.default_rng(SEED + 3)
    fake = {k: (150.0 + rng.normal(0, s), s) for k, (_, s) in data.items()}
    mf, chi2f, _, birgef, _ = glue(fake)
    ok = pair['Cs recoil (Parker 2018) vs Rb recoil (Morel 2020)'] > 5 and birge > 3 and birgef < 2
    must(ok, 'WD')
    R['WD'] = dict(claim='Gluing of numbers in today\'s data. Three protocols that should resolve the same number, the inverse fine-structure '
                         'constant, do not glue: Cs recoil against Rb recoil differs by 5.5 standard deviations, the electron magnetic '
                         'moment sits between them, and the Birge ratio of the set is far above 1. The data-evaluation committee expands '
                         'the uncertainties by a factor 2.5. One World as a gluing statement is therefore falsifiable and is, here, '
                         'falsified in its naive form: at least one protocol model is wrong. Realism reads the same data the same way '
                         '(a systematic error, or new physics in one protocol), so this does not decide between the two readings. '
                         'Canary: a synthetic set drawn from one value glues.',
                   status='computed from MEASURED values (Parker 2018; Morel 2020; Fan 2023; CODATA 2022)',
                   weighted_mean_inverse_alpha=f'{base + m * 1e-9:.12f}', chi2=fl(chi2), dof=dof, birge_ratio=fl(birge),
                   pairwise_sigma=pair, canary_birge=fl(birgef))


if __name__ == '__main__':
    for name, fn in (('WA', WA), ('WB', WB), ('WC', WC), ('WD', WD)):
        try:
            fn()
        except Exception as e:
            must(False, name); R[name] = dict(crash=repr(e))
        print(name, flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(open(os.path.abspath(__file__), 'rb').read()).hexdigest()
    json.dump(out, open(os.path.join(HERE, 'rg_one_world_attack_results.json'), 'w'), indent=1, sort_keys=True)
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
