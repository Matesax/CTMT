# RG – One World Attack: can agreement between experiments demote the atom?

**Verdict: not in general, and the deadlock is a theorem, not a stalemate of opinion. RG has one sharp place where data decide, but that place is already known physics.**

1. **Where protocols glue classically, realism costs nothing.** A classical global section (one joint distribution with every protocol law as a marginal) is an object with pre-existing values. The battery builds that object explicitly from every section it finds, and the object reproduces all four protocol laws (WB). Atomic spacings, masses, charges and counts are commuting, classical quantities. For them, "gluing invariant" and "atom" are two names for one mathematical structure. Agreement between STM, X-ray diffraction and mass spectrometry cannot decide between the names, so it cannot demote the atom.

2. **Where they do not glue classically, data decide, and against the naive ball.** A classical section exists exactly when all CHSH values are at most 2 (Fine; WA, 400/400 random tables). The singlet reaches 2√2 with a single quantum state and has no classical section (WC). The loophole-free test of Hensen et al. measured S = 2.42 ± 0.20 and rejected local realism at p = 0.039. So the picture of a small object carrying pre-existing values for every protocol is excluded by experiment. One World survives on the quantum cone, not on the classical one.

   This is RG's strongest anti-ball statement. It is also exactly the Bell/Kochen–Specker result in the sheaf-theoretic form of Abramsky and Brandenburger (2011), so it is not new. Realism is not refuted either: it retreats to nonlocal or contextual versions (Bohmian mechanics, wavefunction realism), which stay empirically equivalent.

3. **One World as numerical gluing is falsifiable, and today it fails in its naive form (WD).** Three protocols that should give the same inverse fine-structure constant do not agree:

   | Pair | Difference |
   |---|---|
   | Cs recoil vs Rb recoil | 5.5σ |
   | electron g−2 vs Cs recoil | 3.9σ |
   | electron g−2 vs Rb recoil | 2.2σ |

   χ² is 31 for 2 degrees of freedom, a Birge ratio of 3.9. CODATA 2022 expands the uncertainties by a factor of 2.5. This is a genuine holonomy obstruction in real data. But realism reads it the same way (a systematic error, or new physics in one protocol), so it does not discriminate between the two readings.

## Group by group

| Group | Finding |
|---|---|
| WA | Classical section ⇔ all eight CHSH ≤ 2. Linear programming on 400 random no-signalling tables matches the inequality criterion 400/400; 284 tables have a section. Canary: the PR box has CHSH = 4 and no section |
| WB | Every one of the 214 classical sections found is turned into an explicit object model (weights on 16 value assignments). The model reproduces the protocol laws with residual below 10⁻⁹ |
| WC | Singlet: CHSH = 2.8284, Tsirelson–Landau–Masanes value 1.000, no classical section. Hensen et al. 2015: S = 2.42 ± 0.20 over 245 trials, p = 0.039. Canary: classical mixtures stay ≤ 2 |
| WD | α⁻¹ from Cs 137.035999046(27), Rb 137.035999206(11), g−2 137.035999166(15). Weighted mean 137.035999178, χ² = 31.0 for 2 degrees of freedom, Birge ratio 3.94. Canary: a synthetic consistent set has Birge ratio 0.41 |

Battery: `rg_one_world_attack.py`, seed 20261130. Reruns are byte-identical, and all 5 deliberate mutations are caught (crashes would count as defects, not catches).

## What would be novel, and why it is not available

A novelty needs a number on which the gluing reading and the object reading disagree:
- On classical (commuting) data none exists: WB is the theorem.
- On contextual data the disagreement is real, but it is Bell's theorem, which predates RG.

The only remaining route is a predicted failure of gluing that realism does not predict. The α tension is a failure, but nothing in RG says where it sits.

## What can be defended

- **The defensible claim is a typing, not a demotion.** An "atom" is the object whose classical section exists for its commuting protocols (position, mass, charge, count). For its non-commuting protocols (spin, polarization) no section exists, and there the ball picture is excluded by data.
- **The question becomes testable.** RG turns "is the atom a ball?" into "which protocol families admit a classical section?", and that is decided protocol by protocol.
- **It fits current metrology.** Since 2019 the SI fixes h, e, k and N_A exactly and realizes the units through any agreeing protocol. That is the metrology community treating constants as gluing invariants. The SI still counts "elementary entities", so this does not remove the atom.

## Sources

- A. Fine, Hidden variables, joint probability, and the Bell inequalities, Phys. Rev. Lett. 48 (1982) 291.
- S. Abramsky, A. Brandenburger, The sheaf-theoretic structure of non-locality and contextuality, New J. Phys. 13 (2011) 113036.
- B. Hensen et al., Loophole-free Bell inequality violation using electron spins separated by 1.3 kilometres, Nature 526 (2015) 682; arXiv:1508.05949.
- R. H. Parker et al., Science 360 (2018) 191; L. Morel et al., Nature 588 (2020) 61; X. Fan et al., Phys. Rev. Lett. 130 (2023) 071801.
- E. Tiesinga et al., CODATA recommended values 2022, arXiv:2409.03787 (expansion factor 2.5).
- B. van Fraassen, The Scientific Image (1980); I. Hacking, Representing and Intervening (1983); J. Perrin, Les Atomes (1913).
