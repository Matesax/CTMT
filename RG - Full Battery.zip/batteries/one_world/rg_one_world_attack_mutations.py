#!/usr/bin/env python3
"""Mutation suite for rg_one_world_attack.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. Under a minute.

    python3 -I rg_one_world_attack_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('WA', 'the CHSH bound read as 2.2', "crit = max(chsh_all(p)) <= 2 + 1e-9", "crit = max(chsh_all(p)) <= 2.2"),
    ('WB', 'the object model with one assignment dropped', "rec = sum(wi * det_table(d) for wi, d in zip(w, DET))", "rec = sum(wi * det_table(d) for wi, d in zip(w[:-1], DET[:-1]))"),
    ('WC', 'the singlet settings misaligned', "th, ph = (0.0, np.pi / 2), (np.pi / 4, -np.pi / 4)", "th, ph = (0.0, np.pi / 3), (np.pi / 4, -np.pi / 4)"),
    ('WC', 'the measured S misquoted as 2.12', "S_m, dS, pval = 2.42, 0.20, 0.039", "S_m, dS, pval = 2.12, 0.20, 0.039"),
    ('WD', 'the Cs value moved onto Rb', "'Cs recoil (Parker 2018)': (46.0, 27.0)", "'Cs recoil (Parker 2018)': (196.0, 27.0)"),
]


def main():
    base = open(os.path.join(HERE, 'rg_one_world_attack.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_one_world_attack.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_one_world_attack.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_one_world_attack_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
