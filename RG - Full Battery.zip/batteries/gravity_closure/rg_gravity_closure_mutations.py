#!/usr/bin/env python3
"""Mutation suite for rg_gravity_closure.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. Under one minute.

    python3 -I rg_gravity_closure_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('CA', 'a tidal channel with the wrong cross-term factor', "2 * n[0] * n[1], 2 * n[0] * n[2], 2 * n[1] * n[2]]])", "n[0] * n[1], 2 * n[0] * n[2], 2 * n[1] * n[2]]])"),
    ('CA', 'the interior potential of a uniform sphere with the wrong coefficient', "in_pot = sp.Rational(2, 3) * sp.pi", "in_pot = sp.Rational(1, 3) * sp.pi"),
    ('CB', 'the Lanczos tensor without its Riemann-square term', "+ np.einsum('acde,bfgh,cf,dg,eh->ab', Rm, Rm, gi, gi, gi) - 0.25 * g * GB", "- 0.25 * g * GB"),
    ('CC', 'the R^2 tensor with the wrong sign of the derivative terms', "+ 2 * (g * box - cov_hessian(Rs, Gm, X)))", "- 2 * (g * box - cov_hessian(Rs, Gm, X)))"),
    ('CD', 'the Brans-Dicke light-bending parameter inverted', "gamma = (1 + w) / (2 + w)", "gamma = (2 + w) / (1 + w)"),
    ('CE', 'the perihelion advance with 4 pi instead of 6 pi', "per_orbit = 6 * math.pi * GM", "per_orbit = 4 * math.pi * GM"),
    ('CE', 'light deflection with the Newtonian factor 2', "deflection = 4 * GM / (c * c * R_sun)", "deflection = 2 * GM / (c * c * R_sun)"),
]


def main():
    base = open(os.path.join(HERE, 'rg_gravity_closure.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_gravity_closure.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_gravity_closure.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_gravity_closure_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
