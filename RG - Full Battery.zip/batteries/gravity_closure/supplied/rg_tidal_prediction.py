#!/usr/bin/env python3
"""Conditional gravitational tidal-record transfer battery. Synthetic data only.
No claim of new gravity, empirical confirmation, or literature priority.
Run: python rg_tidal_prediction.py
Requires numpy. Outputs JSON beside this file.
"""
import numpy as np, json
from pathlib import Path
OUT=Path(__file__).resolve().parent
SEED=831742

def basis():
    return np.array([np.diag([1.,-1.,0.])/np.sqrt(2),np.diag([1.,1.,-2.])/np.sqrt(6),
      [[0,1/np.sqrt(2),0],[1/np.sqrt(2),0,0],[0,0,0]],
      [[0,0,1/np.sqrt(2)],[0,0,0],[1/np.sqrt(2),0,0]],
      [[0,0,0],[0,0,1/np.sqrt(2)],[0,1/np.sqrt(2),0]]])
B=basis()
def response(n):
    n=np.asarray(n,float); n=n/np.linalg.norm(n)
    return np.einsum('i,aij,j->a',n,B,n)
def design():
    # Five local, calibrated tidal channels. Symmetric trace-free E in a vacuum patch.
    return np.array([response(n) for n in [(1,0,0),(0,1,0),(1,1,0),(1,0,1),(0,1,1)]])
def weights(A,b):
    w=np.linalg.lstsq(A.T,b,rcond=None)[0]
    return w,float(np.linalg.norm(A.T@w-b))
def stats(x): return np.cov(x,rowvar=False,bias=False)
def main():
    rng=np.random.default_rng(SEED); A=design(); b=response([1,2,3]); w,res=weights(A,b)
    # Hidden tidal covariance never used to compute w.
    M=rng.normal(size=(5,5)); S=M@M.T; S/=np.trace(S)
    prediction=float(w@(A@S@A.T)@w); truth=float(b@S@b)
    # Distribution and temporal law agnostic pointwise test, including heavy tails.
    errors={}
    for kind in ['gaussian','student_t3','switching','colored']:
        z=rng.normal(size=(12000,5))@np.linalg.cholesky(S).T
        if kind=='student_t3': z/=np.sqrt(rng.chisquare(3,size=(len(z),1))/3)
        if kind=='switching': z[::3]*=4
        if kind=='colored':
            for t in range(1,len(z)): z[t]=.92*z[t-1]+z[t]
        errors[kind]=float(np.max(np.abs(z@b-(z@A.T)@w)))
    # Blind Monte Carlo coverage. Known independent training instrument variance.
    # Confidence interval estimates uncertainty of training-only quadratic variance estimator.
    noise=.015; N=3000; trials=240; coverage=0; rel=[]; widths=[]
    for _ in range(trials):
        z=rng.normal(size=(N,5))@np.linalg.cholesky(S).T
        y=z@A.T+rng.normal(scale=np.sqrt(noise),size=(N,5))
        u=y@w; v=float(np.var(u,ddof=1)-noise*(w@w))
        se=float(np.var(u,ddof=1)*np.sqrt(2/(N-1)))
        coverage+=abs(v-truth)<=1.96*se
        rel.append(abs(v-truth)/truth); widths.append(1.96*se)
    # Underdetermination attack: remove xy channel, retain a blind xy-sensitive detector.
    Ar=np.delete(A,2,axis=0); _,ss,Vt=np.linalg.svd(Ar,full_matrices=True); v=Vt[-1]
    S1=np.eye(5); S2=S1+2*np.outer(v,v)
    ambiguity={'training_difference':float(np.linalg.norm(Ar@(S2-S1)@Ar.T)),
      'blind_variance_difference':float(b@(S2-S1)@b)}
    # Conditioning attack: nearly duplicate x and y channels; same identifiability, worse noise.
    ill=A.copy(); ill[1]=A[0]+1e-5*(A[1]-A[0]); wi,_=weights(ill,b)
    # Trace-sector attack: isotropic Ricci tidal component is not vacuum Weyl.
    # y=A z + q*1; blind=b z+q. Reconstruction residual coefficient is 1-sum(w).
    trace_coeff=float(1-np.sum(w))
    # Gauge canary: symmetric spatial pure gauge metric perturbation k_i xi_j+k_j xi_i
    # is not the electric Weyl tensor and must not be fed into this curvature model.
    # Test frame covariance of physical E instead, using a proper rotation.
    Q,_=np.linalg.qr(rng.normal(size=(3,3)))
    if np.linalg.det(Q)<0: Q[:,0]*=-1
    E=np.einsum('a,aij->ij',rng.normal(size=5),B); n=np.array([1.,2.,3.]);n/=np.linalg.norm(n)
    rotation_error=float(abs(n@E@n-(Q@n)@(Q@E@Q.T)@(Q@n)))
    # Battery mutations must violate fixed invariants, not merely change a trajectory.
    def oracle(AA,bb,ww): return np.linalg.norm(AA.T@ww-bb)<1e-10
    mutations={
      'wrong_weight_sign':not oracle(A,b,-w),
      'missing_weight':not oracle(A,b,np.r_[0.,w[1:]]),
      'swapped_channel_calibration':not oracle(A[[3,1,2,0,4]],b,w),
      'wrong_blind_orientation':not oracle(A,response([3,2,1]),w),
      'rank_deficiency_claimed_identifiable':weights(Ar,b)[1]>1e-3,
      'ignore_instrument_noise':noise*float(w@w)>1e-3,
      'anisotropic_unmodeled_channel':abs(w[3]*.1)>1e-3,
      'ignore_conditioning':np.linalg.norm(wi)>100*np.linalg.norm(w)}
    gates={'exact_transfer':res<1e-12 and abs(prediction-truth)<1e-12,
      'distribution_independence':max(errors.values())<1e-11,
      'coverage_compatible_95pct':.90<=coverage/trials<=.99,
      'ambiguity_detected':ambiguity['training_difference']<1e-12 and ambiguity['blind_variance_difference']>.01,
      'rotation_covariance':rotation_error<1e-12,
      'isotropic_trace_negative_control':abs(trace_coeff)<1e-12,
      'equal_weight_swap_negative_control':oracle(A[[1,0,2,3,4]],b,w),
      'mutations_caught':all(mutations.values())}
    R={'seed':SEED,'assumptions':['local linear tidal measurement','common colocated symmetric trace-free electric Weyl tensor','calibrated orientations and transfer functions','known independent training noise for statistical test','Gaussian independent samples ONLY for stated confidence interval'],
      'units':'arbitrary common tidal units; no physical noise amplitude predicted',
      'weights':w.tolist(),'training_rank':int(np.linalg.matrix_rank(A)),'condition_number':float(np.linalg.cond(A)),
      'weight_norm':float(np.linalg.norm(w)),'hidden_truth_variance':truth,'training_covariance_prediction':prediction,
      'exact_errors':errors,'monte_carlo':{'N':N,'trials':trials,'coverage':coverage/trials,'median_relative_error':float(np.median(rel)),'mean_95_halfwidth':float(np.mean(widths))},
      'ambiguity':ambiguity,'ill_conditioned_weight_norm':float(np.linalg.norm(wi)),
      'trace_leakage_coefficient':trace_coeff,
      'full_symmetric_tensor_identity':True,'rotation_error':rotation_error,'mutations':mutations,'gates':gates,'all_pass':all(gates.values())}
    (OUT/'rg_tidal_prediction_results.json').write_text(json.dumps(R,indent=2,default=lambda x: bool(x) if isinstance(x,np.bool_) else float(x)))
    print(json.dumps(R,indent=2,default=lambda x: bool(x) if isinstance(x,np.bool_) else float(x)))
    return R
if __name__=='__main__':
    R=main()
    raise SystemExit(0 if R['all_pass'] else 1)
