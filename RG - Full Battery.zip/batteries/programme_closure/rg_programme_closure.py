#!/usr/bin/env python3
"""Resolution Geometry - programme closure: the two gates where known physics stops, decided on RG's rules.

  PA the scale cocycle (H-int). A unit defined by counting events is a measure: the ratio of counted units along any
     chain of overlapping cells telescopes, so its holonomy around every loop is exactly 1, with Poisson noise included.
     A transported standard with a Weyl one-form A has holonomy exp(oint A) = exp(integral dA) != 1 (canary). Weyl's
     second-clock effect therefore cannot live in a counted unit; it can only appear as a disagreement between two
     protocols (transported clocks against event counts), which is a gluing test, not a hypothesis
  PB realization as gluing (H-top and the converse of realization). Order-only protocols on a finite record set:
     Myrheim-Meyer dimension (ordering fraction), midpoint dimension (interval halving), chain dimension (slope of log
     chain against log size), and a frame test (the spread of chain/size^(1/d) must shrink with size, as for Poisson
     discreteness). Sprinkled 2, 3, 4 dimensional intervals glue. Canaries: Kleitman-Rothschild three-layer orders
     (the typical large order) have bounded chains and an infinite chain dimension; a regular grid order glues on
     dimension but its spread does not shrink (chains depend on interval shape)
  PD the frame test: the spread of chain/sqrt(size) follows the n^(-1/3) law for Poisson records (one law per size); the
     number of future links grows like log N for Poisson records and is exactly 2 for a grid (bounded valence = a frame)
  PC scale stability. In a sprinkled interval the protocols glue at every scale tested (sub-intervals of decreasing
     size), within counting noise

Deterministic. Seed 20261207. Writes rg_programme_closure_results.json.
Run:  python3 -I rg_programme_closure.py      (numpy, scipy)
"""
import hashlib, json, math, sys
from pathlib import Path
import numpy as np
from scipy.special import gamma
from scipy.optimize import brentq

HERE = Path(__file__).resolve().parent
SEED = 20261207
R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.8g}')


def below(v, b):
    return f'< {b:g}' if abs(v) < b else fl(v)


# ============================================================================================ PA
def PA():
    rng = np.random.default_rng(SEED); k = 12; rho = 400000.0
    xs = (np.arange(k) + 0.5) / k; X, Y = np.meshgrid(xs, xs, indexing='ij')
    omega2 = 1 + 0.6 * np.sin(2 * math.pi * X) * np.cos(math.pi * Y) + 0.3 * X          # a smooth scale field
    counts = rng.poisson(rho * omega2 / k ** 2)                                              # counted events per cell
    unit = counts.astype(float) ** -0.5                                                     # counted unit (2D: length ~ count^-1/2)
    # holonomy of the counted unit around every elementary loop and around large loops: product of neighbour ratios
    def loop_hol(path):
        h = 1.0
        for (i, j), (a, b) in zip(path, path[1:] + path[:1]):
            h *= unit[a, b] / unit[i, j]
        return h
    loops = []
    for i in range(k - 1):
        for j in range(k - 1):
            loops.append([(i, j), (i + 1, j), (i + 1, j + 1), (i, j + 1)])
    big = [(i, 0) for i in range(k)] + [(k - 1, j) for j in range(1, k)] + [(i, k - 1) for i in range(k - 2, -1, -1)] + [(0, j) for j in range(k - 2, 0, -1)]
    count_hol = max(abs(loop_hol(L) - 1) for L in loops + [big])
    # canary: Weyl transport with A = a (x dy - y dx)/2, dA = a dx dy: holonomy exp(a * area) around the unit square
    a = 0.8; t = np.linspace(0, 1, 4001)
    def weyl_line(p0, p1):
        x = p0[0] + (p1[0] - p0[0]) * t; y = p0[1] + (p1[1] - p0[1]) * t
        integrand = 0.5 * a * (x * (p1[1] - p0[1]) - y * (p1[0] - p0[0])); return np.trapezoid(integrand, t)
    sq = [(0, 0), (1, 0), (1, 1), (0, 1)]; weyl = math.exp(sum(weyl_line(sq[i], sq[(i + 1) % 4]) for i in range(4)))
    # two paths between the same cells: counted units agree exactly; Weyl-transported ones differ
    pathA = [(0, 0)] + [(i, 0) for i in range(1, k)] + [(k - 1, j) for j in range(1, k)]
    pathB = [(0, 0)] + [(0, j) for j in range(1, k)] + [(i, k - 1) for i in range(1, k)]
    ratio = lambda P: np.prod([unit[b] / unit[a_] for a_, b in zip(P, P[1:])])
    path_dep = abs(ratio(pathA) - ratio(pathB)) / ratio(pathA)
    # the scale field itself is recovered from counts (Poisson accuracy)
    rec = np.abs(counts / (rho / k ** 2) - omega2) / omega2
    ok = count_hol < 1e-12 and path_dep < 1e-12 and abs(weyl - math.exp(a)) < 1e-6 and weyl > 1.5 and float(np.median(rec)) < 0.03
    must(ok, 'PA')
    R['PA'] = dict(claim='The scale cocycle is exact for counted units. Events are counted in 144 cells over a smooth scale field (Poisson '
                         'noise included) and the unit in each cell is count^(-1/2). Around all 121 elementary loops and the boundary '
                         'loop, the product of unit ratios is 1 to rounding, and two different paths between the same cells give the '
                         'same ratio: counted ratios telescope, so H-int holds identically for any unit defined by counting events. '
                         'Canary: a transported standard with Weyl one-form A, dA = 0.8 dx dy, returns around the unit square scaled by '
                         'exp(0.8). Weyl\'s second-clock effect cannot be a property of a counted unit; it can only appear as a '
                         'disagreement between transported clocks and event counts, which is a gluing test between two protocols.',
                   status='PROVED (telescoping) + computed', counted_holonomy_deviation=below(count_hol, 1e-12), two_path_difference=below(path_dep, 1e-12),
                   weyl_holonomy=fl(weyl), expected=fl(math.exp(a)), scale_recovery_median_rel_error=fl(np.median(rec)))


# ============================================================================================ order-only protocols
def mm_fraction(d):
    return gamma(d + 1) * gamma(d / 2) / (2 * gamma(3 * d / 2))


def mm_dim(f):
    lo, hi = 1.01, 12.0
    if f >= mm_fraction(lo):
        return lo
    if f <= mm_fraction(hi):
        return hi
    return brentq(lambda s: mm_fraction(s) - f, lo, hi)


def closure(Rm):
    """Transitive closure of a strict order given as a boolean matrix (Warshall by repeated squaring on floats)."""
    M = Rm.astype(np.float32)
    while True:
        M2 = ((M + (M @ M)) > 0).astype(np.float32)
        if np.array_equal(M2, M):
            return M2 > 0
        M = M2


def longest_chain(Rm, idx):
    """Length (number of elements) of the longest chain among the elements idx, by dynamic programming in a linear extension."""
    sub = Rm[np.ix_(idx, idx)]; order = np.argsort(sub.sum(0)); best = np.ones(len(idx), int)
    for a in order:
        preds = np.where(sub[:, a])[0]
        if len(preds):
            best[a] = 1 + best[preds].max()
    return int(best.max()) if len(idx) else 0


def interval(Rm, a, b):
    return np.where(Rm[a] & Rm[:, b])[0]


def sample_intervals(Rm, I, rng, n_pairs=6000):
    """Random comparable pairs inside I; returns (size, longest chain) for each interval."""
    pairs = np.argwhere(Rm[np.ix_(I, I)]); out = []
    for k_ in rng.choice(len(pairs), size=min(n_pairs, len(pairs)), replace=False):
        a_, b_ = I[pairs[k_]]; J = interval(Rm, a_, b_)
        if len(J) >= 8:
            out.append((len(J), longest_chain(Rm, J)))
    return np.array(out, float)


def protocols(Rm, bottom, top, rng):
    I = interval(Rm, bottom, top); n = len(I)
    sub = Rm[np.ix_(I, I)]; f = sub[np.triu_indices(n, 1)].mean() + sub.T[np.triu_indices(n, 1)].mean()
    d_mm = mm_dim(f)
    past = sub.sum(0); fut = sub.sum(1); m = I[int(np.argmax(np.minimum(past, fut)))]
    nh = len(interval(Rm, bottom, m)); d_mid = math.log2(n / nh) if nh > 0 else float('inf')
    S = sample_intervals(Rm, I, rng)
    # chain dimension: slope of log(chain) against log(size) over sampled intervals
    slope = np.polyfit(np.log(S[:, 0]), np.log(S[:, 1]), 1)[0] if len(S) > 20 else 0.0
    d_chain = 1 / slope if slope > 0.05 else float('inf')
    # frame test: relative spread of chain / size^(1/d_chain) in a small and a large size band
    def spread(lo, hi):
        sel = (S[:, 0] >= lo) & (S[:, 0] < hi)
        if sel.sum() < 15 or not math.isfinite(d_chain):
            return float('nan')
        r = S[sel, 1] / S[sel, 0] ** (1 / d_chain); return float(np.std(r) / np.mean(r))
    s_small, s_large = spread(10, 30), spread(n / 8, n / 2)
    return dict(N=n, d_mm=d_mm, d_mid=d_mid, d_chain=d_chain, spread_small=s_small, spread_large=s_large,
                spread_ratio=s_large / s_small if s_small == s_small and s_large == s_large and s_small > 0 else float('nan'), max_chain=int(S[:, 1].max()) if len(S) else 0)


def sprinkle_order(rng, d, n):
    pts = []
    while len(pts) < n:
        t = rng.uniform(0, 1, 4 * n); x = rng.uniform(-0.5, 0.5, size=(4 * n, d - 1)); r = np.linalg.norm(x, axis=1)
        ok = (r < t) & (r < 1 - t); pts.extend(np.column_stack([t[ok], x[ok]]).tolist())
    P = np.array([[0.0] * d] + pts[:n] + [[1.0] + [0.0] * (d - 1)])               # explicit bottom and top
    dt = P[None, :, 0] - P[:, None, 0]; dx = np.linalg.norm(P[None, :, 1:] - P[:, None, 1:], axis=2)
    return (dt > dx), 0, len(P) - 1


def kr_order(rng, n):
    a = n // 4; b = n // 2; c = n - a - b; N = n + 2; Rm = np.zeros((N, N), bool)
    L1 = np.arange(1, 1 + a); L2 = np.arange(1 + a, 1 + a + b); L3 = np.arange(1 + a + b, 1 + n)
    Rm[np.ix_(L1, L2)] = rng.uniform(size=(a, b)) < 0.5; Rm[np.ix_(L2, L3)] = rng.uniform(size=(b, c)) < 0.5
    Rm[0, 1:] = True; Rm[1:N - 1, N - 1] = True; Rm[0, N - 1] = True
    return closure(Rm), 0, N - 1


def grid_order(m):
    i, j = np.meshgrid(np.arange(m), np.arange(m), indexing='ij'); i, j = i.ravel(), j.ravel()
    Rm = (i[:, None] <= i[None, :]) & (j[:, None] <= j[None, :]); np.fill_diagonal(Rm, False)
    return Rm, 0, m * m - 1


def PB():
    rng = np.random.default_rng(SEED + 1); rows = {}; keys = ('N', 'd_mm', 'd_mid', 'd_chain', 'max_chain')
    def summary(vals):
        out = {}
        for k in keys:
            xs = [v[k] for v in vals]; out[k] = fl(np.mean(xs)) if all(math.isfinite(x) for x in xs) else 'inf'
        return out
    for d, n in ((2, 3000), (3, 3000), (4, 3000)):
        rows[f'sprinkle_{d}D'] = summary([protocols(*sprinkle_order(rng, d, n), rng) for _ in range(2)])
    rows['kleitman_rothschild'] = summary([protocols(*kr_order(rng, 3000), rng)])
    rows['grid'] = summary([protocols(*grid_order(56), rng)])
    for r in rows.values():
        r['dimension_disagreement'] = fl(abs(r['d_mm'] - r['d_mid']))
        r['time_grows'] = r['d_chain'] != 'inf'
    tol = 0.3
    spr_ok = all(rows[f'sprinkle_{d}D']['dimension_disagreement'] < tol and abs(rows[f'sprinkle_{d}D']['d_mm'] - d) < 0.3 and rows[f'sprinkle_{d}D']['time_grows'] for d in (2, 3, 4))
    kr = rows['kleitman_rothschild']; kr_fail = kr['dimension_disagreement'] > tol or not kr['time_grows']
    gr = rows['grid']; grid_glue = gr['dimension_disagreement'] < tol and gr['time_grows']
    chain_bias = [rows[f'sprinkle_{d}D']['d_chain'] for d in (2, 3, 4)]
    ok = spr_ok and kr_fail and not kr['time_grows'] and kr['dimension_disagreement'] > tol and grid_glue and chain_bias[2] < 3.5
    must(ok, 'PB')
    R['PB'] = dict(claim='Realization as gluing, dimension and time. Order-only protocols on finite record sets: Myrheim-Meyer dimension '
                         '(ordering fraction) and midpoint dimension (interval halving) must agree, and the longest chain must grow '
                         'with interval size (time exists). Sprinkled intervals of 3000 events in 2, 3 and 4 dimensions glue: the two '
                         'dimensions agree within 0.3 and chains grow. Canary: a Kleitman-Rothschild order, the typical large order, '
                         'fails twice: its two dimensions disagree, and its chains do not grow with interval size. A regular grid '
                         'glues here; it is separated by the valence test (PD). Found by the battery: the chain-based dimension '
                         '(slope of log chain against log size) is biased low at this size (2D 1.78, 3D 2.35, 4D 2.69) because chains '
                         'are short; it is reported, not used for gluing. Each protocol has its own resolution, and gluing is '
                         'declared at the resolution of the coarsest.',
                   status='computed; estimators from Myrheim 1978, Meyer 1988, Brightwell-Gregory 1991', tolerance=tol, by_order=rows)


def PC():
    rng = np.random.default_rng(SEED + 2); Rm, b, t = sprinkle_order(rng, 2, 4000); I = interval(Rm, b, t)
    past = Rm[np.ix_(I, I)].sum(0); out = {}
    for frac in (1.0, 0.5, 0.25, 0.125):
        if frac == 1.0:
            tp = t
        else:
            cand = I[np.argsort(np.abs(past - frac * len(I)))[:30]]; cf = Rm[np.ix_(cand, I)].sum(1); tp = int(cand[np.argmin(np.abs(cf - np.median(cf)))])
        r = protocols(Rm, b, tp, rng); out[str(frac)] = {k: fl(r[k]) for k in ('N', 'd_mm', 'd_mid')}
    dis = [abs(v['d_mm'] - v['d_mid']) for v in out.values()]
    ok = max(dis) < 0.3 and all(abs(v['d_mm'] - 2) < 0.3 for v in out.values())
    must(ok, 'PC')
    R['PC'] = dict(claim='Scale stability. In one sprinkled 2D interval of 4000 events the two dimension protocols glue on nested '
                         'sub-intervals holding the whole, about a half, a quarter and an eighth of it (largest disagreement below). '
                         'The scale at which protocols glue is itself a record, the declared resolution.',
                   status='computed', nested=out, max_disagreement=fl(max(dis)))


def lis_len(seq):
    import bisect
    tails = []
    for x in seq:
        k = bisect.bisect_left(tails, x)
        if k == len(tails):
            tails.append(x)
        else:
            tails[k] = x
    return len(tails)


def future_links(u, v, idx_sample):
    """Number of links (relations with nothing between) from each sampled element to its future: the minimal elements of
    its future quadrant, found by a scan in u keeping the running minimum of v. Order-only: uses comparisons alone."""
    out = []
    for a in idx_sample:
        m = (u > u[a]) & (v > v[a]); fu, fv = u[m], v[m]; o = np.argsort(fu); run = np.inf; c = 0
        for y in fv[o]:
            if y < run:
                c += 1; run = y
        out.append(c)
    return np.array(out, float)


def PD():
    """Frame test, 1+1 dimensions. (i) Every interval of a Poisson sprinkle is a boosted copy of one diamond: at fixed size the
    relative spread of chain/sqrt(size) follows one law, shrinking like n^(-1/3). (ii) Valence: Lorentz-invariant discreteness has
    unbounded valence (links to the future grow like log N); a grid has exactly two."""
    rng = np.random.default_rng(SEED + 3)
    def stats(u, v, band, k=250):
        o = np.argsort(u); u, v = u[o], v[o]; res = []; n = len(u); tries = 0
        while len(res) < k and tries < 400 * k:
            tries += 1; i, j = sorted(rng.integers(0, n, 2))
            if not (u[i] < u[j] and v[i] < v[j]):
                continue
            sel = slice(i + 1, j); m = (v[sel] > v[i]) & (v[sel] < v[j]) & (u[sel] > u[i]); cnt = int(m.sum())
            if band[0] <= cnt < band[1]:
                res.append((cnt, lis_len(v[sel][m])))
        r = np.array(res, float); x = r[:, 1] / np.sqrt(r[:, 0]); return float(np.std(x) / np.mean(x))
    n = 200000; u = rng.uniform(0, 1, n); v = rng.uniform(0, 1, n)
    m = 448; gi, gj = np.meshgrid(np.arange(m), np.arange(m), indexing='ij')
    gu = gi.ravel() / m + 1e-9 * gj.ravel() + rng.uniform(0, 1e-12, m * m); gv = gj.ravel() / m + 1e-9 * gi.ravel() + rng.uniform(0, 1e-12, m * m)
    spread = {}
    for name, (uu, vv) in (('poisson', (u, v)), ('grid', (gu, gv))):
        s1, s2 = stats(uu, vv, (1500, 3000)), stats(uu, vv, (12000, 24000)); spread[name] = dict(small=fl(s1), large=fl(s2), ratio=fl(s2 / s1))
    predicted = (18000 / 2250) ** (-1 / 3)
    # valence against size: sampled elements near the bottom corner (large future)
    val = {}
    for N in (2000, 20000, 200000):
        uu, vv = u[:N], v[:N]; cand = np.where((uu < 0.1) & (vv < 0.1))[0][:200]; val[str(N)] = fl(future_links(uu, vv, cand).mean())
        mm = int(round(math.sqrt(N))); gi2, gj2 = np.meshgrid(np.arange(mm), np.arange(mm), indexing='ij')
        g_u = gi2.ravel() / mm + 1e-9 * gj2.ravel(); g_v = gj2.ravel() / mm + 1e-9 * gi2.ravel(); gc = np.where((g_u < 0.1) & (g_v < 0.1))[0][:200]
        val['grid_' + str(N)] = fl(future_links(g_u, g_v, gc).mean())
    pv = [val[k] for k in ('2000', '20000', '200000')]; gv_ = [val['grid_' + k] for k in ('2000', '20000', '200000')]
    slope = np.polyfit(np.log([2000, 20000, 200000]), pv, 1)[0]
    ok = abs(spread['poisson']['ratio'] - predicted) < 0.15 and pv[0] < pv[1] < pv[2] and slope > 0.5 and max(gv_) == min(gv_) == 2.0
    must(ok, 'PD')
    R['PD'] = dict(claim='The frame test. (i) Universality: for random comparable pairs whose intervals hold 1500-3000 and 12000-24000 '
                         'events of a Poisson sprinkle (2e5 events), the relative spread of chain/sqrt(size) shrinks with ratio 0.51 '
                         'against 0.50 predicted by the n^(-1/3) law: every interval of a given size has one law, as boost invariance '
                         'requires. (ii) Valence: the mean number of future links of an element grows with the number of events '
                         '(about log N; slope below) for Poisson records, and is exactly 2 for a grid at every size. A record set that '
                         'singles out a frame is detected from its order alone, by bounded valence. Refuted on the way, kept as a '
                         'finding: the shape spread of chains does not separate a grid from a sprinkle (the grid ratio also shrinks, '
                         'value below), because chain/sqrt(size) = (1 + r)/sqrt(r) is flat near aspect r = 1.',
                   status='computed; Bombelli-Henson-Sorkin 2009, Baik-Deift-Johansson 1999', spread=spread, bdj_predicted_ratio=fl(predicted),
                   mean_future_links=val, poisson_log_slope=fl(slope))


if __name__ == '__main__':
    for name, fn in (('PA', PA), ('PB', PB), ('PC', PC), ('PD', PD)):
        try:
            fn()
        except Exception as e:
            must(False, name); R[name] = dict(crash=repr(e))
        print(name, flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (HERE / 'rg_programme_closure_results.json').write_text(json.dumps(out, indent=1, sort_keys=True))
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
