#!/usr/bin/env python3
"""Mutation suite for rg_programme_closure.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. A few minutes.

    python3 -I rg_programme_closure_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('PA', 'unit ratio carried by a curled edge factor', "            h *= unit[a, b] / unit[i, j]", "            h *= unit[a, b] / unit[i, j] * math.exp(0.01 * (a - i) * b)"),
    ('PA', 'Weyl canary switched off', "a = 0.8; t = np.linspace(0, 1, 4001)", "a = 0.0; t = np.linspace(0, 1, 4001)"),
    ('PB', 'Myrheim-Meyer fraction misnormalised', "return gamma(d + 1) * gamma(d / 2) / (2 * gamma(3 * d / 2))", "return gamma(d + 1) * gamma(d / 2) / (4 * gamma(3 * d / 2))"),
    ('PB', 'sprinkle relation with a widened light cone', "    return (dt > dx), 0, len(P) - 1", "    return (dt > dx / 2), 0, len(P) - 1"),
    ('PB', 'Kleitman-Rothschild layers made into a chain', "Rm[np.ix_(L1, L2)] = rng.uniform(size=(a, b)) < 0.5;", "Rm[np.ix_(L1, L2)] = np.triu(np.ones((a, b), bool));"),
    ('PD', 'links counted as all future elements', "            if y < run:\n                c += 1; run = y", "            if True:\n                c += 1; run = y"),
    ('PD', 'spread normalised by size instead of sqrt(size)', "r = np.array(res, float); x = r[:, 1] / np.sqrt(r[:, 0]);", "r = np.array(res, float); x = r[:, 1] / r[:, 0];"),
]


def main():
    base = open(os.path.join(HERE, 'rg_programme_closure.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_programme_closure.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_programme_closure.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_programme_closure_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
