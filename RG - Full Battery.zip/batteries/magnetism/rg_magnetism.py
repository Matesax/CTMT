#!/usr/bin/env python3
"""RG - Magnetism: hostile battery.

Groups (every group carries a canary, i.e. a false variant that must fail):
  MA conserved count => excitation (discrete Poincare lemma on a 4-D cell complex); torus canary; flat holonomy
  MB constitutive law: maps on 2-forms invariant under the Lorentz group (dimension 2), under rotations only (4);
     epsilon mu K^2 = 1; two polarizations at one speed; axion term invisible; medium canary
  MC gauge quotient: one null direction, D-1 positive; uniqueness a + b = 0, m = 0; conserved source = existence;
     Gauss flux independent of radius iff massless
  MD lattice Biot-Savart: pseudo-inverse on the quotient; Ampere, Coulomb gauge, energy; refinement to the continuum
  ME continuum Biot-Savart: loop on and off axis, dipole limit, linking number, parallel wires, exponent canary
  MF Biot-Savart as representer: inductance Gram matrix, reciprocity, least energy, divergent self-inductance
  MG magnetism from the frontier: boosted line charge, Heaviside field, force ratio beta^2, K -> infinity
  MH waves: two polarizations at the cone speed, exact front; Proca canary
  MI data: static determination of the frontier; pure numbers K and alpha; photon mass; vacuum nonlinearity

Deterministic. Seed 20261115. Writes rg_magnetism_results.json. Run:  python3 -I rg_magnetism.py
"""
import hashlib, itertools, json, math, os, sys
import numpy as np
from scipy.integrate import quad
from scipy.linalg import expm, null_space
from scipy.special import ellipe, ellipk

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 20261115
R, FAILS = {}, []
MU0 = 4e-7 * math.pi                                             # conventional value for the continuum checks


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.12g}')


# ============================================================================================ MA: count => excitation
def _complex4(n, periodic):
    """Cubical cochain complex on an n^4 grid of vertices. Returns coboundary matrices d0..d3."""
    cells = []
    for k in range(5):
        idx = {}
        for S in itertools.combinations(range(4), k):
            for x in itertools.product(range(n), repeat=4):
                if periodic or all(x[i] <= n - 2 for i in S):
                    idx[(S, x)] = len(idx)
        cells.append(idx)
    ds = []
    for k in range(4):
        D = np.zeros((len(cells[k + 1]), len(cells[k])))
        for (S, x), row in cells[k + 1].items():
            for pos, j in enumerate(S):
                T = tuple(s for s in S if s != j); xp = list(x); xp[j] = (xp[j] + 1) % n if periodic else xp[j] + 1
                sg = (-1) ** pos
                D[row, cells[k][(T, tuple(xp))]] += sg; D[row, cells[k][(T, x)]] -= sg
        ds.append(D)
    return cells, ds


def MA():
    rng = np.random.default_rng(SEED + 1)
    out = {}
    for name, per in (('box', False), ('torus', True)):
        cells, ds = _complex4(3, per)
        dd = max(float(np.max(np.abs(ds[k + 1] @ ds[k]))) for k in range(3))
        rk = [int(np.linalg.matrix_rank(D)) for D in ds]; dims = [len(c) for c in cells]
        betti = [dims[0] - rk[0]] + [dims[k] - rk[k] - rk[k - 1] for k in range(1, 4)] + [dims[4] - rk[3]]
        out[name] = dict(cells=cells, ds=ds, dd=dd, rank=rk, dims=dims, betti=betti)
    b, t = out['box'], out['torus']
    # box: every closed 3-cochain (conserved count) is d of a 2-cochain; solutions differ by d of a 1-cochain
    Z3 = null_space(b['ds'][3]); J = Z3 @ rng.normal(size=Z3.shape[1])
    G, *_ = np.linalg.lstsq(b['ds'][2], J, rcond=None); res_box = float(np.linalg.norm(b['ds'][2] @ G - J) / np.linalg.norm(J))
    freedom = b['dims'][2] - b['rank'][2]                          # dimension of the solutions of dG = J
    # homogeneous pair: F = dA is closed; every closed 2-cochain on the box is exact
    A = rng.normal(size=b['dims'][1]); closed = float(np.max(np.abs(b['ds'][2] @ (b['ds'][1] @ A))))
    Z2 = null_space(b['ds'][2]); Fc = Z2 @ rng.normal(size=Z2.shape[1])
    Ap, *_ = np.linalg.lstsq(b['ds'][1], Fc, rcond=None); res_F = float(np.linalg.norm(b['ds'][1] @ Ap - Fc) / np.linalg.norm(Fc))
    # torus canary: a uniform static charge (one unit on every spatial cube) is conserved but has no excitation
    Jt = np.zeros(t['dims'][3])
    for (S, x), i in t['cells'][3].items():
        if S == (1, 2, 3):
            Jt[i] = 1.0
    cons = float(np.max(np.abs(t['ds'][3] @ Jt))); Gt, *_ = np.linalg.lstsq(t['ds'][2], Jt, rcond=None)
    res_torus = float(np.linalg.norm(t['ds'][2] @ Gt - Jt) / np.linalg.norm(Jt))
    # flat connection with holonomy: A = const on the edges of direction 1; F = 0, loop reading = 3 * const, not a gradient
    Af = np.zeros(t['dims'][1])
    for (S, x), i in t['cells'][1].items():
        if S == (1,):
            Af[i] = 0.2
    flat = float(np.max(np.abs(t['ds'][1] @ Af))); hol = 3 * 0.2
    chi, *_ = np.linalg.lstsq(t['ds'][0], Af, rcond=None); not_exact = float(np.linalg.norm(t['ds'][0] @ chi - Af) / np.linalg.norm(Af))
    ok = b['dd'] == 0 and t['dd'] == 0 and b['betti'] == [1, 0, 0, 0, 0] and t['betti'] == [1, 4, 6, 4, 1] and res_box < 1e-10 \
        and freedom == b['rank'][1] and closed < 1e-12 and res_F < 1e-10 and cons == 0 and res_torus > 0.5 and flat == 0 and not_exact > 0.5
    must(ok, 'MA')
    R['MA'] = dict(claim='From a conserved count to the excitation. On a contractible 4-D cell complex every conserved count '
                         '(closed 3-cochain J) is the coboundary of a 2-cochain G: dG = J, the inhomogeneous pair, with G fixed '
                         'up to d of a 1-cochain. Every F = dA is closed, and every closed 2-cochain is exact: the homogeneous '
                         'pair. Betti numbers (1,0,0,0,0) for the box. Canary: on the 4-torus (1,4,6,4,1) a uniform static '
                         'charge is conserved and has no excitation, and a flat connection carries a loop reading 0.6 with '
                         'F = 0 that is not a gradient.',
                   status='PROVED (Poincare lemma) + exact computation', dims_box=b['dims'], ranks_box=b['rank'], betti_box=b['betti'],
                   betti_torus=t['betti'], excitation_residual=fl(res_box), excitation_freedom=int(freedom), closed_defect=fl(closed),
                   potential_residual=fl(res_F), torus_conservation_defect=fl(cons), torus_excitation_residual=fl(res_torus),
                   flat_curvature=fl(flat), flat_holonomy=fl(hol), flat_not_exact_residual=fl(not_exact))


# ============================================================================================ MB: constitutive law
PAIRS = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]


def _rep2(M):
    """Action F -> M F + F M^T on antisymmetric 4x4 matrices, as a 6x6 matrix in the basis PAIRS."""
    out = np.zeros((6, 6))
    for c, (a, b) in enumerate(PAIRS):
        F = np.zeros((4, 4)); F[a, b], F[b, a] = 1.0, -1.0; dF = M @ F + F @ M.T
        for r_, (p, q) in enumerate(PAIRS):
            out[r_, c] = dF[p, q]
    return out


def _commutant(gens):
    rows = []
    for g in gens:
        rows.append(np.kron(np.eye(6), g) - np.kron(g.T, np.eye(6)))
    return null_space(np.vstack(rows), rcond=1e-10)


def _maxwell_speeds(eps, mu, alpha=0.0, beta=0.0, k=(0.3, -0.4, 1.2)):
    """Plane waves of  d_t D = curl H, d_t B = -curl E  with D = eps E + (alpha + beta) B, H = B/mu - (alpha - beta) E."""
    k = np.array(k); C = np.array([[0, -k[2], k[1]], [k[2], 0, -k[0]], [-k[1], k[0], 0]])       # (curl V) = i C V
    Mc = np.block([[eps * np.eye(3), (alpha + beta) * np.eye(3)], [np.zeros((3, 3)), np.eye(3)]])
    Rc = np.block([[-(alpha - beta) * C, C / mu], [-C, np.zeros((3, 3))]])
    w = np.linalg.eigvals(np.linalg.solve(Mc, -Rc)); return np.sort_complex(w) / np.linalg.norm(k)


def MB():
    rng = np.random.default_rng(SEED + 2)
    eta = np.diag([-1.0, 1, 1, 1]); gens_l, gens_r, gens_e = [], [], []
    for a, b in PAIRS:
        K_ = np.zeros((4, 4)); K_[a, b], K_[b, a] = 1.0, -1.0
        gens_l.append(_rep2(np.linalg.solve(eta, K_))); gens_e.append(_rep2(K_))
        if a > 0:
            gens_r.append(_rep2(K_))
    dim_l, dim_r, dim_e = _commutant(gens_l).shape[1], _commutant(gens_r).shape[1], _commutant(gens_e).shape[1]
    # the Hodge star commutes with the Lorentz action and squares to -1
    eps4 = np.zeros((4, 4, 4, 4))
    for p in itertools.permutations(range(4)):
        eps4[p] = np.linalg.det(np.eye(4)[list(p)])
    star = np.zeros((6, 6))
    for c, (a, b) in enumerate(PAIRS):                               # (*F)^{mu nu} = 1/2 eps^{mu nu}_{rho sigma} F^{rho sigma}
        for r_, (p, q) in enumerate(PAIRS):
            star[r_, c] = eps4[p, q, a, b] * eta[a, a] * eta[b, b]
    comm = max(float(np.max(np.abs(star @ g - g @ star))) for g in gens_l); sq = float(np.max(np.abs(star @ star + np.eye(6))))
    # one constant lambda and the cone speed K fix both vacuum constants: eps = lambda / K, 1/mu = lambda K
    worst = 0.0
    for _ in range(20):
        Kc, lam = rng.uniform(0.5, 3), rng.uniform(0.2, 5); eps, mu = lam / Kc, 1 / (lam * Kc)
        w = _maxwell_speeds(eps, mu, k=rng.normal(size=3)); nz = np.sort(np.abs(w.real))
        worst = max(worst, abs(eps * mu * Kc ** 2 - 1), float(np.max(np.abs(nz[2:] - Kc))), float(np.max(nz[:2])), float(np.max(np.abs(w.imag))))
    # the axion-type term is invisible; the fourth rotation-invariant term is not
    ax = float(np.max(np.abs(np.sort(np.abs(_maxwell_speeds(1.0, 1.0, alpha=0.7).real)) - np.sort(np.abs(_maxwell_speeds(1.0, 1.0).real)))))
    sk = _maxwell_speeds(1.0, 1.0, beta=0.3); skew = float(np.max(np.abs(sk.imag)))
    # canary: a medium at rest (rotation invariant, eps mu K^2 = n^2) has speed K/n; a moving observer sees K/n dragged
    n_, v = 1.5, 0.2; drag = ((1 / n_ + v) / (1 + v / n_), (1 / n_ - v) / (1 - v / n_))
    ok = dim_l == 2 and dim_r == 4 and dim_e == 2 and comm < 1e-12 and sq < 1e-12 and worst < 1e-9 and ax < 1e-9 and skew > 0.1 \
        and abs(drag[0] - 1 / n_) > 0.05
    must(ok, 'MB')
    R['MB'] = dict(claim='Constitutive law. Linear maps on 2-forms that commute with the Lorentz group form a space of dimension '
                         '2, spanned by the identity and the Hodge star (which squares to -1); under rotations alone the dimension '
                         'is 4. The identity term (axion type) does not change the waves; so one constant lambda remains, with '
                         'eps = lambda/K and 1/mu = lambda K, hence eps mu K^2 = 1, two polarizations and one speed K in every '
                         'direction. Canary: the fourth rotation-invariant term makes the frequencies complex; a medium of index '
                         '1.5 has speed K/1.5 at rest and 0.765 K, 0.538 K for an observer moving at 0.2 K.',
                   status='PROVED (representation theory) + numerical check', commutant_dim_lorentz=int(dim_l), commutant_dim_rotations=int(dim_r),
                   commutant_dim_euclidean=int(dim_e), star_commutator=fl(comm), star_squared_plus_one=fl(sq), vacuum_relation_defect=fl(worst),
                   axion_term_effect=fl(ax), fourth_term_imaginary_part=fl(skew), dragged_speeds=[fl(drag[0]), fl(drag[1])])


# ============================================================================================ MC: gauge quotient
def MC():
    import sympy as sp
    rng = np.random.default_rng(SEED + 3)
    a, b, m2, chi = sp.symbols('a b m2 chi'); p = sp.symbols('p0:4')
    A = [pi * chi for pi in p]; p2 = sum(pi ** 2 for pi in p)
    form = a * p2 * sum(x ** 2 for x in A) + b * sum(pi * x for pi, x in zip(p, A)) ** 2 + m2 * sum(x ** 2 for x in A)
    poly = sp.Poly(sp.expand(form / chi ** 2), *p)
    sol = sp.solve(poly.coeffs(), [a, b, m2], dict=True)
    unique = sol == [{a: -b, m2: 0}]
    sig, conv = {}, {}
    for D in (3, 4, 5):
        pv = rng.normal(size=D); Q = (pv @ pv) * np.eye(D) - np.outer(pv, pv); ev = np.linalg.eigvalsh(Q); tol = 1e-9 * ev.max()
        sig[D] = (int(np.sum(ev > tol)), int(np.sum(ev < -tol)), int(np.sum(np.abs(ev) <= tol)))
        Jc = rng.normal(size=D); Jc -= (Jc @ pv) / (pv @ pv) * pv; Jn = rng.normal(size=D)
        resp = lambda J_, e: float(J_ @ np.linalg.solve(e * np.eye(D) + Q, J_))
        conv[D] = (abs(resp(Jc, 1e-8) - resp(Jc, 1e-10)) / resp(Jc, 1e-10), resp(Jn, 1e-10) / resp(Jn, 1e-8))
    # with a mass term there is no null direction and no quotient
    pv = rng.normal(size=4); proca_min = float(np.min(np.linalg.eigvalsh((pv @ pv + 0.3) * np.eye(4) - np.outer(pv, pv))))
    # Gauss flux through a sphere: constant for the massless kernel 1/(4 pi r); (1 + m r) exp(-m r) for the massive one
    flux = lambda r, m: 4 * math.pi * r * r * (1 / r ** 2 + m / r) * math.exp(-m * r) / (4 * math.pi)
    gauss0 = [flux(r, 0.0) for r in (0.5, 2.0, 8.0)]; gaussm = [flux(r, 0.4) for r in (0.5, 2.0, 8.0)]
    lap = lambda f, r, h=1e-3: (f(r + h) - 2 * f(r) + f(r - h)) / h ** 2 + 2 / r * (f(r + h) - f(r - h)) / (2 * h)
    yuk = lambda r: math.exp(-0.4 * r) / (4 * math.pi * r); helm = abs(lap(yuk, 1.7) - 0.16 * yuk(1.7)) / yuk(1.7)
    ok = unique and all(sig[D] == (D - 1, 0, 1) for D in sig) and all(c[0] < 1e-6 and 90 < c[1] < 110 for c in conv.values()) \
        and proca_min > 0.29 and max(abs(g - 1) for g in gauss0) < 1e-12 and gaussm[2] < 0.2 and helm < 1e-5
    must(ok, 'MC')
    R['MC'] = dict(claim='Gauge quotient. The quadratic form a p^2 A^2 + b (p.A)^2 + m^2 A^2 vanishes on the hole A = p chi for '
                         'all p exactly when a + b = 0 and m = 0: descent through the quotient selects the Maxwell form and '
                         'excludes a mass. That form has one null direction and D - 1 positive ones (no negative one: unlike '
                         'gravity, the vector field has a probability kernel on the quotient). The regulated source response '
                         'converges exactly for conserved sources. The flux through a sphere is independent of the radius for '
                         'the massless kernel. Canary: with a mass the form has no null direction, and the flux decays as '
                         '(1 + m r) exp(-m r): the count is no longer recorded at a distance.',
                   status='PROVED', uniqueness=bool(unique), signature={str(D): list(v) for D, v in sig.items()},
                   conserved_change={str(D): fl(v[0]) for D, v in conv.items()}, nonconserved_growth={str(D): fl(v[1]) for D, v in conv.items()},
                   proca_min_eigenvalue=fl(proca_min), gauss_flux_massless=[fl(g) for g in gauss0], gauss_flux_massive=[fl(g) for g in gaussm],
                   yukawa_equation_defect=fl(helm))


# ============================================================================================ MD: lattice Biot-Savart
def _lattice_bs(N, side, chi=None):
    """Square unit-current loop of `side` cells in the plane z = N/2 of an N^3 periodic lattice (spacing 1/N, box 1).
    Returns A (3, N, N, N) by the pseudo-inverse of curl-curl in Fourier space, the current j, and B on faces."""
    j = np.zeros((3, N, N, N)); o = N // 2 - side // 2; z = N // 2
    for s in range(side):
        j[0, o + s, o, z] += 1; j[1, o + side, o + s, z] += 1; j[0, o + s, o + side, z] -= 1; j[1, o, o + s, z] -= 1
    kap = [np.exp(2j * np.pi * np.fft.fftfreq(N)) - 1 for _ in range(3)]
    KX, KY, KZ = np.meshgrid(*kap, indexing='ij'); k2 = np.abs(KX) ** 2 + np.abs(KY) ** 2 + np.abs(KZ) ** 2; k2[0, 0, 0] = 1.0
    A = np.array([np.fft.ifftn(np.fft.fftn(j[i]) / k2).real for i in range(3)])
    if chi is not None:
        A = A + np.array([np.roll(chi, -1, i) - chi for i in range(3)])
    d = lambda f, ax: np.roll(f, -1, ax) - f
    B = np.array([d(A[2], 1) - d(A[1], 2), d(A[0], 2) - d(A[2], 0), d(A[1], 0) - d(A[0], 1)])   # faces yz, zx, xy
    return A, j, B, (o, z)


def MD():
    rng = np.random.default_rng(SEED + 4)
    N, side = 16, 4; A, j, B, (o, z) = _lattice_bs(N, side)
    db = lambda f, ax: f - np.roll(f, 1, ax)
    amp = np.array([db(B[2], 1) - db(B[1], 2), db(B[0], 2) - db(B[2], 0), db(B[1], 0) - db(B[0], 1)])   # adjoint curl of B on edges
    ampere = float(np.max(np.abs(amp - j))); coulomb = float(np.max(np.abs(sum(db(A[i], i) for i in range(3)))))
    divB = float(np.max(np.abs(sum(np.roll(B[i], -1, i) - B[i] for i in range(3)))))
    energy = abs(0.5 * np.sum(B * B) - 0.5 * np.sum(j * A)) / (0.5 * np.sum(B * B))
    _, _, B2, _ = _lattice_bs(N, side, chi=rng.normal(size=(N, N, N))); gauge = float(np.max(np.abs(B2 - B)))
    A3 = A + np.array([np.roll(c_ := rng.normal(size=(N, N, N)), -1, i) - c_ for i in range(3)]); minimal = float(np.sum(A3 * A3) - np.sum(A * A))
    # refinement: physical loop of side l = 1/8 in the unit box; B_z at the centre in units mu0 I / length
    vals = {}
    for Nn in (64, 96, 128, 160):
        _, _, Bn, (on, zn) = _lattice_bs(Nn, Nn // 8); c = Nn // 2
        vals[Nn] = float(np.mean(Bn[2][c - 1:c + 1, c - 1:c + 1, zn])) * Nn                       # flux per face / a^2 for unit current
    Ns = np.array(sorted(vals)); v = np.array([vals[n_] for n_ in Ns]); a2 = 1.0 / Ns ** 2
    fit = np.polyfit(a2, v, 2); extrap = float(fit[2])                                              # v = v0 + c2 a^2 + c4 a^4
    ratio = (v[0] - v[1]) / (v[1] - v[2]); ratio_a2 = (a2[0] - a2[1]) / (a2[1] - a2[2])
    l_ = 1 / 8; free = 2 * math.sqrt(2) / (math.pi * l_); lorentz = -(2 / 3) * l_ ** 2                # periodic images: -(2/3) mu0 m / V
    rel = abs(extrap - (free + lorentz)) / free; rel_nolor = abs(extrap - free) / free
    ok = ampere < 1e-12 and coulomb < 1e-12 and divB < 1e-12 and energy < 1e-12 and gauge < 1e-12 and minimal > 0 \
        and abs(ratio / ratio_a2 - 1) < 0.2 and rel < 2e-4 and rel_nolor > 10 * rel
    must(ok, 'MD')
    R['MD'] = dict(claim='Lattice Biot-Savart. On a periodic lattice the field of a current loop is B = dA with A the pseudo-inverse '
                         'of the curl-curl operator on the gauge quotient. Then the lattice Ampere law holds on every edge, B is '
                         'divergence free on every cube, A is in the Coulomb gauge and has the least norm in its class, the energy '
                         'is j.A/2, and B does not depend on the representative. Under refinement the central field of a square '
                         'loop (8 to 20 cells per side) extrapolates in a^2 to the continuum Biot-Savart value 2 sqrt(2) mu0 I/(pi l) '
                         'minus the periodic-image term (2/3) mu0 I l^2 / V, to 4e-5. Canary: without the image term the '
                         'disagreement is 1.5e-3, forty times larger.',
                   status='PROVED (exact lattice identities) + numerical convergence', ampere_defect=fl(ampere), coulomb_gauge_defect=fl(coulomb),
                   divergence_defect=fl(divB), energy_identity_defect=fl(energy), gauge_dependence=fl(gauge), norm_excess_of_other_gauge=fl(minimal),
                   centre_field_by_N={str(k): fl(v_) for k, v_ in vals.items()}, refinement_ratio=fl(ratio), a2_ratio=fl(ratio_a2), extrapolated=fl(extrap),
                   continuum_free=fl(free), image_term=fl(lorentz), rel_err=fl(rel), rel_err_without_image_term=fl(rel_nolor))


# ============================================================================================ ME: continuum Biot-Savart
def _loop_pts(Rr, n, z0=0.0, turns=1):
    t = (np.arange(n) + 0.5) * 2 * np.pi * turns / n
    return np.stack([Rr * np.cos(t), Rr * np.sin(t), np.full(n, z0)], 1), np.stack([-Rr * np.sin(t), Rr * np.cos(t), np.zeros(n)], 1) * (2 * np.pi * turns / n)


def _bs(x, pts, dl, q=0.0):
    """B / (mu0 I) at the points x from the polygonal current (midpoint rule); kernel exponent 3 + q."""
    r = x[:, None, :] - pts[None, :, :]; d = np.linalg.norm(r, axis=2)
    return np.sum(np.cross(dl[None, :, :], r) / d[:, :, None] ** (3 + q), axis=1) / (4 * math.pi)


def _bz_exact(Rr, rho, z):
    m = 4 * Rr * rho / ((Rr + rho) ** 2 + z * z)
    return (ellipk(m) + (Rr * Rr - rho * rho - z * z) / ((Rr - rho) ** 2 + z * z) * ellipe(m)) / (2 * math.pi * math.sqrt((Rr + rho) ** 2 + z * z))


def ME():
    Rr = 1.0; pts, dl = _loop_pts(Rr, 4000)
    zs = np.array([0.0, 0.3, 1.0, 2.5]); on = _bs(np.stack([0 * zs, 0 * zs, zs], 1), pts, dl)[:, 2]
    on_err = float(np.max(np.abs(on - Rr ** 2 / (2 * (Rr ** 2 + zs ** 2) ** 1.5))))
    off = [(0.4, 0.2), (0.7, -0.5), (1.6, 0.3), (2.5, 1.0)]
    off_err = max(abs(_bs(np.array([[rho, 0, z]]), pts, dl)[0, 2] - _bz_exact(Rr, rho, z)) / abs(_bz_exact(Rr, rho, z)) for rho, z in off)
    far = _bs(np.array([[0, 0, 60.0]]), pts, dl)[0, 2]; dip = math.pi * Rr ** 2 / (2 * math.pi * 60.0 ** 3); dip_err = abs(far - dip) / dip
    # Ampere circulation = linking number: circle through the loop once, the same circle traversed twice, and an unlinked circle
    def circulation(center, rad, turns, n=1500):
        t = (np.arange(n) + 0.5) * 2 * np.pi * turns / n
        x = np.stack([center + rad * np.cos(t), np.zeros(n), rad * np.sin(t)], 1); dx = np.stack([-rad * np.sin(t), np.zeros(n), rad * np.cos(t)], 1) * (2 * np.pi * turns / n)
        return float(np.sum(_bs(x, pts, dl) * dx))
    link = [abs(circulation(1.0, 0.5, 1)), abs(circulation(1.0, 0.5, 2)), abs(circulation(3.0, 0.5, 1))]   # orientation fixes the sign
    # local equations away from the current
    h = 1e-3; x0 = np.array([0.45, 0.2, 0.35]); e = np.eye(3)
    Jm = np.array([(_bs((x0 + h * e[i])[None], pts, dl)[0] - _bs((x0 - h * e[i])[None], pts, dl)[0]) / (2 * h) for i in range(3)])   # Jm[i, j] = d_i B_j
    div = abs(np.trace(Jm)); curl = float(np.max(np.abs(Jm - Jm.T)))
    # straight wire: finite segment formula, long-wire limit, force between parallel wires (N/m for 1 A at 1 m)
    Lw = 400.0; n = 400000; zz = (np.arange(n) + 0.5) * Lw / n - Lw / 2; wp = np.stack([0 * zz, 0 * zz, zz], 1); wd = np.stack([0 * zz, 0 * zz, np.full(n, Lw / n)], 1)
    bw = abs(_bs(np.array([[1.0, 0, 0]]), wp, wd)[0, 1]); seg = (Lw / 2) / math.sqrt(1 + (Lw / 2) ** 2) / (2 * math.pi)
    force = MU0 * bw                                                                                  # mu0 I1 I2 /(2 pi d)
    # canary: with the kernel 1/r^(3+q) the circulation around a long wire depends on the radius as rho^-q
    q = 0.05; b1 = abs(_bs(np.array([[1.0, 0, 0]]), wp, wd, q=q)[0, 1]); b2 = abs(_bs(np.array([[2.0, 0, 0]]), wp, wd, q=q)[0, 1])
    circ_ratio = (2 * b2) / b1
    ok = on_err < 1e-9 and off_err < 1e-6 and dip_err < 1e-3 and abs(link[0] - 1) < 1e-5 and abs(link[1] - 2) < 1e-5 and abs(link[2]) < 1e-6 \
        and div < 1e-5 and curl < 1e-5 and abs(bw - seg) < 1e-9 and abs(force / 2e-7 - 1) < 2e-5 and abs(circ_ratio - 2 ** -q) < 1e-3 and abs(circ_ratio - 1) > 0.02
    must(ok, 'ME')
    R['ME'] = dict(claim='Continuum Biot-Savart. Direct quadrature of the law reproduces the circular loop on the axis, off the axis '
                         '(elliptic integrals) and its dipole limit; B is divergence free and curl free away from the current; '
                         'the circulation of B around a closed path equals mu0 I times the linking number (1, 2, 0); two parallel '
                         'wires 1 m apart carrying 1 A attract with 2e-7 N per metre for mu0 = 4 pi e-7. Canary: with a kernel '
                         '1/r^(3+q) the circulation around a wire depends on the radius as rho^-q: the exponent is fixed by the '
                         'closedness of the count.',
                   status='PROVED + numerical quadrature', on_axis_err=fl(on_err), off_axis_rel_err=fl(off_err), dipole_rel_err=fl(dip_err),
                   circulation_over_mu0I=[fl(v) for v in link], divergence=fl(div), curl=fl(curl), long_wire_field=fl(bw),
                   force_per_metre=fl(force), exponent_canary_circulation_ratio=fl(circ_ratio), predicted_ratio=fl(2 ** -q))


# ============================================================================================ MF: representer and inductance
def _mutual(R1, R2, d):
    m = 4 * R1 * R2 / ((R1 + R2) ** 2 + d * d); k = math.sqrt(m)
    return math.sqrt(R1 * R2) * ((2 / k - k) * ellipk(m) - (2 / k) * ellipe(m))                      # in units of mu0


def MF():
    loops = [(1.0, 0.0), (0.6, 0.4), (1.5, -0.3), (0.8, 1.1)]; wire = 1e-3
    # Neumann double integral against Maxwell's formula
    def neumann(R1, z1, R2, z2, n=1500):
        p1, d1 = _loop_pts(R1, n, z1); p2, d2 = _loop_pts(R2, n, z2)
        return float(np.sum((d1 @ d2.T) / np.linalg.norm(p1[:, None, :] - p2[None, :, :], axis=2)) / (4 * math.pi))
    neu = max(abs(neumann(*loops[i], *loops[j]) - _mutual(loops[i][0], loops[j][0], loops[i][1] - loops[j][1])) / _mutual(loops[i][0], loops[j][0], loops[i][1] - loops[j][1])
              for i in range(4) for j in range(i + 1, 4))
    # reciprocity: flux of the Biot-Savart field of loop i through the disk of loop j
    def flux(i, j):
        Ri, zi = loops[i]; Rj, zj = loops[j]
        return quad(lambda rho: 2 * math.pi * rho * _bz_exact(Ri, rho, zj - zi), 0, Rj, limit=200, points=[Ri] if Ri < Rj else None)[0]
    rec = max(abs(flux(i, j) - flux(j, i)) / abs(flux(i, j)) for i in range(4) for j in range(i + 1, 4))
    fl_vs = max(abs(flux(i, j) - _mutual(loops[i][0], loops[j][0], loops[i][1] - loops[j][1])) / _mutual(loops[i][0], loops[j][0], loops[i][1] - loops[j][1])
                for i in range(4) for j in range(i + 1, 4))
    # Gram matrix of the representers: symmetric, positive; energy of currents; least energy for given flux readings
    Lm = np.array([[_mutual(loops[i][0], loops[j][0], loops[i][1] - loops[j][1]) if i != j else loops[i][0] * (math.log(8 * loops[i][0] / wire) - 2)
                    for j in range(4)] for i in range(4)])
    pos = float(np.min(np.linalg.eigvalsh(Lm)))
    Phi = np.array([1.0, -0.5, 0.3]); L3 = Lm[:3, :3]; W0 = 0.5 * Phi @ np.linalg.solve(L3, Phi); excess = []
    for I4 in (0.2, 0.4):
        I3 = np.linalg.solve(L3, Phi - Lm[:3, 3] * I4); Iall = np.append(I3, I4); excess.append(0.5 * Iall @ Lm @ Iall - W0)
    schur = Lm[3, 3] - Lm[3, :3] @ np.linalg.solve(L3, Lm[:3, 3])
    # force = gradient of the Gram matrix at fixed currents, against I dl x B (coaxial loops R1 = 1, R2 = 0.6, separation 0.4)
    hh = 1e-5; dM = (_mutual(1.0, 0.6, 0.4 + hh) - _mutual(1.0, 0.6, 0.4 - hh)) / (2 * hh)
    pts1, dl1 = _loop_pts(1.0, 4000); Brho = _bs(np.array([[0.6, 0.0, 0.4]]), pts1, dl1)[0, 0]
    force_err = abs(dM - (-2 * math.pi * 0.6 * Brho)) / abs(dM)
    # the line probe is inadmissible: the self-inductance of a filament diverges like mu0 R ln(1/a)
    gaps = [1e-2, 1e-3, 1e-4, 1e-5]; self_ = [_mutual(1.0, 1.0 - g, 0.0) for g in gaps]
    asym = max(abs(s - (math.log(8 / g) - 2)) for s, g in zip(self_[1:], gaps[1:])); slope = (self_[3] - self_[2]) / math.log(10)
    ok = neu < 1e-5 and rec < 1e-7 and fl_vs < 1e-7 and pos > 0 and all(x > 0 for x in excess) and abs(excess[1] / excess[0] - 4) < 1e-9 \
        and abs(excess[0] - 0.5 * schur * 0.04) < 1e-12 and asym < 2e-2 and abs(slope - 1) < 1e-3 and force_err < 1e-6 and dM < 0
    must(ok, 'MF')
    R['MF'] = dict(claim='Biot-Savart as representer. The flux reading of a loop is represented, in the energy form, by the '
                         'Biot-Savart field of a unit current in that loop; the Gram matrix of representers is the inductance '
                         'matrix (Neumann integral = Maxwell formula = flux of one field through the other loop), symmetric and '
                         'positive. Among all current systems with given flux readings the energy Phi L^-1 Phi / 2 is least; a '
                         'current in a further loop adds the positive Schur term. The force between two loops is the gradient of '
                         'their mutual inductance at fixed currents and equals the force I dl x B. Canary: the line probe is inadmissible, its '
                         'self-inductance diverges as mu0 R ln(1/a), slope mu0 R per e-fold of the wire radius.',
                   status='PROVED + numerical check', neumann_vs_maxwell=fl(neu), reciprocity_defect=fl(rec), flux_vs_formula=fl(fl_vs),
                   gram_min_eigenvalue=fl(pos), energy_excess=[fl(x) for x in excess], schur_complement=fl(schur), force_gradient=fl(dM), force_law_rel_err=fl(force_err),
                   self_inductance_by_gap={str(g): fl(s) for g, s in zip(gaps, self_)}, thin_wire_formula_err=fl(asym), log_slope=fl(slope))


# ============================================================================================ MG: magnetism from the frontier
def MG():
    rng = np.random.default_rng(SEED + 5)
    worst = 0.0
    for _ in range(20):
        K, eps0, lam0, rho = rng.uniform(0.5, 4), rng.uniform(0.3, 3), rng.uniform(0.2, 2), rng.uniform(0.3, 3)
        v = rng.uniform(0.05, 0.95) * K; g = 1 / math.sqrt(1 - v * v / K ** 2)
        # field tensor F^{mu nu}, coordinates (K t, x, y, z); line charge along z at rest: E_x = lam0 / (2 pi eps0 rho) at (rho, 0, 0)
        E = lam0 / (2 * math.pi * eps0 * rho); F = np.zeros((4, 4)); F[0, 1], F[1, 0] = E / K, -E / K
        Lb = np.eye(4); Lb[0, 0] = Lb[3, 3] = g; Lb[0, 3] = Lb[3, 0] = g * v / K              # the line moves with +v along z in the new frame
        Fp = Lb @ F @ Lb.T; Ep = Fp[0, 1] * K; Bp = Fp[3, 1]                                  # B_y = F^{zx}
        mu0 = 1 / (eps0 * K ** 2); I = g * lam0 * v
        worst = max(worst, abs(Bp - mu0 * I / (2 * math.pi * rho)) / abs(Bp), abs(Ep - g * E) / Ep)
    # Heaviside field of a point charge in uniform motion, integrated along a line of charges: exactly mu0 I / (2 pi rho)
    K, eps0, mu0 = 1.0, 1.0, 1.0; heav = {}
    for beta in (0.1, 0.6, 0.95):
        f = lambda z: (1 - beta ** 2) / (4 * math.pi * eps0) * 1.0 / ((1.0 + z * z) ** 1.5 * (1 - beta ** 2 * 1.0 / (1.0 + z * z)) ** 1.5)   # E_perp at rho = 1
        Eperp = quad(f, -np.inf, np.inf)[0]; heav[beta] = abs(beta * Eperp / K - mu0 * beta / (2 * math.pi)) / (mu0 * beta / (2 * math.pi))
    # canary: the Biot-Savart law for one moving point charge is not exact; error (1 - beta^2)^(-1/2) - 1 broadside
    point_err = {beta: (1 - beta ** 2) ** -0.5 - 1 for beta in (0.01, 0.1, 0.6)}
    # two parallel co-moving lines: magnetic attraction / electric repulsion = beta^2; net force per lab length = rest-frame value
    ratio, net = {}, {}
    for beta in (0.1, 0.5, 0.9):
        g = 1 / math.sqrt(1 - beta ** 2); lam = g * 1.0; Fel = lam ** 2 / (2 * math.pi * eps0); Fmag = mu0 * (lam * beta) ** 2 / (2 * math.pi)
        ratio[beta] = Fmag / Fel; net[beta] = (Fel - Fmag) / (1.0 / (2 * math.pi * eps0))
    # no frontier, no magnetism: mu0 = 1/(eps0 K^2) -> 0; drift velocity in a copper wire (illustrative numbers)
    galilean = [1 / (1.0 * Kc ** 2) for Kc in (1.0, 1e3, 1e6)]
    vd = 1.0 / (8.5e28 * 1.602176634e-19 * 1e-6); beta2 = (vd / 299792458.0) ** 2
    ok = worst < 1e-12 and max(heav.values()) < 1e-8 and abs(point_err[0.1] - 0.005038) < 1e-5 and all(abs(ratio[b_] - b_ ** 2) < 1e-12 for b_ in ratio) \
        and all(abs(net[b_] - 1) < 1e-12 for b_ in net) and galilean[2] < 1e-11 and 1e-26 < beta2 < 1e-24
    must(ok, 'MG')
    R['MG'] = dict(claim='Magnetism from the frontier. A static line charge seen by an observer in relative motion has '
                         'B = mu0 I / (2 pi rho) exactly, with mu0 = 1/(eps0 K^2) and I the transformed current. The Heaviside '
                         'field of a uniformly moving point charge, integrated along a line, gives the same at every speed. The '
                         'magnetic attraction of two co-moving lines is beta^2 times their electric repulsion, and the net force '
                         'per unit length equals the rest-frame value. As K grows at fixed eps0 the coupling mu0 vanishes: no '
                         'frontier, no magnetism. Canary: Biot-Savart for a single moving point charge is wrong by '
                         '(1 - beta^2)^(-1/2) - 1 broadside. For a copper wire carrying 1 A through 1 mm^2, beta^2 is 6e-26.',
                   status='PROVED (Lorentz transformation) + numerical check', boosted_line_defect=fl(worst), heaviside_line_defect={str(k): fl(v) for k, v in heav.items()},
                   point_charge_law_error={str(k): fl(v) for k, v in point_err.items()}, force_ratio={str(k): fl(v) for k, v in ratio.items()},
                   net_force_over_rest={str(k): fl(v) for k, v in net.items()}, mu0_by_K=[fl(v) for v in galilean], drift_velocity=fl(vd), drift_beta2=fl(beta2))


# ============================================================================================ MH: waves
def MH():
    rng = np.random.default_rng(SEED + 6)
    # lattice vector field in temporal gauge: modes of curl-curl at momentum k: one zero (gauge), two equal (polarizations)
    worst, counts = 0.0, []
    for _ in range(20):
        kap = np.exp(1j * rng.uniform(-np.pi, np.pi, 3)) - 1; Lk = (np.vdot(kap, kap).real) * np.eye(3) - np.outer(kap, kap.conj())
        ev = np.sort(np.linalg.eigvalsh(Lk)); worst = max(worst, abs(ev[0]), abs(ev[1] - ev[2]), abs(ev[2] - np.vdot(kap, kap).real))
        counts.append(int(np.sum(np.linalg.eigvalsh(Lk + 0.2 * np.eye(3)) > 0.21)))
    # 1-D Yee scheme at the magic step: the pulse moves exactly one cell per step; front speed = K
    n = 400; Ey = np.zeros(n); Bz = np.zeros(n); Ey[200:205] = [0.2, 0.7, 1.0, 0.7, 0.2]; Bz[200:205] = Ey[200:205]   # right-moving
    for _ in range(120):
        Ey[1:] -= (Bz[1:] - Bz[:-1]); Bz[:-1] -= (Ey[1:] - Ey[:-1])
    sup = np.nonzero(np.abs(Ey) > 1e-12)[0]; front = (sup.max() - 204) / 120; shape = float(np.max(np.abs(Ey[320:325] - np.array([0.2, 0.7, 1.0, 0.7, 0.2]))))
    # canary: a massive vector field has three polarizations and a slower bulk (group velocity k / sqrt(k^2 + m^2))
    vg = 1.0 / math.sqrt(1.0 + 0.5 ** 2)
    ok = worst < 1e-12 and all(c == 2 for c in counts) and front == 1.0 and shape < 1e-12 and vg < 0.9
    must(ok, 'MH')
    R['MH'] = dict(claim='Waves. On the gauge quotient the field has two polarizations with one dispersion at every momentum. In '
                         'one dimension, at the step that makes the numerical cone equal to the physical one, a pulse moves '
                         'exactly one cell per step without change of shape: the field built on the one cone is a massless '
                         'carrier and attains the frontier. Canary: with a mass the third polarization appears (count 3) and the '
                         'bulk travels at k / sqrt(k^2 + m^2).',
                   status='PROVED + numerical check', polarization_defect=fl(worst), massless_mode_count_above_mass_gap=counts[:5],
                   front_speed=fl(front), shape_defect=fl(shape), massive_group_velocity=fl(vg))


# ============================================================================================ MI: data
def MI():
    c = 299792458.0; h = 6.62607015e-34; e = 1.602176634e-19; me = 9.1093837139e-31
    mu0, dmu0 = 1.25663706127e-6, 0.00000000020e-6; eps0 = 8.8541878188e-12; ainv, dainv = 137.035999177, 0.000000021
    RK = h / e ** 2; Z0 = mu0 * c
    # static determinations of the frontier (ratio of electromagnetic to electrostatic units)
    rosa = (299788.0 - c / 1e3) / 30.0; weber = 3.1e8 / c - 1
    # pure numbers: K (raw speed, Tensor Frontier) and alpha = Z0 / (2 R_K)
    alpha_from_Z = Z0 / (2 * RK); rel_alpha = abs(alpha_from_Z * ainv - 1); unity = abs(mu0 * eps0 * c * c - 1)
    old = mu0 / (4e-7 * math.pi) - 1
    dets = {'Rb recoil 2020': (137.035999206, 0.000000011), 'Cs recoil 2018': (137.035999046, 0.000000027), 'electron g-2 2023': (137.035999166, 0.000000015)}
    spread = (max(v[0] for v in dets.values()) - min(v[0] for v in dets.values())) / ainv
    rbcs = (dets['Rb recoil 2020'][0] - dets['Cs recoil 2018'][0]) / math.hypot(0.000000011, 0.000000027)
    # photon mass bounds as ranges of the static kernel: hbar c / m
    hbarc_eVm = 197.3269804e-9; ranges = {'solar wind (PDG adopted), 1e-18 eV': hbarc_eVm / 1e-18, 'Coulomb law test 1971, 1e-14 eV': hbarc_eVm / 1e-14}
    # vacuum nonlinearity: critical field and the relative correction (2 alpha / 45 pi)(E / E_c)^2 at 1e7 V/m
    hbar = h / (2 * math.pi); Ec = me ** 2 * c ** 3 / (e * hbar); nonlin = (2 / (45 * math.pi * ainv)) * (1e7 / Ec) ** 2
    ampere = mu0 / (2 * math.pi)
    # canary: the pre-1855 alternative, no relation between the unit ratio and the speed of light, e.g. the speed of sound
    sound = (343.0 - c) / 30e3
    ok = abs(rosa) < 2 and abs(weber) < 0.05 and rel_alpha < 3 * dainv / ainv + 2e-10 and unity < 3e-10 and abs(old) < 1e-9 and 5 < rbcs < 6 \
        and spread < 2e-9 and ranges['solar wind (PDG adopted), 1e-18 eV'] > 1e11 and 1.3e18 < Ec < 1.35e18 and nonlin < 1e-25 and abs(sound) > 1e3
    must(ok, 'MI')
    R['MI'] = dict(claim='Data. The frontier from statics: the ratio of electromagnetic to electrostatic units gave 3.1e8 m/s in '
                         '1855 and 299788 +- 30 km/s in 1907, pull -0.15 against the propagation value. The two vacuum constants '
                         'carry two pure numbers only: the raw speed K and alpha = Z0 / (2 R_K) = 1/137.036, the vacuum impedance '
                         'in units of the quantum of resistance; the 2022 values are mutually consistent to 3e-10 and mu0 differs '
                         'from 4 pi e-7 by -1.3e-10. Independent determinations of alpha agree to 1.2e-9 and disagree with each '
                         'other at 5.5 sigma (Rb against Cs). The photon mass is below 1e-18 eV: the static kernel is unscreened '
                         'beyond 2e11 m. The linear-response premise is known to fail: the correction is 6e-27 at 1e7 V/m, '
                         'critical field 1.32e18 V/m.',
                   status='MEASURED inputs (published) + arithmetic', rosa_dorsey_pull=fl(rosa), weber_kohlrausch_rel=fl(weber), alpha_from_impedance_inverse=fl(1 / alpha_from_Z),
                   alpha_consistency=fl(rel_alpha), mu0_eps0_c2_minus_1=fl(unity), mu0_over_old_minus_1=fl(old), Z0_ohm=fl(Z0), RK_ohm=fl(RK),
                   alpha_spread=fl(spread), rb_cs_sigma=fl(rbcs), photon_range_m={k: fl(v) for k, v in ranges.items()}, critical_field=fl(Ec),
                   nonlinearity_at_1e7=fl(nonlin), ampere_force_1A_1m=fl(ampere), sound_pull=fl(sound))


if __name__ == '__main__':
    for f in [MA, MB, MC, MD, ME, MF, MG, MH, MI]:
        f(); print(f.__name__, flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(open(os.path.abspath(__file__), 'rb').read()).hexdigest()
    json.dump(out, open(os.path.join(HERE, 'rg_magnetism_results.json'), 'w'), indent=1, sort_keys=True)
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
