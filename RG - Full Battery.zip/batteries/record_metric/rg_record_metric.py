#!/usr/bin/env python3
"""Resolution Geometry - the record metric: Cencov's theorem with monotonicity as output, classical and quantum.

The metric of a family of states is defined as what records certify: the local minimax width of a scalar target from N
records. Everything else is tested as a consequence.

  CA width is Fisher. N-record intervals at width z/sqrt(N J) cover at the nominal rate uniformly over a local
     neighbourhood (Hajek-Le Cam); canary: a superefficient (Hodges) estimator with a narrower width covers at one point
     and fails near it, so the metric is a local-uniform notion, not a pointwise one
  CB monotonicity as output. Processed records are simulable from the original ones, so the certified width cannot
     shrink: Fisher contraction on random Markov maps, invariance under lossless splitting, and the unit fixed by
     counting (a metric 2J undercovers). Canary: Euclidean distance increases when two outcomes are merged
  CC the envelope, one formula. sup over all record protocols of J_A(v) = tr(rho L_v^2) (L the symmetric logarithmic
     derivative), attained by the eigenbasis of L; classical as the commuting case; qubit and qutrit. Canary: a family
     not closed under the system's symmetry has a non-quadratic envelope (parallelogram law fails)
  CD tasks collapse on single records. With records made copy by copy, the local metric of relative-entropy (Stein)
     testing is SLD/2 and of Chernoff testing SLD/8: every task gives the same metric up to its constant. The Petz
     spread appears only when copies are processed jointly: Umegaki relative entropy gives BKM/2, quantum Chernoff
     WY/8, and the two-copy measured relative entropy already exceeds twice the single-copy one. Estimation alone is
     grouping-invariant: random two-copy POVMs never exceed 2 SLD. Canary: a commuting direction, where all coincide
  CE the direction obstruction is capacity, not quantumness. Tr(J_full^-1 J_A) <= min(m - 1, n) for classical records
     with m outcomes, attained by the full record; a classical Gaussian with one scalar readout per copy has trace 1
     exactly; quantum: <= d - 1 for d = 2, 3 against d^2 - 1 parameters
  CF the obstruction is a curvature. For pure states tr(rho (L_i L_j + L_j L_i)/2) = 4 Re Q_ij and
     tr(rho [L_i, L_j]) = 8 i Im Q_ij (Q the quantum geometric tensor); the antisymmetric part is a closed two-form.
     Canary: commuting generators, zero obstruction
  CG distances are attained pairwise. min over POVMs of the Bhattacharyya coefficient equals the fidelity, attained by
     one measurement; the geodesic length of the record metric equals 2 arccos F
  CH the classical limit keeps the obstruction. Spin-j coherent states: record metric 2j(dtheta^2 + sin^2 dphi^2)
     (round sphere, curvature 1/2j), obstruction j sin(theta) (Chern number 2j), ratio 1/2 for every j; the
     coherent-state (Husimi) measurement attains exactly half the metric in each direction for every j. Canary: a
     commuting family, where one measurement attains the full metric jointly

Deterministic. Seed 20261205. Writes rg_record_metric_results.json.
Run:  python3 -I rg_record_metric.py      (numpy, scipy)
"""
import hashlib, json, math, sys
from pathlib import Path
import numpy as np
from scipy.linalg import expm, sqrtm, logm
from scipy.optimize import minimize, minimize_scalar
from scipy.stats import norm
from scipy.special import comb

HERE = Path(__file__).resolve().parent
SEED = 20261205
R, FAILS = {}, []
SX = np.array([[0, 1], [1, 0]], complex); SY = np.array([[0, -1j], [1j, 0]]); SZ = np.array([[1, 0], [0, -1]], complex); I2 = np.eye(2)
PAULI = (SX, SY, SZ)


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.8g}')


def below(v, b):
    return f'< {b:g}' if abs(v) < b else fl(v)


def bloch(r):
    return (I2 + sum(c * P for c, P in zip(r, PAULI))) / 2


F_PETZ = {
    'SLD': lambda x: (1 + x) / 2,
    'WY': lambda x: ((1 + np.sqrt(x)) / 2) ** 2,
    'BKM': lambda x: np.where(np.abs(x - 1) < 1e-12, 1.0, (x - 1) / np.log(np.where(np.abs(x - 1) < 1e-12, 2.0, x))),
    'RLD': lambda x: 2 * x / (1 + x),
}


def petz(rho, d1, d2=None, kind='SLD'):
    d2 = d1 if d2 is None else d2
    lam, U = np.linalg.eigh(rho); a = U.conj().T @ d1 @ U; b = U.conj().T @ d2 @ U
    X, Y = np.meshgrid(lam, lam, indexing='ij'); return float(np.real(np.sum(np.conj(a) * b / (Y * F_PETZ[kind](X / Y)))))


def sld(rho, d):
    lam, U = np.linalg.eigh(rho); a = U.conj().T @ d @ U
    return U @ (2 * a / (lam[:, None] + lam[None, :])) @ U.conj().T


def cfisher(povm, rho, ds):
    p = np.array([np.real(np.trace(E @ rho)) for E in povm]); keep = p > 1e-14
    dp = np.array([[np.real(np.trace(E @ d)) for E in povm] for d in ds])[:, keep]
    return (dp / p[keep]) @ dp.T


def rpovm(rng, dim, k):
    V = rng.normal(size=(k, dim)) + 1j * rng.normal(size=(k, dim)); S = sum(np.outer(v, v.conj()) for v in V)
    w, Q = np.linalg.eigh(S); Si = Q @ np.diag(w ** -0.5) @ Q.conj().T
    return [Si @ np.outer(v, v.conj()) @ Si for v in V]


def rstate(rng, dim, floor=0.05):
    G = rng.normal(size=(dim, dim)) + 1j * rng.normal(size=(dim, dim)); rho = G @ G.conj().T; rho /= np.trace(rho).real
    return (1 - floor) * rho + floor * np.eye(dim) / dim


def rherm(rng, dim, traceless=True):
    H = rng.normal(size=(dim, dim)) + 1j * rng.normal(size=(dim, dim)); H = (H + H.conj().T) / 2
    return H - np.trace(H) / dim * np.eye(dim) if traceless else H


def gellmann():
    out = []
    for i in range(3):
        for j in range(i + 1, 3):
            A = np.zeros((3, 3), complex); A[i, j] = A[j, i] = 1; out.append(A)
            B = np.zeros((3, 3), complex); B[i, j] = -1j; B[j, i] = 1j; out.append(B)
    out.append(np.diag([1, -1, 0]).astype(complex)); out.append(np.diag([1, 1, -2]).astype(complex) / math.sqrt(3))
    return [m / 2 for m in out]


def proj_basis(U):
    return [np.outer(U[:, i], U[:, i].conj()) for i in range(U.shape[1])]


# ============================================================================================ CA
def CA():
    rng = np.random.default_rng(SEED); z = norm.ppf(0.975)
    Fth = lambda t: 1 / (2 * (1 - t ** 2))                    # p = ((1+t)/4, (1-t)/4, 1/2)
    def sample(t, N, runs):
        c = rng.multinomial(N, [(1 + t) / 4, (1 - t) / 4, 0.5], size=runs); return (c[:, 0] - c[:, 1]) / np.maximum(c[:, 0] + c[:, 1], 1)
    cov = {}; sdr = {}
    for N in (2000, 20000):
        e = sample(0.3, N, 4000); cov[N] = float(np.mean(np.abs(e - 0.3) <= z / np.sqrt(N * Fth(e)))); sdr[N] = float(np.std(e) * math.sqrt(N * Fth(0.3)))
    N = 20000; t0 = 0.3; unit = 1 / math.sqrt(N * Fth(t0)); hs = np.linspace(0, 10, 21)
    cov_mle, cov_hodges = [], []
    for h in hs:
        t = t0 + h * unit; e = sample(t, N, 3000)
        cov_mle.append(float(np.mean(np.abs(e - t) <= z / np.sqrt(N * Fth(e)))))
        hod = np.where(np.abs(e - t0) > N ** -0.25, e, t0)
        cov_hodges.append(float(np.mean(np.abs(hod - t) <= z / np.sqrt(2 * N * Fth(t0)))))
    ok = all(abs(v - 0.95) < 0.015 for v in cov.values()) and all(abs(v - 1) < 0.04 for v in sdr.values()) \
        and min(cov_mle) > 0.93 and cov_hodges[0] > 0.999 and min(cov_hodges) < 0.05
    must(ok, 'CA')
    R['CA'] = dict(claim='Width is Fisher. For a three-outcome family, N-record intervals at half-width z/sqrt(N J) cover at the nominal '
                         '0.95 and the spread of the estimate times sqrt(N J) tends to 1: the metric is read off the certified width, '
                         'and it is the Fisher information (Hajek-Le Cam local asymptotic minimax). Over a neighbourhood of 21 points '
                         'up to 10 resolution units away the coverage stays near 0.95. Canary: a superefficient (Hodges) estimator '
                         'certified at a width sqrt(2) narrower covers perfectly at its chosen point and fails close to it (minimum '
                         'coverage below). A metric narrower than Fisher is never uniformly certifiable.',
                   status='PROVED (Hajek 1972, Le Cam) + computed', coverage_by_N={str(k): fl(v) for k, v in cov.items()}, sd_times_sqrtNJ={str(k): fl(v) for k, v in sdr.items()},
                   neighbourhood_min_coverage_fisher=fl(min(cov_mle)), hodges_coverage_at_point=fl(cov_hodges[0]), hodges_min_coverage=fl(min(cov_hodges)))


# ============================================================================================ CB
def CB():
    rng = np.random.default_rng(SEED + 1)
    fish = lambda p, dp: float(np.sum(dp ** 2 / p)); eucl = lambda p, q: float(np.linalg.norm(p - q))
    worst = -1.0
    for _ in range(500):
        k = int(rng.integers(2, 7)); p = rng.dirichlet(np.ones(k)); dp = rng.normal(size=k); dp -= dp.mean()
        M = rng.uniform(size=(int(rng.integers(2, 7)), k)); M /= M.sum(0); worst = max(worst, fish(M @ p, M @ dp) - fish(p, dp))
    p = np.array([0.2, 0.5, 0.3]); dp = np.array([0.1, -0.3, 0.2]); split = lambda v: np.array([v[0] * 0.3, v[0] * 0.7, v[1], v[2]])
    inv = abs(fish(split(p), split(dp)) - fish(p, dp))
    # Euclidean merge increase: p, q on three outcomes, merge outcomes 0 and 1
    P = np.array([0.5, 0.0, 0.5]); Q = np.array([0.0, 0.5, 0.5]); merge = lambda v: np.array([v[0] + v[1], v[2]])
    P2 = np.array([1 / 3, 0, 2 / 3]); Q2 = np.array([0, 1 / 3, 2 / 3])
    ratio = max(eucl(merge(a), merge(b)) / eucl(a, b) for a, b in ((P, Q), (P2, Q2), (np.array([0.6, 0.1, 0.3]), np.array([0.1, 0.6, 0.3]))))
    merge_euclid_increase = eucl(merge(np.array([0.5, 0.2, 0.3])), merge(np.array([0.2, 0.1, 0.7]))) / eucl(np.array([0.5, 0.2, 0.3]), np.array([0.2, 0.1, 0.7]))
    # unit fixed by counting: a metric c J with c = 2 forecasts a width that undercovers
    z = norm.ppf(0.975); th, N = 0.3, 10000; F = 1 / (th * (1 - th)); est = rng.binomial(N, th, 4000) / N
    cov = {c: float(np.mean(np.abs(est - th) <= z / math.sqrt(N * c * F))) for c in (0.5, 1.0, 2.0)}
    ok = worst < 1e-10 and inv < 1e-12 and merge_euclid_increase > 1 and abs(cov[1.0] - 0.95) < 0.015 and cov[2.0] < 0.86 and cov[0.5] > 0.99
    must(ok, 'CB')
    R['CB'] = dict(claim='Monotonicity as output. A processed record is computable from the original one, so any certificate from the '
                         'processed record is one from the original: the certified width cannot shrink under processing, and the '
                         'width metric cannot increase. Checked: on 500 random Markov maps Fisher never increases; it is invariant under '
                         'lossless splitting of an outcome; and the unit is fixed by counting records, not chosen: a metric 2J forecasts '
                         'widths that cover 0.83 instead of 0.95, a metric J/2 overcovers. Canary: Euclidean distance between two laws '
                         'increases when two outcomes are merged (ratio below), so it is not what records certify.',
                   status='PROVED (simulation argument; Cencov 1982 for uniqueness) + computed', max_fisher_increase=below(worst, 1e-10),
                   split_change=below(inv, 1e-12), euclid_merge_ratio=fl(merge_euclid_increase), coverage_by_scale={str(k): fl(v) for k, v in cov.items()})


# ============================================================================================ CC
def CC():
    rng = np.random.default_rng(SEED + 2); attain = 0.0; excess = -1.0
    for dim in (2, 3):
        for _ in range(150):
            rho = rstate(rng, dim); d = rherm(rng, dim); L = sld(rho, d); env = float(np.real(np.trace(rho @ L @ L)))
            env2 = petz(rho, d, kind='SLD'); _, V = np.linalg.eigh(L)
            attain = max(attain, abs(cfisher(proj_basis(V), rho, [d])[0, 0] - env) / env, abs(env - env2) / env)
            for _ in range(10):
                excess = max(excess, (cfisher(rpovm(rng, dim, int(rng.integers(dim, 3 * dim + 1))), rho, [d])[0, 0] - env) / env)
    # classical case: commuting family, envelope = classical Fisher of the eigenvalue law
    lam = np.array([0.5, 0.3, 0.2]); dl = np.array([0.1, -0.04, -0.06]); rho = np.diag(lam).astype(complex); d = np.diag(dl).astype(complex)
    L = sld(rho, d); classical = abs(float(np.real(np.trace(rho @ L @ L))) - float(np.sum(dl ** 2 / lam)))
    # canary: restricted family (x and y readouts only) on a 2D Gaussian with identity covariance
    env_r = lambda v: max(v[0] ** 2, v[1] ** 2)
    para_r = env_r(np.array([1, 1])) + env_r(np.array([1, -1])) - 2 * env_r(np.array([1, 0])) - 2 * env_r(np.array([0, 1]))
    # rotation-closed family on a random covariance: envelope sup_u (u.v)^2 / (u S u) = v S^-1 v
    A = rng.normal(size=(2, 2)); S = A @ A.T + 0.3 * np.eye(2); Si = np.linalg.inv(S); ang = np.linspace(0, math.pi, 20001)
    U = np.stack([np.cos(ang), np.sin(ang)], 1)
    env_c = lambda v: float(np.max((U @ v) ** 2 / np.einsum('ij,jk,ik->i', U, S, U)))
    vs = rng.normal(size=(20, 2)); quad_err = max(abs(env_c(v) - v @ Si @ v) / (v @ Si @ v) for v in vs)
    a, b = vs[0], vs[1]; para_c = env_c(a + b) + env_c(a - b) - 2 * env_c(a) - 2 * env_c(b)
    ok = attain < 1e-9 and excess < 1e-9 and classical < 1e-12 and abs(para_r) > 1 and quad_err < 1e-6 and abs(para_c) < 1e-5 * (env_c(a) + env_c(b))
    must(ok, 'CC')
    R['CC'] = dict(claim='The envelope, one formula. For 300 random full-rank states of a qubit and a qutrit, the measurement in the '
                         'eigenbasis of the symmetric logarithmic derivative L attains tr(rho L^2), which equals the SLD metric, and '
                         '3000 random POVMs never exceed it. Proof by one Cauchy-Schwarz step: tr(E d rho) = Re tr(rho L E), hence '
                         'J_A <= sum_k tr(rho L E_k L) = tr(rho L^2). Classical systems are the commuting case: the envelope is the '
                         'Fisher information of the eigenvalue law. Canary: a family with only x and y readouts on an isotropic '
                         'Gaussian has envelope max(v1^2, v2^2), which violates the parallelogram law by the value below; closing the '
                         'family under rotations restores a quadratic envelope, v S^-1 v (error below).',
                   status='PROVED (Braunstein-Caves 1994) + computed', attain_rel_error=below(attain, 1e-9), povm_max_rel_excess=fl(excess),
                   classical_case_error=below(classical, 1e-12), restricted_parallelogram_defect=fl(para_r), closed_family_quadratic_error=below(quad_err, 1e-6))


# ============================================================================================ CD
def kl(p, q):
    m = p > 1e-300; return float(np.sum(p[m] * np.log(p[m] / q[m])))


def chernoff(p, q):
    res = minimize_scalar(lambda s: math.log(float(np.sum(p ** s * q ** (1 - s)))), bounds=(1e-6, 1 - 1e-6), method='bounded', options=dict(xatol=1e-12))
    return -res.fun


def measured(rho, sig, div, dim=2):
    """Max over rank-one projective measurements (unitary parametrised by a Hermitian generator) of a classical divergence."""
    def val(h):
        H = np.zeros((dim, dim), complex); iu = np.triu_indices(dim, 1)
        H[np.diag_indices(dim)] = h[:dim]; H[iu] = h[dim:dim + len(iu[0])] + 1j * h[dim + len(iu[0]):]; H = H + np.triu(H, 1).conj().T
        U = expm(1j * H); p = np.real(np.einsum('ji,jk,ki->i', U.conj(), rho, U)); q = np.real(np.einsum('ji,jk,ki->i', U.conj(), sig, U))
        p = np.clip(p, 1e-300, None); q = np.clip(q, 1e-300, None); return -div(p, q)
    npar = dim * dim; rng = np.random.default_rng(SEED + 77); best = -math.inf
    starts = [np.zeros(npar)] + [rng.normal(scale=1.5, size=npar) for _ in range(12 if dim == 2 else 24)]
    for x0 in starts:
        r = minimize(val, x0, method='BFGS', options=dict(gtol=1e-12, maxiter=3000)); best = max(best, -r.fun)
    return best


def umegaki(rho, sig):
    return float(np.real(np.trace(rho @ (logm(rho) - logm(sig)))))


def qchernoff(rho, sig):
    lr, Ur = np.linalg.eigh(rho); ls, Us = np.linalg.eigh(sig)
    f = lambda s: math.log(float(np.real(np.trace((Ur * lr ** s) @ Ur.conj().T @ (Us * ls ** (1 - s)) @ Us.conj().T))))
    return -minimize_scalar(f, bounds=(1e-6, 1 - 1e-6), method='bounded', options=dict(xatol=1e-12)).fun


def CD():
    r0 = 0.6; rv = lambda e: np.array([r0 * math.sin(e), 0.0, r0 * math.cos(e)])
    rho = bloch(rv(0)); d = bloch(np.array([r0, 0, 0])) - I2 / 2
    g = {k: petz(rho, d, kind=k) for k in F_PETZ}
    eps = (0.02, 0.01); rat = {}
    for name, fn, const, kind in (('measured_KL', lambda a, b: measured(a, b, kl), 2, 'SLD'), ('measured_Chernoff', lambda a, b: measured(a, b, chernoff), 8, 'SLD'),
                                  ('Umegaki', umegaki, 2, 'BKM'), ('quantum_Chernoff', qchernoff, 8, 'WY')):
        vals = [fn(rho, bloch(rv(e))) / e ** 2 for e in eps]; extrap = (4 * vals[1] - vals[0]) / 3
        rat[name] = dict(local=fl(extrap), predicted=fl(g[kind] / const), metric=kind, rel_error=fl(abs(extrap - g[kind] / const) / (g[kind] / const)))
    # the same quantities against the other metrics, to show they are distinct
    distinct = g['SLD'] < g['WY'] < g['BKM']
    # grouping, on a purer state (|r| = 0.9): at a finite separation two copies processed jointly gain; locally they do not
    r1 = 0.9; rw = lambda e: np.array([r1 * math.sin(e), 0.0, r1 * math.cos(e)]); rho9 = bloch(rw(0)); d9 = bloch(np.array([r1, 0, 0])) - I2 / 2
    g9 = {k: petz(rho9, d9, kind=k) for k in ('SLD', 'BKM')}
    e = 1.0; s1 = bloch(rw(e)); DM1 = measured(rho9, s1, kl, 2); DM2 = measured(np.kron(rho9, rho9), np.kron(s1, s1), kl, 4) / 2; DU = umegaki(rho9, s1)
    loc2 = [measured(np.kron(rho9, rho9), np.kron(bloch(rw(x)), bloch(rw(x))), kl, 4) / 2 / x ** 2 for x in (0.04, 0.02)]; loc2 = (4 * loc2[1] - loc2[0]) / 3
    # estimation is grouping-invariant: two-copy POVMs never exceed 2 SLD; the product of the single-copy optimum attains it
    rng = np.random.default_rng(SEED + 3); rr = np.kron(rho, rho); dd = np.kron(d, rho) + np.kron(rho, d)
    two_copy_excess = max((cfisher(rpovm(rng, 4, int(rng.integers(4, 13))), rr, [dd])[0, 0] - 2 * g['SLD']) / (2 * g['SLD']) for _ in range(2000))
    _, V = np.linalg.eigh(sld(rho, d)); prod = [np.kron(A, B) for A in proj_basis(V) for B in proj_basis(V)]
    prod_err = abs(cfisher(prod, rr, [dd])[0, 0] - 2 * g['SLD'])
    # canary: commuting direction (change of the Bloch length), all metrics and all tasks coincide
    dc = SZ / 2; gc = [petz(rho, dc, kind=k) for k in F_PETZ]; spread = max(gc) - min(gc)
    # anchor: on commuting states the collective divergences reduce to the classical ones, in the right orientation
    pa, pb = np.array([0.7, 0.3]), np.array([0.4, 0.6]); A_, B_ = np.diag(pa).astype(complex), np.diag(pb).astype(complex)
    anchor = max(abs(umegaki(A_, B_) - kl(pa, pb)), abs(qchernoff(A_, B_) - chernoff(pa, pb)))
    ok = all(v['rel_error'] < 0.01 for v in rat.values()) and distinct and DM1 < DM2 - 1e-3 and DM2 < DU \
        and abs(loc2 - g9['SLD'] / 2) / (g9['SLD'] / 2) < 1e-3 and loc2 < 0.7 * g9['BKM'] / 2 and two_copy_excess < 1e-9 and prod_err < 1e-10 and spread < 1e-12 and anchor < 1e-9
    must(ok, 'CD')
    R['CD'] = dict(claim='Tasks collapse on single records. Mixed qubit (|r| = 0.6), coherent direction. With records made copy by copy, the '
                         'local metric of relative-entropy (Stein) testing is SLD/2 and that of Chernoff testing SLD/8 (measured '
                         'divergences, maximised over measurements, Richardson-extrapolated to zero separation): the task fixes only the '
                         'constant. The Petz spread appears only when copies are processed jointly before recording: the Umegaki relative '
                         'entropy gives BKM/2 and the quantum Chernoff bound WY/8, with SLD < WY < BKM here. On a purer state (|r| = 0.9), at '
                         'a finite separation the two-copy measured relative entropy per copy exceeds the single-copy one and stays '
                         'below Umegaki; but locally it is SLD/2 again, not BKM/2. Every finite grouping gives SLD at the resolution '
                         'scale; BKM and WY are reached only when the number of copies goes to infinity at fixed separation before the '
                         'separation goes to zero. The two limits do not commute, and the task dependence of the quantum metric is '
                         'this order of limits. '
                         'Estimation alone does not depend on grouping: 2000 random two-copy POVMs never exceed 2 SLD, and the product of '
                         'single-copy optimal measurements attains it. Canary: a commuting direction, where all four metrics coincide; on '
                         'commuting states the collective divergences reduce to classical KL and Chernoff, in the right orientation.',
                   status='computed; Hiai-Petz 1991, Nagaoka 2006, Audenaert et al. 2007 for the collective limits', metrics={k: fl(v) for k, v in g.items()}, local=rat,
                   grouping=dict(state_r=r1, separation=e, measured_one_copy=fl(DM1), measured_two_copy_per_copy=fl(DM2), umegaki=fl(DU),
                                 local_two_copy_per_copy=fl(loc2), SLD_over_2=fl(g9['SLD'] / 2), BKM_over_2=fl(g9['BKM'] / 2)),
                   estimation_two_copy_rel_excess=fl(two_copy_excess), product_attains_error=below(prod_err, 1e-10), commuting_spread=below(spread, 1e-12), commuting_anchor_error=below(anchor, 1e-9))


# ============================================================================================ CE
def CE():
    rng = np.random.default_rng(SEED + 4)
    # classical: full model on 4 outcomes (3 parameters), garbled records with m outcomes
    p = rng.dirichlet(np.ones(4) * 3); basis = np.array([[1, -1, 0, 0], [1, 0, -1, 0], [1, 0, 0, -1]], float)
    Ffull = (basis / p) @ basis.T; Fi = np.linalg.inv(Ffull); cls = {}
    for m in (2, 3, 4):
        worst = 0.0
        for _ in range(500):
            M = rng.uniform(size=(m, 4)) ** 3; M /= M.sum(0); q = M @ p; dq = basis @ M.T
            J = (dq / q) @ dq.T; worst = max(worst, float(np.trace(Fi @ J)))
        cls[m] = worst
    ident = float(np.trace(Fi @ Ffull))
    # macro: classical Gaussian with one scalar readout per copy
    A = rng.normal(size=(2, 2)); S = A @ A.T + 0.2 * np.eye(2); us = rng.normal(size=(200, 2))
    macro = max(abs(float(np.trace(S @ (np.outer(u, u) / (u @ S @ u)))) - 1) for u in us)
    # quantum: qubit (3 parameters) and qutrit (8 parameters), full models
    q = {}
    for dim, basisq in ((2, [P / 2 for P in PAULI]), (3, gellmann())):
        rho = rstate(rng, dim, 0.2); JS = np.array([[petz(rho, a, b) for b in basisq] for a in basisq]); JSi = np.linalg.inv(JS)
        q[dim] = max(float(np.trace(JSi @ cfisher(rpovm(rng, dim, int(rng.integers(dim, 3 * dim + 1))), rho, basisq))) for _ in range(1500))
    ok = all(cls[m] <= min(m - 1, 3) + 1e-9 for m in cls) and abs(ident - 3) < 1e-9 and macro < 1e-12 and q[2] <= 1 + 1e-9 and q[3] <= 2 + 1e-9 and q[3] > 1.5
    must(ok, 'CE')
    R['CE'] = dict(claim='The direction obstruction is capacity, not quantumness. Classical: for records with m outcomes on a 3-parameter '
                         'family, Tr(F_full^-1 J_A) <= min(m - 1, 3) (since J_A <= F_full), and the full record attains 3: no '
                         'obstruction. A classical Gaussian read through one scalar per copy has Tr(S J_u) = 1 exactly for every '
                         'readout: per direction it attains the full metric (Cauchy-Schwarz), jointly only one direction\'s worth; this '
                         'is the quantum obstruction in a classical system. Quantum: Tr(J_SLD^-1 J_A) <= d - 1 for every single-copy '
                         'measurement (qubit 1 of 3, qutrit 2 of 8 parameters; Gill-Massar). Quantum mechanics is the case in which '
                         'the capacity of every record is intrinsically below the number of state parameters.',
                   status='PROVED (classical: data processing; quantum: Gill-Massar 2000) + computed', classical_max_trace={str(k): fl(v) for k, v in cls.items()},
                   full_record_trace=fl(ident), macro_single_readout_deviation_from_1=below(macro, 1e-12), quantum_max_trace={'d2_of_3': fl(q[2]), 'd3_of_8': fl(q[3])})


# ============================================================================================ CF
def qgt(psi_fn, th, h=1e-6):
    psi = psi_fn(th); n = len(th); dps = []
    for k in range(n):
        e = np.zeros(n); e[k] = h; a, b = psi_fn(th + e), psi_fn(th - e)
        a = a * np.exp(-1j * np.angle(np.vdot(psi, a))); b = b * np.exp(-1j * np.angle(np.vdot(psi, b))); dps.append((a - b) / (2 * h))
    P = np.eye(len(psi)) - np.outer(psi, psi.conj())
    return np.array([[np.vdot(dps[i], P @ dps[j]) for j in range(n)] for i in range(n)]), psi, dps


def CF():
    rng = np.random.default_rng(SEED + 5); dim = 4; psi0 = rng.normal(size=dim) + 1j * rng.normal(size=dim); psi0 /= np.linalg.norm(psi0)
    Hs = [rherm(rng, dim, False) for _ in range(3)]
    fam = lambda th: expm(-1j * sum(t * H for t, H in zip(th, Hs))) @ psi0
    th0 = np.array([0.3, -0.2, 0.5]); Q, psi, dps = qgt(fam, th0)
    rho = np.outer(psi, psi.conj()); drs = [np.outer(dp, psi.conj()) + np.outer(psi, dp.conj()) for dp in dps]; Ls = [2 * x for x in drs]
    sym_err = max(abs(np.real(np.trace(rho @ (Ls[i] @ Ls[j] + Ls[j] @ Ls[i]) / 2)) - 4 * Q[i, j].real) for i in range(3) for j in range(3))
    anti_err = max(abs(np.trace(rho @ (Ls[i] @ Ls[j] - Ls[j] @ Ls[i])) - 8j * Q[i, j].imag) for i in range(3) for j in range(3))
    curv = lambda th: -2 * qgt(fam, th, 1e-5)[0].imag
    h = 1e-3; dF = 0.0; scale = 0.0
    def dcurv(k, i, j):
        e = np.zeros(3); e[k] = h; return (curv(th0 + e)[i, j] - curv(th0 - e)[i, j]) / (2 * h)
    terms = [dcurv(0, 1, 2), dcurv(1, 2, 0), dcurv(2, 0, 1)]; dF = abs(sum(terms)); scale = max(abs(t) for t in terms)
    Hc = [np.diag(rng.normal(size=dim)).astype(complex) for _ in range(2)]
    famc = lambda th: expm(-1j * sum(t * H for t, H in zip(th, Hc))) @ psi0
    Qc = qgt(famc, np.array([0.3, -0.2]))[0]
    ok = sym_err < 1e-6 and anti_err < 1e-6 and dF < 1e-4 * scale and scale > 0.1 and abs(Qc[0, 1].imag) < 1e-8 and abs(Q[0, 1].imag) > 0.05
    must(ok, 'CF')
    R['CF'] = dict(claim='The obstruction is a curvature. For a random pure four-level family generated by three non-commuting '
                         'Hamiltonians, the symmetric part of the SLD products is the record metric, tr(rho (L_i L_j + L_j L_i)/2) = 4 Re '
                         'Q_ij, and the antisymmetric part is the obstruction, tr(rho [L_i, L_j]) = 8 i Im Q_ij, with Q the quantum '
                         'geometric tensor. -2 Im Q is the Berry curvature: a closed two-form (dF = 0 to the value below relative to its '
                         'terms). Weak commutativity, the condition for joint attainability with collective measurements, is the '
                         'vanishing of this curvature. Canary: commuting generators give Im Q = 0.',
                   status='PROVED (algebra; Berry 1984; Matsumoto 2002, Ragy et al. 2016) + computed', symmetric_identity_error=below(sym_err, 1e-6),
                   antisymmetric_identity_error=below(anti_err, 1e-6), closedness_relative=fl(dF / scale), curvature_scale=fl(scale), commuting_imQ=below(abs(Qc[0, 1].imag), 1e-8))


# ============================================================================================ CG
def fid(rho, sig):
    s = sqrtm(rho); return float(np.real(np.trace(sqrtm(s @ sig @ s))))


def CG():
    rng = np.random.default_rng(SEED + 6); attain = 0.0; below_f = 1.0
    for dim in (2, 3):
        for _ in range(100):
            rho, sig = rstate(rng, dim), rstate(rng, dim); F = fid(rho, sig)
            s = sqrtm(rho); si = np.linalg.inv(s); M = si @ sqrtm(s @ sig @ s) @ si; M = (M + M.conj().T) / 2; _, V = np.linalg.eigh(M)
            E = proj_basis(V); B = sum(math.sqrt(max(np.real(np.trace(e @ rho)), 0) * max(np.real(np.trace(e @ sig)), 0)) for e in E)
            attain = max(attain, abs(B - F))
            for _ in range(10):
                E = rpovm(rng, dim, int(rng.integers(dim, 3 * dim + 1)))
                Bv = sum(math.sqrt(max(np.real(np.trace(e @ rho)), 0) * max(np.real(np.trace(e @ sig)), 0)) for e in E); below_f = min(below_f, Bv - F)
    # geodesic length of the record metric between two qubit states, by direct path minimisation
    G = lambda r: np.eye(3) + np.outer(r, r) / (1 - r @ r)
    pts = rng.uniform(-0.5, 0.5, size=(10, 3)); gerr = max(abs(G(r)[i, j] - petz(bloch(r), PAULI[i] / 2, PAULI[j] / 2)) for r in pts for i in range(3) for j in range(3))
    ra, rb = np.array([0.6, 0.1, -0.2]), np.array([-0.3, 0.5, 0.4]); K = 60
    def length(x):
        path = np.vstack([ra, x.reshape(K - 1, 3), rb]); seg = np.diff(path, axis=0); mid = (path[1:] + path[:-1]) / 2
        if np.any(np.einsum('ij,ij->i', mid, mid) >= 0.999):
            return 1e6
        return float(np.sum(np.sqrt(np.einsum('ij,ij->i', seg, seg) + np.einsum('ij,ij->i', seg, mid) ** 2 / (1 - np.einsum('ij,ij->i', mid, mid)))))
    x0 = np.linspace(ra, rb, K + 1)[1:-1].ravel(); res = minimize(length, x0, method='L-BFGS-B', options=dict(maxiter=20000, ftol=1e-15, gtol=1e-12))
    target = 2 * math.acos(min(1.0, fid(bloch(ra), bloch(rb)))); gl = res.fun
    ok = attain < 1e-8 and below_f > -1e-10 and gerr < 1e-10 and abs(gl - target) / target < 2e-3
    must(ok, 'CG')
    R['CG'] = dict(claim='Distances are attained pairwise. For 200 random pairs of qubit and qutrit states, the Fuchs-Caves measurement '
                         'attains the fidelity as its Bhattacharyya coefficient, and 2000 random POVMs never go below it: the largest '
                         'Fisher-Rao distance between the outcome laws of one measurement, 2 arccos B, is 2 arccos F. A direct '
                         'minimisation of path length in the record metric between two mixed qubit states gives the same number. '
                         'Integrated, the record metric is attained by a single protocol for every pair: in one dimension there is '
                         'no obstruction; the obstruction lives in two-planes.',
                   status='PROVED (Fuchs-Caves 1995; Uhlmann 1976) + computed', fuchs_caves_attain_error=below(attain, 1e-8), random_povm_min_margin=fl(below_f),
                   closed_form_metric_error=below(gerr, 1e-10), geodesic_length=fl(gl), two_arccos_F=fl(target), rel_error=fl(abs(gl - target) / target))


# ============================================================================================ CH
def spin_ops(j):
    m = np.arange(j, -j - 1, -1); n = len(m); Jz = np.diag(m).astype(complex); Jp = np.zeros((n, n), complex)
    for k in range(1, n):
        Jp[k - 1, k] = math.sqrt(j * (j + 1) - m[k] * (m[k] + 1))
    return (Jp + Jp.conj().T) / 2, (Jp - Jp.conj().T) / 2j, Jz


def coherent_analytic(j, th, ph):
    m = np.arange(j, -j - 1, -1)
    return np.sqrt(comb(2 * j, j + m)) * np.cos(th / 2) ** (j + m) * np.sin(th / 2) ** (j - m) * np.exp(-1j * m * ph)


def CH():
    th0, ph0 = math.pi / 3, 0.4; rows = {}
    xg, wg = np.polynomial.legendre.leggauss(240); thg = np.arccos(xg); phg = np.linspace(0, 2 * math.pi, 241)[:-1]; wph = 2 * math.pi / 240
    for j in (0.5, 1, 2, 5, 10, 20):
        Jx, Jy, Jz = spin_ops(j); top = np.zeros(int(2 * j + 1), complex); top[0] = 1
        fam = lambda t: expm(-1j * t[1] * Jz) @ expm(-1j * t[0] * Jy) @ top
        Q, psi, dps = qgt(fam, np.array([th0, ph0])); G = 4 * Q.real; Fb = -2 * Q[0, 1].imag
        # coherent-state measurement: outcome density (2j+1)/(4 pi) |<n|psi>|^2, Fisher by quadrature
        TH, PH = np.meshgrid(thg, phg, indexing='ij')
        C = np.array([coherent_analytic(j, a, b) for a, b in zip(TH.ravel(), PH.ravel())])
        def qdens(t):
            return (2 * j + 1) / (4 * math.pi) * np.abs(C.conj() @ fam(t)) ** 2
        h = 1e-5; q0 = qdens(np.array([th0, ph0])); W = np.repeat(wg, 240) * wph
        dq = [(qdens(np.array([th0 + h * (k == 0), ph0 + h * (k == 1)])) - qdens(np.array([th0 - h * (k == 0), ph0 - h * (k == 1)]))) / (2 * h) for k in range(2)]
        J = np.array([[np.sum(W * dq[a] * dq[b] / np.maximum(q0, 1e-300)) for b in range(2)] for a in range(2)])
        rows[str(j)] = dict(G_tt=fl(G[0, 0]), G_pp_over_sin2=fl(G[1, 1] / math.sin(th0) ** 2), berry=fl(Fb), ratio=fl(abs(Fb) / math.sqrt(np.linalg.det(G))),
                            husimi_tt=fl(J[0, 0] / G[0, 0]), husimi_pp=fl(J[1, 1] / G[1, 1]), trace=fl(np.trace(np.linalg.inv(G) @ J)), norm=fl(np.sum(W * q0)))
    # Chern number for j = 1 and j = 5: integrate the curvature over the sphere (independent of phi)
    chern = {}
    for j in (1, 5):
        Jx, Jy, Jz = spin_ops(j); top = np.zeros(int(2 * j + 1), complex); top[0] = 1
        fam = lambda t: expm(-1j * t[1] * Jz) @ expm(-1j * t[0] * Jy) @ top
        ts = np.linspace(1e-3, math.pi - 1e-3, 201); Fv = np.array([-2 * qgt(fam, np.array([t, 0.0]))[0][0, 1].imag for t in ts])
        chern[str(j)] = fl(abs(np.trapezoid(Fv, ts)) * 2 * math.pi / (2 * math.pi))
    # canary: commuting qutrit family, computational basis attains the full metric jointly
    pf = lambda a, b: np.array([0.4 + 0.1 * a, 0.35 - 0.05 * a + 0.1 * b, 0.25 - 0.05 * a - 0.1 * b])
    rho = np.diag(pf(0, 0)).astype(complex); d1 = np.diag([0.1, -0.05, -0.05]).astype(complex); d2 = np.diag([0, 0.1, -0.1]).astype(complex)
    JS = np.array([[petz(rho, a, b) for b in (d1, d2)] for a in (d1, d2)]); Jc = cfisher(proj_basis(np.eye(3)), rho, [d1, d2])
    L1, L2 = sld(rho, d1), sld(rho, d2); canary = max(float(np.abs(JS - Jc).max()), abs(np.trace(rho @ (L1 @ L2 - L2 @ L1))))
    ok = all(abs(r['G_tt'] - 2 * float(j)) < 1e-5 * float(j) + 1e-6 and abs(r['G_pp_over_sin2'] - 2 * float(j)) < 1e-5 * float(j) + 1e-6
             and abs(abs(r['berry']) - float(j) * math.sin(th0)) < 1e-5 * float(j) and abs(r['ratio'] - 0.5) < 1e-5
             and abs(r['husimi_tt'] - 0.5) < 2e-3 and abs(r['husimi_pp'] - 0.5) < 2e-3 and abs(r['norm'] - 1) < 1e-6 for j, r in rows.items()) \
        and all(abs(v - 2 * float(j)) < 1e-3 * float(j) for j, v in chern.items()) and canary < 1e-12
    must(ok, 'CH')
    R['CH'] = dict(claim='The classical limit keeps the obstruction. For spin-j coherent states (j = 1/2 to 20) the record metric is '
                         '2j(dtheta^2 + sin^2 theta dphi^2): a round sphere of radius sqrt(2j), Gaussian curvature 1/2j, flat in the '
                         'classical limit. The obstruction (Berry curvature) is j sin(theta) dtheta dphi, proportional to the area '
                         'form, with ratio 1/2 to the metric area for every j, and integer total flux: Chern number 2j. The coherent-state '
                         '(Husimi) measurement attains exactly half of the metric in each direction, for every j, so Tr(G^-1 J) = 1: '
                         'the penalty for reading both directions at once does not shrink as the system becomes classical. In the limit '
                         'the record geometry is a flat plane carrying a metric and a symplectic form: classical phase space. Canary: a '
                         'commuting qutrit family, where the computational basis attains the full metric jointly and the obstruction '
                         'vanishes.',
                   status='PROVED (Perelomov; Provost-Vallee 1980) + computed', by_j=rows, chern_number=chern, commuting_canary=below(canary, 1e-12))


if __name__ == '__main__':
    for name, fn in (('CA', CA), ('CB', CB), ('CC', CC), ('CD', CD), ('CE', CE), ('CF', CF), ('CG', CG), ('CH', CH)):
        try:
            fn()
        except Exception as e:
            must(False, name); R[name] = dict(crash=repr(e))
        print(name, flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (HERE / 'rg_record_metric_results.json').write_text(json.dumps(out, indent=1, sort_keys=True))
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
