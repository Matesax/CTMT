#!/usr/bin/env python3
"""Mutation suite for rg_record_metric.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. A few minutes.

    python3 -I rg_record_metric_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('CA', 'certified width narrowed by sqrt 2', "cov[N] = float(np.mean(np.abs(e - 0.3) <= z / np.sqrt(N * Fth(e))))", "cov[N] = float(np.mean(np.abs(e - 0.3) <= z / np.sqrt(2 * N * Fth(e))))"),
    ('CB', 'Euclidean metric in place of Fisher', "fish = lambda p, dp: float(np.sum(dp ** 2 / p))", "fish = lambda p, dp: float(np.sum(dp ** 2))"),
    ('CC', 'SLD operator missing its factor 2', "return U @ (2 * a / (lam[:, None] + lam[None, :])) @ U.conj().T", "return U @ (a / (lam[:, None] + lam[None, :])) @ U.conj().T"),
    ('CC', 'restricted envelope made quadratic', "env_r = lambda v: max(v[0] ** 2, v[1] ** 2)", "env_r = lambda v: v[0] ** 2 + v[1] ** 2"),
    ('CD', 'measurement never optimised', "r = minimize(val, x0, method='BFGS', options=dict(gtol=1e-12, maxiter=3000))", "r = minimize(val, x0, method='BFGS', options=dict(gtol=1e-12, maxiter=0))"),
    ('CD', 'Umegaki with the arguments exchanged', "return float(np.real(np.trace(rho @ (logm(rho) - logm(sig)))))", "return float(np.real(np.trace(sig @ (logm(sig) - logm(rho)))))"),
    ('CE', 'Gill-Massar weight dropped', "JSi = np.linalg.inv(JS)\n        q[dim]", "JSi = np.eye(len(basisq)) / np.trace(JS) * len(basisq)\n        q[dim]"),
    ('CF', 'SLD of a pure state taken as d rho', "Ls = [2 * x for x in drs]", "Ls = [x for x in drs]"),
    ('CF', 'canary generators made non-commuting', "Hc = [np.diag(rng.normal(size=dim)).astype(complex) for _ in range(2)]", "Hc = [rherm(rng, dim, False) for _ in range(2)]"),
    ('CG', 'Fuchs-Caves operator without its sandwich', "M = si @ sqrtm(s @ sig @ s) @ si", "M = sqrtm(s @ sig @ s)"),
    ('CH', 'coherent-state measurement mis-normalised', "return (2 * j + 1) / (4 * math.pi) * np.abs(C.conj() @ fam(t)) ** 2", "return (2 * j + 2) / (4 * math.pi) * np.abs(C.conj() @ fam(t)) ** 2"),
    ('CH', 'commuting canary given a coherent direction', "d2 = np.diag([0, 0.1, -0.1]).astype(complex)", "d2 = np.array([[0, 0.05, 0], [0.05, 0.1, 0], [0, 0, -0.1]], complex)"),
]


def main():
    base = open(os.path.join(HERE, 'rg_record_metric.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_record_metric.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_record_metric.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_record_metric_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
