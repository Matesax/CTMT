#!/usr/bin/env python3
import numpy as np, json, csv
from pathlib import Path
from scipy.optimize import nnls
OUT=Path(__file__).resolve().parent

# Candidate RG predictor: minimal positive/passive exponential completion dimension
# for algebraic memory K(t)=(1+t)^(-alpha) on [0,T].
# Positive exponential mixtures preserve causality, passivity and composability.

def rel_l2(y, yh): return float(np.linalg.norm(y-yh)/np.linalg.norm(y))
def design(t,d,T):
    # fixed logarithmic relaxation spectrum, broad enough to resolve [0,T]
    rates=np.geomspace(1/(20*T),20.0,max(d,1))
    return np.exp(-np.outer(t,rates)), rates

def best_error(alpha,T,d,n=700):
    # geometric time sampling with quadrature weights in log-time; include t=0
    t=np.r_[0.0,np.geomspace(1e-5,T,n-1)]
    y=(1+t)**(-alpha)
    A,r=design(t,d,T)
    # weight approximately uniformly per logarithmic decade, but protect t=0
    w=np.ones_like(t); w[1:]=np.sqrt(np.gradient(np.log1p(t[1:])))
    c,_=nnls(A*w[:,None],y*w,maxiter=10000)
    yh=A@c
    return rel_l2(y*w,yh*w), c, r

def min_dim(alpha,T,eps,dmax=96):
    for d in range(1,dmax+1):
        e,c,r=best_error(alpha,T,d)
        if e<=eps: return d,e,c,r
    return None,e,c,r

alphas=[0.5,0.75,1.0,1.25,1.5,2.0]
Ts=[10,30,100,300,1000,3000,10000]
epss=[1e-2,3e-3,1e-3,3e-4,1e-4]
rows=[]
for a in alphas:
  for T in Ts:
    for eps in epss:
      d,e,_,_=min_dim(a,T,eps)
      rows.append({'alpha':a,'T':T,'eps':eps,'d':d if d is not None else 97,'error':e})

# Competing predictors, train on alternating cells and test on held-out cells.
X=[]; y=[]; train=[]
for i,r in enumerate(rows):
    L=np.log1p(r['T']); E=np.log(1/r['eps']); a=r['alpha']
    # candidate features motivated by exponential-sum approximation of completely monotone kernels
    X.append([1,L,E,L*E,np.log1p(a),E*np.log1p(a)])
    y.append(r['d']); train.append((i%3)!=0)
X=np.array(X); y=np.array(y); train=np.array(train)
coef=np.linalg.lstsq(X[train],y[train],rcond=None)[0]
pred=X@coef
rmse_train=float(np.sqrt(np.mean((pred[train]-y[train])**2)))
rmse_test=float(np.sqrt(np.mean((pred[~train]-y[~train])**2)))
r2_test=float(1-np.sum((pred[~train]-y[~train])**2)/np.sum((y[~train]-y[~train].mean())**2))
# Baselines additive, only logT, only logeps
models={}
for name,cols in {'additive':[0,1,2,4],'no_horizon':[0,2,4],'no_tolerance':[0,1,4],'product_core':[0,1,2,3]}.items():
    c=np.linalg.lstsq(X[train][:,cols],y[train],rcond=None)[0]
    p=X[:,cols]@c
    models[name]={'test_rmse':float(np.sqrt(np.mean((p[~train]-y[~train])**2))),'test_r2':float(1-np.sum((p[~train]-y[~train])**2)/np.sum((y[~train]-y[~train].mean())**2))}

# Scaling slopes per alpha: d ~ A + B log(1+T) log(1/eps)
slopes=[]
for a in alphas:
    rr=[r for r in rows if r['alpha']==a]
    z=np.array([np.log1p(r['T'])*np.log(1/r['eps']) for r in rr]); yy=np.array([r['d'] for r in rr])
    cc=np.polyfit(z,yy,1); pp=np.polyval(cc,z)
    slopes.append({'alpha':a,'slope':float(cc[0]),'intercept':float(cc[1]),'r2':float(1-np.sum((pp-yy)**2)/np.sum((yy-yy.mean())**2))})

# Frontier coupling attack: build finite-speed spatial Volterra dynamics using exact kernel and
# positive d-mode completion. Completion changes temporal approximation but cannot leak outside cone.
def simulate(Tn,L,alpha,modes=None):
    c=L//2; U=[np.eye(1,L,c).ravel()]
    if modes is None:
      weights=None
    else:
      weights,rates=modes
    for t in range(Tn):
      nxt=.5*(np.roll(U[-1],1)+np.roll(U[-1],-1))
      if modes is None:
        for j in range(1,t+2):
          old=U[-j]; k=.012*(1+j)**(-alpha)
          nxt += k*(np.roll(old,1)-2*old+np.roll(old,-1))
      else:
        # approximate kernel at integer lags
        for j in range(1,t+2):
          old=U[-j]; k=.012*np.sum(weights*np.exp(-rates*j))
          nxt += k*(np.roll(old,1)-2*old+np.roll(old,-1))
      U.append(nxt)
    return np.array(U)
alpha=1.5; Th=120; eps=1e-3
d,e,cw,rates=min_dim(alpha,Th,eps)
U=simulate(Th,401,alpha); V=simulate(Th,401,alpha,(cw,rates))
center=200; outside=0.0
for t in range(Th+1):
    mask=np.abs(np.arange(401)-center)>t
    if mask.any(): outside=max(outside,float(np.max(np.abs(V[t,mask]))))
traj_err=float(np.linalg.norm(V-U)/np.linalg.norm(U))

# Attack perturbations: stretched exponential and log-corrected tail should not obey identical coefficients.
def dataset_for_shape(shape):
 out=[]
 for T in Ts:
  for eps in epss:
   for d in range(1,97):
    t=np.r_[0.0,np.geomspace(1e-5,T,699)]
    if shape=='logcorr': yy=(1+t)**-1.5/(1+np.log1p(t))
    else: yy=np.exp(-np.sqrt(t))
    A,_=design(t,d,T); w=np.ones_like(t); w[1:]=np.sqrt(np.gradient(np.log1p(t[1:])))
    cc,_=nnls(A*w[:,None],yy*w,maxiter=10000); er=rel_l2(yy*w,(A@cc)*w)
    if er<=eps: break
   out.append({'T':T,'eps':eps,'d':d})
 return out
attacks={}
for shape in ['logcorr','stretched']:
 rr=dataset_for_shape(shape); XX=np.array([[1,np.log1p(r['T']),np.log(1/r['eps']),np.log1p(r['T'])*np.log(1/r['eps']),np.log1p(1.5),np.log(1/r['eps'])*np.log1p(1.5)] for r in rr]); yy=np.array([r['d'] for r in rr]); pp=XX@coef
 attacks[shape]={'rmse_under_powerlaw_predictor':float(np.sqrt(np.mean((pp-yy)**2))),'mean_dimension':float(yy.mean())}

gates={
 'candidate_beats_additive':rmse_test<models['additive']['test_rmse'],
 'heldout_r2_above_0_9':r2_test>0.9,
 'positive_completion_preserves_frontier':outside==0.0,
 'finite_completion_predicts_full_dynamics':traj_err<0.03,
 'shape_attack_separates_logcorr':attacks['logcorr']['rmse_under_powerlaw_predictor']>rmse_test*1.5,
 'shape_attack_separates_stretched':attacks['stretched']['rmse_under_powerlaw_predictor']>rmse_test*1.5,
}
res={'claim':'For completely monotone algebraic memory, the passive completion budget is approximately bilinear in log horizon and log inverse tolerance, with alpha-dependent correction; the same completion preserves a sharp spatial frontier.',
'coefficients':coef.tolist(),'train_rmse':rmse_train,'test_rmse':rmse_test,'test_r2':r2_test,'baselines':models,'slopes':slopes,'frontier_outside':outside,'trajectory_error':traj_err,'selected_dimension_example':d,'kernel_fit_error_example':e,'attacks':attacks,'gates':gates,'all_pass':all(gates.values()),'rows':rows}
(OUT/'rg_completion_scaling_results.json').write_text(json.dumps(res,indent=2))
with open(OUT/'rg_completion_scaling_rows.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
print(json.dumps({k:v for k,v in res.items() if k!='rows'},indent=2))
raise SystemExit(0 if res['all_pass'] else 1)
