#!/usr/bin/env python3
"""RG - Completion Budget: hostile attack on the supplied completion-scaling predictor.

The supplied battery (supplied/rg_completion_scaling_battery.py) fits the number d of positive relaxation modes needed
to approximate K(t) = (1 + t)^(-alpha) on [0, T] to tolerance eps, on a fixed logarithmic rate grid, and proposes the
bilinear law d ~ A + B log(1 + T) log(1/eps) as a novel prediction. Every group below carries a canary.

  CA reproduction: the 210 supplied budgets are recomputed exactly
  CB the law is published and a priori: McLean's trapezoid construction (2018) gives, with no fitting, positive weights
     and pointwise relative error <= eps on all 210 cells, with a term count of the bilinear form
  CC the horizon growth is an artifact of the T-dependent grid: with free rates, in the supplied norm, the budget
     stops growing with T (equal at T = 1e4, 1e5, 1e6) and is 2 to 3 times smaller; canary: the supplied grid keeps
     growing
  CD the norm decides: the free-rate completion that passes the supplied norm has a pointwise relative error that grows
     with T; growth with T is a property of the relative norm, where it is the published law
  CE the shape attack is an artifact of the rate cap 20: e^(-sqrt t) is completely monotone (Bernstein density checked)
     and needs few modes once rates above 20 are allowed; canary: with the cap the budget hits the search limit
  CF frontier preservation is built in: any kernel, of any sign, through a nearest-neighbour stencil keeps the support
     in the cone; the 3e-4 trajectory error is set by the memory amplitude 0.012; canary: dropping the memory entirely
  CG the predictor interpolates and does not extrapolate: train on small T or small alpha, test on the rest

Deterministic. Seed 20261119. Writes rg_completion_attack_results.json.
Run:  python3 -I rg_completion_attack.py
"""
import hashlib, json, math, os, sys
import numpy as np
from scipy.integrate import quad
from scipy.optimize import least_squares, nnls
from scipy.special import gammaincc, loggamma, gamma

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 20261119
R, FAILS = {}, []
ALPHAS = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]
TS = [10, 30, 100, 300, 1000, 3000, 10000]
EPSS = [1e-2, 3e-3, 1e-3, 3e-4, 1e-4]


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.6g}')


# ------------------------------------------------------------------------------------- the supplied construction, verbatim
def rel_l2(y, yh):
    return float(np.linalg.norm(y - yh) / np.linalg.norm(y))


def design(t, d, T, cap=20.0):
    rates = np.geomspace(1 / (20 * T), cap, max(d, 1))
    return np.exp(-np.outer(t, rates)), rates


def sample(T, n=700):
    t = np.r_[0.0, np.geomspace(1e-5, T, n - 1)]; w = np.ones_like(t); w[1:] = np.sqrt(np.gradient(np.log1p(t[1:])))
    return t, w


def best_error(y, t, w, d, T, cap=20.0):
    A, r = design(t, d, T, cap); c, _ = nnls(A * w[:, None], y * w, maxiter=10000)
    return rel_l2(y * w, (A @ c) * w)


def min_dim(kernel, T, eps, cap=20.0, dmax=96):
    t, w = sample(T); y = kernel(t)
    for d in range(1, dmax + 1):
        if best_error(y, t, w, d, T, cap) <= eps:
            return d
    return dmax + 1


# ================================================================================================ CA
def CA():
    sup = json.load(open(os.path.join(HERE, 'supplied', 'rg_completion_scaling_results_as_supplied.json')))
    rows = sup['rows']; mism = 0; D = {}
    for row in rows:
        d = min_dim(lambda t: (1 + t) ** -row['alpha'], row['T'], row['eps']); D[(row['alpha'], row['T'], row['eps'])] = d
        mism += d != row['d']
    ok = mism == 0 and len(rows) == 210
    must(ok, 'CA')
    R['CA'] = dict(claim='The 210 supplied budgets are recomputed exactly from the supplied construction (fixed rate grid from '
                         '1/(20T) to 20, log-time weighted relative L2 error, nonnegative least squares).',
                   status='computed', cells=len(rows), mismatches=mism)
    return D


# ================================================================================================ CB
def trapezoid(alpha, T, eps):
    """McLean's first construction for s^(-alpha), s = 1 + t in [1, 1 + T]: trapezoid rule for
    s^(-alpha) = (1/Gamma(alpha)) int exp(alpha x - s e^x) dx. Parameters fixed a priori from (alpha, T, eps)."""
    target = eps / 3
    h = 2.0
    while 2 * math.exp(float(np.real(loggamma(alpha + 2j * math.pi / h))) - float(loggamma(alpha))) > target:
        h *= 0.98                                                       # discretization: 2|Gamma(alpha + 2 pi i/h)|/Gamma(alpha)
    X = 0.0
    while gammaincc(alpha, math.exp(X)) > target:
        X += 0.01                                                       # upper truncation: Gamma(alpha, e^X)/Gamma(alpha)
    Y = math.log1p(T) + math.log(1 / (target * alpha * gamma(alpha))) / alpha   # lower truncation at s = 1 + T
    n = np.arange(-math.ceil(Y / h), math.ceil(X / h) + 1); x = n * h
    rates = np.exp(x); weights = h * np.exp(alpha * x - rates) / gamma(alpha)
    return rates, weights


def trapezoid_step(alpha, eps):
    h = 2.0
    while 2 * math.exp(float(np.real(loggamma(alpha + 2j * math.pi / h))) - float(loggamma(alpha))) > eps / 3:
        h *= 0.98
    return h


def CB():
    worst, Ls, rows = 0.0, {}, []
    t = np.r_[0.0, np.geomspace(1e-6, 1, 200)[:-1]]
    for a in ALPHAS:
        for T in TS:
            tt = np.r_[t, np.geomspace(1, T, 1500)]; y = (1 + tt) ** -a
            for eps in EPSS:
                r, w = trapezoid(a, T, eps); yh = np.exp(-np.outer(tt, r)) @ w
                e = float(np.max(np.abs(yh / y - 1))); worst = max(worst, e / eps); Ls[(a, T, eps)] = len(r)
                rows.append((a, T, eps, len(r), bool(np.all(w > 0))))
    # the term count has the bilinear form: fit L = c0 + c1 log(1+T) log(1/eps) + c2 log(1/eps)^2/alpha + c3 log(1/eps)
    X = np.array([[1, math.log1p(T) * math.log(1 / e), math.log(1 / e) ** 2 / a, math.log(1 / e)] for a, T, e, _, _ in rows]); Y = np.array([L for *_, L, _ in rows])
    cf = np.linalg.lstsq(X, Y, rcond=None)[0]; rmse = float(np.sqrt(np.mean((X @ cf - Y) ** 2)))
    positive = all(p for *_, p in rows)
    hs = {e: trapezoid_step(1.0, e) for e in EPSS}; ratio = [hs[e] * math.log(3 / e) / math.pi ** 2 for e in EPSS]
    slope = [(Ls[(1.0, 10000, e)] - Ls[(1.0, 10, e)]) * hs[e] / math.log(10001 / 11) for e in EPSS]
    ok = worst <= 1.0 and positive and all(0.65 < q < 1.0 for q in ratio) and all(abs(q - 1) < 0.35 for q in slope) and cf[1] > 0
    must(ok, 'CB')
    R['CB'] = dict(claim='The law is published and a priori. McLean\'s trapezoid construction for t^(-beta) (2018), applied to '
                         's = 1 + t on [1, 1 + T], fixes step and truncation from (alpha, T, eps) before any fit. On all 210 '
                         'cells it has positive weights and pointwise relative error at most eps (worst ratio 0.52). The step is '
                         'h = pi^2/log(3/eps) times a slowly varying factor (0.70 to 0.79 here, rising toward 1 as eps falls), and each further factor e in '
                         '1 + T adds 1/h terms (checked between T = 10 and 1e4, to within 8 per cent). The term count is therefore '
                         '[log(1+T) + log(1/eps)/alpha + O(1)] log(1/eps)/pi^2 to leading order: the product log(1+T) log(1/eps) '
                         'is the leading term of a known a priori construction. It is an upper bound, not the minimal count '
                         '(16 terms for the supplied worked example, where the supplied grid needs 10).',
                   status='IDENTIFIED (McLean 2018; Beylkin-Monzon 2005, 2010) + computed', worst_error_over_eps=fl(worst), all_weights_positive=positive,
                   fit_coefficients=[fl(c) for c in cf], fit_rmse_terms=fl(rmse), step_over_pi2_per_log={str(e): fl(q) for e, q in zip(EPSS, ratio)}, terms_per_log_horizon_times_h={str(e): fl(q) for e, q in zip(EPSS, slope)},
                   example_terms={'alpha=1.5,T=120,eps=1e-3': len(trapezoid(1.5, 120, 1e-3)[0]), 'alpha=1,T=10000,eps=1e-4': Ls[(1.0, 10000, 1e-4)]})


# ================================================================================================ CC
def free_error(alpha, T, d, kernel=None):
    t, w = sample(T); y = (1 + t) ** -alpha if kernel is None else kernel(t)
    x0 = np.log(np.geomspace(1 / (20 * T), 20.0, d))
    def res(x):
        A = np.exp(-np.outer(t, np.exp(x))) * w[:, None]; c, _ = nnls(A, y * w, maxiter=10000); return A @ c - y * w
    s = least_squares(res, x0, method='trf', bounds=(math.log(1e-9), math.log(1e4)), max_nfev=60 * d, xtol=1e-10, ftol=1e-12)
    A = np.exp(-np.outer(t, np.exp(s.x))); c, _ = nnls(A * w[:, None], y * w, maxiter=10000)
    return rel_l2(y * w, (A @ c) * w), np.exp(s.x), c


def CC(D):
    out, budget = {}, {}
    for a in (1.0, 1.5):
        for T in (10, 100, 1000, 10000, 100000, 1000000):
            errs = [free_error(a, T, d)[0] for d in range(1, 10)]
            out[f'{a}/{T}'] = [fl(e) for e in errs]
            for eps in (1e-2, 1e-3):
                budget[(a, T, eps)] = next((d for d, e in zip(range(1, 10), errs) if e <= eps), 99)   # 99: not reached
    grid = {(a, T, eps): min_dim(lambda t: (1 + t) ** -a, T, eps) for a in (1.0, 1.5) for T in (10, 100, 1000, 10000, 100000, 1000000) for eps in (1e-2, 1e-3)}
    flat = all(budget[(a, 10000, e)] == budget[(a, 100000, e)] == budget[(a, 1000000, e)] for a in (1.0, 1.5) for e in (1e-2, 1e-3))
    growing = all(grid[(a, 1000000, e)] > grid[(a, 10000, e)] for a in (1.0, 1.5) for e in (1e-2, 1e-3))
    smaller = min(grid[k] / budget[k] for k in budget)
    ok = flat and growing and smaller >= 1.5 and all(grid[k] == D[k] for k in grid if k in D)
    must(ok, 'CC')
    R['CC'] = dict(claim='The horizon growth is an artifact of the grid. The supplied rates are fixed at geomspace(1/(20T), 20, d), '
                         'so a larger horizon spreads the same number of modes thinner. With the rates free (variable '
                         'projection, nonnegative weights), in the supplied norm, the budget at eps = 1e-2 and 1e-3 is equal at '
                         'T = 1e4, 1e5 and 1e6 for alpha = 1 and 1.5: it stops growing. It is also 2 to 3 times smaller. The '
                         'norm weights each log-decade by the size of K there, and the far tail is small; this matches the '
                         'theorem that 1/x is approximated uniformly on all of [1, infinity) by finitely many exponentials '
                         '(Braess-Hackbusch 2005). Canary: on the supplied grid the budget keeps growing to T = 1e6.',
                   status='computed; uniform approximation on [1, inf) IMPORTED', free_rate_error_by_d={k: v for k, v in out.items()},
                   budget_free={f'alpha={a},T={T},eps={e}': v for (a, T, e), v in budget.items()},
                   budget_supplied_grid={f'alpha={a},T={T},eps={e}': v for (a, T, e), v in grid.items()}, min_ratio_grid_to_free=fl(smaller))


# ================================================================================================ CD
def CD():
    res = {}
    for T in (100, 10000, 1000000):
        e, r, c = free_error(1.0, T, 6); tt = np.geomspace(1e-3, T, 3000); y = (1 + tt) ** -1.0
        rel = float(np.max(np.abs(np.exp(-np.outer(tt, r)) @ c / y - 1))); res[T] = dict(supplied_norm=fl(e), pointwise_relative=fl(rel))
    ok = all(v['supplied_norm'] < 1e-3 for v in res.values()) and res[1000000]['pointwise_relative'] > 10 * res[100]['pointwise_relative'] and res[1000000]['pointwise_relative'] > 0.5
    must(ok, 'CD')
    R['CD'] = dict(claim='The norm decides. The six-mode free-rate completion passes the supplied norm below 1e-3 at T = 1e2, 1e4 and 1e6, '
                         'while its pointwise relative error grows from 1 per cent at T = 1e2 to 100 per cent at T = 1e4: the tail is '
                         'not captured. A budget that must grow with T belongs to the pointwise relative norm, and there it is '
                         'the published law of group CB. Which norm is physical depends on what is predicted; the supplied '
                         'battery fixed the norm in which the claimed growth does not hold.',
                   status='computed', by_horizon={str(k): v for k, v in res.items()})


# ================================================================================================ CE
def CE():
    K = lambda t: np.exp(-np.sqrt(t))
    dens = lambda s: s ** -1.5 * math.exp(-1 / (4 * s)) / (2 * math.sqrt(math.pi))       # Bernstein density of e^(-sqrt t)
    cm = max(abs(quad(lambda s: math.exp(-s * t) * dens(s), 0, np.inf, limit=400)[0] - math.exp(-math.sqrt(t))) for t in (0.01, 0.5, 3.0, 40.0))
    cells = [(T, e) for T in (10, 100, 1000, 10000) for e in (1e-2, 1e-3)]
    capped = {f'T={T},eps={e}': min_dim(K, T, e, cap=20.0) for T, e in cells}
    opened = {f'T={T},eps={e}': min_dim(K, T, e, cap=1e7) for T, e in cells}
    power = {f'T={T},eps={e}': min_dim(lambda t: (1 + t) ** -1.5, T, e, cap=20.0) for T, e in cells}
    at3 = [k for k in capped if k.endswith('eps=0.001')]
    ok = cm < 1e-8 and all(capped[k] == 97 for k in at3) and max(opened[k] for k in at3) <= 25 and all(opened[k] > power[k] for k in at3)
    must(ok, 'CE')
    R['CE'] = dict(claim='The shape attack is an artifact of the rate cap. e^(-sqrt t) is completely monotone: its Bernstein density '
                         's^(-3/2) e^(-1/(4s))/(2 sqrt pi) reproduces it to 1e-8. Its square-root cusp at t = 0 needs rates far '
                         'above 20, which the supplied grid forbids, and the log-time sampling down to t = 1e-5 makes that cusp '
                         'dominate. At eps = 1e-3 the capped search never succeeds and records its limit (97) at every horizon; '
                         'that is where the mean of 78 and the RMSE of 74.9 come from. With rates up to 1e7 the budget is 16 to 22. '
                         'The stretched exponential does need more modes than the power law (8 to 14 on its grid), so a shape '
                         'difference exists; its size in the supplied attack is set by the cap. At eps = 1e-2 the capped grid '
                         'is even cheaper than the open one: the budget follows the grid in both directions.',
                   status='computed', bernstein_check=f'< 1e-8' if cm < 1e-8 else fl(cm), budget_cap_20=capped, budget_cap_1e7=opened, budget_power_law_1_5=power)


# ================================================================================================ CF
def simulate(Tn, L, kern, amp=0.012):
    c = L // 2; U = [np.eye(1, L, c).ravel()]
    for t in range(Tn):
        nxt = .5 * (np.roll(U[-1], 1) + np.roll(U[-1], -1))
        for j in range(1, t + 2):
            old = U[-j]; nxt = nxt + amp * kern(j) * (np.roll(old, 1) - 2 * old + np.roll(old, -1))
        U.append(nxt)
    return np.array(U)


def CF():
    rng = np.random.default_rng(SEED); Tn, L = 120, 401
    exact = simulate(Tn, L, lambda j: (1 + j) ** -1.5)
    signs = rng.choice([-1.0, 1.0], size=Tn + 2) * rng.random(Tn + 2) * 3
    wild = simulate(Tn, L, lambda j: signs[j])
    none = simulate(Tn, L, lambda j: 0.0)
    out = lambda U: max(float(np.max(np.abs(U[t][np.abs(np.arange(L) - L // 2) > t]), initial=0.0)) for t in range(Tn + 1))
    err_none = float(np.linalg.norm(none - exact) / np.linalg.norm(exact))
    # the supplied ten-mode completion against a four-mode completion with free rates
    e10 = None
    t, w = sample(120); y = (1 + t) ** -1.5
    for d in range(1, 30):
        A, r10 = design(t, d, 120); c10, _ = nnls(A * w[:, None], y * w, maxiter=10000)
        if rel_l2(y * w, (A @ c10) * w) <= 1e-3:
            break
    sup = simulate(Tn, L, lambda j: float(np.sum(c10 * np.exp(-r10 * j))))
    e4, r4, c4 = free_error(1.5, 120, 4); four = simulate(Tn, L, lambda j: float(np.sum(c4 * np.exp(-r4 * j))))
    err10 = float(np.linalg.norm(sup - exact) / np.linalg.norm(exact)); err4 = float(np.linalg.norm(four - exact) / np.linalg.norm(exact))
    ok = out(exact) == 0 and out(wild) == 0 and out(none) == 0 and err_none > 0.1 and d == 10 and abs(err10 - 3.084e-4) < 2e-6 and e4 <= 1e-3 and err4 < 1e-3
    must(ok, 'CF')
    R['CF'] = dict(claim='Frontier preservation is built in. Every update is a nearest-neighbour stencil, so the support grows by '
                         'at most one cell per step whatever the kernel: a random signed kernel of size up to 3, neither '
                         'passive nor a completion, keeps the support in the cone exactly. Passivity plays no part. The memory '
                         'matters inside the cone (canary: dropping it changes the trajectory by 50 per cent), and the supplied '
                         'ten-mode completion reproduces it to 3.08e-4. A four-mode completion with free rates passes the same '
                         'kernel gate and reproduces the trajectory to the error given below: the predicted d = 10 is not the '
                         'minimal number of hidden modes for this dynamics, it is the minimal number on the supplied grid.',
                   status='computed', outside_cone={'algebraic': out(exact), 'random signed': out(wild), 'no memory': out(none)}, trajectory_error_without_memory=fl(err_none),
                   supplied_completion=dict(modes=d, trajectory_error=fl(err10)), free_completion=dict(modes=4, kernel_error=fl(e4), trajectory_error=fl(err4)))


# ================================================================================================ CG
def CG(D):
    rows = [(a, T, e, D[(a, T, e)]) for a in ALPHAS for T in TS for e in EPSS]
    feat = lambda a, T, e: [1, math.log1p(T), math.log(1 / e), math.log1p(T) * math.log(1 / e), math.log1p(a), math.log(1 / e) * math.log1p(a)]
    X = np.array([feat(a, T, e) for a, T, e, _ in rows]); y = np.array([d for *_, d in rows], float)
    def split(train):
        c = np.linalg.lstsq(X[train], y[train], rcond=None)[0]; p = X @ c
        return float(np.sqrt(np.mean((p[~train] - y[~train]) ** 2))), float(np.max(np.abs(p[~train] - y[~train])))
    inter = np.array([i % 3 != 0 for i in range(len(rows))]); horizon = np.array([T <= 1000 for _, T, _, _ in rows]); expo = np.array([a <= 1.25 for a, _, _, _ in rows])
    res = {k: split(m) for k, m in (('interleaved (supplied)', inter), ('train T <= 1000, test T >= 3000', horizon), ('train alpha <= 1.25, test alpha >= 1.5', expo))}
    ok = abs(res['interleaved (supplied)'][0] - 0.355) < 0.01 and all(0.355 < v[0] < 0.6 for k, v in res.items() if k != 'interleaved (supplied)')
    must(ok, 'CG')
    R['CG'] = dict(claim='The held-out test interpolates. The supplied split takes every third cell, so each test cell has trained '
                         'neighbours in T and eps. Trained on T <= 1000 and tested on T = 3000 and 10000, or trained on alpha <= '
                         '1.25 and tested on alpha = 1.5 and 2, it degrades only modestly, to RMSE 0.44 with worst miss 1.1 modes. '
                         'This attack does not break the predictor: it extrapolates the supplied grid well. What it predicts '
                         'is the grid budget (groups CC, CF). Canary: the interleaved split reproduces the supplied RMSE 0.355.',
                   status='computed', rmse_and_worst={k: [fl(v[0]), fl(v[1])] for k, v in res.items()})


if __name__ == '__main__':
    D = CA(); print('CA', flush=True)
    CB(); print('CB', flush=True)
    CC(D); print('CC', flush=True)
    CD(); print('CD', flush=True)
    CE(); print('CE', flush=True)
    CF(); print('CF', flush=True)
    CG(D); print('CG', flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(open(os.path.abspath(__file__), 'rb').read()).hexdigest()
    json.dump(out, open(os.path.join(HERE, 'rg_completion_attack_results.json'), 'w'), indent=1, sort_keys=True)
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
