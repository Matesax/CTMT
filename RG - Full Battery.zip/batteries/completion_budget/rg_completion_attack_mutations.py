#!/usr/bin/env python3
"""Mutation suite for rg_completion_attack.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. Under one minute.

    python3 -I rg_completion_attack_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('CA', 'a different rate grid presented as the supplied one', "rates = np.geomspace(1 / (20 * T), cap, max(d, 1))", "rates = np.geomspace(1 / (10 * T), cap, max(d, 1))"),
    ('CB', 'trapezoid step too coarse for the tolerance', "while 2 * math.exp(float(np.real(loggamma(alpha + 2j * math.pi / h))) - float(loggamma(alpha))) > target:",
     "while 2 * math.exp(float(np.real(loggamma(alpha + 2j * math.pi / h))) - float(loggamma(alpha))) > 300 * target:"),
    ('CB', 'lower truncation without the horizon', "Y = math.log1p(T) + math.log(", "Y = math.log(10.0) + math.log("),
    ('CC', 'free rates frozen at the supplied grid', "A = np.exp(-np.outer(t, np.exp(s.x))); c, _ = nnls(", "A = np.exp(-np.outer(t, np.exp(x0))); c, _ = nnls("),
    ('CD', 'pointwise relative error replaced by the supplied norm', "rel = float(np.max(np.abs(np.exp(-np.outer(tt, r)) @ c / y - 1)))", "rel = e"),
    ('CE', 'a Bernstein density with the wrong power', "s ** -1.5 * math.exp(-1 / (4 * s))", "s ** -1.4 * math.exp(-1 / (4 * s))"),
    ('CF', 'a stencil that reaches two cells', "nxt = .5 * (np.roll(U[-1], 1) + np.roll(U[-1], -1))", "nxt = .5 * (np.roll(U[-1], 2) + np.roll(U[-1], -1))"),
    ('CG', 'a predictor without the cross term', "math.log1p(T) * math.log(1 / e), math.log1p(a), math.log(1 / e) * math.log1p(a)]", "0.0, math.log1p(a), math.log(1 / e) * math.log1p(a)]"),
]


def main():
    base = open(os.path.join(HERE, 'rg_completion_attack.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_completion_attack.py'), 'w').write(base.replace(old, new))
            shutil.copytree(os.path.join(HERE, 'supplied'), os.path.join(tmp, 'supplied'))
            run = subprocess.run([sys.executable, '-I', 'rg_completion_attack.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_completion_attack_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
