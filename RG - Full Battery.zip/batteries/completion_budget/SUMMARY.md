# RG – Completion Budget: attack on the supplied predictor

**Verdict: no novelty locks.** The bilinear law d ≈ A + B·log(1+T)·log(1/ε) for positive exponential completions of algebraic memory is the leading term of a published, a priori construction. In the norm the supplied battery uses, the claimed growth with the horizon does not hold once the relaxation rates are free; it comes from a rate grid that is tied to T. Frontier preservation is built into the stencil. The shape diagnosis is partly real, and its size is set by a rate cap. A novelty paper is not justified.

Battery: `rg_completion_attack.py`, seed 20261119, 7 groups (CA–CG), each with a canary; byte-identical on rerun; 8/8 mutations caught by the battery's own failure reports (`rg_completion_attack_mutations.py`; a crashed run is reported as a defect, not as a catch). The supplied script and results are under `supplied/`, and all 210 supplied budgets are recomputed exactly (CA).

## Claim by claim

| Supplied claim | Finding | Group |
|---|---|---|
| d grows as log(1+T)·log(1/ε): a new pre-fit predictor | Published. McLean's trapezoid construction for t^(−β) (2018) fixes step and truncation from (α, T, ε) before any fit, with positive weights. On all 210 cells it meets pointwise relative error ε (worst 0.52 ε). Its step is h ≈ π²/log(3/ε), times a slowly varying factor 0.70–0.79, and each factor e in 1+T adds 1/h terms. So the term count is [log(1+T) + log(1/ε)/α + O(1)]·log(1/ε)/π² to leading order. Related: Beylkin–Monzón (2005, 2010); sum-of-exponentials kernels in fast fractional solvers | CB |
| "The effective dimension must grow with horizon; no fixed finite model remains adequate" | False in the supplied norm. With free rates (variable projection, nonnegative weights) the budget at ε = 10⁻², 10⁻³ is the same at T = 10⁴, 10⁵, 10⁶ (α = 1: 3 and 6 modes; α = 1.5: 3 and 4). It is 2–3× below the supplied grid, which keeps growing to 13–18. This matches uniform approximation of 1/x on all of [1, ∞) by finitely many exponentials (Braess–Hackbusch 2005) | CC |
| Same | Growth with T is a property of the pointwise relative norm. The free six-mode completion passes the supplied norm below 10⁻³ at T = 10², 10⁴, 10⁶, but its pointwise relative error rises from 1% to 100%. In that norm the growth is the published law of CB | CD |
| Worked example: d = 10 predicted and minimal, d − 1 fails | 10 is minimal only on the supplied grid. A 4-mode free completion passes the same kernel gate (8.9×10⁻⁴) and reproduces the full Volterra trajectory better: 2.05×10⁻⁴ against 3.08×10⁻⁴ | CF |
| Completion preserves the frontier | Built in. Every update is a nearest-neighbour stencil, so a random signed kernel, which is neither passive nor a completion, also keeps the support exactly inside the cone. Passivity plays no part. Memory does matter inside the cone: dropping it changes the trajectory by 50% | CF |
| Shape diagnosis: stretched exponential fails decisively (RMSE 74.9, mean d 78) | Mostly an artifact of the rate cap 20. e^(−√t) is completely monotone (its Bernstein density is checked to 10⁻⁸). Its cusp at t = 0 needs rates above 20. At ε = 10⁻³ the capped search never succeeds and records its limit 97 at every horizon, which produces the mean and the RMSE. With rates up to 10⁷ it needs 16–22 modes, still more than the power law (8–14), so a moderate shape difference is real. At ε = 10⁻² the capped grid is even cheaper than the open one | CE |
| Held-out R² 0.986 | The supplied split interleaves cells. Trained on T ≤ 1000 and tested on T ≥ 3000, or on α ≤ 1.25 and tested on α ≥ 1.5, RMSE rises only to 0.44 (worst miss 1.1 modes). This attack does not break the fit, but what it fits is the grid budget (CC, CF) | CG |

## What holds

- A positive completion exists with an a priori budget of the bilinear form (McLean; Beylkin–Monzón). The weights of these constructions are positive, so the passivity requirement adds no new restriction.
- Whether the budget must grow with the horizon depends on the norm: pointwise relative error, yes; error weighted by the size of the kernel, no.
- A local stencil keeps the cone whatever the kernel. The frontier and the memory budget are independent because the frontier never depended on the kernel.

## Data

No natural-data test is possible that would distinguish this from known mathematics. On the empirical side, how many relaxation rates can be resolved from noisy finite records is the classical resolution limit of Laplace inversion (Bertero, Boccacci and Pike 1982; McWhirter and Pike 1978).

## Sources

- W. McLean, Exponential sum approximations for t^(−β), in *Contemporary Computational Mathematics – A Celebration of the 80th Birthday of Ian Sloan*, Springer, 2018; arXiv:1606.00123.
- G. Beylkin, L. Monzón, On approximation of functions by exponential sums, Appl. Comput. Harmon. Anal. 19 (2005) 17; Approximation by exponential sums revisited, Appl. Comput. Harmon. Anal. 28 (2010) 131.
- D. Braess, W. Hackbusch, Approximation of 1/x by exponential sums in [1, ∞), IMA J. Numer. Anal. 25 (2005) 685.
- M. Bertero, P. Boccacci, E. R. Pike, On the recovery and resolution of exponential relaxation rates from experimental data, Proc. R. Soc. Lond. A 383 (1982) 15.
- J. G. McWhirter, E. R. Pike, On the numerical inversion of the Laplace transform and similar Fredholm integral equations of the first kind, J. Phys. A 11 (1978) 1729.
