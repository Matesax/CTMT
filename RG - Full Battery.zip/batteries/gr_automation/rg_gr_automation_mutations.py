#!/usr/bin/env python3
"""Mutation suite for rg_gr_automation.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. A few minutes.

    python3 -I rg_gr_automation_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('GA', 'capacity 2 at full rank', 'abs(cap(k) - 1) < 1e-12', 'abs(cap(k) - 2) < 1e-12'),
    ('GD', 'wrong growth rate', 'abs(g_ - math.log(2) / (2 * math.pi)) < 0.01', 'abs(g_ - math.log(3) / (2 * math.pi)) < 0.01'),
    ('GF', 'health norm off by 10 per cent', 'abs(normH / closed - 1) < 2e-3', 'abs(normH / closed - 1.1) < 2e-3'),
    ('GH', 'Moebius sign flipped', 'abs(moebius + 1) < 1e-3', 'abs(moebius - 1) < 1e-3'),
    ('GL', 'hole dimension 3', 'hole_dim == 4', 'hole_dim == 3'),
    ('GN', 'energy order swapped', 'E_sh < E_un < E_pk', 'E_un < E_sh < E_pk'),
    ('GO', 'Birkhoff rank 2', 'rank == 1 and pcs[2] > 20 * pcs[0]', 'rank == 2 and pcs[2] > 20 * pcs[0]'),
    ('GP', 'two data values', 'free_centre == data_values == 3', 'free_centre == data_values == 2'),
]


def main():
    base = open(os.path.join(HERE, 'rg_gr_automation.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            for f in os.listdir(HERE):                                  # helpers and supplied data
                if f not in ('rg_gr_automation.py', 'rg_gr_automation_mutations.py', 'rg_gr_automation_results.json'):
                    (shutil.copytree if os.path.isdir(os.path.join(HERE, f)) else shutil.copy)(os.path.join(HERE, f), os.path.join(tmp, f))
            open(os.path.join(tmp, 'rg_gr_automation.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_gr_automation.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_gr_automation_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
