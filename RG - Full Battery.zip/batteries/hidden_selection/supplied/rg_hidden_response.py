#!/usr/bin/env python3
"""Passive hidden-interface dynamics: conditional prediction, synthetic tests only.
No new GR solution, no RG uniqueness claim. numpy/scipy required.
"""
import numpy as np,json
from scipy.linalg import expm
from scipy.integrate import solve_ivp
from pathlib import Path
OUT=Path(__file__).resolve().parent
# Dimensionless variables. Hidden state q, boundary drive y, reaction f.
# M qdd + Gamma qd + K q = g y ; f = g^T q - k0 y.
M=np.diag([1.,1.3]);G=np.diag([.22,.35]);K=np.array([[2.8,.18],[.18,6.2]]);g=np.array([.55,.38]);k0=.65
m=2
A=np.block([[np.zeros((m,m)),np.eye(m)],[-np.linalg.solve(M,K),-np.linalg.solve(M,G)]])
B=np.r_[np.zeros(m),np.linalg.solve(M,g)]
C=np.r_[g,np.zeros(m)]
def H(w):return complex(-k0+g@np.linalg.solve(K-w*w*M+1j*w*G,g))
def main():
 rng=np.random.default_rng(17123)
 # independent matrix exponential convolution vs full ODE under untrained chirp drive
 dt=.002; T=30.;t=np.arange(0,T+dt/2,dt)
 y=lambda s:.3*np.sin(.45*s+.035*s*s)+.1*np.sin(3.4*s)
 def rhs(s,z):return A@z+B*y(s)
 sol=solve_ivp(rhs,[0,T],np.zeros(4),t_eval=t,rtol=1e-10,atol=1e-12)
 f=sol.y.T@C-k0*np.array([y(s) for s in t])
 # exact ZOH discrete completion, compare with independent ZOH ODE on shorter window
 aug=np.zeros((5,5));aug[:4,:4]=A;aug[:4,4]=B
 E=expm(aug*dt);Ad=E[:4,:4];Bd=E[:4,4]
 z=np.zeros(4);fz=[]
 for s in t:
  fz.append(C@z-k0*y(s));z=Ad@z+Bd*y(s)
 rel=float(np.linalg.norm(np.array(fz)-f)/np.linalg.norm(f))
 # convolution from independently evaluated impulse kernel via FFT, trapezoid quadrature
 from scipy.signal import fftconvolve
 from scipy.sparse.linalg import expm_multiply
 impulse=expm_multiply(A,B,start=0,stop=T,num=len(t))@C
 yy=np.array([y(s) for s in t]); conv=dt*fftconvolve(impulse,yy)[:len(t)]-k0*yy
 conv_err=float(np.linalg.norm(conv-f)/np.linalg.norm(f))
 # causal transfer sign: exp(+i omega t), passive work = -f ydot.
 ws=np.geomspace(.03,15,500);hh=np.array([H(w) for w in ws]);loss=-ws*hh.imag
 schur=float(k0-g@np.linalg.solve(K,g))
 # Full energy identity on autonomous visible oscillator coupled to hidden states.
 # xdd + (Omega^2+k0)x-g^T q=0; hidden eq as above.
 Om=.8
 def full(s,z):
  x,v=z[:2];q=z[2:4];u=z[4:6]
  return np.r_[v,-(Om*Om+k0)*x+g@q,u,np.linalg.solve(M,g*x-K@q-G@u)]
 tt=np.linspace(0,50,5001);z0=np.array([.7,0,.1,-.05,0,.2])
 so=solve_ivp(full,[0,50],z0,t_eval=tt,rtol=1e-10,atol=1e-12)
 zz=so.y.T;x=zz[:,0];v=zz[:,1];q=zz[:,2:4];u=zz[:,4:6]
 energy=.5*v*v+.5*(Om*Om+k0)*x*x+.5*np.einsum('ti,ij,tj->t',u,M,u)+.5*np.einsum('ti,ij,tj->t',q,K,q)-x*(q@g)
 from scipy.integrate import cumulative_trapezoid
 dissip=np.einsum('ti,ij,tj->t',u,G,u)
 energy_res=float(np.max(np.abs(energy-energy[0]+cumulative_trapezoid(dissip,tt,initial=0))))
 # Hidden-state ambiguity: same drive and parameters, different q0 changes f.
 h0=np.array([.2,-.1,0,0]); delta=expm_multiply(A,h0,start=0,stop=5,num=501)@C
 # Conditional frequency prediction from low-frequency calibration of SINGLE mode.
 # h(w)=-k0+a/(Omega_h^2-w^2+i gamma w); a=g^2/m.
 a=.49;oh2=3.24;gam=.27;kk=.8
 def hs(w):return -kk+a/(oh2-w*w+1j*gam*w)
 # independently calibrated k0; two exact complex calibration points determine a,oh2,gamma
 train=np.array([.35,.8]); inv=1/np.array([hs(w)+kk for w in train])
 # Re inv=oh2/a-w^2/a ; Im inv=gamma*w/a
 slope,inter=np.polyfit(train**2,inv.real,1);ahat=-1/slope;ohhat=inter*ahat;ghat=float(np.mean(inv.imag/train)*ahat)
 blind=np.array([1.1,1.6,1.8,2.2,3.]);pred=-kk+ahat/(ohhat-blind**2+1j*ghat*blind)
 ferr=float(np.max(np.abs(pred-np.array([hs(w) for w in blind]))))
 # Model-class attack: second hidden mode invalidates single-mode extrapolation.
 def hm(w):return hs(w)+.18/(7.1-w*w+1j*.19*w)
 inv2=1/np.array([hm(w)+kk for w in train]);sl,it=np.polyfit(train**2,inv2.real,1);aa=-1/sl;oo=it*aa;gg=float(np.mean(inv2.imag/train)*aa)
 bad=-kk+aa/(oo-blind**2+1j*gg*blind)
 attack=float(np.linalg.norm(bad-np.array([hm(w) for w in blind]))/np.linalg.norm([hm(w) for w in blind]))
 gates={'positive_energy_schur':schur>0,'stable_hidden_poles':np.max(np.linalg.eigvals(A).real)<0,'passive_spectral_loss':np.min(loss)>-1e-12,'independent_drive_prediction':rel<.01,'convolution_prediction':conv_err<.002,'energy_balance':energy_res<1e-5,'conditional_blind_frequency':ferr<1e-10,'extra_mode_attack_detected':attack>.05,'hidden_initial_state_matters':np.max(np.abs(delta))>.01}
 R={'scope':'dimensionless passive boundary effective model, not derived from RG or Einstein constraints','formula':'f(t)=-k0*y(t)+C exp(A t) z0+integral_0^t C exp(A(t-s)) B y(s) ds','frequency_formula':'H(omega)=-k0+g^T(K-omega^2 M+i omega Gamma)^(-1)g','schur_margin':schur,'max_hidden_pole_real':float(np.max(np.linalg.eigvals(A).real)),'zoh_drive_relative_error':rel,'convolution_relative_error':conv_err,'energy_balance_max_error':energy_res,'min_spectral_loss':float(loss.min()),'calibrated_single_mode':{'a':float(ahat),'omega_squared':float(ohhat),'gamma':ghat,'blind_max_complex_error':ferr},'two_mode_attack_relative_error':attack,'initial_state_reaction_difference_max':float(np.max(np.abs(delta))),'gates':gates,'all_pass':all(gates.values()),'novel_RG_dynamics_locked':False}
 (OUT/'rg_hidden_response_results.json').write_text(json.dumps(R,indent=2,default=lambda o:bool(o) if isinstance(o,np.bool_) else float(o)))
 print(json.dumps(R,indent=2,default=lambda o:bool(o) if isinstance(o,np.bool_) else float(o)))
if __name__=='__main__':main()
