#!/usr/bin/env python3
"""RG - Selection of the Hidden Response: what can RG's principles select in H(w) = -k0 + g^T (K - w^2 M + i w G)^-1 g?

  SA reproduction of the supplied run
  SB the class is selected: causality (the cone), balance with passivity, and reciprocity give a response whose poles
     lie in the upper half-plane, whose loss -w Im H is nonnegative, and whose real and imaginary parts obey the
     Kramers-Kronig relation; canary: a negative damping eigenvalue breaks passivity and stability
  SC the member is not selected: (i) scale: M -> M/s^2, G -> G/s maps an admissible model to an admissible one with
     H_s(w) = H(w/s), so no principle can fix a frequency (the no-internal-unit theorem, L94); (ii) shape: G -> l G keeps
     every principle and changes the quality factor, so not even a dimensionless ratio is fixed
  SD the order is selected by records: the Loewner matrix of sampled responses has rank 2d for d hidden modes; from ten
     training frequencies it detects the second mode that defeated the single-mode extrapolation in the supplied
     attack, before any blind frequency is used; canary: the one-mode response gives rank 2
  SE what remains: parameters are anchors; a d-mode response needs 3d + 1 real numbers from measurement, and with them
     prediction at withheld frequencies is exact (the supplied conditional prediction)

Deterministic. Seed 20261124. Writes rg_selection_attack_results.json.
Run:  python3 -I rg_selection_attack.py
"""
import hashlib, json, os, subprocess, sys
import numpy as np
from scipy.integrate import quad

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 20261124
R, FAILS = {}, []
M0 = np.diag([1., 1.3]); G0 = np.diag([.22, .35]); K0 = np.array([[2.8, .18], [.18, 6.2]]); g0 = np.array([.55, .38]); k00 = .65


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.8g}')


def below(v, b):
    return f'< {b:g}' if abs(v) < b else fl(v)


def H(w, M=M0, G=G0, K=K0, g=g0, k0=k00):
    return complex(-k0 + g @ np.linalg.solve(K - w * w * M + 1j * w * G, g))


def poles(M, G, K):
    m = len(K); A = np.block([[np.zeros((m, m)), np.eye(m)], [-np.linalg.solve(M, K), -np.linalg.solve(M, G)]])
    return np.linalg.eigvals(A)


def SA():
    sup = os.path.join(HERE, 'supplied')
    r = subprocess.run([sys.executable, '-I', 'rg_hidden_response.py'], cwd=sup, capture_output=True, text=True, timeout=600)
    got = json.load(open(os.path.join(sup, 'rg_hidden_response_results.json')))
    ok = r.returncode == 0 and got['all_pass'] and got['novel_RG_dynamics_locked'] is False and abs(got['two_mode_attack_relative_error'] - 0.26336) < 1e-4
    must(ok, 'SA')
    R['SA'] = dict(claim='The supplied run is reproduced: all nine checks pass, the single-mode blind error is 3.7e-15, the second-mode '
                         'attack raises it to 26.3 per cent, and the supplied verdict is "novel RG dynamics not locked".',
                   status='computed', two_mode_attack=fl(got['two_mode_attack_relative_error']), blind_error=below(got['calibrated_single_mode']['blind_max_complex_error'], 1e-13))


def kk_residual(Hf, w0s, cut=400.0):
    """Kramers-Kronig for chi(w) = H(w) - H(inf), time dependence e^{+iwt} (poles in the upper half-plane):
    Re chi(w0) = -(2/pi) P int_0^inf w Im chi(w)/(w^2 - w0^2) dw."""
    Hinf = Hf(1e9).real; out = []
    for w0 in w0s:
        f = lambda w: (w * Hf(w).imag) / (w + w0)
        val = quad(f, 0, cut, weight='cauchy', wvar=w0, limit=800)[0]          # P int f/(w - w0)
        tail = quad(lambda w: w * Hf(w).imag / (w * w - w0 * w0), cut, np.inf, limit=200)[0]
        out.append(abs((Hf(w0).real - Hinf) + (2 / np.pi) * (val + tail)))
    return max(out)


def SB():
    ws = np.geomspace(0.01, 30, 2000)
    loss = min(-w * H(w).imag for w in ws); stab = max(poles(M0, G0, K0).real)
    sym = all(np.allclose(X, X.T) for X in (M0, G0, K0))
    kk = kk_residual(H, [0.5, 1.3, 2.0, 4.0])
    # canary: one negative damping eigenvalue
    Gbad = np.diag([.22, -.35]); lossb = min(-w * H(w, G=Gbad).imag for w in ws); stabb = max(poles(M0, Gbad, K0).real)
    ok = loss >= 0 and stab < 0 and sym and kk < 1e-6 and lossb < 0 and stabb > 0
    must(ok, 'SB')
    R['SB'] = dict(claim='The class is selected. Causality (finite propagation, the cone) puts every pole of the response in the stable '
                         'half-plane (largest real part -0.11); balance with passivity makes the absorbed power -w Im H nonnegative '
                         'at every frequency; reciprocity makes M, G, K symmetric. The response then obeys the Kramers-Kronig '
                         'relation, checked by principal-value integration at four frequencies. Canary: one negative damping '
                         'eigenvalue makes the loss negative and a pole unstable. This is the class of passive, causal, reciprocal '
                         'linear responses (positive-real functions), which linear-response theory already fixes.',
                   status='computed; IDENTIFIED (Kramers-Kronig; positive-real functions)', min_loss=fl(loss), max_pole_real=fl(stab),
                   kramers_kronig_residual=below(kk, 1e-6), canary_min_loss=fl(lossb), canary_max_pole_real=fl(stabb))


def SC():
    ws = np.geomspace(0.01, 30, 800); out = {}
    for s in (0.5, 2.0):
        Ms, Gs = M0 / s ** 2, G0 / s
        same = max(abs(H(w, M=Ms, G=Gs) - H(w / s)) for w in (0.3, 1.1, 2.7))
        adm = min(-w * H(w, M=Ms, G=Gs).imag for w in ws) >= 0 and max(poles(Ms, Gs, K0).real) < 0
        out[f'scale {s}'] = dict(identity=same, admissible=bool(adm), differs_at_1_8=abs(H(1.8, M=Ms, G=Gs) - H(1.8)))
    for l in (0.3, 3.0):
        Gl = l * G0; adm = min(-w * H(w, G=Gl).imag for w in ws) >= 0 and max(poles(M0, Gl, K0).real) < 0
        out[f'damping x{l}'] = dict(admissible=bool(adm), differs_at_1_8=abs(H(1.8, G=Gl) - H(1.8)))
    ok = all(v['admissible'] for v in out.values()) and all(v['differs_at_1_8'] > 0.01 for v in out.values()) \
        and all(v['identity'] < 1e-12 for k, v in out.items() if k.startswith('scale'))
    must(ok, 'SC')
    R['SC'] = dict(claim='The member is not selected. Scale: M -> M/s^2 and G -> G/s give H_s(w) = H(w/s) exactly, and H_s satisfies every '
                         'principle of SB; s = 1/2 and 2 differ from the original at w = 1.8. A principle that fixed a resonance '
                         'frequency would fix a unit, which the no-internal-unit theorem (L94) excludes. Shape: multiplying the '
                         'damping by 0.3 or 3 keeps every principle and changes the quality factor, so not even a dimensionless ratio '
                         'is fixed. Every admissible response is one of a continuum that the principles cannot tell apart.',
                   status='PROVED (substitution) + computed', family={k: {a: (below(b, 1e-12) if a == 'identity' else (b if isinstance(b, bool) else fl(b))) for a, b in v.items()} for k, v in out.items()})


def loewner_rank(Hf, mu, lam, tol=1e-9):
    Hm = np.array([Hf(x) for x in mu]); Hl = np.array([Hf(x) for x in lam])
    L = (Hm[:, None] - Hl[None, :]) / (mu[:, None] - lam[None, :])
    s = np.linalg.svd(L, compute_uv=False); return int(np.sum(s > tol * s[0])), [fl(x / s[0]) for x in s[:6]]


def SD():
    # the supplied single-mode and two-mode responses (k0 known, subtracted)
    hs = lambda w: .49 / (3.24 - w * w + 1j * .27 * w)
    hm = lambda w: hs(w) + .18 / (7.1 - w * w + 1j * .19 * w)
    train = np.linspace(0.2, 0.9, 10)                                # low band only, as in the supplied calibration
    mu, lam = train[0::2], train[1::2]
    r1, s1 = loewner_rank(hs, mu, lam); r2, s2 = loewner_rank(hm, mu, lam)
    ok = r1 == 2 and r2 == 4
    must(ok, 'SD')
    R['SD'] = dict(claim='The order is selected by records. The Loewner matrix of sampled responses, the frequency-domain counterpart of '
                         'the Hankel matrix of RG\'s minimal completion, has rank 2d for d hidden modes. From ten training frequencies '
                         'in the supplied calibration band (0.2 to 0.9) it gives rank 2 for the single-mode response and rank 4 for '
                         'the two-mode response, so the second mode that defeated the single-mode extrapolation (26 per cent) is '
                         'detected before any blind frequency is used. Canary: the single-mode response gives rank 2. The method is '
                         'the Loewner framework of model reduction.',
                   status='computed; IDENTIFIED (Mayo-Antoulas 2007)', rank_single=r1, rank_two=r2, singular_values_two_mode=s2)


def SE():
    # with the order known, 3d + 1 real anchors fix the response; the supplied 1-mode case needs 3 (k0 given separately)
    hs = lambda w: -.8 + .49 / (3.24 - w * w + 1j * .27 * w)
    train = np.array([.35, .8]); inv = 1 / np.array([hs(w) + .8 for w in train])
    sl, it = np.polyfit(train ** 2, inv.real, 1); a = -1 / sl; o2 = it * a; gm = float(np.mean(inv.imag / train) * a)
    blind = np.array([1.1, 1.6, 1.8, 2.2, 3.0]); err = max(abs(-.8 + a / (o2 - w * w + 1j * gm * w) - hs(w)) for w in blind)
    ok = err < 1e-10
    must(ok, 'SE')
    R['SE'] = dict(claim='What remains are anchors. With the order fixed by SD, a d-mode response has 3d + 1 real parameters, and these '
                         'must be measured: none is fixed by a principle (SC). With them, prediction at withheld frequencies is exact '
                         '(blind error below 1e-10 for the supplied single mode). This is system identification.',
                   status='computed', recovered=[fl(a), fl(o2), fl(gm)], blind_error=below(err, 1e-10))


if __name__ == '__main__':
    for name, fn in (('SA', SA), ('SB', SB), ('SC', SC), ('SD', SD), ('SE', SE)):
        fn(); print(name, flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(open(os.path.abspath(__file__), 'rb').read()).hexdigest()
    json.dump(out, open(os.path.join(HERE, 'rg_selection_attack_results.json'), 'w'), indent=1, sort_keys=True)
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
