# RG – Selection of the Hidden Response: what can RG's principles select?

**Verdict: the selection principle locks, but it selects the class and the order, not the member.**

| What is selected | By what | Status |
|---|---|---|
| The class: causal, passive, reciprocal linear responses | the cone, balance with passivity, reciprocity | Locked. Known: positive-real functions, Kramers–Kronig |
| The number of hidden modes | the rank of the records (Loewner matrix, the frequency-domain Hankel rank) | Locked. Known: Loewner framework |
| Resonance frequencies, couplings, damping | nothing | **Provably not selectable**. A frequency would be an internal unit (L94), and even a dimensionless ratio is free |

So prediction works, but as conditional system identification: the order comes from records, and 3d + 1 numbers come from measurement. That is not new physics, and no RG principle narrows it further. The novelty print was not built, because its condition (a selection that fixes values) fails.

Battery: `rg_selection_attack.py`, 5 groups (SA–SE), each with a canary; byte-identical on rerun; 4/4 mutations caught by the battery's own checks. The supplied programme and results are under `supplied/` and reproduce exactly (SA).

## Group by group

- **SA.** The supplied run is reproduced: nine checks pass, the single-mode blind error is 3.7×10⁻¹⁵, and the second-mode attack raises it to 26.3 %.
- **SB, class.** All poles are stable (largest real part −0.11), the absorbed power −ω Im H ≥ 0 at every frequency, M, Γ, K are symmetric, and Kramers–Kronig holds (residual below 10⁻⁶ at four frequencies, with the sign fixed by the e^{+iωt} convention). Canary: one negative damping eigenvalue gives negative loss and an unstable pole.
- **SC, no member.** M → M/s², Γ → Γ/s gives exactly H_s(ω) = H(ω/s) (to 10⁻¹²). For s = ½ and 2 every principle still holds, and the response at ω = 1.8 changes by 0.39 and 0.53. A principle that fixed a resonance would fix a unit, which the no-internal-unit theorem excludes. Scaling the damping by 0.3 or 3 also keeps every principle and changes the quality factor, so not even a dimensionless ratio is fixed.
- **SD, order.** From ten training frequencies in the supplied calibration band (0.2–0.9), the Loewner matrix has rank 2 for the single-mode response and rank 4 for the two-mode response (singular values 1, 3.2×10⁻², 1.4×10⁻⁵, 1.7×10⁻⁸, then 10⁻¹⁶). So the second mode that broke the supplied extrapolation is detected before any blind frequency is used. This is the one place where RG's records improve on the supplied programme. Canary: the single-mode response gives rank 2.
- **SE, anchors.** With the order known, three numbers (plus k₀) fix the supplied single mode, and blind prediction is exact to 10⁻¹⁰.

## What would make it novel

A principle fixing a dimensionless property of the hidden response (a quality factor, a coupling ratio, a sum-rule weight) from something RG measures independently, such as a frontier speed, a Fisher invariant or a holonomy. The present principles admit the continuous family of SC, so no such relation follows from them. Choosing one would be inserting the prediction.

## Sources

- R. de L. Kronig (1926), H. A. Kramers (1927): dispersion relations; positive-real (Foster) functions in network theory.
- A. J. Mayo, A. C. Antoulas, A framework for the solution of the generalized realization problem, Linear Algebra Appl. 425 (2007) 634.
