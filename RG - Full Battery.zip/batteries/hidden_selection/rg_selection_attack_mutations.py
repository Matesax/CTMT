#!/usr/bin/env python3
"""Mutation suite for rg_selection_attack.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. Under one minute.

    python3 -I rg_selection_attack_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('SB', 'Kramers-Kronig with the wrong sign for this time convention', "out.append(abs((Hf(w0).real - Hinf) + (2 / np.pi) * (val + tail)))", "out.append(abs((Hf(w0).real - Hinf) - (2 / np.pi) * (val + tail)))"),
    ('SC', 'scaling the damping with the wrong power of the scale', "Ms, Gs = M0 / s ** 2, G0 / s", "Ms, Gs = M0 / s ** 2, G0 / s ** 2"),
    ('SD', 'a second mode too weak to be resolved presented as detectable', "hm = lambda w: hs(w) + .18 / (7.1 - w * w + 1j * .19 * w)", "hm = lambda w: hs(w) + 1e-13 / (7.1 - w * w + 1j * .19 * w)"),
    ('SE', 'calibration with the wrong sign of the instantaneous term', "inv = 1 / np.array([hs(w) + .8 for w in train])", "inv = 1 / np.array([hs(w) - .8 for w in train])"),
]


def main():
    base = open(os.path.join(HERE, 'rg_selection_attack.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_selection_attack.py'), 'w').write(base.replace(old, new))
            shutil.copytree(os.path.join(HERE, 'supplied'), os.path.join(tmp, 'supplied'))
            run = subprocess.run([sys.executable, '-I', 'rg_selection_attack.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_selection_attack_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
