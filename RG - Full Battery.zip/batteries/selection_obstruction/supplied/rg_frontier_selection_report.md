# Frontier-factorized selection: theorem, experiment, limitations

## Result
The base battery passes 14 gates. All data are synthetic and dimensionless. This is a scalar passive scattering model with an accessible return path, not a constructed Einstein solution, not a prediction of echoes from inside an event horizon, and not an RG-exclusive physical law. The mutation JSON reports actual independent source-mutation executions; crashes are not counted as catches.

## Assumptions
Stationary nondispersive propagation along a known two-way path; known front speed C; effective one-way path length L; zero initial perturbation for the intervention response; linear time-invariant local scattering; a single damped local mode; passive energy-normalized scattering ports. The delay is an independent geometry/front anchor, not fitted from the same calibration spectrum. A generic cone only bounds onset: equality at 2L/C additionally requires a path that attains the front and a local impulse response beginning at zero lag. In curved spacetime use measured optical travel time, not arbitrary coordinate distance. No unknown instrument noise, model-order uncertainty, or confidence intervals are treated in the exact identification test.

## Formula
R(s)=exp(-tau*s) H(s), tau=2L/C,
H(s)=b*s/(s^2+gamma*s+omega0^2).
Here gamma>0, omega0>0, 0<=b<=gamma. This is a SCATTERING transfer function, not the previous force/displacement susceptibility. The two port normalizations cannot be silently identified.

## Conditional selection theorem
If an impulse response vanishes before tau, its transfer factors as exp(-tau*s)H(s) with causal H. If the path attains the frontier and H has nonzero response arbitrarily close to zero lag, onset equals tau. For the declared single-mode class, |H(iw)|^2=b^2*w^2/((omega0^2-w^2)^2+gamma^2*w^2). Its maximum is (b/gamma)^2 at w=omega0. Therefore passive scattering is equivalent to |b|<=gamma in this class; nonnegative b is an additional chosen sign convention. Delay preserves the frequency-domain gain. These conditions select inequalities and support, not parameter values.

## Rank correction
A nonzero strictly delayed rational response is nonrational and cannot have an exact finite-dimensional delay-free LTI realization. A rational function has algebraic asymptotics on the positive real s-axis; multiplication by exp(-tau*s), tau>0, gives exponential decay, impossible for a nonzero rational function. Therefore local hidden-state order must be assessed AFTER removing known propagation. The full numerical Loewner rank in a finite sample is not the infinite exact rank. The experiment obtains local rank 2, full delayed numerical rank 8, and factored rank 2 at tolerance 1e-10.

Loewner rank measures minimal rational state dimension, not universally twice a count of physical oscillators. Twice-mode counting additionally needs distinct uncancelled second-order modes, adequate generic samples, and suitable conditioning. Finite noisy frequency data do not establish exact rank or exclude other continuations.

## Calibration and prediction
For s=iw and h=exp(tau*s)R(s), solve h*gamma*s+h*omega0^2-b*s=-h*s^2 as a real stacked least-squares system. Ten exact training frequencies .15 to .9 identify gamma=.45, omega0^2=2.89, b=.27. Six blind frequencies 1.1 to 4.5 give relative error 2.60e-14. Omitting the known delay gives 0.9724 relative error. This is conditional identification, not an independent physical discovery. The training matrix condition number is 95.47; machine-precision success is not a noise-robust uncertainty certificate.

An independently integrated oscillator under a compact pulse agrees with exact held-input state evolution to 0.00210 relative error; the discrepancy includes input discretization. A pulse energy check passes. Exact prefront zeros are a construction/identity check, not an independent discovery of the cone.

## Nonselection counterfamily
At identical tau=1.6 and identical frontier C=1, three passive stable responses have (omega0,gamma,rho=b/gamma)=(1.2,.12,.3),(1.7,.45,.6),(2.8,1.1,.85). Their Q=omega0/gamma are 10, 3.7778, 2.5455. They satisfy the tested class constraints but have different dimensionless responses. Thus these constraints do not select Q, omega0*tau, or rho. No-internal-unit reasoning alone would not forbid dimensionless predictions; this explicit counterfamily is the relevant nonselection argument.

## What is not established
No general derivation of passivity or reciprocity from a cone alone. No universal finite mode count. No proof of Einstein constraints, nonlinear completion, singularity continuation, quantum gravity, or new physical prediction. No literature-priority certification. Web search was unavailable; general knowledge cutoff December 2025. Standard delay systems and passive realization theory are the expected comparison literature.

## Reproduction
python rg_frontier_selection.py
python rg_frontier_selection_mutations.py
Requires NumPy and SciPy. Each exits nonzero on its declared failure. JSON files contain full outputs. No plots or external data are required.
