#!/usr/bin/env python3
"""Frontier-factorized passive scattering response. Synthetic, dimensionless data.
No full GR solution, new physical law, or novelty certification.
Run: python rg_frontier_selection.py
Requires numpy/scipy. JSON output beside script; nonzero exit on failed gate.
"""
import json, sys
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp, trapezoid
from scipy.linalg import expm
OUT=Path(__file__).resolve().parent
C=1.0; L=.8; TAU=2*L/C
OMEGA=1.7; GAMMA=.45; RHO=.6; B=RHO*GAMMA

def local(s,omega=OMEGA,gamma=GAMMA,rho=RHO):
    return rho*gamma*s/(s*s+gamma*s+omega*omega)

def response(s,tau=TAU,omega=OMEGA,gamma=GAMMA,rho=RHO):
    return np.exp(-s*tau)*local(s,omega,gamma,rho) # MUT_DELAY_SIGN

def impulse(t,omega=OMEGA,gamma=GAMMA,rho=RHO):
    wd=np.sqrt(omega*omega-gamma*gamma/4)
    return rho*gamma*np.exp(-gamma*t/2)*(np.cos(wd*t)-gamma/(2*wd)*np.sin(wd*t))

def fit(s,values,tau):
    h=values*np.exp(s*tau) # MUT_DEEMBED
    # h(s)*(s^2+gamma*s+omega^2)=b*s
    A=np.column_stack([h*s,h,-s]); rhs=-h*s*s
    ar=np.vstack([A.real,A.imag]); br=np.r_[rhs.real,rhs.imag]
    par=np.linalg.lstsq(ar,br,rcond=None)[0]
    gamma,w2,b=par
    return par,float(np.linalg.cond(ar))

def predict(s,par,tau):
    gamma,w2,b=par
    return np.exp(-s*tau)*b*s/(s*s+gamma*s+w2)

def loewner_rank(s,h,tol=1e-10):
    left=s[::2];right=s[1::2];lv=h[::2];rv=h[1::2]
    mat=(lv[:,None]-rv[None,:])/(left[:,None]-right[None,:])
    sv=np.linalg.svd(mat,compute_uv=False)
    return int(np.sum(sv>tol*sv[0])),sv.tolist()

def run():
    # Fixed gates declared before computation. No empirical data.
    t=np.linspace(0,14,7001);dt=t[1]-t[0]
    tau_from_front=TAU # Independently supplied geometry/front anchor, NOT inferred from spectrum.
    front=t>=TAU
    delayed=np.zeros_like(t);delayed[front]=impulse(t[front]-TAU)
    onset=float(t[np.flatnonzero(np.abs(delayed)>1e-12)[0]])
    # Ten complex calibration frequencies, five wholly outside the calibration band.
    trainw=np.linspace(.15,.9,10);sw=1j*trainw; vals=response(sw)
    par,cond=fit(sw,vals,tau_from_front)
    testw=np.array([1.1,1.4,1.7,2.2,3.,4.5]);st=1j*testw
    pred=predict(st,par,tau_from_front);truth=response(st)
    blind_error=float(np.linalg.norm(pred-truth)/np.linalg.norm(truth))
    naive,naivecond=fit(sw,vals,0.)
    naive_error=float(np.linalg.norm(predict(st,naive,0)-truth)/np.linalg.norm(truth))
    # Numerical Loewner rank: pure local response versus response including propagation.
    samples=1j*np.geomspace(.1,8,24)
    ranklocal,svlocal=loewner_rank(samples,local(samples))
    rankfull,svfull=loewner_rank(samples,response(samples))
    rankfactored,_=loewner_rank(samples,response(samples)*np.exp(samples*TAU))
    # Causal passive scattering, not force/displacement susceptibility.
    # |H(iw)|<=rho because denom modulus^2=(omega0^2-w^2)^2+gamma^2*w^2.
    gridw=np.r_[np.geomspace(.001,100,4000),OMEGA]
    maxgain=float(np.max(np.abs(response(1j*gridw))))
    # Independent ODE and exact held-input state update under a compact input pulse.
    def drive(x):
        return np.sin(np.pi*x/.8)**2 if 0<x<.8 else 0.
    def rhs(x,z):return [z[1],drive(x)-GAMMA*z[1]-OMEGA**2*z[0]]
    sol=solve_ivp(rhs,[0,t[-1]],np.zeros(2),t_eval=t,rtol=1e-10,atol=1e-12,max_step=.01)
    A=np.array([[0.,1.],[-OMEGA**2,-GAMMA]])
    aug=np.zeros((3,3));aug[:2,:2]=A;aug[1,2]=1.
    E=expm(aug*dt);z=np.zeros(2);zoh=[]
    for tt in t:
        zoh.append(B*z[1]);z=E[:2,:2]@z+E[:2,2]*drive(tt)
    local_ode=B*sol.y[1];local_zoh=np.array(zoh)
    nshift=int(round(TAU/dt))
    observed=np.r_[np.zeros(nshift),local_ode[:-nshift]]
    forecast=np.r_[np.zeros(nshift),local_zoh[:-nshift]]
    ode_error=float(np.linalg.norm(observed-forecast)/np.linalg.norm(observed))
    ein=float(trapezoid(np.array([drive(tt) for tt in t])**2,t))
    eout=float(trapezoid(observed**2,t))
    # Counterfamily: same geometry/front, positive damping, reciprocal scalar passive responses.
    family=[]
    for om,ga,rh in [(1.2,.12,.3),(1.7,.45,.6),(2.8,1.1,.85)]:
        gains=np.abs(response(1j*np.r_[gridw,om],omega=om,gamma=ga,rho=rh))
        family.append({'omega':om,'gamma':ga,'rho':rh,'Q':om/ga,'front':TAU,'max_gain':float(gains.max()),'poles_real':(-ga/2)})
    # Same front, substantially different calibrated local spectra.
    gap=float(np.linalg.norm(response(st,omega=1.2,gamma=.12,rho=.3)-response(st,omega=2.8,gamma=1.1,rho=.85)))
    # Exact time-unit covariance; no internal-unit argument alone fixes dimensionless Q.
    scale=3.7
    scaled=response(st/scale,tau=TAU*scale,omega=OMEGA/scale,gamma=GAMMA/scale)
    scale_error=float(np.max(np.abs(scaled-truth)))
    # Passivity rejection negative control.
    active_gain=float(np.max(np.abs(response(1j*gridw,rho=1.4))))
    # Dimensionless passivity selection: b/gamma <= 1. It is a bound, not an equality.
    fitted_ratio=float(par[2]/par[0])
    gates={
      'front_matches_geometry':abs(onset-2*L/C)<dt/2,
      'no_prefront_intervention_response':bool(np.all(delayed[t<TAU]==0)),
      'stable_local_poles':bool(np.all(np.linalg.eigvals(A).real<0)),
      'passive_gain_bound':maxgain<=1+1e-12,
      'passive_energy_test':eout<=ein*(1+1e-8),
      'blind_spectral_prediction':blind_error<1e-9,
      'front_factor_required':naive_error>.05,
      'delay_factored_rank_two':ranklocal==2 and rankfactored==2,
      'delay_not_finite_local_mode_count':rankfull>ranklocal,
      'independent_ode_prediction':bool(sol.success) and ode_error<.01,
      'nonunique_dimensionless_parameters':gap>.1 and max(x['max_gain'] for x in family)<1 and max(x['Q'] for x in family)>2*min(x['Q'] for x in family),
      'unit_covariance':scale_error<1e-12,
      'active_control_rejected':active_gain>1.1,
      'identified_passive_ratio':0<=fitted_ratio<=1}
    R={'scope':'Synthetic scalar passive scattering channel with accessible return path; not a force susceptibility, horizon-interior echo, or GR solution.',
      'formula':'R(s)=exp(-2Ls/C) * b*s/(s^2+gamma*s+omega0^2)',
      'extra_assumptions':['known two-way propagation time in stationary effective geometry','zero initial hidden perturbation for intervention response','one collocated local damped mode','passive scattering port normalization','exact noiseless spectral calibration'],
      'anchors':{'C':C,'L':L,'tau':TAU},'fit':{'gamma':float(par[0]),'omega_squared':float(par[1]),'b':float(par[2]),'rho':fitted_ratio,'condition':cond},
      'onset':onset,'blind_relative_error':blind_error,'unfactored_fit_blind_error':naive_error,
      'loewner':{'local_rank':ranklocal,'full_delayed_numerical_rank':rankfull,'factored_rank':rankfactored,'local_singular_values':svlocal,'full_singular_values':svfull},
      'max_scattering_gain':maxgain,'input_energy':ein,'output_energy':eout,'independent_ode_error':ode_error,
      'same_front_family':family,'family_response_gap':gap,'unit_covariance_error':scale_error,
      'gates':gates,'all_pass':bool(all(gates.values())),
      'selection_lock':'causal delay factor plus passive local class and minimal rational order conditional on model assumptions',
      'novel_physics_lock':False,'unique_parameters_from_frontier':False}
    (OUT/'rg_frontier_selection_results.json').write_text(json.dumps(R,indent=2,default=lambda x: bool(x) if isinstance(x,np.bool_) else float(x)))
    print(json.dumps(R,indent=2,default=lambda x: bool(x) if isinstance(x,np.bool_) else float(x)));return R
if __name__=='__main__':
    r=run();sys.exit(0 if r['all_pass'] else 1)
