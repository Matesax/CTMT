#!/usr/bin/env python3
"""Actual source mutation harness; crashes do not count as catches."""
from pathlib import Path
import tempfile,subprocess,sys,json
HERE=Path(__file__).resolve().parent
BASE=HERE/'rg_frontier_selection.py'
MUTATIONS=[
 ('advanced_response','return np.exp(-s*tau)*local(s,omega,gamma,rho) # MUT_DELAY_SIGN','return np.exp(s*tau)*local(s,omega,gamma,rho) # MUT_DELAY_SIGN','blind_spectral_prediction'),
 ('wrong_delay_removal','h=values*np.exp(s*tau) # MUT_DEEMBED','h=values*np.exp(-s*tau) # MUT_DEEMBED','blind_spectral_prediction'),
 ('active_scattering','OMEGA=1.7; GAMMA=.45; RHO=.6; B=RHO*GAMMA','OMEGA=1.7; GAMMA=.45; RHO=1.4; B=RHO*GAMMA','passive_gain_bound'),
 ('wrong_front_anchor','tau_from_front=TAU # Independently','tau_from_front=TAU*.7 # Independently','blind_spectral_prediction'),
 ('rank_includes_propagation','ranklocal,svlocal=loewner_rank(samples,local(samples))','ranklocal,svlocal=loewner_rank(samples,response(samples))','delay_factored_rank_two')]
def main():
 base=BASE.read_text();out=[]
 for name,old,new,target in MUTATIONS:
  if base.count(old)!=1:
   out.append({'name':name,'caught':False,'error':'anchor not unique'});continue
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/BASE.name;p.write_text(base.replace(old,new))
   r=subprocess.run([sys.executable,str(p)],capture_output=True,text=True,timeout=90)
   result=Path(tmp)/'rg_frontier_selection_results.json'
   if not result.exists():
    out.append({'name':name,'caught':False,'error':'crash or missing results','stderr':r.stderr[-500:]});continue
   d=json.loads(result.read_text());failed=[k for k,v in d['gates'].items() if not v]
   out.append({'name':name,'caught':target in failed and r.returncode!=0,'target':target,'failed_gates':failed})
 report={'mutations':out,'caught':sum(x['caught'] for x in out),'total':len(out),'all_caught':all(x['caught'] for x in out)}
 (HERE/'rg_frontier_selection_mutations.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
 return report
if __name__=='__main__':
 r=main();sys.exit(0 if r['all_caught'] else 1)
