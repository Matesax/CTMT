# RG – Selection Obstruction: can a destructor close the gap between RG's principles and a unique hidden response?

**Verdict: the gap is a locked obstruction, not a missing step.** Every constraint RG places on a local hidden response is one of three types:
- an identity that holds for the whole class (causality, Kramers–Kronig, scalar reciprocity);
- an inequality (stability, passivity, the attained front);
- an integer (the order, from descent).

None is an equality on the three dimensionless parameters left after the no-internal-unit theorem: ρ = b/γ, Q = ω₀/γ and θ = ω₀τ. So the admissible set is open and three-dimensional, and every direction in it changes a record. Selecting one response needs three independent equality principles. RG has none, and the only one any extremal principle could supply, saturated passivity ρ = 1, is not a rung and leaves Q and θ free. A novelty paper cannot be built on this: the prediction would have to be inserted.

Battery: `rg_selection_obstruction.py`, 4 groups (OA–OD), each with a canary; byte-identical on rerun; 4/4 mutations caught by the battery's own checks (crashes counted as defects). The supplied frontier-selection bundle is under `supplied/` and reproduces exactly: 14 gates, all 90 values identical (OA).

## Group by group

| Group | Finding |
|---|---|
| OB, constraint types | Causality and Kramers–Kronig hold at 40 random points and 12 frequencies (residual below 10⁻⁶): identities. Passivity is \|H\| ≤ ρ, an inequality whose boundary ρ = 1 is touched only at resonance (sup \|H\| = 1.0000 for Q = 0.5, 2, 5). Descent gives an integer. No equality appears |
| OC, open and observable | Around 20 random admissible points, a ball of relative radius 0.05 stays admissible in 26 probe directions. The map from (ρ, Q, θ) to the delayed response at four dimensionless frequencies has rank 3 everywhere: the freedom is physical, not a relabeling. Canary: one hypothetical equality (ρ = 1) leaves an admissible, observable set of rank 2 |
| OD, destructors | The attained front gives h(0⁺) = b > 0 (initial-value theorem: 0.2 and 0.6 recovered), an inequality. Minimal order gives an integer. Maximal recorded gain at fixed damping drives ρ to 1 (sup \|H\| = ρ, increasing), one equality, not on the ladder, and Q and θ stay free |

## What the supplied run adds, and what it settles

The frontier factorization R = e^{−sτ}H is correct and useful. Remove the propagation before counting hidden modes, or delay is misread as extra modes: the supplied 97 % blind error versus 2.6×10⁻¹⁴. Its counterfamily already showed nonselection by example. This battery shows the nonselection holds for the whole open set and states the count: a point needs three equalities.

## What would change the verdict

An RG rung stating an equality between a dimensionless response parameter and an independently measured RG invariant. For example, Q fixed by a holonomy or a Fisher-volume rate, or θ fixed by the forecast exponent of the Tensor Frontier print. Writing such a rung requires a physical reason for it. Without one it is the prediction inserted by hand.

## Sources

Standard comparison literature: Kramers–Kronig relations; passive (bounded-real and positive-real) network functions; delay systems and delay extraction before rational fitting.
