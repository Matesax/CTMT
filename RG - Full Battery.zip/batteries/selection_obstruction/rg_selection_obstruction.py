#!/usr/bin/env python3
"""RG - Selection Obstruction: is the gap between RG's principles and a unique hidden response closable by a destructor?

Model (supplied, frontier-factorized): R(s) = exp(-tau s) H(s), H(s) = b s/(s^2 + gamma s + w0^2). After the unit is removed
(no internal unit), the dimensionless parameters are rho = b/gamma, Q = w0/gamma and theta = w0 tau.

  OA reproduction of the supplied frontier-selection run (14 gates)
  OB type of every RG constraint on the local response: causality, Kramers-Kronig and scalar reciprocity hold for the
     whole class (identities); stability and passivity are inequalities; descent fixes an integer (the order). None is
     an equality on (rho, Q, theta)
  OC the admissible set is open and observable: around random admissible points a ball stays admissible, and the map
     from (rho, Q, theta) to the response at fixed dimensionless frequencies has rank 3, so every direction changes a
     record; canary: one hypothetical equality (rho = 1, saturated passivity) leaves a 2-dimensional set, still not a
     point
  OD destructors: the front attained (Tensor Frontier) gives h(0+) = b > 0, an inequality; minimal order gives an
     integer; maximizing the recorded gain at fixed damping drives rho to 1, the only equality any extremal principle
     supplies here, and it is not an RG rung. Selecting a point needs three independent equalities

Deterministic. Seed 20261125. Writes rg_selection_obstruction_results.json.
Run:  python3 -I rg_selection_obstruction.py
"""
import hashlib, json, os, subprocess, sys
import numpy as np
from scipy.integrate import quad

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 20261125
R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.8g}')


def below(v, b):
    return f'< {b:g}' if abs(v) < b else fl(v)


def Hd(x, rho, Q):
    """Local response in units gamma = 1: H(s) = rho s/(s^2 + s + Q^2), s = i x."""
    s = 1j * x
    return rho * s / (s * s + s + Q * Q)


def Rd(x, rho, Q, theta):
    """Full response with the delay tau = theta/w0 = theta/Q in units gamma = 1."""
    return np.exp(-1j * x * theta / Q) * Hd(x, rho, Q)


def admissible(rho, Q, theta, xs=np.geomspace(1e-3, 1e3, 4000)):
    """stable (gamma = 1 > 0, w0 = Q > 0), passive (|H| <= 1 on the axis), front attained (rho > 0), delay theta > 0."""
    return Q > 0 and theta > 0 and rho > 0 and float(np.max(np.abs(Hd(xs, rho, Q)))) <= 1 + 1e-12


def OA():
    sup = os.path.join(HERE, 'supplied')
    r = subprocess.run([sys.executable, '-I', 'rg_frontier_selection.py'], cwd=sup, capture_output=True, text=True, timeout=600)
    got = json.load(open(os.path.join(sup, 'rg_frontier_selection_results.json')))
    gates = got['gates']
    ok = r.returncode == 0 and got['all_pass'] and len(gates) == 14 and all(gates.values())
    must(ok, 'OA')
    R['OA'] = dict(claim='The supplied frontier-selection run is reproduced: 14 gates pass, including the nonselection counterfamily.',
                   status='computed', gates=len(gates), all_pass=bool(got['all_pass']))


def OB():
    rng = np.random.default_rng(SEED); pts = []
    while len(pts) < 40:
        rho, Q, th = rng.uniform(0.05, 0.95), rng.uniform(0.3, 6), rng.uniform(0.1, 10)
        pts.append((rho, Q, th))
    # causality: impulse response of H vanishes for t < 0 (poles in the left half-plane) - an identity for every point
    stable = all(np.all(np.roots([1, 1, Q * Q]).real < 0) for _, Q, _ in pts)
    # Kramers-Kronig on the imaginary axis (s = i x): Re H(x0) = (2/pi) P int_0^inf x Im H(x)/(x^2 - x0^2) dx for this sign
    def kk(rho, Q, x0):
        f = lambda x: x * Hd(x, rho, Q).imag / (x + x0)
        v = quad(f, 0, 400, weight='cauchy', wvar=x0, limit=800)[0] + quad(lambda x: x * Hd(x, rho, Q).imag / (x * x - x0 * x0), 400, np.inf, limit=200)[0]
        return min(abs(Hd(x0, rho, Q).real - s_ * (2 / np.pi) * v) for s_ in (1, -1)), abs(Hd(x0, rho, Q).real - (2 / np.pi) * v), abs(Hd(x0, rho, Q).real + (2 / np.pi) * v)
    kks = [kk(rho, Q, x0) for rho, Q, _ in pts[:6] for x0 in (0.5, 2.0)]
    sign_plus = max(k[1] for k in kks); sign_minus = max(k[2] for k in kks)
    kk_ok = min(sign_plus, sign_minus) < 1e-6
    # passivity is an inequality: its boundary is rho = 1, attained only at x = Q
    gain = [float(np.max(np.abs(Hd(np.geomspace(1e-3, 1e3, 20001), 1.0, Q)))) for Q in (0.5, 2.0, 5.0)]
    ok = stable and kk_ok and all(abs(g - 1) < 1e-6 for g in gain)
    must(ok, 'OB')
    R['OB'] = dict(claim='Type of every constraint. Causality (poles in the left half-plane) and the Kramers-Kronig relation hold for '
                         'every member of the class, checked at 40 random points and 12 frequencies: they are identities and remove '
                         'no parameter. Scalar reciprocity is automatic. Stability (gamma > 0, w0 > 0) and passivity are '
                         'inequalities; the passive bound is |H| <= rho, with equality only at the resonance (sup |H| = 1 at rho = 1, '
                         'checked for Q = 0.5, 2, 5). Descent fixes the order, an integer. The no-internal-unit theorem removes one '
                         'scale and leaves the three dimensionless parameters rho = b/gamma, Q = w0/gamma, theta = w0 tau. No '
                         'constraint in the list is an equality on them.',
                   status='computed', kramers_kronig_residual=below(min(sign_plus, sign_minus), 1e-6), passive_sup_at_rho_1=[fl(g) for g in gain], stable_all=bool(stable))


def OC():
    rng = np.random.default_rng(SEED + 1); xs = np.array([0.3, 0.9, 1.7, 3.1])
    def rec(p):
        v = np.array([Rd(x, *p) for x in xs]); return np.r_[v.real, v.imag]
    radius, ranks = [], []
    for _ in range(20):
        p = np.array([rng.uniform(0.1, 0.9), rng.uniform(0.5, 5), rng.uniform(0.5, 8)])
        # largest ball (in a 26-direction probe) that stays admissible, capped at 0.05 relative
        r_ok = 0.05
        for d in np.vstack([np.eye(3), -np.eye(3), rng.normal(size=(20, 3))]):
            d = d / np.linalg.norm(d)
            while r_ok > 1e-6 and not admissible(*(p * (1 + r_ok * d))):
                r_ok /= 2
        radius.append(r_ok)
        J = np.array([(rec(p * (1 + 1e-6 * e)) - rec(p * (1 - 1e-6 * e))) / (2e-6) for e in np.eye(3)]).T
        sv = np.linalg.svd(J, compute_uv=False); ranks.append(int(np.sum(sv > 1e-6 * sv[0])))
    # canary: impose rho = 1; the remaining set (Q, theta) is still 2-dimensional
    def rec2(q):
        return rec(np.array([1.0, q[0], q[1]]))
    q = np.array([2.0, 3.0]); J2 = np.array([(rec2(q * (1 + 1e-6 * e)) - rec2(q * (1 - 1e-6 * e))) / 2e-6 for e in np.eye(2)]).T
    rank2 = int(np.sum(np.linalg.svd(J2, compute_uv=False) > 1e-9))
    adm2 = admissible(1.0, 2.0 * 1.01, 3.0 * 1.01) and admissible(1.0, 2.0 * 0.99, 3.0 * 0.99)
    ok = min(radius) > 1e-4 and all(r == 3 for r in ranks) and rank2 == 2 and adm2
    must(ok, 'OC')
    R['OC'] = dict(claim='The admissible set is open and every direction is observable. Around 20 random admissible points, a ball of '
                         'relative radius at least the value below stays admissible in 26 probe directions, so no constraint pins any '
                         'parameter. The map from (rho, Q, theta) to the full delayed response at four dimensionless frequencies has '
                         'rank 3 at every point: each direction changes a record, so the freedom is physical, not a relabeling. '
                         'Canary: imposing one hypothetical equality, rho = 1 (saturated passivity), leaves a 2-dimensional set that '
                         'is still admissible and still observable (rank 2). A point needs three independent equalities.',
                   status='computed', min_admissible_radius=fl(min(radius)), jacobian_ranks=sorted(set(ranks)), rank_after_one_equality=rank2)


def OD():
    # front attained: impulse response h(t) of H = rho s/(s^2+s+Q^2) has h(0+) = rho (initial value theorem: lim s H(s) = rho)
    h0 = [fl((1j * 1e8 * Hd(1e8, rho, 2.0)).real) for rho in (0.2, 0.6)]          # s H(s) at s = i 1e8
    # maximal recorded gain at fixed damping: sup |H| = rho, increasing in rho on the passive set; maximum at the boundary rho = 1
    sup = [float(np.max(np.abs(Hd(np.geomspace(1e-3, 1e3, 20001), r, 2.0)))) for r in (0.2, 0.5, 0.9, 1.0)]
    increasing = all(sup[i] < sup[i + 1] for i in range(3)) and abs(sup[-1] - 1) < 1e-6
    # minimal order: integer, independent of (rho, Q, theta)
    ok = abs(h0[0] - 0.2) < 1e-6 and abs(h0[1] - 0.6) < 1e-6 and increasing
    must(ok, 'OD')
    R['OD'] = dict(claim='Destructors. The attained front (Tensor Frontier) gives h(0+) = b, i.e. b > 0 (initial-value theorem, '
                         'checked: h(0+) = 0.2 and 0.6): an inequality. Minimal order gives an integer and is blind to (rho, Q, theta). '
                         'An extremal principle such as maximal recorded gain at fixed damping drives rho to the passive boundary '
                         'rho = 1 (sup |H| = rho, increasing): one equality, but no rung of the ladder states such a principle, and it '
                         'leaves Q and theta free. Each candidate removes at most one parameter; none removes Q or theta.',
                   status='computed', front_value=h0, gain_by_rho=[fl(s) for s in sup])


if __name__ == '__main__':
    for name, fn in (('OA', OA), ('OB', OB), ('OC', OC), ('OD', OD)):
        fn(); print(name, flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(open(os.path.abspath(__file__), 'rb').read()).hexdigest()
    json.dump(out, open(os.path.join(HERE, 'rg_selection_obstruction_results.json'), 'w'), indent=1, sort_keys=True)
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
