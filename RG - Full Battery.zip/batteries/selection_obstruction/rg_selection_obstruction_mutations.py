#!/usr/bin/env python3
"""Mutation suite for rg_selection_obstruction.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. Under one minute.

    python3 -I rg_selection_obstruction_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('OB', 'an unstable damping sign in the class', "stable = all(np.all(np.roots([1, 1, Q * Q]).real < 0) for _, Q, _ in pts)", "stable = all(np.all(np.roots([1, -1, Q * Q]).real < 0) for _, Q, _ in pts)"),
    ('OC', 'a parameter that does not reach the records', "return np.exp(-1j * x * theta / Q) * Hd(x, rho, Q)", "return np.exp(-1j * x * 1.0) * Hd(x, rho, Q)"),
    ('OD', 'the front value taken from the wrong end of the spectrum', "h0 = [fl((1j * 1e8 * Hd(1e8, rho, 2.0)).real) for rho in (0.2, 0.6)]", "h0 = [fl((1j * 1e-8 * Hd(1e-8, rho, 2.0)).real) for rho in (0.2, 0.6)]"),
    ('OD', 'gain claimed to fall with the coupling', "increasing = all(sup[i] < sup[i + 1] for i in range(3))", "increasing = all(sup[i] > sup[i + 1] for i in range(3))"),
]


def main():
    base = open(os.path.join(HERE, 'rg_selection_obstruction.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_selection_obstruction.py'), 'w').write(base.replace(old, new))
            shutil.copytree(os.path.join(HERE, 'supplied'), os.path.join(tmp, 'supplied'))
            run = subprocess.run([sys.executable, '-I', 'rg_selection_obstruction.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_selection_obstruction_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
