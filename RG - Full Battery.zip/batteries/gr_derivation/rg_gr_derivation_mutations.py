#!/usr/bin/env python3
"""Mutation suite for rg_gr_derivation.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. About two minutes.

    python3 -I rg_gr_derivation_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('RA', 'a force law one power too steep', "V = k * sp.log(r) if d == 2 else -k / ((d - 2) * r ** (d - 2))", "V = k * sp.log(r) if d == 2 else -k / ((d - 2) * r ** (d - 1))"),
    ('RB', 'the orientation term claimed scale-free', "e1, e2 = eps_up(g3), eps_up(lam ** 2 * g3)", "e1, e2 = eps_up(g3), eps_up(g3)"),
    ('RB', 'the three-dimensional control run in four dimensions', "'so(3)': invariant_rank3([1, 1, 1])", "'so(3)': invariant_rank3([1, 1, 1, 1])"),
    ('RB', 'the Christoffel factor 1/3', "for d in range(n)) / 2)", "for d in range(n)) / 3)"),
    ('RC', 'torsion confused with the symmetric part', "tor = [C(a, b, c) - C(a, c, b) for a, b, c in trip]", "tor = [C(a, b, c) + C(a, c, b) for a, b, c in trip]"),
    ('RC', 'the boosts dropped from the finite certificate', "for j in (1, 2, 3):\n        Q = sp.eye(4); Q[0, 0] = Q[j, j] = sp.Rational(5, 3)", "for j in ():\n        Q = sp.eye(4); Q[0, 0] = Q[j, j] = sp.Rational(5, 3)"),
    ('RD', 'the first Bianchi identity dropped', "T(a, b, c, d) - T(c, d, a, b),\n                 T(a, b, c, d) + T(a, c, d, b) + T(a, d, b, c)]", "T(a, b, c, d) - T(c, d, a, b)]"),
    ('RD', 'the Einstein tensor with a trace factor 1/3', "Ein = Ric - gm * Rs / 2", "Ein = Ric - gm * Rs / 3"),
    ('RD2', 'the trace-gradient term with the wrong sign', "+ c[2] * (kk * kk.T) * tr", "- c[2] * (kk * kk.T) * tr"),
    ('RD2', 'the Newtonian limit with a factor 3', "newton = sp.simplify(G00 - 2 * e * lap) == 0", "newton = sp.simplify(G00 - 3 * e * lap) == 0"),
    ('RE', 'the Thomas angle with the wrong sign', "predicted=wrap(2 * np.pi * (1 - gm))", "predicted=wrap(2 * np.pi * (gm - 1))"),
    ('RE', 'the parity-odd countermodel switched off', "chi = thomas(0.5, chiral=0.3)[0]", "chi = thomas(0.5, chiral=0.0)[0]"),
    ('RF', 'the perihelion factor 5.9 pi', "per_orbit = 6 * math.pi * GM", "per_orbit = 5.9 * math.pi * GM"),
]


def main():
    base = open(os.path.join(HERE, 'rg_gr_derivation.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_gr_derivation.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_gr_derivation.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_gr_derivation_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
