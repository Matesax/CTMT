#!/usr/bin/env python3
"""Resolution Geometry - General Relativity from Records: battery for the print.

A change of unit multiplies the metric by a constant, g -> lambda^2 g. A law with no internal unit gives the same connection
and the same gravitational response for g and lambda^2 g. With naturality, locality and smoothness at flat space this
forces the Levi-Civita connection and the Einstein tensor; every other term carries a length. Each group has a canary.

  RA realization: light cone fixes the metric up to a factor (exact); one clock fixes the factor; orbit stability by
     dimension; metric wave modes D(D-3)/2; canary: eight null directions are not enough
  RB weights (exact): Christoffel and Ricci unchanged under g -> 9g; scalar curvature and its gradient divided by 9;
     three-dimensional orientation tensor multiplied by 3; Schwarzschild R = 0 (the scale-free eps grad R / R is undefined
     in vacuum); invariants of a general rank-3 tensor under so(1,3), so(4), so(1,4), so(2) (none) and so(3) (one)
  RC free fall and torsion (exact): 24 / 4 / 0; axial witness; finite rational certificate for the Lorentz route
  RD response (exact): equivariant maps curvature -> symmetric tensors (dimension 2); Einstein unchanged, Lambda term x9,
     R R_ab /9; divergence of Einstein zero, of Ricci not (canary); Lanczos zero in D = 4
  RD2 cross-checks: Lovelock's dimension; the linear operator (1,-1,1,1,-1); R^2 carries the fourth derivative; Newtonian
     limit G_00 = 2 Laplacian(phi)
  RE observers: Thomas angle; geodetic angle; projector term on and off geodesics; parity-odd countermodel; Gravity Probe B
  RF tests: perihelion, deflection, GPS, Pound-Rebka; Brans-Dicke and Cassini; factor canaries

Deterministic. Seed 20261128. Writes rg_gr_derivation_results.json.
Run:  python3 -I rg_gr_derivation.py      (numpy, scipy, sympy)
"""
import hashlib, itertools, json, math, os, sys
import numpy as np
import sympy as sp
from scipy.integrate import solve_ivp

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 20261128
R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.8g}')


def below(v, b):
    return f'< {b:g}' if abs(v) < b else fl(v)


def wrap(a):
    return float(math.atan2(math.sin(a), math.cos(a)))


# ============================================================================================ symbolic geometry
def christoffel(g, X):
    n = len(X); gi = g.inv()
    return [[[sp.together(sum(gi[a, d] * (sp.diff(g[d, c], X[b]) + sp.diff(g[d, b], X[c]) - sp.diff(g[b, c], X[d])) for d in range(n)) / 2)
              for c in range(n)] for b in range(n)] for a in range(n)]


def riemann(G, X):
    """R^a_{bcd} = d_c G^a_db - d_d G^a_cb + G^a_ce G^e_db - G^a_de G^e_cb."""
    n = len(X)
    return [[[[sp.together(sp.diff(G[a][d][b], X[c]) - sp.diff(G[a][c][b], X[d]) + sum(G[a][c][e] * G[e][d][b] - G[a][d][e] * G[e][c][b] for e in range(n)))
               for d in range(n)] for c in range(n)] for b in range(n)] for a in range(n)]


def ricci(Rm, n):
    return sp.Matrix(n, n, lambda b, d: sp.together(sum(Rm[a][b][a][d] for a in range(n))))


def at(expr, pt):
    return sp.nsimplify(expr.subs(pt)) if hasattr(expr, 'subs') else expr



def so_generators(eta):
    n = eta.shape[0]; gens = []
    for i in range(n):
        for j in range(i + 1, n):
            L = sp.zeros(n)
            for a in range(n):
                for b in range(n):
                    L[a, b] = (1 if a == i else 0) * eta[j, b] - (1 if a == j else 0) * eta[i, b]
            gens.append(L)
    return gens


def invariant_rank3(signature):
    """Exact dimension of the invariants of a general tensor C^a_bc (no symmetry) under the Lie algebra so(eta)."""
    eta = sp.diag(*signature); n = len(signature); gens = so_generators(eta)
    xs = sp.symbols(f'c0:{n ** 3}'); T = lambda a, b, c: xs[n * n * a + n * b + c]
    rows = []
    for L in gens:
        for a, b, c in itertools.product(range(n), repeat=3):
            rows.append(sum(L[a, d] * T(d, b, c) for d in range(n)) - sum(L[d, b] * T(a, d, c) for d in range(n)) - sum(L[d, c] * T(a, b, d) for d in range(n)))
    A, _ = sp.linear_eq_to_matrix(rows, xs)
    return n ** 3 - A.rank()


def equivariant_curvature_to_symmetric(signature):
    """Exact dimension of the linear maps from algebraic curvature tensors to symmetric 2-tensors that commute with so(eta)."""
    eta = sp.diag(*signature); n = len(signature); gens = so_generators(eta)
    N4 = n ** 4; xs = sp.symbols(f'r0:{N4}'); T = lambda a, b, c, d: xs[((a * n + b) * n + c) * n + d]
    cons = []
    for a, b, c, d in itertools.product(range(n), repeat=4):
        cons += [T(a, b, c, d) + T(b, a, c, d), T(a, b, c, d) + T(a, b, d, c), T(a, b, c, d) - T(c, d, a, b),
                 T(a, b, c, d) + T(a, c, d, b) + T(a, d, b, c)]
    A, _ = sp.linear_eq_to_matrix(cons, xs); B = sp.Matrix.hstack(*A.nullspace())          # 256 x 20 basis
    def act4(L):
        M = sp.zeros(N4)
        for a, b, c, d in itertools.product(range(n), repeat=4):
            i = ((a * n + b) * n + c) * n + d
            for e in range(n):
                for k, pos in enumerate(((e, b, c, d), (a, e, c, d), (a, b, e, d), (a, b, c, e))):
                    coef = L[e, (a, b, c, d)[k]]
                    if coef != 0:
                        j = ((pos[0] * n + pos[1]) * n + pos[2]) * n + pos[3]; M[i, j] += coef
        return M
    sym = [(i, j) for i in range(n) for j in range(i, n)]
    S = sp.zeros(n * n, len(sym))
    for k, (i, j) in enumerate(sym):
        S[i * n + j, k] = 1; S[j * n + i, k] = 1
    def act2(L):
        M = sp.zeros(n * n)
        for a, b in itertools.product(range(n), repeat=2):
            for e in range(n):
                if L[e, a] != 0:
                    M[a * n + b, e * n + b] += L[e, a]
                if L[e, b] != 0:
                    M[a * n + b, a * n + e] += L[e, b]
        return M
    BtBi = (B.T * B).inv(); StSi = (S.T * S).inv()
    X = sp.Matrix(len(sym), B.shape[1], sp.symbols(f'm0:{len(sym) * B.shape[1]}'))
    eqs = []
    for L in gens:
        M4 = BtBi * B.T * act4(L) * B; M2 = StSi * S.T * act2(L) * S
        eqs += list(X * M4 - M2 * X)
    A2, _ = sp.linear_eq_to_matrix(eqs, list(X))
    return B.shape[1], X.shape[0] * X.shape[1] - A2.rank()


def RA():
    eta = sp.diag(-1, 1, 1, 1)
    M = sp.Matrix([[2, 1, 0, 1], [0, 3, 1, -1], [1, 0, 2, 1], [1, -1, 1, 3]])
    g = M.T * eta * M
    nulls = [(1, 1, 0, 0), (1, -1, 0, 0), (1, 0, 1, 0), (1, 0, -1, 0), (1, 0, 0, 1), (1, 0, 0, -1), (5, 3, 4, 0), (5, 0, 3, 4),
             (5, 4, 0, 3), (3, 1, 2, 2), (9, 4, 4, 7)]
    vs = [M.inv() * sp.Matrix(n) for n in nulls]
    assert all((v.T * g * v)[0] == 0 for v in vs)
    xs = sp.symbols('q0:10'); idx = [(i, j) for i in range(4) for j in range(i, 4)]
    X = sp.zeros(4)
    for x, (i, j) in zip(xs, idx):
        X[i, j] = X[j, i] = x
    def nullity(vecs):
        A, _ = sp.linear_eq_to_matrix([(v.T * X * v)[0] for v in vecs], xs); return 10 - A.rank(), A
    n11, A = nullity(vs); n8, _ = nullity(vs[:8])
    sol = A.nullspace()[0]; Xs = X.subs(dict(zip(xs, sol)))
    ratio = {sp.nsimplify(Xs[i, j] / g[i, j]) for i, j in idx if g[i, j] != 0}
    # one clock: a timelike vector of known proper time fixes the factor
    w = M.inv() * sp.Matrix([1, 0, 0, 0]); c = (w.T * g * w)[0] / (w.T * Xs * w)[0]
    fixed = sp.simplify(c * Xs - g) == sp.zeros(4)
    # Ehrenfest: circular orbits under the Gauss-law force in d space dimensions
    r, r0, L, k = sp.symbols('r r0 L k', positive=True); stab = {}
    for d in (2, 3, 4, 5):
        V = k * sp.log(r) if d == 2 else -k / ((d - 2) * r ** (d - 2))
        Veff = L ** 2 / (2 * r ** 2) + V
        Lsq = sp.solve(sp.diff(Veff, r).subs(r, r0), L ** 2)[0] if False else sp.solve(sp.Eq(sp.diff(Veff, r), 0).subs(r, r0), L)[0] ** 2
        second = sp.simplify(sp.diff(Veff, r, 2).subs(r, r0).subs(L ** 2, Lsq).subs(L, sp.sqrt(Lsq)))
        stab[d] = sp.simplify(second * r0 ** (d + 1) / k)
    dof = {D: D * (D - 3) // 2 for D in (3, 4, 5)}
    ok = n11 == 1 and len(ratio) == 1 and fixed and n8 >= 2 and stab[3] > 0 and stab[4] == 0 and stab[5] < 0 and stab[2] > 0 and dof[3] == 0 and dof[4] == 2
    must(ok, 'RA')
    R['RA'] = dict(claim='Realization. For a Lorentzian metric with rational entries, eleven rational null directions fix the quadratic form up '
                         'to one factor (nullity 1, exact): light rays alone give the metric up to scale (the causal-order theorems of '
                         'Hawking-King-McCarthy and Malament). One clock, a timelike direction of known proper time, fixes the factor '
                         'exactly. Canary: eight null directions leave at least two free parameters. Dimension: circular orbits under the '
                         'Gauss-law force in d space dimensions are stable for d = 2, 3, marginal for d = 4 and unstable for d = 5 '
                         '(Ehrenfest); the number of propagating metric modes, D(D-3)/2, is 0 for D = 3 and 2 for D = 4. Stable bound '
                         'orbits and gravitational waves together leave D = 4.',
                   status='computed (exact); IDENTIFIED (Malament 1977; Hawking-King-McCarthy 1976; Ehrenfest 1917)',
                   nullity_11_null_directions=int(n11), nullity_8_null_directions=int(n8), factor_fixed_by_one_clock=bool(fixed),
                   orbit_stability_sign_by_space_dimension={str(d): str(sp.sign(v)) for d, v in stab.items()}, metric_modes_by_dimension={str(D): v for D, v in dof.items()})


def RB():
    t, x, y, z = sp.symbols('t x y z'); X4 = [t, x, y, z]; lam = sp.Rational(3)
    g = sp.Matrix([[-(1 + x ** 2 / 3 + t / 5), t * x / 7, 0, 0], [t * x / 7, 1 + t * y / 4, 0, 0], [0, 0, 1 + x * z / 6, 0], [0, 0, 0, 1 + t ** 2 / 5 + y / 9]])
    pt = {t: sp.Rational(1, 2), x: sp.Rational(1, 3), y: sp.Rational(-1, 4), z: sp.Rational(2, 5)}
    G1 = christoffel(g, X4); G2 = christoffel(lam ** 2 * g, X4)
    chr_diff = max(abs(at(G1[a][b][c] - G2[a][b][c], pt)) for a, b, c in itertools.product(range(4), repeat=3))
    # third-jet natural term X^a_bc = delta^a_b d_c R: weight lambda^-2
    Rm1 = riemann(G1, X4); Ric1 = ricci(Rm1, 4); Rs1 = sp.together(sum((g.inv())[a, b] * Ric1[a, b] for a in range(4) for b in range(4)))
    Rs2 = Rs1 / lam ** 2                                                   # exact consequence checked next
    Rm2 = riemann(G2, X4); Ric2 = ricci(Rm2, 4)
    ric_diff = max(abs(at(Ric1[a, b] - Ric2[a, b], pt)) for a in range(4) for b in range(4))
    Rs2_direct = sp.together(sum(((lam ** 2 * g).inv())[a, b] * Ric2[a, b] for a in range(4) for b in range(4)))
    scal_ratio = sp.nsimplify(at(Rs2_direct, pt) / at(Rs1, pt))
    dR1 = [at(sp.diff(Rs1, v), pt) for v in X4]; dR2 = [at(sp.diff(Rs2_direct, v), pt) for v in X4]
    third_jet_ratio = {sp.nsimplify(b / a) for a, b in zip(dR1, dR2) if a != 0}
    # three-dimensional orientation term eps^a_bc: weight lambda^1
    g3 = sp.Matrix([[1 + x ** 2 / 3, x * y / 5, 0], [x * y / 5, 1 + y / 4, 0], [0, 0, 1 + x / 7]]); p3 = {x: sp.Rational(1, 3), y: sp.Rational(1, 2)}
    def eps_up(gm):
        gm = gm.subs(p3); vol = sp.sqrt(gm.det()); gi = gm.inv()
        return [[[sum(gi[a, d] * vol * sp.LeviCivita(d, b, c) for d in range(3)) for c in range(3)] for b in range(3)] for a in range(3)]
    e1, e2 = eps_up(g3), eps_up(lam ** 2 * g3)
    eps_ratio = {sp.nsimplify(e2[a][b][c] / e1[a][b][c]) for a, b, c in itertools.product(range(3), repeat=3) if e1[a][b][c] != 0}
    # the scale-free alternative eps grad R / R is undefined in vacuum: Schwarzschild has R = 0 identically
    r, th = sp.symbols('r theta', positive=True); f = 1 - 2 / r
    gs = sp.diag(-f, 1 / f, r ** 2, r ** 2 * sp.sin(th) ** 2); Xs = [t, r, th, sp.Symbol('phi')]
    Gs = christoffel(gs, Xs); Rms = riemann(Gs, Xs); Rics = ricci(Rms, 4)
    Rs_schw = sp.simplify(sum(gs.inv()[a, b] * Rics[a, b] for a in range(4) for b in range(4)))
    # independent route: exact invariants of a general (1,2) tensor
    inv = {'so(1,3)': invariant_rank3([-1, 1, 1, 1]), 'so(4)': invariant_rank3([1, 1, 1, 1]), 'so(3)': invariant_rank3([1, 1, 1]),
           'so(2)': invariant_rank3([1, 1]), 'so(1,4)': invariant_rank3([-1, 1, 1, 1, 1])}
    ok = chr_diff == 0 and ric_diff == 0 and scal_ratio == sp.Rational(1, 9) and third_jet_ratio == {sp.Rational(1, 9)} and eps_ratio == {lam} \
        and Rs_schw == 0 and inv['so(1,3)'] == 0 and inv['so(4)'] == 0 and inv['so(1,4)'] == 0 and inv['so(3)'] == 1 and inv['so(2)'] == 0
    must(ok, 'RB')
    R['RB'] = dict(claim='Connection. On a four-dimensional Lorentzian metric depending on all four coordinates, at a rational point, exactly: the '
                         'Christoffel symbols and the Ricci tensor of 9g equal those of g (weight 0), while the scalar curvature and its '
                         'gradient, the input of any third-jet term such as delta^a_b d_c R, scale by 1/9 (weight -2). In three '
                         'dimensions the orientation term eps^a_bc scales by 3 (weight 1). Each alternative to Levi-Civita therefore '
                         'needs a coefficient carrying a length, an internal unit. The scale-free combination eps^a_bcd grad^d R / R is '
                         'undefined in vacuum: the Schwarzschild scalar curvature is 0 identically (canary). Independent route: the exact '
                         'invariance equations for a general tensor C^a_bc (no symmetry assumed) leave no invariant under so(1,3), so(4), '
                         'so(1,4) and so(2), and one (eps) under so(3).',
                   status='PROVED (unit lemma) + computed (exact)', christoffel_change=str(chr_diff), ricci_change=str(ric_diff),
                   scalar_curvature_ratio=str(scal_ratio), third_jet_ratio=[str(v) for v in third_jet_ratio], orientation_term_ratio=[str(v) for v in eps_ratio],
                   schwarzschild_scalar_curvature=str(Rs_schw), invariants_of_general_rank3_tensor=inv)


# ============================================================================================ RC
def RC():
    """Connection: what free fall fixes, and a finite exact certificate for the Lorentz route."""
    xs = sp.symbols('c0:64'); C = lambda a, b, c: xs[16 * a + 4 * b + c]        # C_abc = g_ad C^d_bc, b the derivative index
    trip = list(itertools.product(range(4), repeat=3))
    met = [C(a, b, c) + C(c, b, a) for a, b, c in trip]
    tor = [C(a, b, c) - C(a, c, b) for a, b, c in trip]
    geo = [C(a, b, c) + C(a, c, b) for a, b, c in trip]
    def free(eq):
        A, _ = sp.linear_eq_to_matrix(eq, xs); return 64 - A.rank()
    dims = dict(metric_compatible=free(met), plus_torsion_free=free(met + tor), plus_same_free_fall=free(met + geo))
    # an axial (totally antisymmetric) difference changes no free fall but changes the closure of small parallelograms
    rng = np.random.default_rng(SEED)
    eps = np.zeros((4, 4, 4, 4))
    for p in itertools.permutations(range(4)):
        eps[p] = round(np.linalg.det(np.eye(4)[list(p)]))
    Cl = 0.3 * np.einsum('abcd,d->abc', eps, np.array([1.0, 0.2, -0.1, 0.4]))
    Cup = np.einsum('ad,dbc->abc', np.diag([-1.0, 1, 1, 1]), Cl)
    v, w = rng.normal(size=4), rng.normal(size=4)
    accel = float(np.linalg.norm(np.einsum('abc,b,c->a', Cup, v, v)))
    closure = float(np.linalg.norm(np.einsum('abc,b,c->a', Cup - Cup.swapaxes(1, 2), v, w)))
    # finite certificate: rational proper orthochronous transformations, general C^a_bc (64 unknowns, no symmetry)
    eta = sp.diag(-1, 1, 1, 1); Qs = []
    for j in (1, 2, 3):
        Q = sp.eye(4); Q[0, 0] = Q[j, j] = sp.Rational(5, 3); Q[0, j] = Q[j, 0] = sp.Rational(4, 3); Qs.append(Q)
    for i, j in ((1, 2), (2, 3), (1, 3)):
        Q = sp.eye(4); Q[i, i] = Q[j, j] = -1; Qs.append(Q)
    ys = sp.symbols('y0:64'); T = lambda a, b, c: ys[16 * a + 4 * b + c]; eqs = []
    for Q in Qs:
        assert Q.T * eta * Q == eta and Q.det() == 1 and Q[0, 0] > 0
        Qi = Q.inv()
        for a, b, c in trip:
            eqs.append(sum(Q[a, d] * Qi[e, b] * Qi[f, c] * T(d, e, f) for d in range(4) for e in range(4) for f in range(4)) - T(a, b, c))
    A, _ = sp.linear_eq_to_matrix(eqs, ys); finite_nullity = 64 - A.rank()
    ok = dims == dict(metric_compatible=24, plus_torsion_free=0, plus_same_free_fall=4) and accel < 1e-12 and closure > 0.01 and finite_nullity == 0
    must(ok, 'RC')
    R['RC'] = dict(claim='What free fall fixes. Exact dimensions of the difference between a metric-compatible connection and '
                         'Levi-Civita: 24 in general, 0 if torsion-free, 4 if it has the same free-fall paths (a totally antisymmetric '
                         'torsion). An axial example leaves free fall unchanged (below 1e-12) and opens small parallelograms. '
                         'Certificate for the Lorentz route: six rational proper orthochronous transformations (three boosts with '
                         'entries 5/3, 4/3 and three half-turns) leave no invariant general tensor C^a_bc (64 unknowns, exact).',
                   status='computed (exact)', dimensions=dims, axial_free_fall_change=below(accel, 1e-12), axial_parallelogram_defect=fl(closure),
                   finite_certificate_nullity=int(finite_nullity))


def covariant_divergence(T_up_down, G, X):
    """(div T)_b = d_a T^a_b + G^a_ad T^d_b - G^d_ab T^a_d for a mixed tensor T^a_b."""
    n = len(X)
    return [sum(sp.diff(T_up_down[a, b], X[a]) for a in range(n)) + sum(G[a][a][d] * T_up_down[d, b] for a in range(n) for d in range(n))
            - sum(G[d][a][b] * T_up_down[a, d] for a in range(n) for d in range(n)) for b in range(n)]


def RD():
    t, x = sp.symbols('t x'); y, z = sp.symbols('y z'); X = [t, x, y, z]; lam = sp.Rational(3)
    g = sp.diag(-(1 + x ** 2 / 3 + t / 5), 1 + t * x / 4, 1 + x / 7, 1 + t ** 2 / 6)
    pt = {t: sp.Rational(1, 2), x: sp.Rational(1, 3), y: 0, z: 0}
    def tensors(gm):
        G = christoffel(gm, X); Rm = riemann(G, X); Ric = ricci(Rm, 4); gi = gm.inv()
        Rs = sp.together(sum(gi[a, b] * Ric[a, b] for a in range(4) for b in range(4)))
        Ein = Ric - gm * Rs / 2
        return G, Rm, Ric, Rs, Ein, gi
    G1, Rm1, Ric1, Rs1, E1, gi1 = tensors(g); G2, Rm2, Ric2, Rs2, E2, gi2 = tensors(lam ** 2 * g)
    ev = lambda A: A.subs(pt).applyfunc(sp.nsimplify)
    ein_change = ev(E1 - E2) == sp.zeros(4)
    lam_term = sp.nsimplify((ev(lam ** 2 * g) [0, 0]) / ev(g)[0, 0])
    q1 = ev(Rs1 * Ric1); q2 = ev(Rs2 * Ric2)
    quad_ratio = {sp.nsimplify(q2[a, b] / q1[a, b]) for a in range(4) for b in range(4) if q1[a, b] != 0}
    # Lanczos (Gauss-Bonnet) tensor at the point: algebraic in Riemann, weight -2
    def lanczos(Rm, gm, gi):
        P = {k: sp.nsimplify(v) for k, v in pt.items()}
        Rl = [[[[sp.nsimplify(sum(gm[a, e] * Rm[e][b][c][d] for e in range(4)).subs(P)) for d in range(4)] for c in range(4)] for b in range(4)] for a in range(4)]
        G_ = gm.subs(P); Gi = gi.subs(P)
        up = lambda a, b: Gi[a, b]
        Ric = sp.Matrix(4, 4, lambda b, d: sum(Gi[a, c] * Rl[a][b][c][d] for a in range(4) for c in range(4)))
        Rs = sum(Gi[a, b] * Ric[a, b] for a in range(4) for b in range(4))
        RicUp = Gi * Ric * Gi
        Rsq = sum(Ric[a, b] * RicUp[a, b] for a in range(4) for b in range(4))
        RmUp = lambda a, b, c, d: sum(Gi[a, e] * Gi[b, f] * Gi[c, h] * Gi[d, k] * Rl[e][f][h][k] for e in range(4) for f in range(4) for h in range(4) for k in range(4))
        RU = [[[[RmUp(a, b, c, d) for d in range(4)] for c in range(4)] for b in range(4)] for a in range(4)]
        Kr = sum(Rl[a][b][c][d] * RU[a][b][c][d] for a, b, c, d in itertools.product(range(4), repeat=4))
        H = sp.zeros(4)
        for a in range(4):
            for b in range(4):
                H[a, b] = (Rs * Ric[a, b] - 2 * sum(Ric[a, c] * Gi[c, e] * Ric[e, b] for c in range(4) for e in range(4))
                           - 2 * sum(Rl[a][c][b][d] * RicUp[c, d] for c in range(4) for d in range(4))
                           + sum(Rl[a][c][d][e] * sum(Gi[c, c2] * Gi[d, d2] * Gi[e, e2] * Rl[b][c2][d2][e2] for c2 in range(4) for d2 in range(4) for e2 in range(4))
                                 for c in range(4) for d in range(4) for e in range(4))
                           - sp.Rational(1, 4) * G_[a, b] * (Rs ** 2 - 4 * Rsq + Kr))
        return H.applyfunc(sp.nsimplify)
    H1, H2 = lanczos(Rm1, g, gi1), lanczos(Rm2, lam ** 2 * g, gi2)
    lanczos_zero = H1 == sp.zeros(4)
    # divergence: Einstein tensor divergence-free, Ricci tensor not (exact at the point)
    Em = (gi1 * E1); Rmix = (gi1 * Ric1)
    divE = [sp.nsimplify(sp.together(v).subs(pt)) for v in covariant_divergence(Em, G1, X)]
    divR = [sp.nsimplify(sp.together(v).subs(pt)) for v in covariant_divergence(Rmix, G1, X)]
    curv_dim, eqv = equivariant_curvature_to_symmetric([-1, 1, 1, 1])
    ok = curv_dim == 20 and eqv == 2 and ein_change and lam_term == 9 and quad_ratio == {sp.Rational(1, 9)} and all(v == 0 for v in divE) and any(v != 0 for v in divR) and lanczos_zero
    must(ok, 'RD')
    R['RD'] = dict(claim='Response. The linear maps from algebraic curvature tensors (dimension 20) to symmetric 2-tensors that commute '
                         'with so(1,3) form a space of dimension 2, spanned by R_ab and R g_ab (exact). On a four-dimensional metric '
                         'depending on t and x, at a rational point, exactly: the Einstein tensor of 9g '
                         'equals that of g (weight 0); the cosmological term g_ab scales by 9 (weight 2), so Lambda carries a length; '
                         'the curvature-squared term R R_ab scales by 1/9 (weight -2), so any such term carries a length squared. The '
                         'Lanczos tensor vanishes identically in four dimensions (checked at the point). The covariant divergence of the '
                         'Einstein tensor is zero and that of the Ricci tensor is not: Einstein\'s Ricci law of November 1915 violates '
                         'balance (canary).',
                   status='PROVED (unit lemma) + computed (exact)', curvature_space_dimension=curv_dim, equivariant_linear_maps=eqv,
                   einstein_unchanged=bool(ein_change), cosmological_term_ratio=str(lam_term),
                   curvature_squared_ratio=[str(v) for v in quad_ratio], lanczos_zero_in_4d=bool(lanczos_zero),
                   divergence_einstein=[str(v) for v in divE], divergence_ricci=[str(v) for v in divR])


# ============================================================================================ RD extras
def kn(h, k):
    return (np.einsum('ac,bd->abcd', h, k) + np.einsum('bd,ac->abcd', h, k) - np.einsum('ad,bc->abcd', h, k) - np.einsum('bc,ad->abcd', h, k))


def lanczos_num(Rm, g):
    gi = np.linalg.inv(g)
    Ric = np.einsum('acbd,cd->ab', Rm, gi); Rs = np.einsum('ab,ab->', Ric, gi)
    Rup = np.einsum('abcd,ae,bf,cg,dh->efgh', Rm, gi, gi, gi, gi); Ricup = gi @ Ric @ gi
    GB = Rs ** 2 - 4 * np.einsum('ab,ab->', Ric, Ricup) + np.einsum('abcd,abcd->', Rm, Rup)
    H = Rs * Ric - 2 * Ric @ gi @ Ric - 2 * np.einsum('acbd,cd->ab', Rm, Ricup) + np.einsum('acde,bfgh,cf,dg,eh->ab', Rm, Rm, gi, gi, gi) - 0.25 * g * GB
    return H, GB


def RD2():
    """Cross-checks of the response: Lovelock's dimension, the linear limit, the order of R^2, the Newtonian limit."""
    rng = np.random.default_rng(SEED + 1); lov = {}
    for D in (4, 5, 6):
        for sig in ('Lorentzian', 'Euclidean'):
            g = np.diag([-1.0] + [1.0] * (D - 1)) if sig == 'Lorentzian' else np.eye(D); worst = scale = 0.0; gb = np.inf
            for _ in range(6):
                Rm = sum(kn(*(lambda s1, s2: (s1 + s1.T, s2 + s2.T))(rng.normal(size=(D, D)), rng.normal(size=(D, D)))) for _ in range(4))
                H, GB = lanczos_num(Rm, g); scale = max(scale, float(np.max(np.abs(Rm))) ** 2); worst = max(worst, float(np.max(np.abs(H)))); gb = min(gb, abs(GB))
            lov[f'D={D} {sig}'] = dict(lanczos=worst / scale, gauss_bonnet=gb / scale)
    lov_ok = all(lov[f'D=4 {s}']['lanczos'] < 1e-12 for s in ('Lorentzian', 'Euclidean')) and all(lov[f'D={D} {s}']['lanczos'] > 1e-3 for D in (5, 6) for s in ('Lorentzian', 'Euclidean')) \
        and lov['D=4 Euclidean']['gauss_bonnet'] > 1e-3
    # linear limit: the five-term two-derivative operator with gauge nullity and identical conservation
    eta = sp.diag(-1, 1, 1, 1); cs = sp.symbols('a1:6'); k = sp.Matrix(sp.symbols('k0:4')); xi = sp.Matrix(sp.symbols('xi0:4'))
    hs = sp.symbols('h0:10'); h = sp.zeros(4); m = 0
    for i in range(4):
        for j in range(i, 4):
            h[i, j] = h[j, i] = hs[m]; m += 1
    def E(kk, hh, c):
        ku = eta * kk; k2 = (kk.T * eta * kk)[0]; tr = (eta * hh).trace(); v = hh * ku; kk2 = (ku.T * hh * ku)[0]
        return c[0] * k2 * hh + c[1] * (kk * v.T + v * kk.T) + c[2] * (kk * kk.T) * tr + c[3] * eta * kk2 + c[4] * eta * k2 * tr
    conds = []
    for expr in list(E(k, k * xi.T + xi * k.T, cs)) + list((eta * k).T * E(k, h, cs)):
        conds += sp.Poly(sp.expand(expr), *(list(k) + list(xi) + list(hs))).coeffs()
    A, _ = sp.linear_eq_to_matrix(conds, cs); ns = A.nullspace(); direction = list(ns[0] / ns[0][0]) if len(ns) == 1 else None
    # the order of R^2: its field tensor is conserved like Einstein's but carries the fourth derivative
    t, x, y, z = X = sp.symbols('t x y z'); a = sp.Function('a')(t); N = sp.Function('N')(t)
    g = sp.diag(-N ** 2, a ** 2, a ** 2, a ** 2); gi = g.inv()
    Gm = [[[sp.simplify(sum(gi[p, d] * (sp.diff(g[d, b], X[c]) + sp.diff(g[d, c], X[b]) - sp.diff(g[b, c], X[d])) for d in range(4)) / 2) for c in range(4)] for b in range(4)] for p in range(4)]
    Rie = lambda p, b, c, d: sp.diff(Gm[p][b][d], X[c]) - sp.diff(Gm[p][b][c], X[d]) + sum(Gm[p][c][e] * Gm[e][b][d] - Gm[p][d][e] * Gm[e][b][c] for e in range(4))
    Ric = sp.Matrix(4, 4, lambda b, d: sp.simplify(sum(Rie(p, b, p, d) for p in range(4)))); Rs = sp.simplify(sum(gi[p, q] * Ric[p, q] for p in range(4) for q in range(4)))
    hess = lambda f: sp.Matrix(4, 4, lambda p, q: sp.simplify(sp.diff(f, X[p], X[q]) - sum(Gm[c][p][q] * sp.diff(f, X[c]) for c in range(4))))
    Hs = hess(Rs); box = sp.simplify(sum(gi[p, q] * Hs[p, q] for p in range(4) for q in range(4)))
    Ein = sp.simplify(Ric - Rs * g / 2); H2 = sp.simplify(2 * Rs * Ric - Rs ** 2 * g / 2 + 2 * (g * box - Hs))
    def div(T):
        cov = lambda mu, p, b: sp.diff(T[p, b], X[mu]) - sum(Gm[c][mu][p] * T[c, b] + Gm[c][mu][b] * T[p, c] for c in range(4))
        return [sp.simplify(sum(gi[mu, p] * cov(mu, p, nu) for mu in range(4) for p in range(4))) for nu in range(4)]
    order = lambda e: max([kk for kk in range(1, 6) if sp.simplify(e).has(sp.Derivative(a, (t, kk)))] + [0])
    r2_ok = all(v == 0 for v in div(Ein)) and all(v == 0 for v in div(H2)) and order(Ein[1, 1]) == 2 and order(H2[1, 1]) == 4
    # Newtonian limit: g = diag(-(1 + 2 e phi), (1 - 2 e phi) delta); G_00 = 2 e Laplacian(phi) + O(e^2)
    e = sp.Symbol('e'); phi = sp.Function('phi')(x, y, z)
    gN = sp.diag(-(1 + 2 * e * phi), 1 - 2 * e * phi, 1 - 2 * e * phi, 1 - 2 * e * phi); giN = gN.inv()
    GN = [[[sum(giN[p, d] * (sp.diff(gN[d, b], X[c]) + sp.diff(gN[d, c], X[b]) - sp.diff(gN[b, c], X[d])) for d in range(4)) / 2 for c in range(4)] for b in range(4)] for p in range(4)]
    RieN = lambda p, b, c, d: sp.diff(GN[p][b][d], X[c]) - sp.diff(GN[p][b][c], X[d]) + sum(GN[p][c][q] * GN[q][b][d] - GN[p][d][q] * GN[q][b][c] for q in range(4))
    RicN = sp.Matrix(4, 4, lambda b, d: sum(RieN(p, b, p, d) for p in range(4)))
    RsN = sum(giN[p, q] * RicN[p, q] for p in range(4) for q in range(4))
    G00 = sp.series(RicN[0, 0] - gN[0, 0] * RsN / 2, e, 0, 2).removeO()
    lap = sum(sp.diff(phi, v, 2) for v in (x, y, z))
    newton = sp.simplify(G00 - 2 * e * lap) == 0
    ok = lov_ok and direction == [1, -1, 1, 1, -1] and r2_ok and newton
    must(ok, 'RD2')
    R['RD2'] = dict(claim='Cross-checks of the response. (i) Lovelock\'s dimension: for random algebraic curvature tensors the Lanczos tensor '
                         'is zero to rounding in D = 4 (both signatures) and of order one in D = 5, 6; the Gauss-Bonnet scalar itself is '
                         'not zero in D = 4 (canary). (ii) Linear limit: a two-derivative operator on a symmetric field, built from five '
                         'Lorentz-covariant terms, that annihilates pure gauge and is identically conserved, is unique up to scale: '
                         '(1, -1, 1, 1, -1), the linearized Einstein operator (exact, arbitrary momentum and field). (iii) Order: on '
                         '-N(t)^2 dt^2 + a(t)^2 dx^2 the R^2 field tensor is conserved like the Einstein tensor but carries the fourth '
                         'derivative of a; the Einstein tensor stops at the second. (iv) Newtonian limit: for g = diag(-(1 + 2 phi), '
                         '(1 - 2 phi) delta) the time-time Einstein component is 2 Laplacian(phi) to first order, so G_00 = 8 pi G rho '
                         'is the Poisson equation.',
                   status='computed (exact except (i), numerical with residual)', lovelock={k: {a_: fl(b) for a_, b in v.items()} for k, v in lov.items()},
                   linear_direction=[str(v) for v in direction] if direction else None, r2_order=dict(einstein=order(Ein[1, 1]), r_squared=order(H2[1, 1])),
                   newton_limit=bool(newton))


# ============================================================================================ RF
def RF():
    GM, c = 1.32712440018e20, 299792458.0
    a_m, e_m, P_m = 5.7909050e10, 0.205630, 87.9691
    per_orbit = 6 * math.pi * GM / (c * c * a_m * (1 - e_m ** 2)); mercury = per_orbit * (36525 / P_m) * 180 / math.pi * 3600
    R_sun = 6.957e8; deflection = 4 * GM / (c * c * R_sun) * 180 / math.pi * 3600
    GM_e, a_gps = 3.986004418e14, 2.6560e7
    W0 = 62636856.0                                             # geoid potential, gravity plus rotation, m^2 s^-2
    gps = W0 / (c * c) - 1.5 * GM_e / (a_gps * c * c)
    f_factory = 10.23e6 * (1 - gps)
    pound = 9.80665 * 22.5 / (c * c)
    w = sp.symbols('omega', positive=True); gamma = (1 + w) / (2 + w)
    wmin = float(sp.solve(sp.Eq(gamma - 1, -2.5e-5), w)[0])
    canary = dict(mercury_4pi=fl(mercury * 4 / 6), deflection_newton=fl(deflection / 2))
    ok = abs(mercury - 42.98) < 0.02 and abs(deflection - 1.7512) < 0.0005 and abs(gps - 4.4647e-10) < 3e-12 and abs(pound - 2.455e-15) < 1e-17 \
        and 39990 < wmin < 40010 and abs(mercury * 4 / 6 - 43.11) > 10 and abs(deflection / 2 - 1.7512) > 0.5
    must(ok, 'RF')
    R['RF'] = dict(claim='Tests. With GM of the Sun and the Earth from Kepler orbits and nothing relativistic fitted: Mercury\'s perihelion '
                         'advance, solar-limb deflection, the GPS clock offset (and the factory frequency it implies) and the Pound-Rebka '
                         'shift, all against their measured values in the print. A Brans-Dicke scalar gives gamma = (1 + omega)/(2 + '
                         'omega); the Cassini window needs omega >= 39 998. Canaries: 4 pi in place of 6 pi gives 28.65 arcsec per century; '
                         'the Newtonian factor gives half the deflection.',
                   status='computed', mercury_arcsec_per_century=fl(mercury), deflection_arcsec=fl(deflection), gps_rate_offset=fl(gps),
                   gps_factory_frequency_hz=float(f'{f_factory:.12g}'), pound_rebka=fl(pound), brans_dicke_omega_min=fl(wmin), canaries=canary)


def kato(P, Pd):
    return Pd @ P - P @ Pd


def thomas(v, chiral=0.0):
    eta = np.diag([-1.0, 1, 1, 1]); g = 1 / math.sqrt(1 - v * v)
    eps = np.zeros((4, 4, 4, 4))
    for p in itertools.permutations(range(4)):
        eps[p] = round(np.linalg.det(np.eye(4)[list(p)]))
    def uu(t):
        return g * np.array([1.0, -v * math.sin(t), v * math.cos(t), 0.0])
    def ud(t):
        return g * np.array([0.0, -v * math.cos(t), -v * math.sin(t), 0.0])
    def rhs(t, z):
        u, a = uu(t), ud(t); P = np.eye(4) + np.outer(u, u) @ eta; Pd = (np.outer(a, u) + np.outer(u, a)) @ eta
        D = chiral * eta @ np.einsum('abcd,c,d->ab', eps, u, a)
        return (kato(P, Pd) + D) @ z
    e1 = np.array([0.0, 1.0, 0.0, 0.0]); e2 = np.array([g * v, 0.0, g, 0.0])
    s = solve_ivp(rhs, [0, 2 * np.pi], e1, rtol=1e-12, atol=1e-13, max_step=0.01)
    zf = s.y[:, -1]; return float(math.atan2(zf @ eta @ e2, zf @ eta @ e1)), g, float(abs(zf @ eta @ zf - 1))


def geodetic(Rr, M=1.0):
    Om = math.sqrt(M / Rr ** 3); ut = 1 / math.sqrt(1 - 3 * M / Rr); up = Om * ut; f = 1 - 2 * M / Rr
    G = np.zeros((4, 4, 4))
    G[0, 0, 1] = G[0, 1, 0] = M / (Rr * Rr * f)
    G[1, 0, 0] = M * f / Rr ** 2; G[1, 1, 1] = -M / (Rr * Rr * f); G[1, 3, 3] = -Rr * f
    G[3, 1, 3] = G[3, 3, 1] = 1 / Rr
    u = np.array([ut, 0, 0, up]); A = -np.einsum('mab,a->mb', G, u)
    gmet = np.diag([-f, 1 / f, Rr * Rr, Rr * Rr])
    er = np.array([0, math.sqrt(f), 0, 0]); v = Om * Rr / math.sqrt(f); gam = 1 / math.sqrt(1 - v * v)
    eph = np.array([gam * v / math.sqrt(f), 0, 0, gam / Rr])
    T = 2 * np.pi / up; ts = np.linspace(0, T, 4001)
    s = solve_ivp(lambda tau, z: A @ z, [0, T], er, t_eval=ts, rtol=1e-12, atol=1e-14, max_step=T / 2000)
    ang = np.unwrap(np.arctan2(np.array([zz @ gmet @ eph for zz in s.y.T]), np.array([zz @ gmet @ er for zz in s.y.T])))
    P = np.eye(4) + np.outer(u, gmet @ u); DP = np.einsum('mab,a->mb', G, u) @ P - P @ np.einsum('mab,a->mb', G, u)
    return float(2 * np.pi + ang[-1] - ang[0]), float(abs(s.y[:, -1] @ gmet @ u)), float(np.abs(kato(P, DP)).max())


def projector_term_off_geodesic(Rr=10.0, factor=1.2, M=1.0):
    f = 1 - 2 * M / Rr; Om = factor * math.sqrt(M / Rr ** 3); ut = 1 / math.sqrt(f - Rr * Rr * Om * Om); u = np.array([ut, 0, 0, Om * ut])
    G = np.zeros((4, 4, 4))
    G[0, 0, 1] = G[0, 1, 0] = M / (Rr * Rr * f)
    G[1, 0, 0] = M * f / Rr ** 2; G[1, 1, 1] = -M / (Rr * Rr * f); G[1, 3, 3] = -Rr * f
    G[3, 1, 3] = G[3, 3, 1] = 1 / Rr
    gmet = np.diag([-f, 1 / f, Rr * Rr, Rr * Rr]); P = np.eye(4) + np.outer(u, gmet @ u); A = np.einsum('mab,a->mb', G, u)
    return float(np.abs(kato(P, A @ P - P @ A)).max())


def RE():
    th = {}
    for v in (0.1, 0.5, 0.8, 0.94):
        ang, gm, nerr = thomas(v); th[v] = dict(angle=ang, predicted=wrap(2 * np.pi * (1 - gm)), norm_error=nerr)
    chi = thomas(0.5, chiral=0.3)[0]
    geo = {}
    for x in (6.0, 10.0, 20.0, 50.0):
        p, orth, kt = geodetic(x); geo[x] = dict(per_orbit=p, exact=2 * np.pi * (1 - math.sqrt(1 - 3 / x)), orthogonality=orth, kato_term=kt)
    off = projector_term_off_geodesic()
    GM = 3.986004418e14; c = 299792458.0; r = 6378137.0 + 642e3; Mg = GM / c ** 2; T = 2 * np.pi * math.sqrt(r ** 3 / GM)
    year = 365.25 * 86400; mas = 180 / np.pi * 3600e3
    ours = 2 * np.pi * (1 - math.sqrt(1 - 3 * Mg / r)) * (year / T) * mas
    meas, sig, full = 6601.8, 18.3, 6606.1
    conv = lambda m: m / (mas * year)
    interval_full = [conv(meas - full - 1.96 * sig), conv(meas - full + 1.96 * sig)]
    interval_ours = [conv(meas - ours - 1.96 * sig), conv(meas - ours + 1.96 * sig)]
    ok = all(abs(wrap(d['angle'] - d['predicted'])) < 1e-8 and d['norm_error'] < 1e-8 for d in th.values()) and abs(wrap(chi - th[0.5]['predicted'])) > 0.05 \
        and all(abs(d['per_orbit'] - d['exact']) < 1e-8 and d['orthogonality'] < 1e-9 and d['kato_term'] < 1e-12 for d in geo.values()) and off > 1e-3 \
        and interval_full[0] < 0 < interval_full[1] and abs((ours - meas) / sig) < 2
    must(ok, 'RE')
    R['RE'] = dict(claim='Observers. With the connection fixed, a torque-free gyroscope does not rotate within its rest space; the '
                         'resulting law is Fermi-Walker transport, which is the minimum-motion (Kato) transport of the rest-space '
                         'projector. It gives the Thomas angle 2 pi (1 - gamma) at v = 0.1, 0.5, 0.8, 0.94 to 1e-8, and the geodetic '
                         'angle 2 pi (1 - sqrt(1 - 3M/r)) per circular orbit at r = 6M to 50M to 1e-8. The Kato term vanishes on the '
                         'geodesic (below 1e-12) and not on a powered orbit. A parity-odd acceleration term c eps(., ., u, a), with c '
                         'dimensionless and natural under proper Lorentz transformations, changes the Thomas angle: the torque-free '
                         'premise is needed and is not implied by the weight argument. Gravity Probe B: this model (spherical Earth, '
                         'circular 642 km orbit) gives the value below; the signed 95 per cent interval for an additive rate is computed '
                         'from the residual, not centred on zero.',
                   status='computed; IDENTIFIED (Thomas 1926; de Sitter 1916); MEASURED anchor (Everitt et al. 2011)',
                   thomas={str(k): {a: fl(b) for a, b in d.items()} for k, d in th.items()}, thomas_with_chiral_term=fl(chi),
                   geodetic={str(k): {a: fl(b) for a, b in d.items()} for k, d in geo.items()}, kato_term_powered_orbit=fl(off),
                   gpb=dict(model_mas_per_yr=fl(ours), measured=[meas, sig], experiment_gr_value=full, model_minus_measured_sigma=fl((ours - meas) / sig),
                            signed_95_interval_rad_per_s_vs_experiment_gr=[fl(v) for v in interval_full], signed_95_interval_rad_per_s_vs_model=[fl(v) for v in interval_ours]))


if __name__ == '__main__':
    for name, fn in (('RA', RA), ('RB', RB), ('RC', RC), ('RD', RD), ('RD2', RD2), ('RE', RE), ('RF', RF)):
        try:
            fn()
        except Exception as e:                                             # a crash is a failure of its group
            must(False, name); R[name] = dict(crash=repr(e))
        print(name, flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(open(os.path.abspath(__file__), 'rb').read()).hexdigest()
    json.dump(out, open(os.path.join(HERE, 'rg_gr_derivation_results.json'), 'w'), indent=1, sort_keys=True)
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
