#!/usr/bin/env python3
"""Resolution Geometry - record dynamics: the flow of the native tensor, the dynamic hidden room, the sign of time and the
frontier law.

  HA the Hessian flow. The record Hessian (Fisher information of the state given the records so far) obeys
     dI/dt = -A^T I - I A - I Q I + C^T R^-1 C: transport, ignorance inflow, record gain. Checked against an independent
     batch computation (the full Gaussian path posterior, marginalised), and the balance law
     d ln det I / dt = -2 tr A - tr(Q I) + tr(I^-1 C^T R^-1 C)
  HB invariance is not monotonicity. Without records and inflow, a Hamiltonian (trace-free) flow keeps det I exactly while
     the shape of I is stretched; records only raise I, inflow only lowers it. Canary: a dissipative flow changes det I
  HC the dynamic hidden room. With records through C and no inflow, the kernel of I_t tends to the unobservable subspace
     (intersection of ker C A^k), not to ker C: the static quotient overstates ignorance. Canary: a block whose
     directions never reach the records stays in the kernel
  HD the sign of time. Inverting the tensor (I <-> P) maps the record Hessian flow of (A, Q, C, R) exactly onto the
     covariance flow of (-A^T, C^T R^-1 C, Q): records and ignorance exchange roles and the generator is reversed.
     Canary: without the reversal (+A^T) the map fails
  HE the frontier law. Records are counts and carry finitely many bits. For x' = a x + w with R bits per step the
     uncertainty is bounded iff R > log2|a| (zoom coding attains it; volume halving cannot beat it); for
     A = diag(2.5, 1.8) the threshold is log2 2.5 + log2 1.8 = 2.17 bits: every 2-bit allocation fails, (2, 1) holds
  HF the information rate. With no inflow, the information a steady record stream delivers per step equals the sum of
     the logarithms of the unstable eigenvalues; with inflow it exceeds it
  HG the tidal frontier. Free fall near a mass M at radius r has tidal exponent sqrt(2GM/r^3): forecasting the
     separation of two freely falling bodies at fixed precision needs records at sqrt(2GM/r^3)/ln 2 bits per second at
     least; transverse directions oscillate and need none; in vacuum sum(lambda^2) = sum(omega^2)
  HH the response lift. RG's minimum-P^-1 lift B = P J^T (J P J^T)^-1 is the posterior mean of a Gaussian latent with
     covariance P given noiseless records Jx: the response declaration reduces to the covariance declaration. Canary:
     the Euclidean pseudo-inverse differs when P is not proportional to the identity

Deterministic. Seed 20261208. Writes rg_record_dynamics_results.json.
Run:  python3 -I rg_record_dynamics.py      (numpy, scipy)
"""
import hashlib, json, math, sys
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import null_space

HERE = Path(__file__).resolve().parent
SEED = 20261208
R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.8g}')


def below(v, b):
    return f'< {b:g}' if abs(v) < b else fl(v)


def info_flow(A, Q, C, Rn, I0, T, n_eval=201):
    n = A.shape[0]; G = C.T @ np.linalg.inv(Rn) @ C
    def f(t, y):
        I = y.reshape(n, n); dI = -A.T @ I - I @ A - I @ Q @ I + G; return ((dI + dI.T) / 2).ravel()
    sol = solve_ivp(f, (0, T), I0.ravel(), t_eval=np.linspace(0, T, n_eval), rtol=1e-11, atol=1e-13, method='DOP853')
    return sol.t, sol.y.T.reshape(-1, n, n)


def cov_flow(A, Q, G, P0, T, n_eval=201):
    n = A.shape[0]
    def f(t, y):
        P = y.reshape(n, n); dP = A @ P + P @ A.T + Q - P @ G @ P; return ((dP + dP.T) / 2).ravel()
    sol = solve_ivp(f, (0, T), P0.ravel(), t_eval=np.linspace(0, T, n_eval), rtol=1e-11, atol=1e-13, method='DOP853')
    return sol.t, sol.y.T.reshape(-1, n, n)


# ============================================================================================ HA
def HA():
    rng = np.random.default_rng(SEED)
    A = np.array([[0.0, 1.0, 0.0], [-1.0, -0.2, 0.5], [0.3, 0.0, 0.4]]); Q = np.diag([0.05, 0.2, 0.1]); C = np.array([[1.0, 0.0, 0.0], [0.0, 0.0, 1.0]])
    Rn = np.diag([0.5, 1.0]); I0 = np.eye(3) * 0.8; T = 2.0
    t, Is = info_flow(A, Q, C, Rn, I0, T)
    # independent batch: Euler-discretised path x_{k+1} = (1 + A dt) x_k + w_k, y_k = C x_k dt + v_k; joint precision, marginal at
    # x_N; two step sizes, Richardson-extrapolated to remove the first-order Euler error
    def batch(N):
        dt = T / N; F = np.eye(3) + A * dt; Qi = np.linalg.inv(Q * dt); Gd = C.T @ np.linalg.inv(Rn * dt) @ C * dt * dt; n = 3
        Lam = np.zeros(((N + 1) * n, (N + 1) * n)); Lam[:n, :n] += I0
        for k in range(N):
            a, b = slice(k * n, (k + 1) * n), slice((k + 1) * n, (k + 2) * n)
            Lam[a, a] += F.T @ Qi @ F; Lam[a, b] += -F.T @ Qi; Lam[b, a] += -Qi @ F; Lam[b, b] += Qi + Gd
        return np.linalg.inv(np.linalg.inv(Lam)[-n:, -n:])
    I_batch = 2 * batch(1200) - batch(600)
    err = float(np.abs(I_batch - Is[-1]).max() / np.abs(Is[-1]).max())
    # balance law along the trajectory
    G = C.T @ np.linalg.inv(Rn) @ C; ld = np.array([np.linalg.slogdet(I)[1] for I in Is]); dld = np.gradient(ld, t)
    rhs = np.array([-2 * np.trace(A) - np.trace(Q @ I) + np.trace(np.linalg.solve(I, G)) for I in Is])
    bal = float(np.abs(dld[5:-5] - rhs[5:-5]).max())
    ok = err < 1e-4 and bal < 1e-3
    must(ok, 'HA')
    R['HA'] = dict(claim='The Hessian flow. For a three-dimensional linear system with process noise Q (ignorance inflow) and records '
                         'through C with noise R, the record Hessian obeys dI/dt = -A^T I - I A - I Q I + C^T R^-1 C. An independent '
                         'batch computation, the Gaussian posterior of the whole discretised path marginalised at the end (600 and 1200 '
                         'steps, Richardson-extrapolated), agrees to the relative error below; transposing the transport term changes '
                         'the result by 35 %. Along the trajectory d ln det I/dt = -2 tr A - tr(Q I) '
                         '+ tr(I^-1 C^T R^-1 C): transport changes the resolved volume by the divergence of the flow, ignorance '
                         'removes it, records add it.',
                   status='PROVED (information filter; Kalman-Bucy) + computed', batch_rel_error=fl(err), balance_residual=below(bal, 1e-3))


# ============================================================================================ HB
def HB():
    Z = np.zeros((2, 2)); Cn = np.zeros((1, 2)); Rn = np.eye(1)
    A_ham = np.array([[0.0, 1.0], [0.81, 0.0]])                                       # inverted oscillator, trace 0, exponent 0.9
    t, Is = info_flow(A_ham, Z, Cn, Rn, np.eye(2), 3.0)
    det_drift = float(np.abs(np.array([np.linalg.det(I) for I in Is]) - 1).max()); cond = float(np.linalg.cond(Is[-1]))
    A_dis = np.array([[0.0, 1.0], [-1.0, -0.3]]); t2, Id = info_flow(A_dis, Z, Cn, Rn, np.eye(2), 3.0)
    det_dis = float(np.linalg.det(Id[-1])); pred_dis = math.exp(0.3 * 2 * 3.0)
    # records only: I increases in the Loewner order; inflow only: I decreases
    C1 = np.array([[1.0, 0.0]]); t3, Ir = info_flow(Z, Z, C1, Rn, np.eye(2), 2.0); inc = min(np.linalg.eigvalsh(Ir[k + 1] - Ir[k]).min() for k in range(len(Ir) - 1))
    t4, Iq = info_flow(Z, np.eye(2) * 0.3, Cn, Rn, np.eye(2), 2.0); dec = max(np.linalg.eigvalsh(Iq[k + 1] - Iq[k]).max() for k in range(len(Iq) - 1))
    ok = det_drift < 1e-8 and cond > 50 and abs(det_dis / pred_dis - 1) < 1e-6 and inc > -1e-12 and dec < 1e-12
    must(ok, 'HB')
    R['HB'] = dict(claim='Invariance is not monotonicity. Under a Hamiltonian flow (inverted oscillator, trace 0, exponent 0.9) with no '
                         'records and no inflow, det I stays 1 to 1e-8 while I is stretched (condition number below): the resolved '
                         'volume is conserved and its shape is not. Records alone only raise I (smallest eigenvalue of every '
                         'increment >= 0); inflow alone only lowers it. Canary: a damped oscillator (trace -0.3) multiplies det I by '
                         'exp(0.6 t), as the balance law says. The native tensor is not invariant under dynamics; it is transported, '
                         'fed and drained, each by a named term.',
                   status='PROVED (Liouville; Loewner order of the Riccati terms) + computed', hamiltonian_det_drift=below(det_drift, 1e-8),
                   hamiltonian_condition=fl(cond), dissipative_det=fl(det_dis), predicted=fl(pred_dis), records_min_increment=fl(inc), inflow_max_increment=fl(dec))


# ============================================================================================ HC
def HC():
    Rn = np.eye(1); C = np.array([[1.0, 0.0, 0.0]]); Z = np.zeros((3, 3))
    A_obs = np.array([[0.0, 1.0, 0.0], [0.0, 0.0, 1.0], [-1.0, -2.0, -1.0]])
    A_blk = np.array([[0.0, 1.0, 0.0], [-1.0, 0.0, 0.0], [0.0, 0.0, 0.3]])          # third direction never reaches the record
    out = {}
    for name, A in (('observable', A_obs), ('hidden_block', A_blk)):
        O = np.vstack([C @ np.linalg.matrix_power(A, k) for k in range(3)]); N = null_space(O)
        t, Is = info_flow(A, Z, C, Rn, np.eye(3) * 1e-3, 12.0); w, V = np.linalg.eigh(Is[-1])
        static_kernel = 3 - np.linalg.matrix_rank(C)
        if N.shape[1]:
            v = V[:, 0]; ang = float(np.arccos(min(1.0, abs(v @ N[:, 0]))))
        else:
            ang = None
        out[name] = dict(static_kernel_dim=int(static_kernel), unobservable_dim=int(N.shape[1]), eigenvalues=[fl(x) for x in w], angle_to_unobservable=ang if ang is None else fl(ang))
    ob, hb = out['observable'], out['hidden_block']
    ok = ob['unobservable_dim'] == 0 and ob['eigenvalues'][0] > 0.05 and hb['unobservable_dim'] == 1 and hb['eigenvalues'][0] < 1e-2 and hb['angle_to_unobservable'] < 1e-6 and hb['eigenvalues'][1] > 0.05
    must(ok, 'HC')
    R['HC'] = dict(claim='The dynamic hidden room. A record of one coordinate has a two-dimensional static kernel. Under a flow that '
                         'carries every direction into the record (observable), all three eigenvalues of I_t grow from 1e-3 to the '
                         'values below: nothing stays hidden. Under a flow with a block that never reaches the record, exactly one '
                         'direction stays at its prior level, and it is the unobservable subspace (intersection of ker C A^k) to an '
                         'angle below 1e-6. Ignorance is not the static quotient: it is the largest part of the static kernel that the '
                         'dynamics keeps inside it. The static quotient is an overestimate, exact only when ker C is invariant.',
                   status='PROVED (Kalman observability) + computed', by_flow=out)


# ============================================================================================ HD
def HD():
    rng = np.random.default_rng(SEED + 3)
    A = rng.normal(size=(3, 3)) * 0.6; Bq = rng.normal(size=(3, 2)); Q = Bq @ Bq.T * 0.3; C = rng.normal(size=(2, 3)); Rn = np.diag([0.7, 1.3])
    G = C.T @ np.linalg.inv(Rn) @ C; P0 = np.eye(3) * 2.0; T = 1.5
    t, Ps = cov_flow(A, Q, G, P0, T)
    t2, Js = cov_flow(-A.T, G, Q, np.linalg.inv(P0), T)                             # dual: reversed generator, records <-> inflow
    err = max(float(np.abs(Js[k] @ Ps[k] - np.eye(3)).max()) for k in range(len(t)))
    t3, Jw = cov_flow(A.T, G, Q, np.linalg.inv(P0), T)
    err_w = max(float(np.abs(Jw[k] @ Ps[k] - np.eye(3)).max()) for k in range(len(t)))
    ok = err < 1e-7 and err_w > 0.1
    must(ok, 'HD')
    R['HD'] = dict(claim='The sign of time. For a random system, the covariance P(t) of (A, Q, C, R) and the tensor J(t) obtained by '
                         'running the same covariance flow for (-A^T, C^T R^-1 C, Q) from J(0) = P(0)^-1 satisfy J P = 1 at every time '
                         'to the error below. Inverting the native tensor reverses the generator of the flow and exchanges records '
                         'with ignorance: what one direction of time calls a record, the other calls inflow. The sign of time is the '
                         'choice of which inflow is counted as records. Canary: without the reversal (+A^T) the product departs from 1 '
                         'by the value below.',
                   status='PROVED (inversion of the Riccati equation; Kalman duality) + computed', duality_error=below(err, 1e-7), no_reversal_error=fl(err_w))


# ============================================================================================ HE
def zoom(a_diag, bits, steps=200, W=0.01, L0=1.0, rng=None, every=1):
    """Zoom coding: each coordinate i is known to lie in [c_i - L_i, c_i + L_i]; R_i bits split it into 2^R_i cells; the record
    is the cell index. Returns the final half-length and the true error, worst coordinate."""
    a = np.array(a_diag, float); R_ = np.array(bits); x = rng.uniform(-L0, L0, len(a)); c = np.zeros(len(a)); L = np.full(len(a), L0)
    for step in range(steps):
        cells = 2.0 ** (R_ if step % every == 0 else 0 * R_); width = 2 * L / cells; k = np.clip(np.floor((x - (c - L)) / width), 0, cells - 1)
        c = c - L + (k + 0.5) * width; L = width / 2                                    # record received
        w = rng.uniform(-W, W, len(a)); x = a * x + w; c = a * c; L = np.abs(a) * L + W     # dynamics
        if np.any(L > 1e12):
            return float(L.max()), float(np.abs(x - c).max())
    return float(L.max()), float(np.abs(x - c).max())


def HE():
    rng = np.random.default_rng(SEED + 4); table = {}
    for a in (1.5, 2.5, 3.5):
        row = {}
        for bits in (0, 1, 2, 3):
            L, e = zoom([a], [bits], rng=rng); row[str(bits)] = dict(bounded=bool(L < 10), half_length=fl(L))
        table[str(a)] = row
    scalar_ok = all(table[str(a)][str(b)]['bounded'] == (2 ** b > a) for a in (1.5, 2.5, 3.5) for b in (0, 1, 2, 3))
    # volume growth exponent without noise equals log|a| - R log 2
    rates = {}
    for a, b in ((2.5, 1), (3.5, 1), (1.5, 0)):
        Ls = []; L = 1.0
        for k in range(30):
            L = abs(a) * L / 2 ** b; Ls.append(L)
        rates[f'{a}_{b}'] = dict(measured=fl(np.polyfit(np.arange(30), np.log(Ls), 1)[0]), predicted=fl(math.log(a) - b * math.log(2)))
    rate_ok = all(abs(v['measured'] - v['predicted']) < 1e-9 for v in rates.values())
    two = {}
    for alloc in ((2, 0), (1, 1), (0, 2), (2, 1), (1, 2), (3, 0)):
        L, e = zoom([2.5, 1.8], list(alloc), rng=rng); two[str(alloc)] = bool(L < 10)
    thr = math.log2(2.5) + math.log2(1.8)
    two_ok = not any(two[str(a)] for a in ((2, 0), (1, 1), (0, 2))) and two['(2, 1)'] and not two['(1, 2)'] and not two['(3, 0)']
    ok = scalar_ok and rate_ok and two_ok
    must(ok, 'HE')
    R['HE'] = dict(claim='The frontier law. Records are counts and carry finitely many bits. For x\' = a x + w with |w| <= 0.01 and R bits per '
                         'step (zoom coding), the uncertainty stays bounded exactly when 2^R > |a|, for a = 1.5, 2.5, 3.5 and R = 0..3. '
                         'Without noise the uncertainty grows at log|a| - R log 2 per step, the volume bound that no coder beats, '
                         'since R bits can at most divide the set of possible states into 2^R parts while the dynamics stretches it '
                         'by |a|. For A = diag(2.5, 1.8) the threshold is log2 2.5 + log2 1.8 = 2.17 bits: all three 2-bit '
                         'allocations fail, the 3-bit allocation (2, 1) holds, and the misallocated (1, 2) and (3, 0) fail. A forecast '
                         'is held iff records arrive faster than the unstable exponents; Tensor-Frontier horizons are the zero-rate '
                         'case.',
                   status='PROVED (data-rate theorem: Nair-Evans 2004, Tatikonda-Mitter 2004) + computed', scalar=table, growth=rates,
                   two_dimensional=two, threshold_bits=fl(thr))


# ============================================================================================ HF
def HF():
    rng = np.random.default_rng(SEED + 5); rows = []
    for _ in range(40):
        lam = np.concatenate([rng.uniform(1.1, 2.5, 2) * rng.choice([-1, 1], 2), rng.uniform(-0.9, 0.9, 2)])
        S = rng.normal(size=(4, 4)); A = S @ np.diag(lam) @ np.linalg.inv(S); C = rng.normal(size=(2, 4)); Rn = np.eye(2)
        def run(Q):
            P = np.eye(4); gains = []
            for _ in range(3000):
                Pp = A @ P @ A.T + Q; Sm = C @ Pp @ C.T + Rn; K = Pp @ C.T @ np.linalg.inv(Sm); P = Pp - K @ C @ Pp; P = (P + P.T) / 2
                gains.append(0.5 * np.linalg.slogdet(np.eye(2) + np.linalg.solve(Rn, C @ Pp @ C.T))[1])
            return float(np.mean(gains[-200:]))
        target = float(np.sum(np.log(np.abs(lam[np.abs(lam) > 1]))))
        rows.append((run(np.zeros((4, 4))), run(np.eye(4) * 0.2), target))
    rows = np.array(rows); err0 = float(np.abs(rows[:, 0] - rows[:, 2]).max()); excess = float((rows[:, 1] - rows[:, 2]).min())
    ok = err0 < 1e-6 and excess > 0
    must(ok, 'HF')
    R['HF'] = dict(claim='The information rate. For 40 random four-dimensional systems with two unstable eigenvalues and two records per '
                         'step, the steady information delivered per step by the records, (1/2) ln det(1 + R^-1 C P C^T), equals the '
                         'sum of the logarithms of the unstable eigenvalues to the error below when there is no inflow; with inflow '
                         'Q = 0.2 it exceeds it in every case (smallest excess below). A steady record stream delivers exactly what '
                         'the unstable dynamics destroys, plus what the inflow removes.',
                   status='PROVED (steady Riccati; Bode-type entropy identity) + computed', no_inflow_max_error=below(err0, 1e-6), inflow_min_excess=fl(excess), systems=40)


# ============================================================================================ HG
def HG():
    GMs = {'Earth surface': (3.986004418e14, 6.371e6), 'Sun surface': (1.32712440018e20, 6.957e8), 'neutron star surface (1.4 M_sun, 12 km)': (1.4 * 1.32712440018e20, 1.2e4)}
    rows = {}
    for name, (GM, r) in GMs.items():
        E = GM / r ** 3 * np.diag([-2.0, 1.0, 1.0]); e = np.linalg.eigvalsh(E); lam = math.sqrt(-e.min()); om = np.sqrt(e[e > 0])
        rows[name] = dict(tidal_exponent_per_s=fl(lam), min_record_rate_bits_per_s=fl(lam / math.log(2)), sum_rule_residual=fl(lam ** 2 - float(np.sum(om ** 2))),
                          trace=fl(np.trace(E)))
    # the rate threshold on the deviation equation itself: x'' = lam^2 x discretised; bounded iff bits per second > lam/ln 2
    rng = np.random.default_rng(SEED + 6); lam = 1.0; dt = 0.25; a = math.exp(lam * dt)
    need = lam / math.log(2); res = {}
    for bps in (0.5, 1.0, 2.0, 4.0):                                                    # one bit every 1/(bps dt) steps (time sharing)
        every = int(round(1 / (bps * dt))); L, e = zoom([a], [1], steps=800, W=1e-3, rng=rng, every=every)
        res[str(bps)] = dict(one_bit_every_steps=every, bounded=bool(L < 10))
    # interior canary: inside a uniform ball the trace is 4 pi G rho, not 0
    rho = 5514.0; Gc = 6.674e-11; E_in = -(4 * math.pi * Gc * rho / 3) * np.eye(3) * (-1); interior_trace = float(np.trace(E_in))
    ok = all(abs(v['sum_rule_residual']) < 1e-12 * max(1.0, v['tidal_exponent_per_s'] ** 2) and abs(v['trace']) < 1e-12 * v['tidal_exponent_per_s'] ** 2 for v in rows.values()) \
        and not res['0.5']['bounded'] and not res['1.0']['bounded'] and res['2.0']['bounded'] and res['4.0']['bounded'] and abs(interior_trace - 4 * math.pi * Gc * rho) < 1e-12
    must(ok, 'HG')
    R['HG'] = dict(claim='The tidal frontier. In free fall at radius r from a mass M the tidal tensor is (GM/r^3) diag(-2, 1, 1): the radial '
                         'separation of two freely falling bodies grows with exponent sqrt(2GM/r^3) and the transverse ones oscillate. '
                         'By the frontier law, holding a forecast of that separation at fixed precision needs records at no less than '
                         'sqrt(2GM/r^3)/ln 2 bits per second (values below); transverse directions need none; in vacuum the sum rule '
                         'lambda^2 = sum omega^2 holds exactly (trace zero). On the discretised deviation equation (lambda = 1/s, '
                         'step 0.25 s, threshold 1/ln 2 = 1.44 bits/s), with one bit sent every k steps, 0.5 and 1 bits/s fail and 2 '
                         'and 4 bits/s hold: the threshold lies where the law puts it. (A first version sent a whole number of bits per '
                         'step and so could not realise 2 bits/s; it reported a false failure, caught on review.) Canary: inside a uniform ball the '
                         'trace is 4 pi G rho, not 0.',
                   status='derived (tidal frontier + data-rate theorem) + computed', by_body=rows, deviation_equation=res, interior_trace=fl(interior_trace))


# ============================================================================================ HH
def HH():
    rng = np.random.default_rng(SEED + 7); worst = 0.0; diff_pinv = 0.0
    for _ in range(100):
        n, m = 5, 2; S = rng.normal(size=(n, n)); P = S @ S.T + 0.1 * np.eye(n); J = rng.normal(size=(m, n)); y = rng.normal(size=m)
        B = P @ J.T @ np.linalg.inv(J @ P @ J.T); x_lift = B @ y
        eps = 1e-10; post = P @ J.T @ np.linalg.inv(J @ P @ J.T + eps * np.eye(m)) @ y               # Gaussian posterior mean, noise -> 0
        # independent: minimise x^T P^-1 x subject to J x = y by a KKT solve
        K = np.block([[np.linalg.inv(P), J.T], [J, np.zeros((m, m))]]); sol = np.linalg.solve(K, np.concatenate([np.zeros(n), y]))[:n]
        worst = max(worst, float(np.abs(x_lift - post).max()), float(np.abs(x_lift - sol).max()))
        pinv = J.T @ np.linalg.inv(J @ J.T) @ y; diff_pinv = max(diff_pinv, float(np.abs(pinv - x_lift).max()))
    ok = worst < 1e-6 and diff_pinv > 0.1
    must(ok, 'HH')
    R['HH'] = dict(claim='The response lift. For 100 random latent covariances P and record maps J, the lift B = P J^T (J P J^T)^-1 '
                         'equals the Gaussian posterior mean in the noiseless limit and the minimiser of x^T P^-1 x subject to J x = y '
                         '(independent KKT solve) to the error below. Declaring the latent covariance therefore fixes the response: '
                         'the response declaration reduces to the covariance declaration. Canary: the Euclidean pseudo-inverse lift '
                         'differs by the value below.',
                   status='PROVED (Gauss-Markov; Lagrange) + computed', lift_error=below(worst, 1e-6), pseudo_inverse_difference=fl(diff_pinv))


if __name__ == '__main__':
    for name, fn in (('HA', HA), ('HB', HB), ('HC', HC), ('HD', HD), ('HE', HE), ('HF', HF), ('HG', HG), ('HH', HH)):
        try:
            fn()
        except Exception as e:
            must(False, name); R[name] = dict(crash=repr(e))
        print(name, flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (HERE / 'rg_record_dynamics_results.json').write_text(json.dumps(out, indent=1, sort_keys=True))
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
