#!/usr/bin/env python3
"""Mutation suite for rg_record_dynamics.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. A few minutes.

    python3 -I rg_record_dynamics_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('HA', 'ignorance inflow with the wrong sign', "dI = -A.T @ I - I @ A - I @ Q @ I + G;", "dI = -A.T @ I - I @ A + I @ Q @ I + G;"),
    ('HA', 'transport with A instead of its adjoint', "I = y.reshape(n, n); dI = -A.T @ I - I @ A - I @ Q @ I + G;", "I = y.reshape(n, n); dI = -A @ I - I @ A.T - I @ Q @ I + G;"),
    ('HB', 'Hamiltonian flow given a trace', "A_ham = np.array([[0.0, 1.0], [0.81, 0.0]])", "A_ham = np.array([[0.05, 1.0], [0.81, 0.0]])"),
    ('HC', 'unobservable subspace taken as the static kernel', "O = np.vstack([C @ np.linalg.matrix_power(A, k) for k in range(3)]); N = null_space(O)", "O = C; N = null_space(O)"),
    ('HD', 'dual flow without exchanging records and inflow', "t2, Js = cov_flow(-A.T, G, Q, np.linalg.inv(P0), T)", "t2, Js = cov_flow(-A.T, Q, G, np.linalg.inv(P0), T)"),
    ('HE', 'zoom coder that does not shrink the cell', "c = c - L + (k + 0.5) * width; L = width / 2", "c = c - L + (k + 0.5) * width; L = width"),
    ('HF', 'information rate counted from all eigenvalues', "target = float(np.sum(np.log(np.abs(lam[np.abs(lam) > 1]))))", "target = float(np.sum(np.log(np.abs(lam))))"),
    ('HG', 'tidal tensor with the Newtonian sign reversed', "E = GM / r ** 3 * np.diag([-2.0, 1.0, 1.0]);", "E = GM / r ** 3 * np.diag([2.0, -1.0, -1.0]);"),
    ('HH', 'lift without the covariance', "B = P @ J.T @ np.linalg.inv(J @ P @ J.T); x_lift = B @ y", "B = J.T @ np.linalg.inv(J @ J.T); x_lift = B @ y"),
]


def main():
    base = open(os.path.join(HERE, 'rg_record_dynamics.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_record_dynamics.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_record_dynamics.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_record_dynamics_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
