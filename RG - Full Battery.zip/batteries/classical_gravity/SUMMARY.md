# RG – Classical Gravity: does Resolution Geometry exclude fundamentally classical gravity?

**Verdict: it does not lock.** The obstruction proved in the Quantum Gravity print is real, but classical-quantum gravity evades it by construction. No rung of the ladder forbids that evasion. Even under the strictest one-scale reading, one classical kernel survives the published bounds. Resolution Geometry therefore does not predict the outcome of gravitationally-mediated-entanglement experiments: it is compatible with quantum gravity and with fundamentally classical gravity. The final print was not built, because its condition (a locked prediction) failed.

Battery: `rg_classical_gravity_attack.py`, 3 groups (QA–QC), each with a canary; byte-identical on rerun; 5/5 mutations caught by the battery's own failure reports.

## The chain and where it breaks

| Link | Finding | Group |
|---|---|---|
| 1. A weight over gravitational histories that is a function of the action cannot be a probability | **Holds.** On a quadratic form of signature (5, 1), the signature of the gravitational action on the gauge quotient, exp(−S) diverges on growing boxes. A bounded weight such as 1/(1+S²) diverges too, because the region \|S\| ≤ 1 contains the null cone and its volume grows like L⁴ (measured 102 → 1521 → 24 998). Canary: a definite form gives a finite total π³/√det | QA |
| 2. Hence classical gravity is excluded | **Fails.** Classical-quantum gravity weights histories by exp(−\|E − source\|²/D), the squared residual of the field equation over a diffusion coefficient. On the same indefinite space this weight is normalizable, with total (πD)³/\|det A\| matched to 10⁻⁹. It is not a function of the action: x and −x have equal action and different weight. Prop. 11.4's premise does not apply. RG admits stochastic transport (L4 garblings) and treats constants as measured anchors (L94), so the diffusion coefficient is one more anchor, not a contradiction | QB |
| 3. A one-scale premise would close the gap | **Fails.** Set every coefficient by Planck units alone, against the published bounds. The continuous local kernel is excluded whatever its coefficient. The discrete local kernel with a Planckian coefficient is excluded: it decoheres 26 orders too fast (canary). The Diósi–Penrose kernel with a Planckian coefficient (l_P²D₂ = 1.6×10⁻²⁴ kg² s m⁻¹) lies inside the allowed band [10⁻⁴⁰, 10⁻⁹], 16 orders above the lower bound and 15 below the upper. A classical gravity fixed by G, ħ and c alone survives | QC |

## Limits

- The bounds are the order-of-magnitude values of the preprint (arXiv:2203.01982 v1, eqs. 44–47). The published version may state them differently.
- Heating and radiation bounds on Diósi–Penrose-type noise were not evaluated. They might close the surviving window, but that would be a result about the noise kernel, not a consequence of RG.
- The signature (5, 1) is taken from the Quantum Gravity print; the battery uses a rotated diagonal form with that signature.

## What would be needed

A prediction here requires an RG axiom stating that every sector's weight over histories is its own action's amplitude, with no independent noise. That is the assumption of quantized gravity, adopted rather than derived. RG would then predict entanglement exactly as perturbative quantum gravity does, and the experiment would test that assumption, not RG.

## Sources

- J. Oppenheim, C. Sparaciari, B. Šoda, Z. Weller-Davies, Gravitationally induced decoherence vs space-time diffusion: testing the quantum nature of gravity, Nat. Commun. 14 (2023) 7910; arXiv:2203.01982.
- T. Hirotani, A. Matsumura, Testing classical-quantum gravity with geodesic deviation, arXiv:2603.29230 (2026).
- G. W. Gibbons, S. W. Hawking, M. J. Perry, Path integrals and the indefiniteness of the gravitational action, Nucl. Phys. B 138 (1978) 141.
