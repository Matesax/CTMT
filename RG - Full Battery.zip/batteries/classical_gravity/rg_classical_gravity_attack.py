#!/usr/bin/env python3
"""RG - Classical Gravity: does Resolution Geometry exclude fundamentally classical gravity?

The proposed route: the Quantum Gravity print proves that a weight over gravitational histories that is a function of
the action alone cannot be a probability (the action's quadratic form is indefinite on the gauge quotient). If RG also
forbids a second independent scale, classical-quantum (CQ) gravity would be excluded, and RG would predict
gravitationally mediated entanglement. Each group below attacks one link; each has a canary.

  QA the obstruction holds: for a quadratic form of signature (5, 1) every nonnegative weight of the action has total 0
     or infinity on growing boxes; canary: a definite form has a finite total
  QB the obstruction is evaded: the CQ weight exp(-|A x - b|^2 / D) is a function of the field-equation residual, not
     of the action; it is normalizable on the same space whatever the signature of A; the premise of the obstruction
     does not apply, and no RG rung forbids it (RG admits stochastic transport and measured anchors)
  QC one scale does not save the argument: with every coefficient set by Planck units alone, the continuous and the
     discrete CQ kernels are excluded by published bounds, but the Diosi-Penrose kernel lies inside the allowed band
     by about 15 orders of magnitude on either side; canary: the discrete kernel falls outside

Bounds are the order-of-magnitude values of Oppenheim, Sparaciari, Soda and Weller-Davies (arXiv:2203.01982 v1,
eqs. 44-47 and the text after them). Deterministic. Seed 20261121 (no random draws beyond a fixed rotation).
Writes rg_classical_gravity_attack_results.json.
Run:  python3 -I rg_classical_gravity_attack.py
"""
import hashlib, json, math, os, sys
import numpy as np
from scipy.integrate import quad
from scipy.stats import ortho_group

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 20261121
R, FAILS = {}, []
# CODATA 2018 Planck units
LP, MP, TP = 1.616255e-35, 2.176434e-8, 5.391247e-44


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.6g}')


def box_total(eig, w, L):
    """Total of w(x^T A x) over the box |y_i| <= L in the eigenbasis, for w = exp(-s) or w = 1/(1 + s^2) restricted
    to separable checks: exp(-s) factorizes exactly; for 1/(1+s^2) use the volume of the slab |s| <= 1 as a lower bound."""
    if w == 'exp':
        return float(np.prod([quad(lambda y, l=l: math.exp(-l * y * y), -L, L, limit=200)[0] for l in eig]))
    raise ValueError


def QA():
    rot = ortho_group.rvs(6, random_state=SEED)
    A = rot @ np.diag([1.0, 2.0, 0.5, 1.5, 3.0, -1.0]) @ rot.T; B = rot @ np.diag([1.0, 2.0, 0.5, 1.5, 3.0, 1.0]) @ rot.T
    eA, eB = np.linalg.eigvalsh(A), np.linalg.eigvalsh(B)
    sig = (int(np.sum(eA > 0)), int(np.sum(eA < 0)))
    grow = [box_total(eA, 'exp', L) for L in (1.0, 2.0, 3.0, 4.0)]
    finite = [box_total(eB, 'exp', L) for L in (2.0, 4.0, 8.0)]
    exact = math.pi ** 3 / math.sqrt(np.prod(eB))
    # a bounded positive weight that decays in |s|: 1/(1+s^2). The slab |s| <= 1 has infinite volume for an indefinite
    # form (it contains the cone s = 0); its volume inside a box of side 2L grows like L^4 for signature (5, 1)
    def slab_volume(L, n=400000):
        rng = np.random.default_rng(SEED); y = rng.uniform(-L, L, size=(n, 6)); s = (y * y) @ eA
        return float((2 * L) ** 6 * np.mean(np.abs(s) <= 1.0))
    slab = [slab_volume(L) for L in (2.0, 4.0, 8.0)]
    ok = sig == (5, 1) and grow[-1] > 1e3 * grow[0] and abs(finite[-1] / exact - 1) < 1e-9 and slab[2] > 4 * slab[1] > 16 * slab[0] * 0.5
    must(ok, 'QA')
    R['QA'] = dict(claim='The obstruction holds. For a quadratic action of signature (5, 1), the form the gravitational action has on '
                         'the gauge quotient in the Quantum Gravity print, the weight exp(-S) has a total that grows without bound '
                         'on growing boxes, and a bounded weight such as 1/(1 + S^2) does too, because the region |S| <= 1 contains '
                         'the null cone and its volume grows like L^4. No nonnegative function of the action is a probability on '
                         'that space. Canary: for a definite form the total is finite and equals pi^3/sqrt(det).',
                   status='PROVED in the Quantum Gravity print (Prop. 11.4); computed', signature=list(sig), box_totals_exp=[fl(v) for v in grow],
                   definite_totals=[fl(v) for v in finite], definite_exact=fl(exact), slab_volume=[fl(v) for v in slab])
    return A


def QB(A):
    rng = np.random.default_rng(SEED + 1); b = rng.normal(size=6); D = 0.3
    # CQ-type weight: exp(-|A x - b|^2 / D), a function of the field-equation residual A x - b, not of S = x^T A x / 2
    exact = (math.pi * D) ** 3 / abs(np.linalg.det(A))
    eig, V = np.linalg.eigh(A.T @ A); c = np.linalg.solve(A, b)
    # in the eigenbasis of A^T A the weight is a product of Gaussians centred at the solution
    num = float(np.prod([quad(lambda y, l=l: math.exp(-l * y * y / D), -50, 50, limit=200)[0] for l in eig]))
    # it is not a function of the action: two points with equal action and different weight
    S = lambda x: 0.5 * x @ A @ x; W = lambda x: math.exp(-np.sum((A @ x - b) ** 2) / D)
    x1 = c.copy(); v = np.linalg.eigh(A)[1][:, 0]; t = math.sqrt(abs(2 * S(x1) / (v @ A @ v))) if S(x1) * (v @ A @ v) > 0 else None
    x2 = -x1                                                                # S(-x) = S(x), while the residual changes
    not_function = abs(S(x1) - S(x2)) < 1e-12 and abs(W(x1) - W(x2)) > 0.1
    # deterministic limit: as D -> 0 the weight concentrates on the solution of A x = b (classical, deterministic GR)
    spread = [math.sqrt(D_ * 0.5 / eig.min()) for D_ in (1e-2, 1e-4, 1e-6)]
    ok = abs(num / exact - 1) < 1e-9 and not_function and spread[2] < 0.01 * spread[0]
    must(ok, 'QB')
    R['QB'] = dict(claim='The obstruction is evaded. A classical-quantum theory weights histories by exp(-|E - source|^2/D), the '
                         'squared residual of the field equation over a diffusion coefficient. On the same space as QA, with the '
                         'same indefinite A, this weight is normalizable: its total is (pi D)^3/|det A| (matched to 1e-9). It is '
                         'not a function of the action: x and -x have the same action and different weights. As D -> 0 it '
                         'concentrates on the classical solution. The premise of Prop. 11.4, a weight that depends on the history '
                         'through the action alone, does not hold for it. No rung of the ladder forbids it: Resolution Geometry '
                         'admits stochastic transport (garblings, L4) and treats constants as measured anchors (L94), so a '
                         'diffusion coefficient is one more anchor, not a contradiction.',
                   status='computed; rung reading from the print edition', total=fl(num), exact=fl(exact), equal_action_different_weight=bool(not_function),
                   width_of_weight_as_D_to_0=[fl(s) for s in spread])


def QC():
    # Planck values of the coefficient combinations in which the published bounds are stated
    planck = {'continuous local kernel, D2 [kg^2 s m^-3]': MP ** 2 * TP / LP ** 3,
              'discrete local kernel, (l_P^3/m_P) D2 [kg s]': MP * TP,
              'Diosi-Penrose kernel, l_P^2 D2 [kg^2 s m^-1]': MP ** 2 * TP / LP}
    bounds = {'continuous local kernel, D2 [kg^2 s m^-3]': (1e-24, 1e-41),          # lower (interferometry) > upper (torsion): empty
              'discrete local kernel, (l_P^3/m_P) D2 [kg s]': (1e-25, 1e-1),
              'Diosi-Penrose kernel, l_P^2 D2 [kg^2 s m^-1]': (1e-40, 1e-9)}
    out = {}
    for k, v in planck.items():
        lo, hi = bounds[k]
        out[k] = dict(planck_value=fl(v), allowed_band=[lo, hi], band_empty=lo > hi, inside=bool(lo <= v <= hi),
                      orders_from_lower=fl(math.log10(v / lo)), orders_from_upper=fl(math.log10(hi / v)))
    dp = out['Diosi-Penrose kernel, l_P^2 D2 [kg^2 s m^-1]']
    ok = out['continuous local kernel, D2 [kg^2 s m^-3]']['band_empty'] and not out['discrete local kernel, (l_P^3/m_P) D2 [kg s]']['inside'] \
        and dp['inside'] and min(dp['orders_from_lower'], dp['orders_from_upper']) > 10
    must(ok, 'QC')
    R['QC'] = dict(claim='One scale does not save the argument. Set every coefficient by Planck units alone, the strictest reading of a '
                         'one-scale premise. The continuous local kernel is excluded whatever its coefficient (the interferometry '
                         'lower bound exceeds the torsion-balance upper bound by 17 orders). The discrete local kernel with a '
                         'Planckian coefficient is excluded: it would decohere fullerenes 26 orders of magnitude too fast '
                         '(canary). The Diosi-Penrose kernel with a Planckian coefficient lies inside the allowed band, about 16 '
                         'orders above the lower bound and 15 below the upper. A fundamentally classical gravity fixed by G, '
                         'hbar and c alone survives the published bounds. The bounds are order-of-magnitude values from the '
                         'preprint; heating and radiation bounds on Diosi-Penrose-type noise were not evaluated here.',
                   status='computed from published bounds (arXiv:2203.01982 v1)', kernels=out)


if __name__ == '__main__':
    A = QA(); print('QA', flush=True)
    QB(A); print('QB', flush=True)
    QC(); print('QC', flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(open(os.path.abspath(__file__), 'rb').read()).hexdigest()
    json.dump(out, open(os.path.join(HERE, 'rg_classical_gravity_attack_results.json'), 'w'), indent=1, sort_keys=True)
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
