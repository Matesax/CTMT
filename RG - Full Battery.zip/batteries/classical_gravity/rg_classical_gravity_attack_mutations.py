#!/usr/bin/env python3
"""Mutation suite for rg_classical_gravity_attack.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. Under one minute.

    python3 -I rg_classical_gravity_attack_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('QA', 'a definite form presented as the gravitational one', "np.diag([1.0, 2.0, 0.5, 1.5, 3.0, -1.0])", "np.diag([1.0, 2.0, 0.5, 1.5, 3.0, 1.0])"),
    ('QB', 'the residual weight replaced by a weight of the action', "W = lambda x: math.exp(-np.sum((A @ x - b) ** 2) / D)", "W = lambda x: math.exp(-S(x) / D)"),
    ('QB', 'wrong normalization of the residual weight', "exact = (math.pi * D) ** 3 / abs(np.linalg.det(A))", "exact = (math.pi * D) ** 3 / abs(np.linalg.det(A)) ** 0.5"),
    ('QC', 'the Diosi-Penrose bound read 20 orders tighter', "'Diosi-Penrose kernel, l_P^2 D2 [kg^2 s m^-1]': (1e-40, 1e-9)}", "'Diosi-Penrose kernel, l_P^2 D2 [kg^2 s m^-1]': (1e-20, 1e-9)}"),
    ('QC', 'Planck time replaced by Planck length over c taken as 1', "LP, MP, TP = 1.616255e-35, 2.176434e-8, 5.391247e-44", "LP, MP, TP = 1.616255e-35, 2.176434e-8, 1.616255e-35"),
]


def main():
    base = open(os.path.join(HERE, 'rg_classical_gravity_attack.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_classical_gravity_attack.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_classical_gravity_attack.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_classical_gravity_attack_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
