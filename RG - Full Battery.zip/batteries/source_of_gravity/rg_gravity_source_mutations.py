#!/usr/bin/env python3
"""Mutation suite for rg_gravity_source.py.

Each mutation changes one line so that the battery asserts something false. rg_gravity_source.py stops at the first failed
assertion with the group tag as message; the mutation is caught only when that tag is the targeted group. A mutation
that survives is a defect of the battery; any other error is a defect of the suite, not a catch. Runs in a temporary
directory; shipped files are not modified.

    python3 -I rg_gravity_source_mutations.py
"""
import os, re, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('G1', 'balance not conserved', 'abs(load.sum() - total0) < 1e-10', 'abs(load.sum() - 2 * total0) < 1e-10'),
    ('G2', 'wrong Laplacian stencil', 'sol[a0] == -4 * a1', 'sol[a0] == -2 * a1'),
    ('G4', 'two sources claimed distinguishable at the attractor', 'np.max(np.abs(pA0 - pB0)) < 1e-12', 'np.max(np.abs(pA0 - pB0)) > 1e-12'),
    ('G5', 'wrong 1/r normalisation', 'abs(coef[0] * 4 * math.pi - 1) < 0.08', 'abs(coef[0] * 2 * math.pi - 1) < 0.08'),
    ('G6', 'Newtonian half deflection claimed', 'abs(defl(1.0) - 1.751) < 0.002', 'abs(defl(1.0) - 0.8755) < 0.002'),
    ('G7', 'wrong R^2 suppression power', 'sp.simplify(R2 / EH - (l * k) ** 2) == 0', 'sp.simplify(R2 / EH - (l * k) ** 3) == 0'),
    ('G8', 'divergence claimed nonzero', 'all(d_ == 0 for d_ in div)', 'any(d_ != 0 for d_ in div)'),
    ('G10', 'linearized Ricci claimed nonzero', 'must(Rlin == sp.zeros(4, 4), "G10")', 'must(Rlin != sp.zeros(4, 4), "G10")'),
]


def main():
    base = open(os.path.join(HERE, 'rg_gravity_source.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            for f in os.listdir(HERE):
                if f.endswith('.py') and f != 'rg_gravity_source.py':
                    shutil.copy(os.path.join(HERE, f), tmp)
            open(os.path.join(tmp, 'rg_gravity_source.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_gravity_source.py'], cwd=tmp, capture_output=True, text=True)
        m = re.search(r'AssertionError: (\S+)', run.stderr)
        fails = [m.group(1)] if (run.returncode != 0 and m) else (['CRASHED'] if run.returncode != 0 else [])
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
