#!/usr/bin/env python3
"""RG - Autonomous Dynamics: hostile attack on the supplied two-carrier route.

The supplied battery (supplied/rg_autonomous_dynamics.py) derives a second-order record law for the density of a
two-carrier lattice and offers it as a novel prediction. This battery attacks every claim. Each group has a canary.

  DA the law is exact, and exact at the wall from the first step; it is the persistent-random-walk recurrence in
     the generating-function form of Herrmann-Vallois; at the wall the order-2 law is not unique
  DB the memory order is the number of hidden modes coupled to the record, not 2: three states give 3, a square
     lattice with four headings gives 4; the order-2 law fails on both (canary)
  DC the wall r = 1/2 is the boundary of continuous-time embedding: no carrier with a switching rate reaches it at
     any sampling interval; the refinement of the supplied group G runs to r -> 0, away from it
  DD a real refinement test: the lattice against Kac's exact solution of the telegraph equation at fixed physical
     time; the supplied group G is an algebraic identity with no simulation; diffusion puts mass outside the cone
  DE exact variance at every step (Taylor's correlated-step sum), not only the slope; the slope is Taylor's
     (1 + c)/(1 - c); canary: the diffusive law misses a finite offset
  DF finite order is not universal: a record whose correlation has an algebraic tail, as Brownian motion in a
     liquid has in published data, has a Hankel rank that grows without bound; a sum of exponentials saturates
  DG audit of the supplied battery: frontier speed is built in; edge mass is (1 - r)^(t - 1) exactly; the 12 per cent
     one-step error depends on the preparation; the wall threshold fails at r = 0.499 although the law holds

Deterministic. Seed 20261118 (the supplied seed). Writes rg_autonomous_attack_results.json.
Run:  python3 -I rg_autonomous_attack.py
"""
import hashlib, json, math, os, sys
import numpy as np
import sympy as sp
from scipy.integrate import quad
from scipy.linalg import expm, logm
from scipy.special import i0e, i1e
from scipy.stats import norm

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 20261118
R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.10g}')


def below(v, bound):
    return f'< {bound:g}' if abs(v) < bound else fl(v)


# --------------------------------------------------------------------------------------------- the supplied substrate
def step(p, r):
    """One cycle of the supplied two-carrier law: switch, then move one cell (periodic lattice)."""
    pp, pm = p
    return np.array([np.roll((1 - r) * pp + r * pm, 1), np.roll(r * pp + (1 - r) * pm, -1)])


def run(p0, r, T):
    p = np.array(p0, float); h = [p.sum(0)]
    for _ in range(T):
        p = step(p, r); h.append(p.sum(0))
    return np.array(h)


def law(q0, q1, r, T):
    out = [q0, q1]
    for _ in range(T - 1):
        out.append((1 - r) * (np.roll(out[-1], 1) + np.roll(out[-1], -1)) - (1 - 2 * r) * out[-2])
    return np.array(out)


def rel(a, b):
    return float(np.linalg.norm(a - b) / max(np.linalg.norm(b), 1e-300))


# ================================================================================================ DA
def DA():
    rng = np.random.default_rng(SEED)
    r, k, z = sp.symbols('r k z')
    A = sp.Matrix([[(1 - r) * sp.exp(-sp.I * k), r * sp.exp(-sp.I * k)], [r * sp.exp(sp.I * k), (1 - r) * sp.exp(sp.I * k)]])
    charpoly = sp.expand(A.charpoly(z).as_expr())
    target = z ** 2 - 2 * (1 - r) * sp.cos(k) * z + (1 - 2 * r)
    ch_ok = sp.simplify(charpoly.rewrite(sp.cos) - target) == 0
    # generating-function form of Herrmann-Vallois, Lemma 6.3, alpha = beta = r, lambda = e^{ik}
    lam = sp.symbols('lam')
    hv = z ** 2 - ((1 - r) / lam + (1 - r) * lam) * z + (1 - 2 * r)
    hv_ok = sp.simplify(hv.subs(lam, sp.exp(sp.I * k)).rewrite(sp.cos) - target) == 0
    # numerics: exact on random hidden states
    L, T = 129, 60; err = 0.0
    for _ in range(10):
        z0 = rng.random((2, L)); z0 /= z0.sum(); q = run(z0, 0.17, T); err = max(err, float(np.max(np.abs(law(q[0], q[1], 0.17, T) - q))))
    # the wall: order 1 exact from the first step (the supplied text says "after the first step")
    z0 = rng.random((2, L)); z0 /= z0.sum(); q = run(z0, 0.5, 12)
    wall_first = float(np.max(np.abs(q[1] - 0.5 * (np.roll(q[0], 1) + np.roll(q[0], -1)))))
    # non-uniqueness at the wall: (law of order 2) + mu (law of order 1 shifted) is also exact
    mu = 0.37; alt = [q[0], q[1]]
    for _ in range(11):
        nxt = 0.5 * (np.roll(alt[-1], 1) + np.roll(alt[-1], -1)) + mu * (alt[-1] - 0.5 * (np.roll(alt[-2], 1) + np.roll(alt[-2], -1)))
        alt.append(nxt)
    nonunique = float(np.max(np.abs(np.array(alt) - q)))
    # canary: the law without memory
    z0 = rng.random((2, L)); z0 /= z0.sum(); q = run(z0, 0.17, 30); out = [q[0], q[1]]
    for _ in range(29):
        out.append((1 - 0.17) * (np.roll(out[-1], 1) + np.roll(out[-1], -1)))
    canary = rel(np.array(out), q)
    ok = ch_ok and hv_ok and err < 1e-15 and wall_first < 1e-15 and nonunique < 1e-14 and canary > 1
    must(ok, 'DA')
    R['DA'] = dict(claim='The law is exact and it is old. The characteristic polynomial of the Fourier transfer matrix is '
                         'z^2 - 2(1-r) cos k z + (1-2r) (sympy); with alpha = beta = r and lambda = e^(ik) it is the '
                         'generating-function recurrence of Lemma 6.3 of Herrmann and Vallois, and the persistent-walk '
                         'difference equation goes back to Goldstein (1951). On ten random hidden states the law is exact '
                         'to 1e-15. Sharpening: at r = 1/2 the order-1 law holds from the first step, not only after it. At '
                         'the wall the order-2 law is not unique: adding any multiple of the order-1 residual keeps it exact. '
                         'Canary: dropping the memory term fails by more than 100 per cent.',
                   status='PROVED (Cayley-Hamilton); IDENTIFIED (Goldstein 1951; Herrmann-Vallois)', characteristic_polynomial_matches=bool(ch_ok),
                   generating_function_form_matches=bool(hv_ok), max_error=below(err, 1e-15), wall_first_step_error=below(wall_first, 1e-15),
                   nonunique_law_error_at_wall=below(nonunique, 1e-14), canary_no_memory=fl(canary))


# ================================================================================================ DB
def _hankel_rank(seq, tol=1e-9):
    n = (len(seq) + 1) // 2; H = np.array([[seq[i + j] for j in range(n)] for i in range(n)])
    s = np.linalg.svd(H, compute_uv=False); return int(np.sum(s > tol * s[0]))


def _orbit(A, x, e, n):
    out = []; v = x.copy()
    for _ in range(n):
        out.append(e @ v); v = A @ v
    return np.array(out)


def DB():
    rng = np.random.default_rng(SEED + 1); k = 0.731
    sh = lambda d: np.exp(-1j * k * d)
    two = lambda r: np.array([[(1 - r) * sh(1), r * sh(1)], [r * sh(-1), (1 - r) * sh(-1)]])
    # three states: right, left, rest. Runners reverse with r, stop with q; resters start with s (either way), else stay
    def three(r, q, s):
        M = np.array([[1 - r - q, r, s / 2], [r, 1 - r - q, s / 2], [q, q, 1 - s]])     # column = from
        return np.diag([sh(1), sh(-1), 1]) @ M
    # square lattice, four headings E N W S; continue 1-2t-b, turn left or right t each, back b
    def four(t, b, kx=0.731, ky=0.412):
        M = np.zeros((4, 4))
        for j in range(4):
            M[j, j] = 1 - 2 * t - b; M[(j + 1) % 4, j] = t; M[(j - 1) % 4, j] = t; M[(j + 2) % 4, j] = b
        S = np.diag([np.exp(-1j * kx), np.exp(-1j * ky), np.exp(1j * kx), np.exp(1j * ky)])
        return S @ M
    ranks = {}
    for name, A in (('two carriers, r = 0.17', two(0.17)), ('two carriers, r = 1/2', two(0.5)), ('three states (run, reverse, rest)', three(0.12, 0.07, 0.2)),
                    ('square lattice, four headings', four(0.1, 0.05)), ('square lattice, k on an axis', four(0.1, 0.05, 0.731, 0.0))):
        dim = A.shape[0]; rr = [_hankel_rank(_orbit(A, rng.random(dim) + 0j, np.ones(dim), 24)) for _ in range(3)]
        ranks[name] = max(rr)
    # real-space test: best order-m translation-invariant law fitted on three-state data, applied to held-out data
    L = 101
    def sim3(r, q, s, T, rng_):
        p = rng_.random((3, L)); p /= p.sum(); h = [p.sum(0)]
        M = np.array([[1 - r - q, r, s / 2], [r, 1 - r - q, s / 2], [q, q, 1 - s]])
        for _ in range(T):
            n = M @ p; p = np.array([np.roll(n[0], 1), np.roll(n[1], -1), n[2]]); h.append(p.sum(0))
        return np.array(h)
    def design(h, m, wid):
        rows, ys = [], []
        for t in range(m, len(h)):
            rows.append(np.stack([np.roll(h[t - j], s) for j in range(1, m + 1) for s in range(-wid, wid + 1)], axis=1)); ys.append(h[t])
        return np.vstack(rows), np.concatenate(ys)
    train = [sim3(0.12, 0.07, 0.2, 40, rng) for _ in range(6)]; test = [sim3(0.12, 0.07, 0.2, 40, rng) for _ in range(3)]
    fit_err = {}
    for m in (1, 2, 3):
        X = np.vstack([design(h, m, m)[0] for h in train]); y = np.concatenate([design(h, m, m)[1] for h in train])
        c = np.linalg.lstsq(X, y, rcond=None)[0]
        fit_err[m] = max(float(np.linalg.norm(design(h, m, m)[0] @ c - design(h, m, m)[1]) / np.linalg.norm(design(h, m, m)[1])) for h in test)
    ok = ranks['two carriers, r = 0.17'] == 2 and ranks['two carriers, r = 1/2'] == 1 and ranks['three states (run, reverse, rest)'] == 3 \
        and ranks['square lattice, four headings'] == 4 and fit_err[2] > 1e-3 and fit_err[3] < 1e-12
    must(ok, 'DB')
    R['DB'] = dict(claim='The memory order is the number of hidden modes coupled to the record, not 2. It is the rank of the '
                         'Hankel matrix of the record sequence (realization theory, Ho-Kalman), computed here from the record '
                         'alone: two carriers 2 (1 at r = 1/2); run-reverse-rest 3; a square lattice with four headings 4 '
                         '(3 for wavevectors on an axis, where reflection symmetry makes the two transverse headings equal). '
                         'Canary: on three-state data the best fitted order-2 law fails held out, the order-3 law is exact. '
                         'The order of the supplied law is a property of the supplied substrate.',
                   status='PROVED (realization theory, IMPORTED) + computed', hankel_rank=ranks, fitted_law_heldout_error={str(m): below(v, 1e-12) for m, v in fit_err.items()})


# ================================================================================================ DC
def DC():
    rng = np.random.default_rng(SEED + 2)
    M = lambda r: np.array([[1 - r, r], [r, 1 - r]])
    gen = {}
    for r in (0.05, 0.3, 0.49):
        lam = -math.log(1 - 2 * r) / 2; Q = lam * np.array([[-1, 1], [1, -1]])
        gen[str(r)] = dict(rate=fl(lam), reproduces=below(float(np.max(np.abs(expm(Q) - M(r)))), 1e-14))
    # beyond the wall: the determinant of exp(Q) is exp(tr Q) > 0, so det M <= 0 has no generator
    det = {str(r): fl(np.linalg.det(M(r))) for r in (0.5, 0.7, 0.9)}
    L7 = logm(M(0.7)); offdiag_real = float(np.real(L7[0, 1])); imag = float(np.max(np.abs(np.imag(L7))))
    # random 2x2 generators: switching probability never reaches 1/2
    leave_max, det_err = 0.0, 0.0
    for _ in range(2000):
        a, b = rng.exponential(size=2); t = 20 * rng.random() / (a + b)          # (a + b) t up to 20, determinant above 2e-9
        P = expm(t * np.array([[-a, b], [a, -b]])); leave_max = max(leave_max, float(P[1, 0] + P[0, 1]))
        det_err = max(det_err, abs(float(np.linalg.det(P)) / math.exp(-(a + b) * t) - 1))   # 1 - (P10 + P01) = exp(t tr Q) > 0
    gap_min = min(0.5 * math.exp(-2 * lam * dt) for lam in (0.1, 1, 10) for dt in (0.1, 1, 10))     # 1/2 - r for symmetric switching
    # the supplied refinement: r = a/(2 C tau) -> 0, the far side from the wall; exact memory e^(-dt/tau) vs supplied 1 - dt/tau
    tau = 2.0; mem = {str(a): dict(supplied=fl(1 - a / tau), exact_embedding=fl(math.exp(-a / tau)), r_supplied=fl(a / (2 * tau)), r_exact=fl(0.5 * (1 - math.exp(-a / tau))))
                     for a in (0.4, 0.2, 0.1, 0.05)}
    ok = all(v['reproduces'] == '< 1e-14' for v in gen.values()) and all(v <= 0 for v in det.values()) and (imag > 1e-6 or offdiag_real < 0) \
        and gap_min > 0 and leave_max < 1 and det_err < 1e-6
    must(ok, 'DC')
    R['DC'] = dict(claim='The wall is the boundary of continuous-time embedding. For r < 1/2 the switching matrix is exp(Q) of '
                         'a rate matrix (canary: reproduced to 1e-14). For r >= 1/2 its determinant 1 - 2r is not positive, '
                         'while det exp(Q) = exp(tr Q) > 0: no carrier with a switching rate, sampled at any interval, has '
                         'r >= 1/2 (Kingman 1962). The principal logarithm at r = 0.7 is complex. Symmetric switching at rate '
                         'lambda sampled at dt gives r = (1 - e^(-2 lambda dt))/2 < 1/2 and memory e^(-dt/tau) > 0. Two thousand '
                         'random asymmetric generators: 1 minus the sum of the two leaving probabilities equals exp(t tr Q) to 1e-6, so the sum is always below 1, the general form of the bound. The wall is reached only as dt/tau '
                         '-> infinity, and the refinement of the supplied group G runs to r -> 0, the opposite end. Order 2 '
                         'is therefore the order of every continuous-time two-carrier record.',
                   status='PROVED; IDENTIFIED (Kingman 1962)', generators=gen, determinant_beyond_wall=det, log_at_0_7=dict(max_imaginary_part=fl(imag)),
                   max_sum_of_leaving_probabilities_random_generators=fl(leave_max), determinant_identity_error=below(det_err, 1e-6), min_gap_to_wall_symmetric_sampled=fl(gap_min), memory_coefficient=mem)


# ================================================================================================ DD
def _kac(x, t, lam, C=1.0):
    """Continuous part of Kac's solution of u_tt + 2 lam u_t = C^2 u_xx, symmetric start at the origin."""
    s = t * t - x * x / (C * C)
    if s <= 0:
        return 0.0
    w = lam * math.sqrt(s)
    return lam * math.exp(-lam * t) / (2 * C) * (i0e(w) * math.exp(w) + t / math.sqrt(s) * i1e(w) * math.exp(w))


def DD():
    C, tau, T = 1.0, 2.0, 3.0; lam = 1 / (2 * tau)
    norm_check = quad(lambda x: _kac(x, T, lam), -T, T, epsabs=1e-13, limit=200)[0] + math.exp(-lam * T)
    width = 0.25; edges = np.arange(-T, T + 1e-12, width); exact = np.array([quad(lambda x: _kac(x, T, lam), edges[i], edges[i + 1], epsabs=1e-13)[0] for i in range(len(edges) - 1)])
    res = {}
    for a in (0.125, 0.0625, 0.03125, 0.015625):
        n = int(round(T / a)); r = a / (2 * C * tau); L = 2 * n + 41; c = L // 2
        p = np.zeros((2, L)); p[:, c] = 0.5
        for _ in range(n):
            p = step(p, r)
        q = p.sum(0); x = (np.arange(L) - c) * a
        front = float(q[c + n] + q[c - n]); bulk = q.copy(); bulk[c + n] = bulk[c - n] = 0.0
        cells = int(round(width / a)); b = np.array([bulk[c - n + i * cells: c - n + (i + 1) * cells].sum() for i in range(len(exact))])
        # cells at the left edge of each bin start at x = -T; the bin [x_i, x_i + width) holds cells x_i ... x_i + width - a
        res[a] = dict(front_mass=front, front_error=abs(front - math.exp(-lam * T)), bulk_L1=float(np.abs(b - exact).sum()), outside_cone=float(q[np.abs(x) > T + 1e-12].sum()))
    errs = [res[a]['bulk_L1'] for a in sorted(res, reverse=True)]; ferr = [res[a]['front_error'] for a in sorted(res, reverse=True)]
    order = [math.log2(errs[i] / errs[i + 1]) for i in range(3)]; forder = [math.log2(ferr[i] / ferr[i + 1]) for i in range(3)]
    # canary: the diffusion law with D = C^2 tau at the same time
    D = C * C * tau; sig = math.sqrt(2 * D * T)
    gauss = np.array([norm.cdf(edges[i + 1] / sig) - norm.cdf(edges[i] / sig) for i in range(len(exact))])
    diff_L1 = float(np.abs(gauss - exact).sum()) + math.exp(-lam * T); diff_outside = float(2 * norm.sf(T / sig))
    # vacuity of the supplied group G: its numbers follow from a formula, with no simulation
    vac = [fl(-a / math.log(1 - a / tau)) for a in (0.4, 0.2, 0.1, 0.05)]
    ok = abs(norm_check - 1) < 1e-9 and all(0.8 < o < 1.2 for o in order) and all(0.8 < o < 1.2 for o in forder) and errs[-1] < 0.01 \
        and all(v['outside_cone'] == 0 for v in res.values()) and diff_L1 > 0.5 and diff_outside > 0.3 and vac == [1.792568047, 1.898244316, 1.949572575, 1.97489451]
    must(ok, 'DD')
    R['DD'] = dict(claim='A real refinement test. With dx = a, dt = a/C, r = a/(2 C tau), C = 1, tau = 2, the lattice is run to '
                         'physical time T = 3 and compared with Kac\'s exact solution of tau u_tt + u_t = C^2 tau u_xx: two front '
                         'peaks of mass e^(-T/(2 tau)) each half, and a Bessel bulk (normalization checked to 1e-9). The front '
                         'mass and the bulk, in bins of width 0.25, converge at first order in a; at a = 1/64 the bulk L1 error '
                         'is 0.0039. Nothing leaves the cone. Canaries: the diffusion law with D = C^2 tau misses by 0.56 in L1 and '
                         'puts 39 per cent of the mass outside the cone; the numbers of the supplied group G are reproduced '
                         'by the formula -a/ln(1 - a/tau) with no simulation, so that group tests nothing.',
                   status='computed; telegraph limit IDENTIFIED (Goldstein 1951, Kac 1974)', normalization=below(abs(norm_check - 1), 1e-9),
                   lattice={str(a): {k_: fl(v) for k_, v in d.items()} for a, d in res.items()}, bulk_convergence_order=[fl(o) for o in order],
                   front_convergence_order=[fl(o) for o in forder], diffusion_L1_error=fl(diff_L1), diffusion_mass_outside_cone=fl(diff_outside),
                   supplied_group_G_by_formula=vac)


# ================================================================================================ DE
def DE():
    res = {}; worst = 0.0
    for r in (0.1, 0.35, 0.8):
        c = 1 - 2 * r; n = 200; L = 2 * n + 11; c0 = L // 2
        p = np.zeros((2, L)); p[:, c0] = 0.5; x = np.arange(L) - c0; var = [0.0]
        for _ in range(n):
            p = step(p, r); var.append(float((p.sum(0) * x * x).sum()))
        exact = [m * (1 + c) / (1 - c) - 2 * c * (1 - c ** m) / (1 - c) ** 2 for m in range(n + 1)]
        e = max(abs(var[m] - exact[m]) / max(exact[m], 1) for m in range(1, n + 1)); worst = max(worst, e)
        offset = -2 * c / (1 - c) ** 2
        res[str(r)] = dict(slope=fl((1 + c) / (1 - c)), supplied_slope=fl((1 - r) / r), offset=fl(offset), diffusive_law_error_at_200=fl(abs(n * (1 + c) / (1 - c) - var[n])),
                           below_ballistic=bool(all(var[m] <= m * m + 1e-9 for m in range(n + 1))))
    ok = worst < 1e-11 and all(abs(v['slope'] - v['supplied_slope']) < 1e-12 for v in res.values()) and res['0.1']['diffusive_law_error_at_200'] > 30 \
        and all(v['below_ballistic'] for v in res.values())
    must(ok, 'DE')
    R['DE'] = dict(claim='Exact variance at every step. With c = 1 - 2r the step correlation is c^|i-j| and the variance is '
                         'n(1+c)/(1-c) - 2c(1-c^n)/(1-c)^2 (Taylor 1921, correlated steps), matched to 1e-11 for n = 1 to 200 '
                         'at r = 0.1, 0.35, 0.8. The slope (1+c)/(1-c) equals the supplied (1-r)/r. The variance never exceeds '
                         'the ballistic n^2. Canary: the diffusive law alone misses a fixed offset -2c/(1-c)^2, which is -40 '
                         'cells^2 at r = 0.1.',
                   status='PROVED; IDENTIFIED (Taylor 1921)', max_relative_error=below(worst, 1e-11), cases=res)


# ================================================================================================ DF
def DF():
    h = 0.25; out = {}
    for name, f in (('two exponentials', lambda t: 0.7 * np.exp(-t) + 0.3 * np.exp(-0.2 * t)), ('algebraic tail (1 + t)^(-3/2)', lambda t: (1 + t) ** -1.5)):
        out[name] = [_hankel_rank(f(h * np.arange(2 * N - 1)), tol=1e-10) for N in (10, 20, 40, 80)]
    ok = out['two exponentials'] == [2, 2, 2, 2] and out['algebraic tail (1 + t)^(-3/2)'][-1] > out['algebraic tail (1 + t)^(-3/2)'][0] + 2 \
        and all(np.diff(out['algebraic tail (1 + t)^(-3/2)']) >= 0)
    must(ok, 'DF')
    R['DF'] = dict(claim='Finite order is not universal. A record law of order m exists iff the record correlation is a sum of '
                         'm exponentials, i.e. iff the Hankel rank is m. For a sum of two exponentials the numerical rank is 2 at '
                         'every window (canary). For a correlation with the algebraic tail t^(-3/2), the form that hydrodynamic '
                         'memory gives the velocity of a Brownian particle in a liquid (Alder-Wainwright; observed by Franosch et '
                         'al. 2011 and Kheifets et al. 2014), the rank grows with the window: 7, 9, 11, 12 at tolerance 1e-10, roughly logarithmically. Such '
                         'a record has no finite-order law. A claim that the minimal memory is finite in general is refuted by '
                         'published data; the descent criterion itself is not.',
                   status='computed; data cited, not re-analysed', hankel_rank_by_window={k: v for k, v in out.items()}, windows=[10, 20, 40, 80])


# ================================================================================================ DG
def DG():
    rng = np.random.default_rng(SEED + 3); r = 0.17
    # frontier: speed one cell per cycle for every r and every state, because the step is a shift by one
    worst = 0.0
    for rr in (0.0, 0.17, 0.5, 0.99):
        L = 401; c = L // 2; p = rng.random((2, L)) * (np.abs(np.arange(L) - c) <= 3); h = run(p, rr, 80)
        for t in range(81):
            worst = max(worst, float(np.max(np.abs(h[t][np.abs(np.arange(L) - c) > t + 3]), initial=0.0)))
    # edge mass of the symmetric start: (1 - r)^(t - 1), supplied 0.0290057 at t = 20
    L = 401; c = L // 2; p = np.zeros((2, L)); p[:, c] = 0.5; h = run(p, r, 20); edge = float(h[20][c + 20] + h[20][c - 20])
    # the error of the best fitted one-step law is a function of r, vanishing at the wall
    def onestep(rr, Tn=8, n=40):
        X, Y = [], []
        for _ in range(n):
            z = rng.random((2, 257)); z /= z.sum(); q = run(z, rr, Tn); X.append(q[:-1]); Y.append(q[1:])
        X, Y = np.concatenate(X), np.concatenate(Y)
        A = np.stack([np.roll(X, 1, 1).ravel(), X.ravel(), np.roll(X, -1, 1).ravel()], 1); cf = np.linalg.lstsq(A, Y.ravel(), rcond=None)[0]
        return float(np.linalg.norm(A @ cf - Y.ravel()) / np.linalg.norm(Y.ravel()))
    prep = {str(rr): onestep(rr) for rr in (0.05, 0.17, 0.3, 0.45)}
    # the supplied wall threshold (> 1e-3 away from the wall) fails at r = 0.499, although the law holds there
    z = rng.random((2, 257)); z /= z.sum(); q = run(z, 0.499, 12)
    one = 0.5 * (np.roll(q[1:-1], 1, axis=1) + np.roll(q[1:-1], -1, axis=1)); close = rel(one, q[2:])
    exact_there = float(np.max(np.abs(law(q[0], q[1], 0.499, 12) - q)))
    ok = worst == 0.0 and abs(edge - (1 - r) ** 19) < 1e-15 and abs(edge - 0.0290057) < 1e-7 and prep['0.05'] > prep['0.17'] > prep['0.3'] > prep['0.45'] and 0.09 < prep['0.17'] < 0.15 \
        and close < 1e-3 and exact_there < 1e-15
    must(ok, 'DG')
    R['DG'] = dict(claim='Audit of the supplied battery. (1) The frontier speed of one cell per cycle is built into the step, a shift '
                         'by one cell: it holds for every r, including 0 and 0.99, and every state; it is not a finding. (2) The '
                         'edge mass is exactly (1 - r)^(t - 1), because a carrier may switch before its first move: 0.0290057 at '
                         't = 20. (3) The 12 per cent error of the fitted one-step law is not a constant of the theory: it falls '
                         'with r, 21, 12, 6 and 1.4 per cent at r = 0.05, 0.17, 0.3, 0.45, and vanishes at the wall. (4) The supplied wall test requires '
                         'error > 1e-3 away from the wall; at r = 0.499 the error is 1.6e-4 and the test would fail, while the '
                         'order-2 law is exact there to 1e-15. The threshold encodes a choice of grid, not the theory.',
                   status='computed', frontier_violation_any_r=below(worst, 1e-300), edge_mass_t20=fl(edge), edge_formula=fl((1 - r) ** 19),
                   one_step_fit_error_by_r={k: fl(v) for k, v in prep.items()}, one_step_error_r_0_499=fl(close), order_two_error_r_0_499=below(exact_there, 1e-15))


if __name__ == '__main__':
    for name, fn in (('DA', DA), ('DB', DB), ('DC', DC), ('DD', DD), ('DE', DE), ('DF', DF), ('DG', DG)):
        fn(); print(name, flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(open(os.path.abspath(__file__), 'rb').read()).hexdigest()
    json.dump(out, open(os.path.join(HERE, 'rg_autonomous_attack_results.json'), 'w'), indent=1, sort_keys=True)
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
