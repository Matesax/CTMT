#!/usr/bin/env python3
"""Mutation suite for rg_autonomous_attack.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. Under one minute.

    python3 -I rg_autonomous_attack_mutations.py
"""
import json, os, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('DA', 'wrong sign of the memory term', "out.append((1 - r) * (np.roll(out[-1], 1) + np.roll(out[-1], -1)) - (1 - 2 * r) * out[-2])",
     "out.append((1 - r) * (np.roll(out[-1], 1) + np.roll(out[-1], -1)) + (1 - 2 * r) * out[-2])"),
    ('DA', 'wrong order-1 law at the wall', "wall_first = float(np.max(np.abs(q[1] - 0.5 * (", "wall_first = float(np.max(np.abs(q[1] - 0.45 * ("),
    ('DB', 'memory order claimed to be 2 for three states', "ranks['three states (run, reverse, rest)'] == 3", "ranks['three states (run, reverse, rest)'] == 2"),
    ('DC', 'wrong rate of the generator', "lam = -math.log(1 - 2 * r) / 2; Q", "lam = -math.log(1 - 2 * r); Q"),
    ('DD', 'telegraph equation with the wrong damping', "C, tau, T = 1.0, 2.0, 3.0; lam = 1 / (2 * tau)", "C, tau, T = 1.0, 2.0, 3.0; lam = 1 / tau"),
    ('DD', 'diffusion presented as the continuum law', "diff_L1 > 0.5 and diff_outside > 0.3", "diff_L1 < 0.05 and diff_outside < 0.01"),
    ('DE', 'wrong step correlation', "c = 1 - 2 * r; n = 200", "c = 1 - r; n = 200"),
    ('DF', 'a sum of exponentials presented as the algebraic tail', "lambda t: (1 + t) ** -1.5)", "lambda t: 0.5 * np.exp(-t) + 0.5 * np.exp(-0.3 * t))"),
    ('DG', 'edge mass claimed as (1 - r)^t', "abs(edge - (1 - r) ** 19) < 1e-15", "abs(edge - (1 - r) ** 20) < 1e-15"),
    ('DG', 'carriers that move two cells per cycle', "return np.array([np.roll((1 - r) * pp + r * pm, 1), np.roll(r * pp + (1 - r) * pm, -1)])",
     "return np.array([np.roll((1 - r) * pp + r * pm, 2), np.roll(r * pp + (1 - r) * pm, -2)])"),
]


def main():
    base = open(os.path.join(HERE, 'rg_autonomous_attack.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_autonomous_attack.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_autonomous_attack.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_autonomous_attack_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
