# RG – Autonomous Dynamics: attack on the two-carrier route

**Verdict: no novelty locks.** Every exact statement of the supplied route holds, and every one is a published result. The route does not produce a prediction that differs from known physics, and so there is nothing for existing data to verify that has not already been verified. Two supplied tests are vacuous; one supplied claim (the minimal memory is 2) is a property of the chosen substrate, not of RG. The connection with general relativity does not break: the supplied conclusion "RG contains a faithful GR sector and is not exhausted by it" is the SE-1 finding of *RG – GR Equivalence* (observation systems are a wider class), and is not new either.

Battery: `rg_autonomous_attack.py`, seed 20261118, 7 groups (DA–DG), each with a canary; byte-identical on rerun; 10/10 mutations caught (`rg_autonomous_attack_mutations.py`). The supplied script and results are under `supplied/` and reproduce exactly on rerun (last-digit differences from the supplied JSON across machines).

## Claim by claim

| Supplied claim | Holds? | Known as | Group |
|---|---|---|---|
| Second-order law ρ(t+2) = (1−r)[ρ(t+1)(i−1)+ρ(t+1)(i+1)] − (1−2r)ρ(t) | Yes, exactly (Cayley–Hamilton; checked by sympy) | Persistent random walk difference equation: Goldstein 1951; in generating-function form Lemma 6.3 of Herrmann–Vallois | DA |
| One-step law impossible for generic r | Yes | Non-Markovianity of a projected Markov chain; standard | DA, DG |
| Minimal memory m* = 2 | Only for this substrate. Run–reverse–rest gives 3; a square lattice with four headings gives 4; isotropic continuum has no finite order | Hankel rank / minimal realization (Ho–Kalman); in exactly this coarse-dynamics framing: Churilov, arXiv:2610.13951 (July 2026) | DB |
| Wall at r = 1/2 | Yes on the lattice, and the order-1 law holds from the first step (sharper than supplied). But r ≥ 1/2 has no continuous-time generator (det = 1−2r ≤ 0, while det e^Q > 0): no carrier with a switching rate reaches the wall at any sampling interval. The supplied refinement runs to r → 0, the opposite end | Embedding problem: Kingman 1962 | DC |
| Frontier speed 1 cell per cycle, front attained | Yes, but built into the step (a shift by one cell) for every r and state; edge mass is exactly (1−r)^(t−1) | By construction | DG |
| Diffusion D_eff = (1−r)/(2r) | Yes; the full variance is n(1+c)/(1−c) − 2c(1−c^n)/(1−c)², c = 1−2r, at every step | Taylor 1921 (correlated steps) | DE |
| Telegraph continuum limit τρ_tt + ρ_t = C²τρ_xx | Yes. The supplied test (group G) is an algebraic identity with no simulation. Real test added: lattice against Kac's exact Bessel solution converges at first order (bulk L1 0.0039 at a = 1/64); diffusion misses by 0.56 and puts 39 % of the mass outside the cone | Goldstein 1951; Kac 1974 | DD |
| "Novel prediction not supplied by GR" | No. GR is silent on lattice random walks; silence is not a difference. The results are classical stochastic-process theory | — | — |

## What existing data say

The persistent-walk and telegraph predictions have long been confirmed in their own fields (run-and-tumble bacteria, light in turbid media). They confirm Goldstein, Taylor and Kac, not RG. The one place where data bear on the *general* claim is against it: Brownian motion in a liquid has a hydrodynamic t^(−3/2) velocity tail (observed by Franosch et al. 2011 and Kheifets et al. 2014). A record with that tail has a Hankel rank that grows with the window (7, 9, 11, 12 in DF), so it has no finite-order record law. "The minimal memory is finite" is refuted by published data; the descent criterion itself (finite order iff finite Hankel rank) is not.

## What does lock (as structure, not as new physics)

- The descent criterion gives the order of the record law as the Hankel rank of the record sequence, and walls as the points where that rank drops (realization theory; imported).
- For a sampled continuous-time carrier the memory coefficient is e^(−Δt/τ) > 0, so the order never drops at a finite sampling rate.
- Exact finite propagation plus memory gives the telegraph law; diffusion is its infrared limit and violates the cone at finite time.

## Sources

- S. Goldstein, On diffusion by discontinuous movements, and on the telegraph equation, Q. J. Mech. Appl. Math. 4 (1951) 129.
- M. Kac, A stochastic model related to the telegrapher's equation, Rocky Mountain J. Math. 4 (1974) 497.
- S. Herrmann, P. Vallois, From persistent random walks to the telegraph noise, arXiv:0810.0650 (Lemma 6.3).
- G. I. Taylor, Diffusion by continuous movements, Proc. London Math. Soc. 20 (1921) 196.
- J. F. C. Kingman, The imbedding problem for finite Markov chains, Z. Wahrscheinlichkeitstheorie 1 (1962) 14.
- M. V. Churilov, Predictive holonomy and minimal completion of coarse dynamics, arXiv:2610.13951 (2026).
- J. M. Porrà, J. Masoliver, G. H. Weiss, When the telegrapher's equation furnishes a better approximation to the transport equation than the diffusion approximation, Phys. Rev. E 55 (1997) 7771.
- T. Franosch et al., Resonances arising from hydrodynamic memory in Brownian motion, Nature 478 (2011) 85; arXiv:1106.6161.
