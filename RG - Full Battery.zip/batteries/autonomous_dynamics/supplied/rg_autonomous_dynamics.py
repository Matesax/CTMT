#!/usr/bin/env python3
"""RG autonomous dynamics battery.

A persistent two-carrier lattice is treated as microscopic/natural-law data.
Only the density record rho=p_plus+p_minus is exposed to RG.
The battery derives and tests the minimal descended dynamics rather than
inserting a diffusion or telegraph equation.

Exact derived law (periodic lattice):
 rho[t+2,i] = (1-r)*(rho[t+1,i-1]+rho[t+1,i+1]) - (1-2*r)*rho[t,i].

The law follows from Cayley-Hamilton elimination of the hidden two-state
carrier in Fourier space.  At r=1/2 the memory coefficient vanishes and the
record closes at order one; away from that wall order two is generically
necessary.
"""
import numpy as np, json, csv, sys, math
from pathlib import Path

SEED=20261118
OUT=Path(__file__).resolve().parent
rng=np.random.default_rng(SEED)

def step(p, r):
    pp, pm = p
    return np.array([
        np.roll((1-r)*pp + r*pm, 1),
        np.roll(r*pp + (1-r)*pm, -1)
    ])

def run(p0,r,T):
    p=np.array(p0,float); hist=[p.copy()]
    for _ in range(T):
        p=step(p,r); hist.append(p.copy())
    return np.array(hist)

def descended(rho0,rho1,r,T):
    out=[rho0.copy(),rho1.copy()]
    for _ in range(T-1):
        nxt=(1-r)*(np.roll(out[-1],1)+np.roll(out[-1],-1))-(1-2*r)*out[-2]
        out.append(nxt)
    return np.array(out)

def relerr(a,b):
    return float(np.linalg.norm(a-b)/max(np.linalg.norm(b),1e-15))

def fit_one_step(X,Y):
    # translation-invariant three-point Markov fit rho' = a L + b C + c R
    A=np.stack([np.roll(X,1,axis=1).ravel(),X.ravel(),np.roll(X,-1,axis=1).ravel()],axis=1)
    coef=np.linalg.lstsq(A,Y.ravel(),rcond=None)[0]
    return coef

def apply_one(X,c):
    return c[0]*np.roll(X,1,axis=1)+c[1]*X+c[2]*np.roll(X,-1,axis=1)

results={'seed':SEED,'groups':{}}
# A. Exact autonomous descent and held-out prediction
L=257; r=.17; T=90
tr=[]; te=[]
for j in range(30):
    z=rng.random((2,L)); z/=z.sum()
    h=run(z,r,T); rho=h.sum(axis=1)
    rec=descended(rho[0],rho[1],r,T)
    (tr if j<20 else te).append((rho,rec))
max_exact=max(np.max(np.abs(a-b)) for a,b in te)
results['groups']['A_exact_descent']={'max_abs_error':float(max_exact),'pass':max_exact<2e-14}

# B. One-step descent obstruction: same density, different hidden flux
rho=np.zeros(L); rho[L//2]=1
pA=np.array([rho.copy(),np.zeros(L)])
pB=np.array([np.zeros(L),rho.copy()])
rhoA=step(pA,r).sum(axis=0); rhoB=step(pB,r).sum(axis=0)
sep=np.linalg.norm(rhoA-rhoB)
results['groups']['B_one_step_impossible']={'future_separation_same_present':float(sep),'pass':sep>0.9}

# C. Minimal-memory wall r=1/2
wall_errors={}
for rr in [0.1,0.3,0.49,0.5,0.51,0.7,0.9]:
    z=rng.random((2,L)); z/=z.sum(); h=run(z,rr,12); q=h.sum(axis=1)
    one=.5*(np.roll(q[1:-1],1,axis=1)+np.roll(q[1:-1],-1,axis=1))
    # At wall q[t+1] = 1/2(S+ + S-) q[t]
    wall_errors[str(rr)]=relerr(one,q[2:])
results['groups']['C_memory_wall']={'errors':wall_errors,'pass':wall_errors['0.5']<2e-14 and min(v for k,v in wall_errors.items() if k!='0.5')>1e-3}

# D. Generic one-step fitted dynamics fails; exact order-two law predicts held-out
Xs=[]; Ys=[]; test_pairs=[]
for j in range(60):
    z=rng.random((2,L)); z/=z.sum(); h=run(z,r,8); q=h.sum(axis=1)
    if j<40:
        Xs.append(q[:-1]); Ys.append(q[1:])
    else: test_pairs.append((q[:-1],q[1:]))
X=np.concatenate(Xs); Y=np.concatenate(Ys); coef=fit_one_step(X,Y)
one_err=np.mean([relerr(apply_one(x,coef),y) for x,y in test_pairs])
two_err=np.mean([relerr(descended(runz[0],runz[1],r,len(runz)-1),runz) for runz,_ in [(run(np.array([rng.random(L),rng.random(L)]),r,20).sum(axis=1),None) for _ in range(10)]])
results['groups']['D_model_selection']={'one_step_coefficients':coef.tolist(),'one_step_test_rel_error':float(one_err),'two_step_test_rel_error':float(two_err),'pass':one_err>1e-2 and two_err<2e-13}

# E. Exact frontier/maximal speed: compact support cannot move more than one cell/step
Lc=401; c=Lc//2; init=np.zeros((2,Lc)); init[:,c]=.5
h=run(init,r,80); q=h.sum(axis=1)
viol=0.; edge_amp=[]
for t in range(81):
    dist=np.minimum((np.arange(Lc)-c)%Lc,(c-np.arange(Lc))%Lc)
    viol=max(viol,float(np.max(np.abs(q[t][dist>t])) if np.any(dist>t) else 0))
    edge_amp.append(float(q[t,(c+t)%Lc]+q[t,(c-t)%Lc]))
results['groups']['E_frontier']={'outside_cone_max':viol,'edge_amplitude_t20':edge_amp[20],'speed_cells_per_step':1.0,'pass':viol<1e-15 and edge_amp[20]>0}

# F. Long-wave emergent diffusion is a consequence, not the inserted law
# For persistent walk, asymptotic variance slope = (1-r)/r, hence D=(1-r)/(2r).
Lbig=4001; cb=Lbig//2; init=np.zeros((2,Lbig)); init[:,cb]=.5
for rr in [.1,.2,.35,.5,.8]:
    h=run(init,rr,800); q=h.sum(axis=1)
    x=np.arange(Lbig)-cb
    var=(q*x*x).sum(axis=1)
    tt=np.arange(400,801)
    slope=np.polyfit(tt,var[400:],1)[0]
    pred=(1-rr)/rr
    results['groups'].setdefault('F_emergent_diffusion',{'cases':{}})['cases'][str(rr)]={'measured_variance_slope':float(slope),'predicted':float(pred),'relative_error':abs(float(slope-pred))/pred}
results['groups']['F_emergent_diffusion']['pass']=max(v['relative_error'] for v in results['groups']['F_emergent_diffusion']['cases'].values())<.015

# G. Refinement/continuum telegraph scaling. Choose r=a/(2 tau), dt=a/c with c=1;
# then relaxation time tau fixed. Exact lattice cone speed remains one.
tau=2.0
sc=[]
for a in [.4,.2,.1,.05]:
    rr=a/(2*tau)
    # memory factor 1-2r = 1-a/tau; inferred tau=-dt/log(factor)
    inferred=-a/math.log(1-2*rr)
    sc.append({'a':a,'r':rr,'inferred_tau':inferred,'relative_error':abs(inferred-tau)/tau})
results['groups']['G_refinement']={'cases':sc,'pass':sc[-1]['relative_error']<.013 and all(sc[i+1]['relative_error']<sc[i]['relative_error'] for i in range(len(sc)-1))}

# H. Mutation canaries: flip/remove each structurally essential term
z=rng.random((2,L)); z/=z.sum(); h=run(z,r,30); q=h.sum(axis=1)
def mutated(kind):
    out=[q[0],q[1]]
    for _ in range(29):
        spatial=(1-r)*(np.roll(out[-1],1)+np.roll(out[-1],-1))
        mem=(1-2*r)*out[-2]
        if kind=='no_memory': nxt=spatial
        elif kind=='wrong_sign': nxt=spatial+mem
        elif kind=='no_left': nxt=(1-r)*np.roll(out[-1],-1)-mem
        elif kind=='r_shift':
            rp=r+.03; nxt=(1-rp)*(np.roll(out[-1],1)+np.roll(out[-1],-1))-(1-2*rp)*out[-2]
        out.append(nxt)
    return np.array(out)
mut={k:relerr(mutated(k),q) for k in ['no_memory','wrong_sign','no_left','r_shift']}
results['groups']['H_mutations']={'relative_errors':mut,'pass':min(mut.values())>1e-2}

results['all_pass']=all(g.get('pass',False) for g in results['groups'].values())
(OUT/'rg_autonomous_dynamics_results.json').write_text(json.dumps(results,indent=2,default=lambda o: bool(o) if isinstance(o,np.bool_) else float(o)),encoding='utf-8')
with open(OUT/'rg_autonomous_dynamics_summary.csv','w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['group','pass','metric'])
    for k,g in results['groups'].items(): w.writerow([k,g['pass'],json.dumps({x:y for x,y in g.items() if x!='pass'},separators=(',',':'))])
print(json.dumps(results,indent=2,default=lambda o: bool(o) if isinstance(o,np.bool_) else float(o)))
sys.exit(0 if results['all_pass'] else 1)
