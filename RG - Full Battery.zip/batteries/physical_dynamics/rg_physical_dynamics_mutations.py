#!/usr/bin/env python3
"""Mutation suite for rg_physical_dynamics.py.

Each mutation changes one line so that the battery asserts something false. rg_physical_dynamics.py stops at the first failed
assertion with the group tag as message; the mutation is caught only when that tag is the targeted group. A mutation
that survives is a defect of the battery; any other error is a defect of the suite, not a catch. Runs in a temporary
directory; shipped files are not modified.

    python3 -I rg_physical_dynamics_mutations.py
"""
import os, re, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('P1', 'null flux vanishes everywhere', 'fnull.subs(x, R_ + (L_ - R_) / 4) != 0', 'fnull.subs(x, R_ + (L_ - R_) / 4) == 0'),
    ('P2', 'wrong balance coefficient', 'Esel[i, j] + 2 * A * G1[i, j]', 'Esel[i, j] + 3 * A * G1[i, j]'),
    ('P4', 'wrong Kretschmann scalar', 'sp.simplify(kretsch_minus_dS - 48 * M_ ** 2 / rr ** 6) == 0', 'sp.simplify(kretsch_minus_dS - 12 * M_ ** 2 / rr ** 6) == 0'),
    ('P5', 'wrong plateau count', 'sum(tr["above_plateau"] for tr in traj) == 24', 'sum(tr["above_plateau"] for tr in traj) == 25'),
    ('P6', 'wrong scalaron mass', 'sp.simplify(m2 - 1 / (6 * al_s', 'sp.simplify(m2 - 1 / (3 * al_s'),
    ('P7', 'wrong short-range gamma', 'gam.subs(xx, 0) == sp.Rational(1, 2)', 'gam.subs(xx, 0) == sp.Rational(1, 3)'),
    ('P8', 'unstable relaxation claimed stable', 'np.linalg.eigvalsh(-Lneg).max() > 0', 'np.linalg.eigvalsh(-Lneg).max() < 0'),
]


def main():
    base = open(os.path.join(HERE, 'rg_physical_dynamics.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            for f in os.listdir(HERE):
                if f.endswith('.py') and f != 'rg_physical_dynamics.py':
                    shutil.copy(os.path.join(HERE, f), tmp)
            open(os.path.join(tmp, 'rg_physical_dynamics.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_physical_dynamics.py'], cwd=tmp, capture_output=True, text=True)
        m = re.search(r'AssertionError: (\S+)', run.stderr)
        fails = [m.group(1)] if (run.returncode != 0 and m) else (['CRASHED'] if run.returncode != 0 else [])
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
