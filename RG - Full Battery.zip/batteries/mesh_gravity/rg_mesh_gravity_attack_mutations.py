#!/usr/bin/env python3
"""Mutation suite for rg_mesh_gravity_attack.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. About ten minutes.

    python3 -I rg_mesh_gravity_attack_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('MA', 'the mesh without mirror pairing claimed dipole-free', "mesh[idx(i, j, k)] += 1.0 / 40; mesh[idx(2 * c - i, 2 * c - j, 2 * c - k)] += 1.0 / 40", "mesh[idx(i, j, k)] += 1.0 / 20"),
    ('MB', 'mean-field gravity given the branch deflection', "mean_field = np.zeros(n)", "mean_field = branch.astype(float) * 0.5"),
    ('MC', 'the gravitational phase without 1/distance', "phase = np.array([[G * m * m * t / (HBAR * abs(xb[j] - xa[i])) for j in range(2)] for i in range(2)])", "phase = np.array([[G * m * m * t / (HBAR * 300e-6) for j in range(2)] for i in range(2)])"),
    ('MD', 'the width law with m^2 in place of m^3', "width = lambda m: w0 * HBAR ** 2 / (G * m ** 3)", "width = lambda m: w0 * HBAR ** 2 / (G * m ** 2)"),
]


def main():
    base = open(os.path.join(HERE, 'rg_mesh_gravity_attack.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_mesh_gravity_attack.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_mesh_gravity_attack.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_mesh_gravity_attack_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
