#!/usr/bin/env python3
"""RG - Mesh Gravity and the Particle: what a gravitating mesh of particles forces on the quantum picture.

A shift-blind, reciprocal, passive network relaxes to the graph Laplacian, i.e. Newtonian gravity sourced by node masses.
Combine this with the One World reading of particles (counts glue, extent is a separate quotient) and ask three questions.

  MA gravity is a counting protocol: relaxation on a 3D lattice converges to one attractor (the Poisson solution); outside
     a compact source the field depends on the total mass and its centre, with the structure visible only in higher
     multipoles; a point, a uniform ball and a mirror-paired random mesh of 40 sub-masses give the same far field; canary: a
     displaced source shows its dipole
  MB a superposed source: mean-field gravity (sourced by the expectation) never deflects a centred test mass, while
     branch-sourced gravity always deflects it, to either side with equal frequency (what Page and Geilker observed);
     canary: a classical coin gives the branch statistics too, so the observation does not decide quantum versus collapse
  MC the decisive experiment: two 1e-14 kg masses, each split by 250 um, closest 200 um apart, 2.5 s of gravitational
     interaction: entangling gravity gives the negativity below; any classical or mean-field mediator gives a product
     state (negativity 0)
  MD gravitational self-attraction cannot make atomic particles: the Schroedinger-Newton ground state (solved here) has
     width w0 hbar^2/(G m^3); for a nucleon that is about 1e23 m; it reaches the size of the body only near 1e10 u, five
     orders of magnitude above today's interferometry record (25 kDa); canary: without self-gravity the trapped width does
     not depend on mass

Deterministic. Seed 20261201. Writes rg_mesh_gravity_attack_results.json.
Run:  python3 -I rg_mesh_gravity_attack.py      (numpy, scipy)
"""
import hashlib, json, math, os, sys
import numpy as np
import scipy.sparse as sps
import scipy.sparse.linalg as spla
from scipy.linalg import eigh_tridiagonal

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 20261201
R, FAILS = {}, []
G, HBAR, U = 6.67430e-11, 1.054571817e-34, 1.66053906660e-27


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.6g}')


def below(v, b):
    return f'< {b:g}' if abs(v) < b else fl(v)


# ============================================================================================ MA
def lattice_laplacian(n):
    e = np.ones(n); D = sps.diags([e[:-1], -2 * e, e[:-1]], [-1, 0, 1]); I = sps.identity(n)
    return (sps.kron(sps.kron(D, I), I) + sps.kron(sps.kron(I, D), I) + sps.kron(sps.kron(I, I), D)).tocsr()


def MA():
    n = 41; c = n // 2; L = lattice_laplacian(n); rng = np.random.default_rng(SEED)
    def idx(i, j, k):
        return (i * n + j) * n + k
    def solve(rho):
        return spla.spsolve(-L.tocsc(), 4 * math.pi * rho)          # -Lap phi = 4 pi rho  (phi > 0 means attraction depth)
    point = np.zeros(n ** 3); point[idx(c, c, c)] = 1.0
    ball = np.zeros(n ** 3); a = 3
    cells = [(i, j, k) for i in range(c - a, c + a + 1) for j in range(c - a, c + a + 1) for k in range(c - a, c + a + 1) if (i - c) ** 2 + (j - c) ** 2 + (k - c) ** 2 <= a * a]
    for t in cells:
        ball[idx(*t)] = 1.0 / len(cells)
    mesh = np.zeros(n ** 3)
    for _ in range(20):                                               # 20 random sub-masses and their mirror images: no dipole
        i, j, k = cells[rng.integers(len(cells))]
        mesh[idx(i, j, k)] += 1.0 / 40; mesh[idx(2 * c - i, 2 * c - j, 2 * c - k)] += 1.0 / 40
    shifted = np.zeros(n ** 3); shifted[idx(c + 2, c, c)] = 1.0
    phis = {k: solve(v) for k, v in (('point', point), ('ball', ball), ('mesh', mesh), ('shifted', shifted))}
    # relaxation (Jacobi) from zero converges to the same attractor
    diag = 6.0; phi = np.zeros(n ** 3); b = 4 * math.pi * mesh; A = -L
    for _ in range(3000):
        phi = phi + (b - A @ phi) / diag
    relax_err = float(np.abs(phi - phis['mesh']).max() / np.abs(phis['mesh']).max())
    probes = {r: [idx(c + r, c, c), idx(c, c + r, c), idx(c, c, c - r), idx(c - r, c, c)] for r in (6, 9, 12)}
    rel = {}
    for r, ps in probes.items():
        p0 = np.array([phis['point'][p] for p in ps])
        rel[r] = dict(ball=float(np.max(np.abs(np.array([phis['ball'][p] for p in ps]) / p0 - 1))),
                      mesh=float(np.max(np.abs(np.array([phis['mesh'][p] for p in ps]) / p0 - 1))),
                      shifted=float(np.max(np.abs(np.array([phis['shifted'][p] for p in ps]) / p0 - 1))))
    decays = rel[12]['mesh'] < rel[6]['mesh']
    ok = relax_err < 1e-3 and rel[12]['ball'] < 0.01 and rel[12]['mesh'] < 0.02 and decays and rel[12]['shifted'] > 3 * rel[12]['mesh']
    must(ok, 'MA')
    R['MA'] = dict(claim='Gravity is a counting protocol. On a 41^3 lattice, Jacobi relaxation of the passive reciprocal network '
                         'converges to the Poisson solution (relative error below 1e-3): one attractor. Outside a compact source of '
                         'radius 3, a point mass, a uniform ball and a random mesh of 40 sub-masses (20 random positions and their mirror '
                         'images, so no dipole) give potentials that differ by the relative amounts below at distances 6, 9, 12, falling '
                         'with distance: the far field reads the total mass, a count, and its centre, and sees structure only through '
                         'higher multipoles. Canary: the same mass displaced by 2 cells shows a dipole many times larger. A random mesh '
                         'without the mirror pairing shows its own dipole (about 5 per cent at distance 12): the centre is resolved, the '
                         'internal arrangement is not.',
                   status='computed (lattice); IDENTIFIED (Gauss law, shell theorem)', relaxation_error=fl(relax_err),
                   relative_difference_from_point={str(r): {k: fl(v) for k, v in d.items()} for r, d in rel.items()})


# ============================================================================================ MB
def MB():
    rng = np.random.default_rng(SEED + 1); n = 20000
    # source at -s or +s (one quantum branch each), test mass at 0; deflection sign follows the source branch
    branch = rng.integers(0, 2, n) * 2 - 1
    mean_field = np.zeros(n)                                          # field of the expectation: zero net force at the centre
    branch_sourced = branch.astype(float)
    classical_coin = (rng.integers(0, 2, n) * 2 - 1).astype(float)   # canary: a classical random choice of position
    frac = lambda x: dict(left=float(np.mean(x < 0)), none=float(np.mean(x == 0)), right=float(np.mean(x > 0)))
    out = dict(mean_field=frac(mean_field), branch_sourced=frac(branch_sourced), classical_coin=frac(classical_coin))
    ok = out['mean_field']['none'] == 1.0 and out['branch_sourced']['none'] == 0.0 and abs(out['branch_sourced']['left'] - 0.5) < 0.02 \
        and abs(out['classical_coin']['left'] - out['branch_sourced']['left']) < 0.02
    must(ok, 'MB')
    R['MB'] = dict(claim='A superposed source. A source placed left or right by a quantum outcome, test mass at the centre. Gravity sourced '
                         'by the expectation gives zero net deflection in every run; gravity sourced by the realized branch deflects in '
                         'every run, left or right with equal frequency. Page and Geilker (1981) observed deflection in every run, to '
                         'either side, which excludes expectation-sourced gravity without collapse. Canary: a classical coin gives the '
                         'same statistics as the branch model, so this test cannot tell quantum gravity from collapse.',
                   status='computed (protocol model); MEASURED anchor (Page and Geilker 1981)', fractions={k: {a: fl(b) for a, b in v.items()} for k, v in out.items()})


# ============================================================================================ MC
def MC():
    m, dx, d, t = 1e-14, 250e-6, 200e-6, 2.5
    # positions: mass A at {0, dx}, mass B at {d + dx, d + 2 dx}; nearest branches (A right, B left) at distance d
    xa, xb = (0.0, dx), (dx + d, 2 * dx + d)
    phase = np.array([[G * m * m * t / (HBAR * abs(xb[j] - xa[i])) for j in range(2)] for i in range(2)])
    psi = np.array([np.exp(1j * phase[i, j]) for i in range(2) for j in range(2)]) / 2
    rho = np.outer(psi, psi.conj())
    def partial_transpose(r):
        r4 = r.reshape(2, 2, 2, 2); return r4.transpose(0, 3, 2, 1).reshape(4, 4)
    neg = float(-sum(v for v in np.linalg.eigvalsh(partial_transpose(rho)) if v < 0))
    # canary: a classical (or mean-field) mediator applies only local phases, giving a product state
    loc = np.array([np.exp(1j * (phase[i, :].mean() + phase[:, j].mean())) for i in range(2) for j in range(2)]) / 2
    neg_loc = float(-sum(v for v in np.linalg.eigvalsh(partial_transpose(np.outer(loc, loc.conj()))) if v < 0))
    dphi = float(phase[1, 0] - phase[0, 0] - phase[1, 1] + phase[0, 1])
    ok = neg > 0.05 and neg_loc < 1e-12
    must(ok, 'MC')
    R['MC'] = dict(claim='The decisive experiment. Two masses of 1e-14 kg, each in a superposition of two positions 250 um apart, with the '
                         'nearest branches 200 um apart, interact gravitationally for 2.5 s. Gravity that acts branch by branch as a '
                         'quantum mediator gives the entangling phase and the negativity below. A classical or mean-field mediator gives '
                         'only local phases and a product state (negativity 0, canary). This is the proposal of Bose et al. and of '
                         'Marletto and Vedral; it has not been performed.',
                   status='computed (proposal model); IDENTIFIED (Bose et al. 2017; Marletto and Vedral 2017)', entangling_phase_rad=fl(dphi),
                   negativity=fl(neg), negativity_classical_mediator=below(neg_loc, 1e-12))


# ============================================================================================ MD
def sn_ground_width(lam, n=800, rmax=40.0, iters=400):
    """Radial Schroedinger-Newton ground state, units hbar = m = 1, coupling lam = G m^3 / hbar^2 in units of length^-1."""
    h = rmax / (n + 1); r = h * np.arange(1, n + 1); u = np.exp(-r) * r; u /= math.sqrt(np.sum(u * u) * h)
    for _ in range(iters):
        q = np.cumsum(u * u) * h; tail = np.cumsum((u * u / r)[::-1])[::-1] * h
        V = -lam * (q / r + tail - (u * u / r) * h * 0.0)
        d = 1.0 / h ** 2 + V; e = -0.5 / h ** 2 * np.ones(n - 1)
        w, v = eigh_tridiagonal(d, e, select='i', select_range=(0, 0))
        un = v[:, 0] / math.sqrt(np.sum(v[:, 0] ** 2) * h)
        u = 0.5 * u + 0.5 * np.abs(un); u /= math.sqrt(np.sum(u * u) * h)
    rms = math.sqrt(np.sum(r * r * u * u) * h)
    return rms, float(w[0])


def MD():
    rms1, _ = sn_ground_width(1.0); rms2, _ = sn_ground_width(2.0)
    scaling = rms1 / rms2                                             # width proportional to 1/lam: ratio 2
    w0 = rms1                                                         # rms width in units hbar^2/(G m^3)
    width = lambda m: w0 * HBAR ** 2 / (G * m ** 3)
    bodies = {'electron': 9.1093837e-31, 'nucleon': 1.67262192e-27, '25 kDa molecule': 25000 * U, '1e10 u': 1e10 * U}
    widths = {k: width(v) for k, v in bodies.items()}
    rho = 2000.0
    size = lambda m: (3 * m / (4 * math.pi * rho)) ** (1 / 3)
    lo, hi = 1e-22, 1e-10
    for _ in range(200):
        mid = math.sqrt(lo * hi)
        if width(mid) > size(mid):
            lo = mid
        else:
            hi = mid
    crossover_u = math.sqrt(lo * hi) / U
    gap = crossover_u / 25000
    # canary: a harmonic trap without self-gravity has a width fixed by the trap alone, sqrt(hbar/(2 m omega))
    ok = abs(scaling - 2) < 0.06 and widths['nucleon'] > 1e21 and 1e9 < crossover_u < 1e11 and gap > 1e4
    must(ok, 'MD')
    R['MD'] = dict(claim='Self-attraction cannot make atomic particles. The Schroedinger-Newton ground state, solved here, has rms width '
                         'w0 hbar^2/(G m^3) with w0 below (width halves when the coupling doubles, 2.05 on this grid). For an electron or a nucleon this '
                         'width exceeds the observable universe; gravitational self-localization therefore plays no part in atomic '
                         'structure. The width falls to the size of the body itself (density 2000 kg/m^3) near the mass below, five '
                         'orders above the 25 kDa interferometry record: the regime where a gravitating mesh would first shape a '
                         'quantum particle is open to future matter-wave experiments, not to atoms.',
                   status='computed (radial Schroedinger-Newton); IDENTIFIED (Diosi 1984; Giulini and Grossardt 2011)',
                   w0=fl(w0), width_ratio_lam_1_to_2=fl(scaling), width_m={k: fl(v) for k, v in widths.items()}, crossover_mass_u=fl(crossover_u),
                   gap_to_25kDa=fl(gap), diosi_penrose_bound=dict(R0_lower_bound_m=0.54e-10, parameter_free_R0_m=0.05e-10, source='Donadi et al. 2021'))


if __name__ == '__main__':
    for name, fn in (('MA', MA), ('MB', MB), ('MC', MC), ('MD', MD)):
        try:
            fn()
        except Exception as e:
            must(False, name); R[name] = dict(crash=repr(e))
        print(name, flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(open(os.path.abspath(__file__), 'rb').read()).hexdigest()
    json.dump(out, open(os.path.join(HERE, 'rg_mesh_gravity_attack_results.json'), 'w'), indent=1, sort_keys=True)
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
