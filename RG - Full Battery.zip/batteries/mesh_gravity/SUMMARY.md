# RG – Mesh Gravity and the Particle: what a gravitating mesh of particles forces on the quantum picture

**Verdict: the combination forces three things. Each is measurable, and none of them is new.**
- Gravity is itself a counting protocol, so it cannot see behind the particle.
- For a superposed source, gravity must either entangle or collapse. Mean-field gravity is out, and so is the parameter-free collapse model.
- Gravitational self-attraction cannot be the structure behind atomic particles. It first matters near 10¹⁰ u, five orders of magnitude above today's interferometry.

## 1. Gravity is a counting protocol (MA)

A shift-blind, reciprocal, passive network relaxes to one attractor. On a 41³ lattice, Jacobi relaxation reaches the Poisson solution to 3×10⁻⁵. Outside a compact source of radius 3:

| Distance | Uniform ball vs point | Mirror-paired random mesh (40 sub-masses) vs point | Same point displaced by 2 cells (canary) |
|---|---|---|---|
| 6 | 0.72 % | 3.5 % | 68 % |
| 9 | 0.17 % | 2.1 % | 44 % |
| 12 | 0.07 % | 1.5 % | 36 % |

- **What the far field reads.** It reads the total mass (a count) and its centre. The internal arrangement appears only in higher multipoles, which fade with distance.
- **What breaks the match.** A random mesh without mirror pairing shows its own dipole, about 5 % at distance 12.

This is the gravitational version of the counting theorem in *One World and the Particle*. A gravitating mesh therefore cannot reveal what lies behind a particle, for the same reason probes cannot: it measures a conserved charge through Gauss's law. Status: Gauss's law and the shell theorem, identified.

## 2. A superposed source: gravity must entangle or collapse (MB, MC)

**MB, mean field against branch-sourced gravity.** A quantum outcome places a source mass left or right of a centred test mass.
- Gravity sourced by the expectation value deflects the test mass in no run.
- Gravity sourced by the realized branch deflects it in every run, left or right with equal frequency.
- **Measured:** Page and Geilker (1981) saw a deflection in every run, to either side. This excludes expectation-sourced gravity without collapse.
- **Canary:** a classical coin gives the branch statistics too, so this measurement cannot tell quantum gravity from collapse.

**MC, the decisive experiment, not yet done.** Two masses of 10⁻¹⁴ kg are each split by 250 µm, with the nearest branches 200 µm apart, and interact for 2.5 s.

| Mediator | Entangling phase | Negativity |
|---|---|---|
| Quantum, branch by branch | 0.31 rad | 0.078 |
| Classical or mean-field (canary) | none (local phases only) | 0 (product state) |

This is the proposal of Bose et al. and Marletto–Vedral (2017).

**Collapse.** The underground germanium test (Donadi et al.) bounds the Diósi–Penrose parameter at R₀ > 0.54 Å. The parameter-free value, 0.05 Å, is excluded. Tunable collapse remains open.

**What One World says here:**
- If the gravitational record is one of the protocols that one quantum state must reproduce, gravity must act branch by branch: it either entangles or its record collapses the branches.
- If the cone is declared hybrid, classical field plus quantum matter as in Oppenheim's postquantum gravity, One World also holds, and the prediction is diffusion instead of entanglement.

RG does not choose between these. The experiment does.

## 3. Attraction cannot make atomic particles (MD)

- **The self-gravity width.** The Schrödinger–Newton ground state, solved here, has rms width 4.54 ħ²/(G m³).
- **Electron and nucleon.** For an electron the width is 10³³ m; for a nucleon, 1.6×10²³ m. Self-gravity plays no part in atomic structure.
- **Where it starts to matter.** The width shrinks to the body's own size, at density 2000 kg/m³, near 1.1×10¹⁰ u. That is 4×10⁵ times the 25 kDa interferometry record.

So the regime where a gravitating mesh would first shape a quantum particle lies ahead of matter-wave experiments, not inside the atom. Status: Diósi 1984, Giulini–Großardt 2011, identified.

## What this means for the programme

- The structure behind particles is not reachable through gravity at atomic scales.
- The places where gravity and the particle picture meet are two sharp, known experimental frontiers:
  - gravitationally mediated entanglement, at about 10⁻¹⁴ kg;
  - self-gravity of matter waves, at about 10¹⁰ u.
- Each has a stated outcome for each alternative, but no RG-specific number.
- A novelty would need an RG principle that fixes which alternative holds. One example: an argument that the gravitational record is reversible, so the field must be quantum. No current rung states one.

Battery: `rg_mesh_gravity_attack.py`, 4 groups (MA–MD), each with a canary, seed 20261201. Byte-identical on rerun; 4/4 mutations caught by the battery's own checks (crashes would count as defects).

## Attempt to lock a novel prediction: selection by unit count

**The idea.** Take the alternatives for gravity acting on a superposed source and count the constants each needs beyond G, ħ and c:

| Alternative | New constants | Status |
|---|---|---|
| Mean-field gravity (Schrödinger–Newton) | none | excluded without collapse by Page–Geilker; with collapse it needs a collapse model |
| Diósi–Penrose collapse, parameter-free | none (Penrose's choice of mass density) | excluded: R₀ > 0.54 Å against the natural 0.05 Å |
| Diósi–Penrose or CSL, tunable | R₀, or λ and r_c | open |
| Classical-quantum gravity (Oppenheim) | free diffusion and decoherence kernels, with D₂D₀ ≥ 1 in the simplest case | open; part of the space excluded |
| Gravity as a quantum mediator | none | untested; predicts a negativity of 0.078 in the setup of MC |

The only survivor with no new constant is entangling gravity. RG's no-internal-unit principle would then select it and predict a positive entanglement witness.

**Why this does not lock.**
1. **The no-internal-unit principle allows anchors.** A constant becomes legitimate once it is measured, exactly as Λ is in the GR derivation. Collapse and classical-quantum gravity add anchors not yet measured, and the principle does not exclude them; it only marks them as anchored deviations. So the selection is a parsimony rule, not a derivation.
2. **The eliminations depend on models.** Page–Geilker excludes mean-field gravity only under a no-collapse reading. Donadi et al. exclude parameter-free Diósi–Penrose only for Penrose's choice of mass density.
3. **The outcome is not distinctive.** Entanglement through gravity is the standard expectation of linearized quantum gravity. A positive result would be credited to that theory, not to RG. A negative result, with coherence maintained, would falsify RG's zero-anchor reading. That makes it a falsifiable commitment, but not a novel prediction.
4. **No sharp quantum-mechanical distinction.** Nothing in RG changes the Born rule, unitary dynamics or the entanglement structure, so RG predicts no number that quantum theory does not.

**Status:** no novel prediction is locked, and no paper is built. What remains is the commitment, stated with its falsifier: RG's zero-anchor reading predicts gravitationally mediated entanglement and no anomalous gravitational diffusion. Two observations would refute that reading:
- coherent masses at 10⁻¹⁴ kg that fail to entangle at the phase computed in MC;
- an anomalous gravitational diffusion, which would need a new anchor.

## Sources

- D. N. Page, C. D. Geilker, Indirect evidence for quantum gravity, Phys. Rev. Lett. 47 (1981) 979.
- S. Bose et al., Spin entanglement witness for quantum gravity, Phys. Rev. Lett. 119 (2017) 240401; C. Marletto, V. Vedral, Phys. Rev. Lett. 119 (2017) 240402.
- S. Donadi et al., Underground test of gravity-related wave function collapse, Nature Phys. 17 (2021) 74; arXiv:2111.13490.
- L. Diósi, Gravitation and quantum-mechanical localization of macro-objects, Phys. Lett. A 105 (1984) 199; D. Giulini, A. Großardt, Class. Quantum Grav. 28 (2011) 195026.
- J. Oppenheim, C. Sparaciari, B. Šoda, Z. Weller-Davies, Gravitationally induced decoherence vs space-time diffusion: testing the quantum nature of gravity, Nature Commun. 14 (2023) 7910; arXiv:2203.01982.
- Y. Y. Fein et al., Quantum superposition of molecules beyond 25 kDa, Nature Phys. 15 (2019) 1242.
