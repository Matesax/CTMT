#!/usr/bin/env python3
"""Mutation suite for rg_observer_bounds.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. A few minutes.

    python3 -I rg_observer_bounds_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('OA', 'Komar factor 1', 'komar == 2', 'komar == 1'),
    ('OC', 'event horizon at 17.7 Gly', "16.5 < d['event_Gly'] < 16.9", "17.5 < d['event_Gly'] < 17.9"),
    ('OF', 'Stefan-Boltzmann doubled', 'abs(s3 / sigma_SB - 1) < 1e-12', 'abs(s3 / sigma_SB - 2) < 1e-12'),
    ('OG', 'wrong total in 3 dimensions', "abs(totals['3'] - 4) < 1e-9", "abs(totals['3'] - 3) < 1e-9"),
    ('OH', 'dimension 3 selected', 'sol == [4]', 'sol == [3]'),
    ('OI', 'wrong recoil tension', "abs(z['Rb_recoil_2020-Cs_recoil_2018'] - 5.48) < 0.05", "abs(z['Rb_recoil_2020-Cs_recoil_2018'] - 4.48) < 0.05"),
    ('OL', 'wrong ratio in 3D', 'abs(r3 - 1) < 1e-9', 'abs(r3 - 1.5) < 1e-9'),
]


def main():
    base = open(os.path.join(HERE, 'rg_observer_bounds.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            for f in os.listdir(HERE):                                  # helpers and supplied data
                if f not in ('rg_observer_bounds.py', 'rg_observer_bounds_mutations.py', 'rg_observer_bounds_results.json'):
                    (shutil.copytree if os.path.isdir(os.path.join(HERE, f)) else shutil.copy)(os.path.join(HERE, f), os.path.join(tmp, f))
            open(os.path.join(tmp, 'rg_observer_bounds.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_observer_bounds.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_observer_bounds_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
