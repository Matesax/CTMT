# Resolution Geometry: full battery ledger

batteries: 34 | passed: 34 | groups: 298 | byte_identical: 34 | python: 3.13.18 | verdict: PASS

| battery | kind | rungs | groups | status | identical | runtime s |
|---|---|---|---|---|---|---|
| Native chain (this print) | print | L18--L29, L38--L41, L59 | 7 | PASS | True | 22.3 |
| This print: audit | print | L0--L133 | 6 | PASS | True | 0.7 |
| Physical Dynamics | companion | L64--L68, L94--L109 | 8 | PASS | True | 34.4 |
| Tensor Derivation | companion | L64--L68, L94--L109 | 35 | PASS | True | 55.9 |
| Coherence Geometry | companion | L1, L27--L29, L35, L38--L41 | 15 | PASS | True | 1.0 |
| Quantum Gravity | companion | L1--L2, L19, L38--L48, L64--L68, L94--L109 | 30 | PASS | True | 22.2 |
| Observer Bounds | companion | L28, L34--L35, L38--L39, L64--L68, L81--L109 | 12 | PASS | True | 0.7 |
| GR Automation | companion | L28--L35, L104--L106, L117, L120 | 17 | PASS | True | 17.3 |
| Non-Spacetime Attractors and the Source of Gravity | companion | L64--L68, L94--L109 | 10 | PASS | True | 32.2 |
| Tensor Frontier | companion | L1--L2, L28, L35, L64--L68, L94--L95, L117, L120 | 17 | PASS | True | 7.9 |
| Magnetism | companion | L1--L2, L28, L64--L68, L94--L95, L117, L120 | 9 | PASS | True | 6.9 |
| Light Ring | companion | L1--L2, L28, L35, L64--L68, L94--L95, L117, L120 | 5 | PASS | True | 6.9 |
| GR Equivalence | companion | L1--L2, L4, L6, L9, L21--L24, L35, L64 | 6 | PASS | True | 0.9 |
| Gravity Closure | companion | L1--L2, L9, L64--L68, L94--L95 | 5 | PASS | True | 9.7 |
| Ringdown Light Ring | companion | L1--L2, L28, L35, L64--L68, L94--L95 | 7 | PASS | True | 5.3 |
| GR Derivation | companion | L1--L2, L9, L64--L68, L80, L94--L95 | 7 | PASS | True | 19.8 |
| GR Derivation: order and count | companion | L1--L2, L9, L64--L68, L80, L94--L95 | 7 | PASS | True | 17.6 |
| Record Metric | companion | L4, L28--L29, L35--L36, L38--L39 | 8 | PASS | True | 37.1 |
| One World and the Particle | companion | L1--L6, L15, L38--L43, L94--L95 | 6 | PASS | True | 8.2 |
| Forced Predictions | companion | L1--L4, L19, L47--L49 | 8 | PASS | True | 36.0 |
| Programme Closure | companion | L29, L39, L66, L74 | 4 | PASS | True | 58.7 |
| Record Dynamics | companion | L80, L90, L111 | 8 | PASS | True | 8.5 |
| Record Gaps | companion | L80, L90, L102--L104 | 6 | PASS | True | 4.0 |
| Attack: forced metric | attack | L28--L29, L38--L39 | 6 | PASS | True | 28.8 |
| Attack: autonomous dynamics | attack | L80 | 7 | PASS | True | 1.4 |
| Attack: completion budget | attack | L119 | 7 | PASS | True | 3.7 |
| Attack: completion tower | attack | L119 | 5 | PASS | True | 6.6 |
| Attack: classical gravity | attack | L64--L68, L119 | 3 | PASS | True | 0.7 |
| Attack: selection obstruction | attack | L29, L39 | 4 | PASS | True | 1.0 |
| Attack: hidden room | attack | L1--L2, L19 | 5 | PASS | True | 1.7 |
| Attack: hidden response selection | attack | L80 | 5 | PASS | True | 6.0 |
| Attack: information protection | attack | L1--L6, L38--L41 | 5 | PASS | True | 0.2 |
| Attack: mesh gravity | attack | L119 | 4 | PASS | True | 114.3 |
| Attack: one world | attack | L1--L6 | 4 | PASS | True | 1.2 |
