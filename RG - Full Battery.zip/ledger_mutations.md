# Resolution Geometry: full battery ledger

batteries: 34 | passed: 34 | groups: 298 | byte_identical: 34 | mutations_caught: 297 | mutations_total: 297 | verdict: PASS

| battery | kind | rungs | groups | status | identical | runtime s | mutations |
|---|---|---|---|---|---|---|---|
| Native chain (this print) | print | L18--L29, L38--L41, L59 | 7 | PASS | True | 20.4 | 13/13 |
| This print: audit | print | L0--L133 | 6 | PASS | True | 0.5 | 11/11 |
| Physical Dynamics | companion | L64--L68, L94--L109 | 8 | PASS | True | 30.0 | 7/7 |
| Tensor Derivation | companion | L64--L68, L94--L109 | 35 | PASS | True | 54.9 | 8/8 |
| Coherence Geometry | companion | L1, L27--L29, L35, L38--L41 | 15 | PASS | True | 0.9 | 7/7 |
| Quantum Gravity | companion | L1--L2, L19, L38--L48, L64--L68, L94--L109 | 30 | PASS | True | 28.5 | 13/13 |
| Observer Bounds | companion | L28, L34--L35, L38--L39, L64--L68, L81--L109 | 12 | PASS | True | 0.7 | 7/7 |
| GR Automation | companion | L28--L35, L104--L106, L117, L120 | 17 | PASS | True | 19.3 | 8/8 |
| Non-Spacetime Attractors and the Source of Gravity | companion | L64--L68, L94--L109 | 10 | PASS | True | 36.5 | 8/8 |
| Tensor Frontier | companion | L1--L2, L28, L35, L64--L68, L94--L95, L117, L120 | 17 | PASS | True | 16.8 | 22/22 |
| Magnetism | companion | L1--L2, L28, L64--L68, L94--L95, L117, L120 | 9 | PASS | True | 10.8 | 14/14 |
| Light Ring | companion | L1--L2, L28, L35, L64--L68, L94--L95, L117, L120 | 5 | PASS | True | 13.7 | 10/10 |
| GR Equivalence | companion | L1--L2, L4, L6, L9, L21--L24, L35, L64 | 6 | PASS | True | 1.8 | 13/13 |
| Gravity Closure | companion | L1--L2, L9, L64--L68, L94--L95 | 5 | PASS | True | 20.2 | 7/7 |
| Ringdown Light Ring | companion | L1--L2, L28, L35, L64--L68, L94--L95 | 7 | PASS | True | 12.0 | 9/9 |
| GR Derivation | companion | L1--L2, L9, L64--L68, L80, L94--L95 | 7 | PASS | True | 40.2 | 13/13 |
| GR Derivation: order and count | companion | L1--L2, L9, L64--L68, L80, L94--L95 | 7 | PASS | True | 36.0 | 9/9 |
| Record Metric | companion | L4, L28--L29, L35--L36, L38--L39 | 8 | PASS | True | 38.6 | 12/12 |
| One World and the Particle | companion | L1--L6, L15, L38--L43, L94--L95 | 6 | PASS | True | 8.3 | 7/7 |
| Forced Predictions | companion | L1--L4, L19, L47--L49 | 8 | PASS | True | 34.6 | 12/12 |
| Programme Closure | companion | L29, L39, L66, L74 | 4 | PASS | True | 57.9 | 7/7 |
| Record Dynamics | companion | L80, L90, L111 | 8 | PASS | True | 9.6 | 9/9 |
| Record Gaps | companion | L80, L90, L102--L104 | 6 | PASS | True | 3.6 | 7/7 |
| Attack: forced metric | attack | L28--L29, L38--L39 | 6 | PASS | True | 27.0 | 9/9 |
| Attack: autonomous dynamics | attack | L80 | 7 | PASS | True | 1.3 | 10/10 |
| Attack: completion budget | attack | L119 | 7 | PASS | True | 3.3 | 8/8 |
| Attack: completion tower | attack | L119 | 5 | PASS | True | 6.3 | 6/6 |
| Attack: classical gravity | attack | L64--L68, L119 | 3 | PASS | True | 0.8 | 5/5 |
| Attack: selection obstruction | attack | L29, L39 | 4 | PASS | True | 0.8 | 4/4 |
| Attack: hidden room | attack | L1--L2, L19 | 5 | PASS | True | 1.3 | 4/4 |
| Attack: hidden response selection | attack | L80 | 5 | PASS | True | 5.0 | 4/4 |
| Attack: information protection | attack | L1--L6, L38--L41 | 5 | PASS | True | 0.2 | 5/5 |
| Attack: mesh gravity | attack | L119 | 4 | PASS | True | 120.6 | 4/4 |
| Attack: one world | attack | L1--L6 | 4 | PASS | True | 1.3 | 5/5 |
