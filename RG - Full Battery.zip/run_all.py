#!/usr/bin/env python3
"""Resolution Geometry: full battery runner.

Runs every registered battery in its own temporary copy, with ``python3 -I``, and checks three things:

  1. exit status 0;
  2. an empty ``failures`` list in the results file, where the battery writes one;
  3. the results file is byte-identical to the shipped reference (determinism; the reference carries the seed).

With ``--mutations`` it also runs every mutation suite. A mutation counts as caught only when the targeted group
fails; a crash counts as a suite defect, not as a catch (this rule lives in each suite).

Writes ``ledger.json`` (one record per battery: status, runtime, groups, rungs, script hash) and ``LEDGER.md``.
Shipped files are never modified. Exit status 0 only when every battery passes (and, with ``--mutations``, every
mutation is caught).

    python3 -I run_all.py                    # reproduction and determinism, about 10 to 20 minutes
    python3 -I run_all.py --mutations        # plus every mutation suite, about 1 to 2 hours
    python3 -I run_all.py --only record_gaps record_dynamics
    python3 -I run_all.py --jobs 2           # two batteries at a time
"""
import argparse, concurrent.futures, hashlib, json, os, re, shutil, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
BAT = os.path.join(HERE, 'batteries')


def sha(path):
    return hashlib.sha256(open(path, 'rb').read()).hexdigest()


def run_one(entry, timeout):
    src = os.path.join(BAT, entry['key'])
    rec = dict(key=entry['key'], title=entry['title'], kind=entry['kind'], rungs=entry['rungs'], seed=entry['seed'])
    if sha(os.path.join(src, entry['script'])) != entry['sha256']:
        rec.update(status='SCRIPT HASH MISMATCH'); return rec
    with tempfile.TemporaryDirectory() as tmp:
        work = os.path.join(tmp, entry['key']); shutil.copytree(src, work)
        os.remove(os.path.join(work, entry['results']))            # the battery must regenerate it
        t0 = time.time()
        try:
            run = subprocess.run([sys.executable, '-I', entry['script']], cwd=work, capture_output=True, text=True, timeout=timeout)
            code, err = run.returncode, run.stderr[-2000:]
        except subprocess.TimeoutExpired:
            code, err = 'TIMEOUT', ''
        rec['runtime_s'] = round(time.time() - t0, 1)
        out = os.path.join(work, entry['results'])
        if not os.path.exists(out):
            rec.update(status='NO RESULTS', exit=code, stderr=err); return rec
        data = json.load(open(out))
        groups = sorted(k for k, v in data.items() if isinstance(v, dict) and 'claim' in v)
        fails = data.get('failures', [])
        identical = open(out, 'rb').read() == open(os.path.join(src, entry['results']), 'rb').read()
        rec.update(exit=code, groups=groups, failures=fails, byte_identical=identical, results_sha256=sha(out))
        ok = code == 0 and not fails and identical
        rec['status'] = 'PASS' if ok else 'FAIL'
        if not ok:
            rec['stderr'] = err
    return rec


def run_mutations(entry, timeout):
    if not entry.get('mutations'):
        return dict(status='no suite')
    src = os.path.join(BAT, entry['key'])
    with tempfile.TemporaryDirectory() as tmp:
        work = os.path.join(tmp, entry['key']); shutil.copytree(src, work)
        t0 = time.time()
        try:
            run = subprocess.run([sys.executable, '-I', entry['mutations']], cwd=work, capture_output=True, text=True, timeout=timeout)
            text, code = run.stdout, run.returncode
        except subprocess.TimeoutExpired:
            text, code = '', 'TIMEOUT'
    m = re.search(r'(\d+)\s*/\s*(\d+)\s+caught', text)
    caught, total = (int(m.group(1)), int(m.group(2))) if m else (0, None)
    survived = [ln for ln in text.splitlines() if 'SURVIVED' in ln or 'SUITE DEFECT' in ln]
    ok = code == 0 and total is not None and caught == total
    return dict(status='ALL CAUGHT' if ok else 'DEFECT', caught=caught, total=total, survived=survived, runtime_s=round(time.time() - t0, 1))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--mutations', action='store_true')
    ap.add_argument('--only', nargs='*')
    ap.add_argument('--timeout', type=int, default=3600)
    ap.add_argument('--jobs', type=int, default=1, help='batteries run in parallel (results do not depend on it)')
    a = ap.parse_args()
    reg = json.load(open(os.path.join(HERE, 'registry.json')))
    if a.only:
        reg = [e for e in reg if e['key'] in a.only]
    def job(e):
        rec = run_one(e, a.timeout)
        line = f"{rec['status']:<6} {e['key']:<24} {rec.get('runtime_s', 0):>7.1f} s  groups {len(rec.get('groups', [])):>2}"
        if a.mutations:
            rec['mutation_suite'] = run_mutations(e, a.timeout)
            ms = rec['mutation_suite']
            line += f"  mutations {ms.get('caught', '-')}/{ms.get('total', '-')} {ms['status']}"
        print(line, flush=True)
        return rec
    with concurrent.futures.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        ledger = list(ex.map(job, reg))                      # results kept in registry order
    ok = all(r['status'] == 'PASS' for r in ledger) and (not a.mutations or all(r['mutation_suite']['status'] in ('ALL CAUGHT', 'no suite') for r in ledger))
    summary = dict(batteries=len(ledger), passed=sum(r['status'] == 'PASS' for r in ledger),
                   groups=sum(len(r.get('groups', [])) for r in ledger),
                   byte_identical=sum(bool(r.get('byte_identical')) for r in ledger), python=sys.version.split()[0])
    if a.mutations:
        summary['mutations_caught'] = sum(r['mutation_suite'].get('caught', 0) for r in ledger)
        summary['mutations_total'] = sum(r['mutation_suite'].get('total') or 0 for r in ledger)
    summary['verdict'] = 'PASS' if ok else 'FAIL'
    name = 'ledger_mutations' if a.mutations else 'ledger'
    if a.only:
        name += '_partial'
    json.dump(dict(summary=summary, batteries=ledger), open(os.path.join(HERE, name + '.json'), 'w'), indent=1)
    with open(os.path.join(HERE, name + '.md'), 'w') as f:
        f.write('# Resolution Geometry: full battery ledger\n\n')
        f.write(' | '.join(f'{k}: {v}' for k, v in summary.items()) + '\n\n')
        f.write('| battery | kind | rungs | groups | status | identical | runtime s' + (' | mutations' if a.mutations else '') + ' |\n')
        f.write('|---|---|---|---|---|---|---' + ('|---' if a.mutations else '') + '|\n')
        for r in ledger:
            row = f"| {r['title']} | {r['kind']} | {r['rungs']} | {len(r.get('groups', []))} | {r['status']} | {r.get('byte_identical')} | {r.get('runtime_s')}"
            if a.mutations:
                ms = r['mutation_suite']; row += f" | {ms.get('caught', '-')}/{ms.get('total', '-')}"
            f.write(row + ' |\n')
    print(json.dumps(summary))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
