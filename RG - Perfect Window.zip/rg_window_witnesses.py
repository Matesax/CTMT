"""Witnesses for 'The Impossibility of the Perfect Window'. Exact, symbolic or deterministic; no random sampling.
W1  two worlds, one record: any decision rule has worst-case error >= |Q(A) - Q(B)| / 2 (two-point bound, exact)
W2  refinement inside a symmetry-closed family never separates orbits: Pauli-twirled (reference-frame-free) access maps every
    qubit state to I/2; adding a shared frame (a new resource) splits the fibre
W3  finite recorder: k-bit records cannot separate 2^k + 1 hypotheses (pigeonhole); Fano lower bound for probabilistic records
W4  causal horizon in the measured universe: flat LCDM with our Pantheon+ Omega_m = 0.3326 has a finite comoving event horizon
W5  many-room building: cylinder and Moebius band are locally identical flat strips, globally distinct (orientation holonomy +1 vs -1)
W6  measurement context: unbiased joint approximations of sigma_x and sigma_z exist iff eta_x^2 + eta_z^2 <= 1 (Busch); boundary is exact
W7  development: logistic map r = 4, two initial states 1e-30 apart separate to O(1) after ~ log2(1e30) ~ 100 steps (400-digit arithmetic)
Run: python rg_window_witnesses.py   (sympy, mpmath, scipy)
"""
import json, math, hashlib, pathlib, itertools
import sympy as sp
import mpmath as mp
from scipy.integrate import quad
RES = {}
def must(c, m):
    if not c: raise AssertionError(m)

# W1 two-point bound: records equal under A and B; any rule outputs the same law in both worlds
qA, qB, a = sp.symbols("q_A q_B a", real=True)
worst = sp.Max(sp.Abs(a - qA), sp.Abs(a - qB))
best = sp.Abs(qA - qB) / 2                                       # attained at a = (qA + qB)/2
chk = sp.simplify(worst.subs(a, (qA + qB) / 2).subs({qA: 3, qB: 7}) - best.subs({qA: 3, qB: 7}))
must(chk == 0, "W1")
RES["W1"] = dict(claim="If O(A) = O(B), every estimator of Q based on the records has max(|err_A|, |err_B|) >= |Q(A) - Q(B)|/2",
                 status="PROVED (triangle inequality) + exact instance", instance="Q(A)=3, Q(B)=7: minimax error 2")

# W2 reference-frame-free access: Pauli twirl
I2 = sp.eye(2); X = sp.Matrix([[0, 1], [1, 0]]); Y = sp.Matrix([[0, -sp.I], [sp.I, 0]]); Z = sp.Matrix([[1, 0], [0, -1]])
r1, r2, r3 = sp.symbols("r1 r2 r3", real=True)
rho = (I2 + r1 * X + r2 * Y + r3 * Z) / 2
tw = sp.simplify(sum((P * rho * P.H for P in (I2, X, Y, Z)), sp.zeros(2)) / 4)
must(sp.simplify(tw - I2 / 2) == sp.zeros(2), "W2")
RES["W2"] = dict(claim="Every protocol available without a shared reference frame factors through the twirl, which sends every qubit state to I/2: "
                       "refining such protocols never separates the orbit. A shared frame is a new declared resource that splits the fibre",
                 status="PROVED (symbolic twirl) + IMPORTED (Bartlett-Rudolph-Spekkens)", twirled_state=str(tw))

# W3 pigeonhole and Fano
k = 3; M = 2 ** k + 1
fano = lambda M, bits: 1 - (bits + 1) / math.log2(M)
RES["W3"] = dict(claim="k-bit deterministic records separate at most 2^k hypotheses; with probabilistic records, Fano gives error >= 1 - (k+1)/log2 M",
                 status="PROVED (pigeonhole, Fano)", k=k, hypotheses=M, fano_bound_for_M_2pow20_k10=fano(2 ** 20, 10))
must(M > 2 ** k and fano(2 ** 20, 10) > 0.4, "W3")

# W4 event horizon, flat LCDM with our measured Omega_m
Om = 0.3326; OL = 1 - Om; H0 = 70.0; c = 299792.458
integrand = lambda a: 1.0 / (a * a * math.sqrt(Om / a ** 3 + OL))
dE = c / H0 * quad(integrand, 1.0, math.inf)[0]                 # comoving event horizon today, Mpc
dE_Gly = dE * 3.26156e-3
must(dE_Gly > 10 and dE_Gly < 25, "W4")
RES["W4"] = dict(claim="With Lambda > 0 (Pantheon+: Lambda = 0 rejected by Delta chi^2 = 48), every comoving observer has a finite event horizon: "
                       "events beyond it never enter its records", status="COMPUTED (flat LCDM, Omega_m = 0.3326, H0 = 70)",
                 event_horizon_Mpc=dE, event_horizon_Gly=dE_Gly)

# W5 cylinder vs Moebius: transport a normal around the core loop
def transported_normal(twist):
    phi = sp.Symbol("phi", real=True)
    n = sp.Matrix([sp.cos(twist * phi / 2), sp.sin(twist * phi / 2)])
    return sp.simplify(n.subs(phi, 2 * sp.pi).dot(n.subs(phi, 0)))
cyl, mob = transported_normal(0), transported_normal(1)
must(cyl == 1 and mob == -1, "W5")
RES["W5"] = dict(claim="Cylinder and Moebius band: every small patch is the same flat strip; the orientation holonomy around the core loop is +1 vs -1",
                 status="PROVED (exact)", cylinder=int(cyl), moebius=int(mob))

# W6 Busch joint measurability: G(s,t) = (I + s eta_x X + t eta_z Z)/4 must be positive for s,t = +-1
ex, ez = sp.symbols("eta_x eta_z", nonnegative=True)
def min_eig(exv, ezv):
    vals = []
    for s, t in itertools.product((1, -1), repeat=2):
        G = (I2 + s * exv * X + t * ezv * Z) / 4; vals += [sp.N(v) for v in G.eigenvals()]
    return min(float(v) for v in vals)
on = min_eig(sp.sqrt(sp.Rational(1, 2)), sp.sqrt(sp.Rational(1, 2))); out = min_eig(sp.Rational(3, 4), sp.Rational(3, 4))
must(abs(on) < 1e-15 and out < 0, "W6")
RES["W6"] = dict(claim="Unbiased joint approximation of sigma_x and sigma_z with sharpness eta_x, eta_z exists iff eta_x^2 + eta_z^2 <= 1",
                 status="IMPORTED (Busch 1986) + exact boundary check", min_eig_on_boundary=on, min_eig_at_0p75_0p75=out)

# W7 chaos horizon
mp.mp.dps = 400
x = mp.mpf("0.3141592653589793"); y = x + mp.mpf("1e-30"); n_sep = None
for n in range(1, 200):
    x = 4 * x * (1 - x); y = 4 * y * (1 - y)
    if abs(x - y) > mp.mpf("0.1"): n_sep = n; break
must(n_sep is not None and 85 <= n_sep <= 110, "W7")
RES["W7"] = dict(claim="Finite precision delta gives a prediction horizon ~ log(1/delta)/lambda; logistic r = 4 (lambda = ln 2), delta = 1e-30",
                 status="EXECUTED (400-digit arithmetic)", steps_to_separation=n_sep, predicted=math.log2(1e30))
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_window_witnesses_results.json").write_text(json.dumps(RES, indent=1, default=str))
for kk, v in RES.items():
    if isinstance(v, dict): print(kk, "|", v["status"])
print(dE, dE_Gly, n_sep)
