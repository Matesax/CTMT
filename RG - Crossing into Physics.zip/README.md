# RG - Crossing into Physics: the consilience engine (CN01-CN11)

    python3 rg_consilience_attack.py --data data --figs figs   # needs rg_gnss_real_attack.py alongside
    python3 rg_consilience_attack.py --data data --canary      # unblind-early; pretend falsified test passed; prefer a cluster

Four routes to one baseline (real GEONET GPS): code SPP, DD phase, published coordinates, DD code. Two contradicting
clusters -> CORRESPONDENCE; resolved only by pre-registered tests of distinctive assumptions (round 1: integer
ambiguities pass, code whiteness not failed -- registered expectation wrong; round 2: constant per-satellite code bias,
z up to 9). Result: 3335.3913 +- 0.0034 m LOCKED conditional on five listed assumptions. Physical-curvature resolution
ladder (Sagnac, relativistic clock detected; Shapiro double difference and ellipsoid curvature behind STRUCTURAL WALLs).
11/11 pass; canaries 3/3. Deterministic (no seeds): repetition across sessions/stations is the next step.
