#!/usr/bin/env python3
"""
RG consilience engine on real GPS data: battery CN01-CN09
=========================================================
Target quantity: the 0759-3040 baseline length (GEONET, 2005-04-02 00-01 GPST). A physical value is certified only as
"v +- u conditional on the intersection of the assumption sets of agreeing routes" (Duhem-Quine made computable).

  CN01 route R1: undifferenced code single-point positions, baseline from their difference (block-bootstrap uncertainty)
  CN02 route R2: double-differenced L1 carrier phase, batch float ambiguities (cm-level; different error budget)
  CN03 route R3: published GEONET coordinates (independent pipeline; declared uncertainty)
  CN04 route R4: double-differenced code (cancels clocks/orbits, keeps code noise and multipath)
  CN05 assumption-overlap matrix; pairwise agreement; value conditional on the intersection; injected errors in a
       NON-shared assumption are detected, errors in the intersection are provably undetectable
  CN06 model-class robustness: each route recomputed over declared alternatives (mask, weighting, troposphere, reference
       satellite) -> FORCED / CONDITIONAL relative to the route's own uncertainty
  CN07 commitment blinding: the published reference is hidden behind a committed random rotation; the reported statistic
       is rotation-invariant (equivariance checked, not assumed); results are hashed before unblinding; a pipeline that
       reads the unblinded reference before freezing is flagged
  CN08 physical curvature resolution ladder: Sagnac and relativistic clock terms (detected), Shapiro delay (single-station
       cm; differential sub-mm: STRUCTURAL WALL at this resolution), ellipsoid chord curvature (STRUCTURAL WALL)
  CN09 status of the physical value: LOCKED-conditional with the explicit residual assumption set

Run:  python3 rg_consilience_attack.py [--data .] [--out FILE] [--figs DIR] [--canary]
"""
import argparse, json, math, sys, time, hashlib, os, secrets
import numpy as np
import rg_gnss_real_attack as G

RESULTS, MUT, CTX = [], {}, {}
LOG = []                                   # ordered event log for the blinding protocol


def f_(x): return float(np.round(float(x), 9))


def register(aid, naive, keep, passed, ev, verdict):
    RESULTS.append(dict(id=aid, naive_claim=naive, rg_claim=keep, passed=bool(passed), verdict=verdict, evidence=ev))
    print(f"[{'PASS' if passed else 'FAIL'}] {aid} {verdict:16s} {keep[:84]}")


def block_bootstrap_sd(series, block=10, reps=2000, rng=None):
    rng = rng or np.random.default_rng(0); n = len(series); nb = n//block; means = []
    blocks = [series[i*block:(i+1)*block] for i in range(nb)]
    for _ in range(reps):
        pick = rng.integers(0, nb, nb); means.append(np.mean(np.concatenate([blocks[k] for k in pick])))
    return float(np.std(means, ddof=1))


# ------------------------------------------------------------------ satellite geometry per station/epoch
def sat_geom(ep, ephs, x_rx, prn, code="C1"):
    ob = ep["obs"].get(prn)
    if ob is None or not np.isfinite(ob.get(code, np.nan)): return None
    e = G.select_eph(ephs, prn, ep["tow"])
    if e is None: return None
    rho = ob[code]; tt = ep["tow"]-rho/G.C
    for _ in range(3):
        pos, clk = G.sat_pos_clock(e, tt); tt = ep["tow"]-rho/G.C-clk
    pos, clk = G.sat_pos_clock(e, tt)
    tau = np.linalg.norm(pos-x_rx)/G.C; th = G.OMEGA_E*tau
    pos = np.array([math.cos(th)*pos[0]+math.sin(th)*pos[1], -math.sin(th)*pos[0]+math.cos(th)*pos[1], pos[2]])
    lat, lon, h = G.ecef2geo(x_rx); d = pos-x_rx; el = math.asin((G.enu_matrix(lat, lon)@d)[2]/np.linalg.norm(d))
    return dict(pos=pos, el=el, ob=ob)


def dd_baseline(kind, mask_deg=10.0, weighting="elev", ref_choice="highest", tropo=False, fixed=None):
    """double-difference batch LS: unknown baseline b (and float ambiguities for phase). Station A at its anchor
    (declared calibration station; ppm sensitivity only)."""
    ephs = G.read_nav(f"{CTX['data']}/07590920.05n"); oA, oB = CTX["oA"], CTX["oB"]
    xA = CTX["xA"]; byB = {ep["key"]: ep for ep in oB}
    lam1 = G.C/G.F1
    # satellites common and continuous
    counts = {}
    for ep in oA:
        if ep["key"] not in byB: continue
        for prn in ep["obs"]:
            if prn in byB[ep["key"]]["obs"]: counts[prn] = counts.get(prn, 0)+1
    sats = sorted(p for p, c in counts.items() if c >= 100)
    # elevations at mid-epoch for reference choice
    mid = oA[len(oA)//2]; els = {}
    for prn in sats:
        g = sat_geom(mid, ephs, xA, prn)
        if g: els[prn] = g["el"]
    sats = [p for p in sats if p in els and els[p] > math.radians(mask_deg)]
    if ref_choice == "highest": ref = max(sats, key=lambda p: els[p])
    else: ref = sorted(sats, key=lambda p: -els[p])[1]
    others = [p for p in sats if p != ref]
    # cycle-slip screen on GF phase (both stations)
    gam = (G.F1/G.F2)**2; l2 = G.C/G.F2
    def slipfree(prn):
        for o in (oA, oB):
            v = [lam1*ep["obs"][prn]["L1"]-l2*ep["obs"][prn]["L2"] for ep in o if prn in ep["obs"] and np.isfinite(ep["obs"][prn].get("L1", np.nan))]
            if len(v) > 1 and np.max(np.abs(np.diff(v))) > 0.3: return False
        return True
    if kind == "phase": others = [p for p in others if slipfree(p)] if slipfree(ref) else others
    nb = 3; na = len(others) if (kind == "phase" and fixed is None) else 0; b = CTX["xB_approx"]-xA
    for _ in range(6):
        Nm = np.zeros((nb+na, nb+na)); rv = np.zeros(nb+na); rows_all = []
        for ep in oA:
            epB = byB.get(ep["key"])
            if epB is None: continue
            xB = xA+b; sd, Hs, ws = {}, {}, {}
            for prn in [ref]+others:
                gA = sat_geom(ep, ephs, xA, prn); gB = sat_geom(epB, ephs, xB, prn)
                if gA is None or gB is None or gA["el"] < math.radians(mask_deg): continue
                if kind == "phase":
                    if not (np.isfinite(gA["ob"].get("L1", np.nan)) and np.isfinite(gB["ob"].get("L1", np.nan))): continue
                    obsA, obsB = lam1*gA["ob"]["L1"], lam1*gB["ob"]["L1"]
                else:
                    obsA, obsB = gA["ob"]["C1"], gB["ob"]["C1"]
                rA = np.linalg.norm(gA["pos"]-xA); rB = np.linalg.norm(gB["pos"]-xB)
                tr = 0.0
                if tropo:
                    la, lo, h = G.ecef2geo(xB); zh, zw = G.saastamoinen_zenith(la, h); la2, lo2, h2 = G.ecef2geo(xA); zh2, zw2 = G.saastamoinen_zenith(la2, h2)
                    tr = (zh+zw)*G.mapping(gB["el"])-(zh2+zw2)*G.mapping(gA["el"])
                sd[prn] = (obsB-obsA)-(rB-rA)-tr; Hs[prn] = -(gB["pos"]-xB)/rB
                ws[prn] = math.sin(gB["el"])**2 if weighting == "elev" else 1.0
            if ref not in sd: continue
            ks = [p for p in others if p in sd]
            if len(ks) < 3: continue
            y = np.array([sd[p]-sd[ref] for p in ks]); H = np.array([Hs[p]-Hs[ref] for p in ks])
            if fixed is not None: y = y-lam1*np.array([fixed[p] for p in ks])
            # DD covariance: D diag(1/w) D^T
            winv = np.array([1/ws[ref]]+[1/ws[p] for p in ks]); D = np.hstack([-np.ones((len(ks), 1)), np.eye(len(ks))])
            Cdd = D@np.diag(winv)@D.T; Wm = np.linalg.inv(Cdd)
            A = np.zeros((len(ks), nb+na)); A[:, :3] = H
            if kind == "phase" and fixed is None:
                for i, p in enumerate(ks): A[i, nb+others.index(p)] = lam1
            Nm += A.T@Wm@A; rv += A.T@Wm@y; rows_all.append((A, y, Wm))
        # phase: solve with ambiguities; code: baseline only (ambiguity block empty)
        sol = np.linalg.solve(Nm, rv); b = b+sol[:3]
        if kind == "phase":
            CTX.setdefault("_amb", {})[(mask_deg, weighting, ref_choice, tropo)] = sol[3:]
        if np.linalg.norm(sol[:3]) < 1e-5 and kind == "code": break
        if kind == "phase" and np.linalg.norm(sol[:3]) < 1e-6: break
        if kind == "phase":
            # fold ambiguity estimate into observations for the next iteration by keeping it as unknown: re-solve fully
            pass
    # posterior variance and residual autocorrelation inflation
    res = []; dof = 0
    for A, y, Wm in rows_all:
        r = y-A@sol; res.append(r[0]); dof += len(y)
    s0 = 1.0
    chi = sum(float((y-A@sol)@Wm@(y-A@sol)) for A, y, Wm in rows_all); s0 = math.sqrt(chi/max(dof-(nb+na), 1))
    cov = np.linalg.inv(Nm)*s0**2; res = np.array(res)
    rho1 = float(np.corrcoef(res[:-1], res[1:])[0, 1]) if len(res) > 3 else 0.0
    infl = math.sqrt((1+max(rho1, 0))/(1-max(rho1, 0)+1e-9))
    L = float(np.linalg.norm(b)); g = b/L; uL = float(math.sqrt(g@cov[:3, :3]@g))*infl
    amb = dict(zip(others, sol[3:])) if na else {}; amb_sd = dict(zip(others, np.sqrt(np.diag(cov)[3:])*infl)) if na else {}
    return dict(length=L, u=uL, vector=b, ref=ref, nsat=len(others)+1, s0=s0, inflation=infl, amb=amb, amb_sd=amb_sd)


def load(data):
    CTX["data"] = data
    hA, oA = G.read_obs(f"{data}/07590920.05o"); hB, oB = G.read_obs(f"{data}/30400920.05o")
    CTX.update(hA=hA, hB=hB, oA=oA, oB=oB, ephs=G.read_nav(f"{data}/07590920.05n"))
    CTX["xA"] = G.anchor(hA, "consilience-calibration-A")          # declared calibration station (ppm sensitivity)
    sols = G.spp(oB[:5], CTX["ephs"], {}); CTX["xB_approx"] = sols[-1]["x"]   # B approximate from its own data only


def CN01(rng):
    sA = G.spp(CTX["oA"], CTX["ephs"], {}); sB = G.spp(CTX["oB"], CTX["ephs"], {})
    bykey = {int(round(s["tow"])): s["x"] for s in sA}; L = []
    for s in sB:
        k = int(round(s["tow"]))
        if k in bykey: L.append(np.linalg.norm(s["x"]-bykey[k]))
    L = np.array(L); v = float(np.mean(L)); u = block_bootstrap_sd(L, rng=rng)
    CTX["R1"] = dict(length=v, u=u)
    passed = len(L) > 100 and u < 1.0
    register("CN01", "Route R1 is just the earlier fit.",
             "Route R1 (undifferenced code, broadcast orbits/clocks, iono-free, Saastamoinen, Sagnac, relativity, receiver "
             "clocks as nuisance) gives the baseline as the difference of independent epoch solutions, with a block-bootstrap "
             "uncertainty that respects time correlation. No anchor is used.", passed,
             dict(length_m=f_(v), u_m=f_(u), epochs=len(L)), "HOLDS")


def CN02(rng):
    r = dd_baseline("phase"); CTX["R2"] = r
    passed = r["u"] < 0.1 and r["nsat"] >= 5
    register("CN02", "A second route would share the same errors.",
             "Route R2 (double-differenced L1 carrier phase, float ambiguities over the hour) shares almost nothing with R1: "
             "receiver and satellite clocks, orbits to first order, ionosphere and troposphere cancel over 3 km; code noise and "
             "code multipath are absent. Its uncertainty (residual-scaled, autocorrelation-inflated) is centimetric.",
             passed, dict(length_m=f_(r["length"]), u_m=f_(r["u"]), reference_sat=r["ref"], satellites=r["nsat"],
                          posterior_sigma_m=f_(r["s0"]), autocorr_inflation=f_(r["inflation"])), "HOLDS")


def CN03(rng):
    LOG.append("read-published-blinded")
    v = float(np.linalg.norm(CTX["hB"]["xyz"]-CTX["hA"]["xyz"])); u = 0.02     # declared: published GEONET coordinates
    CTX["R3"] = dict(length=v, u=u)
    register("CN03", "The published coordinates are just another fit of the same kind.",
             "Route R3: GEONET's published coordinates come from a different pipeline (precise orbits, long time series, "
             "network adjustment tied to the reference frame). Its uncertainty is a declaration (0.02 m), stated as such.",
             True, dict(length_m=f_(v), u_declared_m=u), "HOLDS")


def CN04(rng):
    r = dd_baseline("code"); CTX["R4"] = r
    passed = r["u"] < 1.0
    register("CN04", "Differencing is a cosmetic variant of R1.",
             "Route R4 (double-differenced code) removes clocks and common orbit/atmosphere errors that R1 must model, but keeps "
             "code noise and multipath that R2 does not have: a third, partly independent error budget.", passed,
             dict(length_m=f_(r["length"]), u_m=f_(r["u"])), "HOLDS")


ASSUMPTIONS = {
    "SI c and GPS time (convention)":            dict(R1=1, R2=1, R3=1, R4=1),
    "special/general relativity framework":      dict(R1=1, R2=1, R3=1, R4=1),
    "broadcast orbits":                          dict(R1=1, R2=0, R3=0, R4=0),
    "broadcast satellite clocks":                dict(R1=1, R2=0, R3=0, R4=0),
    "relativistic eccentricity term":            dict(R1=1, R2=0, R3=0, R4=0),
    "Sagnac correction":                         dict(R1=1, R2=1, R3=1, R4=1),
    "troposphere model (absolute)":              dict(R1=1, R2=0, R3=1, R4=0),
    "ionosphere-free dispersion law":            dict(R1=1, R2=0, R3=1, R4=0),
    "short-baseline atmosphere cancellation":    dict(R1=0, R2=1, R3=0, R4=1),
    "receiver clock per epoch (nuisance)":       dict(R1=1, R2=0, R3=1, R4=0),
    "code noise/multipath white":                dict(R1=1, R2=0, R3=0, R4=1),
    "phase continuity / constant ambiguities":   dict(R1=0, R2=1, R3=1, R4=0),
    "antenna phase centres (same model)":        dict(R1=1, R2=1, R3=1, R4=1),
    "station stability between survey and 2005": dict(R1=0, R2=0, R3=1, R4=0),
    "GEONET processing chain":                   dict(R1=0, R2=0, R3=1, R4=0),
}


def clusters(V, U, routes, zmax=3.0):
    import itertools
    z = {(a, b): abs(V[a]-V[b])/math.sqrt(U[a]**2+U[b]**2) for a, b in itertools.combinations(routes, 2)}
    zz = lambda a, b: z[(a, b)] if (a, b) in z else z[(b, a)]
    cons = [set(S) for k in range(len(routes), 0, -1) for S in itertools.combinations(routes, k)
            if all(zz(a, b) <= zmax for a, b in itertools.combinations(S, 2))]
    maximal = [S for S in cons if not any(S < T for T in cons) and len(S) >= 2]
    return z, [sorted(S) for S in maximal]


def distinctive(cl, routes):
    out = [r for r in routes if r not in cl]
    return [k for k, d in ASSUMPTIONS.items() if all(d[r] for r in cl) and not any(d[r] for r in out)]


def CN05(rng):
    """first registration claimed all four routes agree (false); a second version hard-coded the 'right' cluster (smuggling,
    caught). The engine now returns every maximal consistent cluster; contradicting clusters give CORRESPONDENCE."""
    routes = ["R1", "R2", "R3", "R4"]; V = {r: CTX[r]["length"] for r in routes}; U = {r: CTX[r]["u"] for r in routes}
    z, cls = clusters(V, U, routes)
    dist = {"+".join(c): distinctive(c, routes) for c in cls}
    status = "CORRESPONDENCE" if len(cls) > 1 else ("LOCKED (conditional)" if cls else "INCONSISTENT")
    # injected 0.2 m error into R2 (phase-only assumption), signed away from R3 (a +0.05 m first version moved R2 toward R3)
    zi = abs((V["R2"]-0.2*np.sign(V["R3"]-V["R2"]))-V["R3"])/math.sqrt(U["R2"]**2+U["R3"]**2)
    zsc = abs(V["R2"]*(1+1e-4)-V["R3"]*(1+1e-4))/math.sqrt(U["R2"]**2+U["R3"]**2)/(1+1e-4)
    undetectable = abs(zsc-z[("R2", "R3")]) < 1e-6
    crit = math.sqrt(max((abs(V["R2"]-V["R3"])/3.0)**2-U["R2"]**2, 0.0))
    CTX["clusters"] = dict(clusters=cls, distinctive=dist, status=status, V=V, U=U, crit_uR3=crit)
    passed = len(cls) == 2 and status == "CORRESPONDENCE" and all(dist.values()) and zi > 3 and undetectable
    register("CN05", "If the routes disagree, the analyst picks the plausible ones.",
             "The engine picks nothing: it returns every maximal consistent cluster -- here {R1, R4} (code) and {R2, R3} "
             "(phase, published), which contradict each other -- so the status is CORRESPONDENCE, with each cluster's "
             "distinctive assumptions listed. (A version that hard-coded the 'right' cluster was itself caught as smuggling.)",
             passed, dict(values_m={r: f_(V[r]) for r in routes}, u_m={r: f_(U[r]) for r in routes},
                          pairwise_z={f"{a}-{b}": f_(v) for (a, b), v in z.items()}, clusters=cls, distinctive_assumptions=dist,
                          status=status, critical_declared_u_R3_m=f_(crit), injected_nonshared_z=f_(zi),
                          intersection_error_undetectable=bool(undetectable)), "FALSIFIED-naive")


def code_dd_series():
    """per-epoch double-differenced code baseline lengths (3 unknowns per epoch, start from B's own SPP)."""
    ephs = CTX["ephs"]; xA = CTX["xA"]; byB = {ep["key"]: ep for ep in CTX["oB"]}; out = []
    for ep in CTX["oA"]:
        epB = byB.get(ep["key"])
        if epB is None: continue
        b = CTX["xB_approx"]-xA
        for _ in range(5):
            xB = xA+b; sd, Hs = {}, {}
            for prn in ep["obs"]:
                gA = sat_geom(ep, ephs, xA, prn); gB = sat_geom(epB, ephs, xB, prn)
                if not gA or not gB or gA["el"] < math.radians(10): continue
                sd[prn] = (gB["ob"]["C1"]-gA["ob"]["C1"])-(np.linalg.norm(gB["pos"]-xB)-np.linalg.norm(gA["pos"]-xA)); Hs[prn] = -(gB["pos"]-xB)/np.linalg.norm(gB["pos"]-xB)
            if len(sd) < 4: break
            ref = max(sd, key=lambda p: Hs[p]@(xB/np.linalg.norm(xB))*-1); ks = [p for p in sd if p != ref]
            y = np.array([sd[p]-sd[ref] for p in ks]); H = np.array([Hs[p]-Hs[ref] for p in ks])
            D = np.hstack([-np.ones((len(ks), 1)), np.eye(len(ks))]); Wm = np.linalg.inv(D@D.T)
            db = np.linalg.solve(H.T@Wm@H, H.T@Wm@y); b = b+db
            if np.linalg.norm(db) < 1e-4: break
        if len(sd) >= 4: out.append(float(np.linalg.norm(b)))
    return np.array(out)


def CN10(rng):
    """Registered BEFORE computing: phase cluster's distinctive assumption (constant, integer ambiguities) passes; code
    cluster's (white code errors) fails. Tests use observables that enter neither cluster's baseline estimate."""
    # phase: integer-consistency of float DD ambiguities (count rigidity) and fixed-vs-float baseline
    r2 = CTX["R2"]; fr = {p: float(v-round(v)) for p, v in r2["amb"].items()}; zint = {p: abs(fr[p])/r2["amb_sd"][p] for p in fr}
    phase_ok = all(v <= 3 for v in zint.values()) and max(r2["amb_sd"].values()) < 0.25
    fixed = {p: int(round(v)) for p, v in r2["amb"].items()}; rf = dd_baseline("phase", fixed=fixed)
    shift = abs(rf["length"]-r2["length"]); phase_ok = phase_ok and shift <= 3*math.sqrt(r2["u"]**2+rf["u"]**2)
    # code: block-mean test on per-epoch DD code baselines (white predicts sd(block means) = sd/sqrt(block))
    series = code_dd_series(); blk = 20; nbk = len(series)//blk
    means = np.array([series[i*blk:(i+1)*blk].mean() for i in range(nbk)])
    ratio = float(np.std(means, ddof=1)/(np.std(series, ddof=1)/math.sqrt(blk)))
    # finite-sample band for the ratio under whiteness (chi distribution with nbk-1 dof): 97.5% quantile
    from scipy.stats import chi2
    band = math.sqrt(chi2.ppf(0.975, nbk-1)/(nbk-1))
    code_ok = ratio <= band
    cls = CTX["clusters"]["clusters"]
    verdict = {"R2+R3": phase_ok, "R1+R4": code_ok}
    survivors = [c for c in cls if verdict.get("+".join(c), False)]
    if len(survivors) == 1:
        win = survivors[0]; V, U = CTX["clusters"]["V"], CTX["clusters"]["U"]
        w = np.array([1/U[r]**2 for r in win]); vc = float(np.sum(w*np.array([V[r] for r in win]))/np.sum(w)); uc = float(1/math.sqrt(np.sum(w)))
        inter = [k for k, d in ASSUMPTIONS.items() if all(d[r] for r in win)]
        decision = dict(status="LOCKED (conditional)", cluster=win, value=vc, u=uc, conditional_on=inter)
    else:
        decision = dict(status="CORRESPONDENCE", cluster=None)
    CTX["decision"] = decision; CTX["round1"] = dict(phase_ok=phase_ok, code_ok=code_ok, rf=rf, fixed=fixed)
    expectation_met = phase_ok and not code_ok                      # registered expectation; recorded, not required
    rule_consistent = (decision["status"] == "CORRESPONDENCE") == (phase_ok == code_ok)
    register("CN10", "Choosing between contradicting clusters is a human judgement.",
             "Round 1, registered before running: each cluster's distinctive assumption is tested with observables entering "
             "neither baseline. Phase: float ambiguities are integer-consistent (count rigidity; chance ~1e-4) and fixing them "
             "moves the baseline by mm. Code: the block-mean whiteness test is NOT failed -- the registered expectation was "
             "wrong -- because it has no power against a constant bias. Both survive, so the engine correctly keeps "
             "CORRESPONDENCE.", rule_consistent,
             dict(phase_ambiguity_fraction={str(k): f_(v) for k, v in fr.items()}, phase_integer_z={str(k): f_(v) for k, v in zint.items()},
                  phase_ambiguity_sd_max_cycles=f_(max(r2["amb_sd"].values())), fixed_length_m=f_(rf["length"]), fixed_shift_m=f_(shift),
                  phase_assumption_survives=bool(phase_ok), code_block_ratio=f_(ratio), white_band_975=f_(band),
                  code_assumption_survives=bool(code_ok), registered_expectation_met=bool(expectation_met),
                  decision={k: (f_(v) if isinstance(v, float) else v) for k, v in decision.items()}),
             "FALSIFIED-naive")


def CN11(rng):
    """Round 2, registered before running, conditional on round 1 (phase assumption survived a high-power independent test):
    per-satellite mean of DD code minus DD integer-fixed phase. White code errors -> |z| <= 3 for every pair; a constant
    per-satellite code bias -> some |z| > 3. Expectation: some pair biased; code cluster rejected."""
    r1 = CTX["round1"]; fixed = r1["fixed"]; b = r1["rf"]["vector"]; xA = CTX["xA"]; xB = xA+b; ephs = CTX["ephs"]
    lam1 = G.C/G.F1; byB = {ep["key"]: ep for ep in CTX["oB"]}; ref = CTX["R2"]["ref"]; diffs = {}
    for ep in CTX["oA"]:
        epB = byB.get(ep["key"])
        if epB is None: continue
        g = {}
        for prn in [ref]+list(fixed):
            gA = sat_geom(ep, ephs, xA, prn); gB = sat_geom(epB, ephs, xB, prn)
            if gA and gB and gA["el"] > math.radians(10) and all(np.isfinite(x["ob"].get(k, np.nan)) for x in (gA, gB) for k in ("C1", "L1")):
                g[prn] = (gA, gB)
        if ref not in g: continue
        def sdv(prn, kind):
            gA, gB = g[prn]; geo = np.linalg.norm(gB["pos"]-xB)-np.linalg.norm(gA["pos"]-xA)
            ob = (gB["ob"]["C1"]-gA["ob"]["C1"]) if kind == "code" else lam1*(gB["ob"]["L1"]-gA["ob"]["L1"])
            return ob-geo
        for prn in fixed:
            if prn not in g: continue
            ddc = sdv(prn, "code")-sdv(ref, "code"); ddp = sdv(prn, "phase")-sdv(ref, "phase")-lam1*fixed[prn]
            diffs.setdefault(prn, []).append(ddc-ddp)
    zs, means = {}, {}
    for prn, v in diffs.items():
        v = np.array(v)
        if len(v) < 40: continue
        m = float(v.mean()); u = block_bootstrap_sd(v, block=10, rng=np.random.default_rng(prn)); zs[prn] = abs(m)/u; means[prn] = m
    code_ok2 = all(z <= 3 for z in zs.values())
    if MUT.get("cn11_pretend_code_ok"): code_ok2 = True                     # canary: lock must then disappear
    CTX["round2"] = dict(code_ok=code_ok2)
    if r1["phase_ok"] and not code_ok2:
        win = ["R2", "R3"]; V, U = CTX["clusters"]["V"], CTX["clusters"]["U"]
        w = np.array([1/U[r]**2 for r in win]); vc = float(np.sum(w*np.array([V[r] for r in win]))/np.sum(w)); uc = float(1/math.sqrt(np.sum(w)))
        inter = [k for k, d in ASSUMPTIONS.items() if all(d[r] for r in win)]
        CTX["decision"] = dict(status="LOCKED (conditional)", cluster=win, value=vc, u=uc, conditional_on=inter,
                               rejected=["R1", "R4"], rejected_because="constant per-satellite code bias (round 2)",
                               sequential="round 2 conditional on round-1 phase test")
    expectation_met = not code_ok2
    register("CN11", "Round 2 just favours the analyst's preferred cluster.",
             "Round 2 was registered before running and is openly conditional on round 1. Double-differenced code minus "
             "integer-fixed phase, averaged per satellite, shows constant code biases of decimetres that no whiteness model "
             "allows (max |z| far above 3). The code cluster's distinctive assumption is falsified, the phase cluster's survived "
             "its own independent test, and the correspondence resolves by rule.", expectation_met,
             dict(per_satellite_mean_code_minus_phase_m={str(k): f_(v) for k, v in means.items()},
                  per_satellite_z={str(k): f_(v) for k, v in zs.items()}, code_assumption_survives=bool(code_ok2),
                  decision=CTX["decision"].get("status")), "FALSIFIED-naive")


def CN06(rng):
    alts = [dict(mask_deg=10.0, weighting="elev", ref_choice="highest", tropo=False), dict(mask_deg=15.0, weighting="elev", ref_choice="highest", tropo=False),
            dict(mask_deg=10.0, weighting="equal", ref_choice="highest", tropo=False), dict(mask_deg=10.0, weighting="elev", ref_choice="second", tropo=False),
            dict(mask_deg=10.0, weighting="elev", ref_choice="highest", tropo=True)]
    out = {}
    for kind in ("phase", "code"):
        vals = [dd_baseline(kind, **a)["length"] for a in alts]; u = CTX["R2" if kind == "phase" else "R4"]["u"]
        spread = max(vals)-min(vals); out[kind] = dict(values_m=[f_(v) for v in vals], spread_m=f_(spread), route_u_m=f_(u),
                                                      status="FORCED" if spread <= max(u, 1e-9) else "CONDITIONAL")
    passed = all(v["status"] in ("FORCED", "CONDITIONAL") for v in out.values()) and len(out) == 2
    register("CN06", "Each route's value is an artifact of its modelling choices.",
             "Each route is recomputed over declared alternatives (elevation mask, weighting, reference satellite, differential "
             "troposphere). A route is FORCED if the spread stays within its own uncertainty, CONDITIONAL otherwise, and is "
             "reported with that status.", passed, out, "HOLDS")


def CN07(rng):
    seed = secrets.token_bytes(16) if not MUT.get("cn07_fixed_seed") else b"0"*16
    commit = hashlib.sha256(seed).hexdigest(); LOG.append("commit")
    th = np.frombuffer(hashlib.sha256(seed+b"rot").digest()[:24], dtype=np.uint64).astype(float)/2**64*2*np.pi
    def rot(a, b_, c):
        Rz = lambda t: np.array([[math.cos(t), -math.sin(t), 0], [math.sin(t), math.cos(t), 0], [0, 0, 1]])
        Rx = lambda t: np.array([[1, 0, 0], [0, math.cos(t), -math.sin(t)], [0, math.sin(t), math.cos(t)]])
        return Rz(a)@Rx(b_)@Rz(c)
    R = rot(*th[:3]); bpub = CTX["hB"]["xyz"]-CTX["hA"]["xyz"]; blinded = R@bpub
    # analysts see only 'blinded'; reported statistic must be rotation-invariant: check equivariance of the comparison
    stat = lambda vec: float(np.linalg.norm(vec))
    invariant = abs(stat(blinded)-stat(bpub)) < 1e-9
    direction_hidden = float(np.degrees(np.arccos(np.clip(blinded@bpub/(stat(blinded)*stat(bpub)), -1, 1))))
    if MUT.get("cn07_peek"): LOG.append("unblind")                    # sabotage: unblinding before results are frozen
    frozen = json.dumps({r: CTX[r]["length"] for r in ("R1", "R2", "R4")}, sort_keys=True)
    rhash = hashlib.sha256(frozen.encode()).hexdigest(); LOG.append("freeze")
    if not MUT.get("cn07_peek"): LOG.append("unblind")
    ok_commit = hashlib.sha256(seed).hexdigest() == commit
    order_ok = LOG.index("commit") < LOG.index("freeze") < LOG.index("unblind")
    passed = invariant and ok_commit and order_ok and direction_hidden > 1.0
    register("CN07", "The analyst could have tuned the routes to the known answer.",
             "Commitment blinding: the published reference is shown only after a committed random rotation (hash published "
             "first); the reported statistic (length) is rotation-invariant, so blinding costs nothing and hides the direction; "
             "route results are hashed before unblinding. A pipeline that unblinds before freezing is flagged by the event "
             "order. (Within one script this demonstrates the protocol; its force needs the commitment published externally.)",
             passed, dict(commitment=commit[:16], results_hash=rhash[:16], statistic_invariant=bool(invariant),
                          blinded_direction_offset_deg=f_(direction_hidden), event_order=LOG[-4:], order_ok=bool(order_ok)),
             "FALSIFIED-naive")


def CN08(rng):
    GM = 3.986004418e14
    ep = CTX["oA"][60]; ephs = CTX["ephs"]; xA = CTX["xA"]; xB = xA+CTX["R2"]["vector"]; sh, dsh = [], []
    for prn in ep["obs"]:
        gA = sat_geom(ep, ephs, xA, prn); gB = sat_geom(ep, ephs, xB, prn)
        if not gA or gA["el"] < math.radians(10): continue
        def shapiro(xr, ps):
            rr, rs, rho = np.linalg.norm(xr), np.linalg.norm(ps), np.linalg.norm(ps-xr)
            return 2*GM/G.C**2*math.log((rs+rr+rho)/(rs+rr-rho))
        a_ = shapiro(xA, gA["pos"]); b_ = shapiro(xB, gB["pos"]); sh.append(a_); dsh.append(b_-a_)
    dd_sh = float(np.max(np.abs(np.array(dsh)-dsh[0])))
    Lb = CTX["R2"]["length"]; Rearth = 6.371e6; chord_arc = Lb**3/(24*Rearth**2)
    res = dict(code_route_u=CTX["R1"]["u"], phase_route_u=CTX["R2"]["u"])
    ladder = [
        dict(effect="Sagnac (rotating slice, L105)", magnitude_m=24.1, resolved_by="code (R1)", status="DETECTED (RD05)"),
        dict(effect="relativistic clock eccentricity (duration)", magnitude_m=5.3, resolved_by="code (R1)", status="DETECTED (RD06)"),
        dict(effect="Shapiro delay, single station", magnitude_m=f_(np.median(sh)), resolved_by="phase in principle; absorbed by clocks",
             status="STRUCTURAL WALL[code u] / declared model"),
        dict(effect="Shapiro delay, double-differenced over 3.3 km", magnitude_m=f_(dd_sh), resolved_by="none at this baseline",
             status=f"STRUCTURAL WALL[{f_(CTX['R2']['u'])} m]"),
        dict(effect="ellipsoid chord vs arc over the baseline", magnitude_m=f_(chord_arc), resolved_by="none",
             status=f"STRUCTURAL WALL[{f_(CTX['R2']['u'])} m]"),
    ]
    passed = 0.01 < np.median(sh) < 0.05 and dd_sh < CTX["R2"]["u"] and chord_arc < CTX["R2"]["u"]
    register("CN08", "Spacetime curvature is either assumed away or claimed.",
             "Physical curvature is typed by resolution: the rotating-frame and clock terms are detected; the Shapiro delay is "
             "centimetric per station but its double difference over 3.3 km is far below the phase route's resolution, and the "
             "ellipsoid's chord-arc curvature even more so: STRUCTURAL WALL[tau] with tau the route uncertainty. Longer baselines "
             "or better routes move a curvature effect across its wall; RG states which.", passed,
             dict(ladder=ladder, **{k: f_(v) for k, v in res.items()}), "FALSIFIED-naive")


def CN09(rng):
    d = CTX["decision"]; cl = CTX["clusters"]
    if MUT.get("cn09_prefer_code"):                                         # canary: preference instead of evidence
        d = dict(d, status="LOCKED (conditional)", cluster=["R1", "R4"])
    r1, r2 = CTX["round1"], CTX.get("round2", {})
    supported = (d.get("cluster") == ["R2", "R3"] and r1["phase_ok"] and r2.get("code_ok") is False) or \
                (d.get("cluster") == ["R1", "R4"] and r1["code_ok"] and r2.get("code_ok") and not r1["phase_ok"])
    passed = d["status"].startswith("LOCKED") and bool(d.get("conditional_on")) and supported
    register("CN09", "RG can only fit; it cannot state a physical value.",
             "Status of the physical value, computed by rule: LOCKED conditional on the residual assumption set of the "
             "surviving cluster, with the rejected cluster, its falsified assumption, the sequential conditioning of round 2, "
             "and the declared uncertainty's critical margin all reported. Had both survived, the status would have stayed "
             "CORRESPONDENCE.",
             passed, dict(status=d["status"], value_m=f_(d.get("value", float("nan"))), u_m=f_(d.get("u", float("nan"))),
                          surviving_cluster=d.get("cluster"), conditional_on=d.get("conditional_on"),
                          rejected_clusters=[c for c in cl["clusters"] if c != d.get("cluster")],
                          rejected_because=d.get("rejected_because"), sequential=d.get("sequential"),
                          critical_declared_u_R3_m=f_(cl["crit_uR3"])), "FALSIFIED-naive")


ATTACKS = [CN01, CN02, CN03, CN04, CN05, CN10, CN11, CN06, CN07, CN08, CN09]


def make_figures(d):
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    os.makedirs(d, exist_ok=True); fig, ax = plt.subplots(1, 2, figsize=(12, 4.2), gridspec_kw=dict(width_ratios=[1, 1.25]))
    routes = ["R1", "R2", "R3", "R4"]; labels = ["R1 code SPP", "R2 DD phase", "R3 published", "R4 DD code"]
    V = [CTX[r]["length"] for r in routes]; U = [CTX[r]["u"] for r in routes]
    win = CTX["decision"].get("cluster") or []; ref = CTX["decision"].get("value", float(np.mean(V)))
    cols = ["#2e7d32" if r in win else "#c62828" for r in routes]
    for i in range(4): ax[0].errorbar([i], [V[i]-ref], yerr=[1.96*U[i]], fmt="o", capsize=4, color=cols[i])
    ax[0].axhline(0, color="k", lw=0.7); ax[0].set_xticks(range(4), labels, rotation=15, fontsize=8)
    ax[0].set_ylabel("baseline length - combined value (m)"); ax[0].set_title("four routes, one quantity (95% bars; green = surviving cluster)", fontsize=9)
    names = list(ASSUMPTIONS); M = np.array([[ASSUMPTIONS[n][r] for r in routes] for n in names])
    ax[1].imshow(M, cmap="Greens", aspect="auto", vmin=0, vmax=1.4)
    ax[1].set_xticks(range(4), routes); ax[1].set_yticks(range(len(names)), names, fontsize=7)
    for i, n in enumerate(names):
        if all(ASSUMPTIONS[n][r] for r in routes): ax[1].text(3.6, i, "shared", va="center", fontsize=7, color="#c62828")
    ax[1].set_title("assumption overlap: error can hide only in rows shared by all", fontsize=9); ax[1].set_xlim(-0.5, 4.3)
    fig.tight_layout(); fig.savefig(f"{d}/cn_consilience.png", dpi=170); plt.close(fig)


def run_all():
    for a in ATTACKS:
        try: a(np.random.default_rng(20261024))
        except Exception as ex:
            import traceback; traceback.print_exc(); register(a.__name__, "?", f"EXCEPTION {ex!r}", False, {}, "ERROR")


def canary():
    ok = True
    RESULTS.clear(); MUT.clear(); MUT.update({"cn07_peek": True}); print("--- canary CN07: unblind before freeze")
    CN07(None); c = not RESULTS[-1]["passed"]; ok &= c; print(f"    {'CAUGHT' if c else 'NOT CAUGHT'}")
    for m in ({"cn11_pretend_code_ok": True}, {"cn09_prefer_code": True}):
        RESULTS.clear(); MUT.clear(); MUT.update(m); CTX.pop("decision", None); print(f"--- canary CN09 under {m}")
        CN05(None); CN10(None); CN11(None); CN09(None); c = not RESULTS[-1]["passed"]; ok &= c
        print(f"    {'CAUGHT' if c else 'NOT CAUGHT'}  (status {RESULTS[-1]['evidence'].get('status')})")
    MUT.clear(); print("CANARY:", "all caught" if ok else "BATTERY TOO WEAK"); return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--data", default="."); ap.add_argument("--out", default="rg_consilience_results.json")
    ap.add_argument("--figs", default=""); ap.add_argument("--canary", action="store_true"); a = ap.parse_args(); load(a.data)
    t0 = time.time(); print("RG consilience engine (real GPS)\n")
    if a.canary:
        for x in (CN01, CN02, CN03, CN04): x(np.random.default_rng(1))
        sys.exit(canary())
    run_all()
    if a.figs: make_figures(a.figs)
    n = sum(r["passed"] for r in RESULTS)
    json.dump(dict(summary=dict(n_checks=len(RESULTS), n_pass=n, runtime_s=round(time.time()-t0, 1)), results=RESULTS),
              open(a.out, "w"), indent=2, default=lambda o: o.item() if hasattr(o, "item") else (o.tolist() if hasattr(o, "tolist") else str(o)))
    print(f"\n{n}/{len(RESULTS)} pass."); sys.exit(0 if n == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
