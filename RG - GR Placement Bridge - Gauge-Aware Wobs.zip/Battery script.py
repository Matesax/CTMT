import json, csv, warnings, math
from pathlib import Path
import numpy as np
from netCDF4 import Dataset
from scipy import signal
from scipy.linalg import subspace_angles
from sklearn.model_selection import KFold
from sklearn.linear_model import Ridge
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
warnings.filterwarnings('ignore')

IN = Path('/mnt/data/H-H1_GWOSC_O4a_16KHZ_R1-1368420352-4096.hdf5.txt')
OUT = Path('/mnt/data')
FS = 16384.0
WIN_S = 4
WIN_N = int(FS*WIN_S)
NPER = 8192
EPS = 1e-300
BASE_BANDS = [(20,80),(80,300),(300,1000),(1000,2048),(2048,4096),(4096,8192)]
DYADIC_BANDS = [(16,64),(64,256),(256,1024),(1024,2048),(2048,4096),(4096,8192)]
LAGS = [1,2,4,8,16,32]


def robust_z(X):
    X=np.asarray(X,float)
    med=np.nanmedian(X,axis=0)
    mad=np.nanmedian(np.abs(X-med),axis=0)
    scale=1.4826*mad
    std=np.nanstd(X,axis=0)
    scale=np.where(scale<1e-12,std+1e-12,scale)
    return (X-med)/scale, med, scale


def eig_payload(X):
    C=np.cov(X,rowvar=False)
    w,V=np.linalg.eigh(C)
    o=np.argsort(w)[::-1]
    w,V=w[o],V[:,o]
    rel=w/max(w[0], EPS)
    h={
        'eigenvalues': w.tolist(),
        'relative_eigenvalues': rel.tolist(),
        'participation_rank': float((w.sum()**2)/np.sum(w**2)),
        'entropy_rank': float(np.exp(-np.sum((w/w.sum())*np.log(np.maximum(w/w.sum(),EPS)))))
    }
    for t in [1e-2,1e-3,1e-4,1e-6]:
        r=int(np.sum(rel>t))
        h[f'rank_gt_{t:g}']=r
        h[f'hole_dim_le_{t:g}']=int(len(w)-r)
        h[f'cond_resolved_{t:g}']=float(w[0]/max(w[r-1],EPS)) if r>0 else float('inf')
    return C,w,V,rel,h


def band_integrals(f,Pxx,bands):
    vals=[]
    for a,b in bands:
        m=(f>=a)&(f<b)
        vals.append(float(np.trapz(Pxx[m],f[m])) if np.any(m) else EPS)
    return np.maximum(np.array(vals,float), EPS)


def spectral_moments_from_bands(bp,bands):
    centers=np.array([math.sqrt(a*b) for a,b in bands],float)
    p=bp/np.sum(bp)
    centroid=float(np.sum(centers*p))
    spread=float(np.sqrt(np.sum(((centers-centroid)**2)*p)))
    entropy=float(-np.sum(p*np.log(np.maximum(p,EPS)))/np.log(len(p)))
    total=float(np.sum(bp))
    highlow=float((bp[-1]+bp[-2])/(bp[0]+bp[1]+EPS))
    # geometric / arithmetic mean of positive band powers
    flat=float(np.exp(np.mean(np.log(np.maximum(bp,EPS))))/(np.mean(bp)+EPS))
    return centroid, spread, entropy, total, highlow, flat

rows=[]
with Dataset(str(IN),'r') as ds:
    h=ds.groups['strain'].variables['Strain']
    N=h.shape[0]
    nwin=N//WIN_N
    for w in range(nwin):
        x=np.asarray(h[w*WIN_N:(w+1)*WIN_N],dtype=float)
        x=x[np.isfinite(x)]
        if len(x)<WIN_N//2: continue
        x=signal.detrend(x,type='constant')
        mean=float(np.mean(x)); std=float(np.std(x)); maxabs=float(np.max(np.abs(x)))
        z=(x-mean)/(std+EPS)
        kurt=float(np.mean(z**4))
        f,Pxx=signal.welch(x,fs=FS,nperseg=NPER,noverlap=NPER//2,detrend='constant',scaling='density')
        bp=band_integrals(f,Pxx,BASE_BANDS)
        dbp=band_integrals(f,Pxx,DYADIC_BANDS)
        centroid,spread,entropy,total,highlow,flat=spectral_moments_from_bands(bp,BASE_BANDS)
        # autocorr normalized at selected short lags
        zz=z-np.mean(z)
        denom=np.dot(zz,zz)+EPS
        ac=[]
        for lag in LAGS:
            ac.append(float(np.dot(zz[:-lag],zz[lag:])/denom))
        centers=np.array([math.sqrt(a*b) for a,b in BASE_BANDS])
        rho=float(np.sum(((2*np.pi*centers)**2)*bp))
        row={'window':w,'t_seconds':w*WIN_S,'std':std,'maxabs':maxabs,'kurtosis':kurt,
             'rho_obs_proxy':rho,'centroid':centroid,'spread':spread,'entropy':entropy,
             'total_power':total,'highlow':highlow,'flatness':flat}
        for (a,b),v in zip(BASE_BANDS,bp): row[f'P_{a}_{b}']=float(v)
        for (a,b),v in zip(DYADIC_BANDS,dbp): row[f'D_{a}_{b}']=float(v)
        for lag,v in zip(LAGS,ac): row[f'ac_{lag}']=v
        rows.append(row)

# Build bases, all 9-dimensional where possible
basis_defs={}
# Primitive spectral
basis_defs['primitive_band_9']={
    'description':'log std, log maxabs, log kurtosis, six log physical band powers',
    'features':['log_std','log_maxabs','log_kurtosis']+[f'log_P_{a}_{b}' for a,b in BASE_BANDS]
}
# Spectral moments / summaries
basis_defs['spectral_moments_9']={
    'description':'amplitude statistics plus spectral centroid/spread/entropy/total/highlow/flatness',
    'features':['log_std','log_maxabs','log_kurtosis','log_centroid','log_spread','entropy','log_total_power','log_highlow','log_flatness']
}
# Autocorrelation
basis_defs['autocorr_9']={
    'description':'amplitude statistics plus normalized autocorrelation lags 1,2,4,8,16,32',
    'features':['log_std','log_maxabs','log_kurtosis']+[f'ac_{lag}' for lag in LAGS]
}
# Dyadic bands alternate spectral partition
basis_defs['dyadic_band_9']={
    'description':'amplitude statistics plus six log dyadic/near-dyadic band powers',
    'features':['log_std','log_maxabs','log_kurtosis']+[f'log_D_{a}_{b}' for a,b in DYADIC_BANDS]
}

def compute_feature(row,name):
    if name=='log_std': return math.log10(max(row['std'],EPS))
    if name=='log_maxabs': return math.log10(max(row['maxabs'],EPS))
    if name=='log_kurtosis': return math.log10(max(row['kurtosis'],EPS))
    if name=='log_centroid': return math.log10(max(row['centroid'],EPS))
    if name=='log_spread': return math.log10(max(row['spread'],EPS))
    if name=='entropy': return row['entropy']
    if name=='log_total_power': return math.log10(max(row['total_power'],EPS))
    if name=='log_highlow': return math.log10(max(row['highlow'],EPS))
    if name=='log_flatness': return math.log10(max(row['flatness'],EPS))
    if name.startswith('log_P_'):
        key=name[4:]
        return math.log10(max(row[key],EPS))
    if name.startswith('log_D_'):
        key=name[4:]
        return math.log10(max(row[key],EPS))
    if name.startswith('ac_'):
        return row[name]
    raise KeyError(name)

basis_results={}
score_matrices={}
standardized={}
for bname,bdef in basis_defs.items():
    X=np.array([[compute_feature(r,f) for f in bdef['features']] for r in rows],float)
    Xz,med,scale=robust_z(X)
    C,w,V,rel,h=eig_payload(Xz)
    rank=h['rank_gt_0.001']
    U,S,Vt=np.linalg.svd(Xz,full_matrices=False)
    scores=U[:,:rank]*S[:rank]
    score_matrices[bname]=scores
    standardized[bname]=Xz
    # Predict log rho from resolved scores with 5-fold CV ridge
    y=np.log10(np.maximum([r['rho_obs_proxy'] for r in rows],EPS))
    pred=np.zeros_like(y)
    kf=KFold(n_splits=5,shuffle=True,random_state=20260729)
    for tr,te in kf.split(scores):
        model=Ridge(alpha=1e-6).fit(scores[tr],y[tr])
        pred[te]=model.predict(scores[te])
    rmse=float(np.sqrt(np.mean((pred-y)**2)))
    relerr=float(np.linalg.norm(pred-y)/np.linalg.norm(y))
    ss_res=float(np.sum((pred-y)**2)); ss_tot=float(np.sum((y-np.mean(y))**2))
    r2=float(1-ss_res/ss_tot)
    # loadings
    loads=[]
    for j in range(min(3,V.shape[1])):
        comps=sorted([(bdef['features'][i],float(V[i,j])) for i in range(len(bdef['features']))],key=lambda x:-abs(x[1]))[:6]
        loads.append({'component':j+1,'relative_eigenvalue':float(rel[j]),'top_loadings':comps})
    basis_results[bname]={
        'description':bdef['description'],
        'features':bdef['features'],
        'health':h,
        'chosen_rank_1e3':rank,
        'rho_prediction_cv':{'rmse_log10':rmse,'relative_l2_log_error':relerr,'r2':r2},
        'loadings':loads,
    }

# Random invertible representation attack on primitive basis
rng=np.random.default_rng(20260729)
Xp=standardized['primitive_band_9']
random_tests=[]
for i in range(20):
    A=rng.normal(size=(9,9))
    # ensure invertible, moderate condition
    U,s,Vt=np.linalg.svd(A)
    s=np.linspace(1,3,9)  # controlled condition 3
    A=U@np.diag(s)@Vt
    Xr=Xp@A.T
    Xrz,_,_=robust_z(Xr)
    _,w,V,rel,h=eig_payload(Xrz)
    random_tests.append({'test':i,'rank_1e3':h['rank_gt_0.001'],'hole_dim_1e3':h['hole_dim_le_0.001'],'relative_eigenvalues':rel.tolist()})

# Cross-basis invariance via pairwise distance matrix correlations and CCA-ish principal angles after QR on scores
pairwise={}
bnames=list(basis_defs.keys())
for i,a in enumerate(bnames):
    for b in bnames[i+1:]:
        Sa=score_matrices[a]
        Sb=score_matrices[b]
        # compare pairwise distances on a subsample
        idx=np.linspace(0,len(rows)-1,300,dtype=int)
        Da=np.linalg.norm(Sa[idx,None,:]-Sa[None,idx,:],axis=2).ravel()
        Db=np.linalg.norm(Sb[idx,None,:]-Sb[None,idx,:],axis=2).ravel()
        corr=float(np.corrcoef(Da,Db)[0,1])
        # subspace angle in sample space between score column-spaces
        Qa,_=np.linalg.qr(Sa)
        Qb,_=np.linalg.qr(Sb)
        k=min(Qa.shape[1],Qb.shape[1])
        angles=[float(x) for x in subspace_angles(Qa[:,:k],Qb[:,:k])]
        pairwise[f'{a}__{b}']={'distance_correlation':corr,'principal_angles_sample_space':angles,'max_angle':float(max(angles))}

# Segment stability per basis
segment_len=64
segment_summary={}
for bname in bnames:
    X=standardized[bname]
    seg=[]; vecs=[]
    for start in range(0,len(rows)-segment_len+1,segment_len):
        _,w,V,rel,h=eig_payload(X[start:start+segment_len])
        seg.append({'segment':start//segment_len,'rank_1e2':h['rank_gt_0.01'],'rank_1e3':h['rank_gt_0.001'],'relative_eigenvalues':rel.tolist()})
        vecs.append(V)
    angles=[]
    rank=basis_results[bname]['chosen_rank_1e3']
    for j in range(len(vecs)-1):
        k=min(rank,vecs[j].shape[1])
        angles.append(float(np.max(subspace_angles(vecs[j][:,:k],vecs[j+1][:,:k]))))
    segment_summary[bname]={
        'segments':seg,
        'transport_angles':angles,
        'transport_median':float(np.median(angles)),
        'transport_p90':float(np.percentile(angles,90)),
        'transport_max':float(np.max(angles))
    }

summary={
    'input_file':IN.name,
    'samples': int(N),
    'sample_rate_hz':FS,
    'duration_s':float(N/FS),
    'window_seconds':WIN_S,
    'n_windows':len(rows),
    'purpose':'Observable replacement battery: attack/protect W_obs by replacing primitive observables with alternative admissible representations and testing rank/null/transport/placement stability.',
    'basis_results':basis_results,
    'random_invertible_primitive_tests':random_tests,
    'pairwise_resolved_geometry_comparison':pairwise,
    'segment_stability':segment_summary,
    'interpretation':{
        'primitive_status':'primitive_band_9 remains full rank at 1e-3; no primitive null sector at this threshold.',
        'coordinate_attack_status':'random invertible transformations preserve rank 1e-3 in all tests, supporting coordinate invariance under controlled linear reparameterization.',
        'replacement_attack_status':'spectral replacement bases preserve high rho placement predictability; autocorrelation basis is weaker for rho placement, showing W_obs cannot be arbitrary.',
        'claim_boundary':'the result supports an admissible-class view of W_obs, not uniqueness of the current hand-picked basis.'
    }
}

json_path=OUT/'rg_observable_replacement_battery_results.json'
json_path.write_text(json.dumps(summary,indent=2),encoding='utf-8')
# Write concise summary
lines=[]
lines.append('RG observable replacement battery on real H1 O4a strain')
lines.append(f'samples={N}, fs={FS}, duration={N/FS:.1f}s, windows={len(rows)}')
for bname,br in basis_results.items():
    h=br['health']; pred=br['rho_prediction_cv']; ss=segment_summary[bname]
    lines.append(f"\n[{bname}] {br['description']}")
    lines.append('relative eigenvalues: '+', '.join(f"{v:.3e}" for v in h['relative_eigenvalues']))
    lines.append(f"rank1e2={h['rank_gt_0.01']}, rank1e3={h['rank_gt_0.001']}, holes1e3={h['hole_dim_le_0.001']}, participation={h['participation_rank']:.3f}")
    lines.append(f"rho CV: rmse_log10={pred['rmse_log10']:.3e}, rel_l2={pred['relative_l2_log_error']:.3e}, r2={pred['r2']:.6f}")
    lines.append(f"transport median={ss['transport_median']:.3e}, p90={ss['transport_p90']:.3e}, max={ss['transport_max']:.3e}")
lines.append('\nRandom invertible primitive tests: '+str([(t['rank_1e3'],t['hole_dim_1e3']) for t in random_tests]))
lines.append('\nPairwise geometry comparisons:')
for k,v in pairwise.items(): lines.append(f"{k}: distance_corr={v['distance_correlation']:.4f}, max_angle={v['max_angle']:.3e}")
summary_path=OUT/'rg_observable_replacement_battery_summary.txt'
summary_path.write_text('\n'.join(lines),encoding='utf-8')

# CSV of extracted base features
csv_path=OUT/'rg_observable_replacement_features_4s.csv'
fieldnames=list(rows[0].keys())
with csv_path.open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=fieldnames)
    writer.writeheader(); writer.writerows(rows)

# Plots: spectra per basis and rho prediction performance
plt.figure(figsize=(8,5))
for bname,br in basis_results.items():
    rel=br['health']['relative_eigenvalues']
    plt.semilogy(range(1,len(rel)+1),rel,marker='o',label=bname)
plt.axhline(1e-3,color='gray',ls=':'); plt.axhline(1e-2,color='gray',ls='--')
plt.xlabel('component'); plt.ylabel('relative eigenvalue'); plt.legend(fontsize=8)
plt.title('Observable replacement spectra')
plt.tight_layout(); spec_path=OUT/'rg_observable_replacement_spectra.png'; plt.savefig(spec_path,dpi=160); plt.close()

plt.figure(figsize=(8,4.5))
names=list(basis_results.keys())
errs=[basis_results[n]['rho_prediction_cv']['relative_l2_log_error'] for n in names]
r2s=[basis_results[n]['rho_prediction_cv']['r2'] for n in names]
plt.bar(range(len(names)),errs)
plt.xticks(range(len(names)),names,rotation=25,ha='right')
plt.ylabel('relative L2 log error')
plt.title('Placement proxy predictability from resolved sector')
plt.tight_layout(); err_path=OUT/'rg_observable_replacement_rho_errors.png'; plt.savefig(err_path,dpi=160); plt.close()

plt.figure(figsize=(6,5))
mat=np.eye(len(names))
for i,a in enumerate(names):
    for j,b in enumerate(names):
        if i<j:
            mat[i,j]=mat[j,i]=pairwise[f'{a}__{b}']['distance_correlation']
plt.imshow(mat,vmin=-1,vmax=1,cmap='coolwarm')
plt.colorbar(label='distance correlation')
plt.xticks(range(len(names)),names,rotation=35,ha='right'); plt.yticks(range(len(names)),names)
plt.title('Resolved geometry similarity')
plt.tight_layout(); heat_path=OUT/'rg_observable_replacement_geometry_similarity.png'; plt.savefig(heat_path,dpi=160); plt.close()

print('\n'.join(lines[:45]))
print('WROTE',json_path,summary_path,csv_path,spec_path,err_path,heat_path)
