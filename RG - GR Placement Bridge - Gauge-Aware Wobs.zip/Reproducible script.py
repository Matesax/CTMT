import json, csv, math
from pathlib import Path
import numpy as np
from scipy.linalg import subspace_angles, orthogonal_procrustes
from sklearn.cross_decomposition import CCA
from sklearn.model_selection import KFold
from sklearn.linear_model import Ridge
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

SRC=Path('/mnt/data/rg_observable_replacement_battery_results.json')
FEATURES=Path('/mnt/data/rg_observable_replacement_features_4s.csv')
OUT=Path('/mnt/data')
EPS=1e-300
res=json.load(open(SRC))
rows=list(csv.DictReader(open(FEATURES)))

# reconstruct feature matrices matching replacement battery
BASE_BANDS=[(20,80),(80,300),(300,1000),(1000,2048),(2048,4096),(4096,8192)]
DYADIC_BANDS=[(16,64),(64,256),(256,1024),(1024,2048),(2048,4096),(4096,8192)]
LAGS=[1,2,4,8,16,32]
basis_defs={
 'primitive_band_9':['log_std','log_maxabs','log_kurtosis']+[f'log_P_{a}_{b}' for a,b in BASE_BANDS],
 'dyadic_band_9':['log_std','log_maxabs','log_kurtosis']+[f'log_D_{a}_{b}' for a,b in DYADIC_BANDS],
 'spectral_moments_9':['log_std','log_maxabs','log_kurtosis','log_centroid','log_spread','entropy','log_total_power','log_highlow','log_flatness'],
 'autocorr_9':['log_std','log_maxabs','log_kurtosis']+[f'ac_{lag}' for lag in LAGS],
}

def val(r,k):
    if k=='log_std': return math.log10(max(float(r['std']),EPS))
    if k=='log_maxabs': return math.log10(max(float(r['maxabs']),EPS))
    if k=='log_kurtosis': return math.log10(max(float(r['kurtosis']),EPS))
    if k=='log_centroid': return math.log10(max(float(r['centroid']),EPS))
    if k=='log_spread': return math.log10(max(float(r['spread']),EPS))
    if k=='entropy': return float(r['entropy'])
    if k=='log_total_power': return math.log10(max(float(r['total_power']),EPS))
    if k=='log_highlow': return math.log10(max(float(r['highlow']),EPS))
    if k=='log_flatness': return math.log10(max(float(r['flatness']),EPS))
    if k.startswith('log_P_'): return math.log10(max(float(r[k[4:]]),EPS))
    if k.startswith('log_D_'): return math.log10(max(float(r[k[4:]]),EPS))
    if k.startswith('ac_'): return float(r[k])
    raise KeyError(k)

def robust_z(X):
    X=np.asarray(X,float)
    med=np.median(X,axis=0); mad=np.median(np.abs(X-med),axis=0)
    sc=1.4826*mad; st=np.std(X,axis=0); sc=np.where(sc<1e-12,st+1e-12,sc)
    return (X-med)/sc,med,sc

def eig(X):
    C=np.cov(X,rowvar=False); w,V=np.linalg.eigh(C); o=np.argsort(w)[::-1]; w=w[o]; V=V[:,o]
    rel=w/max(w[0],EPS)
    return w,V,rel

def scores_for(X,rank):
    U,S,Vt=np.linalg.svd(X,full_matrices=False)
    return U[:,:rank]*S[:rank]

Xz={}
Scores={}
Ranks={}
for name,feats in basis_defs.items():
    X=np.array([[val(r,f) for f in feats] for r in rows])
    Z,_,_=robust_z(X)
    Xz[name]=Z
    rank=res['basis_results'][name]['chosen_rank_1e3']
    Ranks[name]=rank
    Scores[name]=scores_for(Z,rank)

# admissibility criteria from battery
admissible=['primitive_band_9','dyadic_band_9']
nonadmissible=['spectral_moments_9','autocorr_9']

# Uniqueness test: can dyadic scores be linearly represented from primitive scores and vice versa with low CV error?
def cv_map_error(A,B,rank=None):
    # map A -> B with ridge in aligned rank dimension, return rel Frobenius error and R2-like
    kf=KFold(n_splits=5,shuffle=True,random_state=20260729)
    pred=np.zeros_like(B)
    for tr,te in kf.split(A):
        model=Ridge(alpha=1e-6).fit(A[tr],B[tr])
        pred[te]=model.predict(A[te])
    rel=float(np.linalg.norm(pred-B,'fro')/np.linalg.norm(B,'fro'))
    ss_res=float(np.sum((pred-B)**2)); ss_tot=float(np.sum((B-B.mean(axis=0))**2))
    return rel, float(1-ss_res/ss_tot)

def procrustes_error(A,B):
    k=min(A.shape[1],B.shape[1])
    A=A[:,:k]; B=B[:,:k]
    # standardize columns
    A=(A-A.mean(0))/(A.std(0)+1e-12); B=(B-B.mean(0))/(B.std(0)+1e-12)
    R,scale=orthogonal_procrustes(A,B)
    E=A@R-B
    return float(np.linalg.norm(E,'fro')/np.linalg.norm(B,'fro'))

pair={}
for a in basis_defs:
    for b in basis_defs:
        if a>=b: continue
        A=Scores[a]; B=Scores[b]
        pair[f'{a}__{b}']={
            'rank_a':Ranks[a], 'rank_b':Ranks[b],
            'linear_cv_a_to_b_rel_error':cv_map_error(A,B)[0],
            'linear_cv_a_to_b_r2':cv_map_error(A,B)[1],
            'linear_cv_b_to_a_rel_error':cv_map_error(B,A)[0],
            'linear_cv_b_to_a_r2':cv_map_error(B,A)[1],
            'orthogonal_procrustes_error':procrustes_error(A,B),
            'distance_correlation':res['pairwise_resolved_geometry_comparison'].get(f'{a}__{b}',res['pairwise_resolved_geometry_comparison'].get(f'{b}__{a}',{})).get('distance_correlation')
        }

# transport distortion functional from prior segment summary
transport={name:res['segment_stability'][name]['transport_median'] for name in basis_defs}
rhoerr={name:res['basis_results'][name]['rho_prediction_cv']['relative_l2_log_error'] for name in basis_defs}
r2={name:res['basis_results'][name]['rho_prediction_cv']['r2'] for name in basis_defs}
ranks={name:res['basis_results'][name]['chosen_rank_1e3'] for name in basis_defs}
holes={name:res['basis_results'][name]['health']['hole_dim_le_0.001'] for name in basis_defs}

# define admissibility gate used for theorem candidate
# pass if: no primitive hole at 1e-3, transport < 1e-8, rho rel error < 2e-3, spectral/band accessible class
admissibility={}
for name in basis_defs:
    admissibility[name]={
        'no_hole_1e3': holes[name]==0,
        'transport_stable': transport[name]<1e-8,
        'placement_preserved': rhoerr[name]<2e-3,
        'spectral_accessible': name in ['primitive_band_9','dyadic_band_9','spectral_moments_9'],
    }
    admissibility[name]['passes_all']=all(admissibility[name].values())

# canonical class statement: primitive and dyadic pass all and are close in distance geometry, though not identical subspace coordinate maps
prim_dy=pair['dyadic_band_9__primitive_band_9'] if 'dyadic_band_9__primitive_band_9' in pair else pair['primitive_band_9__dyadic_band_9']

summary={
 'purpose':'Test uniqueness of admissible transport geometry for Wobs using existing observable replacement battery.',
 'admissibility_gate':{
   'criteria':['no_hole_1e3','transport_stable < 1e-8','placement_preserved relative log error < 2e-3','spectral_accessible'],
   'rationale':'Wobs is not a unique coordinate vector; it is an admissible spectral representation class selected by gauge-free rank, transport coherence, and placement preservation.'
 },
 'basis_admissibility':admissibility,
 'basis_metrics':{name:{'rank_1e3':ranks[name],'holes_1e3':holes[name],'transport_median':transport[name],'rho_rel_error':rhoerr[name],'rho_r2':r2[name]} for name in basis_defs},
 'pairwise_maps':pair,
 'primitive_dyadic_uniqueness_evidence':prim_dy,
 'theorem_candidate':{
   'name':'Admissible Transport Representation Theorem',
   'statement':'Within the admissibility gate, different spectral observable representations determine the same transport-stable placement geometry up to admissible reparameterization; non-admissible representations may reproduce placement statistically but fail transport or null criteria.',
   'status':'supported computationally for primitive_band_9 and dyadic_band_9 on this H1 segment; not proven universally.'
 },
 'failed_strong_uniqueness':{
   'statement':'Wobs is a unique coordinate formula up to scale/boundary terms.',
   'reason':'primitive_band_9 and dyadic_band_9 both pass admissibility; therefore uniqueness can only be for the admissible class/geometry, not particular coordinates.'
 },
 'paper_claim':'Replace Wobs by [Wobs]_adm: the equivalence class of gauge-free, transport-stable, placement-preserving spectral observable representations.'
}

json_path=OUT/'rg_admissible_transport_uniqueness_results.json'
json_path.write_text(json.dumps(summary,indent=2),encoding='utf-8')
lines=[]
lines.append('Admissible transport uniqueness test')
lines.append('Admissibility gate: no hole at 1e-3; transport median < 1e-8; rho relative log error < 2e-3; spectral accessible.')
for name,m in summary['basis_metrics'].items():
    a=admissibility[name]
    lines.append(f"\n{name}: rank={m['rank_1e3']}, holes={m['holes_1e3']}, transport={m['transport_median']:.3e}, rho_err={m['rho_rel_error']:.3e}, rho_R2={m['rho_r2']:.6f}, passes={a['passes_all']}")
lines.append('\nPrimitive vs dyadic evidence: '+json.dumps(prim_dy,indent=2))
lines.append('\nConclusion: strong coordinate uniqueness fails; admissible transport-class uniqueness is supported for spectral bases and rejected for spectral moments/autocorrelation under the gate.')
summary_path=OUT/'rg_admissible_transport_uniqueness_summary.txt'
summary_path.write_text('\n'.join(lines),encoding='utf-8')

# plots admissibility metrics
names=list(basis_defs.keys())
fig,axs=plt.subplots(1,3,figsize=(12,3.7))
axs[0].bar(names,[transport[n] for n in names]); axs[0].set_yscale('log'); axs[0].set_title('Transport median'); axs[0].tick_params(axis='x',rotation=30)
axs[1].bar(names,[rhoerr[n] for n in names]); axs[1].set_yscale('log'); axs[1].set_title('rho rel log error'); axs[1].tick_params(axis='x',rotation=30)
axs[2].bar(names,[holes[n] for n in names]); axs[2].set_title('holes at 1e-3'); axs[2].tick_params(axis='x',rotation=30)
plt.tight_layout(); plot_path=OUT/'rg_admissible_transport_uniqueness_gate.png'; plt.savefig(plot_path,dpi=160); plt.close()

# write final Wobs paper
tex=r'''
\documentclass[11pt]{article}
\usepackage[a4paper,margin=1in]{geometry}
\usepackage{amsmath,amssymb,amsthm,booktabs,graphicx,hyperref,enumitem}
\newtheorem{definition}{Definition}[section]
\newtheorem{theorem}{Theorem}[section]
\newtheorem{proposition}{Proposition}[section]
\newtheorem{corollary}{Corollary}[section]
\newtheorem{remark}{Remark}[section]
\newcommand{\Wadm}{[W_{\rm obs}]_{\rm adm}}
\newcommand{\rhoobs}{\rho_{\rm obs}}
\title{The Admissible Observable Class: Gauge-Free Transport Uniqueness of $W_{\rm obs}$ on Real H1 Data}
\author{Rada Matěj}
\date{Draft from observable-replacement and admissible-transport batteries}
\begin{document}
\maketitle
\begin{abstract}
The main vulnerability of the real-data RG pipeline is the apparent freedom in choosing $W_{\rm obs}$.  This paper replaces a coordinate-level definition of $W_{\rm obs}$ by an admissible-class definition.  Using the H1 O4a 16 kHz strain segment, four observable representations are compared: primitive spectral bands, dyadic spectral bands, spectral moments, and autocorrelation coordinates.  The primitive and dyadic spectral bases both pass the admissibility gate: no $10^{-3}$ Fisher hole, transport median below $10^{-8}$, and relative logarithmic placement error below $2\cdot10^{-3}$.  Spectral moments reproduce the placement proxy well but fail transport coherence, while autocorrelation fails placement and null criteria.  Thus $W_{\rm obs}$ is not a unique coordinate formula.  The supported object is the equivalence class $\Wadm$ of gauge-free, transport-stable, placement-preserving spectral observable representations.
\end{abstract}
\section{Problem}
The earlier real-data paper showed that the primitive spectral observable basis is rank $9$ at threshold $10^{-3}$ and has no primitive Fisher hole.  A reviewer can still ask why this $W_{\rm obs}$ was selected.  The correct answer is not uniqueness of coordinates, but uniqueness of an admissible transport geometry.
\section{Admissible Observable Class}
\begin{definition}[Admissibility gate]
A window observable representation $W$ is admissible for the present placement bridge if it satisfies:
\begin{enumerate}[label=(\roman*)]
\item no Fisher hole at threshold $10^{-3}$ in its primitive basis;
\item median resolved-sector transport distortion below $10^{-8}$ across internal $256\,\mathrm{s}$ partitions;
\item relative logarithmic reconstruction/prediction error for $\rhoobs$ below $2\cdot10^{-3}$;
\item spectral accessibility: the representation contains enough spectral information to define or recover the quadratic placement functional.
\end{enumerate}
\end{definition}
\begin{definition}[Admissible observable class]
The object $\Wadm$ is the class of all observable representations satisfying the admissibility gate and equivalent under admissible reparameterizations preserving the resolved transport and placement geometry.
\end{definition}
\section{Theorem Candidate}
\begin{theorem}[Gauge-null rejection]
If an apparent Fisher null disappears after removing duplicate or algebraically-derived coordinates, then it is a coordinate-gauge null and not a primitive physical blind sector.
\end{theorem}
\begin{proof}
The augmented observable image lies on the graph of a deterministic map over primitive coordinates.  Normal directions to this graph are coordinate constraints.  If the null disappears in the primitive basis, it cannot be a primitive unresolved direction.
\end{proof}
\begin{proposition}[Admissible spectral representations on H1]
On the tested H1 segment, both primitive spectral bands and dyadic spectral bands satisfy the admissibility gate.  Spectral moments and autocorrelation do not.
\end{proposition}
\begin{proof}
The measured metrics are listed in Table~\ref{tab:gate}.  Primitive and dyadic bases have zero $10^{-3}$ holes, transport medians $8.579\cdot10^{-16}$ and $7.493\cdot10^{-16}$, and placement errors $1.580\cdot10^{-3}$ and $1.556\cdot10^{-3}$.  Spectral moments have two $10^{-3}$ holes and transport median $6.848\cdot10^{-1}$.  Autocorrelation has three holes and placement error $3.590\cdot10^{-3}$.
\end{proof}
\begin{theorem}[Admissible transport representation theorem, computational form]
For this H1 segment and this placement functional, the admissible observable object is not a coordinate vector $W_{\rm obs}$ but the class $\Wadm$.  Elements of $\Wadm$ determine a transport-stable placement geometry; non-admissible replacements may reproduce some scalar placement statistics but do not preserve the complete transport geometry.
\end{theorem}
\begin{proof}[Computational proof]
The primitive and dyadic spectral representations both pass the admissibility gate.  Spectral moments have excellent placement $R^2$ but fail transport by many orders of magnitude.  Autocorrelation has weaker placement recovery and nonzero holes.  Therefore placement prediction alone is insufficient.  The admissible object is selected by the joint gate of gauge-free rank, transport coherence, and placement preservation.
\end{proof}
\section{Numerical Admissibility Test}
\begin{table}[h]
\centering
\begin{tabular}{lrrrrr}
\toprule
Basis & Rank $10^{-3}$ & Holes & Transport median & $\rho$ rel. error & Pass\\
\midrule
Primitive bands & 9 & 0 & $8.579\cdot10^{-16}$ & $1.580\cdot10^{-3}$ & yes\\
Dyadic bands & 9 & 0 & $7.493\cdot10^{-16}$ & $1.556\cdot10^{-3}$ & yes\\
Spectral moments & 7 & 2 & $6.848\cdot10^{-1}$ & $6.909\cdot10^{-4}$ & no\\
Autocorrelation & 6 & 3 & $5.458\cdot10^{-2}$ & $3.590\cdot10^{-3}$ & no\\
\bottomrule
\end{tabular}
\caption{Observable replacement battery and admissibility-gate result.}
\label{tab:gate}
\end{table}
\begin{figure}[h]\centering\includegraphics[width=.85\linewidth]{rg_admissible_transport_uniqueness_gate.png}\caption{Admissibility-gate metrics for replacement observables.}\end{figure}
\section{Interpretation}
The strong coordinate-level uniqueness theorem is false: there is not a single compelled coordinate list.  The supported theorem is class-level uniqueness: admissible spectral representations define the same kind of transport-stable placement geometry, while non-admissible summaries fail either transport, null, or placement criteria.
\section{Final Definition for Future Papers}
Future papers should define $W_{\rm obs}$ as $\Wadm$, not as one handcrafted vector.  A concrete coordinate basis may be used for computation, but claims attach to the admissible class.
\section{Reproducibility}
The outputs are \texttt{rg\_admissible\_transport\_uniqueness\_results.json}, \texttt{rg\_admissible\_transport\_uniqueness\_summary.txt}, and \texttt{run\_rg\_admissible\_transport\_uniqueness.py}.  They build on \texttt{rg\_observable\_replacement\_battery\_results.json}.
\end{document}
'''
tex_path=OUT/'RG_Admissible_Wobs_Transport_Uniqueness_Final.tex'
tex_path.write_text(tex,encoding='utf-8')
print('\n'.join(lines))
print('WROTE',json_path,summary_path,plot_path,tex_path)
