"""RG GR Automation battery (print: 'RG - GR Automation').

The pipeline under attack:   (M, g) + (B, Sigma, S)  ->  (F, H_g)  ->  (P_R, P_N)  ->  A_RN  ->  W_obs  ->  T_obs.
Every arrow is a theorem checked here on computed objects. Nothing is seeded: transport blocks are derivatives of
projectors computed from the metric. Every group carries a canary that fails when the claim is false, or exhibits the
boundary where the claim stops.

Groups
  GA  pencil invariants: congruence invariance, completeness, Sigma-independence of the full sector, capture identities
  GB  identification: Bayesian posterior with energy (Gibbs) prior, mutual information, optimal low-rank update
  GC  representer theorem: R = span of Green functions of the detector; health spectrum = spec(Sigma^-1 G)
  GD  continuum limit: 1-D Green matrix converges O(h^2); 2-D block detector converges; point detector diverges (canary)
  GE  Schwarzschild s-wave exact: G_ij = u_min/(8 pi M), u = -ln(1-2M/r); capacitance law; horizon wall; flat limit
  GF  transport block: dP_R = -P_N H^-1 dH P_R, complete (purely N<-R); closed-form Schwarzschild amplitude;
      massless conformal rescaling gives zero block; seeded-amplitude canary
  GG  transport-stress duality: dH(u, v) equals the stress bilinear integrated against the metric variation
  GH  holonomy: full sector exactly trivial on any loop; truncated sector nontrivial; rotating detector gives a Moebius
      kernel bundle (holonomy -1)
  GI  envelope identity: exact for data constraints (linear and quartic); fails for metric-dependent frames (canary);
      corrected formula with the multiplier term
  GJ  energy deficit: E = W_obs + E_N, W_obs is the quotient norm; refinement monotone; local cross stress nonzero
  GK  Ward identity: observable stress is conserved off the detector; jump equals the force on the detector source
  GL  Killing transport: spatial isometry and Killing time leave the health spectrum invariant; Hellmann-Feynman rate
      otherwise; Kalman unobservable subspace is the hole and is flow invariant; time-dependent background canary
  GM  Lorentzian wall: an indefinite form has no orthogonal resolved/null split (null vector canary, complex pencil)
  GN  exterior gravimetry hole: null densities Laplacian(psi) (exact), resolution law (a/R)^(l+1), balayage: the
      energy complement is the boundary layer, the L2 complement is the harmonic density (complement relativity)
  GO  GR interior hole: two TOV interiors with equal mass have the same exterior; Buchdahl wall canary
  GP  groupoid algebra of the hole action: free action gives matrix blocks over the quotient (Morita, finite case);
      non-free action canary
  GQ  monotonicity: detector refinement raises the spectrum (Weyl), coarse-graining lowers it (data processing)

Run: python rg_gr_automation.py   (numpy, scipy, sympy). Seed 20261111. Deterministic. Writes rg_gr_automation_results.json.
"""
import hashlib, json, math, sys
from pathlib import Path
import numpy as np
import sympy as s
from scipy.linalg import eigh, expm, null_space
from scipy.integrate import solve_ivp, quad

HERE = Path(__file__).resolve().parent
SEED = 20261111
rng = np.random.default_rng(SEED)
R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.10g}')


def spd(n, lo=0.5):
    A = rng.normal(size=(n, n)); return A @ A.T + lo * np.eye(n)


def chain(w):
    n = len(w) + 1; H = np.zeros((n, n))
    for e, we in enumerate(w):
        H[e, e] += we; H[e + 1, e + 1] += we; H[e, e + 1] -= we; H[e + 1, e] -= we
    return H


def P_R(H, B):
    Hi = np.linalg.inv(H); return Hi @ B.T @ np.linalg.inv(B @ Hi @ B.T) @ B


def pencil(F, H):
    lam, V = eigh(F, H); return lam[::-1], V[:, ::-1]


def u_of(r, M):
    return -np.log(1 - 2 * M / r)


def radial_exact(M, r):
    """Massless static s-wave on Schwarzschild, exact harmonic conductances; Dirichlet at the outer node."""
    g = (lambda x: u_of(x, M) / (8 * np.pi * M)) if M > 0 else (lambda x: 1 / (4 * np.pi * x))
    H = chain(1 / (g(r[:-1]) - g(r[1:])))
    return H[:-1, :-1], g


def radial_mid(r, lapse, u, m2):
    """General static s-wave energy: 1/2 int 4 pi r^2 [N sqrt(u) phi'^2 + N m2 phi^2 / sqrt(u)] dr, u = h^{rr}; midpoint rule."""
    dr = r[1] - r[0]; re = 0.5 * (r[:-1] + r[1:])
    Ne, ue = 0.5 * (lapse[:-1] + lapse[1:]), 0.5 * (u[:-1] + u[1:])
    H = chain(4 * np.pi * re ** 2 * Ne * np.sqrt(ue) / dr)
    mu = 4 * np.pi * r ** 2 * lapse / np.sqrt(u) * m2 * dr; mu[0] *= 0.5; mu[-1] *= 0.5
    return (H + np.diag(mu))[:-1, :-1]


def schw_mid(M, m2, r):
    return radial_mid(r, np.sqrt(1 - 2 * M / r), 1 - 2 * M / r, m2)


def node_detector(idx, n):
    B = np.zeros((len(idx), n))
    for a, i in enumerate(idx):
        B[a, i] = 1.0
    return B


# ============================================================================================  GA
def GA():
    n, k = 14, 5
    H = spd(n); B = rng.normal(size=(k, n)); Sig = spd(k); F = B.T @ np.linalg.inv(Sig) @ B
    lam, V = pencil(F, H)
    # congruence invariance under a random change of field coordinates phi = T phi'
    T = rng.normal(size=(n, n)) + 3 * np.eye(n)
    lam2, _ = pencil(T.T @ F @ T, T.T @ H @ T)
    inv_err = np.max(np.abs(lam - lam2)) / lam[0]
    # completeness: two pairs with the same spectrum are congruent (construct the congruence, verify)
    H2 = spd(n); W2 = np.linalg.cholesky(H2)
    Q = np.linalg.qr(rng.normal(size=(n, n)))[0]
    F2 = W2 @ Q @ np.diag(np.maximum(lam, 0)) @ Q.T @ W2.T          # same pencil spectrum by construction
    l1, V1 = pencil(F, H); l2, V2 = pencil(F2, H2)
    Tc = V1 @ np.linalg.inv(V2)                                     # maps pair 2 to pair 1
    comp_err = max(np.max(np.abs(Tc.T @ H @ Tc - H2)), np.max(np.abs(Tc.T @ F @ Tc - F2))) / np.max(np.abs(H2))
    # Sigma-independence of the full sector: N = ker B, R = H-orthocomplement, for any Sigma
    P = P_R(H, B)
    sig_err = 0.0
    for _ in range(5):
        S2 = spd(k); _, Vs = pencil(B.T @ np.linalg.inv(S2) @ B, H)
        sig_err = max(sig_err, np.max(np.abs(Vs[:, :k] @ Vs[:, :k].T @ H - P)))
    ker_err = np.max(np.abs(B @ (np.eye(n) - P)))
    # capture identities: capture(k') = sum of top k' eigenvalues / trace; equals 1 iff k' >= rank B;
    # a random H-orthonormal k'-frame captures k'/n in expectation
    cap = lambda kk: float(np.sum(lam[:kk]) / np.sum(lam))
    Li = np.linalg.inv(np.linalg.cholesky(H))
    Fw = Li @ F @ Li.T
    rnd = []
    for _ in range(4000):
        Qr = np.linalg.qr(rng.normal(size=(n, 3)))[0]; rnd.append(np.trace(Qr.T @ Fw @ Qr) / np.trace(Fw))
    rnd_mean, rnd_se = float(np.mean(rnd)), float(np.std(rnd) / math.sqrt(len(rnd)))
    # canary: a non-congruence change (H -> H + D) changes the spectrum
    lam3, _ = pencil(F, H + np.diag(rng.uniform(0.5, 1.5, n)))
    canary = np.max(np.abs(lam - lam3)) / lam[0]
    ok = inv_err < 1e-10 and comp_err < 1e-8 and sig_err < 1e-9 and ker_err < 1e-10 and abs(cap(k) - 1) < 1e-12 and cap(k - 1) < 1 - 1e-6 \
        and abs(rnd_mean - 3 / n) < 4 * rnd_se and canary > 1e-3
    must(ok, 'GA')
    R['GA'] = dict(claim='The relative spectrum of the Fisher form F = B^T Sigma^-1 B with respect to the energy form H is invariant under '
                         'every linear change of field coordinates and is a complete invariant of the pair (constructed congruence). With '
                         'full budget the null sector is ker B and the resolved sector is its H-orthocomplement, independent of Sigma. '
                         'Capture identities: capture equals 1 exactly when the budget reaches rank B, and a random frame captures k/n in '
                         'expectation. Both are identities, so they certify nothing about a model. Canary: a non-congruent change of H '
                         'moves the spectrum.',
                   status='PROVED (linear algebra) + IDENTIFIED (simultaneous diagonalization)', invariance_err=fl(inv_err),
                   completeness_err=fl(comp_err), sigma_independence_err=fl(sig_err), kernel_err=fl(ker_err), capture_at_rank=fl(cap(k)),
                   capture_below_rank=fl(cap(k - 1)), random_capture_mean=fl(rnd_mean), random_capture_expected=fl(3 / n),
                   random_capture_se=fl(rnd_se), canary_shift=fl(canary))


# ============================================================================================  GB
def GB():
    n, k = 12, 6
    H = spd(n); B = rng.normal(size=(k, n)); Sig = spd(k); F = B.T @ np.linalg.inv(Sig) @ B
    beta = 0.7
    lam, V = pencil(F, H)                                             # V^T H V = I
    post = np.linalg.inv(F + beta * H); prior = np.linalg.inv(beta * H)
    # mutual information between field and data under the Gibbs prior N(0, (beta H)^-1)
    mi_direct = 0.5 * (np.linalg.slogdet(prior)[1] - np.linalg.slogdet(post)[1])
    mi_spec = 0.5 * float(np.sum(np.log1p(np.maximum(lam, 0) / beta)))
    # optimal rank-q posterior update (Spantini et al.): prior - sum_{i<=q} lam_i/(beta(beta+lam_i)) v_i v_i^T
    def approx(order, q):
        C = prior.copy()
        for i in order[:q]:
            C -= lam[i] / (beta * (beta + lam[i])) * np.outer(V[:, i], V[:, i])
        return C
    def forstner(A, Bm):
        w = eigh(A, Bm, eigvals_only=True); return float(np.sqrt(np.sum(np.log(w) ** 2)))
    q = 3
    d_opt = forstner(approx(list(range(n)), q), post)
    d_wrong = forstner(approx([3, 4, 5, 0, 1, 2], q), post)          # canary: keep the weakest resolved directions instead
    d_rand = []
    for _ in range(200):
        Qr = np.linalg.qr(rng.normal(size=(n, q)))[0]
        Lh = np.linalg.cholesky(H); W = np.linalg.solve(Lh.T, Qr)     # H-orthonormal random frame
        Fq = W.T @ F @ W
        mu, Z = np.linalg.eigh(Fq); Wz = W @ Z
        C = prior.copy()
        for j in range(q):
            C -= mu[j] / (beta * (beta + mu[j])) * np.outer(Wz[:, j], Wz[:, j])
        d_rand.append(forstner(C, post))
    full = forstner(approx(list(range(n)), k), post)
    ok = abs(mi_direct - mi_spec) < 1e-9 and full < 1e-6 and d_opt < d_wrong and d_opt <= min(d_rand) + 1e-9
    must(ok, 'GB')
    R['GB'] = dict(claim='Identification. With the Gibbs prior of the energy form, covariance (beta H)^-1, the pencil eigenvalues are the '
                         'signal-to-noise eigenvalues of a linear Bayesian inverse problem: the mutual information is '
                         '1/2 sum log(1 + lambda_i/beta), and the top generalized eigenvectors give the optimal low-rank posterior '
                         'update (likelihood-informed subspace). The energy form plays the role of the prior precision; it is supplied '
                         'by the metric, not chosen. Canary: keeping the weakest resolved directions, or random frames, is worse.',
                   status='IDENTIFIED (Spantini et al. 2015; Ky Fan)', mutual_info_direct=fl(mi_direct), mutual_info_spectral=fl(mi_spec),
                   forstner_optimal=fl(d_opt), forstner_wrong_order=fl(d_wrong), forstner_random_min=fl(min(d_rand)), forstner_full_rank=fl(full))


# ============================================================================================  GC
def GC():
    n, k = 16, 4
    H = spd(n); B = rng.normal(size=(k, n)); Sig = spd(k); F = B.T @ np.linalg.inv(Sig) @ B
    Hi = np.linalg.inv(H); G = B @ Hi @ B.T
    rep = Hi @ B.T                                                    # representers r_i = H^-1 b_i
    lam, V = pencil(F, H)
    # span check: resolved eigenvectors lie in span(rep)
    Pspan = rep @ np.linalg.pinv(rep)
    span_err = np.max(np.abs(Pspan @ V[:, :k] - V[:, :k]))
    spec_err = np.max(np.abs(np.sort(lam[:k]) - np.sort(np.linalg.eigvals(np.linalg.inv(Sig) @ G).real))) / lam[0]
    # reproducing property: H(r_i, v) = b_i(v)
    v = rng.normal(size=n); repro_err = np.max(np.abs(rep.T @ H @ v - B @ v))
    # minimal-energy interpolant is in R and solves the field equation with sources on the detector: H phi* = B^T mu
    y = rng.normal(size=k); mu = np.linalg.solve(G, y); phi = rep @ mu
    eq_err = max(np.max(np.abs(B @ phi - y)), np.max(np.abs(H @ phi - B.T @ mu)))
    # canary: representers computed with a different energy form do not span the resolved sector
    rep2 = np.linalg.inv(H + np.diag(rng.uniform(1, 2, n))) @ B.T
    canary = np.max(np.abs(rep2 @ np.linalg.pinv(rep2) @ V[:, :k] - V[:, :k]))
    ok = span_err < 1e-9 and spec_err < 1e-10 and repro_err < 1e-10 and eq_err < 1e-9 and canary > 1e-2
    must(ok, 'GC')
    R['GC'] = dict(claim='Representer theorem. The resolved sector is the span of the Riesz representers r_i = H^-1 b_i of the detector '
                         'functionals: the fields that sources placed on the detector would generate (Green functions of the metric). '
                         'The nonzero health spectrum equals the spectrum of the k x k matrix Sigma^-1 G, G_ij = b_i(H^-1 b_j). The '
                         'minimal-energy field consistent with the data solves the field equation with sources on the detector. Canary: '
                         'representers of another energy form do not span the sector.',
                   status='PROVED + IDENTIFIED (Riesz; Kimeldorf-Wahba)', span_err=fl(span_err), spectrum_err=fl(spec_err),
                   reproducing_err=fl(repro_err), field_equation_err=fl(eq_err), canary_misfit=fl(canary))


# ============================================================================================  GD
def GD():
    # 1-D massive field on [0, L], Dirichlet ends: G(x, y) = sinh(m x<) sinh(m (L - x>)) / (m sinh(m L))
    L, m = 6.0, 0.8; xs = [1.5, 2.5, 4.0]
    def Gex(x, y):
        a, b = min(x, y), max(x, y); return math.sinh(m * a) * math.sinh(m * (L - b)) / (m * math.sinh(m * L))
    Gx = np.array([[Gex(x, y) for y in xs] for x in xs])
    errs = []
    for n in (120, 240, 480):
        h = L / n
        H = chain(np.full(n, 1 / h))[1:-1, 1:-1] + m * m * h * np.eye(n - 1)
        idx = [int(round(x / h)) - 1 for x in xs]
        G = np.linalg.inv(H)[np.ix_(idx, idx)]
        errs.append(float(np.max(np.abs(G - Gx))))
    rate = math.log2(errs[0] / errs[1]), math.log2(errs[1] / errs[2])
    # 2-D: block-average detector converges; point detector diverges like log(1/h)/(2 pi)
    def grid2(n):
        h = 1.0 / n; N = n - 1
        I = np.eye(N); T = 2 * np.eye(N) - np.eye(N, k=1) - np.eye(N, k=-1)
        return np.kron(T, I) + np.kron(I, T) + (1.0 * h * h) * np.eye(N * N), N, h
    point, block = [], []
    for n in (16, 32, 64):
        H, N, h = grid2(n)
        Hi = np.linalg.inv(H)
        c = n // 2 - 1
        point.append(float(Hi[c * N + c, c * N + c]))
        b = np.zeros(N * N); w = n // 8                               # block of physical side 1/4 centred
        for i in range(n // 2 - 1 - w, n // 2 - 1 + w):
            for j in range(n // 2 - 1 - w, n // 2 - 1 + w):
                b[i * N + j] = 1.0
        b /= b.sum()
        block.append(float(b @ Hi @ b))
    point_growth = [point[1] - point[0], point[2] - point[1]]
    block_change = [abs(block[1] - block[0]), abs(block[2] - block[1])]
    ok = rate[0] > 1.9 and rate[1] > 1.9 and all(abs(g_ - math.log(2) / (2 * math.pi)) < 0.01 for g_ in point_growth) \
        and block_change[1] < 0.5 * block_change[0] and block_change[1] < 0.01
    must(ok, 'GD')
    R['GD'] = dict(claim='The construction is not a finite-grid artefact when the detector functionals are bounded on the energy space: '
                         'the Green matrix G converges to its continuum value (1-D: closed form, rate h^2; 2-D block averages '
                         'converge). Canary and wall: a point detector in two dimensions has self-energy growing by ln 2/(2 pi) per '
                         'mesh halving, so its health spectrum is a mesh artefact. Point probes are inadmissible in dimension >= 2.',
                   status='PROVED (energy-space boundedness) + numerical convergence', green_errors_1d=[fl(e) for e in errs],
                   convergence_orders=[fl(x) for x in rate], point_self_energy=[fl(p) for p in point],
                   point_growth_per_halving=[fl(p) for p in point_growth], log2_over_2pi=fl(math.log(2) / (2 * math.pi)),
                   block_self_energy=[fl(b) for b in block])


# ============================================================================================  GE
def amp_closed(x):
    """|A_RN| per unit d ln M for one shell detector at areal radius r0, x = 2M/r0 (infinite exterior)."""
    E = 1 / (1 - x); u0 = -math.log(1 - x)
    return math.sqrt(((E * E - 1) / 2 - (E - 1) ** 2 / u0) / u0)


def GE():
    M = 1.0; r = np.concatenate([np.linspace(2.2, 30, 300), np.geomspace(31, 3e6, 200)])
    H, g = radial_exact(M, r); n = H.shape[0]
    idx = [5, 40, 120, 260]
    G = np.linalg.inv(H)[np.ix_(idx, idx)]
    Gex = np.array([[g(max(r[i], r[j])) - g(r[-1]) for j in idx] for i in idx])
    err = np.max(np.abs(G - Gex)) / np.max(G)
    # kernel in the static tortoise coordinate u: G = min(u_i, u_j)/(8 pi M): Wiener covariance; inverse tridiagonal
    Ginf = np.array([[min(u_of(r[i], M), u_of(r[j], M)) / (8 * np.pi * M) for j in idx] for i in idx])
    Kinv = np.linalg.inv(Ginf); tri = max(abs(Kinv[0, 2]), abs(Kinv[0, 3]), abs(Kinv[1, 3])) / np.max(np.abs(Kinv))
    # flat limit and capacitance C = 1/G_00: flat 4 pi r0; Schwarzschild 8 pi M / u0
    r0 = 8.0
    C_s = 8 * math.pi * M / u_of(r0, M); C_flat = 4 * math.pi * r0
    lim = [8 * math.pi * Mx / u_of(r0, Mx) / C_flat for Mx in (1e-2, 1e-4, 1e-6)]
    # horizon wall: capacitance -> 0 logarithmically; certified energy per squared reading W/y^2 = C/2
    wall = {f'{x:g}': fl(8 * math.pi * M / u_of(2 * M * (1 + x), M)) for x in (1e-1, 1e-3, 1e-6, 1e-12)}
    # grid check of the wall: detector on the innermost node at r_in = 2M(1 + delta); capacitance from the grid inverse
    wall_grid = []
    for dlt in (1e-1, 1e-3, 1e-6):
        rg_ = np.concatenate([2 * M * (1 + dlt * np.geomspace(1, 1e3, 60)), np.geomspace(2 * M * (1 + dlt * 1.1e3), 1e9, 300)])
        Hg, gg = radial_exact(M, rg_)
        wall_grid.append(abs(1 / np.linalg.inv(Hg)[0, 0] / (1 / (gg(rg_[0]) - gg(rg_[-1]))) - 1))
    # canary: flat-space kernel 1/(4 pi r>) does not reproduce the Schwarzschild grid matrix
    Gflat = np.array([[1 / (4 * np.pi * max(r[i], r[j])) for j in idx] for i in idx])
    canary = np.max(np.abs(G - Gflat)) / np.max(G)
    ok = err < 1e-9 and tri < 1e-10 and abs(lim[2] - 1) < 1e-5 and lim[0] < 1 and wall['1e-12'] < wall['0.001'] < wall['0.1'] \
        and max(wall_grid) < 1e-8 and canary > 1e-2
    must(ok, 'GE')
    R['GE'] = dict(claim='Exact worked example in general relativity. For a static massless scalar on Schwarzschild and shell detectors at '
                         'areal radii r_i, the Green matrix is G_ij = min(u_i, u_j)/(8 pi M) with u = -ln(1 - 2M/r): the Wiener kernel '
                         'in the static tortoise coordinate u (inverse tridiagonal). The grid with harmonic conductances reproduces it '
                         'to rounding. The capacitance of a shell is C = 8 pi M/u_0, with flat limit 4 pi r_0. Horizon wall: C -> 0 '
                         'like 1/|ln(1 - 2M/r_0)|, so a near-horizon reading certifies vanishing Killing energy. Canary: the flat '
                         'kernel 1/(4 pi r>) does not fit.',
                   status='PROVED (closed form) + grid check', closed_form_err=fl(err), tridiagonal_defect=fl(tri),
                   capacitance_r0_8M=fl(C_s), capacitance_flat=fl(C_flat), flat_limit_ratio=[fl(x) for x in lim], horizon_wall_capacitance=wall,
                   wall_grid_rel_err=fl(max(wall_grid)), canary_flat_misfit=fl(canary))


# ============================================================================================  GF
def GF():
    M = 1.0; r = np.concatenate([np.linspace(2.2, 30, 400), np.geomspace(30.5, 3e7, 300)])
    H, _ = radial_exact(M, r); n = H.shape[0]
    idx = [int(np.argmin(np.abs(r - 8.0)))]; r0 = r[idx[0]]
    B = node_detector(idx, n); P = P_R(H, B); PN = np.eye(n) - P
    eps = 1e-5
    Hp, _ = radial_exact(M + eps, r); Hm, _ = radial_exact(M - eps, r)
    dH = (Hp - Hm) / (2 * eps); dP = (P_R(Hp, B) - P_R(Hm, B)) / (2 * eps)
    A = -PN @ np.linalg.inv(H) @ dH @ P
    form_err = np.max(np.abs(dP - A)) / np.max(np.abs(A))
    complete = max(np.max(np.abs(P @ dP)), np.max(np.abs(dP @ PN))) / np.max(np.abs(dP))
    Lc = np.linalg.cholesky(H)
    normH = float(np.linalg.norm(Lc.T @ A @ np.linalg.inv(Lc.T), 2)) * M     # per unit d ln M
    closed = amp_closed(2 * M / r0)
    weak = (2 * M / r0) / (2 * math.sqrt(3))
    # weak-field limit of the closed form: x / (2 sqrt 3)
    weak_ratio = amp_closed(1e-4) / (1e-4 / (2 * math.sqrt(3)))
    # the amplitude that had been seeded by hand, beta = 1 - sqrt(1 - 2M/r), is not the computed block (canary)
    seeded = 1 - math.sqrt(1 - 2 * M / r0)
    # multi-shell block, computed (no closed form claimed)
    idx4 = [int(np.argmin(np.abs(r - x))) for x in (4.0, 8.0, 16.0, 30.0)]
    B4 = node_detector(idx4, n); P4 = P_R(H, B4)
    A4 = -(np.eye(n) - P4) @ np.linalg.inv(H) @ dH @ P4
    norm4 = float(np.linalg.norm(Lc.T @ A4 @ np.linalg.inv(Lc.T), 2)) * M
    # conformal rescaling h_ij -> a^2 h_ij in three dimensions: H(a) = a K + a^3 m^2 Mass; massless: no rotation
    rr = np.linspace(3, 40, 160); K = schw_mid(0.0, 0.0, rr); Mass = schw_mid(0.0, 1.0, rr) - K
    Bc = node_detector([8, 30, 70, 120], K.shape[0])
    def dPa(m2):
        Ha = lambda a: a * K + a ** 3 * m2 * Mass
        return np.max(np.abs((P_R(Ha(1 + 1e-5), Bc) - P_R(Ha(1 - 1e-5), Bc)) / 2e-5))
    conf_massless, conf_massive = dPa(0.0), dPa(0.05)
    ok = form_err < 1e-6 and complete < 1e-6 and abs(normH / closed - 1) < 2e-3 and abs(weak_ratio - 1) < 1e-3 \
        and abs(seeded / closed - 1) > 0.2 and conf_massless < 1e-8 and conf_massive > 1e-4
    must(ok, 'GF')
    R['GF'] = dict(claim='Transport block, computed from the metric. For the full sector, dP_R = -P_N H^-1 (dH) P_R: the derivative of the '
                         'resolved projector is purely the N <- R block, so A_RN is the whole derivative. For one shell detector at '
                         'r_0 on Schwarzschild the energy-norm amplitude per unit d ln M is the closed form '
                         'a(x) = sqrt(((E^2-1)/2 - (E-1)^2/u_0)/u_0), E = 1/(1-x), u_0 = -ln(1-x), x = 2M/r_0; weak field x/(2 sqrt 3). '
                         'At r_0 = 8M: 0.0962. A uniform conformal rescaling of a massless field does not rotate the sector at all; '
                         'a mass term does. Canary: the hand-seeded amplitude 1 - sqrt(1 - 2M/r) = 0.134 is not the computed block.',
                   status='PROVED (formula, closed form) + computed', formula_err=fl(form_err), completeness_defect=fl(complete),
                   amplitude_grid=fl(normH), amplitude_closed=fl(closed), detector_radius=fl(r0), weak_field_estimate=fl(weak),
                   weak_limit_ratio=fl(weak_ratio), seeded_amplitude=fl(seeded), four_shell_amplitude=fl(norm4),
                   conformal_massless_dP=fl(conf_massless), conformal_massive_dP=fl(conf_massive))


# ============================================================================================  GG
def GG():
    # general static radial metric: lapse N(r), u(r) = h^{rr}; energy density e = 4 pi r^2 [N sqrt(u) phi'^2 + N m2 phi^2/sqrt(u)]/2
    r = np.linspace(3, 20, 400); dr = r[1] - r[0]; m2 = 0.3
    N0 = np.sqrt(1 - 2 / r) * (1 + 0.1 * np.sin(r)); u0 = (1 - 2 / r) * (1 + 0.05 * np.cos(2 * r))
    dN = 0.3 * np.exp(-(r - 9) ** 2); du = 0.2 * np.exp(-(r - 13) ** 2 / 2)
    eps = 1e-6
    dH = (radial_mid(r, N0 + eps * dN, u0 + eps * du, m2) - radial_mid(r, N0 - eps * dN, u0 - eps * du, m2)) / (2 * eps)
    n = dH.shape[0]
    f1 = np.sin(0.7 * r) * np.exp(-((r - 10) / 4) ** 2); f2 = np.cos(0.4 * r) * np.exp(-((r - 12) / 5) ** 2)
    f1[-1] = f2[-1] = 0.0
    lhs = f1[:-1] @ dH @ f2[:-1]
    # continuum stress bilinear: dE = int sqrt(h) [rho dN + (1/2) N T_rr d(h^{rr})] with sqrt(h) = r^2/sqrt(u) (4 pi included)
    d1 = lambda f: np.gradient(f, dr)
    rho = 0.5 * (u0 * d1(f1) * d1(f2) + m2 * f1 * f2)                 # polarized energy density
    Trr = d1(f1) * d1(f2) - (1 / u0) * rho                            # polarized T_rr = phi' phi' - h_rr * (1/2)(...)
    integrand = 4 * np.pi * r ** 2 / np.sqrt(u0) * (rho * dN + 0.5 * N0 * Trr * du) * 2   # factor 2: dH is the Hessian of E
    rhs = float(np.sum(integrand) * dr)
    rel = abs(lhs - rhs) / abs(lhs)
    # duality: H(A[dg] r, n) = -dH(r, n) for r in R, n in N
    H = radial_mid(r, N0, u0, m2); B = node_detector([40, 150, 260, 330], n)
    P = P_R(H, B); PN = np.eye(n) - P
    A = -PN @ np.linalg.inv(H) @ dH @ P
    rv = P @ rng.normal(size=n); nv = PN @ rng.normal(size=n)
    dual = abs(nv @ H @ A @ rv + nv @ dH @ rv) / abs(nv @ dH @ rv)
    # canary: dropping the pressure (T_rr) term breaks the identity
    rhs_bad = float(np.sum(4 * np.pi * r ** 2 / np.sqrt(u0) * (rho * dN) * 2) * dr)
    canary = abs(lhs - rhs_bad) / abs(lhs)
    ok = rel < 2e-3 and dual < 1e-9 and canary > 0.05
    must(ok, 'GG')
    R['GG'] = dict(claim='Transport-stress duality. The metric variation of the energy form is the polarized stress tensor: '
                         'dH(u, v) = 2 int sqrt(h) [rho(u, v) dN + (1/2) N T_ij(u, v) d h^{ij}], so the transport block is the mixed '
                         'resolved-null matrix element of the stress tensor: H(A[dg] r, n) = -dH(r, n). Checked for a general static '
                         'radial metric with independent lapse and radial-metric perturbations. Canary: omitting the pressure term fails.',
                   status='PROVED (variation) + numerical check', stress_bilinear_rel_err=fl(rel), duality_rel_err=fl(dual),
                   canary_without_pressure=fl(canary))


# ============================================================================================  GH
def GH():
    r = np.linspace(3, 40, 150); n = len(r) - 1
    B = node_detector([5, 20, 45, 80, 120], n); Sig = np.diag([1, 2, 0.5, 3, 1.5]); F = B.T @ np.linalg.inv(Sig) @ B
    def loop(K):
        t = np.linspace(0, 2 * np.pi, K, endpoint=False)
        return [schw_mid(1.0 + 0.3 * math.cos(x), 0.05 + 0.04 * math.sin(x), r) for x in t]
    def hol(k, Hs):
        V0 = pencil(F, Hs[0])[1][:, :k]; X = V0.copy()
        for H in Hs[1:] + [Hs[0]]:
            V = pencil(F, H)[1][:, :k]; X = V @ (V.T @ H @ X)
        return V0.T @ Hs[0] @ X
    full = [float(np.max(np.abs(hol(5, loop(K)) - np.eye(5)))) for K in (12, 100)]
    trunc = [float(np.max(np.abs(hol(2, loop(K)) - np.eye(2)))) for K in (100, 400, 1600)]
    # retraced path (out and back along the same arc): trivial in the fine limit even for the truncated sector (canary for method)
    def retrace(K):
        t = np.concatenate([np.linspace(0, 2.0, K), np.linspace(2.0, 0, K)[1:-1]])
        return [schw_mid(1.0 + 0.3 * math.cos(x), 0.05 + 0.04 * math.sin(x), r) for x in t]
    back = [float(np.max(np.abs(hol(2, retrace(K)) - np.eye(2)))) for K in (100, 400)]
    # rotating detector: b(t) = (cos t/2, sin t/2) on R^2, t in [0, 2 pi]; the kernel line bundle is Moebius
    K = 40000; ts = np.linspace(0, 2 * np.pi, K + 1)
    v = np.array([-math.sin(0), math.cos(0)]); v0 = v.copy()
    for t in ts[1:]:
        kline = np.array([-math.sin(t / 2), math.cos(t / 2)]); v = kline * (kline @ v)
    moebius = float(v @ v0 / (v0 @ v0))
    ok = max(full) < 1e-10 and trunc[2] > 1e-3 and abs(trunc[2] - trunc[1]) < 0.05 * trunc[2] and back[1] < 0.3 * back[0] \
        and back[1] < 0.1 * trunc[2] and abs(moebius + 1) < 1e-3
    must(ok, 'GH')
    R['GH'] = dict(claim='Holonomy. For the full sector the resolved bundle over the space of metrics is canonically the observable '
                         'quotient V/ker B, so transport by projection has exactly trivial holonomy on every loop, even a coarse one. '
                         'Holonomy appears only through (i) a truncated budget, where the discarded part depends on the metric and on '
                         'Sigma, or (ii) a detector that moves with the loop: a detector line rotating by pi gives a Moebius kernel '
                         'bundle with holonomy -1. Canary for the method: a retraced path has vanishing holonomy in the fine limit.',
                   status='PROVED (quotient identification) + computed', full_sector_holonomy_defect=[fl(x) for x in full],
                   truncated_holonomy_defect=[fl(x) for x in trunc], retraced_defect=[fl(x) for x in back], moebius_holonomy=fl(moebius))


# ============================================================================================  GI
def GI():
    r = np.linspace(3, 30, 120); n = len(r) - 1
    B = np.zeros((4, n))
    for a, c in enumerate((10, 35, 70, 100)):
        B[a, c - 2:c + 3] = 0.2
    y = np.array([0.7, -0.4, 1.1, 0.3]); m2 = 0.1; M0 = 1.0
    Hof = lambda M: schw_mid(M, m2, r)
    def W_lin(M):
        H = Hof(M); G = B @ np.linalg.inv(H) @ B.T; return 0.5 * y @ np.linalg.solve(G, y)
    def phi_star(M):
        H = Hof(M); Hi = np.linalg.inv(H); return Hi @ B.T @ np.linalg.solve(B @ Hi @ B.T, y)
    eps = 1e-5
    dW = (W_lin(M0 + eps) - W_lin(M0 - eps)) / (2 * eps)
    dH = (Hof(M0 + eps) - Hof(M0 - eps)) / (2 * eps)
    ph = phi_star(M0); env = 0.5 * ph @ dH @ ph
    lin_err = abs(dW - env) / abs(env)
    # quartic (nonlinear) action with the same data constraint: phi = phi_p + Z z
    lam4 = 0.5; dr = r[1] - r[0]; wq = 4 * np.pi * r[:-1] ** 2 * dr
    Z = null_space(B); php = np.linalg.pinv(B) @ y
    def S(phi, M):
        return 0.5 * phi @ Hof(M) @ phi + lam4 * float(np.sum(wq * phi ** 4)) / 4
    def W_nl(M, z0=None):
        H = Hof(M); z = np.zeros(Z.shape[1]) if z0 is None else z0.copy()
        for _ in range(60):                                           # Newton on the convex reduced problem
            ph_ = php + Z @ z
            gz = Z.T @ (H @ ph_ + lam4 * wq * ph_ ** 3)
            Hz = Z.T @ (H + 3 * lam4 * np.diag(wq * ph_ ** 2)) @ Z
            dz = np.linalg.solve(Hz, gz); z = z - dz
            if np.max(np.abs(dz)) < 1e-14:
                break
        return S(php + Z @ z, M), z
    w0, z0 = W_nl(M0)
    wp, _ = W_nl(M0 + 1e-4, z0); wm, _ = W_nl(M0 - 1e-4, z0)
    dWn = (wp - wm) / 2e-4
    phn = php + Z @ z0
    envn = 0.5 * phn @ dH @ phn
    nl_err = abs(dWn - envn) / abs(envn)
    stat = float(np.max(np.abs(Z.T @ (Hof(M0) @ phn + lam4 * wq * phn ** 3))) / np.max(np.abs(Hof(M0) @ phn)))
    # canary: hold H-orthonormal resolved coordinates c = V_R^T H phi fixed instead of the data. Then W = |c|^2/2 for every
    # metric, its metric derivative is zero, and the naive envelope value is wrong. The corrected identity carries the
    # multiplier term: dW/dM = dS/dM - mu^T (dC/dM) phi*.
    def frame(M):
        H = Hof(M); lam, V = pencil(B.T @ B, H); VR = V[:, :4]
        return H, VR
    H0, VR0 = frame(M0); c = VR0.T @ H0 @ ph
    def W_frame(M):
        H, VR = frame(M); sgn = np.sign(np.sum(VR * (H0 @ VR0) * 0 + VR * VR0, axis=0)); VR = VR * sgn
        C = VR.T @ H; phi = np.linalg.solve(H, C.T @ np.linalg.solve(C @ np.linalg.solve(H, C.T), c)); return 0.5 * phi @ H @ phi
    dWf = (W_frame(M0 + eps) - W_frame(M0 - eps)) / (2 * eps)
    naive = 0.5 * ph @ dH @ ph
    frame_gap = abs(dWf - naive) / abs(naive)
    ok = lin_err < 1e-6 and nl_err < 1e-6 and stat < 1e-10 and abs(dWf) < 1e-6 * abs(naive) and frame_gap > 0.99
    must(ok, 'GI')
    R['GI'] = dict(claim='Envelope identity, operational form. With the detector readings y held fixed (a metric-independent constraint '
                         'B phi = y), dW_obs/dg equals the explicit metric derivative of the action at the eliminated field, for the '
                         'quadratic and for a quartic action. Omitted step found: the identity is false when "the resolved field" is '
                         'held fixed in a metric-dependent frame. In H-orthonormal resolved coordinates W = |c|^2/2 for every metric, so '
                         'its metric derivative vanishes and the source would be zero (canary). The general identity is '
                         'dW = dS - mu^T (dC) phi* with mu the constraint multiplier.',
                   status='PROVED (constrained envelope) + canary', linear_rel_err=fl(lin_err), quartic_rel_err=fl(nl_err),
                   quartic_stationarity=fl(stat), frame_constraint_dW=fl(dWf), naive_envelope_value=fl(naive), frame_gap=fl(frame_gap))


# ============================================================================================  GJ
def GJ():
    r = np.linspace(3, 30, 200); n = len(r) - 1; H = schw_mid(1.0, 0.1, r)
    phi = np.sin(0.9 * r[:-1]) * np.exp(-((r[:-1] - 12) / 6) ** 2) + 0.3 * rng.normal(size=n) / r[:-1]
    E = 0.5 * phi @ H @ phi
    Ws, splits = [], []
    cuts = [[60], [30, 60, 120], [15, 30, 45, 60, 90, 120, 150], list(range(5, 195, 5))]
    for c_ in cuts:
        B = node_detector(c_, n); P = P_R(H, B); pr, pn = P @ phi, phi - P @ phi
        W = 0.5 * pr @ H @ pr; EN = 0.5 * pn @ H @ pn
        Ws.append(W); splits.append(abs(E - W - EN) / E)
        cross = abs(pr @ H @ pn) / E
    # W is the quotient norm: minimum of the energy over the coset phi + ker B
    B = node_detector(cuts[1], n); P = P_R(H, B); Z = null_space(B)
    trial = []
    for _ in range(200):
        cand = phi + Z @ rng.normal(size=Z.shape[1]) * 0.3; trial.append(0.5 * cand @ H @ cand)
    quot = min(trial) >= Ws[1] - 1e-9 * Ws[1]
    # local cross stress does not vanish although its integral does
    pr, pn = P @ phi, phi - P @ phi
    dr = r[1] - r[0]; re = 0.5 * (r[:-1] + r[1:])
    full_r = lambda v: np.append(v, 0.0)
    local_cross = 4 * np.pi * re * (re - 2.0) * np.diff(full_r(pr)) * np.diff(full_r(pn)) / dr
    local_max = float(np.max(np.abs(local_cross))); integral = float(abs(pr @ H @ pn))
    # canary: a non-orthogonal split (Euclidean projector onto the same R) has a cross term
    Q = np.linalg.qr(np.linalg.inv(H) @ B.T)[0]; pe = Q @ (Q.T @ phi)
    canary = abs(pe @ H @ (phi - pe)) / E
    ok = max(splits) < 1e-10 and all(Ws[i] <= Ws[i + 1] + 1e-12 for i in range(3)) and Ws[-1] <= E and quot and cross < 1e-10 \
        and local_max > 1e3 * integral and canary > 1e-4
    must(ok, 'GJ')
    R['GJ'] = dict(claim='Energy deficit. W_obs is the quotient norm of the energy on V/ker B: the least energy of any field with the '
                         'observed readings. Every field obeys E = W_obs + E_N with E_N >= 0 the energy of its null part, so a finite '
                         'observer certifies a lower bound and the deficit has one sign. Refining the detector raises W_obs '
                         'monotonically towards E. The cross term vanishes in the integrated energy but not in the local stress. '
                         'Canary: a Euclidean (not energy-orthogonal) split has a nonzero cross energy.',
                   status='PROVED (orthogonal decomposition)', total_energy=fl(E), W_obs_by_refinement=[fl(w) for w in Ws],
                   split_defect=fl(max(splits)), local_cross_stress_max=fl(local_max), integrated_cross=fl(integral), canary_cross=fl(canary))


# ============================================================================================  GK
def GK():
    L, m = 10.0, 0.6; xs = [3.0, 5.0, 8.0]; y = np.array([1.0, -0.5, 0.8])
    out = {}
    for n in (2000, 4000):
        h = L / n; H = chain(np.full(n, 1 / h))[1:-1, 1:-1] + m * m * h * np.eye(n - 1)
        idx = [int(round(x / h)) - 1 for x in xs]; B = node_detector(idx, n - 1)
        Hi = np.linalg.inv(H); mu = np.linalg.solve(B @ Hi @ B.T, y); phi = Hi @ B.T @ mu
        ph = np.concatenate([[0.0], phi, [0.0]])
        dphi = np.diff(ph) / h; mid = 0.5 * (ph[:-1] + ph[1:])
        T = 0.5 * (dphi ** 2 - m * m * mid ** 2)                     # T_xx on edges
        nodes = [i + 1 for i in idx]                                  # index in ph
        segs = [(0, nodes[0]), (nodes[0], nodes[1]), (nodes[1], nodes[2]), (nodes[2], n)]
        flat = max(float(np.ptp(T[a:b])) for a, b in segs)
        jumps = [float(T[i] - T[i - 1]) for i in nodes]
        forces = [float(-mu[a] * 0.5 * (dphi[i] + dphi[i - 1])) for a, i in enumerate(nodes)]
        jerr = max(abs(j - f) for j, f in zip(jumps, forces)) / max(abs(j) for j in jumps)
        balance = abs((T[-1] - T[0]) - sum(forces)) / max(abs(j) for j in jumps)
        out[n] = (flat, jerr, balance, jumps)
    # canary: a field that is not the eliminated branch (add a null-sector bump) is not conserved off the detector
    bump = np.exp(-((np.linspace(0, L, 4001)[1:-1] - 6.5) / 0.4) ** 2)
    Bn = node_detector(idx, 3999); bump = bump - P_R(H, Bn) @ bump
    ph2 = np.concatenate([[0.0], phi + bump, [0.0]]); d2 = np.diff(ph2) / h; mid2 = 0.5 * (ph2[:-1] + ph2[1:])
    T2 = 0.5 * (d2 ** 2 - m * m * mid2 ** 2); canary = float(np.ptp(T2[nodes[1]:nodes[2]]))
    ok = out[4000][0] < 0.3 * out[2000][0] and out[4000][0] < 1e-6 and out[4000][1] < 1e-5 and out[4000][1] < 0.5 * out[2000][1] and out[4000][2] < 1e-5 and canary > 1e-2
    must(ok, 'GK')
    R['GK'] = dict(claim='Ward identity for the observable source. The eliminated field solves the field equation with sources on the '
                         'detector, so its stress tensor obeys div T_obs = -J grad(phi*): it is conserved wherever the detector is '
                         'absent, and its jump across a detector equals the force on the detector source (1-D: T_xx piecewise constant, '
                         'jump = -mu_i phi\'_avg). Coupling T_obs alone to the Einstein tensor is therefore inconsistent with the '
                         'Bianchi identity on the detector support: the detector must be in the ledger. Canary: adding a null-sector '
                         'bump destroys conservation between detectors.',
                   status='PROVED (field equation) + numerical check', off_detector_variation=[fl(out[2000][0]), fl(out[4000][0])],
                   jump_vs_force_rel_err=[fl(out[2000][1]), fl(out[4000][1])], global_balance_rel_err=fl(out[4000][2]), jumps=[fl(j) for j in out[4000][3]],
                   canary_variation=fl(canary))


# ============================================================================================  GL
def GL():
    # (a) spatial isometry: periodic 2-D torus, uniform metric; translating the detector leaves spec(G) invariant
    n = 16; I = np.eye(n); T1 = 2 * I - np.roll(I, 1, 0) - np.roll(I, -1, 0)
    def torus(conf):
        # energy 1/2 sum_edges w_e (dphi)^2 + 1/2 sum m^2 a^2 phi^2, conformal factor a(x) in two dimensions: edges unweighted
        Hk = np.kron(T1, I) + np.kron(I, T1); return Hk + np.diag(0.3 * conf.ravel() ** 2)
    def detector(shift):
        B = np.zeros((3, n * n))
        for a, (i, j) in enumerate([(2, 3), (5, 9), (11, 6)]):
            for di in range(2):
                for dj in range(2):
                    B[a, ((i + di + shift) % n) * n + (j + dj) % n] = 0.25
        return B
    Sig = np.diag([1.0, 2.0, 0.5])
    spec = lambda H, B: np.sort(np.linalg.eigvals(np.linalg.inv(Sig) @ B @ np.linalg.inv(H) @ B.T).real)
    flat = torus(np.ones((n, n)))
    iso = float(np.max(np.abs(spec(flat, detector(0)) - spec(flat, detector(3)))))
    xx = np.arange(n)[:, None] * np.ones((1, n))
    bumpy = torus(1 + 0.5 * np.sin(2 * np.pi * xx / n))
    non_iso = float(np.max(np.abs(spec(bumpy, detector(0)) - spec(bumpy, detector(3)))))
    # Hellmann-Feynman for the pencil: d lambda = v^T (dF - lambda dH) v with v^T H v = 1
    H = spd(10); Bm = rng.normal(size=(4, 10)); F = Bm.T @ Bm; dHm = spd(10, 0.0) * 0.1
    lam, V = pencil(F, H); eps = 1e-6
    lp, _ = pencil(F, H + eps * dHm); lm, _ = pencil(F, H - eps * dHm)
    hf = max(abs((lp[i] - lm[i]) / (2 * eps) + lam[i] * V[:, i] @ dHm @ V[:, i]) for i in range(4)) / lam[0]
    # (b) Killing time: phase space z = (phi, pi), energy form E = diag(K, 1), flow U_t = exp(t [[0, 1], [-K, 0]])
    N = 6; K = chain(np.ones(N - 1)) + 0.4 * np.eye(N)
    Jm = np.block([[np.zeros((N, N)), np.eye(N)], [-K, np.zeros((N, N))]]); Ef = np.block([[K, np.zeros((N, N))], [np.zeros((N, N)), np.eye(N)]])
    b = np.zeros((1, 2 * N)); b[0, 1] = 1.0
    times = np.array([0.0, 0.7, 1.9, 3.1, 4.4, 6.0, 7.3, 9.9, 11.2, 13.0, 14.1, 16.6, 18.0])
    def Fwin(s0, drift=0.0):
        Fm = np.zeros((2 * N, 2 * N))
        for t in times:
            if drift == 0.0:
                U = expm((t + s0) * Jm)
            else:                                                      # time-dependent background: stiffness drifts during the window
                U = np.eye(2 * N)
                for q in range(200):
                    tq = (t + s0) * (q + 0.5) / 200
                    Jq = np.block([[np.zeros((N, N)), np.eye(N)], [-(1 + drift * tq) * K, np.zeros((N, N))]])
                    U = expm((t + s0) / 200 * Jq) @ U
            Fm += U.T @ b.T @ b @ U
        return Fm
    l0 = pencil(Fwin(0.0), Ef)[0]; l1 = pencil(Fwin(2.3), Ef)[0]
    killing = float(np.max(np.abs(l0 - l1)) / l0[0])
    ld0 = pencil(Fwin(0.0, 0.02), Ef)[0]; ld1 = pencil(Fwin(2.3, 0.02), Ef)[0]
    nonstat = float(np.max(np.abs(ld0 - ld1)) / ld0[0])
    energy_pres = float(np.max(np.abs(expm(1.7 * Jm).T @ Ef @ expm(1.7 * Jm) - Ef)))
    # Kalman: a symmetric chain observed at its centre cannot see antisymmetric modes
    N2 = 5; K2 = chain(np.ones(N2 - 1)) + 0.4 * np.eye(N2)
    J2 = np.block([[np.zeros((N2, N2)), np.eye(N2)], [-K2, np.zeros((N2, N2))]]); E2 = np.block([[K2, np.zeros((N2, N2))], [np.zeros((N2, N2)), np.eye(N2)]])
    c = np.zeros((1, 2 * N2)); c[0, 2] = 1.0
    Obs = np.vstack([c @ np.linalg.matrix_power(J2, q) for q in range(2 * N2)])
    hole = null_space(Obs, rcond=1e-10); hole_dim = hole.shape[1]
    inv = float(np.max(np.abs(Obs @ expm(0.9 * J2) @ hole)))
    Fk = sum(expm(t * J2).T @ c.T @ c @ expm(t * J2) for t in np.linspace(0, 20, 60))
    lk = pencil(Fk, E2)[0]; zero_count = int(np.sum(lk < 1e-9 * lk[0]))
    # deformation formula in closed form (1-D, massive, Dirichlet interval; xi vanishes at the ends):
    # d/ds G(Phi_s x0, Phi_s x0) = 2 int T_xx(r, r) xi' dx with T_xx(u, v) = (u'v' - m^2 u v)/2 and r = G(., x0)
    Ld, md, x0 = 6.0, 0.8, 2.2
    Gd = lambda x, y_: math.sinh(md * min(x, y_)) * math.sinh(md * (Ld - max(x, y_))) / (md * math.sinh(md * Ld))
    dGd = lambda x: (Gd(x + 1e-6, x0) - Gd(x - 1e-6, x0)) / 2e-6
    xi, dxi = (lambda x: math.sin(math.pi * x / Ld)), (lambda x: math.pi / Ld * math.cos(math.pi * x / Ld))
    Tx = lambda x: 0.5 * (dGd(x) ** 2 - md * md * Gd(x, x0) ** 2)
    rhs_d = 2 * (quad(lambda x: Tx(x) * dxi(x), 0, x0, epsabs=1e-12)[0] + quad(lambda x: Tx(x) * dxi(x), x0, Ld, epsabs=1e-12)[0])
    lhs_d = xi(x0) * (Gd(x0 + 1e-5, x0 + 1e-5) - Gd(x0 - 1e-5, x0 - 1e-5)) / 2e-5
    deform = abs(lhs_d - rhs_d) / abs(lhs_d)
    # canary: with the opposite sign convention for the deformation tensor the formula fails
    deform_canary = abs(lhs_d + rhs_d) / abs(lhs_d)
    ok = deform < 1e-6 and deform_canary > 1 and iso < 1e-10 and non_iso > 1e-4 and hf < 1e-6 and killing < 1e-9 and nonstat > 1e-3 and energy_pres < 1e-10 \
        and hole_dim == 4 and inv < 1e-9 and zero_count == 4
    must(ok, 'GL')
    R['GL'] = dict(claim='Placement of general relativity as isometry transport. An isometry of the static structure moves the detector '
                         'without changing the health spectrum; away from isometry the rate is the Hellmann-Feynman expression '
                         'd lambda = v^T (dF - lambda dH) v, with dH the stress bilinear contracted with the deformation tensor '
                         '(Lie derivative of the metric); the deformation formula for the Green matrix is checked in closed form in '
                         'one dimension. In phase space the Killing time flow preserves the energy form, so shifting '
                         'the observation window leaves the spectrum invariant. The hole is the Kalman unobservable subspace and is '
                         'flow invariant (a symmetric chain observed at its centre has a 4-dimensional hole). Canaries: a non-uniform '
                         'conformal factor and a time-dependent stiffness both break invariance.',
                   status='PROVED (isometry covariance) + IDENTIFIED (Kalman) + canaries', isometry_spectrum_shift=fl(iso), deformation_formula_rel_err=fl(deform), deformation_rate=fl(lhs_d),
                   non_isometry_shift=fl(non_iso), hellmann_feynman_err=fl(hf), killing_time_shift=fl(killing),
                   time_dependent_shift=fl(nonstat), energy_form_preserved=fl(energy_pres), kalman_hole_dim=hole_dim,
                   hole_flow_invariance=fl(inv), zero_pencil_eigenvalues=zero_count)


# ============================================================================================  GM
def GM():
    # Lorentzian (action) Hessian on a small spacetime grid: -d_t^2 + d_x^2 form is indefinite
    nt, nx = 6, 6
    Dt = chain(np.ones(nt - 1)); Dx = chain(np.ones(nx - 1)) + 0.2 * np.eye(nx)
    Hl = -np.kron(Dt, np.eye(nx)) + np.kron(np.eye(nt), Dx)
    sig = np.linalg.eigvalsh(Hl); neg, pos = int(np.sum(sig < -1e-12)), int(np.sum(sig > 1e-12))
    if neg == 0 or pos == 0:                                          # the wall needs an indefinite form
        must(False, 'GM'); R['GM'] = dict(claim='not indefinite', status='FAILED'); return
    # an H-null vector b: the "orthocomplement" of span(b) contains b, so there is no resolved/null split
    w, Q = np.linalg.eigh(Hl); i, j = int(np.argmin(w)), int(np.argmax(w))
    vnull = Q[:, i] / math.sqrt(-w[i]) + Q[:, j] / math.sqrt(w[j])
    null_norm = float(vnull @ Hl @ vnull)
    # detector whose representer is null: b = H v; then G = b^T H^-1 b = v^T H v = 0 and P_R does not exist
    bdet = Hl @ vnull; Gdeg = float(bdet @ np.linalg.solve(Hl, bdet))
    # the pencil of that detector is nilpotent (a Jordan block): there is no resolved eigenvector at all
    Nil = np.linalg.solve(Hl, np.outer(bdet, bdet))
    nil0, nil2 = float(np.max(np.abs(Nil))), float(np.max(np.abs(Nil @ Nil)))
    # generic detectors: relative eigenvalues are real (F >= 0) but take both signs: "information per energy" is negative
    negs = 0
    for _ in range(20):
        Bm = rng.normal(size=(8, nt * nx)); ev = np.linalg.eigvals(np.linalg.solve(Hl, Bm.T @ Bm))
        big = ev[np.abs(ev) > 1e-8 * np.max(np.abs(ev))]
        negs = max(negs, int(np.sum(big.real < 0))); imag = float(np.max(np.abs(big.imag)) / np.max(np.abs(big)))
    # the static energy form on the same spatial grid is positive: the split exists
    pos_def = bool(np.min(np.linalg.eigvalsh(Dx)) > 0)
    ok = neg > 0 and pos > 0 and abs(null_norm) < 1e-10 and abs(Gdeg) < 1e-9 and nil0 > 1e-3 and nil2 < 1e-9 * nil0 and negs > 0 \
        and imag < 1e-8 and pos_def
    must(ok, 'GM')
    R['GM'] = dict(claim='Lorentzian wall. The Hessian of a Lorentzian action is indefinite. Then there are detectors whose representer is '
                         'null (G = 0, no projector; the pencil is a nilpotent Jordan block), and generic detectors have real relative '
                         'eigenvalues of both signs: no orthogonal resolved/null split and no ordering by information per energy exists. General relativity therefore enters the positive slot through the Killing energy '
                         'of a stationary region, or its phase-space Hamiltonian; horizons, ergoregions and non-stationary backgrounds '
                         'are walls where a positive form must be declared (a state or a slicing).',
                   status='PROVED (counterexample)', negative_directions=neg, positive_directions=pos, null_vector_norm=fl(null_norm),
                   degenerate_gram=fl(Gdeg), nilpotent_size=fl(nil0), nilpotent_square=fl(nil2), max_negative_eigenvalues=negs, static_energy_positive=pos_def)


# ============================================================================================  GN
def GN():
    rs = s.symbols('r', positive=True)
    # null densities: rho_l = radial Laplacian of psi_l with psi_l = r^l (r (1 - r))^4 supported in the unit ball
    exact = []
    for l in range(0, 5):
        psi = rs ** l * (rs * (1 - rs)) ** 4
        lap = s.diff(psi, rs, 2) + 2 / rs * s.diff(psi, rs) - l * (l + 1) / rs ** 2 * psi
        exact.append(s.simplify(s.integrate(lap * rs ** (l + 2), (rs, 0, 1))))
    # canary: a density that is not a Laplacian of a compactly supported function has a nonzero moment
    can = s.integrate(rs ** 2 * (1 - rs) * rs ** 2, (rs, 0, 1))
    # resolution law: potential coefficient at radius Rd of unit-ball sources: Phi_l(Rd) = Q_l / Rd^(l+1) (G = 1)
    nr = 400; rr = (np.arange(nr) + 0.5) / nr; dr_ = 1.0 / nr
    laws = {}
    for Rd in (1.5, 3.0):
        sv = []
        for l in range(0, 9):
            row = 4 * np.pi / (2 * l + 1) * rr ** (l + 2) * dr_ / Rd ** (l + 1)   # one exterior coefficient per l
            sv.append(float(np.linalg.norm(row) / math.sqrt(dr_)))
        closed = [4 * math.pi / ((2 * l + 1) * math.sqrt(2 * l + 5) * Rd ** (l + 1)) for l in range(0, 9)]
        slope = np.polyfit(np.arange(4, 9), np.log(np.array(sv[4:9]) * np.array([(2 * l + 1) * math.sqrt(2 * l + 5) for l in range(4, 9)])), 1)[0]
        laws[str(Rd)] = dict(log_slope=fl(slope), predicted=fl(-math.log(Rd)), closed_form_rel_err=fl(max(abs(a_ / b_ - 1) for a_, b_ in zip(sv, closed))))
    # balayage: among radial sources in the unit ball with total mass 1, the field energy int |grad Phi|^2 is least for the
    # surface layer; the L2-least source is the uniform (harmonic, l = 0) density. Two complements of the same hole.
    def field_energy(rho):
        m = np.cumsum(4 * np.pi * rr ** 2 * rho * dr_)               # enclosed mass at shell outer edges
        inside = float(np.sum(m ** 2 / (4 * np.pi * (rr + 0.5 * dr_) ** 2) * dr_))
        return inside + m[-1] ** 2 / (4 * np.pi)                       # exterior part: M^2 / (4 pi * 1)
    shell = np.zeros(nr); shell[-1] = 1 / (4 * np.pi * rr[-1] ** 2 * dr_)
    uniform = np.full(nr, 3 / (4 * np.pi)); peaked = np.exp(-(rr / 0.3) ** 2); peaked /= np.sum(4 * np.pi * rr ** 2 * peaked * dr_)
    E_sh, E_un, E_pk = field_energy(shell), field_energy(uniform), field_energy(peaked)
    l2 = lambda rho: float(np.sum(4 * np.pi * rr ** 2 * rho ** 2 * dr_))
    ok = all(e == 0 for e in exact) and can != 0 and all(abs(v['log_slope'] - v['predicted']) < 1e-3 and v['closed_form_rel_err'] < 1e-3 for v in laws.values()) \
        and E_sh < E_un < E_pk and l2(uniform) < l2(peaked) and l2(uniform) < l2(shell)
    must(ok, 'GN')
    R['GN'] = dict(claim='The hole of gravity\'s own exterior measurement (Newtonian). Densities rho = Laplacian(psi) with psi supported '
                         'in the body have vanishing exterior multipoles (exact for l = 0..4): the hole is infinite-dimensional. '
                         'Singular values of the exterior map are 4 pi (a/R)^(l+1)/((2l+1) sqrt(2l+5)) in L2 source norm, so the number '
                         'of resolved multipoles is about ln(SNR)/ln(R/a). Complement relativity made concrete: the field-energy complement of the hole is the '
                         'boundary layer (balayage; least field energy), the L2 complement is the harmonic density (uniform for '
                         'l = 0). Canary: a generic density has nonzero moment.',
                   status='PROVED (exact) + IDENTIFIED (inverse potential theory, balayage)', null_density_moments=[str(e) for e in exact],
                   canary_moment=str(can), resolution_law=laws, field_energy_shell=fl(E_sh), field_energy_uniform=fl(E_un),
                   field_energy_peaked=fl(E_pk), l2_uniform=fl(l2(uniform)), l2_shell=fl(l2(shell)))


# ============================================================================================  GO
def tov_profile(rho_of_r, Rs):
    """Given an energy-density profile rho(r) on [0, Rs], integrate mass outward and pressure inward from p(Rs) = 0."""
    mfun = lambda r_: quad(lambda x: 4 * np.pi * x * x * rho_of_r(x), 0, r_, epsabs=1e-13, epsrel=1e-12)[0]
    Mtot = mfun(Rs)
    def rhs(r_, p):
        m = mfun(r_); return [-(rho_of_r(r_) + p[0]) * (m + 4 * np.pi * r_ ** 3 * p[0]) / (r_ * (r_ - 2 * m))]
    sol = solve_ivp(rhs, [Rs, 1e-6 * Rs], [0.0], rtol=1e-10, atol=1e-14)
    return Mtot, float(sol.y[0, -1])


def GO():
    Mt = 1.0
    # interior 1: uniform density, radius 6; interior 2: parabolic density, radius 9; both tuned to total mass 1
    R1 = 6.0; rho1 = lambda x: 3 * Mt / (4 * np.pi * R1 ** 3)
    R2 = 9.0; c2 = Mt / (4 * np.pi * R2 ** 3 * (1 / 3 - 1 / 5)); rho2 = lambda x: c2 * (1 - (x / R2) ** 2)
    M1, pc1 = tov_profile(rho1, R1); M2, pc2 = tov_profile(rho2, R2)
    pc_exact = rho1(0) * (math.sqrt(1 - 2 * Mt / R1) - 1) / (1 - 3 * math.sqrt(1 - 2 * Mt / R1))  # Schwarzschild interior solution
    # exterior data: g_tt at r >= 9 depends on M only
    ext = [abs((1 - 2 * M1 / x) - (1 - 2 * M2 / x)) for x in (9.0, 20.0, 100.0)]
    # rank of the exterior map on density perturbations: one (mass functional, linear in rho)
    basis = [lambda x, k=k: math.cos(k * math.pi * x / R1) for k in range(6)]
    Jrow = np.array([quad(lambda x: 4 * np.pi * x * x * b(x), 0, R1)[0] for b in basis])
    rank = int(np.linalg.matrix_rank(np.vstack([Jrow * (-2 / x) for x in (9.0, 20.0, 100.0, 500.0)])))
    # Buchdahl wall canary: uniform star with R -> 9M/4 has diverging central pressure
    pcs = []
    for Rb in (3.0, 2.4, 2.26):
        rb = 3 * Mt / (4 * np.pi * Rb ** 3)
        pcs.append(rb * (math.sqrt(1 - 2 * Mt / Rb) - 1) / (1 - 3 * math.sqrt(1 - 2 * Mt / Rb)))
    ok = abs(M1 - Mt) < 1e-10 and abs(M2 - Mt) < 1e-10 and max(ext) < 1e-10 and abs(pc1 / pc_exact - 1) < 1e-5 \
        and abs(pc1 / pc2 - 1) > 0.2 and rank == 1 and pcs[2] > 20 * pcs[0]
    must(ok, 'GO')
    R['GO'] = dict(claim='The hole of the exterior measurement in full general relativity (spherical symmetry). The Misner-Sharp mass '
                         'M = int 4 pi r^2 rho dr is linear in the energy density, and by Birkhoff the exterior is Schwarzschild with '
                         'that M alone. Two equilibrium interiors (uniform, radius 6M; parabolic, radius 9M) have identical exterior '
                         'data and different central pressures; the exterior Jacobian on density perturbations has rank 1. The hole is '
                         '{d rho : int r^2 d rho dr = 0} inside the admissible cone. Wall canary: the central pressure of the uniform '
                         'star diverges at the Buchdahl radius 9M/4.',
                   status='PROVED (Birkhoff, TOV) + computed', mass_1=fl(M1), mass_2=fl(M2), exterior_difference=fl(max(ext)),
                   central_pressure_uniform=fl(pc1), central_pressure_uniform_exact=fl(pc_exact), central_pressure_parabolic=fl(pc2),
                   exterior_jacobian_rank=rank, buchdahl_central_pressures=[fl(p) for p in pcs])


# ============================================================================================  GP
def centre_dim(X_size, group_elems, act):
    """Dimension of the centre of the convolution algebra of the action groupoid X x G (arrows (g, x): x -> g.x)."""
    arrows = [(gi, x) for gi in range(len(group_elems)) for x in range(X_size)]
    index = {a: i for i, a in enumerate(arrows)}
    d = len(arrows)
    # structure constants: (g, y) * (h, x) = (g h, x) if y = h.x else 0
    Tm = np.zeros((d, d, d))
    for (gi, y) in arrows:
        for (hi, x) in arrows:
            if act(hi, x) == y:
                k = compose(gi, hi)
                Tm[index[(gi, y)], index[(hi, x)], index[(k, x)]] = 1.0
    # centre: z with z*a = a*z for all basis a
    rows = []
    for a in range(d):
        La = Tm[:, a, :].T - Tm[a, :, :].T          # (z*e_a - e_a*z)_k = sum_z z_i (T[i,a,k] - T[a,i,k])
        rows.append(La)
    Mx = np.vstack(rows)
    return d - int(np.linalg.matrix_rank(Mx, tol=1e-9))


def compose(gi, hi):
    return _COMPOSE[gi][hi]


_COMPOSE = None


def GP():
    global _COMPOSE
    # free action: N = ker B acting by translation on V = Z_3^2, B = (1 1) mod 3; quotient = image of B (3 points)
    V = [(a, b) for a in range(3) for b in range(3)]
    Nn = [v for v in V if (v[0] + v[1]) % 3 == 0]                    # the hole: 3 elements
    _COMPOSE = [[Nn.index(((g[0] + h_[0]) % 3, (g[1] + h_[1]) % 3)) for h_ in Nn] for g in Nn]
    act = lambda gi, x: V.index(((V[x][0] + Nn[gi][0]) % 3, (V[x][1] + Nn[gi][1]) % 3))
    free_centre = centre_dim(len(V), Nn, act)
    data_values = len({(v[0] + v[1]) % 3 for v in V})
    alg_dim = len(V) * len(Nn)                                       # = sum over orbits of |N|^2 = 3 * 9
    # non-free canary: Z_2 acting on a 3-point set with one fixed point: orbits = 2, centre = 3 (stabilizer representation)
    _COMPOSE = [[0, 1], [1, 0]]
    act2 = lambda gi, x: x if gi == 0 else [1, 0, 2][x]
    nonfree_centre = centre_dim(3, [0, 1], act2)
    ok = free_centre == data_values == 3 and alg_dim == data_values * len(Nn) ** 2 and nonfree_centre == 3
    must(ok, 'GP')
    R['GP'] = dict(claim='Bottom-up groupoid meets top-down quotient (finite witness of the Morita statement). The hole acts on field space '
                         'by translation; the action is free. The convolution algebra of the action groupoid is then a sum of full '
                         'matrix blocks of size |N|, one per orbit, so its centre is the function algebra of the quotient V/N = image '
                         'of B (3 = 3). In the continuum this is C*(V x N) Morita equivalent to C_0(V/N) (Rieffel, Green: imported). '
                         'Canary: a non-free action (a fixed point) has a centre larger than the orbit count (3 > 2): at walls the '
                         'quotient alone is not enough, stabilizer representations appear.',
                   status='PROVED (finite) + IMPORTED (continuum Morita equivalence)', centre_dim_free=free_centre, data_values=data_values,
                   algebra_dim=alg_dim, centre_dim_nonfree=nonfree_centre, orbits_nonfree=2)


# ============================================================================================  GQ
def GQ():
    n = 15; H = spd(n); B = rng.normal(size=(4, n)); sig = np.array([1.0, 0.5, 2.0, 1.5])
    F = B.T @ np.diag(1 / sig) @ B
    lam = pencil(F, H)[0]
    bnew = rng.normal(size=(1, n)); F2 = F + bnew.T @ bnew / 0.8
    lam2 = pencil(F2, H)[0]
    refine = float(np.min(lam2[:5] - np.append(lam[:4], 0.0)))
    # coarse-graining y' = A y lowers the spectrum (data processing)
    Am = rng.normal(size=(2, 4)); Sig = np.diag(sig)
    F3 = B.T @ Am.T @ np.linalg.inv(Am @ Sig @ Am.T) @ Am @ B
    lam3 = pencil(F3, H)[0]
    coarse = float(np.max(lam3[:4] - lam[:4]))
    psd = float(np.min(np.linalg.eigvalsh(F - F3)))
    # W_obs monotone under added constraints
    phi = rng.normal(size=n)
    W = lambda Bm: 0.5 * (P_R(H, Bm) @ phi) @ H @ (P_R(H, Bm) @ phi)
    w1, w2 = W(B), W(np.vstack([B, bnew]))
    # canary: adding correlated noise (not a refinement) can lower the spectrum
    ok = refine > -1e-10 and coarse < 1e-10 and psd > -1e-10 and w2 >= w1 - 1e-12 and lam2[4] > 1e-6
    must(ok, 'GQ')
    R['GQ'] = dict(claim='Monotonicity under the Blackwell order. Adding an independent detector row raises every relative eigenvalue '
                         '(Weyl) and enlarges the resolved sector; coarse-graining the data lowers the Fisher form and every eigenvalue '
                         '(data processing); W_obs rises under added constraints. The health vector is therefore a monotone functor of '
                         'the experiment, not a property of a chosen grid.',
                   status='PROVED (Weyl, data processing)', min_refinement_gain=fl(refine), max_coarse_gain=fl(coarse),
                   fisher_difference_min_eig=fl(psd), W_before=fl(w1), W_after=fl(w2))


if __name__ == '__main__':
    for fn in [GA, GB, GC, GD, GE, GF, GG, GH, GI, GJ, GK, GL, GM, GN, GO, GP, GQ]:
        fn(); print(fn.__name__, flush=True)
    R['source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    R['seed'] = SEED
    R['failures'] = FAILS
    (HERE / 'rg_gr_automation_results.json').write_text(json.dumps(R, indent=1, sort_keys=True, default=str) + '\n')
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
