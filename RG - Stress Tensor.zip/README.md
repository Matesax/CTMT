# RG - Stress Tensor: battery ST01-ST11

    python3 rg_stress_attack.py --figs figs   # exact SymPy curvature + numerics (~1-2 min)
    python3 rg_stress_attack.py --canary      # curvature-as-stress; wrong charge; overclaimed forgetting rate

11/11 on seeds 20261025, 1, 42, 777, 2026; canary 3/3.
Tensor descent; vacuum no-go (Schwarzschild T=0, Kretschmann 48M^2/r^6); RN geometry = Maxwell stress (two routes);
FLRW radiation/dust routes; scalar vs stiff-fluid correspondence; radiation correspondence {S PSD, tr S = eps};
l<=2 minimal angular panel; C^2 derivative no-go; exact forgetting certificate (1-s)^n; Lambda convention.
