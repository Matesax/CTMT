#!/usr/bin/env python3
"""
RG stress tensor: battery ST01-ST11 (exact symbolic GR where possible)
=====================================================================
Target: T_{mu nu} as an RG task. Two independent routes:
  geometric route  g -> Einstein tensor / 8 pi   (needs a resolved metric to second order + the field equation, imported)
  source route     direct field or kinetic stress (Maxwell stress; T^{ab} = int p^a p^b f dPi)
Their agreement is the field equation as a consilience test; their disagreement localizes the failing assumption.

  ST01 independent Einstein tensor (Christoffel -> Riemann -> Ricci -> Einstein) for the static spherical family
  ST02 Schwarzschild: curvature (Kretschmann 48 M^2/r^6) with T = 0 -> curvature scalars are not stress (canary for
       mapping Fisher/coherence/curvature scalars to T_00)
  ST03 two routes agree: Reissner-Nordstrom geometry gives eps = Q^2/(8 pi r^4), p_r = -eps, p_perp = +eps; the Maxwell
       stress of the Coulomb field E = Q/r^2 gives the same tensor; a wrong charge is INCONSISTENT
  ST04 FLRW: geometric route eps = 3H^2/8pi, p = -(2Hdot+3H^2)/8pi; source routes (kinetic radiation, dust) agree for
       alpha = 1/2, 2/3 and are INCONSISTENT when swapped; conservation holds identically
  ST05 source non-uniqueness: a massless scalar and a stiff fluid give the same (eps, p) -> CORRESPONDENCE on the source
  ST06 energy does not determine stress: the exact correspondence set for radiation of energy eps is
       {S PSD, tr S = eps} (every member realized by six beams; Caratheodory)
  ST07 minimal angular panel: radiation stress depends only on the l <= 2 harmonics of the intensity; l >= 3 is in the
       kernel of the stress map
  ST08 derivative no-go: metric perturbations with sup -> 0 can carry stress -> infinity; stress needs a C^2 certificate
  ST09 forgetting certificate: under isotropic rescattering with probability s the stress anisotropy decays exactly as
       (1-s)^n uniformly over ALL declared direction laws; the beam attains the bound (bounded functional)
  ST10 Lambda bookkeeping: geometric-side and source-side conventions give identical equations; the convention must be
       declared (correspondence of descriptions, not of physics)
  ST11 status: T LOCKED conditional on the listed route assumptions in the two-route examples; CORRESPONDENCE where
       the source or the directional moments are not resolved

Run:  python3 rg_stress_attack.py [--seed 20261025] [--out FILE] [--figs DIR] [--canary]
"""
import argparse, json, math, sys, time
import numpy as np
import sympy as sp

RESULTS, MUT, FIG = [], {}, {}


def f_(x): return float(np.round(float(x), 12))


def register(aid, naive, keep, passed, ev, verdict):
    RESULTS.append(dict(id=aid, naive_claim=naive, rg_claim=keep, passed=bool(passed), verdict=verdict, evidence=ev))
    print(f"[{'PASS' if passed else 'FAIL'}] {aid} {verdict:16s} {keep[:84]}")


# ------------------------------------------------------------------ exact curvature
def einstein_mixed(g, X):
    n = len(X); gi = g.inv()
    Gam = [[[sp.simplify(sum(gi[a, d]*(sp.diff(g[d, b], X[c])+sp.diff(g[d, c], X[b])-sp.diff(g[b, c], X[d])) for d in range(n))/2)
             for c in range(n)] for b in range(n)] for a in range(n)]
    def Riem(a, b, c, d):
        return sp.diff(Gam[a][b][d], X[c])-sp.diff(Gam[a][b][c], X[d])+sum(Gam[a][c][e]*Gam[e][b][d]-Gam[a][d][e]*Gam[e][b][c] for e in range(n))
    Ric = sp.Matrix(n, n, lambda b, d: sp.simplify(sum(Riem(a, b, a, d) for a in range(n))))
    R = sp.simplify(sum(gi[a, b]*Ric[a, b] for a in range(n) for b in range(n)))
    G = sp.simplify(gi*(Ric-R*g/2))                                                 # G^a_b
    return G, Ric, R, Gam, Riem


t, r, th, ph, M, Q, al, Lam = sp.symbols("t r theta phi M Q alpha Lambda", positive=True)
X = [t, r, th, ph]


def static_metric(f):
    return sp.diag(-f, 1/f, r**2, r**2*sp.sin(th)**2)


def ST01(rng):
    fs = sp.Function("f")(r); G, *_ = einstein_mixed(static_metric(fs), X)
    e_tt = sp.simplify(G[0, 0]-(r*sp.diff(fs, r)+fs-1)/r**2); e_rr = sp.simplify(G[1, 1]-(r*sp.diff(fs, r)+fs-1)/r**2)
    e_th = sp.simplify(G[2, 2]-(sp.diff(fs, r, 2)/2+sp.diff(fs, r)/r))
    off = all(sp.simplify(G[i, j]) == 0 for i in range(4) for j in range(4) if i != j)
    passed = e_tt == 0 and e_rr == 0 and e_th == 0 and off
    register("ST01", "The geometric route is taken from the literature on trust.",
             "Computed independently (Christoffel -> Riemann -> Ricci -> Einstein, exact): G^t_t = G^r_r = (r f' + f - 1)/r^2, "
             "G^theta_theta = G^phi_phi = f''/2 + f'/r, off-diagonal zero, for every static spherical f(r).", passed,
             dict(residuals=[str(e_tt), str(e_rr), str(e_th)], off_diagonal_zero=bool(off)), "HOLDS")


def ST02(rng):
    f = 1-2*M/r; G, Ric, R, Gam, Riem = einstein_mixed(static_metric(f), X)
    Tzero = all(sp.simplify(G[i, j]) == 0 for i in range(4) for j in range(4))
    g = static_metric(f); gi = g.inv()
    # Kretschmann R_abcd R^abcd via mixed form R^a_bcd R_a^bcd
    K = 0
    for a in range(4):
        for b in range(4):
            for c in range(4):
                for d in range(4):
                    Rabcd = Riem(a, b, c, d)
                    if Rabcd == 0: continue
                    K += Rabcd**2*g[a, a]*gi[b, b]*gi[c, c]*gi[d, d]
    K = sp.simplify(K)
    curvature_to_stress = (K != 0) and Tzero
    if MUT.get("st02_curvature_energy"): Tzero = False
    passed = Tzero and sp.simplify(K-48*M**2/r**6) == 0
    register("ST02", "Resolved curvature (or a Fisher/coherence scalar) is a local energy density.",
             "Schwarzschild exterior: every component of G^a_b vanishes while the Kretschmann scalar is 48 M^2/r^6. Tidal "
             "(Weyl) curvature is not stress; only the Ricci part is. Mapping a curvature or Fisher scalar to T_00 is "
             "falsified by the vacuum.", passed, dict(einstein_tensor_zero=bool(Tzero), kretschmann=str(K)), "FALSIFIED-naive")


def ST03(rng):
    m = M-Q**2/(2*r); f = 1-2*m/r; G, *_ = einstein_mixed(static_metric(f), X)
    Tgeo = sp.simplify(G/(8*sp.pi))                                                  # T^a_b from geometry
    eps_g, pr_g, pp_g = sp.simplify(-Tgeo[0, 0]), sp.simplify(Tgeo[1, 1]), sp.simplify(Tgeo[2, 2])
    # source route: Maxwell stress of the Coulomb field (Gaussian, geometrized): E = Q/r^2 in the orthonormal frame
    Qs = Q if not MUT.get("st03_wrong_charge") else 1.1*Q
    E = Qs/r**2; eps_s = E**2/(8*sp.pi); pr_s = -E**2/(8*sp.pi); pp_s = E**2/(8*sp.pi)
    agree = all(sp.simplify(a-b) == 0 for a, b in ((eps_g, eps_s), (pr_g, pr_s), (pp_g, pp_s)))
    wrongE = (1.1*Q)/r**2; inconsistent_wrong = sp.simplify(eps_g-wrongE**2/(8*sp.pi)) != 0
    passed = agree and inconsistent_wrong
    register("ST03", "A stress tensor read off a metric is unfalsifiable bookkeeping.",
             "Two independent routes, one tensor: the Reissner-Nordstrom geometry gives eps = Q^2/(8 pi r^4), p_r = -eps, "
             "p_perp = +eps; the Maxwell stress of the Coulomb field E = Q/r^2, computed without any metric derivative, gives "
             "exactly the same. A source declared with 10% more charge is INCONSISTENT: the field equation is a testable "
             "consilience between routes.", passed,
             dict(geometric=[str(eps_g), str(pr_g), str(pp_g)], source=[str(eps_s), str(pr_s), str(pp_s)], routes_agree=bool(agree),
                  wrong_charge_inconsistent=bool(inconsistent_wrong)), "FALSIFIED-naive")


def ST04(rng):
    a = t**al; g = sp.diag(-1, a**2, a**2, a**2); Xc = [t]+list(sp.symbols("x y z"))
    G, *_ = einstein_mixed(g, Xc); H = sp.diff(a, t)/a
    eps = sp.simplify(-G[0, 0]/(8*sp.pi)); p = sp.simplify(G[1, 1]/(8*sp.pi))
    e1 = sp.simplify(eps-3*H**2/(8*sp.pi)); e2 = sp.simplify(p+(2*sp.diff(H, t)+3*H**2)/(8*sp.pi))
    w = sp.simplify(p/eps); cons = sp.simplify(sp.diff(eps, t)+3*H*(eps+p))
    # source routes: kinetic radiation (isotropic massless: T^ij = eps/3 delta) and dust (cold: T^ij = 0)
    w_rad = sp.Rational(1, 3); w_dust = 0
    agree_rad = sp.simplify(w.subs(al, sp.Rational(1, 2))-w_rad) == 0
    agree_dust = sp.simplify(w.subs(al, sp.Rational(2, 3))-w_dust) == 0
    swapped = sp.simplify(w.subs(al, sp.Rational(2, 3))-w_rad) != 0
    passed = e1 == 0 and e2 == 0 and cons == 0 and agree_rad and agree_dust and swapped
    register("ST04", "Cosmological sources are fitted labels for an expansion history.",
             "Geometric route on FLRW, a = t^alpha: eps = 3H^2/8pi, p = -(2Hdot+3H^2)/8pi, w = 2/(3 alpha) - 1, with energy "
             "conservation identically zero. Independent kinetic source routes agree (radiation w = 1/3 at alpha = 1/2; dust "
             "w = 0 at alpha = 2/3) and the swapped assignment is INCONSISTENT.", passed,
             dict(w=str(w), conservation_residual=str(cons), radiation_agrees=bool(agree_rad), dust_agrees=bool(agree_dust),
                  swapped_inconsistent=bool(swapped)), "FALSIFIED-naive")


def ST05(rng):
    a = t**sp.Rational(1, 3); H = sp.diff(a, t)/a; Hd = sp.diff(H, t)
    phid2 = sp.simplify(-Hd/(4*sp.pi)); V = sp.simplify((3*H**2+Hd)/(8*sp.pi))
    phi = sp.log(t)/sp.sqrt(12*sp.pi); kg = sp.simplify(sp.diff(phi, t, 2)+3*H*sp.diff(phi, t))
    eps_scalar = sp.simplify(sp.diff(phi, t)**2/2); p_scalar = eps_scalar
    eps_stiff = sp.simplify(3*H**2/(8*sp.pi)); p_stiff = eps_stiff
    same = sp.simplify(eps_scalar-eps_stiff) == 0 and sp.simplify(p_scalar-p_stiff) == 0
    passed = V == 0 and kg == 0 and same and sp.simplify(phid2-sp.diff(phi, t)**2) == 0
    register("ST05", "A reconstructed background identifies its source.",
             "It identifies (eps, p), not the source: at alpha = 1/3 a massless scalar phi = log(t)/sqrt(12 pi) (V = 0, field "
             "equation residual 0) and a stiff fluid give the same tensor. The source is a CORRESPONDENCE until another "
             "observable (perturbations, sound speed, couplings) separates them.", passed,
             dict(V=str(V), klein_gordon_residual=str(kg), scalar_equals_stiff=bool(same)), "FALSIFIED-naive")


def ST06(rng):
    eps = 1.0; iso = np.eye(3)/3*eps; beams = np.diag([1.0, 0, 0])*eps
    # correspondence set: random direction laws -> T PSD, trace eps
    ok_members = True
    for _ in range(500):
        n = rng.normal(size=(rng.integers(1, 30), 3)); n /= np.linalg.norm(n, axis=1)[:, None]; w = rng.dirichlet(np.ones(len(n)))
        T = eps*np.einsum("k,ki,kj->ij", w, n, n); ev = np.linalg.eigvalsh(T)
        ok_members &= ev.min() > -1e-12 and abs(np.trace(T)-eps) < 1e-12
    # every PSD trace-eps S is realized by six beams along its eigenvectors (Caratheodory)
    worst = 0.0
    for _ in range(500):
        A = rng.normal(size=(3, 3)); S = A@A.T; S *= eps/np.trace(S); lam, U = np.linalg.eigh(S)
        dirs = np.vstack([U.T, -U.T]); wts = np.concatenate([lam, lam])/(2*eps)
        Tr = eps*np.einsum("k,ki,kj->ij", wts, dirs, dirs); worst = max(worst, np.max(np.abs(Tr-S)))
    passed = ok_members and worst < 1e-12 and np.max(np.abs(iso-beams)) > 0.5
    register("ST06", "Energy density determines the stress (one energy coordinate suffices).",
             "No: isotropic radiation and counter-propagating beams share energy and zero flux but differ in stress. The exact "
             "RG correspondence for radiation of energy eps is {S positive semidefinite, tr S = eps}: every random direction law "
             "lands in it, and every member is realized by six beams on its eigenvectors (error < 1e-12).", passed,
             dict(isotropic_minus_beams_max=f_(np.max(np.abs(iso-beams))), members_ok=bool(ok_members), realization_error=f_(worst)),
             "FALSIFIED-naive")


def fib_sphere(N):
    k = np.arange(N)+0.5; z = 1-2*k/N; phi = np.pi*(1+5**0.5)*k; s = np.sqrt(1-z*z)
    return np.c_[s*np.cos(phi), s*np.sin(phi), z]


def ST07(rng):
    from scipy.special import sph_harm_y
    N = 200000; n = fib_sphere(N); thv = np.arccos(n[:, 2]); phv = np.arctan2(n[:, 1], n[:, 0])
    def Ylm_real(l, m):
        Y = sph_harm_y(l, abs(m), thv, phv)
        return np.real(Y) if m >= 0 else np.imag(Y)
    def stress(I): return 4*np.pi*np.einsum("k,ki,kj->ij", I, n, n)/N
    base = 1.0+0.3*Ylm_real(1, 0)+0.2*Ylm_real(2, 1)+0.15*Ylm_real(2, -2)
    T0 = stress(base); dev_high = 0.0
    for l in (3, 4, 5, 6):
        for m in (-l, 0, l):
            dev_high = max(dev_high, np.max(np.abs(stress(base+0.25*Ylm_real(l, m))-T0)))
    dev_l2 = np.max(np.abs(stress(base+0.25*Ylm_real(2, 0))-T0))
    passed = dev_high < 1e-4 and dev_l2 > 1e-2
    register("ST07", "Stress needs the full angular distribution of the radiation.",
             "Only its l <= 2 harmonics: adding l = 3..6 components to the intensity changes the stress by < 1e-4 (quadrature "
             "level), while an l = 2 change moves it by > 1e-2. Harmonics l >= 3 lie in the kernel of the stress map, so the "
             "minimal sufficient angular panel is l <= 2 (monopole, dipole, quadrupole).", passed,
             dict(max_change_from_l3_to_l6=f_(dev_high), change_from_l2=f_(dev_l2)), "FALSIFIED-naive")


def ST08(rng):
    rows = []
    for eta in (1e-1, 1e-2, 1e-3):
        rr = np.linspace(10, 11, 200001); df = eta*np.sin(rr/eta**2)
        d2 = -eta/eta**4*np.sin(rr/eta**2); d1 = eta/eta**2*np.cos(rr/eta**2)
        dpp = np.max(np.abs(d2/2+d1/rr))/(8*np.pi)                        # perturbation of p_perp = G^theta_theta/8pi
        rows.append(dict(eta=eta, sup_metric_perturbation=f_(np.max(np.abs(df))), sup_stress_perturbation=f_(dpp)))
    passed = rows[-1]["sup_metric_perturbation"] < 2e-3 and rows[-1]["sup_stress_perturbation"] > 1e6 and \
        rows[0]["sup_stress_perturbation"] < rows[-1]["sup_stress_perturbation"]
    register("ST08", "If the metric is resolved, the stress is resolved.",
             "Not without derivative control: metric perturbations eta sin(r/eta^2) have sup -> 0 (1e-3) while the induced "
             "stress grows like eta^-3 (above 1e6). The geometric route needs a C^2 certificate at the declared scale, not "
             "metric agreement.", passed, dict(rows=rows), "FALSIFIED-naive")


def ST09(rng):
    s = 0.3; nmax = 12; eps = 1.0
    def evolve(dirs, n_steps, rng_):
        d = dirs.copy()
        for _ in range(n_steps):
            hit = rng_.random(len(d)) < s; k = int(hit.sum())
            if k: v = rng_.normal(size=(k, 3)); d[hit] = v/np.linalg.norm(v, axis=1)[:, None]
        return d
    def T(d): return eps*np.einsum("ki,kj->ij", d, d)/len(d)
    decl = {"beams_x": np.tile([[1, 0, 0], [-1, 0, 0]], (100000, 1)).astype(float),
            "isotropic": (lambda v: v/np.linalg.norm(v, axis=1)[:, None])(rng.normal(size=(200000, 3))),
            "planar": (lambda v: v/np.linalg.norm(v, axis=1)[:, None])(np.c_[rng.normal(size=(200000, 2)), np.zeros(200000)])}
    # exact operator statement (symbolic): E[T_n] = (1-s)^n T_0 + (1 - (1-s)^n) eps I/3 for ANY initial direction law
    ss, nn = sp.symbols("s n", positive=True); T0 = sp.Matrix(3, 3, lambda i, j: sp.Symbol(f"T{i}{j}"))
    step = lambda T: (1-ss)*T+ss*sp.trace(T)/3*sp.eye(3)                          # isotropic redirection keeps energy
    Tn = T0
    for _ in range(4): Tn = step(Tn)
    exact_ok = sp.simplify(Tn-((1-ss)**4*T0+(1-(1-ss)**4)*sp.trace(T0)/3*sp.eye(3))) == sp.zeros(3, 3)
    # Monte Carlo check with a noise-derived tolerance: sd of a stress element ~ sqrt(4/(45 N)); 3 sd added to the bound
    # (first registration used a fixed 1.03 ratio, which ignored MC noise once the bound fell to ~1e-2)
    worst_excess = 0.0; beam_dev = []
    for n_ in (1, 3, 6, 12):
        bound = (2/3)*eps*(1-s)**n_
        for k, d0 in decl.items():
            tol = 3*math.sqrt(4/(45*len(d0)))*3                                       # 3 sd, spectral norm over 3 directions
            dev = np.linalg.norm(T(evolve(d0, n_, np.random.default_rng(n_)))-eps*np.eye(3)/3, 2)
            worst_excess = max(worst_excess, dev-(bound+tol))
            if k == "beams_x": beam_dev.append(dict(n=n_, dev=f_(dev), bound=f_(bound), tol=f_(tol)))
    attains = all(abs(b_["dev"]-b_["bound"]) <= b_["tol"] for b_ in beam_dev)
    passed = exact_ok and worst_excess <= 0 and attains
    if MUT.get("st09_overclaim"):                                                   # canary: claim the faster rate (1-s)^(n+1)
        passed = passed and all(b_["dev"] <= (2/3)*eps*(1-s)**(b_["n"]+1)+b_["tol"] for b_ in beam_dev)
    register("ST09", "Forgetting cannot certify a stress tensor.",
             "It can, for a bounded functional and a declared kernel: under isotropic rescattering with probability s, the "
             "anisotropic stress decays exactly as (1-s)^n, uniformly over all declared direction laws (bound (2/3) eps (1-s)^n "
             "on the deviation from eps/3 I); the operator identity holds symbolically for any initial law, and the beam attains the "
             "bound within Monte Carlo error. Forgetting certifies robustness of the stress; it creates no directional "
             "information.", passed, dict(scatter_probability=s, exact_operator_identity=bool(exact_ok),
                                          worst_excess_over_bound_plus_noise=f_(worst_excess), beam=beam_dev), "FALSIFIED-naive")


def ST10(rng):
    f = 1-2*M/r-Lam*r**2/3; G, *_ = einstein_mixed(static_metric(f), X)
    geom_side = sp.simplify(G+Lam*sp.eye(4))                                          # G + Lambda g (mixed) = 8 pi T, T = 0
    src_side = sp.simplify(G/(8*sp.pi))                                               # G = 8 pi (T_Lambda), T_Lambda = -Lambda/(8pi) delta
    same = all(sp.simplify(geom_side[i, j]) == 0 for i in range(4) for j in range(4)) and \
        all(sp.simplify(src_side[i, i]+Lam/(8*sp.pi)) == 0 for i in range(4))
    passed = same
    register("ST10", "Lambda is unambiguously either geometry or source.",
             "Both conventions solve the same equations exactly (G + Lambda g = 0, or G = 8 pi T_Lambda with eps_Lambda = "
             "Lambda/8pi = -p_Lambda). The choice is a declared convention -- a correspondence of descriptions, not of physics "
             "-- and the stress-tensor certificate must record it.", passed, dict(conventions_equivalent=bool(same)), "HOLDS")


def ST11(rng):
    status = {
        "Reissner-Nordstrom exterior stress": dict(status="LOCKED (conditional)", conditional_on=["Einstein equation",
                    "static spherical ansatz", "metric resolved in C^2", "Maxwell source model", "geometrized Gaussian units"]),
        "flat FLRW (eps, p)": dict(status="LOCKED (conditional)", conditional_on=["Einstein equation", "FLRW ansatz",
                    "a(t) resolved in C^2", "kinetic source model"]),
        "FLRW source identity (scalar vs stiff fluid)": dict(status="CORRESPONDENCE", conditional_on=["(eps, p) only"]),
        "radiation stress from energy density only": dict(status="CORRESPONDENCE", set="{S PSD, tr S = eps}"),
        "radiation stress from l <= 2 intensity moments": dict(status="LOCKED", conditional_on=["massless kinetic model"]),
        "Schwarzschild exterior matter stress": dict(status="LOCKED (conditional)", value="T = 0", conditional_on=["Einstein equation",
                    "Lambda convention"]),
    }
    passed = sum(v["status"].startswith("LOCKED") for v in status.values()) >= 3 and \
        sum(v["status"] == "CORRESPONDENCE" for v in status.values()) >= 2
    register("ST11", "Either RG produces 'the' stress tensor or it produces nothing.",
             "RG produces a typed stress-tensor certificate: LOCKED (conditional) with its listed route assumptions where two "
             "independent routes agree or moments are resolved, and an explicit CORRESPONDENCE set where the source or the "
             "directional moments are not resolved.", passed, dict(certificates=status), "FALSIFIED-naive")


ATTACKS = [ST01, ST02, ST03, ST04, ST05, ST06, ST07, ST08, ST09, ST10, ST11]


def make_figures(d, seed):
    import os, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    os.makedirs(d, exist_ok=True); fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    rr = np.linspace(1.2, 6, 300); Qv, Mv = 0.8, 1.0
    eps = Qv**2/(8*np.pi*rr**4)
    ax[0].plot(rr, eps, label=r"$\epsilon$ (geometric route)"); ax[0].plot(rr, -eps, label=r"$p_r$"); ax[0].plot(rr, eps, "--", label=r"$p_\perp$")
    ax[0].plot(rr[::20], (Qv/rr[::20]**2)**2/(8*np.pi), "ko", ms=3, label="Maxwell stress (source route)")
    ax[0].plot(rr, 0*rr, color="grey", lw=0.8, label="Schwarzschild: T = 0")
    ax[0].set_xlabel("r (geometrized units, M = 1)"); ax[0].set_ylabel("orthonormal components"); ax[0].legend(fontsize=7)
    ax[0].set_title("two routes, one tensor (Reissner-Nordstrom)", fontsize=9)
    s = 0.3; ns = np.arange(0, 13); ax[1].semilogy(ns, (2/3)*(1-s)**ns, "k-", label=r"certified bound $(2/3)\,\epsilon\,(1-s)^n$")
    rng = np.random.default_rng(seed); dirs = np.tile([[1, 0, 0], [-1, 0, 0]], (50000, 1)).astype(float); devs = []
    for n_ in ns:
        devs.append(np.linalg.norm(np.einsum("ki,kj->ij", dirs, dirs)/len(dirs)-np.eye(3)/3, 2))
        hit = rng.random(len(dirs)) < s; v = rng.normal(size=(int(hit.sum()), 3)); dirs[hit] = v/np.linalg.norm(v, axis=1)[:, None]
    ax[1].semilogy(ns, devs, "o", label="beam declaration (simulated)"); ax[1].set_xlabel("scatterings n")
    ax[1].set_ylabel(r"$\|T^{ij}-\epsilon\,\delta^{ij}/3\|$"); ax[1].legend(fontsize=7)
    ax[1].set_title("forgetting certificate for the stress anisotropy", fontsize=9)
    fig.tight_layout(); fig.savefig(f"{d}/st_stress.png", dpi=170); plt.close(fig)


def run_all(seed):
    for a in ATTACKS:
        rng = np.random.default_rng([seed, ATTACKS.index(a)])
        try: a(rng)
        except Exception as ex:
            import traceback; traceback.print_exc(); register(a.__name__, "?", f"EXCEPTION {ex!r}", False, {}, "ERROR")


def canary(seed):
    ok = True
    for tgt, m in (("ST02", {"st02_curvature_energy": True}), ("ST03", {"st03_wrong_charge": True}), ("ST09", {"st09_overclaim": True})):
        RESULTS.clear(); MUT.clear(); MUT.update(m); print(f"--- canary {tgt}: {m}")
        a = next(x for x in ATTACKS if x.__name__ == tgt); a(np.random.default_rng([seed, ATTACKS.index(a)]))
        c = not RESULTS[-1]["passed"]; ok &= c; print(f"    {'CAUGHT' if c else 'NOT CAUGHT'}")
    MUT.clear(); print("CANARY:", "all caught" if ok else "BATTERY TOO WEAK"); return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--seed", type=int, default=20261025)
    ap.add_argument("--out", default="rg_stress_results.json"); ap.add_argument("--figs", default=""); ap.add_argument("--canary", action="store_true")
    a = ap.parse_args()
    if a.canary: sys.exit(canary(a.seed))
    t0 = time.time(); print(f"RG stress tensor battery, seed {a.seed}\n"); run_all(a.seed)
    if a.figs: make_figures(a.figs, a.seed)
    n = sum(r["passed"] for r in RESULTS)
    json.dump(dict(summary=dict(seed=a.seed, n_checks=len(RESULTS), n_pass=n, runtime_s=round(time.time()-t0, 1)), results=RESULTS),
              open(a.out, "w"), indent=2, default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print(f"\n{n}/{len(RESULTS)} pass."); sys.exit(0 if n == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
