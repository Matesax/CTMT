"""Final closure battery for the Observable Orbit-Cone theorem ladder."""
import json
from pathlib import Path
import numpy as np

SEED=20260824
rng=np.random.default_rng(SEED)
base=json.loads(Path('/mnt/data/observable_orbit_cone_attack.json').read_text())
checks=dict(base['checks'])
def add(k,ok,detail,value=None,threshold=None):
 d={'passed':bool(ok),'detail':detail}
 if value is not None:d['value']=float(value)
 if threshold is not None:d['threshold']=float(threshold)
 checks[k]=d

# 1. Cone projectability: distinct fibre representatives must project same cone.
# Latent coordinates (t,x,y,theta,h), projection drops theta,h.
K=12000
ang=rng.uniform(0,2*np.pi,K); t=rng.uniform(.05,2,K)
Cobs=np.column_stack([t,t*np.cos(ang),t*np.sin(ang)])
# Two representative embeddings differ only vertically.
Crep1=np.column_stack([Cobs,rng.normal(size=K),rng.normal(size=K)])
Crep2=np.column_stack([Cobs,rng.normal(size=K),rng.normal(size=K)])
Dpi=np.zeros((3,5)); Dpi[:3,:3]=np.eye(3)
p1=(Dpi@Crep1.T).T; p2=(Dpi@Crep2.T).T
err=np.max(np.abs(p1-p2))
add('cone_projectability_across_full_observation_fibre',err<1e-15,
    'Admissible cones at gauge- and hidden-related representatives have the same observable projection.',err,1e-15)
# Hostile cone with hidden-dependent observable opening fails.
h1=np.ones(K); h2=-np.ones(K)
B1=Cobs.copy(); B2=Cobs.copy(); B1[:,1:]*=1+.15*h1[:,None]; B2[:,1:]*=1+.15*h2[:,None]
gap=np.sqrt(np.mean((B1-B2)**2))
add('hidden_dependent_cone_rejected',gap>.1,
    'A cone whose observable opening depends on silent h cannot descend.',gap,.1)

# 2. Saturated invariants must be constant on completed orbits and separate them.
Q=7; A=5; H=4
states=[(q,a,h) for q in range(Q) for a in range(A) for h in range(H)]
I=lambda x: np.array([x[0],x[0]**2,1.0])
constant=True; distinct=True
for q in range(Q):
 vals=[I(x) for x in states if x[0]==q]
 constant &= all(np.array_equal(vals[0],v) for v in vals)
for q in range(Q):
 for r in range(q+1,Q): distinct &= not np.array_equal(I((q,0,0)),I((r,0,0)))
add('saturated_invariants_factor_through_completed_orbits',constant and distinct,
    'The tested invariant family is constant on completed fibres and separates their orbit classes.')

# 3. Singular-stratum warning: isotropy jump changes orbit dimension, so ordinary tangent quotient rank jumps.
# SO(2) on R2: generic orbit dimension 1, origin orbit dimension 0.
generic_vertical_rank=1; origin_vertical_rank=0
add('isotropy_jump_requires_stratified_tangent_cone',generic_vertical_rank!=origin_vertical_rank,
    'Orbit dimension jumps at the fixed point; a single smooth tangent-bundle quotient is invalid.',
    generic_vertical_rank-origin_vertical_rank,1)

# 4. Strict transport composition and loop consistency select a single global scale mode.
P=50
edges=[(i,i+1) for i in range(P-1)] + [(P-1,0)]
C=np.zeros((len(edges),P))
for k,(i,j) in enumerate(edges):C[k,i]=1;C[k,j]-=1
nullity=P-np.linalg.matrix_rank(C)
add('closed_connected_strict_transport_has_one_scale_mode',nullity==1,
    'Connected loop-compatible strict transport leaves one global logarithmic scale.',nullity,1)
# Add inconsistent edge offset: loop sum detects no global potential.
b=np.zeros(len(edges)); b[-1]=.2
ls=np.linalg.lstsq(C,b,rcond=None)[0]; residual=np.linalg.norm(C@ls-b)
add('scale_holonomy_obstruction_detected',residual>.01,
    'Nonzero accumulated scale around a loop obstructs global representative selection.',residual,.01)

passed=sum(v['passed'] for v in checks.values()); total=len(checks)
out={'seed':SEED,'passed':passed,'total':total,'all_passed':passed==total,
     'base_attack':'observable_orbit_cone_attack.json','checks':checks,
     'final_verdict':{
       'locked_regular_ladder':'Gauge soundness -> kernel-groupoid comparison -> gauge completeness -> saturated orbit separation -> projectable W and cone -> quadratic conformal reconstruction -> integrable scale selection.',
       'singular_extension':'At isotropy/rank jumps replace ordinary tangent quotients by orbit-type strata, slices, and tangent cones.',
       'non_equivalences':['local saturation is not global separation','global orbit separation is not gauge completeness','gauge completeness is not latent reconstruction','cone reconstruction is not metric-scale selection'],
       'common_geometry':'The quotient and completed groupoid agree through the kernel groupoid; their common differential object is the observable horizontal tangent-cone structure TX/ker(Dpi_obs), stratified at singular points.',
       'Wobs':'Wobs is the unique descended basic transport; its admissible values form the descended cone Cobs.',
       'scope':'Synthetic exact-data validation; no empirical physical, GR-dynamical, or noise-recovery claim.'}}
Path('/mnt/data/observable_orbit_cone_final_attack.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({'passed':passed,'total':total,'all_passed':passed==total,'final_verdict':out['final_verdict']},indent=2))
