import json, math, os, warnings
from pathlib import Path
import numpy as np
from netCDF4 import Dataset
from scipy import signal
from scipy.linalg import subspace_angles
from sklearn.decomposition import PCA
from sklearn.neighbors import NearestNeighbors
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

warnings.filterwarnings('ignore')

IN = Path('/mnt/data/H-H1_GWOSC_O4a_16KHZ_R1-1368420352-4096.hdf5')
OUT = Path('/mnt/data')
FS = 16384.0
WIN_S = 4
WIN_N = int(FS * WIN_S)
NPER = 8192
BANDS = [(20,80),(80,300),(300,1000),(1000,2048),(2048,4096),(4096,8192)]
BAND_NAMES = [f'P_{a}_{b}' for a,b in BANDS]
EPS = 1e-300


def as_string(x):
    try:
        return str(x[:])
    except Exception:
        try: return str(x.getValue())
        except Exception: return str(x)


def robust_z(X):
    med = np.nanmedian(X, axis=0)
    mad = np.nanmedian(np.abs(X-med), axis=0)
    scale = 1.4826*mad
    small = scale < 1e-12
    if np.any(small):
        scale[small] = np.nanstd(X[:,small], axis=0) + 1e-12
    return (X-med)/scale, med, scale


def health(evals, thresholds=(1e-2,1e-3,1e-4,1e-6)):
    evals = np.maximum(np.asarray(evals), 0)
    rel = evals / max(evals[0], EPS)
    out = {
        'eigenvalues': evals.tolist(),
        'relative_eigenvalues': rel.tolist(),
        'effective_rank_entropy': float(np.exp(-np.sum((evals/evals.sum())*np.log(np.maximum(evals/evals.sum(), EPS))))),
        'effective_rank_participation': float((evals.sum()**2)/np.sum(evals**2)),
    }
    for t in thresholds:
        r = int(np.sum(rel > t))
        out[f'rank_rel_gt_{t:g}'] = r
        out[f'hole_dim_rel_le_{t:g}'] = int(len(evals)-r)
        out[f'cond_resolved_{t:g}'] = float(evals[0]/max(evals[r-1], EPS)) if r>0 else float('inf')
    return out


def pca_payload(X, names):
    C = np.cov(X, rowvar=False)
    evals, evecs = np.linalg.eigh(C)
    order = np.argsort(evals)[::-1]
    evals, evecs = evals[order], evecs[:,order]
    h = health(evals)
    loadings = []
    for j in range(min(6, evecs.shape[1])):
        comps = sorted([(names[i], float(evecs[i,j])) for i in range(len(names))], key=lambda x: -abs(x[1]))[:6]
        loadings.append({'component': j+1, 'top_loadings': comps})
    return C, evals, evecs, h, loadings

# ---------- Read HDF5 structure and compute features ----------
ds = Dataset(str(IN), 'r')
meta = {k: as_string(ds.groups['meta'].variables[k]) for k in ds.groups['meta'].variables.keys()}
strain = ds.groups['strain'].variables['Strain']
N = strain.shape[0]
duration = float(meta.get('Duration','4096')) if str(meta.get('Duration','')).isdigit() else N/FS
nwin = N // WIN_N
# quality masks are 1Hz arrays of length 4096 for this file
simple = ds.groups['quality'].groups['simple']
dqmask = np.array(simple.variables['DQmask'][:], dtype=np.uint32)
dq_short = [str(x) for x in simple.variables['DQShortnames'][:]]
dq_desc = [str(x) for x in simple.variables['DQDescriptions'][:]]

rows=[]
for w in range(nwin):
    start = w*WIN_N
    x = np.asarray(strain[start:start+WIN_N], dtype=np.float64)
    x = x[np.isfinite(x)]
    if len(x) < WIN_N//2:
        continue
    x = signal.detrend(x, type='constant')
    mean = float(np.mean(x)); std = float(np.std(x)); rms = float(np.sqrt(np.mean(x*x)))
    mx = float(np.max(x)); mn = float(np.min(x)); maxabs = float(max(abs(mx),abs(mn)))
    z = (x-mean)/(std+EPS)
    kurt = float(np.mean(z**4))
    # Welch PSD; density units strain^2/Hz. Integrate for band variance.
    f, Pxx = signal.welch(x, fs=FS, nperseg=NPER, noverlap=NPER//2, detrend='constant', scaling='density')
    band_power=[]
    for a,b in BANDS:
        m=(f>=a)&(f<b)
        val=float(np.trapz(Pxx[m], f[m])) if np.any(m) else 0.0
        band_power.append(max(val, EPS))
    sec0=w*WIN_S; sec1=sec0+WIN_S
    dq_vals=dqmask[sec0:sec1]
    dq_and=int(np.bitwise_and.reduce(dq_vals)) if len(dq_vals)>0 else 0
    dq_or=int(np.bitwise_or.reduce(dq_vals)) if len(dq_vals)>0 else 0
    dq_unique=int(len(np.unique(dq_vals))) if len(dq_vals)>0 else 0
    row={
        'window_index': w, 'gps_start': int(meta.get('GPSstart','0')) + sec0,
        't_seconds': sec0, 'mean': mean, 'std': std, 'rms': rms, 'min': mn, 'max': mx,
        'maxabs': maxabs, 'kurtosis': kurt, 'dq_and': dq_and, 'dq_or': dq_or, 'dq_unique': dq_unique,
    }
    row.update({name: val for name,val in zip(BAND_NAMES, band_power)})
    rows.append(row)

ds.close()

# Build feature matrix. Use logs for positive scale observables.
feature_names = ['log_std','log_rms','log_maxabs','log_kurtosis'] + ['log_'+n for n in BAND_NAMES]
M=[]
for r in rows:
    vals=[np.log10(max(r['std'],EPS)), np.log10(max(r['rms'],EPS)), np.log10(max(r['maxabs'],EPS)), np.log10(max(r['kurtosis'],EPS))]
    vals += [np.log10(max(r[n], EPS)) for n in BAND_NAMES]
    M.append(vals)
Xraw=np.array(M, dtype=float)
valid=np.all(np.isfinite(Xraw), axis=1)
Xraw=Xraw[valid]
rows=[r for r,v in zip(rows,valid) if v]
X, med, scale = robust_z(Xraw)

C, evals, evecs, h, loadings = pca_payload(X, feature_names)
rel = evals / max(evals[0], EPS)
rank_1e3 = int(np.sum(rel>1e-3))
rank_1e2 = int(np.sum(rel>1e-2))

# Reconstruction / elimination errors for blind-sector truncation
U, S, Vt = np.linalg.svd(X, full_matrices=False)
recon=[]
for k in range(1, min(X.shape[1],10)+1):
    Xk=(U[:,:k]*S[:k])@Vt[:k,:]
    err=float(np.linalg.norm(X-Xk,'fro')/np.linalg.norm(X,'fro'))
    # observable band-only error
    band_idx=[feature_names.index('log_'+n) for n in BAND_NAMES]
    berr=float(np.linalg.norm((X-Xk)[:,band_idx],'fro')/np.linalg.norm(X[:,band_idx],'fro'))
    recon.append({'k':k,'relative_total_error':err,'relative_band_error':berr})

# Local Fisher / local covariance rank from nearest-neighbor neighborhoods in feature space
n_neighbors=32
sample_idx=np.linspace(0, X.shape[0]-1, min(300, X.shape[0]), dtype=int)
nn=NearestNeighbors(n_neighbors=min(n_neighbors, X.shape[0])).fit(X)
_, inds=nn.kneighbors(X[sample_idx])
local=[]
for ids in inds:
    Y=X[ids]-X[ids].mean(0)
    c=np.cov(Y,rowvar=False)
    ev=np.linalg.eigvalsh(c)[::-1]
    rr=ev/max(ev[0],EPS)
    local.append({
        'rank_1e2': int(np.sum(rr>1e-2)),
        'rank_1e3': int(np.sum(rr>1e-3)),
        'min_rel': float(rr[-1]),
        'cond_1e3': float(ev[0]/max(ev[np.sum(rr>1e-3)-1],EPS)) if np.sum(rr>1e-3)>0 else float('inf')
    })
local_summary={}
for key in ['rank_1e2','rank_1e3','min_rel','cond_1e3']:
    arr=np.array([d[key] for d in local],dtype=float)
    local_summary[key]={'median':float(np.median(arr)),'p10':float(np.percentile(arr,10)),'p90':float(np.percentile(arr,90))}

# Stability: first half vs second half PCA subspace angles
mid=X.shape[0]//2
_, ev1, V1, h1, _ = pca_payload(X[:mid], feature_names)
_, ev2, V2, h2, _ = pca_payload(X[mid:], feature_names)
angles={}
for k in [1,2,3,rank_1e2,rank_1e3]:
    k=max(1,min(k,X.shape[1]))
    angles[f'top_{k}']= [float(a) for a in subspace_angles(V1[:,:k], V2[:,:k])]

# Noise attack in feature space
rng=np.random.default_rng(20260729)
noise_attack=[]
for sigma in [0.01,0.03,0.05,0.10,0.20]:
    ranks=[]; angles_noise=[]
    for rep in range(20):
        Xn=X + rng.normal(scale=sigma, size=X.shape)
        _, evn, Vn, hn, _ = pca_payload(Xn, feature_names)
        reln=evn/max(evn[0],EPS)
        ranks.append(int(np.sum(reln>1e-3)))
        k=rank_1e3
        angles_noise.append(float(np.max(subspace_angles(evecs[:,:k], Vn[:,:k]))))
    noise_attack.append({'feature_noise_sigma':sigma,'rank_1e3_median':float(np.median(ranks)),'rank_1e3_values':ranks,'max_subspace_angle_median':float(np.median(angles_noise)),'max_subspace_angle_p90':float(np.percentile(angles_noise,90))})

# DQ sectors: group by dq_unique, but mostly should be 1 for stable masks
by_dq={}
for key in sorted(set(r['dq_unique'] for r in rows)):
    idx=[i for i,r in enumerate(rows) if r['dq_unique']==key]
    if len(idx)>=10:
        _, evd, _, hd, _=pca_payload(X[idx], feature_names)
        by_dq[str(key)]={'n':len(idx),'rank_1e3':hd['rank_rel_gt_0.001'],'eff_rank_participation':hd['effective_rank_participation']}

# basic metadata/strain stats
means=np.array([r['mean'] for r in rows]); stds=np.array([r['std'] for r in rows]); kurts=np.array([r['kurtosis'] for r in rows])
summary={
    'input_file': IN.name,
    'file_size_bytes': IN.stat().st_size,
    'meta': meta,
    'n_samples': int(N), 'sample_rate_hz': FS, 'duration_s': float(N/FS),
    'window_seconds': WIN_S, 'n_windows': int(len(rows)),
    'dq_shortnames': dq_short, 'dq_descriptions': dq_desc,
    'feature_names': feature_names,
    'strain_window_stats': {
        'std_median': float(np.median(stds)), 'std_p10': float(np.percentile(stds,10)), 'std_p90': float(np.percentile(stds,90)),
        'mean_abs_median': float(np.median(np.abs(means))), 'kurtosis_median': float(np.median(kurts)), 'kurtosis_p90': float(np.percentile(kurts,90))
    },
    'global_fisher_proxy_health': h,
    'pca_loadings': loadings,
    'chosen_resolved_rank_1e3': rank_1e3,
    'chosen_resolved_rank_1e2': rank_1e2,
    'reconstruction_elimination': recon,
    'local_fisher_proxy_summary': local_summary,
    'split_half_subspace_angles_radians': angles,
    'noise_attack': noise_attack,
    'dq_sector_health': by_dq,
}

# CSV features
import csv
csv_path=OUT/'rg_o4a_h1_features_4s.csv'
with csv_path.open('w', newline='') as fcsv:
    writer=csv.DictWriter(fcsv, fieldnames=list(rows[0].keys()))
    writer.writeheader(); writer.writerows(rows)
json_path=OUT/'rg_o4a_h1_rg_battery_results.json'
json_path.write_text(json.dumps(summary, indent=2), encoding='utf-8')

# Summary TXT
lines=[]
lines.append('RG O4a H1 16kHz real-data Fisher-hole battery')
lines.append(f"input={IN.name}")
lines.append(f"samples={N}, fs={FS}, duration={N/FS:.1f}s, windows={len(rows)} of {WIN_S}s")
lines.append(f"strain std median={summary['strain_window_stats']['std_median']:.6e}, p10={summary['strain_window_stats']['std_p10']:.6e}, p90={summary['strain_window_stats']['std_p90']:.6e}")
lines.append('\nGlobal Fisher/PCA proxy spectrum relative eigenvalues:')
lines.append(', '.join(f'{v:.3e}' for v in h['relative_eigenvalues']))
lines.append(f"effective rank participation={h['effective_rank_participation']:.3f}, entropy={h['effective_rank_entropy']:.3f}")
lines.append(f"rank >1e-2={rank_1e2}, rank >1e-3={rank_1e3}, hole_dim_1e-3={len(evals)-rank_1e3}")
lines.append('\nTop PCA loadings:')
for ld in loadings[:4]: lines.append(str(ld))
lines.append('\nReconstruction/elimination errors:')
for r in recon: lines.append(str(r))
lines.append('\nLocal Fisher proxy summary:')
lines.append(str(local_summary))
lines.append('\nSplit-half subspace angles radians:')
lines.append(str(angles))
lines.append('\nNoise attack:')
for r in noise_attack: lines.append(str(r))
lines.append('\nDQ sector health:')
lines.append(str(by_dq))
summary_path=OUT/'rg_o4a_h1_rg_battery_summary.txt'
summary_path.write_text('\n'.join(lines),encoding='utf-8')

# Plots
# 1 eigen spectrum
plt.figure(figsize=(7,4.5))
plt.semilogy(np.arange(1,len(rel)+1), rel, marker='o')
plt.axhline(1e-2, color='gray', linestyle='--', linewidth=1)
plt.axhline(1e-3, color='gray', linestyle=':', linewidth=1)
plt.xlabel('component index')
plt.ylabel('relative eigenvalue')
plt.title('RG Fisher proxy spectrum: H1 O4a 16kHz segment')
plt.tight_layout(); p1=OUT/'rg_o4a_h1_fisher_spectrum.png'; plt.savefig(p1,dpi=160); plt.close()
# 2 PC scatter over time
scores=X@evecs
plt.figure(figsize=(6,5))
sc=plt.scatter(scores[:,0], scores[:,1], c=[r['t_seconds'] for r in rows], s=10, cmap='viridis')
plt.colorbar(sc,label='time seconds')
plt.xlabel('PC1'); plt.ylabel('PC2'); plt.title('Observable sector atlas (4s windows)')
plt.tight_layout(); p2=OUT/'rg_o4a_h1_sector_atlas_pc12.png'; plt.savefig(p2,dpi=160); plt.close()
# 3 reconstruction errors
plt.figure(figsize=(7,4.5))
ks=[r['k'] for r in recon]
plt.plot(ks,[r['relative_total_error'] for r in recon], marker='o', label='total')
plt.plot(ks,[r['relative_band_error'] for r in recon], marker='o', label='band powers')
plt.xlabel('resolved components retained')
plt.ylabel('relative reconstruction error')
plt.title('Blind-sector elimination error')
plt.legend(); plt.tight_layout(); p3=OUT/'rg_o4a_h1_elimination_error.png'; plt.savefig(p3,dpi=160); plt.close()
# 4 band power time traces standardized
plt.figure(figsize=(9,5))
for name in BAND_NAMES[:4]:
    vals=np.array([np.log10(max(r[name],EPS)) for r in rows])
    vals=(vals-np.median(vals))/(np.std(vals)+EPS)
    plt.plot([r['t_seconds'] for r in rows], vals, label=name, alpha=0.8)
plt.xlabel('time seconds'); plt.ylabel('standardized log band power')
plt.title('Band-power observables used for RG sector extraction')
plt.legend(ncol=2, fontsize=8); plt.tight_layout(); p4=OUT/'rg_o4a_h1_bandpowers.png'; plt.savefig(p4,dpi=160); plt.close()

print('\n'.join(lines[:40]))
print('WROTE', json_path, summary_path, csv_path, p1, p2, p3, p4)
