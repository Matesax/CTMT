import json, csv
from pathlib import Path
import numpy as np
from scipy.linalg import subspace_angles
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

IN=Path('/mnt/data/rg_o4a_h1_fullstory_features_4s.csv')
OUT=Path('/mnt/data')
EPS=1e-300
BANDS=['P_20_80','P_80_300','P_300_1000','P_1000_2048','P_2048_4096','P_4096_8192']
feature_names=['log_std','log_maxabs','log_kurtosis']+[f'log_{b}' for b in BANDS]
rows=[]
with IN.open() as f:
    for r in csv.DictReader(f):
        rows.append({k:float(v) if k not in ['window','gps_start','dq_unique','dq_and','dq_or'] else int(float(v)) for k,v in r.items()})

def robust_z(X):
    med=np.median(X,axis=0); mad=np.median(np.abs(X-med),axis=0); scale=1.4826*mad
    scale=np.where(scale<1e-12,np.std(X,axis=0)+1e-12,scale)
    return (X-med)/scale, med, scale

def eig(X):
    C=np.cov(X,rowvar=False); w,V=np.linalg.eigh(C); o=np.argsort(w)[::-1]; w=w[o]; V=V[:,o]
    rel=w/max(w[0],EPS)
    h={'relative_eigenvalues':rel.tolist(),'eigenvalues':w.tolist(),
       'participation_rank':float((w.sum()**2)/np.sum(w**2)),
       'entropy_rank':float(np.exp(-np.sum((w/w.sum())*np.log(np.maximum(w/w.sum(),EPS)))))}
    for t in [1e-2,1e-3,1e-4,1e-6]:
        r=int(np.sum(rel>t)); h[f'rank_gt_{t:g}']=r; h[f'hole_dim_le_{t:g}']=int(len(w)-r)
    return w,V,rel,h

X=[]
for r in rows:
    vals=[np.log10(max(r['std'],EPS)),np.log10(max(r['maxabs'],EPS)),np.log10(max(r['kurtosis'],EPS))]
    vals += [np.log10(max(r[b],EPS)) for b in BANDS]
    X.append(vals)
Xraw=np.array(X,float); X,med,scale=robust_z(Xraw)
w,V,rel,h=eig(X)
rank1e3=h['rank_gt_0.001']; rank1e2=h['rank_gt_0.01']
# Loadings
load=[]
for j in range(V.shape[1]):
    comps=sorted([(feature_names[i],float(V[i,j])) for i in range(len(feature_names))],key=lambda x:-abs(x[1]))[:6]
    load.append({'component':j+1,'relative_eigenvalue':float(rel[j]),'top_loadings':comps})
# segment rank/transport 16 * 256 s
seg_len=64; seg=[]; vec=[]
for a in range(0,len(rows)-seg_len+1,seg_len):
    ww,VV,rr,hh=eig(X[a:a+seg_len])
    seg.append({'segment':a//seg_len,'t0':rows[a]['t_seconds'],'t1':rows[a+seg_len-1]['t_seconds']+4,'rank_1e2':hh['rank_gt_0.01'],'rank_1e3':hh['rank_gt_0.001'],'rel_eval':rr.tolist()})
    vec.append(VV)
transport=[]
for i in range(len(vec)-1):
    k=min(rank1e3,X.shape[1])
    transport.append({'from':i,'to':i+1,'max_angle':float(np.max(subspace_angles(vec[i][:,:k],vec[i+1][:,:k])))})
# noise
rng=np.random.default_rng(20260729); noise=[]
for sigma in [0.01,0.03,0.05,0.1,0.2]:
    ranks=[]; angles=[]
    for rep in range(20):
        Xn=X+rng.normal(scale=sigma,size=X.shape)
        ww,VV,rr,hh=eig(Xn); ranks.append(hh['rank_gt_0.001'])
        k=min(rank1e3,X.shape[1]); angles.append(float(np.max(subspace_angles(V[:,:k],VV[:,:k]))))
    noise.append({'sigma':sigma,'rank_1e3_values':ranks,'median_rank':float(np.median(ranks)),'median_angle':float(np.median(angles)),'p90_angle':float(np.percentile(angles,90))})
# GR placement as post-map not Fisher coordinate
centers=np.array([np.sqrt(20*80),np.sqrt(80*300),np.sqrt(300*1000),np.sqrt(1000*2048),np.sqrt(2048*4096),np.sqrt(4096*8192)])
omega=(2*np.pi*centers)**2
rho=np.array([sum(omega[j]*max(r[BANDS[j]],EPS) for j in range(len(BANDS))) for r in rows])
# reconstruct primitive features using k=rank1e3; then recompute rho from reconstructed band logs
U,S,Vt=np.linalg.svd(X,full_matrices=False)
Xr=(U[:,:rank1e3]*S[:rank1e3])@Vt[:rank1e3,:]
Xr_raw=Xr*scale+med
band_idx=[feature_names.index(f'log_{b}') for b in BANDS]
rho_rec=[]
for row in Xr_raw[:,band_idx]:
    bp=10**row; rho_rec.append(float(np.sum(omega*bp)))
rho_rec=np.array(rho_rec)
rho_err=float(np.linalg.norm(np.log10(rho)-np.log10(np.maximum(rho_rec,EPS)))/np.linalg.norm(np.log10(rho)))
placement={'type':'post-map GR placement bridge from primitive spectral observables','rho_definition':'sum_bands (2*pi*f_center)^2 P_band','resolved_rank_used':rank1e3,'rho_log_relative_error':rho_err,'claim':'placement automation only; no Tmunu reconstruction'}
summary={'basis':'gauge-free primitive observable basis: log_std, log_maxabs, log_kurtosis, six log band powers; derived ratios and rho excluded from Fisher coordinates',
         'features':feature_names,'n_windows':len(rows),'global_health':h,'rank_1e2':rank1e2,'rank_1e3':rank1e3,
         'loadings':load,'segments_256s':seg,'transport':transport,
         'transport_summary':{'median':float(np.median([x['max_angle'] for x in transport])),'p90':float(np.percentile([x['max_angle'] for x in transport],90)),'max':float(np.max([x['max_angle'] for x in transport]))},
         'noise':noise,'gr_placement_bridge':placement}
Path('/mnt/data/rg_o4a_h1_gaugefree_results.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
lines=[]
lines.append('RG O4a H1 gauge-free primitive-basis battery')
lines.append('Relative eigenvalues: '+', '.join(f'{x:.3e}' for x in rel))
lines.append(f"rank>1e-2={rank1e2}, rank>1e-3={rank1e3}, hole_dim_1e-3={h['hole_dim_le_0.001']}, participation={h['participation_rank']:.3f}, entropy={h['entropy_rank']:.3f}")
lines.append('Transport summary: '+str(summary['transport_summary']))
lines.append('Noise: '+str(noise))
lines.append('GR placement: '+str(placement))
lines.append('Loadings: '+str(load))
Path('/mnt/data/rg_o4a_h1_gaugefree_summary.txt').write_text('\n'.join(lines),encoding='utf-8')
plt.figure(figsize=(7,4.5)); plt.semilogy(np.arange(1,len(rel)+1),rel,marker='o'); plt.axhline(1e-3,color='gray',ls=':'); plt.axhline(1e-2,color='gray',ls='--'); plt.xlabel('component'); plt.ylabel('relative eigenvalue'); plt.title('Gauge-free primitive Fisher spectrum'); plt.tight_layout(); plt.savefig('/mnt/data/rg_o4a_h1_gaugefree_spectrum.png',dpi=160); plt.close()
plt.figure(figsize=(8,4.5)); plt.plot([x['from'] for x in transport],[x['max_angle'] for x in transport],marker='o'); plt.xlabel('adjacent 256 s segment'); plt.ylabel('max subspace angle'); plt.title('Gauge-free sector transport'); plt.tight_layout(); plt.savefig('/mnt/data/rg_o4a_h1_gaugefree_transport.png',dpi=160); plt.close()
print('\n'.join(lines[:6]))
