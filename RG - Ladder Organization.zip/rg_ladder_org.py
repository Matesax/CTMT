"""Organization engine for the Resolution Geometry ladder L0-L133 (second edition).
Parses the ladder table from the final print, validates it, and produces the organizational views:
global map, branch/hand-over map, walls, hypothesis gates, anti-ladders (reverse dependency cones),
longest chains, criticality, audience views and lab pipelines. Second edition adds the companion register,
anti-connectors (common cones and meets of two targets), destructor and dispatcher tables, a unity audit against a
scattered-toolkit null model, and the validation of the executable wall-tap walks (rg_walks.py) against the printed
ladder.  Deterministic; no randomness.
Run: python rg_walks.py ; python rg_ladder_org.py --tex final_print.tex --walks rg_walks_results.json --out build
"""
import argparse, collections, hashlib, json, pathlib, re, subprocess, sys
import networkx as nx

BRANCHES = [  # (key, name, first, last, audience)
    ("B0", "Exact core and symmetry", 0, 11, "all"),
    ("B1", "Observable sector", 12, 17, "lab"),
    ("B2", "Differential and strata", 18, 27, "geometry"),
    ("B3", "Second order (Fisher)", 28, 37, "geometry"),
    ("B4", "Quantum", 38, 43, "physics"),
    ("B5", "Ignorance", 44, 48, "lab"),
    ("B6", "Uncertainty and forgetting", 49, 58, "lab"),
    ("B7", "Statistical distance", 59, 63, "geometry"),
    ("B8", "Order and cone", 64, 73, "geometry"),
    ("B9", "Scale and transport", 74, 80, "physics"),
    ("B10", "Duration and dynamics", 81, 89, "physics"),
    ("B11", "Chaos frontier", 90, 93, "physics"),
    ("B12", "Physical distance", 94, 109, "physics"),
    ("B13", "Assembly and closure", 110, 115, "lab"),
    ("B14", "Final remainder", 116, 123, "geometry"),
    ("B15", "Local classification", 124, 128, "geometry"),
    ("B16", "Remainder across walls", 129, 131, "geometry"),
    ("B17", "Open", 132, 133, "all"),
]
ROLE = {  # declared reading of each station: what kind of object it is in the single structure
    "B0": "primitive: records, kernel, quotient, symmetry", "B1": "certificates on the quotient",
    "B2": "tangent structure of the quotient (H-reg)", "B3": "the forced geometry (Fisher)",
    "B4": "coherence: standalone geometry, conditional (non-simplicial cone, declared frame)",
    "B5": "ignorance: the fibre, prior to uncertainty", "B6": "uncertainty: not standalone, the dual of Fisher on the quotient",
    "B7": "distance: integrated Fisher, experiment-relative", "B8": "order and cone; sign by declaration",
    "B9": "transport: declared covariance", "B10": "clock groupoid on the quotient", "B11": "resolution horizon of dynamics",
    "B12": "unit: anchors close the dilation hole", "B13": "dispatcher: typed statuses", "B14": "second-order global structure",
    "B15": "local classification", "B16": "structure across walls", "B17": "open problems (external)"}
SHORT = """observation system|kernel groupoid|universal factorization|joint kernel = intersection|garbling enlarges kernel|
exact layer fixes nothing|Gau-Stab-Gamma sequence|no splitting|count rigidity|orbit-quotient comparison|
rank, separation, completeness distinct|coherent completeness|minimal-panel selector|no task-free selector|
robust observability|coupled refines marginals|confidence-set bridge|tolerance not a groupoid|tangent sequence|
natural descent|automatic descent|slices and tangent cones|one-sided wall directions|kernel upper semicontinuity|
specialization iff inclusion|normalizer descent|tangent USC, tame strata|stratified quotient category|Fisher natural|
Fisher selected (Cencov)|(R,N,Sigma) reconstruction|Fisher does not fix covariance|quotient dim p+q+pq|shadow is not the law|
efficient metric|data processing|kernel order not Blackwell|Hellinger specialization|Petz family gate|quantum task lock|
Petz identification|quantum wall f(0)>0|trace rule|contextual protocols (Fine)|persistent null|sensor/precision/representation nulls|
finite-sample reconstruction|rank walls not certifiable|law equality not certifiable|uncertainty splits on quotient|
de Finetti|LAN and folds|TV rigidity|no uniform forgetting|BV mixing lock|contraction gate|samples refute, operators lock|
non-circularity certificate|non-dominated strata|RG distance|garbling monotone|no angle in rank one|divergences not rulers|
experiment-relative distance|reachability descends|projective typing|realization branches|conformal ray|Lorentz forcing|
tame reduction|no finite classification|smooth/convex duality|hyperbolic lock|wild class|scale cocycle|strict transport|
induced connection|entropy selects no connection|law transport descends|no law-natural connection|canonical connection|
clock groupoid|affine clocks|path independence|coherence duration (BCH)|stratified finite histories|entropy from counts|
Ruelle, Pesin locks|typed dynamical certificates|chaos cone fields|frontier law 1/lambda|duality 2 lambda, growth h|
lambda/ln2 bits per step|offset/rate/warp|no internal unit|counted channel|count loss|ratio scale|two-point invariant|
metric proportionality|anchor budget|unit-distance rigidity|radar distance|radar = rod|Landau-Lifshitz stationary|
Sagnac holonomy|non-stationary no-go|media|ergodic metre transfer|physical distance|kernel-stabilizer theorem|global transport|
dispatcher statuses|composite soundness|window-indexed walls|maximal closure|task residual|coupling complement-relative|
coupling stabilizer|global structure|remainder consequences|gluing class H2|wall monodromy|no new primitive|
local classifier (word traces)|simple-spectrum sign chart|short descriptors lose orbits|
Lorentzian scalars do not separate|classification selects no dynamics|hidden-room descent|no constructible exit paths|
obstruction tower|tame type enumeration|forced turbulence forgetting""".replace("\n", "").split("|")
HYPS = {"reg", "sound", "compl", "coh", "unif", "hell", "mono", "nuis", "task", "sens", "exch", "adm", "top", "int",
        "cov", "resp", "SI", "med", "stat", "val", "split", "type", "band"}
CLASS_COLOR = {"input": "#bbbbbb", "F": "#7fbf7f", "I": "#8fb3e0", "H": "#f2c46d", "G": "#d9a0e0", "N": "#e88a8a",
               "O": "#ffffff"}


def num(tok):
    return int(tok.strip().lstrip("L"))


def parse(tex):
    body = tex[tex.index(r"\itshape Exact layer"):]
    body = body[:body.index(r"\bottomrule")]
    rows = []
    for line in body.splitlines():
        m = re.match(r"^L(\d+) & (.*) & (.*?) & (.*?) & \\ref\{(.*?)\}\\\\$", line.strip())
        if m:
            rows.append(dict(id=int(m.group(1)), statement=m.group(2), status=m.group(3), deps_raw=m.group(4),
                             ref=m.group(5)))
    return rows


def deps_of(raw):
    logical, aggregate = [], []
    if raw.strip() in ("---", ""):
        return logical, aggregate
    for part in raw.split(","):
        part = part.strip()
        if "--" in part:
            a, b = part.split("--")
            span = list(range(num(a), num(b) + 1))
            if len(span) > 20:          # the assembly umbrella (L110 <- L1..L109)
                aggregate += span
            else:                       # genuine range dependencies (L57, L109, L115, L123)
                logical += span
        else:
            logical.append(num(part))
    return logical, aggregate


def classes(status):
    s = status.replace("$\\Gamma$", "G")
    cl = []
    for tok in re.split(r"[ /()]+", s):
        tok = tok.strip(":;,")
        if tok in ("input", "F", "I", "H", "G", "N", "O") and tok not in cl:
            cl.append(tok)
    hyps = set()
    for m in re.finditer(r"H:\s*([^)]*)", s):
        for seg in m.group(1).split(";"):
            for h in re.split(r"[,\s]+", seg):
                if h in HYPS:
                    hyps.add(h)
    return cl, hyps


def branch_of(i):
    for k, name, a, b, aud in BRANCHES:
        if a <= i <= b:
            return k
    raise KeyError(i)


def build(rows):
    G = nx.DiGraph()     # edge u -> v : v depends on u
    for r in rows:
        cl, hy = classes(r["status"])
        lg, ag = deps_of(r["deps_raw"])
        r.update(classes=cl, hyps=sorted(hy), logical=lg, aggregate=ag, branch=branch_of(r["id"]),
                 short=SHORT[r["id"]].strip())
        G.add_node(r["id"], **{k: r[k] for k in ("classes", "hyps", "branch", "short", "status")})
    for r in rows:
        for d in r["logical"]:
            G.add_edge(d, r["id"], kind="logical")
        for d in r["aggregate"]:
            if not G.has_edge(d, r["id"]):
                G.add_edge(d, r["id"], kind="aggregate")
    return G


def logical_graph(G):
    L = nx.DiGraph(); L.add_nodes_from(G.nodes(data=True))
    L.add_edges_from((u, v) for u, v, k in G.edges(data="kind") if k == "logical")
    return L


def validate(rows, G):
    checks = []
    def chk(name, ok, detail=""):
        checks.append(dict(check=name, passed=bool(ok), detail=detail))
        if not ok:
            raise AssertionError(name + " " + str(detail))
    ids = [r["id"] for r in rows]
    chk("O1 contiguous L0-L133", ids == list(range(134)), len(ids))
    bad = [(d, r["id"]) for r in rows for d in r["logical"] + r["aggregate"] if not d < r["id"]]
    chk("O2 every dependency points backward", not bad, bad)
    chk("O3 acyclic", nx.is_directed_acyclic_graph(G))
    roots = [n for n in G if G.in_degree(n) == 0]
    chk("O4 single root L0", roots == [0], roots)
    chk("O5 every rung reachable from L0", len(nx.descendants(G, 0)) == 133)
    chk("O6 every rung has a parsed status class", all(r["classes"] for r in rows),
        [r["id"] for r in rows if not r["classes"]])
    unknown = sorted({h for r in rows for h in r["hyps"]} - HYPS)
    chk("O7 every hypothesis is a declared name", not unknown, unknown)
    opens = [r["id"] for r in rows if "O" in r["classes"]]
    chk("O8 nothing depends on an open rung", all(G.out_degree(o) == 0 for o in opens), opens)
    chk("O9 the only input is L0", [r["id"] for r in rows if "input" in r["classes"]] == [0])
    return checks


def header_starts(tex):
    """First rung after each printed section header of the ladder table."""
    body = tex[tex.index(r"\itshape Exact layer"):]
    body = body[:body.index(r"\bottomrule")]
    starts, pending = [], None
    for line in body.splitlines():
        m = re.search(r"\\itshape ([^}]*)\}", line)
        if m:
            pending = m.group(1)
        mm = re.match(r"^L(\d+) & ", line.strip())
        if mm and pending is not None:
            starts.append((int(mm.group(1)), pending)); pending = None
    return starts


def inherited(G, Gfull=None):
    out = {}
    for n in nx.topological_sort(G):
        hy = set(G.nodes[n]["hyps"]); gam = "G" in G.nodes[n]["classes"]
        imp = 1 if "I" in G.nodes[n]["classes"] else 0
        anc = nx.ancestors(G, n)
        for a in anc:
            hy |= set(G.nodes[a]["hyps"]); gam = gam or "G" in G.nodes[a]["classes"]
        imps = sum(1 for a in anc | {n} if "I" in G.nodes[a]["classes"])
        out[n] = dict(hyps=sorted(hy), gamma=gam, imports=imps, ancestors=len(anc),
                      via_assembly=bool(Gfull is not None and n != 110 and 110 in nx.ancestors(Gfull, n)))
    return out


def longest_chain(G, target):
    sub = G.subgraph(nx.ancestors(G, target) | {target})
    return nx.dag_longest_path(sub)


def tred(G, nodes):
    return nx.transitive_reduction(G.subgraph(nodes))


# ------------------------------------------------------------------ drawing
def dot_node(n, G, show_label=True):
    d = G.nodes[n]; c = d["classes"]
    prim = c[0]
    shape = {"N": "octagon", "O": "doubleoctagon", "I": "box", "H": "hexagon", "G": "hexagon",
             "input": "invhouse"}.get(prim, "ellipse")
    if "H" in c and prim == "F":
        shape = "hexagon"
    fill = CLASS_COLOR.get(prim, "#ffffff")
    if prim == "F" and ("H" in c):
        fill = CLASS_COLOR["H"]
    label = f"L{n}" + (f"\\n{d['short']}" if show_label else "")
    if d["hyps"] and show_label:
        label += "\\n[" + ",".join(d["hyps"]) + "]"
    style = "filled,dashed" if prim == "I" else "filled"
    return f'  n{n} [label="{label}", shape={shape}, style="{style}", fillcolor="{fill}"];'


BCOL = ["#444444", "#1f77b4", "#2ca02c", "#9467bd", "#8c564b", "#e377c2", "#7f7f7f", "#bcbd22", "#17becf",
        "#d62728", "#ff7f0e", "#393b79", "#637939", "#843c39", "#7b4173", "#5254a3", "#8c6d31", "#000000"]


def render(dotsrc, path):
    p = pathlib.Path(path); p.with_suffix(".dot").write_text(dotsrc)
    subprocess.run(["dot", "-Tpdf", str(p.with_suffix(".dot")), "-o", str(p.with_suffix(".pdf"))], check=True)


def global_map(G, L, out):
    T = nx.transitive_reduction(L)
    s = ['digraph G { rankdir=LR; newrank=true; nodesep=0.12; ranksep=0.35; splines=true;',
         '  node [fontsize=9, fontname="Helvetica", margin="0.03,0.02", height=0.25];',
         '  edge [arrowsize=0.4, penwidth=0.6];']
    for bi, (k, name, a, b, aud) in enumerate(BRANCHES):
        s.append(f'  subgraph cluster_{k} {{ label="{k} {name}"; fontsize=11; style=rounded; color="{BCOL[bi]}";')
        for n in range(a, b + 1):
            s.append("  " + dot_node(n, G, show_label=False))
        s.append("  }")
    for k, name, a, b, aud in BRANCHES[:13]:
        s.append(f'  n{b} -> n110 [style=dashed, color="#555555", penwidth=0.5, constraint=false];')
    for u, v in T.edges():
        bu, bv = G.nodes[u]["branch"], G.nodes[v]["branch"]
        if bu == bv:
            s.append(f'  n{u} -> n{v} [color="#9a9a9a"];')
        else:
            col = BCOL[int(bu[1:])]
            s.append(f'  n{u} -> n{v} [color="{col}", penwidth=1.1];')
    s.append("}")
    render("\n".join(s), out / "fig_global_map")
    return T


def branch_map(G, L, out):
    H = collections.Counter(); ex = collections.defaultdict(list)
    for u, v in L.edges():
        bu, bv = G.nodes[u]["branch"], G.nodes[v]["branch"]
        if bu != bv:
            H[(bu, bv)] += 1; ex[(bu, bv)].append((u, v))
    s = ['digraph B { rankdir=TB; nodesep=0.35; ranksep=0.45;',
         '  node [shape=box, style="rounded,filled", fontname="Helvetica", fontsize=10];',
         '  edge [fontname="Helvetica", fontsize=7, arrowsize=0.6];']
    for bi, (k, name, a, b, aud) in enumerate(BRANCHES):
        fill = {"lab": "#fde3c8", "geometry": "#d7e8f7", "physics": "#e3f2d6", "all": "#eeeeee"}[aud]
        s.append(f'  {k} [label="{k} {name}\\nL{a}-L{b}  ({aud})", fillcolor="{fill}", color="{BCOL[bi]}"];')
    for (bu, bv), c in sorted(H.items()):
        lab = ", ".join(f"{u}>{v}" for u, v in ex[(bu, bv)][:3]) + (" ..." if c > 3 else "")
        s.append(f'  {bu} -> {bv} [label="{c}: {lab}", penwidth={0.6 + 0.35 * c:.2f}];')
    s.append('  B13 [peripheries=2];')
    s.append("}")
    render("\n".join(s), out / "fig_branch_map")
    return H, ex


def anti_ladder(G, L, target, out, name, extra=()):
    nodes = nx.ancestors(L, target) | {target} | set(extra)
    T = nx.transitive_reduction(L.subgraph(nodes))
    s = ['digraph A { rankdir=TB; nodesep=0.15; ranksep=0.28;',
         '  node [fontsize=8, fontname="Helvetica", margin="0.04,0.02"];', '  edge [arrowsize=0.45, dir=back];']
    for n in sorted(nodes):
        s.append(dot_node(n, G))
    for u, v in T.edges():
        hand = G.nodes[u]["branch"] != G.nodes[v]["branch"]
        s.append(f'  n{v} -> n{u} [color="{"#c0392b" if hand else "#888888"}"{", penwidth=1.3" if hand else ""}];')
    s.append(f'  n{target} [peripheries=2];')
    s.append("}")
    render("\n".join(s), out / f"fig_anti_{name}")


# ------------------------------------------------------------------ main
TARGETS = {
    "physics": [109, 105, 68, 80, 90, 39, 43, 104],
    "geometry": [27, 32, 69, 72, 110, 119, 124, 131],
    "lab": [12, 16, 47, 57, 95, 108, 113, 114],
}
PIPELINES = [
    ("P1", "Choose sufficient instruments", [12, 14], "minimal panels; ties retained; robust union over models"),
    ("P2", "Report a value with uncertainty", [16, 49, 51], "confidence set; quotient/kernel split; LAN fails at folds"),
    ("P3", "Certify a wall or a rank", [23, 26, 47, 114], "upper-bound certificates only; window-indexed walls"),
    ("P4", "Calibrated distance (radar, SI)", [102, 103, 107, 109], "counted channel, SI anchor, medium, held-out anchor"),
    ("P5", "Compare and synchronize clocks", [82, 83, 93, 105], "affine clocks; path independence; Sagnac holonomy"),
    ("P6", "Forecast horizon of a chaotic system", [88, 90, 91, 92], "frontier slope 1/lambda; bits per step"),
    ("P7", "Non-circular simulation / forgetting", [54, 55, 57], "declared admissible class; contraction gate"),
    ("P8", "Quantum estimation or testing", [39, 40, 41], "task fixes the Petz member; wall iff f(0)>0"),
    ("P9", "Locomotion / latent transport", [80, 111], "declared covariance; canonical connection; H-resp"),
    ("P10", "Lock decision for any request", [112, 113, 114, 115], "one status; false LOCK <= sum of alphas"),
    ("P11", "Global gluing of local measurements", [119, 121, 129, 131], "twisted forms; H2 class; hidden rooms; obstruction tower"),
    ("P12", "Classify a second-order datum", [124, 125, 126], "word traces; sign chart; no shorter descriptor"),
]


def main(texpath, outdir, walkspath=None):
    out = pathlib.Path(outdir); out.mkdir(parents=True, exist_ok=True)
    tex = pathlib.Path(texpath).read_text()
    rows = parse(tex)
    G = build(rows); L = logical_graph(G)
    checks = validate(rows, G)
    inh = inherited(L, G)
    # chains
    chains = {}
    for tgt in sorted({t for v in TARGETS.values() for t in v} | {109, 110, 115, 123, 131, 133}):
        chains[tgt] = dict(logical=longest_chain(L, tgt), with_aggregate=longest_chain(G, tgt))
    glob_log = nx.dag_longest_path(L); glob_all = nx.dag_longest_path(G)
    # criticality: forward cone in the logical graph
    blast = {n: len(nx.descendants(L, n)) for n in L}
    hubs = sorted(blast, key=lambda n: (-blast[n], n))[:15]
    # walls: N rungs and what lies past them
    walls = []
    for r in rows:
        if "N" in r["classes"]:
            kids = sorted(L.successors(r["id"]))
            walls.append(dict(id=r["id"], short=r["short"], branch=r["branch"],
                              children=[(k, G.nodes[k]["status"]) for k in kids],
                              gated_children=[k for k in kids if {"H", "G", "I"} & set(G.nodes[k]["classes"])]))
    # hypothesis gates
    gates = {}
    for h in sorted(HYPS):
        first = sorted(n for n in G if h in G.nodes[n]["hyps"])
        if not first:
            continue
        cone = set()
        for f in first:
            cone |= nx.descendants(L, f)
        gates[h] = dict(rungs=first, downstream=len(cone - set(first)))
    gam_rungs = sorted(n for n in G if "G" in G.nodes[n]["classes"])
    gates["Gamma"] = dict(rungs=gam_rungs, downstream=len(set().union(*[nx.descendants(L, g) for g in gam_rungs]) - set(gam_rungs)))
    # hand-overs
    Hc, ex = branch_map(G, L, out)
    T = global_map(G, L, out)
    for aud, ts in TARGETS.items():
        pass
    for name, tgt in (("L109", 109), ("L119", 119), ("L90", 90), ("L113", 113), ("L80", 80), ("L39", 39),
                      ("L68", 68), ("L47", 47)):
        anti_ladder(G, L, tgt, out, name)
    # pipelines
    pipes = []
    for pid, title, tg, note in PIPELINES:
        anc = set()
        for t in tg:
            anc |= nx.ancestors(L, t) | {t}
        hy = sorted(set().union(*[set(G.nodes[a]["hyps"]) for a in anc]))
        wallsin = sorted(a for a in anc if "N" in G.nodes[a]["classes"])
        imps = sorted(a for a in anc if "I" in G.nodes[a]["classes"])
        gam = any("G" in G.nodes[a]["classes"] for a in anc)
        pipes.append(dict(id=pid, title=title, targets=tg, note=note, rungs=len(anc), hyps=hy, walls=wallsin,
                          imports=len(imps), gamma=gam,
                          branches=sorted({G.nodes[a]["branch"] for a in anc}, key=lambda b: int(b[1:]))))
    stats = dict(rungs=len(rows), logical_edges=L.number_of_edges(),
                 aggregate_edges=sum(1 for _, _, k in G.edges(data="kind") if k == "aggregate"),
                 reduced_edges=T.number_of_edges(),
                 handover_edges=sum(Hc.values()),
                 by_class=collections.Counter(c for r in rows for c in r["classes"]),
                 by_branch={k: b - a + 1 for k, _, a, b, _ in BRANCHES})
    data = dict(source_sha256=hashlib.sha256(tex.encode()).hexdigest(), checks=checks, stats=stats,
                rows=[{k: r[k] for k in ("id", "short", "status", "classes", "hyps", "logical", "aggregate", "branch", "ref")}
                      for r in rows],
                inherited={str(k): v for k, v in inh.items()}, chains={str(k): v for k, v in chains.items()},
                global_longest_logical=glob_log, global_longest_with_aggregate=glob_all,
                blast={str(k): v for k, v in blast.items()}, hubs=hubs, walls=walls, gates=gates,
                handovers={f"{a}->{b}": dict(count=c, edges=ex[(a, b)]) for (a, b), c in sorted(Hc.items())},
                pipelines=pipes,
                targets=TARGETS)
    (out / "rg_ladder_org.json").write_text(json.dumps(data, indent=1, default=str))
    dep = metro_map(G, L, out)
    assumption_matrix(G, L, data, out)
    core = unconditional_core(G, L, out)
    aud = audits(G, L)
    data.update(depth={str(k): v for k, v in dep.items()}, unconditional_core=core, audits=aud)
    (out / "rg_ladder_org.json").write_text(json.dumps(data, indent=1, default=str))
    write_tables(data, rows, G, L, out)
    second_edition(tex, rows, G, L, data, out, walkspath)
    (out / "rg_ladder_org.json").write_text(json.dumps(data, indent=1, default=str, sort_keys=True) + "\n")
    print(json.dumps(dict(checks=[c["check"] for c in checks], stats={k: v for k, v in stats.items()
                                                                       if k != "by_branch"},
                          longest_logical=len(glob_log) - 1, longest_all=len(glob_all) - 1), default=str))


OPENED = {5: "declared higher structure: H-reg (L18), H-mono (L29), H-top (L66), $\\Gamma$, H-SI",
          7: "presentation-relative $\\Gamma$ (L6)", 10: "separate certificate per property (L11, L12)",
          13: "a declared task (L12 then selects exactly)", 17: "confidence sets (L16); window walls (L114)",
          29: "H-mono selects Fisher (\\v Cencov)", 31: "second-order contract (L32, L117); global $[K_N]$ (L120)",
          33: "protocols on the full law (L15, L43)", 36: "none inside the ladder (decision-theoretic order)",
          48: "confidence correspondences (L16, L47)", 52: "a declared class (L53 to L57)",
          53: "H-adm: BV lock (L54), contraction gate (L55)", 56: "operator certificates under H-adm (L57)",
          61: "rank-two strata; anchors", 62: "infinitesimal metric (L59); anchors (L102)",
          63: "counted channel and SI anchor (L95, L102, L109)", 65: "H-top: realization branches (L66)",
          70: "tame reduction (L69); enumeration open (L124)", 73: "window certificates only",
          77: "declared covariance (L80)", 79: "H-cov: canonical connection (L80)",
          94: "counted channel (L95) and H-SI (L102)", 96: "loss-calibrated channel (H-val in L109)",
          106: "stationary slices only (L104); otherwise open", 117: "H-split: declared complement",
          118: "H-type: constant multiplicity (L119)", 122: "hidden-room descent (L129); obstruction tower (L131)",
          127: "observer-relative classification (L124)", 128: "a declared dynamics (duration lane, L81 onward)",
          130: "the obstruction tower (L131) replaces a constructible classification"}


def chain_str(ch):
    return r"$\to$\allowbreak ".join(f"L{c}" for c in ch)


def esc(s):
    return s.replace("&", r"\&").replace("_", r"\_").replace("#", r"\#")


def write_tables(d, rows, G, L, out):
    T = []
    # master register: local vs effective status
    T.append(r"\begin{longtable}{@{}p{0.07\textwidth}p{0.3\textwidth}p{0.06\textwidth}p{0.13\textwidth}p{0.2\textwidth}p{0.06\textwidth}p{0.06\textwidth}@{}}")
    T.append(r"\toprule Rung & Name & Br. & Local status & Inherited hypotheses & Anc. & Cone\\\midrule\endhead")
    for r in rows:
        inh = d["inherited"][str(r["id"])]
        hy = ", ".join(h for h in inh["hyps"]) + (", $\\Gamma$" if inh["gamma"] else "")
        T.append(f"L{r['id']} & {esc(r['short'])} & {r['branch']} & {r['status']} & {hy if hy else '---'} & "
                 f"{inh['ancestors']} & {d['blast'][str(r['id'])]}\\\\")
    T.append(r"\bottomrule\end{longtable}")
    (out / "tab_register.tex").write_text("\n".join(T))
    # hand-overs
    H = [r"\begin{longtable}{@{}p{0.2\textwidth}p{0.08\textwidth}p{0.62\textwidth}@{}}",
         r"\toprule Hand-over & Edges & Exporting rung $\to$ importing rung\\\midrule\endhead"]
    for k, v in d["handovers"].items():
        a, b = k.split("->")
        H.append(f"{a} $\\to$ {b} & {v['count']} & " + ", ".join(
            f"L{u}\\,({esc(G.nodes[u]['short'])})$\\to$L{w}" for u, w in v["edges"]) + r"\\")
    H.append(r"\bottomrule\end{longtable}")
    (out / "tab_handovers.tex").write_text("\n".join(H))
    # walls
    W = [r"\begin{longtable}{@{}p{0.06\textwidth}p{0.22\textwidth}p{0.05\textwidth}p{0.27\textwidth}p{0.32\textwidth}@{}}",
         r"\toprule Wall & What it denies & Br. & Direct successors (status) & Opened by\\\midrule\endhead"]
    for w in d["walls"]:
        kids = "; ".join(f"L{k} ({esc(st)})" for k, st in w["children"]) or r"\emph{terminal}"
        W.append(f"L{w['id']} & {esc(w['short'])} & {w['branch']} & {kids} & {OPENED.get(w['id'], '---')}\\\\")
    W.append(r"\bottomrule\end{longtable}")
    (out / "tab_walls.tex").write_text("\n".join(W))
    # gates
    Gt = [r"\begin{tabular}{@{}lp{0.42\textwidth}r@{}}\toprule Hypothesis & Gated rungs & Downstream\\\midrule"]
    for h, v in sorted(d["gates"].items(), key=lambda kv: -kv[1]["downstream"]):
        nm = "$\\Gamma$" if h == "Gamma" else f"\\textsf{{H-{h}}}"
        Gt.append(f"{nm} & " + ", ".join(f"L{x}" for x in v["rungs"]) + f" & {v['downstream']}\\\\")
    Gt.append(r"\bottomrule\end{tabular}")
    (out / "tab_gates.tex").write_text("\n".join(Gt))
    # targets by audience
    for aud, ts in d["targets"].items():
        A = [r"\begin{tabular}{@{}p{0.065\textwidth}p{0.21\textwidth}rrp{0.31\textwidth}r@{}}",
             r"\toprule Target & Name & Anc. & Chain & Hypothesis budget & Imp.\\\midrule"]
        for t in ts:
            inh = d["inherited"][str(t)]
            hy = ", ".join(inh["hyps"]) + (", $\\Gamma$" if inh["gamma"] else "")
            A.append(f"L{t} & {esc(G.nodes[t]['short'])} & {inh['ancestors']} & "
                     f"{len(d['chains'][str(t)]['logical']) - 1} & {hy or '---'} & {inh['imports']}\\\\")
        A.append(r"\bottomrule\end{tabular}")
        (out / f"tab_targets_{aud}.tex").write_text("\n".join(A))
    # pipelines
    P = [r"\begin{longtable}{@{}p{0.04\textwidth}p{0.2\textwidth}p{0.11\textwidth}p{0.05\textwidth}p{0.22\textwidth}p{0.27\textwidth}@{}}",
         r"\toprule & Measurement / task & Target rungs & Rungs & Hypothesis budget & Walls on the way\\\midrule\endhead"]
    for p in d["pipelines"]:
        P.append(f"{p['id']} & {esc(p['title'])} & " + ", ".join(f"L{t}" for t in p["targets"]) +
                 f" & {p['rungs']} & " + (", ".join(p["hyps"]) or "---") + (", $\\Gamma$" if p["gamma"] else "")
                 + " & " + (", ".join(f"L{w}" for w in p["walls"]) or "---") + r"\\")
    P.append(r"\bottomrule\end{longtable}")
    (out / "tab_pipelines.tex").write_text("\n".join(P))
    # hubs
    Hb = [r"\begin{tabular}{@{}llrr@{}}\toprule Rung & Name & Forward cone & Branches reached\\\midrule"]
    for h in d["hubs"]:
        br = {G.nodes[x]["branch"] for x in nx.descendants(L, h)}
        Hb.append(f"L{h} & {esc(G.nodes[h]['short'])} & {d['blast'][str(h)]} & {len(br)}\\\\")
    Hb.append(r"\bottomrule\end{tabular}")
    (out / "tab_hubs.tex").write_text("\n".join(Hb))
    # chains
    C = [r"\begin{longtable}{@{}p{0.07\textwidth}p{0.075\textwidth}p{0.78\textwidth}@{}}",
         r"\toprule Target & Length & Longest logical dependency chain\\\midrule\endhead"]
    for t in (109, 113, 119, 90, 80, 39, 68, 131):
        ch = d["chains"][str(t)]["logical"]
        C.append(f"L{t} & {len(ch) - 1} & {chain_str(ch)}\\\\")
    C.append(f"global & {len(d['global_longest_logical']) - 1} & {chain_str(d['global_longest_logical'])}\\\\")
    C.append(r"\bottomrule\end{longtable}")
    (out / "tab_chains.tex").write_text("\n".join(C))




# ================================================================== additional views (appended)
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Rectangle

AUD_COL = {"lab": "#fde3c8", "geometry": "#d7e8f7", "physics": "#e3f2d6", "all": "#eeeeee"}


def depths(L):
    dep = {}
    for n in nx.topological_sort(L):
        preds = list(L.predecessors(n))
        dep[n] = 0 if not preds else 1 + max(dep[p] for p in preds)
    return dep


def metro_map(G, L, out):
    dep = depths(L)
    dep[110] = max(dep[n] for n in range(110)) + 1          # assembly umbrella column
    for n in nx.topological_sort(L):                        # re-propagate after moving L110
        preds = list(L.predecessors(n))
        if preds and n != 110:
            dep[n] = max(dep[n], 1 + max(dep[p] for p in preds))
    lanes = []; y = 0.0; pos = {}
    for k, name, a, b, aud in BRANCHES:
        cols = collections.defaultdict(list)
        for n in range(a, b + 1):
            cols[dep[n]].append(n)
        h = max(len(v) for v in cols.values())
        for d_, ns in cols.items():
            for j, n in enumerate(ns):
                pos[n] = (d_, -(y + 0.5 + j * 0.9))
        lanes.append((k, name, aud, y, h * 0.9 + 0.35)); y += h * 0.9 + 0.35
    W = max(dep.values()) + 1
    fig, ax = plt.subplots(figsize=(17, 0.42 * y + 1.5))
    for k, name, aud, y0, hh in lanes:
        ax.add_patch(Rectangle((-0.7, -(y0 + hh) + 0.15), W + 0.4, hh - 0.1, color=AUD_COL[aud], alpha=0.55, lw=0))
        ax.text(-0.75, -(y0 + 0.5), f"{k} {name}", ha="right", va="center", fontsize=8.5)
    for u, v in nx.transitive_reduction(L).edges():
        (x1, y1), (x2, y2) = pos[u], pos[v]
        hand = G.nodes[u]["branch"] != G.nodes[v]["branch"]
        col = BCOL[int(G.nodes[u]["branch"][1:])] if hand else "#9a9a9a"
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=6,
                                     connectionstyle=f"arc3,rad={0.12 if hand else 0.0}", color=col,
                                     lw=0.9 if hand else 0.5, alpha=0.85 if hand else 0.6, zorder=1))
    xa, ya = pos[110]
    ax.plot([xa - 0.35, xa - 0.35], [ya + 0.4, -(lanes[12][3] + lanes[12][4])], color="#555", lw=1.2, ls="--", zorder=1)
    ax.text(xa - 0.45, -(lanes[6][3]), "assembly umbrella: L110 <- L1..L109", rotation=90, fontsize=7, color="#555",
            ha="right", va="center")
    marker = {"F": "o", "I": "s", "H": "h", "G": "H", "N": "8", "O": "D", "input": "v"}
    for n, (x, yy) in pos.items():
        c = G.nodes[n]["classes"]; prim = c[0]
        col = CLASS_COLOR[prim] if not (prim == "F" and "H" in c) else CLASS_COLOR["H"]
        ax.scatter([x], [yy], s=230, marker=marker.get(prim, "o"), c=col, edgecolors="black", linewidths=0.6, zorder=3)
        ax.text(x, yy, str(n), fontsize=6.3, ha="center", va="center", zorder=4)
    for x in range(W):
        ax.text(x, 0.55, str(x), fontsize=7, ha="center", color="#666")
    ax.text(W / 2, 1.25, "logical depth (longest dependency chain from L0)", ha="center", fontsize=9)
    ax.set_xlim(-0.8, W); ax.set_ylim(-y - 0.3, 1.6); ax.axis("off")
    from matplotlib.lines import Line2D
    leg = [Line2D([0], [0], marker=marker[k], color="w", markerfacecolor=CLASS_COLOR[k], markeredgecolor="k",
                  markersize=9, label=lab) for k, lab in (("F", "forced"), ("I", "imported"), ("H", "hypothesis"),
                                                          ("G", "Gamma-conditional"), ("N", "no-go (wall)"),
                                                          ("O", "open"), ("input", "input"))]
    leg += [Line2D([0], [0], color="#9a9a9a", lw=1, label="within branch"),
            Line2D([0], [0], color="#d62728", lw=1.4, label="hand-over (coloured by source branch)")]
    ax.legend(handles=leg, loc="lower right", fontsize=8, ncol=3, frameon=True)
    fig.tight_layout(); fig.savefig(out / "fig_metro_map.pdf"); plt.close(fig)
    return dep


def assumption_matrix(G, L, d, out):
    hyps = sorted(HYPS); cols = hyps + ["Gamma"]
    rows_ = []
    for aud in ("physics", "geometry", "lab"):
        for t in d["targets"][aud]:
            rows_.append((f"L{t} {G.nodes[t]['short']} [{aud[:3]}]", t))
    import numpy as np
    M = np.zeros((len(rows_), len(cols)))
    for i, (_, t) in enumerate(rows_):
        anc = nx.ancestors(L, t) | {t}
        for j, h in enumerate(cols):
            if h == "Gamma":
                M[i, j] = any("G" in G.nodes[a]["classes"] for a in anc)
            else:
                M[i, j] = (2 if h in G.nodes[t]["hyps"] else 1) if any(h in G.nodes[a]["hyps"] for a in anc) else 0
    keep = [j for j in range(len(cols)) if M[:, j].any()]
    M = M[:, keep]; cols = [cols[j] for j in keep]
    fig, ax = plt.subplots(figsize=(0.42 * len(cols) + 4.5, 0.3 * len(rows_) + 1.6))
    from matplotlib.colors import ListedColormap
    ax.imshow(M, cmap=ListedColormap(["#ffffff", "#f2c46d", "#c0392b"]), aspect="auto", vmin=0, vmax=2)
    ax.set_xticks(range(len(cols))); ax.set_xticklabels(["$\\Gamma$" if c == "Gamma" else f"H-{c}" for c in cols],
                                                       rotation=60, ha="right", fontsize=8)
    ax.set_yticks(range(len(rows_))); ax.set_yticklabels([r[0] for r in rows_], fontsize=7.5)
    for i in range(len(rows_) + 1):
        ax.axhline(i - 0.5, color="#ddd", lw=0.5)
    for j in range(len(cols) + 1):
        ax.axvline(j - 0.5, color="#ddd", lw=0.5)
    for b in (8, 16):
        ax.axhline(b - 0.5, color="k", lw=1)
    ax.set_title("Assumption budget: red = gated at the target itself, amber = inherited", fontsize=9)
    fig.tight_layout(); fig.savefig(out / "fig_assumption_matrix.pdf"); plt.close(fig)


def unconditional_core(G, L, out):
    core = [n for n in L if not any(G.nodes[a]["hyps"] or "G" in G.nodes[a]["classes"]
                                    for a in nx.ancestors(L, n) | {n})]
    T = nx.transitive_reduction(L.subgraph(core))
    s = ['digraph C { rankdir=LR; nodesep=0.12; ranksep=0.3;',
         '  node [fontsize=8, fontname="Helvetica", margin="0.04,0.02"];', '  edge [arrowsize=0.45, color="#888888"];']
    for n in sorted(core):
        s.append(dot_node(n, G))
    for u, v in T.edges():
        s.append(f"  n{u} -> n{v};")
    s.append("}")
    render("\n".join(s), out / "fig_unconditional_core")
    return core


def budget(Gl, n):
    hy = set(Gl.nodes[n]["hyps"]); gam = "G" in Gl.nodes[n]["classes"]
    for a in nx.ancestors(Gl, n):
        hy |= set(Gl.nodes[a]["hyps"]); gam = gam or "G" in Gl.nodes[a]["classes"]
    return hy, gam


def audits(G, L):
    res = []
    base = {n: budget(L, n) for n in L}
    def effect(Lm, label, desc, focus):
        changed = []
        for n in Lm:
            b0, b1 = base[n], budget(Lm, n)
            if b0 != b1:
                changed.append((n, sorted(b0[0] - b1[0]), b0[1] and not b1[1]))
        res.append(dict(id=label, description=desc, rungs_changed=len(changed),
                        examples=[(n, rm) for n, rm, _ in changed if n in focus],
                        removed_counts=collections.Counter(h for _, rm, _ in changed for h in rm)))
    # A1: closure through transport
    L1_ = L.copy(); L1_.remove_edge(111, 112); L1_.add_edge(110, 112)
    effect(L1_, "A1", "L112 (dispatcher) depends on L111 (global transport) and thus on L80 (H-cov, H-resp). "
           "Proposed: L112 <- L110; L111 a sibling module.", [112, 113, 114, 115, 116, 123])
    # A2: tangent sequence bundles the completeness defect
    L2_ = L.copy(); L2_.remove_edge(9, 18)
    effect(L2_, "A2", "L18 (tangent sequence) depends on L9 (orbit-quotient, H-sound, H-compl) only for the "
           "completeness-defect clause. Proposed: split L18; the tangent sequence needs L2 and H-reg only.",
           [19, 28, 59, 90, 109, 119])
    # A3: L80 bundles the physical reading
    L3_ = L.copy(); L3_.nodes[80]["hyps"] = ["cov"]
    effect(L3_, "A3", "L80 carries H-resp only for its physical corollary (Physical Curvature). Proposed: "
           "move H-resp to a corollary rung; L80 itself H-cov.", [111, 112, 113, 115, 123])
    return res



# ================================================================== second edition: companions, anti-connectors,
# destructor / dispatcher, unity audit, walk validation
FEATURED = ["From the Wall-Tap", "Wall-Tap Delay, Structural", "RG Topology", "Ignorance Before Uncertainty", "Hessian Theorem",
            "Coherence Geometry", "Quantum Mechanics", "One World, Two Protocols", "Monotonicity and the Lorentz Sign",
            "Tensor Derivation", "Physical Dynamics", "Quantum Gravity", "Observer Bounds", "GR Automation",
            "Physical Path", "Light as Emission"]
PROFILES = {  # declaration profiles for the dispatcher
    "none": set(),
    "laboratory": {"reg", "nuis", "unif", "sens", "sound", "compl", "coh", "task", "exch", "adm"},
    "physics": {"reg", "nuis", "unif", "sens", "sound", "compl", "coh", "task", "exch", "adm", "top", "int", "SI", "med", "val",
                "stat", "mono", "hell", "Gamma"},
}
ANTI_PAIRS = [(39, 109), (49, 68)]
EDITORIAL_SPLITS, EDITORIAL_MERGES = {38}, {6, 111}


def parse_companions(tex):
    i = tex.index(r"Companion & Attaches at & Content and status"); j = tex.index(r"\end{longtable}", i)
    comps = []
    for line in tex[i:j].splitlines()[1:]:
        parts = line.strip().split(" & ", 2)
        if len(parts) != 3:
            continue
        name, raw, content = parts
        rungs = set()
        for a, b in re.findall(r"L(\d+)--L(\d+)", raw):
            rungs |= set(range(int(a), int(b) + 1))
        for a in re.findall(r"(?<!-)L(\d+)(?!\d)(?!--)", raw):
            rungs.add(int(a))
        comps.append(dict(name=name, attach_raw=raw, rungs=sorted(rungs), meta=raw.strip().startswith("all")))
    return comps


def cone_of(L, rungs):
    out = set(rungs)
    for r in rungs:
        out |= nx.ancestors(L, r)
    return out


def budget_of(G, cone):
    hy = set()
    for a in cone:
        hy |= set(G.nodes[a]["hyps"])
    if any("G" in G.nodes[a]["classes"] for a in cone):
        hy.add("Gamma")
    return hy


def meets(L, common):
    """Maximal common ancestors: elements of the common cone with no descendant inside it."""
    return sorted(u for u in common if not (nx.descendants(L, u) & common))


def toolkit_null(G, L):
    """Scattered-toolkit null model: keep dependencies inside a branch; replace every hand-over by a dependency on L0."""
    T = nx.DiGraph(); T.add_nodes_from(L.nodes(data=True))
    for u, v in L.edges():
        if G.nodes[u]["branch"] == G.nodes[v]["branch"]:
            T.add_edge(u, v)
        else:
            T.add_edge(0, v)
    return T


def unity_metrics(G, Lg):
    import statistics
    n = Lg.number_of_nodes()
    anc = {v: nx.ancestors(Lg, v) | {v} for v in Lg}
    sinks = [v for v in Lg if Lg.out_degree(v) == 0]
    spine = set.intersection(*[anc[v] for v in sinks])
    branches = [k for k, *_ in BRANCHES]
    rep = {}
    for k, _, a, b, _ in BRANCHES:                               # representative: the rung with the largest cone in the branch
        rep[k] = max(range(a, b + 1), key=lambda v: (len(anc[v]), -v))
    pair_common = []
    for i, bi in enumerate(branches[1:], 1):
        for bj in branches[i + 1:]:
            pair_common.append(len(anc[rep[bi]] & anc[rep[bj]]))
    U = Lg.to_undirected()
    def comps(removed):
        H = U.copy(); H.remove_nodes_from(removed); return nx.number_connected_components(H)
    root_only = 0
    for k, _, a, b, _ in BRANCHES[1:]:
        ext = {u for v in range(a, b + 1) for u in Lg.predecessors(v) if not a <= u <= b}
        root_only += int(ext <= {0})
    mix = [len({G.nodes[u]["branch"] for u in anc[v]}) for v in Lg if G.nodes[v]["branch"] != "B0"]
    hand = sum(1 for u, v in Lg.edges() if G.nodes[u]["branch"] != G.nodes[v]["branch"])
    pairs_beyond_root = 0; total_pairs = 0
    late = [v for v in Lg if G.nodes[v]["branch"] != "B0"]
    for i, u in enumerate(late):
        for v in late[i + 1:]:
            if G.nodes[u]["branch"] != G.nodes[v]["branch"]:
                total_pairs += 1; pairs_beyond_root += int(len(anc[u] & anc[v]) > 1)
    return dict(sinks=len(sinks), common_spine=sorted(spine), components_without_root=comps({0}),
                components_without_spine=comps(spine), branches_hanging_from_root_only=root_only,
                min_pair_common_cone=min(pair_common), median_pair_common_cone=statistics.median(pair_common),
                median_branches_in_cone=statistics.median(mix), handover_edges=hand,
                cross_branch_pairs_sharing_more_than_root=round(pairs_beyond_root / total_pairs, 4))


def dispatch(G, cone, declared):
    need = budget_of(G, cone)
    if not need:
        return "FORCED", []
    missing = sorted(need - declared)
    return ("LOCKED" if not missing else "BLOCKED"), missing


def anti_connector_fig(G, L, s_, t_, out):
    cs, ct = cone_of(L, [s_]), cone_of(L, [t_])
    common = cs & ct; mt = meets(L, common)
    nodes = cs | ct
    T = nx.transitive_reduction(L.subgraph(nodes))
    s = ['digraph A { rankdir=TB; nodesep=0.14; ranksep=0.26;',
         '  node [fontsize=8, fontname="Helvetica", margin="0.04,0.02", style=filled];', '  edge [arrowsize=0.45, dir=back];']
    for n in sorted(nodes):
        fill = "#d9c7ef" if n in common else ("#cfe2f7" if n in cs else "#d5ecc8")
        extra = ", peripheries=2" if n in (s_, t_) else (", penwidth=2.2, color=\"#6a3d9a\"" if n in mt else "")
        s.append(f'  n{n} [label="L{n}\\n{G.nodes[n]["short"]}", shape=box, fillcolor="{fill}"{extra}];')
    for u, v in T.edges():
        col = "#6a3d9a" if (u in common and v in common) else "#888888"
        s.append(f'  n{v} -> n{u} [color="{col}"];')
    s.append(f'  {{ rank=same; n{s_}; n{t_}; }}')
    s.append("}")
    render("\n".join(s), out / f"fig_anticonn_L{s_}_L{t_}")
    return dict(pair=[s_, t_], cone_sizes=[len(cs), len(ct)], common=len(common), meets=mt,
                shared_fraction=round(len(common) / min(len(cs), len(ct)), 4))


def walks_fig(G, walks, out):
    s = ['digraph W { rankdir=LR; nodesep=0.2; ranksep=0.3;',
         '  node [fontsize=8, fontname="Helvetica", shape=box, style="rounded,filled", margin="0.05,0.03"];',
         '  edge [arrowsize=0.5, fontsize=7, fontname="Helvetica"];']
    for wi, (key, w) in enumerate(walks.items()):
        s.append(f'  subgraph cluster_{wi} {{ label="{w["title"]}   [{", ".join(w["groups"])}]"; fontsize=10; style=rounded; color="#999999";')
        for st in w["stations"]:
            bi = int(G.nodes[st]["branch"][1:])
            s.append(f'    w{wi}_{st} [label="L{st}\\n{G.nodes[st]["short"]}\\n{G.nodes[st]["branch"]}", fillcolor="{BCOL[bi]}33"];')
        for a, b in zip(w["stations"][:-1], w["stations"][1:]):
            direct = "solid" if w["direct"][f"{a}-{b}"] else "dashed"
            s.append(f'    w{wi}_{a} -> w{wi}_{b} [style={direct}];')
        s.append("  }")
    s.append("}")
    render("\n".join(s), out / "fig_walks")


def second_edition(tex, rows, G, L, data, out, walkspath):
    import numpy as np
    checks = data["checks"]
    def chk(name, ok, detail=""):
        checks.append(dict(check=name, passed=bool(ok), detail=str(detail)))
        if not ok:
            raise AssertionError(name + " " + str(detail))
    # O10: branch boundaries against printed headers
    hs = {a for a, _ in header_starts(tex)}; bs = {a for _, _, a, _, _ in BRANCHES}
    chk("O10 branch boundaries match printed headers up to declared splits and merges",
        bs - hs == EDITORIAL_SPLITS and hs - bs == EDITORIAL_MERGES, (sorted(bs - hs), sorted(hs - bs)))
    dep = {int(k): v for k, v in data["depth"].items()}
    # ---------------- companions
    comps = parse_companions(tex)
    chk("O11 every companion attach rung exists", all(max(c["rungs"], default=0) <= 133 for c in comps))
    for c in comps:
        cone = cone_of(L, c["rungs"]) if not c["meta"] else set(L.nodes)
        c["cone"] = sorted(cone)
        c["budget"] = sorted(budget_of(G, cone))
        c["walls"] = sorted(a for a in cone if "N" in G.nodes[a]["classes"])
        c["branches"] = sorted({G.nodes[a]["branch"] for a in cone}, key=lambda b: int(b[1:]))
        c["attach_branches"] = sorted({G.nodes[a]["branch"] for a in c["rungs"]}, key=lambda b: int(b[1:]))
        c["deepest"] = max(c["rungs"], key=lambda v: (dep[v], v)) if c["rungs"] else None
        c["depth"] = dep[c["deepest"]] if c["rungs"] else None
    real = [c for c in comps if not c["meta"]]
    chk("O12 every non-meta companion has an attach rung", all(c["rungs"] for c in real), [c["name"] for c in real if not c["rungs"]])
    # ---------------- stations
    stations = []
    for k, name, a, b, aud in BRANCHES:
        att = [c["name"] for c in real if k in c["attach_branches"]]
        stations.append(dict(branch=k, name=name, first=a, last=b, role=ROLE[k], companions=len(att)))
    # ---------------- anti-connectors among featured companions
    feat = []
    for key in FEATURED:
        m = [c for c in real if c["name"].startswith(key)]
        chk(f"O13 featured companion found: {key}", len(m) == 1, [c["name"] for c in m])
        feat.append(m[0])
    nF = len(feat); M = np.zeros((nF, nF)); Cn = np.zeros((nF, nF), int)
    for i in range(nF):
        for j in range(nF):
            ci, cj = set(feat[i]["cone"]), set(feat[j]["cone"])
            Cn[i, j] = len(ci & cj); M[i, j] = len(ci & cj) / min(len(ci), len(cj))
    all_common = set.intersection(*[set(c["cone"]) for c in real])
    pair_tab = []
    for a_, b_ in (("Ignorance Before Uncertainty", "Coherence Geometry"), ("Coherence Geometry", "Tensor Derivation"),
                   ("Tensor Derivation", "Quantum Gravity"), ("Quantum Gravity", "GR Automation"),
                   ("Observer Bounds", "GR Automation"), ("One World, Two Protocols", "Tensor Derivation"),
                   ("RG Topology", "Physical Dynamics"), ("Ignorance Before Uncertainty", "Observer Bounds")):
        ca = next(c for c in feat if c["name"].startswith(a_)); cb = next(c for c in feat if c["name"].startswith(b_))
        common = set(ca["cone"]) & set(cb["cone"])
        pair_tab.append(dict(a=ca["name"], b=cb["name"], cones=[len(ca["cone"]), len(cb["cone"])], common=len(common),
                             meets=meets(L, common), shared=round(len(common) / min(len(ca["cone"]), len(cb["cone"])), 3)))
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(9.2, 7.6))
    im = ax.imshow(M, cmap="Purples", vmin=0, vmax=1)
    labs = [c["name"].split(" (")[0][:30] for c in feat]
    ax.set_xticks(range(nF)); ax.set_xticklabels(labs, rotation=60, ha="right", fontsize=7.5)
    ax.set_yticks(range(nF)); ax.set_yticklabels(labs, fontsize=7.5)
    for i in range(nF):
        for j in range(nF):
            ax.text(j, i, str(Cn[i, j]), ha="center", va="center", fontsize=6.3, color="white" if M[i, j] > 0.6 else "black")
    ax.set_title("Anti-connector matrix: common cone (number) and shared fraction (shade)", fontsize=9)
    fig.colorbar(im, ax=ax, fraction=0.04, pad=0.02)
    fig.tight_layout(); fig.savefig(out / "fig_anticonn_matrix.pdf"); plt.close(fig)
    anti = [anti_connector_fig(G, L, a_, b_, out) for a_, b_ in ANTI_PAIRS]
    # ---------------- unity audit against the toolkit null
    T = toolkit_null(G, L)
    uni, uni_null = unity_metrics(G, L), unity_metrics(G, T)
    chk("U1 the ladder is not root-star: no branch hangs from the root only", uni["branches_hanging_from_root_only"] == 0, uni)
    chk("U2 connected without the root", uni["components_without_root"] == 1, uni["components_without_root"])
    chk("U3 null model is detected", uni_null["branches_hanging_from_root_only"] == len(BRANCHES) - 1
        and uni_null["components_without_root"] > 1 and uni_null["min_pair_common_cone"] == 1, uni_null)
    featured_min = float(np.min(M + np.eye(nF) * 9))
    # ---------------- destructor tables
    gate_rows = []
    for h, v in data["gates"].items():
        key = "Gamma" if h == "Gamma" else h
        hit = [c["name"] for c in real if key in c["budget"]]
        gate_rows.append(dict(gate=h, rungs_lost=v["downstream"] + len(v["rungs"]), companions=len(hit)))
    gate_rows.sort(key=lambda d: (-d["companions"], -d["rungs_lost"], d["gate"]))
    rung_rows = []
    for v in L:
        hit = sum(1 for c in real if v in c["cone"])
        rung_rows.append(dict(rung=v, forward_cone=data["blast"][str(v)], companions=hit))
    rung_rows.sort(key=lambda d: (-d["companions"], -d["forward_cone"], d["rung"]))
    free = [c["name"] for c in real if not c["budget"]]
    L2_ = L.copy(); L2_.remove_edge(9, 18)                       # audit A2 applied: what the companions would then inherit
    after_a2 = dict(still_sound=sum(1 for c in real if "sound" in budget_of(G, cone_of(L2_, c["rungs"]))),
                    now_sound=sum(1 for c in real if "sound" in c["budget"]))
    # ---------------- dispatcher
    disp = []
    for c in feat:
        row = dict(name=c["name"])
        for pn, decl in PROFILES.items():
            st, missing = dispatch(G, set(c["cone"]), decl); row[pn] = dict(status=st, missing=missing)
        disp.append(row)
    # ---------------- walks: validate the executable witnesses against the printed ladder
    walks_out = None
    if walkspath and pathlib.Path(walkspath).exists():
        W = json.loads(pathlib.Path(walkspath).read_text())
        chk("W-a the walks battery passed", W.get("failures") == [], W.get("failures"))
        groups = {k: v for k, v in W.items() if isinstance(v, dict) and "edges" in v}
        bad_edges, edge_list = [], []
        for gk, gv in sorted(groups.items()):
            for u, v in gv["edges"]:
                okk = u in nx.ancestors(L, v)
                edge_list.append(dict(group=gk, edge=[u, v], direct=bool(L.has_edge(u, v)),
                                      handover=G.nodes[u]["branch"] != G.nodes[v]["branch"]))
                if not okk:
                    bad_edges.append((gk, u, v))
        chk("W-b every witnessed connector is a dependency of the printed ladder", not bad_edges, bad_edges)
        walks = W["walks"]
        for key, w in walks.items():
            w["direct"] = {}
            for a_, b_ in zip(w["stations"][:-1], w["stations"][1:]):
                chk(f"W-c walk {key}: L{a_} is an ancestor of L{b_}", a_ in nx.ancestors(L, b_))
                w["direct"][f"{a_}-{b_}"] = bool(L.has_edge(a_, b_))
            cone = cone_of(L, [w["stations"][-1]])
            w["budget"] = sorted(budget_of(G, cone)); w["cone"] = len(cone)
            w["branches"] = sorted({G.nodes[s_]["branch"] for s_ in w["stations"]}, key=lambda b: int(b[1:]))
            w["in_anti_ladder"] = all(s_ in cone for s_ in w["stations"])
        touched = sorted({r for gv in groups.values() for r in gv["rungs"]})
        br_touched = sorted({G.nodes[r]["branch"] for r in touched}, key=lambda b: int(b[1:]))
        uniq = {tuple(e["edge"]) for e in edge_list}
        walks_fig(G, walks, out)
        walks_out = dict(source_sha256=W.get("source_sha256"), groups=sorted(groups), edges=edge_list, walks=walks,
                         rungs_touched=touched, branches_touched=br_touched, distinct_edges=len(uniq),
                         handover_edges_witnessed=len({tuple(e["edge"]) for e in edge_list if e["handover"]}),
                         direct_edges_witnessed=len({tuple(e["edge"]) for e in edge_list if e["direct"]}))
    data.update(companions=[{k: c[k] for k in ("name", "attach_raw", "rungs", "meta", "budget", "walls", "branches",
                                                "attach_branches", "deepest", "depth")} | {"cone": len(c["cone"])} for c in comps],
                stations=stations, anticonn=dict(featured=[c["name"] for c in feat], shared=M.round(4).tolist(),
                                                 common=Cn.tolist(), pairs=pair_tab, rung_pairs=anti,
                                                 common_to_all_companions=sorted(all_common), featured_min_shared=round(featured_min, 4)),
                unity=dict(ladder=uni, toolkit_null=uni_null), destructor=dict(gates=gate_rows, rungs=rung_rows[:14],
                                                                               hypothesis_free_companions=free, audit_a2_on_companions=after_a2),
                dispatch=disp, walks=walks_out, checks=checks)
    # ---------------- tables
    S = [r"\begin{longtable}{@{}p{0.05\textwidth}p{0.2\textwidth}p{0.1\textwidth}p{0.46\textwidth}p{0.08\textwidth}@{}}",
         r"\toprule & Station & Rungs & Role in the single structure & Comp.\\\midrule\endhead"]
    for sd in stations:
        S.append(f"{sd['branch']} & {esc(sd['name'])} & L{sd['first']}--L{sd['last']} & {esc(sd['role'])} & {sd['companions']}\\\\")
    S.append(r"\bottomrule\end{longtable}")
    (out / "tab_stations.tex").write_text("\n".join(S))
    C = [r"\begin{longtable}{@{}p{0.27\textwidth}p{0.2\textwidth}rrrp{0.25\textwidth}@{}}",
         r"\toprule Companion & Attaches at & Cone & Br. & Walls & Hypothesis budget\\\midrule\endhead"]
    for c in comps:
        if c["meta"]:
            C.append(f"{esc(c['name'])} & {c['attach_raw'].split('(')[0].strip()} & all & all & --- & (reads every rung)\\\\")
            continue
        hy = ", ".join("$\\Gamma$" if h == "Gamma" else h for h in c["budget"]) or "---"
        raw = re.sub(r", A\d(--A\d)?", "", c["attach_raw"])
        C.append(f"{esc(c['name'])} & {raw} & {len(c['cone'])} & {len(c['branches'])} & {len(c['walls'])} & {hy}\\\\")
    C.append(r"\bottomrule\end{longtable}")
    (out / "tab_companions.tex").write_text("\n".join(C))
    names = dict(sinks="terminal rungs (sinks)", components_without_root="connected components after deleting L0",
                 components_without_spine="connected components after deleting the common spine",
                 branches_hanging_from_root_only="branches whose only outside dependency is L0",
                 min_pair_common_cone="smallest common cone of two branch representatives",
                 median_pair_common_cone="median common cone of two branch representatives",
                 median_branches_in_cone="median number of branches inside a rung's cone",
                 handover_edges="hand-over edges",
                 cross_branch_pairs_sharing_more_than_root="cross-branch rung pairs sharing more than L0")
    Ut = [r"\begin{tabular}{@{}p{0.56\textwidth}rr@{}}\toprule Quantity & Ladder & Toolkit null\\\midrule"]
    Ut.append("common spine of all terminal rungs & " + ", ".join(f"L{v}" for v in uni["common_spine"]) + " & "
              + ", ".join(f"L{v}" for v in uni_null["common_spine"]) + r"\\")
    def fmtu(k, v):
        return f"{100 * v:.1f}\\%" if k == "cross_branch_pairs_sharing_more_than_root" else f"{v:g}"
    for k, lab in names.items():
        Ut.append(f"{lab} & {fmtu(k, uni[k])} & {fmtu(k, uni_null[k])}\\\\")
    Ut.append(r"\bottomrule\end{tabular}")
    (out / "tab_unity.tex").write_text("\n".join(Ut))
    Pt = [r"\begin{longtable}{@{}p{0.2\textwidth}p{0.2\textwidth}rrp{0.3\textwidth}@{}}",
          r"\toprule Result A & Result B & Common & Shared & Meets (where the two become one)\\\midrule\endhead"]
    for pr in pair_tab:
        Pt.append(f"{esc(pr['a'].split(' (')[0])} & {esc(pr['b'].split(' (')[0])} & {pr['common']} & {pr['shared']:.2f} & "
                  + ", ".join(f"L{m}" for m in pr["meets"]) + r"\\")
    Pt.append(r"\bottomrule\end{longtable}")
    (out / "tab_anticonn.tex").write_text("\n".join(Pt))
    Dg = [r"\begin{tabular}{@{}lrr@{}}\toprule Gate not declared & Rungs lost & Companions affected\\\midrule"]
    for d_ in gate_rows:
        nm = "$\\Gamma$" if d_["gate"] == "Gamma" else f"\\textsf{{H-{d_['gate']}}}"
        Dg.append(f"{nm} & {d_['rungs_lost']} & {d_['companions']}\\\\")
    Dg.append(r"\bottomrule\end{tabular}")
    (out / "tab_destructor_gates.tex").write_text("\n".join(Dg))
    Dr = [r"\begin{tabular}{@{}llrr@{}}\toprule Rung & Name & Forward cone & Companions resting on it\\\midrule"]
    for d_ in rung_rows[:14]:
        Dr.append(f"L{d_['rung']} & {esc(G.nodes[d_['rung']]['short'])} & {d_['forward_cone']} & {d_['companions']}\\\\")
    Dr.append(r"\bottomrule\end{tabular}")
    (out / "tab_destructor_rungs.tex").write_text("\n".join(Dr))
    Dp = [r"\begin{longtable}{@{}p{0.26\textwidth}p{0.09\textwidth}p{0.3\textwidth}p{0.25\textwidth}@{}}",
          r"\toprule Companion & Budget & Laboratory profile: missing & Physics profile: missing\\\midrule\endhead"]
    def fm(d_):
        if d_["status"] == "FORCED":
            return "FORCED"
        if d_["status"] == "LOCKED":
            return "LOCKED"
        return ", ".join("$\\Gamma$" if h == "Gamma" else h for h in d_["missing"])
    for row in disp:
        st0 = str(len(row["none"]["missing"]))
        Dp.append(f"{esc(row['name'].split(' (')[0])} & {st0} & {fm(row['laboratory'])} & {fm(row['physics'])}\\\\")
    Dp.append(r"\bottomrule\end{longtable}")
    (out / "tab_dispatch.tex").write_text("\n".join(Dp))
    if walks_out:
        Wt = [r"\begin{longtable}{@{}p{0.19\textwidth}p{0.3\textwidth}p{0.1\textwidth}p{0.08\textwidth}p{0.24\textwidth}@{}}",
              r"\toprule Walk & Stations & Witness & Cone & Budget of the endpoint\\\midrule\endhead"]
        for key, w in walks_out["walks"].items():
            hy = ", ".join("$\\Gamma$" if h == "Gamma" else h for h in w["budget"]) or "---"
            Wt.append(f"{esc(w['title'].split(':')[0])} & " + r"$\to$\allowbreak ".join(f"L{s_}" for s_ in w["stations"])
                      + f" & {', '.join(w['groups'])} & {w['cone']} & {hy}\\\\")
        Wt.append(r"\bottomrule\end{longtable}")
        (out / "tab_walks.tex").write_text("\n".join(Wt))
        W = json.loads(pathlib.Path(walkspath).read_text())
        meth = W["W1"]["methods"]
        Sf = [r"\begin{tabular}{@{}l" + "c" * len(meth) + r"c@{}}\toprule Root law of the tap & " + " & ".join(m.split(" ")[0] for m in meth)
              + r" & Expected\\\midrule"]
        for law in ("single_wall", "two_walls", "gain_contrast", "anchored", "anchored_calibrated", "attenuation"):
            Sf.append(esc(law.replace("_", " ")) + " & " + " & ".join(str(v) for v in W["W1"]["table"][law]) + f" & {W['W1']['expected'][law]}\\\\")
        Sf.append(r"\midrule mixed pipeline (canary) & " + " & ".join(str(v) for v in W["W10"]["mixed_row"]) + r" & not constant\\")
        Sf.append(r"\bottomrule\end{tabular}")
        (out / "tab_sharedfate.tex").write_text("\n".join(Sf))
        Wg = [r"\begin{longtable}{@{}p{0.06\textwidth}p{0.34\textwidth}p{0.5\textwidth}@{}}",
              r"\toprule Group & Rungs witnessed & Ladder edges witnessed (bold: hand-over)\\\midrule\endhead"]
        for gk in sorted(walks_out["groups"], key=lambda s_: int(s_[1:])):
            es = [e for e in walks_out["edges"] if e["group"] == gk]
            Wg.append(f"{gk} & " + ", ".join(f"L{r_}" for r_ in W[gk]["rungs"]) + " & " + ", ".join(
                (r"\textbf{" if e["handover"] else "") + f"L{e['edge'][0]}$\\to$L{e['edge'][1]}" + ("}" if e["handover"] else "")
                for e in es) + r"\\")
        Wg.append(r"\bottomrule\end{longtable}")
        (out / "tab_witness.tex").write_text("\n".join(Wg))
    # companion assumption matrix
    hyps = sorted(HYPS) + ["Gamma"]
    Mx = np.array([[1.0 if h in c["budget"] else 0.0 for h in hyps] for c in real])
    keep = [j for j in range(len(hyps)) if Mx[:, j].any()]
    fig, ax = plt.subplots(figsize=(0.4 * len(keep) + 4.8, 0.27 * len(real) + 1.5))
    from matplotlib.colors import ListedColormap
    ax.imshow(Mx[:, keep], cmap=ListedColormap(["#ffffff", "#f2c46d"]), aspect="auto", vmin=0, vmax=1)
    ax.set_xticks(range(len(keep))); ax.set_xticklabels(["$\\Gamma$" if hyps[j] == "Gamma" else f"H-{hyps[j]}" for j in keep],
                                                       rotation=60, ha="right", fontsize=8)
    ax.set_yticks(range(len(real))); ax.set_yticklabels([c["name"].split(" (")[0][:42] for c in real], fontsize=7.2)
    for i in range(len(real) + 1):
        ax.axhline(i - 0.5, color="#ddd", lw=0.5)
    for j in range(len(keep) + 1):
        ax.axvline(j - 0.5, color="#ddd", lw=0.5)
    ax.set_title("Dispatcher matrix: hypotheses each companion inherits through its attachment rungs", fontsize=9)
    fig.tight_layout(); fig.savefig(out / "fig_companion_matrix.pdf"); plt.close(fig)
    print(json.dumps(dict(unity=uni, toolkit_null=uni_null, companions=len(comps), meta=len(comps) - len(real),
                          featured_min_shared=round(featured_min, 4), common_to_all=sorted(all_common),
                          walks=None if not walks_out else dict(distinct_edges=walks_out["distinct_edges"],
                                                                 handover=walks_out["handover_edges_witnessed"],
                                                                 direct=walks_out["direct_edges_witnessed"],
                                                                 branches=walks_out["branches_touched"])), default=str))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--tex", default="final_print.tex"); ap.add_argument("--out", default="build")
    ap.add_argument("--walks", default="rg_walks_results.json")
    a = ap.parse_args(); main(a.tex, a.out, a.walks)
