"""RG structural walks from the wall-tap (print: 'RG - Ladder Organization', second edition).

One experiment: tap, wait, record the echo. Parameters: distance x to the wall, speed c of the medium (and, in variants,
further walls, gains, an anchor path). The quotient coordinate is the delay tau = 2x/c.

Claim under attack: RG is ONE construction (the kernel of a record law, the quotient, the forced Fisher form on the
quotient and its dual), applied at every station; stations hand objects to one another. A scattered toolkit would compute
unrelated things at each station. The battery therefore
  (1) uses a single function resolve() at every station;
  (2) computes the hole dimension of six root laws by five unrelated methods and demands that each row is constant
      (shared fate); a deliberately mixed pipeline must break the row (toolkit canary);
  (3) witnesses named hand-overs of the printed ladder on this one system, each with a destructor.
Every group lists the rungs and ladder edges it witnesses; the organization engine checks them against the printed ladder.

Groups
  W0  the construction: resolve(), descent test, naturality under chart change
  W1  shared-fate table: six root laws x five methods
  W2  unit walk: no internal unit; more walls do not help; an anchor closes; ratio scale; closed-form bound
  W3  gauge walk: relabeling generators are exactly the unremovable Fisher nulls; interior hole; rods
  W4  wall walk: the fold; rank drop, two-point fibre, n^(-1/4) modulus; a signed channel splits it
  W5  cone walk: no distinguishability before arrival; geometry from delays up to the unit; one negative direction; wind
  W6  clock walk: affine clock gauge; cocycle; twisted overlap; uniform wind exact, rotation gives Sagnac holonomy
  W7  protocol walk: one entity, fine and coarse protocols; coarse law is a garbling; data processing; which-path hole
  W8  One World as gluing (Fine): classical section iff CHSH <= 2; one quantum state reaches 2 sqrt 2; PR box excluded
  W9  observer floor: Cramer-Rao on the quotient attained; no bound off the quotient
  W10 toolkit canary and connector destructors

Run: python rg_walks.py   (numpy, scipy, sympy). Seed 20261111. Deterministic. Writes rg_walks_results.json.
"""
import hashlib, itertools, json, math, sys
from pathlib import Path
import numpy as np
import sympy as s
from scipy.integrate import solve_ivp
from scipy.optimize import linprog
from scipy.stats import norm

HERE = Path(__file__).resolve().parent
SEED = 20261111
rng = np.random.default_rng(SEED)
R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.10g}')


# ------------------------------------------------------------------------------------------- the one construction
def resolve(J, Sigma=None, tol=1e-9):
    """Kernel, quotient, Fisher form and dual of a linearized record law. Used at every station."""
    J = np.atleast_2d(np.asarray(J, float)); k, n = J.shape
    Sinv = np.eye(k) if Sigma is None else np.linalg.inv(Sigma)
    F = J.T @ Sinv @ J
    w, V = np.linalg.eigh(F)
    cut = tol * max(float(w.max()), 1e-300)
    hole = V[:, w <= cut]; res = V[:, w > cut]; wr = w[w > cut]
    dual = res @ np.diag(1 / wr) @ res.T                         # efficient covariance, defined on the quotient only
    return dict(F=F, hole=hole, hole_dim=int(hole.shape[1]), rank=int(res.shape[1]), resolved=res, dual=dual)


def descends(grad, res, tol=1e-8):
    """A function descends to the quotient iff its gradient annihilates the hole."""
    g = np.asarray(grad, float)
    return bool(res['hole_dim'] == 0 or np.max(np.abs(res['hole'].T @ g)) <= tol * max(1.0, float(np.max(np.abs(g)))))


def variance(grad, res):
    """Cramer-Rao bound of a descending function; None if it does not descend."""
    return float(np.asarray(grad) @ res['dual'] @ np.asarray(grad)) if descends(grad, res) else None


def subspace_gap(A, B):
    """Largest principal angle (sine) between column spans."""
    QA, QB = np.linalg.qr(A)[0], np.linalg.qr(B)[0]
    if QA.shape[1] != QB.shape[1]:
        return 1.0
    sv = np.linalg.svd(QA.T @ QB, compute_uv=False)
    return float(math.sqrt(max(0.0, 1 - min(sv) ** 2)))


# ------------------------------------------------------------------------------------------- root laws
x, c, x2, g, r = s.symbols('x c x2 g r', positive=True)
L0A, A0 = s.Rational(7, 2), s.Integer(3)
POINT = {x: s.Rational(17, 10), c: s.Rational(9, 10), x2: s.Rational(13, 5), g: s.Rational(13, 10), r: s.Rational(3, 5)}
LAWS = {
    'single_wall': ([x, c], [2 * x / c]),
    'two_walls': ([x, x2, c], [2 * x / c, 2 * x2 / c]),
    'anchored': ([x, c], [2 * x / c, L0A / c]),
    'gain_contrast': ([x, c, g, r], [2 * x / c, g * r]),
    'anchored_calibrated': ([x, c, g, r], [2 * x / c, L0A / c, g * r, g]),
    'attenuation': ([x, c], [2 * x / c, A0 / x ** 2]),
}
EXPECT = {'single_wall': 1, 'two_walls': 1, 'anchored': 0, 'gain_contrast': 2, 'anchored_calibrated': 0, 'attenuation': 0}


def numeric(name):
    P, mu = LAWS[name]
    f = s.lambdify(P, mu, 'numpy')
    th0 = np.array([float(POINT[p]) for p in P])
    return (lambda th: np.array(f(*th), float)), th0


def jac_fd(f, th, h=1e-6):
    return np.array([(f(th + h * e) - f(th - h * e)) / (2 * h) for e in np.eye(len(th))]).T


def m1_symbolic_rank(name):
    P, mu = LAWS[name]
    return len(P) - s.Matrix(mu).jacobian(P).subs(POINT).rank()


def m2_symmetry_algebra(name):
    """Dimension of the algebra of scaling fields sum a_i theta_i d_i that annihilate the law identically."""
    P, mu = LAWS[name]
    rows = []
    pts = [{p: s.Rational(3 + 2 * i + 5 * j, 4 + j + i * i) for i, p in enumerate(P)} for j in range(5)]
    for pt in pts:
        for m in mu:
            rows.append([(p * s.diff(m, p)).subs(pt) for p in P])
    return len(s.Matrix(rows).nullspace())


def m3_continuation(name):
    """Move a finite distance with identical law: integrate the projected null field."""
    f, th0 = numeric(name)
    res0 = resolve(jac_fd(f, th0))
    disp, floor_x = [], 0.0
    for j in range(res0['hole_dim']):
        v = res0['hole'][:, j]
        def rhs(_, th):
            N = resolve(jac_fd(f, th))['hole']
            return N @ (N.T @ v)
        sol = solve_ivp(rhs, [0, 0.5], th0, rtol=1e-10, atol=1e-12)
        th1 = sol.y[:, -1]
        if np.max(np.abs(f(th1) - f(th0))) < 1e-7 and np.linalg.norm(th1 - th0) > 1e-2:
            disp.append(th1 - th0); floor_x = max(floor_x, abs(th1[0] - th0[0]) / 2)
    hd = int(np.linalg.matrix_rank(np.array(disp), tol=1e-6)) if disp else 0
    return hd, floor_x


def m4_fisher_spectrum(name, sigma=0.05):
    f, th0 = numeric(name)
    J = jac_fd(f, th0)
    return resolve(J, sigma ** 2 * np.eye(J.shape[0]))['hole_dim']


def m5_mle_cloud(name, sigma=0.05, n=200, starts=40):
    """Dimension of the set of maximum-likelihood estimates of one seeded data set (Gauss-Newton, minimal-norm steps)."""
    f, th0 = numeric(name)
    k = len(f(th0)); lrng = np.random.default_rng(SEED + sum(map(ord, name)))
    ybar = f(th0) + sigma / math.sqrt(n) * lrng.normal(size=k)
    fl_ = lambda ph: f(np.exp(ph))
    cloud = []
    for _ in range(starts):
        ph = np.log(th0) + 0.2 * lrng.normal(size=len(th0))
        for _ in range(80):
            Jp = jac_fd(fl_, ph); step = np.linalg.pinv(Jp, rcond=1e-10) @ (fl_(ph) - ybar)
            ph = ph - step
            if np.max(np.abs(step)) < 1e-13:
                break
        if np.max(np.abs(fl_(ph) - ybar)) < 1e-9:
            cloud.append(ph)
    C = np.array(cloud); C = C - C.mean(axis=0)
    sv = np.linalg.svd(C, compute_uv=False) / math.sqrt(len(cloud))
    return int(np.sum(sv > 1e-6)), len(cloud)


METHODS = ['M1 symbolic rank', 'M2 symmetry algebra', 'M3 continuation', 'M4 Fisher spectrum', 'M5 likelihood cloud']


def table_row(name, mixed=False):
    row = [m1_symbolic_rank(name), m2_symmetry_algebra(name), m3_continuation(name)[0],
           m4_fisher_spectrum('anchored' if mixed else name), m5_mle_cloud(name)[0]]
    return [int(v) for v in row]


# ============================================================================================  W0
def W0():
    f, th0 = numeric('single_wall')
    J = jac_fd(f, th0); res = resolve(J, 0.05 ** 2 * np.eye(1))
    gen = th0 / np.linalg.norm(th0)                                  # dilation generator (x, c)
    align = abs(float(res['hole'][:, 0] @ gen))
    tau_grad = J[0]; x_grad = np.array([1.0, 0.0])
    v_tau = variance(tau_grad, res)
    # naturality: the bound of a descending function is the same in another chart (log parameters)
    D = np.diag(th0); res_log = resolve(J @ D, 0.05 ** 2 * np.eye(1))
    v_tau_log = variance(D @ tau_grad, res_log)
    # destructor: the pseudo-inverse on parameter space is not a tensor: it disagrees between charts off the quotient
    naive = np.linalg.pinv(res['F']); naive_log = np.linalg.pinv(res_log['F'])
    chart_gap = float(np.max(np.abs(np.linalg.inv(D) @ naive @ np.linalg.inv(D) - naive_log)) / np.max(np.abs(naive_log)))
    ok = res['hole_dim'] == 1 and align > 1 - 1e-9 and descends(tau_grad, res) and not descends(x_grad, res) \
        and abs(v_tau - 0.05 ** 2) < 1e-10 and abs(v_tau_log - v_tau) < 1e-10 and variance(x_grad, res) is None and chart_gap > 0.1
    must(ok, 'W0')
    R['W0'] = dict(claim='The construction. resolve() returns the hole (kernel of the linearized record law), the resolved '
                         'complement, the Fisher form and its dual. For the tap, the hole is the dilation generator (x, c); the '
                         'delay descends and has variance sigma^2 in every chart; the distance x does not descend and has no '
                         'bound. Destructor: the pseudo-inverse of Fisher on parameter space is chart dependent, so uncertainty is '
                         'the dual on the quotient and not a geometry of its own.',
                   status='PROVED (linear algebra) + witness', rungs=[0, 1, 2, 19, 28, 49], edges=[[1, 2], [19, 28], [28, 49], [2, 49]],
                   hole_alignment_with_dilation=fl(align), variance_tau=fl(v_tau), variance_tau_log_chart=fl(v_tau_log),
                   x_descends=False, pinv_chart_gap=fl(chart_gap))


# ============================================================================================  W1
def W1():
    tab = {name: table_row(name) for name in LAWS}
    const = {name: len(set(row)) == 1 for name, row in tab.items()}
    agree = {name: tab[name][0] == EXPECT[name] for name in LAWS}
    # hand-over witness: tangent of the symmetry orbits equals the Fisher radical (subspace equality)
    gaps = {}
    for name in ('single_wall', 'two_walls', 'gain_contrast'):
        P, mu = LAWS[name]; f, th0 = numeric(name)
        rows = []
        for pt in [{p: s.Rational(3 + 2 * i + 5 * j, 4 + j + i * i) for i, p in enumerate(P)} for j in range(5)]:
            for m in mu:
                rows.append([(p * s.diff(m, p)).subs(pt) for p in P])
        A = np.array([[float(v) for v in vec] for vec in s.Matrix(rows).nullspace()]).T      # scaling exponents a
        gens = np.diag(th0) @ A                                                            # vector fields at th0
        gaps[name] = fl(subspace_gap(gens, resolve(jac_fd(f, th0))['hole']))
    floor = m3_continuation('single_wall')[1]
    ok = all(const.values()) and all(agree.values()) and max(gaps.values()) < 1e-6 and floor > 0.05
    must(ok, 'W1')
    R['W1'] = dict(claim='Shared fate. Six root laws of the tap; the hole dimension computed by five unrelated methods: exact local '
                         'rank, the algebra of global scaling symmetries, numerical continuation at identical law, the Fisher '
                         'spectrum from scores, and the dimension of the maximum-likelihood set of one data set. Every row is '
                         'constant. The symmetry orbits are exactly the Fisher radical (subspace equality). Moving along the hole '
                         'changes x by a finite amount at identical law, so the error of any estimate of x has a floor at every '
                         'sample size.',
                   status='witness (exact + numerical)', rungs=[0, 1, 2, 6, 19, 28, 44], edges=[[1, 2], [6, 19], [19, 28], [28, 44]],
                   methods=METHODS, table=tab, expected=EXPECT, rows_constant=const, radical_equals_orbit_tangent=gaps,
                   ignorance_floor_x=fl(floor))


# ============================================================================================  W2
def W2():
    sig = 0.05
    holes = {}
    for k in range(1, 6):                                            # k walls, one medium
        xs = s.symbols(f'y1:{k + 1}', positive=True)
        P = list(xs) + [c]; mu = [2 * xi / c for xi in xs]
        holes[k] = len(P) - s.Matrix(mu).jacobian(P).rank()
    f, th0 = numeric('two_walls'); res = resolve(jac_fd(f, th0), sig ** 2 * np.eye(2))
    ratio_grad = np.array([1 / th0[1], -th0[0] / th0[1] ** 2, 0.0])   # x / x2
    ratio_ok, x_ok = descends(ratio_grad, res), descends(np.array([1.0, 0, 0]), res)
    # anchor: a reference path of known length closes the hole; closed-form relative variance
    fa, tha = numeric('anchored'); resa = resolve(jac_fd(fa, tha), sig ** 2 * np.eye(2))
    v = variance(np.array([1.0, 0.0]), resa)
    tau, tref = fa(tha)
    closed = tha[0] ** 2 * (sig ** 2 / tau ** 2 + sig ** 2 / tref ** 2)
    # destructor: a "fake anchor" that is itself dilation covariant (a second echo) does not close the hole
    fake = m4_fisher_spectrum('two_walls')
    # shared fate at the root: an attenuation record breaks the dilation symmetry and closes every station at once
    att = table_row('attenuation')
    ok = all(h == 1 for h in holes.values()) and ratio_ok and not x_ok and resa['hole_dim'] == 0 and abs(v / closed - 1) < 1e-6 \
        and fake == 1 and att == [0] * 5
    must(ok, 'W2')
    R['W2'] = dict(claim='Unit walk. Any number of walls in one medium leaves exactly one hole, the unit: records of the same kind '
                         'never fix it. Ratios of distances descend; a distance does not. A reference path of known length closes '
                         'the hole, and the bound is Var(x)/x^2 = sigma^2/tau^2 + sigma^2/t_ref^2. Destructor: a second echo used '
                         'as an "anchor" leaves the hole open. A root law without the symmetry (attenuation record) is closed at '
                         'every station.',
                   status='PROVED (exact rank) + closed form', rungs=[6, 28, 94, 95, 97, 102, 109],
                   edges=[[28, 94], [6, 97], [94, 109], [95, 109], [102, 109]], holes_by_number_of_walls={str(k): int(h) for k, h in holes.items()},
                   ratio_descends=ratio_ok, distance_descends=x_ok, anchored_variance=fl(v), closed_form=fl(closed),
                   fake_anchor_hole=int(fake), attenuation_row=att)


# ============================================================================================  W3
def W3():
    n = 6
    w0 = rng.uniform(0.5, 1.5, n); s0 = rng.uniform(0.7, 1.4, n)     # cell widths and slownesses
    def law(th, interior):
        w, sl = th[:n], th[n:]
        out = [2 * np.sum(w * sl)]
        if interior:
            out += [np.sum(w[:k] * sl[:k]) for k in range(1, n)]
        return np.array(out)
    th0 = np.concatenate([w0, s0])
    ext = resolve(jac_fd(lambda t: law(t, False), th0)); full = resolve(jac_fd(lambda t: law(t, True), th0))
    gens = np.zeros((2 * n, n))
    for i in range(n):
        gens[i, i] = w0[i]; gens[n + i, i] = -s0[i]                   # relabeling of cell i: w -> lambda w, s -> s / lambda
    in_hole = float(np.max(np.abs(jac_fd(lambda t: law(t, True), th0) @ gens)))
    gauge_gap = subspace_gap(gens, full['hole'])
    # rods: widths known. Exterior record alone leaves the interior hole; interior receivers close it
    rod_ext = resolve(jac_fd(lambda sl: law(np.concatenate([w0, sl]), False), s0))
    rod_full = resolve(jac_fd(lambda sl: law(np.concatenate([w0, sl]), True), s0))
    # uniform relabeling is the dilation of the tap
    dil = gens.sum(axis=1); dil_ok = float(np.max(np.abs(jac_fd(lambda t: law(t, True), th0) @ dil)))
    # destructor: a perturbation that changes the optical length is not null
    bad = np.zeros(2 * n); bad[n] = 1.0
    bad_resp = float(np.max(np.abs(jac_fd(lambda t: law(t, True), th0) @ bad)))
    ok = ext['hole_dim'] == 2 * n - 1 and full['hole_dim'] == n and gauge_gap < 1e-6 and in_hole < 1e-8 and rod_ext['hole_dim'] == n - 1 \
        and rod_full['hole_dim'] == 0 and ext['hole_dim'] == n + rod_ext['hole_dim'] and dil_ok < 1e-8 and bad_resp > 0.1
    must(ok, 'W3')
    R['W3'] = dict(claim='Gauge walk. A layered medium (6 cells, widths and slownesses) seen by the echo alone has 11 null '
                         'directions. They split exactly as 6 + 5: six relabelings of the cells, which no record removes, and an '
                         'interior hole of dimension 5, which interior receivers remove. With interior receivers the Fisher '
                         'radical equals the span of the relabeling generators. Rods (known widths) remove the relabelings. The '
                         'uniform relabeling is the dilation of the tap. This is the hand-over to the source tensor (relabeling '
                         'response) and to the exterior-interior hole of GR Automation. Destructor: changing the optical length '
                         'is not null.',
                   status='witness (subspace equality)', rungs=[6, 28, 30, 31, 117, 119, 120],
                   edges=[[6, 28], [28, 30], [30, 31], [30, 117], [117, 119], [31, 120]], null_exterior=ext['hole_dim'],
                   null_with_interior_receivers=full['hole_dim'], gauge_dimension=n, interior_hole=rod_ext['hole_dim'],
                   radical_equals_relabelings=fl(gauge_gap), rods_and_receivers_hole=rod_full['hole_dim'], destructor_response=fl(bad_resp))


# ============================================================================================  W4
def W4():
    b, d = s.symbols('b d', real=True)
    mu = (b - d) ** 2
    J = s.diff(mu, b)
    rank_fold, rank_away = int(J.subs(b, d) != 0), int(J.subs({b: 2, d: 1}) != 0)
    mirror = s.simplify(mu.subs(b, 2 * d - b) - mu)
    signed_rank = int(s.diff(b - d, b) != 0)
    # identification modulus: at the fold the error scales as n^(-1/4); away from it as n^(-1/2)
    sig = 0.3; ns = np.array([1e2, 1e3, 1e4, 1e5, 1e6]); trials = 4000
    def rms(delta):
        out = []
        for n in ns:
            y = delta ** 2 + sig / math.sqrt(n) * rng.normal(size=trials)
            est = np.sqrt(np.maximum(y, 0.0)); out.append(float(np.sqrt(np.mean((est - delta) ** 2))))
        return np.polyfit(np.log(ns), np.log(out), 1)[0]
    slope_fold, slope_away = rms(0.0), rms(1.0)
    ok = rank_fold == 0 and rank_away == 1 and mirror == 0 and signed_rank == 1 and abs(slope_fold + 0.25) < 0.01 and abs(slope_away + 0.5) < 0.02
    must(ok, 'W4')
    R['W4'] = dict(claim='Wall walk. An overlap channel symmetric under b -> 2d - b has a fold at b = d: the rank drops there, the '
                         'fibre is the pair {b, 2d - b}, and the identification rate is n^(-1/4) at the fold against n^(-1/2) away '
                         'from it. Cramer-Rao is void at the wall. A signed (anti-invariant) channel splits the fold.',
                   status='PROVED (exact) + seeded rates', rungs=[21, 22, 23, 49, 51], edges=[[21, 22], [22, 51], [49, 51], [22, 23]],
                   rank_at_fold=rank_fold, rank_away=rank_away, mirror_law_difference=str(mirror), signed_channel_rank=signed_rank,
                   rate_exponent_at_fold=fl(slope_fold), rate_exponent_away=fl(slope_away))


# ============================================================================================  W5
def W5():
    # (a) mediation: wall present or absent; samples of a compact pulse arriving at tau
    tau, wd, A, sig, dt = 2.0, 0.2, 1.0, 0.5, 0.01
    t = np.arange(0, 4, dt); m = A * np.clip(1 - np.abs(t - tau) / wd, 0, None)
    errs = []
    for T in (1.0, 1.79, 1.9, 2.0, 2.2, 3.0):
        dp = math.sqrt(float(np.sum(m[t <= T] ** 2)) / sig ** 2); errs.append(float(norm.cdf(-dp / 2)))
    before = errs[0] == 0.5 and errs[1] == 0.5
    mono = all(errs[i + 1] <= errs[i] + 1e-15 for i in range(len(errs) - 1))
    # (b) geometry from delays: multidimensional scaling of first-arrival times; unit hole
    cs = 0.9; P = rng.normal(size=(6, 2)); D = np.linalg.norm(P[:, None] - P[None], axis=2); Tm = D / cs
    Jc = np.eye(6) - np.ones((6, 6)) / 6
    ev = np.sort(np.linalg.eigvalsh(-0.5 * Jc @ Tm ** 2 @ Jc))[::-1]
    rank2 = ev[1] > 1e-6 and abs(ev[2]) < 1e-10 * ev[0]
    wv, Q = np.linalg.eigh(-0.5 * Jc @ Tm ** 2 @ Jc); Y = Q[:, -2:] * np.sqrt(wv[-2:])
    rec = np.linalg.norm(Y[:, None] - Y[None], axis=2)
    unit_err = float(np.max(np.abs(rec * cs - D)))                    # distances are recovered only after multiplying by c
    # (c) one negative direction: interval matrix of events
    te = rng.normal(size=7); Pe = rng.normal(size=(7, 2))
    S = -cs ** 2 * (te[:, None] - te[None]) ** 2 + np.linalg.norm(Pe[:, None] - Pe[None], axis=2) ** 2
    J7 = np.eye(7) - np.ones((7, 7)) / 7
    es = np.linalg.eigvalsh(-0.5 * J7 @ S @ J7)
    sign = (int(np.sum(es > 1e-9)), int(np.sum(es < -1e-9)))
    # reachability from first arrivals equals the cone of that form
    reach = (te[None] - te[:, None]) >= np.linalg.norm(Pe[:, None] - Pe[None], axis=2) / cs
    cone = (S <= 1e-12) & ((te[None] - te[:, None]) >= 0)
    cone_match = bool(np.all(reach == cone))
    # (d) wind: one-way times are asymmetric; the relation is not the cone of a quadratic form (isotropy gate)
    wvec = np.array([0.3, 0.1])
    def tw(dv):
        a = cs ** 2 - wvec @ wvec; bq = dv @ wvec
        return (bq + math.sqrt(bq ** 2 + a * (dv @ dv))) / a
    asym = max(abs(tw(P[j] - P[i]) - tw(P[i] - P[j])) for i in range(6) for j in range(6))
    ok = before and mono and errs[-1] < 0.5 and rank2 and unit_err < 1e-9 and sign == (2, 1) and cone_match and asym > 0.1
    must(ok, 'W5')
    R['W5'] = dict(claim='Cone walk. Before the mediated arrival the two hypotheses (wall, no wall) have identical record laws and the '
                         'optimal error is exactly 1/2; afterwards it is nonincreasing. First-arrival times among six points '
                         'determine a planar configuration (two positive eigenvalues, the rest zero) only up to the unit: distances '
                         'need c. The interval matrix of events has exactly one negative direction, and reachability computed '
                         'from arrivals is the cone of that form. Gate canary: with wind the one-way times are asymmetric, so the '
                         'quadratic cone needs the isotropy declaration.',
                   status='witness (exact identities)', rungs=[2, 64, 65, 66, 68], edges=[[2, 64], [64, 65], [65, 66], [66, 68], [6, 68]],
                   bayes_error_by_window=[fl(e) for e in errs], mds_eigenvalues=[fl(e) for e in ev[:4]], unit_recovery_err=fl(unit_err),
                   signature=list(sign), reachability_equals_cone=cone_match, wind_asymmetry=fl(asym))


# ============================================================================================  W6
def W6():
    a = np.array([1.0, 1.7, 0.6]); b = np.array([0.2, -1.1, 3.0])
    taus = np.array([0.5, 1.0, 2.0, 3.5, 5.0])
    Y = a[:, None] * taus[None] + b[:, None]
    def trans(i, j):                                                  # y_i as an affine function of y_j
        return np.polyfit(Y[j], Y[i], 1)
    g12, g23, g31 = trans(0, 1), trans(1, 2), trans(2, 0)
    comp = lambda p, q: np.array([p[0] * q[0], p[0] * q[1] + p[1]])
    loop = comp(comp(g12, g23), g31)
    cocycle = float(np.max(np.abs(loop - np.array([1.0, 0.0]))))
    # gauge dimension: transitions as a function of (a_i, b_i); rank 4 of 6
    def tr(v):
        aa, bb = v[:3], v[3:]
        return np.array([aa[0] / aa[1], bb[0] - aa[0] / aa[1] * bb[1], aa[1] / aa[2], bb[1] - aa[1] / aa[2] * bb[2]])
    gauge = resolve(jac_fd(tr, np.concatenate([a, b])))['hole_dim']
    gauge_counted = resolve(jac_fd(lambda v: tr(np.concatenate([[1.0], v])), np.concatenate([a[1:], b])))['hole_dim']
    # twisted overlap: one transition reflected; holonomy is a reflection, no global description
    g31t = np.array([-g31[0], g31[1]]); twisted = comp(comp(g12, g23), g31t)
    # uniform wind: loop sum of one-way differences vanishes exactly; rotation: first-order Sagnac 4 Omega A / c^2
    cs = 0.9; pts = np.array([[0.0, 0.0], [2.0, 0.3], [0.7, 1.9]]); wvec = np.array([0.3, 0.1])
    def tw(dv):
        aq = cs ** 2 - wvec @ wvec; bq = dv @ wvec
        return (bq + math.sqrt(bq ** 2 + aq * (dv @ dv))) / aq
    uni = sum(tw(pts[(i + 1) % 3] - pts[i]) - tw(pts[i] - pts[(i + 1) % 3]) for i in range(3))
    Om = 0.05; e1, e2 = pts[1] - pts[0], pts[2] - pts[0]; area = 0.5 * abs(e1[0] * e2[1] - e1[1] * e2[0])
    circ = 0.0
    for i in range(3):
        p, q = pts[i], pts[(i + 1) % 3]
        for u in (0.0, 0.5, 1.0):                                     # Simpson, exact for a linear field
            rr = p + u * (q - p); wrot = Om * np.array([-rr[1], rr[0]])
            circ += {0.0: 1, 0.5: 4, 1.0: 1}[u] / 6 * (wrot @ (q - p))
    sagnac, pred = 2 * circ / cs ** 2, 4 * Om * area / cs ** 2
    ok = cocycle < 1e-10 and gauge == 2 and gauge_counted == 1 and abs(twisted[0] + 1) < 1e-10 and abs(uni) < 1e-12 \
        and abs(sagnac / pred - 1) < 1e-12 and abs(sagnac) > 1e-2
    must(ok, 'W6')
    R['W6'] = dict(claim='Clock walk. Three observers read the same delay on their own affine clocks. The fitted transition maps '
                         'satisfy the cocycle condition, so one description exists, unique up to a two-parameter gauge (rate, '
                         'offset); a counted clock removes the rate. Destructor: reflecting one overlap gives a reflection as '
                         'holonomy and no global description. Around a triangle, uniform wind gives zero synchronization holonomy '
                         'exactly; rotation gives 4 Omega A / c^2 at first order (Sagnac).',
                   status='witness (exact) + first-order Sagnac', rungs=[2, 8, 81, 82, 83, 93, 104, 105, 119, 121],
                   edges=[[2, 81], [81, 83], [81, 93], [8, 93], [104, 105], [119, 121]], cocycle_defect=fl(cocycle), gauge_dimension=gauge,
                   gauge_with_counted_clock=gauge_counted, twisted_holonomy_slope=fl(twisted[0]), uniform_wind_loop=fl(uni),
                   sagnac_holonomy=fl(sagnac), sagnac_predicted=fl(pred))


# ============================================================================================  W7
def W7():
    K = 64; a1, a2, tau = 1.0, 0.7, 2.0
    def fine(th, om, gam=1.0):
        t_, p, q = th; return p * p + q * q + 2 * gam * p * q * np.cos(om * t_)
    th0 = np.array([tau, a1, a2])
    om_n = 20 + 0.02 * np.arange(K)                                   # narrow band
    om_w = 20 + 0.98 * np.arange(K)                                   # wide band: about 20 fringes across the band
    Jf = jac_fd(lambda th: fine(th, om_n), th0)
    A = np.ones((1, K)) / K                                           # the coarse protocol is a garbling of the fine one
    Ff = resolve(Jf)['F']; Fc = resolve(A @ Jf, np.eye(1) / K)['F']
    rank_f, rank_c = resolve(Jf)['rank'], resolve(A @ Jf)['rank']
    dp = float(np.min(np.linalg.eigvalsh(Ff - Fc)))
    one_law = float(np.max(np.abs(A @ fine(th0, om_n) - np.mean(fine(th0, om_n)))))
    wash = abs(float(np.mean(fine(th0, om_w))) - (a1 ** 2 + a2 ** 2)) / (2 * a1 * a2)
    narrow = abs(float(np.mean(fine(th0, om_n))) - (a1 ** 2 + a2 ** 2)) / (2 * a1 * a2)
    # which-path protocol: populations only; the delay is in its hole
    Jw = jac_fd(lambda th: np.array([th[1] ** 2, th[2] ** 2]), th0); wp = resolve(Jw)
    tau_in_hole = bool(wp['hole_dim'] == 1 and abs(abs(wp['hole'][0, 0]) - 1) < 1e-9)
    # the tap's unit hole is seen by the coherent record too: chain rule tau = 2x/c
    xv, cv = 1.7, 0.9; chain = np.array([2 / cv, -2 * xv / cv ** 2])
    dil = float(np.max(np.abs(Jf[:, 0][:, None] * chain[None] @ np.array([xv, cv]))))
    # destructor: without mutual coherence the fine protocol has no information on the delay
    Jg = jac_fd(lambda th: fine(th, om_n, 0.0), th0); dead = float(np.max(np.abs(Jg[:, 0])))
    ok = rank_f == 3 and rank_c == 1 and dp > -1e-9 and one_law < 1e-12 and wash < 0.06 and narrow > 0.3 and tau_in_hole \
        and dil < 1e-9 and dead < 1e-9
    must(ok, 'W7')
    R['W7'] = dict(claim='Protocol walk (One World on the tap). One entity: the direct and the reflected wave with delay tau. The fine '
                         'protocol (narrow-band intensities) resolves delay and both amplitudes. The coarse protocol (band '
                         'average) is a garbling of the fine one: its law is the image of the same law, its Fisher form is smaller '
                         'in the positive order, and over a wide band the fringes wash out and intensities add, the classical '
                         'rule. A which-path protocol has the delay in its hole. The unit hole of the tap persists. Destructor: '
                         'without mutual coherence the delay is invisible to the fine protocol.',
                   status='witness (exact identities)', rungs=[1, 4, 28, 35, 38, 39], edges=[[1, 4], [4, 35], [28, 35], [35, 38], [38, 39]],
                   rank_fine=rank_f, rank_coarse=rank_c, data_processing_min_eig=fl(dp), coarse_is_image_err=fl(one_law),
                   fringe_residual_wide_band=fl(wash), fringe_residual_narrow_band=fl(narrow), delay_in_which_path_hole=tau_in_hole,
                   dilation_response=fl(dil), decohered_delay_response=fl(dead))


# ============================================================================================  W8
def behaviour(E):
    """Unbiased two-setting, two-outcome behaviour from correlators E[x][y]."""
    return {(xx, yy, aa, bb): (1 + aa * bb * E[xx][yy]) / 4 for xx in (0, 1) for yy in (0, 1) for aa in (-1, 1) for bb in (-1, 1)}


def classical_section(Pb):
    strategies = list(itertools.product((-1, 1), repeat=4))           # (a0, a1, b0, b1)
    Aeq, beq = [], []
    for (xx, yy, aa, bb), val in Pb.items():
        Aeq.append([1.0 if (st[xx] == aa and st[2 + yy] == bb) else 0.0 for st in strategies]); beq.append(val)
    res = linprog(np.zeros(16), A_eq=np.array(Aeq), b_eq=np.array(beq), bounds=[(0, None)] * 16, method='highs')
    return bool(res.status == 0)


def W8():
    strategies = list(itertools.product((-1, 1), repeat=4))
    chsh = lambda E: E[0][0] + E[0][1] + E[1][0] - E[1][1]
    classical_max = max(st[0] * st[2] + st[0] * st[3] + st[1] * st[2] - st[1] * st[3] for st in strategies)
    # one quantum state: the singlet, with four protocols
    sx = np.array([[0, 1], [1, 0]], complex); sz = np.array([[1, 0], [0, -1]], complex)
    psi = np.array([0, 1, -1, 0], complex) / math.sqrt(2)
    ob = lambda th: math.cos(th) * sz + math.sin(th) * sx
    Aang, Bang = (0.0, math.pi / 2), (math.pi / 4, -math.pi / 4)
    Eq = [[float(np.real(psi.conj() @ np.kron(ob(al), ob(be)) @ psi)) for be in Bang] for al in Aang]
    Eq = [[-v for v in row] for row in Eq]                            # relabel one outcome: E = +cos(difference)
    Sq = chsh(Eq)
    Epr = [[1.0, 1.0], [1.0, -1.0]]; Ecl = [[0.5, 0.5], [0.5, -0.5]]
    def nosig(Pb):
        worst = 0.0
        for xx in (0, 1):
            for aa in (-1, 1):
                m = [sum(Pb[(xx, yy, aa, bb)] for bb in (-1, 1)) for yy in (0, 1)]; worst = max(worst, abs(m[0] - m[1]))
        return worst
    def tlm(E):
        v = [math.asin(max(-1, min(1, E[i][j]))) for i in (0, 1) for j in (0, 1)]
        return max(abs(sum(v) - 2 * vi) for vi in v)
    sect = {name: classical_section(behaviour(E)) for name, E in (('classical', Ecl), ('quantum', Eq), ('pr_box', Epr))}
    ns = {name: fl(nosig(behaviour(E))) for name, E in (('classical', Ecl), ('quantum', Eq), ('pr_box', Epr))}
    tl = {name: fl(tlm(E) / math.pi) for name, E in (('classical', Ecl), ('quantum', Eq), ('pr_box', Epr))}
    ok = classical_max == 2 and abs(Sq - 2 * math.sqrt(2)) < 1e-12 and sect == {'classical': True, 'quantum': False, 'pr_box': False} \
        and max(ns.values()) < 1e-12 and abs(tl['quantum'] - 1) < 1e-12 and tl['pr_box'] > 1.5 and tl['classical'] < 1
    must(ok, 'W8')
    R['W8'] = dict(claim='One World as a gluing statement, with its falsifier. "One world" means: one state on a declared cone whose '
                         'images under the protocols are the observed laws. For four protocols with consistent marginals: a single '
                         'classical state (a global section over the simplex) exists iff CHSH <= 2 (Fine); the linear program finds '
                         'it at S = 2 and refutes it for the singlet. A single quantum state reproduces all four laws at '
                         'S = 2 sqrt 2, on the boundary of the Tsirelson-Landau-Masanes set. A PR box is consistent on overlaps '
                         'and has no single quantum state (criterion value 2 against the bound 1): its observation would refute '
                         'the claim. The claim is therefore a theorem with a test, not a philosophy.',
                   status='PROVED (enumeration, linear program) + IDENTIFIED (Fine; Tsirelson, Landau, Masanes)', rungs=[3, 15, 42, 43],
                   edges=[[3, 15], [15, 43], [42, 43]], classical_chsh_max=int(classical_max), singlet_chsh=fl(Sq),
                   classical_section_exists=sect, no_signalling_defect=ns, tlm_over_pi=tl)


# ============================================================================================  W9
def W9():
    sig, n, trials = 0.05, 50, 6000
    f, th0 = numeric('single_wall'); tau0 = float(f(th0)[0])
    est = tau0 + sig * rng.normal(size=(trials, n)).mean(axis=1)
    ratio = float(np.std(est) * math.sqrt(n) / sig)
    se = 1 / math.sqrt(2 * trials)
    res = resolve(jac_fd(f, th0), sig ** 2 / n * np.eye(1))
    bound_tau = variance(jac_fd(f, th0)[0], res)
    ok = abs(ratio - 1) < 4 * se and abs(bound_tau - sig ** 2 / n) < 1e-12 and variance(np.array([1.0, 0.0]), res) is None
    must(ok, 'W9')
    R['W9'] = dict(claim='Observer floor on the tap. The Cramer-Rao bound exists on the quotient (the delay) and is attained by the '
                         'mean of n records; off the quotient (the distance) there is no bound at any n. The observer bounds of '
                         'the companion prints are this dual read at other stations.',
                   status='witness (seeded)', rungs=[28, 34, 46, 49], edges=[[28, 34], [34, 46], [28, 49]],
                   attained_ratio=fl(ratio), monte_carlo_se=fl(se), bound_tau=fl(bound_tau), bound_x='none')


# ============================================================================================  W10
def W10():
    honest = table_row('single_wall'); mixed = table_row('single_wall', mixed=True)
    toolkit_detected = len(set(honest)) == 1 and len(set(mixed)) > 1
    # connector destructors
    f, th0 = numeric('single_wall'); res = resolve(jac_fd(f, th0))
    wrong_tangent = np.array([1.0, -1.0]) / math.sqrt(2)              # fibre tangent of a wrong quotient x + c
    d1 = 1 - abs(float(res['hole'][:, 0] @ wrong_tangent))
    # a station fed a non-descended input: the "phase" computed from x alone changes along the fibre
    lam = 1.3; phase_tau = lambda xx, cc: 20 * 2 * xx / cc; phase_x = lambda xx, cc: 20 * 2 * xx
    d2_ok = abs(phase_tau(1.7 * lam, 0.9 * lam) - phase_tau(1.7, 0.9)); d2_bad = abs(phase_x(1.7 * lam, 0.9 * lam) - phase_x(1.7, 0.9))
    ok = toolkit_detected and d1 > 0.1 and d2_ok < 1e-12 and d2_bad > 1.0
    must(ok, 'W10')
    R['W10'] = dict(claim='Toolkit canary. If one station is fed a different root law than the others, the row of hole dimensions is '
                          'no longer constant: the shared-fate table detects a scattered pipeline. Connector destructors: the '
                          'tangent of a wrong quotient is not the Fisher radical; a downstream quantity built from a non-descended '
                          'input (x instead of tau) changes along the fibre at identical records.',
                    status='canary', rungs=[2, 19, 28], edges=[[2, 19], [19, 28]], honest_row=honest, mixed_row=mixed,
                    toolkit_detected=toolkit_detected, wrong_quotient_gap=fl(d1), descended_input_change=fl(d2_ok),
                    non_descended_input_change=fl(d2_bad))


WALKS = {
    'unit': dict(title='Unit walk: tap to physical distance', stations=[0, 1, 2, 19, 28, 94, 109], groups=['W0', 'W1', 'W2', 'W9']),
    'gauge': dict(title='Gauge walk: tap to the second-order remainder and the source', stations=[0, 1, 6, 19, 28, 30, 117, 119, 120],
                  groups=['W1', 'W3']),
    'wall': dict(title='Wall walk: tap to folds and singular rates', stations=[0, 1, 2, 18, 21, 22, 51], groups=['W4']),
    'cone': dict(title='Cone and clock walk: tap to the light cone and Sagnac holonomy', stations=[0, 1, 2, 64, 65, 66, 68],
                 groups=['W5', 'W6']),
    'protocol': dict(title='Protocol walk: tap to contextual protocols (One World)', stations=[0, 1, 3, 15, 43], groups=['W7', 'W8']),
}


if __name__ == '__main__':
    for fn in [W0, W1, W2, W3, W4, W5, W6, W7, W8, W9, W10]:
        try:
            fn()
        except Exception as exc:                                      # a crash is a failure of that group, reported as such
            must(False, fn.__name__); R[fn.__name__] = dict(claim='exception', status='FAILED', error=repr(exc), rungs=[], edges=[])
        print(fn.__name__, flush=True)
    R['walks'] = WALKS
    R['source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    R['seed'] = SEED
    R['failures'] = FAILS
    (HERE / 'rg_walks_results.json').write_text(json.dumps(R, indent=1, sort_keys=True, default=str) + '\n')
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
