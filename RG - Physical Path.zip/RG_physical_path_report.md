# RG physical path: battery report

**Question.** Can RG compute physics from its own second-order layer and its final remainder,
rather than only select imported dynamics (Fisher by Cencov, Einstein by Lovelock)?

**Verdict.**
- **Locked (computation and constraint):**
  - the stress symbol T = ∫ p⊗p dμ: a natural second-order module, which equals RG's (Σ_R, C, Σ_N)
    datum with p = 1, q = 3;
  - the Fisher–stress identity T = Z(g_F + m m^T) for the thermal law;
  - the kinetic cone K = {T PSD on covectors, η-trace ≥ 0}, with a constructive decomposition into four
    equal-weight beams;
  - the energy conditions, which are forced rather than declared; K is strictly inside the dominant
    energy condition;
  - Hawking–Ellis type I unless pure null dust, with the Landau frame as the observer of minimal energy
    density;
  - isotropy controlled by multiplicities;
  - the remainder of stress fields;
  - the **conservation of principal-stress defect charge (±1/2) under every continuous evolution**, with
    creation and annihilation only in opposite pairs. This needs no constitutive law or field equation.
- **Refuted:** T determines the source law. The source stays a correspondence.
- **Boundary:**
  - ∇T = 0 follows only from declared free-fall transport;
  - Petrov types II, III and N lie outside the self-adjoint remainder theorem.
- **No-go:** no function of the source remainder determines the gravitational field.
  - Minkowski and Schwarzschild both have T = 0.
  - Nordström and Einstein vacua differ in light bending.
  - The Weyl part is the gravitational remainder. The field equation remains a selection or a measurement.

| ID | Claim | Status | Seed |
|---|---|---|---|
| P01 | stress symbol is natural (Lorentz-covariant) | LOCKED | 20261124 |
| P02 | kinetic ⇒ K | LOCKED | 20261225 |
| P03 | K ⇒ four equal-weight future causal beams (2000 fixtures built without kinetic construction, 121 on tr_η = 0) | LOCKED | 20261326 |
| P04 | K is a sharp test, strictly inside DEC (EM, stiff, Λ, tension excluded) | LOCKED | 20261427 |
| P05 | WEC, NEC, SEC, DEC forced (40 000 checks) | LOCKED | 20261528 |
| P06 | Hawking–Ellis I/II; variational Landau frame | LOCKED | 20261629 |
| P07 | T determines the source law | REFUTED | 20261730 |
| P08 | block map; canonical correlation < 1; isotropy dims 3/1/0, dust 3, Λ 6 | LOCKED | 20261831 |
| P09 | Airy defects: ±1/2 indices, Z2 monodromy (exact equilibrium) | LOCKED | deterministic |
| P10 | pair annihilation at t_c = −ε²/4; loop charge conserved | LOCKED | deterministic |
| P10b | random families: generic charge ±1/2; every change of loop charge is a boundary crossing (4/4) | LOCKED | 20262033 |
| P12 | source remainder fixes gravity | NO-GO | deterministic |
| P13 | Petrov I/D/O isotropy 0/2/6; type N is non-diagonalizable | BOUNDARY | deterministic |
| P14 | ∇T = 0 iff free transport (2.6e-9 vs 0.55) | BOUNDARY | deterministic |
| P16 | Fisher–stress identity (errors 2e-8, 3e-9) | LOCKED | deterministic |

**Canaries** (5/5 rejected):
- a non-null EM field is kinetic;
- the index of an isotropic point is an integer;
- T = 0 forces flat space (computed against the Kretschmann value from P12);
- null dust has a rest frame;
- perturbed beams still reproduce T.

**Reproduce:** `pip install numpy scipy sympy; python rg_physical_path_attacks.py --out OUT` (about 70 s).
Fresh-process reruns give identical witnesses.

**Limits.**
- Not blind.
- Analytic and synthetic fixtures only.
- No photoelastic or astrophysical data.
- References are from memory, not from an online check.
