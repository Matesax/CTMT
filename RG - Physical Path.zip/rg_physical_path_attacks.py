"""RG physical path: hostile battery.

Question attacked: can RG compute physics from its own second-order layer and remainder,
rather than only select imported dynamics?  Each attack returns a witness.

Statuses: LOCKED (claim survives exact/exhaustive/seeded attack on its stated domain, and a proof
is given in the paper), REFUTED, BOUNDARY (holds only under a named hypothesis), NO-GO (a proved
impossibility with an explicit witness).  Canaries are false statements the harness must reject.

Conventions: eta = diag(+1,-1,-1,-1); T^{ab} contravariant; a "law" is a finite positive measure on
the future causal cone, T = sum_i w_i p_i p_i^T.  All fixtures are synthetic or analytic.
Run: python rg_physical_path_attacks.py --out DIR   (numpy, scipy, sympy)
"""
import argparse, hashlib, json, math, pathlib, platform, sys, time
import numpy as np
import sympy as sp
from scipy.optimize import brentq, minimize

MASTER_SEED = 20261023
K_SCHW = None
ETA = np.diag([1.0, -1.0, -1.0, -1.0])
RES = []


def sd(k):
    return MASTER_SEED + 101 * k


def must(c, m):
    if not c:
        raise AssertionError(m)


def rec(aid, claim, status, witness, seed=None, details=None):
    RES.append(dict(id=aid, claim=claim, status=status, witness=witness, seed=seed,
                    details=details or {}))


# ------------------------------------------------------------------ helpers
def rand_causal(rng, n, null_frac=0.3, mmax=2.0):
    P = []
    for _ in range(n):
        v = rng.standard_normal(3) * rng.uniform(0.1, 3.0)
        m = 0.0 if rng.random() < null_frac else rng.uniform(0.05, mmax)
        P.append(np.r_[math.sqrt(v @ v + m * m), v])
    return np.array(P)


def T_of(P, w):
    return sum(wi * np.outer(p, p) for p, wi in zip(P, w))


def boost(rap):
    r = np.linalg.norm(rap)
    if r == 0:
        return np.eye(4)
    n = rap / r
    L = np.eye(4)
    L[0, 0] = math.cosh(r)
    L[0, 1:] = L[1:, 0] = math.sinh(r) * n
    L[1:, 1:] = np.eye(3) + (math.cosh(r) - 1) * np.outer(n, n)
    return L


def rand_lorentz(rng, rmax=2.0):
    A = rng.standard_normal((3, 3))
    Q, _ = np.linalg.qr(A)
    if np.linalg.det(Q) < 0:
        Q[:, 0] *= -1
    R = np.eye(4); R[1:, 1:] = Q
    return boost(rng.standard_normal(3) * rng.uniform(0, rmax) / math.sqrt(3)) @ R


def in_cone(T, tol=1e-10):
    s = np.linalg.norm(T) + 1.0
    return np.linalg.eigvalsh((T + T.T) / 2).min() >= -tol * s and np.trace(ETA @ T) >= -tol * s


def constant_diagonal(M):
    """Orthogonal Q with Q^T M Q of constant diagonal tr(M)/k (Givens + IVT)."""
    M = np.array(M, float); k = M.shape[0]; a = np.trace(M) / k
    Q = np.eye(k)
    for _ in range(4 * k):
        d = np.diag(M)
        if np.max(np.abs(d - a)) < 1e-13 * (1 + np.abs(M).max()):
            break
        i = int(np.argmax(d - a)); j = int(np.argmin(d - a))
        def entry(th):
            c, s = math.cos(th), math.sin(th)
            return c * c * M[i, i] + s * s * M[j, j] + 2 * c * s * M[i, j] - a
        th = brentq(entry, 0.0, math.pi / 2, xtol=1e-15)
        G = np.eye(k); c, s = math.cos(th), math.sin(th)
        G[i, i] = c; G[j, j] = c; G[j, i] = s; G[i, j] = -s
        M = G.T @ M @ G; Q = Q @ G
    return Q, M


def beam_decomposition(T):
    """T in cone -> 4 future causal beams p_l with sum p p^T = T and equal invariant weight."""
    w, U = np.linalg.eigh((T + T.T) / 2)
    w = np.clip(w, 0, None)
    V = U @ np.diag(np.sqrt(w))
    M = V.T @ ETA @ V
    Q, Md = constant_diagonal(M)
    P = (V @ Q).T
    P = np.array([p if p[0] >= 0 else -p for p in P])
    return P, np.diag(Md)


# ================================================================ P01 symbol covariance
def P01():
    rng = np.random.default_rng(sd(1)); err = tr = 0.0
    for _ in range(500):
        P = rand_causal(rng, 7); w = rng.uniform(0.1, 2, 7); L = rand_lorentz(rng)
        T = T_of(P, w); TL = T_of(P @ L.T, w)
        err = max(err, np.abs(TL - L @ T @ L.T).max() / (1 + np.abs(TL).max()))
        tr = max(tr, abs(np.trace(ETA @ TL) - np.trace(ETA @ T)) / (1 + abs(np.trace(ETA @ T))))
    must(err < 1e-10 and tr < 1e-10, "covariance")
    rec("P01", "T = E[p (x) p] is a natural (Lorentz-covariant) second-order module of the momentum law",
        "LOCKED", "500 seeded laws x random Lorentz maps: T(Lambda p) = Lambda T Lambda^T, "
        "eta-trace invariant (max rel. err %.1e, %.1e)" % (err, tr), sd(1),
        dict(cov_err=err, trace_err=tr))


# ================================================================ P02 necessity
def P02():
    rng = np.random.default_rng(sd(2)); mineig = 1e9; mintr = 1e9
    for _ in range(2000):
        P = rand_causal(rng, int(rng.integers(1, 9))); w = rng.uniform(0.01, 3, len(P))
        T = T_of(P, w)
        mineig = min(mineig, np.linalg.eigvalsh(T).min() / np.linalg.norm(T))
        mintr = min(mintr, np.trace(ETA @ T) / np.linalg.norm(T))
    must(mineig > -1e-12 and mintr > -1e-12, "necessity")
    rec("P02", "Every kinetic stress tensor lies in K = {T PSD on covectors, eta-trace >= 0}",
        "LOCKED", "2000 seeded laws (30%% null beams): min normalized eigenvalue %.1e, "
        "min normalized eta-trace %.1e" % (mineig, mintr), sd(2))


# ================================================================ P03 sufficiency (constructive)
def P03():
    rng = np.random.default_rng(sd(3)); worst = 0.0; worst_mass = 0.0; n = 0; zero_trace = 0
    for k in range(2000):
        A = rng.standard_normal((4, int(rng.integers(1, 5))))
        T = A @ A.T
        s = np.trace(ETA @ T)
        if k % 2 == 1 and s > 0:                       # push to the boundary tr_eta = 0
            T = T + (s / 3) * np.diag([0, 1, 1, 1]); zero_trace += 1
        elif s < 0:
            T = T + (-s + rng.uniform(0, 1)) * np.diag([1, 0, 0, 0])
        must(in_cone(T), "fixture in cone")
        P, m2 = beam_decomposition(T)
        R = sum(np.outer(p, p) for p in P)
        worst = max(worst, np.abs(R - T).max() / np.abs(T).max())
        mass = np.array([p @ ETA @ p for p in P])
        worst_mass = max(worst_mass, np.abs(mass - np.trace(ETA @ T) / 4).max() / np.abs(T).max())
        must(all(p[0] >= -1e-12 for p in P), "future")
        n += 1
    must(worst < 1e-9 and worst_mass < 1e-9, "decomposition")
    rec("P03", "Every T in K is the stress of four future causal beams of equal invariant weight tr_eta(T)/4",
        "LOCKED", f"{n} seeded T in K, built WITHOUT kinetic construction ({zero_trace} pushed to tr_eta=0): "
        f"reconstruction rel. err {worst:.1e}, equal-weight err {worst_mass:.1e}, all beams future causal",
        sd(3), dict(n=n, boundary=zero_trace))


# ================================================================ P04 outside-cone certificates; K < DEC
def em_T(E, B):
    E = np.asarray(E, float); B = np.asarray(B, float)
    T = np.zeros((4, 4))
    T[0, 0] = 0.5 * (E @ E + B @ B)
    T[0, 1:] = T[1:, 0] = np.cross(E, B)
    T[1:, 1:] = 0.5 * (E @ E + B @ B) * np.eye(3) - np.outer(E, E) - np.outer(B, B)
    return T


def dec_ok(T, rng, n=2000):
    for _ in range(n):
        u = boost(rng.standard_normal(3) * rng.uniform(0, 3))[:, 0]
        wv = T @ ETA @ u
        if wv[0] < -1e-9 or wv @ ETA @ wv < -1e-9 * (1 + wv[0] ** 2):
            return False
    return True


def P04():
    rng = np.random.default_rng(sd(4))
    cases = {
        "dust": np.diag([1.0, 0, 0, 0]), "radiation": np.diag([1.0, 1 / 3, 1 / 3, 1 / 3]),
        "perfect p=0.2": np.diag([1.0, 0.2, 0.2, 0.2]), "stiff p=rho": np.diag([1.0, 1, 1, 1]),
        "Lambda": np.diag([1.0, -1, -1, -1]), "EM electric": em_T([1, 0, 0], [0, 0, 0]),
        "EM null": em_T([1, 0, 0], [0, 1, 0]), "tension p<0": np.diag([1.0, -0.1, 0.2, 0.2]),
    }
    out = {}
    for k, T in cases.items():
        out[k] = dict(kinetic=bool(in_cone(T)), dec=bool(dec_ok(T, rng)),
                      min_eig=float(np.linalg.eigvalsh(T).min()), tr_eta=float(np.trace(ETA @ T)))
    must(out["dust"]["kinetic"] and out["radiation"]["kinetic"] and out["EM null"]["kinetic"], "in")
    must(not out["stiff p=rho"]["kinetic"] and not out["Lambda"]["kinetic"]
         and not out["EM electric"]["kinetic"] and not out["tension p<0"]["kinetic"], "out")
    must(out["EM electric"]["dec"] and out["stiff p=rho"]["dec"], "K strictly inside DEC")
    # random non-null EM fields are never kinetic
    bad = 0
    for _ in range(500):
        E, B = rng.standard_normal(3), rng.standard_normal(3)
        bad += in_cone(em_T(E, B))
    must(bad == 0, "non-null EM never kinetic")
    rec("P04", "Kinetic realizability is a sharp test strictly stronger than the dominant energy condition",
        "LOCKED", "In K: dust, radiation, perfect fluid 0<=p<=rho/3, null EM (photon beam). Out of K with a "
        "certificate (negative eigenvalue or eta-trace<0): stiff fluid, Lambda, electric field, tension. "
        "Electric field and stiff fluid satisfy DEC: K is strictly inside DEC. 500 random non-null EM fields: "
        "0 kinetic.", sd(4), out)


# ================================================================ P05 energy conditions forced
def P05():
    rng = np.random.default_rng(sd(5)); viol = 0; checks = 0
    for _ in range(400):
        P = rand_causal(rng, 5); T = T_of(P, rng.uniform(0.1, 2, 5)); Tl = ETA @ T @ ETA
        tr = np.trace(ETA @ T)
        for _ in range(25):
            u = boost(rng.standard_normal(3) * rng.uniform(0, 4))[:, 0]
            k = np.r_[1.0, rng.standard_normal(3)]; k[1:] /= np.linalg.norm(k[1:])
            wv = T @ ETA @ u; sc = 1 + np.abs(T).max() * u[0] ** 2
            viol += (u @ Tl @ u < -1e-9 * sc) + (k @ Tl @ k < -1e-9 * sc)
            viol += (u @ Tl @ u - 0.5 * tr < -1e-9 * sc)
            viol += (wv[0] < -1e-9 * sc) or (wv @ ETA @ wv < -1e-8 * sc * sc)
            checks += 4
    must(viol == 0, "energy conditions")
    rec("P05", "WEC, NEC, SEC and DEC are forced by kinetic realizability (not declared)",
        "LOCKED", f"{checks} observer/null checks on 400 seeded kinetic laws (rapidity up to 4): 0 violations",
        sd(5))


# ================================================================ P06 Hawking-Ellis and Landau frame
def landau_min(T):
    def f(r):
        u = boost(r)[:, 0]; return (ETA @ u) @ T @ (ETA @ u)
    best = None
    for s in range(6):
        r0 = np.random.default_rng(s).standard_normal(3) * 0.3
        o = minimize(f, r0, method="BFGS", options=dict(gtol=1e-12))
        if best is None or o.fun < best.fun:
            best = o
    return boost(best.x)[:, 0], best.fun


def P06():
    rng = np.random.default_rng(sd(6)); worst = 0.0; n = 0
    for _ in range(150):
        P = rand_causal(rng, 4, null_frac=0.5); T = T_of(P, rng.uniform(0.2, 2, 4))
        ev, EV = np.linalg.eig(T @ ETA)
        tl = [(ev[i].real, EV[:, i].real) for i in range(4)
              if abs(ev[i].imag) < 1e-9 and EV[:, i].real @ ETA @ EV[:, i].real > 1e-9]
        must(len(tl) == 1, "exactly one timelike eigenvector (type I)")
        lam, v = tl[0]; v = v / math.sqrt(v @ ETA @ v); v = v if v[0] > 0 else -v
        u, rho = landau_min(T)
        worst = max(worst, abs(rho - lam) / abs(lam), np.abs(u - v).max())
        n += 1
    must(worst < 1e-5, "variational Landau frame = eigenvector")
    k = np.array([1.0, 1, 0, 0]); Tn = np.outer(k, k)
    vals = [((ETA @ boost(np.array([r, 0, 0]))[:, 0]) @ Tn @ (ETA @ boost(np.array([r, 0, 0]))[:, 0]))
            for r in (0, 2, 4, 8)]
    ev, EV = np.linalg.eig(Tn @ ETA)
    has_tl = any(abs(ev[i].imag) < 1e-12 and EV[:, i].real @ ETA @ EV[:, i].real > 1e-9 for i in range(4))
    must(not has_tl and all(vals[i + 1] < vals[i] for i in range(3)) and vals[-1] > 0, "null dust")
    rec("P06", "Kinetic T is Hawking-Ellis type I unless supported on one null ray (then type II); the Landau "
        "frame is the observer minimizing measured energy density", "LOCKED",
        f"{n} seeded non-collinear kinetic T (50% null beams): exactly one timelike eigenvector; BFGS "
        f"minimizer of T(u,u) on the hyperboloid matches it (max err {worst:.1e}). Null dust: no timelike "
        f"eigenvector, inf T(u,u)=0 not attained ({[round(x, 6) for x in vals]}).", sd(6),
        dict(err=worst, null_dust_energy_along_boost=vals))


# ================================================================ P07 source fibre
def P07():
    rng = np.random.default_rng(sd(7))
    P = rand_causal(rng, 400, null_frac=0.0, mmax=1.0); w = np.full(400, 1 / 400)
    T = T_of(P, w)
    B, _ = beam_decomposition(T)
    TB = sum(np.outer(p, p) for p in B)
    M3 = np.einsum("i,ia,ib,ic->abc", w, P, P, P)
    M3b = np.einsum("ia,ib,ic->abc", B, B, B)
    must(np.abs(TB - T).max() < 1e-10 and np.abs(M3 - M3b).max() > 1e-2, "fibre")
    rec("P07", "The stress tensor determines the source law", "REFUTED",
        "A 400-particle gas and its 4-beam decomposition have identical T (err %.1e) but third moments "
        "differ by %.3f: the source remains a correspondence on the T-fibre; a third-moment protocol "
        "separates them." % (np.abs(TB - T).max(), np.abs(M3 - M3b).max()), sd(7))


# ================================================================ P08 block map and isotropy
def stab_dim(T, group="so3"):
    X = sp.Matrix(4, 4, sp.symbols("a0:16"))
    eqs = []
    if group == "so3":
        eqs += [X[0, j] for j in range(4)] + [X[j, 0] for j in range(4)]
        S = X[1:, 1:]; eqs += list(S + S.T)
    else:
        E = sp.diag(1, -1, -1, -1); eqs += list(X.T * E + E * X)
    Ts = sp.Matrix(T)
    eqs += list(X * Ts + Ts * X.T)
    M = sp.Matrix([[sp.diff(e, v) for v in X] for e in eqs])
    return 16 - M.rank()


def P08():
    q = sp.Rational
    dims = {"perfect fluid": stab_dim(sp.diag(1, q(1, 5), q(1, 5), q(1, 5))),
            "axisymmetric": stab_dim(sp.diag(1, q(1, 10), q(1, 5), q(1, 5))),
            "anisotropic": stab_dim(sp.diag(1, q(1, 10), q(1, 5), q(3, 10))),
            "dust (Lorentz)": stab_dim(sp.diag(1, 0, 0, 0), "lorentz"),
            "Lambda (Lorentz)": stab_dim(sp.diag(1, -1, -1, -1), "lorentz")}
    must([dims[k] for k in ("perfect fluid", "axisymmetric", "anisotropic")] == [3, 1, 0], "so3 dims")
    must(dims["dust (Lorentz)"] == 3 and dims["Lambda (Lorentz)"] == 6, "lorentz dims")
    rng = np.random.default_rng(sd(8)); worst = 0.0
    for _ in range(300):
        T = T_of(rand_causal(rng, 6, null_frac=0.0), rng.uniform(0.1, 1, 6))
        L = boost(rng.standard_normal(3) * 0.7); Tb = L @ T @ L.T
        rho, j, S = Tb[0, 0], Tb[0, 1:], Tb[1:, 1:]
        w, U = np.linalg.eigh(S); Sm = U @ np.diag(w ** -0.5) @ U.T
        sigma = np.linalg.norm(j @ Sm) / math.sqrt(rho)
        worst = max(worst, sigma)
        must(sigma < 1, "canonical correlation < 1 iff T positive definite")
    rec("P08", "Block map T = [[rho, j],[j, S]] <-> (Sigma_R, C, Sigma_N), p=1, q=3; isotropy is controlled by "
        "principal-pressure multiplicities", "LOCKED",
        f"Exact rotation-stabilizer dims: perfect fluid 3, axisymmetric 1, anisotropic 0; Lorentz stabilizer: "
        f"dust 3, Lambda 6. 300 boosted positive-definite kinetic T: canonical correlation |S^-1/2 j|/sqrt(rho) "
        f"< 1 (max {worst:.3f}); it vanishes exactly in the Landau frame. The coupling j is observer-relative, "
        f"as the coupling is complement-relative in the remainder paper.", sd(8), dict(dims=dims))


# ================================================================ P09/P10 Airy defects and their dynamics
X_, Y_, T_, E_ = sp.symbols("x y t epsilon", real=True)
Z_ = X_ + sp.I * Y_; ZB_ = X_ - sp.I * Y_


def airy_family():
    phi = sp.expand(sp.re(sp.expand(ZB_ * Z_ ** 3 / 6 - T_ * Z_ ** 2 / 2 + sp.I * E_ * Z_ ** 3 / 6)))
    sxx, syy, sxy = sp.diff(phi, Y_, 2), sp.diff(phi, X_, 2), -sp.diff(phi, X_, Y_)
    return phi, sxx, syy, sxy


def winding(fun, cx, cy, r, n=4000):
    th = np.linspace(0, 2 * math.pi, n + 1)
    vals = np.array([fun(cx + r * math.cos(a), cy + r * math.sin(a)) for a in th])
    ang = np.unwrap(np.angle(vals))
    return (ang[-1] - ang[0]) / (2 * math.pi), float(np.abs(vals).min())


def P09_P10():
    phi, sxx, syy, sxy = airy_family()
    bih = sp.simplify(sp.diff(phi, X_, 4) + 2 * sp.diff(phi, X_, 2, Y_, 2) + sp.diff(phi, Y_, 4))
    div1 = sp.simplify(sp.diff(sxx, X_) + sp.diff(sxy, Y_)); div2 = sp.simplify(sp.diff(sxy, X_) + sp.diff(syy, Y_))
    must(bih == 0 and div1 == 0 and div2 == 0, "plane elasticity: equilibrium and compatibility")
    D = sp.expand((sxx - syy) / 2 + sp.I * sxy)
    must(sp.simplify(D - (T_ - X_ ** 2 - Y_ ** 2 + E_ * Y_ + sp.I * E_ * X_)) == 0, "D formula")
    eps = 0.6; Df = sp.lambdify((X_, Y_, T_), D.subs(E_, eps), "numpy")
    tc = -eps ** 2 / 4
    out = []
    for tv in (0.5, 0.1, tc + 0.02, tc - 0.02, -0.3):
        f = lambda a, b: complex(Df(a, b, tv))
        tot, mb = winding(f, 0.0, 0.3, 3.0)
        loc = []
        disc = eps ** 2 + 4 * tv
        if disc > 0:
            for yz in ((eps + math.sqrt(disc)) / 2, (eps - math.sqrt(disc)) / 2):
                w, _ = winding(f, 0.0, yz, min(0.05, math.sqrt(disc) / 4))
                loc.append(round(w))
                # principal direction monodromy around the defect: eigenvector sign after a loop
                th = np.linspace(0, 2 * math.pi, 2001); v = v0 = None
                rr = min(0.05, math.sqrt(disc) / 4)
                for a in th:
                    d = f(rr * math.cos(a), yz + rr * math.sin(a))
                    ang = np.angle(d) / 2; vec = np.array([math.cos(ang), math.sin(ang)])
                    if v is None:
                        v0 = v = vec
                    else:
                        v = vec if vec @ v > 0 else -vec
                loc.append(("monodromy", round(float(v @ v0))))
        out.append(dict(t=tv, total_winding=round(tot, 6), min_boundary_D=mb, local=loc))
    tots = [o["total_winding"] for o in out]
    must(all(abs(x) < 1e-6 for x in tots), "total charge conserved (=0) through annihilation")
    must(out[0]["local"] == [1, ("monodromy", -1), -1, ("monodromy", -1)] or
         out[0]["local"] == [-1, ("monodromy", -1), 1, ("monodromy", -1)], "opposite +-1/2 pair, Z2 monodromy -1")
    must(out[3]["local"] == [] and out[4]["local"] == [], "annihilated below t_c")
    rec("P09", "Principal-stress defects of a plane elastic stress field carry the RG wall charge",
        "LOCKED", "Airy stress function phi = Re(zbar z^3/6 - t z^2/2 + i eps z^3/6): equilibrium and "
        "compatibility exact (sympy). D = (sxx-syy)/2 + i sxy = t - |z|^2 + eps y + i eps x. Isotropic points "
        "(0, (eps +- sqrt(eps^2+4t))/2): local windings +1 and -1, i.e. stress-line indices +1/2 and -1/2; "
        "principal direction returns with sign -1 around each (the Z2 remainder).", details=dict(scan=out))
    rec("P10", "Remainder-driven dynamics: the total defect charge is conserved under any continuous evolution; "
        "defects are created/annihilated only in opposite pairs", "LOCKED",
        f"Same family, load parameter t swept through t_c = -eps^2/4 = {tc}: charge on a fixed loop is 0 "
        f"before and after; the +1/2/-1/2 pair merges and annihilates at t_c. No constitutive law or field "
        f"equation beyond equilibrium was used.", details=dict(t_c=tc))
    # random families: degree additivity and conservation while boundary avoids zeros
    rng = np.random.default_rng(sd(10)); checks = 0; jumps = 0; jumps_explained = 0; generic_ok = True
    for fam in range(12):
        c = rng.standard_normal(6) + 1j * rng.standard_normal(6)
        def D2(a, b, tv, c=c):
            z = a + 1j * b; zb = a - 1j * b
            return zb * (c[0] + c[1] * z) + c[2] + c[3] * z + c[4] * z * z + tv * c[5]
        ts = np.linspace(-1, 1, 21); prev = None
        for tv in ts:
            f = lambda a, b: D2(a, b, tv)
            tot, mb = winding(f, 0, 0, 1.5, 3000)
            for gx in np.linspace(-1.5, 1.35, 20):
                for gy in np.linspace(-1.5, 1.35, 20):
                    cx, cy = gx + 0.075, gy + 0.075
                    if cx * cx + cy * cy > 1.5 ** 2 - 0.2:
                        continue
                    w, m_ = winding(f, cx, cy, 0.075, 200)
                    if abs(round(w)) > 0:
                        generic_ok &= abs(round(w)) == 1
            checks += 1
            if prev is not None and round(prev[0]) != round(tot):
                jumps += 1
                th = np.linspace(0, 2 * math.pi, 1500)
                mins = min(np.abs(D2(1.5 * np.cos(th), 1.5 * np.sin(th), tt)).min()
                           for tt in np.linspace(prev[1], tv, 400))
                scale = np.abs(D2(1.5 * np.cos(th), 1.5 * np.sin(th), tv)).max()
                jumps_explained += mins < 1e-2 * scale
            prev = (tot, tv)
    must(jumps == jumps_explained, "every change of boundary charge is a zero crossing the boundary")
    must(generic_ok, "generic local windings are +-1")
    rec("P10b", "Generic isotropic points have index +-1/2 (never 0 or integer) in random Airy-type families",
        "LOCKED", f"12 seeded random families x 21 times ({checks} snapshots): every grid-cell defect has "
        f"local winding +-1; all {jumps} changes of the boundary charge coincide with a zero crossing the "
        f"boundary loop (|D| < 1% of its scale on the loop at an intermediate time).", sd(10),
        dict(jumps=jumps, explained=int(jumps_explained)))


# ================================================================ P12 gravitational no-go
def christoffel_riemann(g, coords):
    n = len(coords); gi = g.inv()
    G = [[[sp.simplify(sum(gi[a, d] * (sp.diff(g[d, b], coords[c]) + sp.diff(g[d, c], coords[b])
           - sp.diff(g[b, c], coords[d])) for d in range(n)) / 2) for c in range(n)] for b in range(n)]
         for a in range(n)]
    R = {}
    for a in range(n):
        for b in range(n):
            for c in range(n):
                for d in range(n):
                    R[a, b, c, d] = sp.simplify(sp.diff(G[a][b][d], coords[c]) - sp.diff(G[a][b][c], coords[d])
                        + sum(G[a][c][e] * G[e][b][d] - G[a][d][e] * G[e][b][c] for e in range(n)))
    Ric = sp.Matrix(n, n, lambda b, d: sp.simplify(sum(R[a, b, a, d] for a in range(n))))
    return R, Ric, gi


def P12():
    t, r, th, ph, m = sp.symbols("t r theta phi m", positive=True)
    co = (t, r, th, ph)
    gS = sp.diag(-(1 - 2 * m / r), 1 / (1 - 2 * m / r), r ** 2, r ** 2 * sp.sin(th) ** 2)
    R, Ric, gi = christoffel_riemann(gS, co)
    # Kretschmann
    Rl = {k: sum(gS[k[0], e] * R[e, k[1], k[2], k[3]] for e in range(4)) for k in R}
    K = 0
    for a in range(4):
        for b in range(4):
            for c in range(4):
                for d in range(4):
                    if Rl[a, b, c, d] != 0:
                        Rup = sum(gi[a, a2] * gi[b, b2] * gi[c, c2] * gi[d, d2] * Rl[a2, b2, c2, d2]
                                  for a2 in range(4) for b2 in range(4) for c2 in range(4) for d2 in range(4)
                                  if Rl[a2, b2, c2, d2] != 0)
                        K += Rl[a, b, c, d] * Rup
    K = sp.simplify(K)
    must(all(sp.simplify(x) == 0 for x in Ric) and sp.simplify(K - 48 * m ** 2 / r ** 6) == 0, "Schwarzschild")
    global K_SCHW
    K_SCHW = float(K.subs({m: 1, r: 3}))
    # Nordstrom vacuum: g = phi^2 eta, phi = 1 - m/rho (isotropic); conformally flat, T = 0 in that theory
    x, y, zc = sp.symbols("x y z", real=True); rho = sp.sqrt(x ** 2 + y ** 2 + zc ** 2)
    phiN = 1 - m / rho
    lap = sp.simplify(sum(sp.diff(phiN, v, 2) for v in (x, y, zc)))
    must(lap == 0, "Nordstrom vacuum field equation box phi = 0")
    # deflection: GR (exact integral) vs Nordstrom (conformally flat => 0)
    from scipy.integrate import quad
    mm, r0 = 1.0, 30.0
    A = lambda rr: 1 - 2 * mm / rr
    b = r0 / math.sqrt(A(r0))
    def integrand(s):
        u = 1 - s * s; rr = r0 / u
        val = b / (rr ** 2 * math.sqrt(max(1 - A(rr) * b * b / rr ** 2, 1e-300)))
        return val * r0 * 2 * s / u ** 2
    alpha_gr = 2 * quad(integrand, 0, 1, limit=400)[0] - math.pi
    second = 4 * mm / b + 15 * math.pi / 4 * (mm / b) ** 2
    must(abs(alpha_gr - second) / second < 0.02 and alpha_gr > 0.1, "GR deflection (2nd-order PPN check)")
    rec("P12", "RG's source remainder (any function of the stress field) determines the gravitational field",
        "NO-GO", "Two vacua with identical source remainder T = 0: Minkowski (K = 0) and Schwarzschild "
        "(Ricci = 0, Kretschmann = 48 m^2/r^6, sympy). A rival theory (Nordstrom, g = phi^2 eta, box phi = 0) "
        "also has T = 0 outside the source but zero light bending (conformal flatness) versus "
        f"GR alpha = {alpha_gr:.6f} at r0 = 30 m. The 10 Weyl components are not functions of T; a field "
        "equation must be selected (Lovelock) or measured (light bending), not read off the remainder.",
        details=dict(alpha_GR=alpha_gr, weak_field=4 * mm / b))


# ================================================================ P13 Petrov as gravitational remainder
def complex_stab_dim(Q):
    """real dim of {X in so(3,C): XQ = QX}"""
    a = sp.symbols("a0:9", real=True); bb = sp.symbols("b0:9", real=True)
    X = sp.Matrix(3, 3, [a[i] + sp.I * bb[i] for i in range(9)])
    eqs = list(X + X.T) + list(X * Q - Q * X)
    real_eqs = []
    for e in eqs:
        e = sp.expand(e); real_eqs += [sp.re(e), sp.im(e)]
    M = sp.Matrix([[sp.diff(e, v) for v in a + bb] for e in real_eqs])
    return 18 - M.rank()


def P13():
    dims = {"type D Schwarzschild diag(-2,1,1)": complex_stab_dim(sp.diag(-2, 1, 1)),
            "type I diag(-3,1,2)": complex_stab_dim(sp.diag(-3, 1, 2)),
            "type O (Q=0)": complex_stab_dim(sp.zeros(3, 3)),
            "type N nilpotent": complex_stab_dim(sp.Matrix([[1, sp.I, 0], [sp.I, -1, 0], [0, 0, 0]]))}
    Qn = sp.Matrix([[1, sp.I, 0], [sp.I, -1, 0], [0, 0, 0]])
    must(Qn * Qn == sp.zeros(3, 3) and Qn != sp.zeros(3, 3), "type N not diagonalizable")
    must(dims["type D Schwarzschild diag(-2,1,1)"] == 2 and dims["type I diag(-3,1,2)"] == 0
         and dims["type O (Q=0)"] == 6, "Petrov isotropy")
    rec("P13", "Petrov types are the multiplicity types of the gravitational remainder", "BOUNDARY",
        f"Isotropy (real dim) of the Weyl operator Q in so(3,C) ~ so(1,3): type D {dims['type D Schwarzschild diag(-2,1,1)']} "
        f"(boost + rotation of Schwarzschild), type I 0, type O 6, as the multiplicity rule predicts. Type N "
        f"(Q nilpotent, isotropy {dims['type N nilpotent']}) is not diagonalizable: the self-adjoint remainder theorem "
        f"does not cover Petrov II, III, N.", details=dims)


# ================================================================ P14 conservation from declared transport
def P14():
    m = 1.0; ps = np.linspace(-8, 8, 3201); dp = ps[1] - ps[0]
    p0 = np.sqrt(ps ** 2 + m * m); v = ps / p0
    def f(tt, xx, decay=0.0):
        return np.exp(-(xx - v * tt) ** 2 - ps ** 2 / 2 - decay * tt)
    def T(tt, xx, decay=0.0):
        F = f(tt, xx, decay) / p0
        T00 = np.sum(p0 * p0 * F) * dp; T01 = np.sum(p0 * ps * F) * dp; T11 = np.sum(ps * ps * F) * dp
        return np.array([[T00, T01], [T01, T11]])
    h = 1e-4; worst = {}
    for decay in (0.0, 0.3):
        res = 0.0; scale = 0.0
        for (tt, xx) in [(0.3, 0.1), (1.0, -0.4), (2.0, 1.2)]:
            dT = (T(tt + h, xx, decay) - T(tt - h, xx, decay)) / (2 * h)
            dX = (T(tt, xx + h, decay) - T(tt, xx - h, decay)) / (2 * h)
            div = dT[0] + dX[1]
            res = max(res, np.abs(div).max()); scale = max(scale, np.abs(dT).max())
        worst[decay] = res / scale
    must(worst[0.0] < 1e-6 and worst[0.3] > 1e-2, "conservation iff free transport")
    rec("P14", "Conservation div T = 0 follows from transport of the momentum law by free fall (declared)",
        "BOUNDARY", f"1+1 free-streaming massive gas: relative divergence {worst[0.0]:.1e}; the same law with a "
        f"non-conservative decay: {worst[0.3]:.2f}. Conservation is a consequence of the declared transport "
        f"(Vlasov), not of the remainder.", details={str(k): v for k, v in worst.items()})


# ================================================================ P16 Fisher-stress identity
def P16():
    m = 1.0; ps = np.linspace(-30, 30, 60001); dp = ps[1] - ps[0]; p0 = np.sqrt(ps ** 2 + m * m)
    P = np.vstack([p0, ps])
    def Z(b):
        return np.sum(np.exp(-(b[0] * p0 + b[1] * ps)) / p0) * dp
    b = np.array([1.3, 0.4]); h = 1e-4
    W = np.exp(-(b[0] * p0 + b[1] * ps)) / p0 * dp
    Tdir = (P * W) @ P.T; N = P @ W; Z0 = Z(b)
    H = np.zeros((2, 2))
    for i in range(2):
        for j in range(2):
            ei, ej = np.eye(2)[i] * h, np.eye(2)[j] * h
            H[i, j] = (Z(b + ei + ej) - Z(b + ei - ej) - Z(b - ei + ej) + Z(b - ei - ej)) / (4 * h * h)
    lZ = lambda bb: math.log(Z(bb))
    Fi = np.zeros((2, 2))
    for i in range(2):
        for j in range(2):
            ei, ej = np.eye(2)[i] * h, np.eye(2)[j] * h
            Fi[i, j] = (lZ(b + ei + ej) - lZ(b + ei - ej) - lZ(b - ei + ej) + lZ(b - ei - ej)) / (4 * h * h)
    e1 = np.abs(H - Tdir).max() / np.abs(Tdir).max()
    e2 = np.abs(Z0 * (Fi + np.outer(N / Z0, N / Z0)) - Tdir).max() / np.abs(Tdir).max()
    must(e1 < 1e-5 and e2 < 1e-5 and np.linalg.eigvalsh(Fi).min() > 0, "Fisher-stress identity")
    rec("P16", "Symbol bridge: for the thermal (Juettner) law, T = Hess_beta Z = Z (g_Fisher + mu mu^T)",
        "LOCKED", f"1+1 Juettner gas at beta = (1.3, 0.4): Hessian of the partition function equals the direct "
        f"second moment (err {e1:.1e}); Z times (Fisher metric of the thermal family + mean outer product) equals "
        f"T (err {e2:.1e}); the Fisher metric is positive definite (Riemannian), as the positive-cost "
        f"obstruction requires.", details=dict(err_hessian=e1, err_fisher=e2))


# ================================================================ canaries
def canaries():
    rng = np.random.default_rng(sd(99)); out = []
    out.append(("non-null EM field is kinetic", bool(in_cone(em_T([1, 0, 0], [0, 0.3, 0])))))
    phi, sxx, syy, sxy = airy_family()
    Df = sp.lambdify((X_, Y_, T_), sp.expand((sxx - syy) / 2 + sp.I * sxy).subs(E_, 0.6), "numpy")
    w, _ = winding(lambda a, b: complex(Df(a, b, 0.5)), 0.0, (0.6 + math.sqrt(0.36 + 2)) / 2, 0.05)
    out.append(("isotropic-point index is an integer", abs(w / 2 - round(w / 2)) < 1e-6))
    out.append(("T = 0 forces flat space", abs(K_SCHW) < 1e-12))   # computed in P12 at m=1, r=3
    k = np.array([1.0, 1, 0, 0]); ev, EV = np.linalg.eig(np.outer(k, k) @ ETA)
    out.append(("null dust has a rest frame", any(EV[:, i].real @ ETA @ EV[:, i].real > 1e-9 for i in range(4))))
    T = T_of(rand_causal(rng, 5), np.ones(5)); B, _ = beam_decomposition(T); B[0] = B[0] * 1.01
    out.append(("perturbed beams still reproduce T", np.abs(sum(np.outer(p, p) for p in B) - T).max() < 1e-9))
    res = [dict(statement=s, accepted=bool(a), caught=not bool(a)) for s, a in out]
    must(all(r["caught"] for r in res), "canary accepted")
    return res


def main(outdir):
    out = pathlib.Path(outdir); out.mkdir(parents=True, exist_ok=True)
    src = pathlib.Path(__file__).read_bytes()
    manifest = dict(master_seed=MASTER_SEED, blind=False, data="analytic and synthetic fixtures only",
                    source_sha256=hashlib.sha256(src).hexdigest(),
                    written_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                    attacks=["P01", "P02", "P03", "P04", "P05", "P06", "P07", "P08", "P09", "P10", "P10b",
                             "P12", "P13", "P14", "P16"])
    mt = json.dumps(manifest, indent=2, sort_keys=True); (out / "rg_physical_path_manifest.json").write_text(mt)
    t0 = time.time()
    for fn in (P01, P02, P03, P04, P05, P06, P07, P08, P09_P10, P12, P13, P14, P16):
        fn()
    can = canaries()
    res = dict(manifest_sha256=hashlib.sha256(mt.encode()).hexdigest(), python=sys.version.split()[0],
               numpy=np.__version__, sympy=sp.__version__, platform=platform.platform(),
               runtime_s=round(time.time() - t0, 1), attacks=RES, canaries=can,
               summary={s: sum(r["status"] == s for r in RES) for s in ("LOCKED", "REFUTED", "BOUNDARY", "NO-GO")},
               verdict=("RG computes the source side (stress symbol, realizability, energy conditions, Landau frame, "
                        "remainder classes) and a remainder-driven conservation law for stress defects. It does not "
                        "compute the gravitational field: no function of the source remainder fixes the Weyl part."))
    (out / "rg_physical_path_results.json").write_text(json.dumps(res, indent=2, default=str))
    print(json.dumps(res["summary"]), res["runtime_s"], "s")
    for r in RES:
        print(r["id"], r["status"])


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default="."); main(ap.parse_args().out)
