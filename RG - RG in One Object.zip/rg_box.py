"""Resolution Geometry - the two-knob box: library.

Two hidden signed knobs x, y in [-1, 1]; an optional hidden display gain g; two displays
    F(x, y) = (a, b) = (g x^2, g x^2 y).
The single object computed here is the ANSWER RELATION of a declared record box and a declared task:
    R(record box) = { T(x, y) : (x, y) in knobs, F(x, y) in record box }
(the joint image of record and task, thickened by the record tolerance). Locks, walls, hidden rooms, anchors and
units are all read from it. Exact rational arithmetic throughout.
"""
from fractions import Fraction as Fr
import math

ONE = Fr(1)


def F(x, y, g=ONE):
    return (g * x * x, g * x * x * y)


def jacobian_det(x, y):
    """d(a,b)/d(x,y) = [[2x, 0], [2xy, x^2]] -> 2 x^3."""
    return 2 * x * x * x


def fibre_exact(a, b):
    """Compatible knob settings of an exact record (g = 1). Returns ('points', list) or ('segment', x) or ('empty',)."""
    a, b = Fr(a), Fr(b)
    if a < 0 or a > 1 or abs(b) > a:
        return ('empty',)
    if a == 0:
        return ('segment', Fr(0)) if b == 0 else ('empty',)
    r = math.isqrt(a.numerator * a.denominator)                  # exact square root when it exists
    s = Fr(r, a.denominator) if r * r == a.numerator * a.denominator else None
    return ('points', [(s, b / a), (-s, b / a)] if s is not None else [('+sqrt', b / a), ('-sqrt', b / a)])


def y_slice(A, B):
    """Exact set of y in [-1, 1] with some a in A (cap [0, 1]) and b in B such that b = a y (g = 1).
    A line through the origin with slope y meets the record box A x B. Returns (lo, hi) or None."""
    a_lo, a_hi = max(Fr(A[0]), Fr(0)), min(Fr(A[1]), ONE)
    b_lo, b_hi = Fr(B[0]), Fr(B[1])
    if a_lo > a_hi or b_lo > b_hi:
        return None
    if a_lo > 0:
        c = [b / a for a in (a_lo, a_hi) for b in (b_lo, b_hi)]
        lo, hi = min(c), max(c)
    elif b_lo <= 0 <= b_hi:
        lo, hi = -ONE, ONE                                        # the tip of the wedge is in the box
    elif b_lo > 0:
        if a_hi == 0:
            return None
        lo, hi = b_lo / a_hi, ONE
    else:
        if a_hi == 0:
            return None
        lo, hi = -ONE, b_hi / a_hi
    lo, hi = max(lo, -ONE), min(hi, ONE)
    return (lo, hi) if lo <= hi else None


def square_slice(Y):
    """Image of the task y^2 (the first display after swapping the knobs) over a y-interval."""
    if Y is None:
        return None
    lo, hi = Y
    return (Fr(0) if lo <= 0 <= hi else min(lo * lo, hi * hi), max(lo * lo, hi * hi))


def width(I):
    return None if I is None else I[1] - I[0]


def witness(A, B, Y):
    """A constructive member for a y-slice: pick y, then a in A with a*y in B (exact)."""
    if Y is None:
        return None
    for y in (Y[0], Y[1], (Y[0] + Y[1]) / 2):
        for a in (max(Fr(A[0]), Fr(0)), min(Fr(A[1]), ONE), (max(Fr(A[0]), Fr(0)) + min(Fr(A[1]), ONE)) / 2):
            if Fr(B[0]) <= a * y <= Fr(B[1]):
                return (a, y)
    return None


def status(I, tol, member):
    """Status read from the answer relation alone."""
    if I is None:
        return 'INCONSISTENT'
    if member is None:
        return 'UNWITNESSED'
    return 'LOCKED' if width(I) <= tol else 'UNRESOLVED'


def joint_tasks_exact(a, b, signed_meter=False):
    """Joint answer relation of the tasks (x, x*y) for an exact record with a a perfect square; optional signed x
    meter (a new record). Returns the set of jointly attainable answer pairs."""
    kind, pts = fibre_exact(a, b)[0], fibre_exact(a, b)[1:]
    if kind != 'points':
        raise ValueError('needs a regular record with rational square root')
    out = {(x, x * y) for x, y in pts[0]}
    if signed_meter:
        out = {p for p in out if p[0] > 0}
    return out


def gain_slices(a, b, G):
    """Hidden display gain g in G: the ratio y = b/a is forced exactly; x^2 = a/g is not."""
    a, b = Fr(a), Fr(b)
    return dict(y=(b / a, b / a), x2=(max(Fr(0), a / Fr(G[1])), min(ONE, a / Fr(G[0]))))   # capped by the knob range


def calibrate_gain(reference_reading, x_ref=ONE):
    """A reference input of known setting x_ref read through the first display fixes g = reading / x_ref^2."""
    return Fr(reference_reading) / (x_ref * x_ref)


# ------------------------------------------------------------------ shadows
def fisher_y(a, sigma_b):
    """Gaussian noise on the second display: Fisher information on y at fixed a is a^2 / sigma^2."""
    return (Fr(a) * Fr(a)) / (Fr(sigma_b) * Fr(sigma_b))


def local_norm(J, d):
    """Gauge (Minkowski) norm of a knob displacement d under a box tolerance on both displays: max |J d|."""
    return max(abs(J[0][0] * d[0] + J[0][1] * d[1]), abs(J[1][0] * d[0] + J[1][1] * d[1]))


def local_quadratic(J, d):
    """Gaussian (Fisher) shadow of the same tolerance: |J d|^2."""
    u = (J[0][0] * d[0] + J[0][1] * d[1], J[1][0] * d[0] + J[1][1] * d[1])
    return u[0] * u[0] + u[1] * u[1]
