#!/usr/bin/env python3
"""Resolution Geometry in one object - hostile battery (rg_one.py, rg_box.py).

  OA the object and its operations, on 500 seeded finite systems: every per-task relation is the projection of the
     joint relation, and the joint relation is strictly smaller than the product of its marginals on some records;
     adding a record coordinate only shrinks slices, garbling only enlarges them
  OB everyday 1, regression with collinear predictors: the coefficient beta_1 is a hidden room (slice spans the
     declared box) while beta_1 + beta_2 locks; the pseudo-inverse returns one member (1, 1) of the room as if it were
     the answer (truth (3, -1)); near collinearity the slice width per unit tolerance grows like 1/delta (a wall)
  OC everyday 2, partial qubit tomography: <sigma_x> = 2/3 and <sigma_z> = 1/3 leave <sigma_y>^2 in [0, 4/9] on the
     Bloch ball and exactly 4/9 on pure states (two points, a sign room); the symmetric completion <sigma_y> = 0 is not
     a member under the pure-state declaration; with tolerance the slices contain the truth
  OD everyday 3, forecast against retrodiction in the doubling map: one bit per step locks the past to 2^-n and never
     the future; with x_0 known to eps the forecast lock horizon gains exactly one step per halving of eps (the
     frontier slope 1/lambda, lambda = ln 2)
  OE everyday 4, ranging with unknown speed and offset: two surveyed references recover both exactly; one leaves a
     5.59 cm spread over a 0-50 us offset box; a declared zero offset biases by 4.13 cm
  OF everyday 5, the two-knob box: slice width 2 min(1, eps/a); off the wall the Fisher shadow and the box-tolerance
     norm agree within the factor sqrt 2 (norm equivalence, exact over 300 directions); at the wall the derivative
     vanishes, the Fisher bound is infinite, and the slice is [-1, 1]
  OG prior art and silent failures: classical set inversion by interval bisection reproduces the box slice as an outer
     cover with proved inner boxes (the object is not new); five standard point pipelines fail silently where the
     relation does not (selection by pseudo-inverse, symmetric completion, Cramer-Rao at a wall, per-task tables,
     a nominal gain)
  OH dictionary from smooth manifolds: the record image of the box has covering exponent 2 while the wall segment
     maps to one point; the rank of the derivative drops from 2 to 0 at the wall; a conversion between records
     exists only one way (kernel inclusion)

Seeds 1801-1806. Writes rg_one_battery_results.json.  Run: python3 -I rg_one_battery.py  (sympy)
"""
import hashlib, itertools, json, math, os, random, sys
from fractions import Fraction as Fr
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rg_one as O
import rg_box as B

R, FAILS = {}, []
ONE = Fr(1)


def must(cond, tag):
    if not cond and tag not in FAILS:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def f9(v):
    return None if v is None else float('%.9g' % float(v))


def group_OA():
    rng = random.Random(1801); strict = proj_bad = refine_bad = garble_bad = 0
    for _ in range(500):
        X = list(range(12)); Fm = {x: rng.randrange(4) for x in X}; G = {x: rng.randrange(3) for x in X}
        T1 = {x: rng.randrange(3) for x in X}; T2 = {x: rng.randrange(3) for x in X}; h = {0: 0, 1: 0, 2: 1, 3: 2}
        for r in set(Fm.values()):
            joint, marg = O.joint_and_marginals(X, Fm.get, [T1.get, T2.get], r)
            proj_bad += not ({j[0] for j in joint} == marg[0] and {j[1] for j in joint} == marg[1])
            strict += joint < {(u, v) for u in marg[0] for v in marg[1]}
            for g in set(G.values()):                                            # refinement (F, G)
                fine, _ = O.joint_and_marginals(X, lambda x: (Fm[x], G[x]), [T1.get, T2.get], (r, g))
                refine_bad += not fine <= joint
            coarse, _ = O.joint_and_marginals(X, lambda x: h[Fm[x]], [T1.get, T2.get], h[r])
            garble_bad += not joint <= coarse
    out = dict(records_with_joint_strictly_smaller=strict, projection_failures=proj_bad,
               refinement_failures=refine_bad, garbling_failures=garble_bad)
    must(strict > 0 and proj_bad == 0 and refine_bad == 0 and garble_bad == 0, 'OA')
    R['OA'] = out


def group_OB():
    out = {}; u = [ONE, Fr(2), Fr(3)]; truth = (Fr(3), Fr(-1)); eps = Fr(1, 10); box = Fr(10)
    design = [(ui, ui) for ui in u]; y = [ui * (truth[0] + truth[1]) for ui in u]
    V = O.polygon(O.regression_constraints(design, y, eps, box))
    s1 = O.linear_slice(V, (ONE, Fr(0))); ssum = O.linear_slice(V, (ONE, ONE))
    out['beta1_slice'] = [f9(v) for v in s1]; out['sum_slice'] = [f9(v) for v in ssum]
    must(s1[1] - s1[0] > 15 and s1[0] <= truth[0] <= s1[1], 'OB')                       # hidden room
    must(ssum == (2 - eps / 3, 2 + eps / 3), 'OB')                                     # lock, exact and tight
    member = (truth[0], truth[1] + Fr(1, 40))                                            # admissible: |u (1/40)| <= eps
    must(all(abs(d[0] * member[0] + d[1] * member[1] - yi) <= eps for d, yi in zip(design, y)) and
         ssum[0] <= member[0] + member[1] <= ssum[1], 'OB')
    p = O.pinv_solution(design, y); out['pinv'] = [str(v) for v in p]
    must(p == (ONE, ONE) and p != truth and s1[0] <= p[0] <= s1[1], 'OB')               # a member chosen silently
    rows = []
    for d in (Fr(1, 10), Fr(1, 100), Fr(1, 1000)):
        des = [(ONE, ONE + d), (Fr(2), Fr(2) - d), (Fr(3), Fr(3))]
        yy = [a * truth[0] + b * truth[1] for a, b in des]
        w = O.linear_slice(O.polygon(O.regression_constraints(des, yy, eps, box)), (ONE, Fr(0)))
        rows.append([f9(d), f9(w[1] - w[0])])
        must(w[0] <= truth[0] <= w[1], 'OB')
    out['near_collinear_width'] = rows
    must(rows[1][1] > 5 * rows[0][1], 'OB')                                            # width ~ eps / delta
    R['OB'] = out


def group_OC():
    out = {}; x, z, yt = Fr(2, 3), Fr(1, 3), Fr(2, 3)
    must(x * x + yt * yt + z * z == 1, 'OC')                                             # the truth is pure
    mixed = O.bloch_y2_slice((x, x), (z, z), pure=False); pure = O.bloch_y2_slice((x, x), (z, z), pure=True)
    out['mixed_y2'] = [str(v) for v in mixed]; out['pure_y2'] = [str(v) for v in pure]
    must(mixed == (0, Fr(4, 9)) and pure == (Fr(4, 9), Fr(4, 9)), 'OC')
    must(not (pure[0] <= 0 <= pure[1]) and mixed[0] <= 0 <= mixed[1], 'OC')             # y = 0 is not a pure member
    e = Fr(1, 100); pe = O.bloch_y2_slice((x - e, x + e), (z - e, z + e), pure=True)
    out['pure_y2_tol'] = [f9(v) for v in pe]
    must(pe[0] <= yt * yt <= pe[1] and pe[0] > 0, 'OC')
    must(O.bloch_y2_slice((Fr(9, 10), ONE), (Fr(9, 10), ONE), pure=False) is None, 'OC')  # records outside the ball
    R['OC'] = out


def group_OD():
    out = {}; x0 = Fr(5, 13); bad = 0
    for n in range(1, 21):
        bits = O.bit_records(x0, n); P = O.past_slice(bits); Fu = O.future_slice(bits)
        bad += not (P[0] <= x0 < P[1] and P[1] - P[0] == Fr(1, 2 ** n) and Fu == (0, ONE) and Fu[0] <= O.doubling(x0, n) < Fu[1])
    out['past_future_violations'] = bad
    must(bad == 0, 'OD')
    tol = Fr(1, 8); hz = [O.lock_horizon(Fr(1, 2 ** k), tol) for k in range(4, 16)]
    out['lock_horizons'] = hz
    must(hz[0] == 0 and all(b - a == 1 for a, b in zip(hz, hz[1:])), 'OD')
    must(O.forecast_width(Fr(1, 2 ** 10), 30) == 1, 'OD')
    R['OD'] = out


def group_OE():
    out = {}; c = Fr(1500); dl = Fr(37, 10 ** 6); tau = lambda L: 2 * Fr(L) / c + dl; L = Fr(12482924720280682, 10 ** 15)
    ch, dh = O.two_reference(5, tau(5), 10, tau(10))
    must(ch == c and dh == dl and ch * (tau(L) - dh) / 2 == L, 'OE')
    lo, hi = O.one_reference_range(5, tau(5), tau(L), (0, Fr(50, 10 ** 6)))
    out['one_reference_width_m'] = f9(hi - lo); out['zero_offset_bias_m'] = f9(5 * tau(L) / tau(5) - L)
    must(hi - lo > Fr(3, 100) and lo <= L <= hi and abs(5 * tau(L) / tau(5) - L) > Fr(3, 100), 'OE')
    R['OE'] = out


def group_OF():
    out = {}; rng = random.Random(1806); lo_r, hi_r = Fr(10), Fr(0)
    x0, y0 = Fr(3, 5), Fr(1, 3); J = [[2 * x0, Fr(0)], [2 * x0 * y0, x0 * x0]]
    for _ in range(300):
        d = (Fr(rng.randint(-50, 50)), Fr(rng.randint(-50, 50)))
        if d == (0, 0):
            continue
        r = B.local_quadratic(J, d) / B.local_norm(J, d) ** 2                     # squared ratio of shadow to norm
        lo_r, hi_r = min(lo_r, r), max(hi_r, r)
    out['shadow_over_norm_squared'] = [f9(lo_r), f9(hi_r)]
    must(1 <= lo_r and hi_r <= 2, 'OF')
    must(B.jacobian_det(Fr(0), Fr(1, 3)) == 0 and B.fisher_y(0, Fr(1, 1000)) == 0 and B.width(B.y_slice((0, 0), (-Fr(1, 1000), Fr(1, 1000)))) == 2, 'OF')
    must(all(B.width(B.y_slice((a, a), (-Fr(1, 100), Fr(1, 100)))) == 2 * min(ONE, Fr(1, 100) / a) for a in (ONE, Fr(1, 10), Fr(1, 1000))), 'OF')
    R['OF'] = out


def group_OG():
    out = {}; A = (Fr(1, 2) - Fr(1, 20), Fr(1, 2) + Fr(1, 20)); Bb = (Fr(1, 4) - Fr(1, 20), Fr(1, 4) + Fr(1, 20))
    exact = B.y_slice(A, Bb); gaps = []
    for depth in (8, 14, 20):
        cover, inner = O.sivia_y(A, Bb, depth)
        must(cover[0] <= exact[0] and exact[1] <= cover[1], 'OG')                     # an outer cover
        gaps.append(f9((cover[1] - cover[0]) - (exact[1] - exact[0])))
    out['sivia_excess_width'] = gaps; out['sivia_inner_boxes'] = inner
    Bn = (-Fr(1, 4) - Fr(1, 20), -Fr(1, 4) + Fr(1, 20)); en = B.y_slice(A, Bn); cn, _ = O.sivia_y(A, Bn, 14)
    must(cn is not None and cn[0] <= en[0] and en[1] <= cn[1], 'OG')                     # negative readings too
    must(gaps[0] > gaps[1] > gaps[2] >= 0 and inner > 0, 'OG')
    silent = dict(
        pseudo_inverse_selects_member=R['OB']['pinv'] == ['1', '1'],
        symmetric_completion_not_member=R['OC']['pure_y2'] == ['4/9', '4/9'],
        cramer_rao_infinite_at_bounded_wall=B.fisher_y(0, Fr(1, 1000)) == 0 and B.width(B.y_slice((0, 0), (0, 0))) == 2,
        per_task_tables_admit_unattainable_pairs=len(B.joint_tasks_exact(Fr(9, 25), Fr(3, 25))) == 2,
        nominal_gain_wrong=B.F(Fr(3, 5), Fr(1, 3), Fr(3, 2))[0] != Fr(9, 25) and
        B.gain_slices(*B.F(Fr(3, 5), Fr(1, 3), Fr(3, 2)), (Fr(1, 2), Fr(2)))['x2'][0] <= Fr(9, 25))
    out['silent_failures'] = silent
    must(all(silent.values()), 'OG')
    R['OG'] = out


def group_OH():
    out = {}; n = 400; pts = []
    for i in range(n + 1):
        for j in range(n + 1):
            x = -1 + 2 * i / n; y = -1 + 2 * j / n; pts.append((x * x, x * x * y))
    cells = [O.box_cells(pts, k) for k in (8, 16, 32, 64)]
    slopes = [math.log(b / a) / math.log(2) for a, b in zip(cells, cells[1:])]
    out['image_cells'] = cells; out['covering_slopes'] = [round(s, 6) for s in slopes]
    must(1.8 < slopes[-1] < 2.05, 'OH')
    wall = [(0.0, 0.0) for _ in range(50)]
    must(O.box_cells(wall, 64) == 1, 'OH')
    import sympy as sp
    xs, ys = sp.symbols('x y'); J = sp.Matrix([xs**2, xs**2 * ys]).jacobian([xs, ys])
    must(J.subs({xs: sp.Rational(1, 2), ys: sp.Rational(1, 3)}).rank() == 2 and J.subs({xs: 0, ys: sp.Rational(1, 3)}).rank() == 0, 'OH')
    rng = random.Random(1805); clash = 0
    for _ in range(200):
        x = Fr(rng.randint(1, 100), 100); y1, y2 = Fr(rng.randint(-100, 0), 100), Fr(rng.randint(1, 100), 100)
        clash += B.F(x, y1)[0] == B.F(x, y2)[0] and B.F(x, y1) != B.F(x, y2)
    out['a_does_not_determine_ab'] = clash
    must(clash == 200, 'OH')
    R['OH'] = out


GROUPS = dict(OA=group_OA, OB=group_OB, OC=group_OC, OD=group_OD, OE=group_OE, OF=group_OF, OG=group_OG, OH=group_OH)
CLAIMS = dict(OA='joint relation is terminal: projections give every task, marginals lose; refine shrinks, garble enlarges',
              OB='collinear regression: hidden room, forced combination, pseudo-inverse selects a member, near-collinear wall',
              OC='partial tomography: sign room on pure states; symmetric completion not a member; tolerance slices hold the truth',
              OD='doubling map: past locks at 2^-n, future never; lock horizon +1 per halving of eps',
              OE='ranging: two references exact; one reference spread; declared zero offset bias',
              OF='box: width law; Fisher shadow within sqrt 2 of the norm off the wall; derivative and Fisher vanish at the wall, slice [-1,1]',
              OG='prior art reproduces the slice (set inversion); five silent failures of point pipelines',
              OH='dictionary: covering exponent 2 of the record image, wall to a point, rank drop, one-way conversion')


def main():
    want = os.environ.get('RG_ONE_GROUPS'); sel = want.split(',') if want else list(GROUPS)
    if 'OG' in sel:
        for dep in ('OB', 'OC'):
            if dep not in sel:
                GROUPS[dep]()
    for g in sel:
        GROUPS[g](); R[g]['claim'] = CLAIMS[g]
    R['failures'] = FAILS; R['groups_run'] = sel
    R['source_sha256'] = {f: hashlib.sha256((HERE / f).read_bytes()).hexdigest() for f in ('rg_one.py', 'rg_box.py', 'rg_one_battery.py')}
    (HERE / 'rg_one_battery_results.json').write_text(json.dumps(R, indent=1, sort_keys=True))
    print(json.dumps({k: R[k] for k in sel}, indent=1, sort_keys=True))
    return 1 if FAILS else 0


if __name__ == '__main__':
    sys.exit(main())
