#!/usr/bin/env python3
"""Mutation suite for rg_one_battery.py.

Each mutation changes one line of the library (or of the battery's reference computation) so that a claim of the one-object print becomes false. It is caught only when the targeted group fails; the battery is run on that
group alone. A survivor is a defect of the battery; a crash is a defect of the suite, not a catch. Runs in temporary
copies.

    python3 -I rg_one_battery_mutations.py [--jobs 2] [--only UA,UB]
"""
import argparse, json, os, shutil, subprocess, sys, tempfile
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
NAME = 'rg_one_battery'
LIB = 'rg_one.py'
BAT = NAME + '.py'
MUTATIONS = [  # (group, description, file, old, new)
    ('OA', 'marginals read from the whole space, not the fibre', LIB, '    marg = [{T(x) for x in fib} for T in tasks]', '    marg = [{T(x) for x in X} for T in tasks]'),
    ('OA', 'refinement replaced by a garbled record', BAT, 'fine, _ = O.joint_and_marginals(X, lambda x: (Fm[x], G[x]), [T1.get, T2.get], (r, g))', 'fine, _ = O.joint_and_marginals(X, lambda x: h[Fm[x]], [T1.get, T2.get], h[r])'),
    ('OB', 'infeasible vertices kept', LIB, '        if all(lo <= u2[0] * p[0] + u2[1] * p[1] <= hi for u2, lo, hi in constraints):', '        if True:'),
    ('OB', 'record tolerance ignored in the regression', LIB, '    cons = [(d, yi - eps, yi + eps) for d, yi in zip(design, y)]', '    cons = [(d, yi - eps / 1000, yi + eps / 1000) for d, yi in zip(design, y)]'),
    ('OC', 'pure-state declaration dropped', LIB, '    return (max(Fr(0), 1 - M), 1 - m) if pure else (Fr(0), 1 - m)', '    return (Fr(0), 1 - m)'),
    ('OD', 'dyadic past slice one level too coarse', LIB, '    return (Fr(m, 2 ** n), Fr(m + 1, 2 ** n))', '    return (Fr(m, 2 ** n), Fr(m + 2, 2 ** n))'),
    ('OD', 'forecast arc without the two-sided tolerance', LIB, '    return min(ONE, Fr(2) ** n * 2 * Fr(eps))', '    return min(ONE, Fr(2) ** n * Fr(eps))'),
    ('OE', 'two-reference solve without the round-trip factor', LIB, '    inv = (Fr(t2) - Fr(t1)) / (2 * (Fr(L2) - Fr(L1)))', '    inv = (Fr(t2) - Fr(t1)) / (Fr(L2) - Fr(L1))'),
    ('OF', 'box norm replaced by the sum norm', BAT, 'r = B.local_quadratic(J, d) / B.local_norm(J, d) ** 2', 'r = B.local_quadratic(J, d) / (abs(J[0][0] * d[0] + J[0][1] * d[1]) + abs(J[1][0] * d[0] + J[1][1] * d[1])) ** 2'),
    ('OG', 'interval product without its corners', LIB, '        p = [I[0] * J[0], I[0] * J[1], I[1] * J[0], I[1] * J[1]]\n        return (min(p), max(p))', '        return (I[0] * J[0], I[1] * J[1])'),
    ('OG', 'set inversion never proves an inner box', LIB, '            if A[0] <= a[0] and a[1] <= A[1] and B[0] <= b[0] and b[1] <= B[1]:', '            if False:'),
    ('OH', 'wall made invisible: the squarer removed', BAT, 'J = sp.Matrix([xs**2, xs**2 * ys]).jacobian([xs, ys])', 'J = sp.Matrix([xs, xs * ys]).jacobian([xs, ys])'),
    ('OH', 'record image sampled through the knobs, not the displays', BAT, 'x = -1 + 2 * i / n; y = -1 + 2 * j / n; pts.append((x * x, x * x * y))', 'x = -1 + 2 * i / n; y = -1 + 2 * j / n; pts.append((x * x, 0.0))'),
]


def run(mut):
    group, desc, rel, old, new = mut
    base = open(os.path.join(HERE, rel)).read()
    if base.count(old) != 1:
        return group, desc, 'anchor not found exactly once -> SUITE DEFECT', False
    with tempfile.TemporaryDirectory() as tmp:
        work = os.path.join(tmp, 'b')
        shutil.copytree(HERE, work, ignore=shutil.ignore_patterns('__pycache__', NAME + '_results.json', NAME + '_mutations.py',
                                                                  '*.log', 'paper', '*.zip', 'RG_*bundle*', 'run*.log', 'RG_answer*'))
        open(os.path.join(work, rel), 'w').write(base.replace(old, new))
        env = dict(os.environ, RG_ONE_GROUPS=group)
        subprocess.run([sys.executable, '-I', NAME + '.py'], cwd=work, capture_output=True, text=True, env=env)
        try:
            fails = json.load(open(os.path.join(work, NAME + '_results.json')))['failures']
        except Exception:
            fails = ['CRASHED']
    ok = group in fails
    return group, desc, ('caught ' if ok else 'SURVIVED ') + str(fails), ok


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--jobs', type=int, default=2); ap.add_argument('--only', default='')
    a = ap.parse_args(); sel = [m for m in MUTATIONS if not a.only or m[0] in a.only.split(',')]
    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(run, sel))
    for g, d, msg, _ in res:
        print(f'{g}  {d}: {msg}', flush=True)
    caught = sum(r[3] for r in res)
    print(f'{caught} / {len(sel)} caught')
    return 0 if caught == len(sel) else 1


if __name__ == '__main__':
    sys.exit(main())
