#!/usr/bin/env python3
"""Mutation suite for rg_box_battery.py.

Each mutation changes one line of the library (or of the battery's reference computation) so that a claim about the two-knob box becomes false. It is caught only when the targeted group fails; the battery is run on that
group alone. A survivor is a defect of the battery; a crash is a defect of the suite, not a catch. Runs in temporary
copies.

    python3 -I rg_box_battery_mutations.py [--jobs 2] [--only UA,UB]
"""
import argparse, json, os, shutil, subprocess, sys, tempfile
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
NAME = 'rg_box_battery'
LIB = 'rg_box.py'
BAT = NAME + '.py'
MUTATIONS = [  # (group, description, file, old, new)
    ('BA', 'Jacobian determinant of the wrong order', LIB, 'return 2 * x * x * x', 'return 2 * x * x'),
    ('BA', 'negative branch of the fibre dropped', LIB, '[(s, b / a), (-s, b / a)] if s is not None', '[(s, b / a)] if s is not None'),
    ('BB', 'square of an interval through zero taken at the ends', LIB, '(Fr(0) if lo <= 0 <= hi else min(lo * lo, hi * hi)', '(min(lo * lo, hi * hi)'),
    ('BC', 'tip of the wedge in the record box read as y = 0', LIB, '        lo, hi = -ONE, ONE                                        # the tip', '        lo, hi = Fr(0), Fr(0)                                     # the tip'),
    ('BD', 'slice from the upper a edge only (misses admissible members)', LIB, 'c = [b / a for a in (a_lo, a_hi) for b in (b_lo, b_hi)]', 'c = [b / a for a in (a_hi,) for b in (b_lo, b_hi)]'),
    ('BD', 'joint relation replaced by the product of its marginals', LIB, '    out = {(x, x * y) for x, y in pts[0]}', '    out = {(x, u * v) for x, y in pts[0] for u, v in pts[0]}'),
    ('BD', 'status released without a witness', LIB, "    if member is None:\n        return 'UNWITNESSED'\n", "    if False:\n        return 'UNWITNESSED'\n"),
    ('BD', 'garbled slice reported as the full slice', BAT, 'garbled = B.y_slice(A, (-ONE, ONE))', 'garbled = B.y_slice((a0, a0), Bx)'),
    ('BE', 'reference calibration ignores the reference setting', LIB, 'return Fr(reference_reading) / (x_ref * x_ref)', 'return Fr(reference_reading) / x_ref'),
    ('BE', 'gain bounds exchanged', LIB, 'max(Fr(0), a / Fr(G[1])), min(ONE, a / Fr(G[0]))', 'max(Fr(0), a / Fr(G[0])), min(ONE, a / Fr(G[1]))'),
    ('BF', 'Fisher information linear in the gain', LIB, 'return (Fr(a) * Fr(a)) / (Fr(sigma_b) * Fr(sigma_b))', 'return Fr(a) / (Fr(sigma_b) * Fr(sigma_b))'),
    ('BF', 'quadratic shadow replaced by the box norm', LIB, '    return u[0] * u[0] + u[1] * u[1]', '    return max(abs(u[0]), abs(u[1])) ** 2'),
]


def run(mut):
    group, desc, rel, old, new = mut
    base = open(os.path.join(HERE, rel)).read()
    if base.count(old) != 1:
        return group, desc, 'anchor not found exactly once -> SUITE DEFECT', False
    with tempfile.TemporaryDirectory() as tmp:
        work = os.path.join(tmp, 'b')
        shutil.copytree(HERE, work, ignore=shutil.ignore_patterns('__pycache__', NAME + '_results.json', NAME + '_mutations.py',
                                                                  '*.log', 'paper', '*.zip', 'RG_*bundle*', 'run*.log'))
        open(os.path.join(work, rel), 'w').write(base.replace(old, new))
        env = dict(os.environ, RG_BOX_GROUPS=group)
        subprocess.run([sys.executable, '-I', NAME + '.py'], cwd=work, capture_output=True, text=True, env=env)
        try:
            fails = json.load(open(os.path.join(work, NAME + '_results.json')))['failures']
        except Exception:
            fails = ['CRASHED']
    ok = group in fails
    return group, desc, ('caught ' if ok else 'SURVIVED ') + str(fails), ok


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--jobs', type=int, default=2); ap.add_argument('--only', default='')
    a = ap.parse_args(); sel = [m for m in MUTATIONS if not a.only or m[0] in a.only.split(',')]
    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(run, sel))
    for g, d, msg, _ in res:
        print(f'{g}  {d}: {msg}', flush=True)
    caught = sum(r[3] for r in res)
    print(f'{caught} / {len(sel)} caught')
    return 0 if caught == len(sel) else 1


if __name__ == '__main__':
    sys.exit(main())
