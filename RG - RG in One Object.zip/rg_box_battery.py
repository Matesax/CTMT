#!/usr/bin/env python3
"""Resolution Geometry - hostile battery for the two-knob box and the answer relation (rg_box.py).

  BA exact layer: the record set is the wedge 0 <= a <= 1, |b| <= a (no record outside it, seeded); off the tip an
     exact record leaves exactly two settings (+-sqrt a, b/a), at the tip the whole segment {0} x [-1, 1]; the
     Jacobian determinant is 2 x^3 (symbolic); locally invertible off the wall, globally two-to-one
  BB forcing is a property of the task, not of identification: after swapping the knobs the first display reads
     y^2, forced as (b/a)^2 although the sign of x is not; at the tip every y^2 in [0, 1] is admitted; a signed x
     meter (a new record) resolves the sign and leaves the wall's y-slice unchanged
  BC resolution: with exact a > 0 and |b - 0| <= eps the y-slice has width 2 min(1, eps/a) exactly; the operational
     loss of resolution (width above a tolerance) begins at a = 2 eps / tol, before the structural wall at a = 0;
     better precision moves that boundary and never restores y at a = 0; with a tolerance on a too, the tip enters
     the record box for a <= eps_a and the slice jumps to [-1, 1]
  BD the answer relation is the object: the joint relation of tasks (x, xy) has 2 points while the product of its
     marginals has 4 (per-task tables lose the coupling); garbling (dropping a display) only enlarges slices;
     an added record only shrinks them; the slice covers every admissible member, not only the truth; a padded cover
     of an empty record box is UNWITNESSED, never LOCKED; every status (LOCKED, UNRESOLVED, INCONSISTENT) is read from slices and
     witnesses alone, and a slice is never reported without a witness
  BE units: with a hidden display gain g in [1/2, 2] the ratio y = b/a is forced exactly while x^2 spreads by a
     by more than a factor 3 up to the knob range (the dilation fibre); a reference input of known setting closes it; a nominal gain declared but not
     read through a display gives a wrong point answer, while the honest slice contains the truth
  BF shadows: off the wall the Gaussian (Fisher) shadow agrees with the slice (sd = sigma/a, slice half-width
     eps/a); at the wall Fisher is zero (Cramer-Rao infinite) while the slice is [-1, 1], bounded by the declared
     knob range, which the tensor cannot carry; under a box tolerance the local object is a norm that violates the
     parallelogram law, and its Fisher shadow satisfies it

Seed 1701. Writes rg_box_battery_results.json.   Run: python3 -I rg_box_battery.py  (sympy)
"""
import hashlib, json, os, sys
from fractions import Fraction as Fr
from pathlib import Path
import random

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import rg_box as B

R, FAILS = {}, []
ONE = Fr(1)


def must(cond, tag):
    if not cond and tag not in FAILS:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def f6(v):
    return None if v is None else float('%.9g' % float(v))


def group_BA():
    out = {}; rng = random.Random(1701); outside = 0
    for _ in range(2000):
        x = Fr(rng.randint(-1000, 1000), 1000); y = Fr(rng.randint(-1000, 1000), 1000)
        a, b = B.F(x, y)
        outside += not (0 <= a <= 1 and abs(b) <= a)
    out['records_outside_wedge'] = outside
    must(outside == 0, 'BA')
    k, pts = B.fibre_exact(Fr(9, 25), Fr(3, 25))
    out['fibre_regular'] = [[str(p[0]), str(p[1])] for p in pts]
    must(k == 'points' and set(pts) == {(Fr(3, 5), Fr(1, 3)), (Fr(-3, 5), Fr(1, 3))}, 'BA')
    must(all(B.F(*p) == (Fr(9, 25), Fr(3, 25)) for p in pts), 'BA')
    must(B.fibre_exact(0, 0) == ('segment', Fr(0)) and all(B.F(Fr(0), y) == (0, 0) for y in (Fr(-1), Fr(0), Fr(1, 3), Fr(1))), 'BA')
    must(B.fibre_exact(Fr(1, 4), Fr(1, 2))[0] == 'empty', 'BA')                                # outside the wedge
    import sympy as sp
    x, y = sp.symbols('x y'); J = sp.Matrix([x**2, x**2 * y]).jacobian([x, y])
    must(sp.simplify(J.det() - 2 * x**3) == 0, 'BA')
    must(all(B.jacobian_det(Fr(v), Fr(1, 3)) == 2 * Fr(v) ** 3 for v in (Fr(1, 2), Fr(-2, 3))), 'BA')
    out['det'] = str(J.det())
    R['BA'] = out


def group_BB():
    out = {}; a, b = Fr(9, 25), Fr(3, 25)
    Y = B.y_slice((a, a), (b, b)); S = B.square_slice(Y)
    out['swap_forced'] = [str(S[0]), str(S[1])]
    must(S == ((b / a) ** 2, (b / a) ** 2), 'BB')
    k, pts = B.fibre_exact(a, b)
    must(len({p[0] for p in pts}) == 2 and len({p[1] ** 2 for p in pts}) == 1, 'BB')        # sign open, task forced
    Yw = B.y_slice((0, 0), (0, 0)); Sw = B.square_slice(Yw)
    out['swap_at_wall'] = [str(Sw[0]), str(Sw[1])]
    must(Sw == (Fr(0), Fr(1)), 'BB')
    meter = [p for p in pts if p[0] > 0]                                                         # signed x meter
    must(len(meter) == 1 and B.y_slice((0, 0), (0, 0)) == Yw, 'BB')
    R['BB'] = out


def group_BC():
    out = {}; tol = Fr(1, 10); rows = []
    for eps in (Fr(1, 100), Fr(1, 1000)):
        for a in (Fr(1), Fr(1, 2), Fr(1, 10), Fr(1, 50), Fr(1, 200), Fr(1, 1000)):
            Y = B.y_slice((a, a), (-eps, eps))
            must(B.width(Y) == 2 * min(ONE, eps / a), 'BC')
            rows.append([f6(eps), f6(a), f6(B.width(Y))])
        boundary = 2 * eps / tol                                         # operational wall, before the structural one
        must(B.width(B.y_slice((boundary * Fr(11, 10),) * 2, (-eps, eps))) < tol and
             B.width(B.y_slice((boundary * Fr(9, 10),) * 2, (-eps, eps))) > tol, 'BC')
    out['width_rows'] = rows
    must(all(B.width(B.y_slice((0, 0), (-e, e))) == 2 for e in (Fr(1, 10), Fr(1, 10 ** 9))), 'BC')   # never restored
    ea = Fr(1, 100)
    near = B.y_slice((Fr(1, 200) - ea, Fr(1, 200) + ea), (-Fr(1, 1000), Fr(1, 1000)))
    far = B.y_slice((Fr(1, 2) - ea, Fr(1, 2) + ea), (-Fr(1, 1000), Fr(1, 1000)))
    out['tip_in_box_width'] = f6(B.width(near)); out['far_width'] = f6(B.width(far))
    must(B.width(near) == 2 and B.width(far) < Fr(1, 100), 'BC')
    R['BC'] = out


ONE = Fr(1)


def group_BD():
    out = {}; a, b = Fr(9, 25), Fr(3, 25)
    joint = B.joint_tasks_exact(a, b)
    m1 = {p[0] for p in joint}; m2 = {p[1] for p in joint}
    prod = {(u, v) for u in m1 for v in m2}
    out['joint_size'] = len(joint); out['product_size'] = len(prod)
    must(len(joint) == 2 and len(prod) == 4 and joint < prod, 'BD')
    must(len(B.joint_tasks_exact(a, b, signed_meter=True)) == 1, 'BD')                   # an added record shrinks
    rng = random.Random(1702); grow = shrink = 0
    for _ in range(300):
        a0 = Fr(rng.randint(1, 1000), 1000); y0 = Fr(rng.randint(-1000, 1000), 1000); e = Fr(rng.randint(1, 50), 1000)
        A = (a0 - e, a0 + e); Bx = (a0 * y0 - e, a0 * y0 + e)
        full = B.y_slice(A, Bx); garbled = B.y_slice(A, (-ONE, ONE))
        finer = B.y_slice((a0 - e / 2, a0 + e / 2), (a0 * y0 - e / 2, a0 * y0 + e / 2))
        grow += not (garbled[0] <= full[0] and full[1] <= garbled[1])
        shrink += not (full[0] <= finer[0] and finer[1] <= full[1])
        must(full[0] <= y0 <= full[1] and B.witness(A, Bx, full) is not None, 'BD')
    out['garbling_violations'] = grow; out['refinement_violations'] = shrink
    escaped = 0                                                          # the slice covers EVERY admissible member,
    for _ in range(300):                                                 # not only the truth
        a0 = Fr(rng.randint(1, 1000), 1000); e = Fr(rng.randint(1, 50), 1000); bc = Fr(rng.randint(-1000, 1000), 1000) * a0
        A = (a0 - e, a0 + e); Bx = (bc - e, bc + e); Y = B.y_slice(A, Bx)
        for _k in range(5):
            a = A[0] + (A[1] - A[0]) * Fr(rng.randint(0, 64), 64); b = Bx[0] + (Bx[1] - Bx[0]) * Fr(rng.randint(0, 64), 64)
            if 0 < a <= 1 and abs(b) <= a:
                escaped += not (Y[0] <= b / a <= Y[1])
    out['admissible_members_outside_slice'] = escaped
    must(escaped == 0, 'BD')
    A, Bx = (Fr(1, 4), Fr(1, 4)), (Fr(1, 2), Fr(3, 4))                   # an outward-padded cover of an empty box
    must(B.y_slice(A, Bx) is None and B.status((ONE, ONE), Fr(1, 10), B.witness(A, Bx, (ONE, ONE))) == 'UNWITNESSED', 'BD')
    must(grow == 0 and shrink == 0, 'BD')
    tol = Fr(1, 10); st = {}
    for name, (A, Bx) in dict(lock=((Fr(1, 2), Fr(1, 2)), (Fr(1, 4) - Fr(1, 100), Fr(1, 4) + Fr(1, 100))),
                              wide=((Fr(1, 50), Fr(1, 50)), (-Fr(1, 100), Fr(1, 100))),
                              empty=((Fr(1, 4), Fr(1, 4)), (Fr(1, 2), Fr(3, 4)))).items():
        Y = B.y_slice(A, Bx); st[name] = B.status(Y, tol, B.witness(A, Bx, Y))
    out['statuses'] = st
    must(st == dict(lock='LOCKED', wide='UNRESOLVED', empty='INCONSISTENT'), 'BD')
    R['BD'] = out


def group_BE():
    out = {}; x, y, g = Fr(3, 5), Fr(1, 3), Fr(3, 2)
    a, b = B.F(x, y, g); s = B.gain_slices(a, b, (Fr(1, 2), Fr(2)))
    out['y_slice'] = [str(v) for v in s['y']]; out['x2_slice'] = [str(v) for v in s['x2']]
    must(s['y'] == (y, y), 'BE')                                                               # ratio forced
    must(s['x2'][1] / s['x2'][0] > 3 and s['x2'][1] == 1 and s['x2'][0] <= x * x <= s['x2'][1], 'BE')   # dilation fibre,
    g_hat = B.calibrate_gain(B.F(Fr(1, 2), Fr(0), g)[0], Fr(1, 2))                             # capped by the knob range;
                                                                                               # reference input x = 1/2
    must(g_hat == g and a / g_hat == x * x, 'BE')
    nominal = a / ONE                                                                          # g = 1 declared, not read
    out['nominal_x2'] = str(nominal)
    must(nominal != x * x and s['x2'][0] <= x * x <= s['x2'][1], 'BE')
    R['BE'] = out


def group_BF():
    out = {}; sig = Fr(1, 1000)
    for a in (Fr(1, 2), Fr(1, 10), Fr(1, 100)):
        sd2 = 1 / B.fisher_y(a, sig); half = B.width(B.y_slice((a, a), (-sig, sig))) / 2
        must(sd2 == (sig / a) ** 2 and half == sig / a, 'BF')                                  # shadow agrees
    must(B.fisher_y(0, sig) == 0 and B.width(B.y_slice((0, 0), (-sig, sig))) == 2, 'BF')     # CR infinite, slice 2
    x0, y0 = Fr(3, 5), Fr(1, 3); J = [[2 * x0, Fr(0)], [2 * x0 * y0, x0 * x0]]
    worst = Fr(0); rng = random.Random(1703)
    for _ in range(200):
        u = (Fr(rng.randint(-9, 9)), Fr(rng.randint(-9, 9))); v = (Fr(rng.randint(-9, 9)), Fr(rng.randint(-9, 9)))
        add = (u[0] + v[0], u[1] + v[1]); sub = (u[0] - v[0], u[1] - v[1])
        lhs = B.local_norm(J, add) ** 2 + B.local_norm(J, sub) ** 2; rhs = 2 * B.local_norm(J, u) ** 2 + 2 * B.local_norm(J, v) ** 2
        if rhs:
            worst = max(worst, abs(lhs - rhs) / rhs)
        must(B.local_quadratic(J, add) + B.local_quadratic(J, sub) == 2 * B.local_quadratic(J, u) + 2 * B.local_quadratic(J, v), 'BF')
    out['parallelogram_defect_norm'] = f6(worst)
    must(worst > Fr(1, 10), 'BF')
    R['BF'] = out


GROUPS = dict(BA=group_BA, BB=group_BB, BC=group_BC, BD=group_BD, BE=group_BE, BF=group_BF)
CLAIMS = dict(BA='record wedge; two-point and segment fibres; Jacobian 2x^3', BB='task forced without identification; wall admits all; new record leaves the wall',
              BC='width 2min(1,eps/a); operational wall before the structural wall; tip in box', BD='the answer relation: joint beats marginals; garbling and refinement monotone; statuses from slices and witnesses',
              BE='hidden gain: ratio forced, magnitude a dilation fibre; reference input closes it; nominal declaration does not', BF='Fisher shadow agrees off the wall, loses the box at the wall; box tolerance gives a norm, not a tensor')


def main():
    want = os.environ.get('RG_BOX_GROUPS'); sel = want.split(',') if want else list(GROUPS)
    for g in sel:
        GROUPS[g](); R[g]['claim'] = CLAIMS[g]
    R['failures'] = FAILS; R['groups_run'] = sel
    R['source_sha256'] = {f: hashlib.sha256((HERE / f).read_bytes()).hexdigest() for f in ('rg_box.py', 'rg_box_battery.py')}
    (HERE / 'rg_box_battery_results.json').write_text(json.dumps(R, indent=1, sort_keys=True))
    print(json.dumps({k: R[k] for k in sel}, indent=1, sort_keys=True))
    return 1 if FAILS else 0


if __name__ == '__main__':
    sys.exit(main())
