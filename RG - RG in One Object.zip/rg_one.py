"""Resolution Geometry in one object: the answer relation, with five everyday computations.

    rho(record box) = { T(x) : x in X (declared), F(x) in record box }

Operations used here: slice (rho at a record box), refine (add a record coordinate), garble (drop or coarsen one),
join (several tasks at once), witness (a member). Exact rational arithmetic unless stated.
"""
from fractions import Fraction as Fr
import itertools, math

ONE = Fr(1)


# ------------------------------------------------------------------ linear set membership (exact 2-D LP by vertices)
def polygon(constraints):
    """Vertices of {beta in R^2 : lo <= u . beta <= hi for every (u, lo, hi)} (bounded; exact)."""
    lines = []
    for u, lo, hi in constraints:
        lines += [(u, lo), (u, hi)]
    verts = set()
    for (u, s), (w, t) in itertools.combinations(lines, 2):
        det = u[0] * w[1] - u[1] * w[0]
        if det == 0:
            continue
        p = ((s * w[1] - t * u[1]) / det, (u[0] * t - w[0] * s) / det)
        if all(lo <= u2[0] * p[0] + u2[1] * p[1] <= hi for u2, lo, hi in constraints):
            verts.add(p)
    return sorted(verts)


def linear_slice(verts, c):
    vals = [c[0] * p[0] + c[1] * p[1] for p in verts]
    return (min(vals), max(vals)) if vals else None


def regression_constraints(design, y, eps, box):
    """Records y_i = d_i . beta + e_i with |e_i| <= eps; declared |beta_j| <= box."""
    cons = [(d, yi - eps, yi + eps) for d, yi in zip(design, y)]
    return cons + [((ONE, Fr(0)), -box, box), ((Fr(0), ONE), -box, box)]


def pinv_solution(design, y):
    """The minimum-norm least-squares representative (what a solver returns) for a rank-deficient 2-column design."""
    import sympy as sp
    A = sp.Matrix([[sp.Rational(d[0]), sp.Rational(d[1])] for d in design]); b = sp.Matrix([sp.Rational(v) for v in y])
    s = A.pinv() * b
    return (Fr(str(s[0])), Fr(str(s[1])))


# ------------------------------------------------------------------ qubit with partial tomography
def bloch_y2_slice(X, Z, pure):
    """Records <sigma_x> in X, <sigma_z> in Z (intervals). Declared states: the Bloch ball, or its surface (pure).
    Returns the slice of y^2 (exact): pure gives 1 - [max, min] of x^2 + z^2, mixed gives [0, 1 - min]."""
    def sq_range(I):
        lo, hi = I
        return (Fr(0) if lo <= 0 <= hi else min(lo * lo, hi * hi), max(lo * lo, hi * hi))
    xs, zs = sq_range(X), sq_range(Z)
    m, M = xs[0] + zs[0], xs[1] + zs[1]
    if m > 1:
        return None
    return (max(Fr(0), 1 - M), 1 - m) if pure else (Fr(0), 1 - m)


# ------------------------------------------------------------------ the doubling map: forecast against retrodiction
def doubling(x, n=1):
    for _ in range(n):
        x = (2 * x) % 1
    return x


def bit_records(x0, n):
    """Coarse records: the first binary digit of each iterate x_0 .. x_{n-1}."""
    out, x = [], Fr(x0)
    for _ in range(n):
        out.append(int(2 * x >= 1)); x = doubling(x)
    return out


def past_slice(bits):
    """Settings of x_0 compatible with the bit records: a dyadic interval [m/2^n, (m+1)/2^n)."""
    m = 0
    for b in bits:
        m = 2 * m + b
    n = len(bits)
    return (Fr(m, 2 ** n), Fr(m + 1, 2 ** n))


def future_slice(bits):
    """Settings of x_n compatible with the same records: the doubling of the dyadic interval n times is [0, 1)."""
    lo, hi = past_slice(bits)
    return (Fr(0), ONE) if bits else (Fr(0), ONE)


def forecast_width(eps, n):
    """x_0 known to +-eps (an arc on the circle): the arc of x_n has length min(1, 2^n * 2 eps)."""
    return min(ONE, Fr(2) ** n * 2 * Fr(eps))


def lock_horizon(eps, tol):
    """Largest n with forecast width <= tol."""
    n = 0
    while forecast_width(eps, n + 1) <= tol:
        n += 1
    return n


# ------------------------------------------------------------------ ranging: scale and offset
def two_reference(L1, t1, L2, t2):
    inv = (Fr(t2) - Fr(t1)) / (2 * (Fr(L2) - Fr(L1)))
    return 1 / inv, Fr(t1) - 2 * Fr(L1) * inv


def one_reference_range(Lr, tr, t, dbox):
    v = [Fr(Lr) * (Fr(t) - d) / (Fr(tr) - d) for d in (Fr(dbox[0]), Fr(dbox[1]))]
    return min(v), max(v)


# ------------------------------------------------------------------ prior art: set inversion by interval bisection
def sivia_y(A, B, depth):
    """Outer cover of the box's y-slice by bisection on (x, y) in [-1,1]^2 with natural interval extensions; returns
    the hull of kept boxes and the inner (proved) boxes count. Classical set inversion (Jaulin-Walter)."""
    def sq(lo, hi):
        return (Fr(0) if lo <= 0 <= hi else min(lo * lo, hi * hi), max(lo * lo, hi * hi))
    def mul(I, J):
        p = [I[0] * J[0], I[0] * J[1], I[1] * J[0], I[1] * J[1]]
        return (min(p), max(p))
    boxes = [((-ONE, ONE), (-ONE, ONE))]; inner = []
    for _ in range(depth):
        nxt = []
        for X, Y in boxes:
            a = sq(*X); b = mul(a, Y)
            if a[1] < A[0] or a[0] > A[1] or b[1] < B[0] or b[0] > B[1]:
                continue
            if A[0] <= a[0] and a[1] <= A[1] and B[0] <= b[0] and b[1] <= B[1]:
                inner.append((X, Y)); continue
            if X[1] - X[0] >= Y[1] - Y[0]:
                m = (X[0] + X[1]) / 2; nxt += [((X[0], m), Y), ((m, X[1]), Y)]
            else:
                m = (Y[0] + Y[1]) / 2; nxt += [(X, (Y[0], m)), (X, (m, Y[1]))]
        boxes = nxt
    allb = boxes + inner
    if not allb:
        return None, 0
    return (min(Y[0] for X, Y in allb), max(Y[1] for X, Y in allb)), len(inner)


# ------------------------------------------------------------------ finite systems: joint relation is terminal
def joint_and_marginals(X, F, tasks, record):
    fib = [x for x in X if F(x) == record]
    joint = {tuple(T(x) for T in tasks) for x in fib}
    marg = [{T(x) for x in fib} for T in tasks]
    return joint, marg


# ------------------------------------------------------------------ dictionary checks on the box
def box_cells(points, k):
    return len({(math.floor(a * k), math.floor(b * k)) for a, b in points})
