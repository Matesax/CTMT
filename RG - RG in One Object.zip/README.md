# The two-knob box and the answer relation: battery

To run, use `python3 -I rg_box_battery.py` (needs sympy; under a second) and `python3 -I rg_box_battery_mutations.py --jobs 4`. Seeds are 1701, 1702 and 1703, and all arithmetic is exact rational. Reruns are byte-identical. The battery has six groups, all passing. The mutation suite has twelve mutations, and all twelve are caught: a mutation counts as caught only when its target group fails, and a crash is not a catch.

The box is two hidden knobs x, y in [-1, 1] with two displays, F(x, y) = (x², x²y). It has an optional hidden display gain g.

The object under test is the answer relation. For a record box and a task T it is

  ρ(record box) = { T(x, y) : F(x, y) lies in the record box },

which is the joint image of record and task, thickened by the record tolerance.

| Group | Claim | Result |
|---|---|---|
| BA | records fill the wedge 0 ≤ a ≤ 1, abs(b) ≤ a; off the tip a record has two settings, at the tip the segment {0}×[-1,1]; Jacobian determinant 2x³ | no record of 2000 seeded settings falls outside the wedge; fibres exact; determinant checked symbolically |
| BB | a task can be forced without identification | after swapping the knobs, y² = (b/a)² is forced while the sign of x is open; at the tip every y² in [0,1] remains; a signed x meter resolves the sign and leaves the tip slice unchanged |
| BC | resolution | width of the y slice is 2·min(1, ε/a) exactly; the operational wall (width above tolerance) starts at a = 2ε/tol, before the structural wall; no precision restores y at a = 0; with tolerance on a as well, the tip enters the record box and the slice jumps to [-1,1] |
| BD | one relation carries the machinery | the joint relation for the tasks (x, xy) has 2 points, while the product of its marginals has 4; garbling only enlarges slices and refinement only shrinks them (0 violations in 300 each); every admissible member lies in its slice (0 of 1500 outside); a padded cover of an empty box is UNWITNESSED, never LOCKED; LOCKED, UNRESOLVED and INCONSISTENT are all read from slices plus witnesses |
| BE | units | with a hidden gain in [1/2, 2], y = b/a is forced exactly, while x² spreads more than threefold, up to the knob range (the dilation fibre); a reference input of known setting closes it; a nominal gain that is declared but never read through a display gives a wrong point |
| BF | the tensor is a shadow | off the wall, the Fisher standard deviation σ/a equals the slice half-width ε/a; at the wall Fisher is 0 (Cramér–Rao bound infinite) while the slice is [-1,1], bounded by the declared knob range; under a box tolerance the local object is a norm with parallelogram defect 0.73, while its quadratic shadow satisfies the parallelogram law exactly |

Weak points found in the proposal:
- The width formula 2·min(1, ε_b/a) holds as stated. However, it is the declared knob range that makes the wall slice finite: with unbounded knobs, the slice at the tip would be all of ℝ.
- The gain extension shows that the box needs one more knob to exhibit units, anchors and the ratio scale.
- Requiring a witness cannot be tested on exact slices. It is tested here on a padded cover, which is what interval arithmetic produces.
