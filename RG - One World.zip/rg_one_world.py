"""One world, two protocols: a single spin-j entity under one Hamiltonian, read through fine and coarse protocols.
W1 exact Ehrenfest for Lie-algebraic Hamiltonians: <J>(t) follows classical rotation exactly, for every j (symbolic + numeric)
W2 fine protocol (sharp parity): Leggett-Garg K > 1 for every tested j (no macrorealist description)
W3 coarse protocol (fuzzy sign of J_z, resolution Delta): K <= 1 once Delta >~ sqrt(j); the coarse measurement is nearly non-invasive,
   the fine one is not
W4 nonlinear Hamiltonian (one-axis twisting): early on the coarse mean follows a classical ensemble; at t = pi j the quantum mean is -1,
   the classical +1 (a coarse-grained quantum effect); an unobserved environment (dephasing) erases it
W5 collapse as a protocol record update: the nonselective measurement equals a unitary on system + pointer followed by a partial trace
Run: python rg_one_world.py   (numpy, scipy, sympy); deterministic (no random sampling)
"""
import json, math, hashlib, pathlib
import numpy as np
from scipy.linalg import expm
from scipy.stats import norm
import sympy as sp
RES = {}
def must(c, m):
    if not c: raise AssertionError(m)
def spin(j):
    m = np.arange(j, -j - 1, -1).astype(float); d = len(m)
    Jz = np.diag(m).astype(complex); Jp = np.zeros((d, d), complex)
    for k in range(1, d): Jp[k - 1, k] = math.sqrt(j * (j + 1) - m[k] * (m[k] + 1))
    return m, (Jp + Jp.conj().T) / 2, (Jp - Jp.conj().T) / 2j, Jz
def top(d):
    r = np.zeros((d, d), complex); r[0, 0] = 1; return r

# W1 exact Ehrenfest (symbolic for the algebra; numeric for j = 7.5)
w, t = sp.symbols("omega t", real=True)
# Heisenberg: dJ/dt = i[H, J] with H = w Jx gives dJy/dt = w Jz, dJz/dt = -w Jy: a rotation, independent of j (only [Ji, Jj] = i eps Jk used)
j = 7.5; m, Jx, Jy, Jz = spin(j); rho = top(len(m)); errs = []
for tt in np.linspace(0, 6, 25):
    U = expm(-1j * 0.8 * Jx * tt); r = U @ rho @ U.conj().T
    errs.append(abs(np.trace(r @ Jz).real - j * math.cos(0.8 * tt)) + abs(np.trace(r @ Jy).real + j * math.sin(0.8 * tt)))
must(max(errs) < 1e-10, "W1")
RES["W1"] = dict(claim="For H linear in the su(2) generators, <J>(t) obeys the classical rotation law exactly at every j (only the Lie algebra is used)",
                 status="PROVED (Heisenberg equations) + numeric j = 7.5", max_error=float(max(errs)))

# W2 / W3 Leggett-Garg with fine and coarse protocols (rotation about x, initial |j, j>)
def LG(j, tau, kraus, H):
    m, Jx, Jy, Jz = spin(j); rho0 = top(len(m)); U = expm(-1j * H(Jx, Jy, Jz) * tau); U2 = U @ U; I = np.eye(len(m))
    Kp, Km = kraus(m)
    def corr(Ua, Ub):
        ra = Ua @ rho0 @ Ua.conj().T; c = 0.0
        for qa, Ka in ((1, Kp), (-1, Km)):
            ev = Ub @ (Ka @ ra @ Ka.conj().T) @ Ub.conj().T
            c += qa * (np.trace(Kp.conj().T @ Kp @ ev).real - np.trace(Km.conj().T @ Km @ ev).real)
        return c
    return corr(I, U) + corr(U, U) - corr(I, U2)
def parity(m):
    s = (-1.0) ** np.round(m.max() - m); return np.diag((s > 0) * 1.0).astype(complex), np.diag((s < 0) * 1.0).astype(complex)
def fuzzy(D):
    def f(m):
        ep = norm.cdf(m / D); return np.diag(np.sqrt(ep)).astype(complex), np.diag(np.sqrt(1 - ep)).astype(complex)
    return f
rot = lambda Jx, Jy, Jz: Jx
taus = np.linspace(0.01, math.pi, 240)
lg = {}
for jj in (5, 10, 20, 40):
    fine = max(LG(jj, tt, parity, rot) for tt in taus)
    coarse = {f"{k}sqrt(j)": float(max(LG(jj, tt, fuzzy(k * math.sqrt(jj)), rot) for tt in taus)) for k in (1, 2, 3)}
    lg[str(jj)] = dict(fine_parity_K=float(fine), coarse=coarse)
must(all(v["fine_parity_K"] > 1.1 for v in lg.values()) and all(v["coarse"]["2sqrt(j)"] <= 1 + 1e-9 for v in lg.values()), "W2/W3")
# invasiveness: TV of the later coarse statistics with vs without an earlier measurement
def later_stats(jj, tau, kraus_first, D):
    m, Jx, Jy, Jz = spin(jj); rho0 = top(len(m)); U = expm(-1j * Jx * tau)
    def p_plus(r):
        Kp, _ = fuzzy(D)(m); return np.trace(Kp.conj().T @ Kp @ r).real
    r_no = U @ U @ rho0 @ U.conj().T @ U.conj().T
    ra = U @ rho0 @ U.conj().T; Kp, Km = kraus_first(m)
    r_meas = U @ (Kp @ ra @ Kp.conj().T + Km @ ra @ Km.conj().T) @ U.conj().T
    return abs(p_plus(r_no) - p_plus(r_meas))
inv = {}
for jj in (10, 40):
    D = 2 * math.sqrt(jj); tau = math.pi / 3
    inv[str(jj)] = dict(after_fine_parity=float(later_stats(jj, tau, parity, D)), after_coarse=float(later_stats(jj, tau, fuzzy(D), D)))
must(all(v["after_fine_parity"] > 5 * v["after_coarse"] for v in inv.values()), "W3 invasive")
RES["W2_W3"] = dict(claim="Same entity, same Hamiltonian: the fine (parity) protocol violates Leggett-Garg; the coarse protocol (resolution >~ 2 sqrt(j)) does not, "
                          "and is nearly non-invasive while the fine one is invasive", status="EXECUTED (deterministic, j = 5..40)", leggett_garg=lg,
                    invasiveness=inv)

# W4 one-axis twisting: revival of the coarse mean; classical ensemble; dephasing
def twist_means(jj, Gamma, ts):
    # work in the Jx eigenbasis: H = Jx^2 / j, L = sqrt(Gamma) Jx commutes with H
    m, Jx, Jy, Jz = spin(jj); lam, V = np.linalg.eigh(Jx); rho0 = V.conj().T @ top(len(m)) @ V; Jz_x = V.conj().T @ Jz @ V
    out = []
    for tt in ts:
        ph = np.exp(-1j * (lam[:, None] ** 2 - lam[None, :] ** 2) * tt / jj) * np.exp(-Gamma * tt * (lam[:, None] - lam[None, :]) ** 2 / 2)
        out.append(float(np.trace((rho0 * ph) @ Jz_x).real / jj))
    return out
def classical_ensemble(jj, ts):
    m, Jx, Jy, Jz = spin(jj); lam, V = np.linalg.eigh(Jx); P = np.abs(V[0, :]) ** 2           # J_x distribution of |j, j>
    return [float(np.sum(P * np.sqrt(np.maximum(jj * (jj + 1) - lam ** 2, 0)) * np.cos(2 * lam * tt / jj)) / jj) for tt in ts]
tw = {}
for jj in (10, 20, 40):
    ts = [0.0, math.pi * jj / 4, math.pi * jj]
    q = twist_means(jj, 0.0, ts); c = classical_ensemble(jj, ts); dph = twist_means(jj, 0.05, ts)
    tw[str(jj)] = dict(times=["0", "pi j/4", "pi j (revival)"], quantum=q, classical_ensemble=c, dephased=dph)
must(all(abs(v["quantum"][2] + 1) < 1e-6 and v["classical_ensemble"][2] > 0.99 and abs(v["dephased"][2]) < 0.5
         and abs(v["quantum"][1] - v["classical_ensemble"][1]) < 0.01 for v in tw.values()), "W4")
RES["W4"] = dict(claim="Nonlinear (twisting) dynamics: quantum and classical-ensemble coarse means agree early (t = pi j/4) but at t = pi j the quantum "
                       "mean is -1 (a reversed coherent state, from the discreteness 2 lambda + 1) while the classical ensemble returns to +1; an unobserved "
                       "environment (dephasing Gamma = 0.05) drives the mean toward 0",
                 status="EXECUTED (exact in the Jx eigenbasis)", results=tw)

# W5 nonselective measurement = unitary dilation + partial trace (Stinespring / von Neumann pointer), exact for a qubit
P0 = np.diag([1, 0]).astype(complex); P1 = np.diag([0, 1]).astype(complex)
CNOT = np.kron(P0, np.eye(2)) + np.kron(P1, np.array([[0, 1], [1, 0]]))
psi = np.array([0.6, 0.8j]); rho_s = np.outer(psi, psi.conj()); rho_tot = CNOT @ np.kron(rho_s, np.diag([1, 0])) @ CNOT.conj().T
red = rho_tot.reshape(2, 2, 2, 2).trace(axis1=1, axis2=3)
must(np.allclose(red, P0 @ rho_s @ P0 + P1 @ rho_s @ P1) and np.allclose(CNOT @ CNOT.conj().T, np.eye(4)), "W5")
RES["W5"] = dict(claim="The nonselective measurement channel is a unitary interaction with a pointer followed by a partial trace (von Neumann; Ozawa): "
                       "'collapse' is the conditional record of a protocol; the law on system + pointer stays unitary", status="PROVED (exact qubit)")
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_one_world_results.json").write_text(json.dumps(RES, indent=1, default=float))
for k, v in RES.items():
    if isinstance(v, dict): print(k, "|", v["status"])
print(json.dumps(lg, indent=0)); print(inv); print(json.dumps(tw, indent=0))
