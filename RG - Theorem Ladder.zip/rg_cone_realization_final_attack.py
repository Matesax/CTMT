#!/usr/bin/env python3
"""Deterministic hostile battery for the RG observable-cone realization branch.

Purpose: attack whether the theorem ladder may jump directly from an observable
cone to Lorentzian conformal reconstruction, and whether an additional typed
realization rung is required.

Numerics are counterexample/search witnesses and regression checks. They are
not a proof of an exhaustive global classification.
"""
from __future__ import annotations
import json
import math
from pathlib import Path
import numpy as np

SEED = 20260925
rng = np.random.default_rng(SEED)
TOL = 1e-8
results = []

def record(name, passed, value=None, threshold=None, consequence=""):
    results.append({"name": name, "passed": bool(passed), "value": value,
                    "threshold": threshold, "consequence": consequence})

def sym_features(v):
    # coefficients for v^T G v in dimension 3, order 00,11,22,01,02,12
    t,x,y = v
    return np.array([t*t,x*x,y*y,2*t*x,2*t*y,2*x*y], float)

def fit_quadric(null_dirs):
    A = np.vstack([sym_features(v) for v in null_dirs])
    _, s, vh = np.linalg.svd(A, full_matrices=False)
    c = vh[-1]
    G = np.array([[c[0],c[3],c[4]],[c[3],c[1],c[5]],[c[4],c[5],c[2]]])
    G /= np.linalg.norm(G)
    residual = np.linalg.norm(A @ c) / max(np.linalg.norm(A), 1e-15)
    return G, residual, s

def quad_eval(G, V):
    return np.einsum('ni,ij,nj->n', V, G, V)

def fd_hessian(f, x, h=2e-4):
    x=np.asarray(x,float); n=len(x); H=np.zeros((n,n)); f0=f(x)
    for i in range(n):
        ei=np.zeros(n); ei[i]=h
        H[i,i]=(f(x+ei)-2*f0+f(x-ei))/(h*h)
        for j in range(i+1,n):
            ej=np.zeros(n); ej[j]=h
            H[i,j]=H[j,i]=(f(x+ei+ej)-f(x+ei-ej)-f(x-ei+ej)+f(x-ei-ej))/(4*h*h)
    return H

# A. Presentation attack: nonquadratic defining function, exactly quadratic cone.
angles=np.linspace(0,2*np.pi,181,endpoint=False)
Vq=np.c_[np.ones_like(angles),np.cos(angles),np.sin(angles)]
Gq,resq,_=fit_quadric(Vq)
hold=np.c_[np.ones(97),np.cos(np.linspace(.013,6.1,97)),np.sin(np.linspace(.013,6.1,97))]
errq=float(np.max(np.abs(quad_eval(Gq,hold))))
eigs=np.linalg.eigvalsh(Gq)
record("A1_nonquadratic_presentation_has_quadratic_projective_cone", errq<1e-10 and np.sum(eigs>0) in (1,2), errq, 1e-10,
       "Nonquadratic x=Q^3 does not imply non-Lorentzian cone geometry; classify the projective zero set, not the formula.")
# Explicit homogeneity degree check for x=Q^3.
v=np.array([1.4,.3,-.2]); lam=1.73
Q=lambda z: -z[0]**2+z[1]**2+z[2]**2
hom=abs(Q(lam*v)**3-lam**6*Q(v)**3)
record("A2_disguised_quadratic_degree_six", hom<1e-10, float(hom), 1e-10,
       "Polynomial degree alone cannot choose the realization branch.")

# B. Smooth single-sheet nonquadratic strongly convex cone.
eps=0.055
def Fsp(z):
    z=np.asarray(z,float); r=np.linalg.norm(z)
    return r + eps*np.sum(z**4)/(r**3)
def E(z): return 0.5*Fsp(z)**2
# Null boundary t=Fsp(direction), test failure of every fitted quadratic on held-out directions.
train_a=np.linspace(0,2*np.pi,90,endpoint=False)
test_a=np.linspace(np.pi/181,2*np.pi+np.pi/181,181,endpoint=False)
def finsler_null(a):
    z=np.c_[np.cos(a),np.sin(a)]
    t=np.array([Fsp(w) for w in z])
    return np.c_[t,z]
Gf,resf,_=fit_quadric(finsler_null(train_a))
ferr=float(np.sqrt(np.mean(quad_eval(Gf,finsler_null(test_a))**2)))
record("B1_regular_single_sheet_rejects_quadratic_cone", ferr>1e-4, ferr, 1e-4,
       "A regular nonquadratic branch exists; R17 cannot be the only realization rung.")
# Strong convexity of spatial Finsler energy on projective directions.
mins=[]; maxs=[]
for a in np.linspace(0,2*np.pi,121,endpoint=False):
    z=np.array([math.cos(a),math.sin(a)])
    ev=np.linalg.eigvalsh(fd_hessian(E,z))
    mins.append(ev[0]); maxs.append(ev[-1])
min_eig=float(min(mins)); max_cond=float(max(maxs)/min_eig)
record("B2_finsler_energy_strongly_convex", min_eig>0.2, min_eig, 0.2,
       "The single-sheet witness has a positive fibre Hessian on the sampled projective shell.")
# Lorentzian fibre Hessian for L=-t^2+F^2.
def L(w): return -w[0]**2 + Fsp(w[1:])**2
sig_ok=True; worst=1e9
for a in np.linspace(0,2*np.pi,73,endpoint=False):
    z=np.array([math.cos(a),math.sin(a)]); w=np.r_[1.3*Fsp(z),z]
    ev=np.linalg.eigvalsh(0.5*fd_hessian(L,w))
    sig_ok &= (np.sum(ev<0)==1 and np.sum(ev>0)==2)
    worst=min(worst,float(np.min(np.abs(ev))))
record("B3_lorentz_finsler_hessian_signature", sig_ok and worst>0.1, worst, 0.1,
       "A genuine Lorentz-Finsler-type regular cone survives the signature lock.")
# Homogeneity lock.
herrs=[]
for _ in range(100):
    z=rng.normal(size=2); l=float(rng.uniform(.2,3.0))
    herrs.append(abs(Fsp(l*z)-l*Fsp(z))/max(l*Fsp(z),1e-15))
record("B4_positive_homogeneity", max(herrs)<1e-12, float(max(herrs)), 1e-12,
       "The witness is cone-compatible rather than a generic nonhomogeneous admissibility relation.")

# C. Multicone witness: two persistent Lorentzian sheets.
c1,c2=1.0,1.55
def xm(v):
    t,x,y=v; r2=x*x+y*y
    return (t*t-c1*c1*r2)*(t*t-c2*c2*r2)
# roots on each radial direction; separation and factor residual.
sep=c2-c1
mres=max(abs(xm(np.array([c,math.cos(a),math.sin(a)]))) for c in (c1,c2) for a in angles)
record("C1_two_persistent_characteristic_sheets", sep>0.4 and mres<1e-10, float(mres), 1e-10,
       "Multiple regular characteristic sheets require a multicone branch rather than one conformal metric.")
# A single quadratic cannot have both circular null slopes.
Vm=np.vstack([np.c_[np.full_like(angles,c1),np.cos(angles),np.sin(angles)],
              np.c_[np.full_like(angles,c2),np.cos(angles),np.sin(angles)]])
Gm,resm,sm=fit_quadric(Vm)
held=float(np.sqrt(np.mean(quad_eval(Gm,Vm)**2)))
record("C2_multicone_rejects_single_quadric", held>1e-3, held, 1e-3,
       "The union of separated cone sheets is not the null set of one nondegenerate Lorentzian quadratic form.")

# D. Stratified transition: two sheets collide at a=1 and sheet count/type changes.
def roots_for(a): return sorted(set([1.0,abs(a)]))
left=len(roots_for(.72)); wall=len(roots_for(1.0)); right=len(roots_for(1.31))
record("D1_sheet_collision_changes_orbit_type", left==2 and wall==1 and right==2, [left,wall,right], "[2,1,2]",
       "A discriminant wall is unavoidable; one smooth global cone bundle is false.")
# At collision x=(t^2-r^2)^2: gradient vanishes on the characteristic set.
w=np.array([1.0,math.cos(.37),math.sin(.37)])
def xwall(z):
    t,x,y=z; q=t*t-x*x-y*y; return q*q
g=[]; h=1e-6
for i in range(3):
    e=np.zeros(3); e[i]=h; g.append((xwall(w+e)-xwall(w-e))/(2*h))
gnorm=float(np.linalg.norm(g))
record("D2_collision_wall_is_singular", gnorm<1e-8, gnorm, 1e-8,
       "The transition needs tangent-cone/slice or stratified data.")

# E. Residual-path attacks: trichotomy is gated, not exhaustive without assumptions.
# Nonhomogeneous x cannot define a cone under positive scaling.
def xnh(v):
    t,x,y=v; return -t*t+x*x+y*y+0.08*t**3
z=np.array([1.1,.4,.2]); l=1.8
nh=abs(xnh(l*z)-l**2*xnh(z))
record("E1_nonhomogeneous_residual_rejects_cone_typing", nh>1e-2, float(nh), 1e-2,
       "Without homogeneity, the object is a general admissibility/characteristic relation, not automatically Finsler, multicone, or cone-stratified.")
# Homogeneous but nonconvex projective section: r(theta)=1+0.32 cos(4theta), curvature numerator changes sign.
th=np.linspace(0,2*np.pi,2001)
r=1+0.32*np.cos(4*th); rp=-1.28*np.sin(4*th); rpp=-5.12*np.cos(4*th)
curv_num=r*r+2*rp*rp-r*rpp
record("E2_homogeneous_nonconvex_residual_rejects_finsler_lock", float(np.min(curv_num))<0, float(np.min(curv_num)), 0.0,
       "Homogeneity and one sheet do not suffice; convexity is an independent gate.")

# F. Classification-lock consistency.
all_core=all(r['passed'] for r in results)
record("F1_all_registered_attacks_pass", all_core, sum(r['passed'] for r in results), len(results),
       "The old direct cone-to-Lorentzian rung is incomplete; a gated realization module is required.")

summary={
    "seed":SEED,
    "registered":len(results),
    "passed":sum(r['passed'] for r in results),
    "failed":[r['name'] for r in results if not r['passed']],
    "verdict": (
        "NEW_RUNG_REQUIRED" if all(r['passed'] for r in results) else "BATTERY_FAILURE"
    ),
    "claim_boundary": (
        "The battery proves necessity by explicit counterexamples to a direct universal Lorentzian branch and verifies finite witnesses for quadratic-presentation, Lorentz-Finsler, multicone, stratified, and residual branches. It does not prove that these branches exhaust all possible characteristic geometries."
    ),
    "results":results,
}
out=Path('/mnt/data/rg_cone_realization_final_attack.json')
out.write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({k:summary[k] for k in ('seed','registered','passed','failed','verdict')},indent=2))
