#!/usr/bin/env python3
"""Deterministic attack on quadratic, Finsler-like, multicone, and stratified null structures.

We probe homogeneous dispersion functions X(y), y=(t,x,y), through the projective slice t=1.
For each spatial direction n(theta), we solve X(1, s n)=0 for positive speeds s.
The resulting root branches form candidate cone sheets. Branch birth/death, merging,
and vanishing full gradient are candidate strata/singular walls.

The script deliberately includes both positive controls and false-structure controls.
It does not prove a universal classification theorem; it tests identifiable signatures.
"""
from __future__ import annotations
import json
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import brentq, least_squares
from scipy.optimize import linear_sum_assignment

OUT = Path('/mnt/data')
SEED = 20260925
rng = np.random.default_rng(SEED)
EPS = 1e-10

@dataclass
class Model:
    name: str
    degree: int
    func: callable


def q(v, ax=1.0, ay=1.0, tilt=0.0):
    t, x, y = v
    return t*t + 2*tilt*t*x - ax*x*x - ay*y*y

# Controls and attacks.
models = [
    Model('quadratic_lorentz', 2, lambda v: q(v, 1.0, 1.0)),
    Model('quadratic_anisotropic', 2, lambda v: q(v, 1.35, 0.72, 0.12)),
    # Smooth, homogeneous degree 2, but not polynomial-quadratic. A genuine direction-dependent candidate.
    Model('finsler_smooth', 2, lambda v: q(v, 1.0, 1.0) + 0.24*((v[1]**4 - 6*v[1]**2*v[2]**2 + v[2]**4)/(v[1]**2+v[2]**2+0.12*v[0]**2))),
    # Two Lorentz factors: exact multicone positive control.
    Model('bimetric_product', 4, lambda v: q(v, 1.00, 1.00)*q(v, 1.62, 0.58, -0.08)),
    # Sheets touch at selected directions, creating branch-merger strata.
    Model('touching_multicone', 4, lambda v: q(v, 1.0, 1.0)*(q(v, 1.0, 1.0) + 0.34*v[1]**2)),
    # Nonhomogeneous false control. Projective cone interpretation should fail scale consistency.
    Model('false_nonhomogeneous', 0, lambda v: q(v, 1.0, 1.0) + 0.18*v[0] + 0.08),
]


def finite_grad(f, v, h=2e-6):
    v = np.asarray(v, float)
    g = np.zeros(3)
    for i in range(3):
        e = np.zeros(3); e[i] = h
        g[i] = (f(v+e)-f(v-e))/(2*h)
    return g


def finite_hessian(f, v, h=2e-4):
    v = np.asarray(v, float)
    H = np.zeros((3,3))
    f0 = f(v)
    for i in range(3):
        ei = np.zeros(3); ei[i] = h
        H[i,i] = (f(v+ei)-2*f0+f(v-ei))/(h*h)
        for j in range(i+1,3):
            ej=np.zeros(3); ej[j]=h
            H[i,j]=H[j,i]=(f(v+ei+ej)-f(v+ei-ej)-f(v-ei+ej)+f(v-ei-ej))/(4*h*h)
    return H


def roots_for_theta(f, theta, smax=3.2, ns=1800):
    n = np.array([np.cos(theta), np.sin(theta)])
    ss = np.linspace(0.0, smax, ns)
    vals = np.array([f(np.array([1.0, s*n[0], s*n[1]])) for s in ss])
    roots=[]
    # Sign-changing simple roots.
    for i in range(ns-1):
        a,b=ss[i],ss[i+1]; fa,fb=vals[i],vals[i+1]
        if np.isfinite(fa) and np.isfinite(fb) and fa*fb < 0:
            try: roots.append(brentq(lambda s: f(np.array([1.0,s*n[0],s*n[1]])),a,b,maxiter=100))
            except ValueError: pass
    # Tangential/even-multiplicity roots: local minima of |X| followed by local refinement.
    av=np.abs(vals)
    scale=max(1.0,np.nanmedian(av))
    idx=np.where((av[1:-1] <= av[:-2]) & (av[1:-1] <= av[2:]) & (av[1:-1] < 2e-4*scale))[0]+1
    for i in idx:
        lo=max(0,i-3); hi=min(ns-1,i+3)
        grid=np.linspace(ss[lo],ss[hi],80)
        vv=np.abs([f(np.array([1.0,z*n[0],z*n[1]])) for z in grid])
        z=grid[int(np.argmin(vv))]
        if min(vv) < 1e-6*scale: roots.append(z)
    roots=np.array(sorted(roots))
    if roots.size:
        keep=np.r_[True,np.diff(roots)>2.5e-3]
        roots=roots[keep]
    return roots


def track_branches(root_lists, max_jump=0.12):
    branches=[]
    active={}
    for k, roots in enumerate(root_lists):
        roots=list(roots)
        if not active:
            for r in roots:
                b=np.full(len(root_lists),np.nan); b[k]=r; branches.append(b); active[len(branches)-1]=r
            continue
        ids=list(active.keys()); prev=np.array([active[i] for i in ids])
        if len(roots):
            C=np.abs(prev[:,None]-np.array(roots)[None,:])
            rr,cc=linear_sum_assignment(C)
            matched_ids=set(); matched_roots=set(); new_active={}
            for i,j in zip(rr,cc):
                if C[i,j] <= max_jump:
                    bid=ids[i]; branches[bid][k]=roots[j]; new_active[bid]=roots[j]
                    matched_ids.add(bid); matched_roots.add(j)
            for j,r in enumerate(roots):
                if j not in matched_roots:
                    b=np.full(len(root_lists),np.nan); b[k]=r; branches.append(b); new_active[len(branches)-1]=r
            active=new_active
        else:
            active={}
    return branches


def quadratic_fit_residual(model, samples):
    # Fit general symmetric quadratic y^T A y to X(y), normalized by RMS(X).
    Y=np.asarray(samples)
    Phi=np.column_stack([Y[:,0]**2, 2*Y[:,0]*Y[:,1], 2*Y[:,0]*Y[:,2], Y[:,1]**2, 2*Y[:,1]*Y[:,2], Y[:,2]**2])
    z=np.array([model.func(v) for v in Y])
    coef=np.linalg.lstsq(Phi,z,rcond=None)[0]
    pred=Phi@coef
    return float(np.sqrt(np.mean((z-pred)**2))/(np.sqrt(np.mean(z*z))+EPS))


def homogeneity_error(model, samples):
    if model.degree <= 0:
        degrees=range(1,7)
    else:
        degrees=[model.degree]
    best=np.inf; best_d=None
    for d in degrees:
        errs=[]
        for v in samples:
            for lam in (0.55,1.7):
                a=model.func(lam*v); b=(lam**d)*model.func(v)
                errs.append(abs(a-b)/(abs(a)+abs(b)+1e-8))
        e=float(np.median(errs))
        if e<best: best,best_d=e,d
    return best,best_d


def analyse(model):
    thetas=np.linspace(0,2*np.pi,361,endpoint=False)
    root_lists=[roots_for_theta(model.func,th) for th in thetas]
    branches=track_branches(root_lists)
    rows=[]
    for i,(th,roots) in enumerate(zip(thetas,root_lists)):
        n=np.array([np.cos(th),np.sin(th)])
        for j,s in enumerate(roots):
            v=np.array([1.0,s*n[0],s*n[1]])
            g=finite_grad(model.func,v)
            H=finite_hessian(model.func,v)
            rows.append(dict(model=model.name,theta=th,root_index=j,speed=s,
                             grad_norm=np.linalg.norm(g),hessian_norm=np.linalg.norm(H),
                             hessian_det=np.linalg.det(H),root_count=len(roots)))
    df=pd.DataFrame(rows)
    samples=rng.normal(size=(1200,3)); samples[:,0]+=1.4
    herr, inferred_degree=homogeneity_error(model,samples[:180])
    qres=quadratic_fit_residual(model,samples)
    counts=np.array([len(r) for r in root_lists])
    transitions=int(np.sum(counts != np.roll(counts,1)))
    if len(df):
        gmed=float(df.grad_norm.median()); singular=int(np.sum(df.grad_norm < max(2e-3,0.015*gmed)))
        # Hessian variation on normalized generic directions. Constant Hessian is quadratic signature.
        hs=[]
        for th in thetas[::6]:
            v=np.array([1.0,0.7*np.cos(th),0.7*np.sin(th)])
            hs.append(finite_hessian(model.func,v))
        hs=np.array(hs); hvar=float(np.linalg.norm(hs-hs.mean(0))/ (np.linalg.norm(hs.mean(0))*np.sqrt(len(hs))+EPS))
    else:
        singular=0; hvar=np.nan
    summary=dict(model=model.name,declared_degree=model.degree,inferred_degree=inferred_degree,
                 homogeneity_error=herr,quadratic_fit_relative_rmse=qres,hessian_relative_variation=hvar,
                 min_sheet_count=int(counts.min()),max_sheet_count=int(counts.max()),
                 sheet_count_transitions=transitions,candidate_singular_root_samples=singular,
                 discovered_branches=len([b for b in branches if np.sum(np.isfinite(b))>8]))
    return thetas,root_lists,branches,df,summary

all_df=[]; summaries=[]; analyses={}
for m in models:
    analyses[m.name]=analyse(m)
    all_df.append(analyses[m.name][3]); summaries.append(analyses[m.name][4])

roots_df=pd.concat(all_df,ignore_index=True)
summary_df=pd.DataFrame(summaries)
roots_df.to_csv(OUT/'multicone_root_samples.csv',index=False)
summary_df.to_csv(OUT/'multicone_attack_summary.csv',index=False)

# Classification is explicit and falsifiable, not a theorem.
def classify(r):
    if r.homogeneity_error > 1e-4:
        return 'reject cone: scale inconsistency'
    if r.max_sheet_count >= 2:
        if r.candidate_singular_root_samples > 0 or r.sheet_count_transitions > 0:
            return 'multicone with candidate strata'
        return 'regular multicone'
    if r.quadratic_fit_relative_rmse < 2e-5 and r.hessian_relative_variation < 2e-4:
        return 'single quadratic cone'
    return 'single nonquadratic/Finsler-like cone'
summary_df['attack_classification']=summary_df.apply(classify,axis=1)
summary_df.to_csv(OUT/'multicone_attack_summary.csv',index=False)

# Plot projective root branches.
fig,axs=plt.subplots(3,2,figsize=(13,12),sharex=True)
for ax,m in zip(axs.flat,models):
    th,root_lists,branches,df,s=analyses[m.name]
    for b in branches:
        if np.sum(np.isfinite(b))>8:
            ax.plot(th,b,lw=1.5)
    if len(df):
        gmed=df.grad_norm.median(); crit=df[df.grad_norm < max(2e-3,0.015*gmed)]
        ax.scatter(crit.theta,crit.speed,s=12,c='red',label='candidate singular')
    ax.set_title(m.name)
    ax.set_ylabel('projective speed s')
    ax.grid(alpha=.25)
axs[-1,0].set_xlabel('direction angle theta')
axs[-1,1].set_xlabel('direction angle theta')
fig.suptitle('Discovered null-sheet branches on t=1',y=.995)
fig.tight_layout()
fig.savefig(OUT/'multicone_branches.png',dpi=180)
plt.close(fig)

# Diagnostic phase plot.
fig,ax=plt.subplots(figsize=(9,6))
for _,r in summary_df.iterrows():
    ax.scatter(r.quadratic_fit_relative_rmse+1e-12,r.homogeneity_error+1e-12,
               s=70+50*r.max_sheet_count,label=r.model)
    ax.annotate(r.model,(r.quadratic_fit_relative_rmse+1e-12,r.homogeneity_error+1e-12),xytext=(5,4),textcoords='offset points',fontsize=8)
ax.set_xscale('log'); ax.set_yscale('log')
ax.set_xlabel('relative error of best global quadratic fit')
ax.set_ylabel('best projective homogeneity error')
ax.grid(alpha=.3,which='both')
ax.set_title('Attack map: quadraticity versus cone consistency')
fig.tight_layout(); fig.savefig(OUT/'multicone_attack_map.png',dpi=180); plt.close(fig)

record={
 'seed':SEED,
 'direction_samples':361,
 'speed_grid_samples':1800,
 'models':[m.name for m in models],
 'files':['multicone_attack_summary.csv','multicone_root_samples.csv','multicone_branches.png','multicone_attack_map.png']
}
(OUT/'multicone_reproducibility.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(summary_df.to_string(index=False))
print('\nWrote outputs to',OUT)
