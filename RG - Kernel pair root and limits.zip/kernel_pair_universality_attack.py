#!/usr/bin/env python3
"""Deterministic hostile battery for kernel-pair unification/universality.

This battery tests finite witnesses to the claims separated in the accompanying
paper. Numerical checks are implementation/reproducibility evidence, not proofs.
"""
from __future__ import annotations
import argparse, hashlib, json, math, platform, sys
from dataclasses import dataclass, asdict
from pathlib import Path
import numpy as np

MASTER_SEED = 20260912
SUBSEEDS = {
    "linear_fibre": 2026091201,
    "fisher_completion": 2026091202,
    "blackwell": 2026091203,
    "oblique": 2026091204,
}
TOL = 1e-10

@dataclass
class Check:
    name: str
    passed: bool
    observed: object
    consequence: str

def rank(a, tol=TOL): return int(np.linalg.matrix_rank(a, tol=tol))
def nullity(a): return a.shape[1] - rank(a)
def add(C, name, cond, observed, consequence):
    C.append(Check(name, bool(cond), observed, consequence))

def main(out: Path):
    C=[]
    # 1. Regular linear fibre.
    rng=np.random.default_rng(SUBSEEDS["linear_fibre"])
    J=rng.normal(size=(3,6))
    _,_,Vt=np.linalg.svd(J, full_matrices=True)
    N=Vt[rank(J):].T
    x=rng.normal(size=6); delta=N@rng.normal(size=N.shape[1])
    err=float(np.linalg.norm(J@(x+delta)-J@x))
    add(C,"regular_linear_fibre",err<1e-12,{"fibre_error":err,"nullity":N.shape[1]},
        "For a regular linear map, ker dF equals the fibre tangent and finite null moves stay in the fibre.")

    # 2. Singular counterexample F(t)=t^2 at zero.
    dF0=0.0; fibre_tangent_dim=0; differential_kernel_dim=1
    add(C,"singular_tangent_failure",differential_kernel_dim!=fibre_tangent_dim,
        {"map":"t^2","ker_dF_dim":1,"exact_fibre_tangent_dim":0},
        "At singular points ker dF need not be the tangent space of the exact fibre.")

    # 3. Jet visibility: first derivative zero, second nonzero.
    h=1e-4; f=lambda t:t*t
    d1=(f(h)-f(-h))/(2*h); d2=(f(h)-2*f(0)+f(-h))/h**2
    add(C,"second_jet_visibility",abs(d1)<1e-12 and abs(d2-2)<1e-7,
        {"first_derivative":d1,"second_derivative":d2},
        "Higher fibre contact is controlled by higher jets of F, not by Fisher covariance.")

    # 4. Smooth flat function: all tested jets vanish numerically while not locally constant.
    def flat(t): return 0.0 if t==0 else math.exp(-1.0/(t*t))
    vals=[flat(t) for t in (0.5,0.4,0.3)]
    add(C,"smooth_formal_vs_exact",all(v>0 for v in vals),{"F(0.5,0.4,0.3)":vals},
        "In C-infinity, formal infinite-order flatness at a point does not imply local constancy.")

    # 5. Fisher does not reconstruct a covariance completion.
    rng=np.random.default_rng(SUBSEEDS["fisher_completion"])
    A=rng.normal(size=(3,3)); SR=A@A.T+np.eye(3)
    Jr=np.hstack([np.eye(3),np.zeros((3,3))])
    fish=[]; covtr=[]
    for s in (1.0,9.0):
        Sigma=np.block([[SR,np.zeros((3,3))],[np.zeros((3,3)),s*np.eye(3)]])
        # Parameter is the 3D mean in observed block; standard Fisher = SR^{-1}.
        I=np.linalg.inv(SR)
        fish.append(I); covtr.append(float(np.trace(Sigma)))
    ferr=float(np.linalg.norm(fish[0]-fish[1]))
    add(C,"fisher_completion_nonuniqueness",ferr<TOL and abs(covtr[0]-covtr[1])>1,
        {"fisher_difference":ferr,"covariance_traces":covtr},
        "The same Fisher tensor can accompany different unobserved covariance completions.")

    # 6. Same identifiability kernel, strict Gaussian garbling.
    # N(theta,1) -> add N(0,3) -> N(theta,4), with Fisher 1 and 1/4.
    rng=np.random.default_rng(SUBSEEDS["blackwell"]); n=200000
    y=rng.normal(size=n); z=y+rng.normal(scale=math.sqrt(3),size=n)
    empirical_var=[float(np.var(y)),float(np.var(z))]
    add(C,"blackwell_not_kernel_pair",abs(empirical_var[0]-1)<0.02 and abs(empirical_var[1]-4)<0.05,
        {"kernel_pairs":"both diagonal","fisher":[1.0,0.25],"empirical_variances":empirical_var},
        "Identical parameter kernel pairs do not imply Blackwell equivalence or equal information.")

    # 7. Deterministic garbling gives kernel inclusion only.
    G=np.array([[1.,1.,0.],[0.,0.,1.]])
    nF=nullity(J); nGF=nullity(G@J)
    add(C,"deterministic_garbling_monotonicity",nGF>=nF,
        {"nullity_F":nF,"nullity_GF":nGF},
        "Deterministic post-processing coarsens the kernel pair and enlarges the differential null.")

    # 8. Precision null is computed, not exact.
    eps=1e-12; Jp=np.diag([1.0,eps,0.0]); true_rank=rank(Jp,tol=0.0)
    numerical_rank=rank(Jp,tol=1e-10)
    add(C,"precision_layer_separation",true_rank==2 and numerical_rank==1,
        {"exact_algebraic_rank":true_rank,"thresholded_rank":numerical_rank,"epsilon":eps},
        "Precision/threshold null lies in an evaluator, not in the exact kernel of F.")

    # 9. Representation null downstream: symmetric x makes linear feature orthogonal to x^2.
    xs=np.linspace(-1,1,1001); q=xs**2
    X1=np.column_stack([np.ones_like(xs),xs]); X2=np.column_stack([X1,q])
    r1=np.linalg.norm(q-X1@np.linalg.lstsq(X1,q,rcond=None)[0])
    r2=np.linalg.norm(q-X2@np.linalg.lstsq(X2,q,rcond=None)[0])
    add(C,"representation_layer_separation",r1>1 and r2<1e-10,
        {"linear_residual":float(r1),"quadratic_residual":float(r2)},
        "Representation loss occurs in a downstream map A although the observed data retain the dependence.")

    # 10. Gauge soundness is not completeness: finite hidden extension.
    # X={(q,h): q=0..4,h=0..2}; F(q,h)=q; declared A changes h only between 0 and 1.
    fibres=5; declared_orbits=10; completed_orbits=5
    add(C,"gauge_soundness_not_completeness",declared_orbits>fibres and completed_orbits==fibres,
        {"observation_fibres":fibres,"declared_orbits":declared_orbits,"completed_orbits":completed_orbits},
        "A sound declared groupoid can split an observation fibre; orbit equality needs completeness.")

    # 11. Complementarity witness.
    sx=np.array([[0,1],[1,0]],complex); sz=np.array([[1,0],[0,-1]],complex)
    comm=sx@sz-sz@sx; cn=float(np.linalg.norm(comm))
    add(C,"incompatible_measurement_family",cn>1,
        {"pauli_commutator_norm":cn},
        "A global product observation over all measurement contexts requires compatibility; it is not automatic.")

    # 12. Cone does not determine scale: conformal forms have same null cone.
    g=np.diag([-1.,1.,1.]); gp=7.3*g
    probes=np.array([[1,1,0],[1,0,1],[math.sqrt(2),1,1]],float)
    null_g=np.einsum('ni,ij,nj->n',probes,g,probes)
    null_gp=np.einsum('ni,ij,nj->n',probes,gp,probes)
    add(C,"cone_scale_independence",np.max(abs(null_g))<TOL and np.max(abs(null_gp))<TOL,
        {"scale_factor":7.3,"max_null_residual":float(max(np.max(abs(null_g)),np.max(abs(null_gp))))},
        "A regular quadratic cone fixes a conformal ray, not a metric scale.")

    # 13. Protocol-free uniqueness failure: two thresholds, same spectrum, different projectors.
    lam=np.array([0.2,0.8,1.2,2.0]); p1=(lam>0.5).astype(int); p2=(lam>1.5).astype(int)
    add(C,"protocol_free_uniqueness_failure",not np.array_equal(p1,p2),
        {"spectrum":lam.tolist(),"thresholds":[0.5,1.5],"projectors":[p1.tolist(),p2.tolist()]},
        "The experiment does not select threshold, gates, cone, scale, or protocol.")

    # 14. Fixed protocol completeness restores unique maximal mask.
    gate=np.array([1,0,1,1],int); canonical=p1*gate
    sound=[]
    for m in range(16):
        w=np.array([(m>>i)&1 for i in range(4)],int)
        if np.all(w<=canonical): sound.append(w.tolist())
    complete=[w for w in sound if w==canonical.tolist()]
    add(C,"fixed_protocol_maximality",len(sound)>1 and len(complete)==1,
        {"sound_sectors":len(sound),"complete_sectors":len(complete),"canonical":canonical.tolist()},
        "Soundness plus completeness selects the greatest sector only inside a fixed protocol fibre.")

    # 15. Correct Fisher orientation/type check.
    Jobs=rng.normal(size=(3,6)); Sigma=np.eye(3); I=Jobs.T@np.linalg.inv(Sigma)@Jobs
    add(C,"fisher_type_check",I.shape==(6,6),{"J_shape":list(Jobs.shape),"Sigma_shape":[3,3],"Fisher_shape":list(I.shape)},
        "For J: parameter to observation, Fisher is J^T Sigma^{-1} J on parameter tangents.")

    passed=sum(c.passed for c in C)
    payload={
      "title":"Kernel-pair unification and universality hostile battery",
      "master_seed":MASTER_SEED,"subseeds":SUBSEEDS,"tolerance":TOL,
      "environment":{"python":sys.version.split()[0],"numpy":np.__version__,"platform":platform.platform()},
      "summary":{"passed":passed,"total":len(C),"all_passed":passed==len(C)},
      "checks":[asdict(c) for c in C]
    }
    canonical=json.dumps(payload,sort_keys=True,separators=(",",":"),default=str).encode()
    payload["sha256_without_hash_field"]=hashlib.sha256(canonical).hexdigest()
    out.write_text(json.dumps(payload,indent=2,sort_keys=True),encoding="utf-8")
    print("KERNEL-PAIR UNIFICATION / UNIVERSALITY ATTACK")
    print(f"master seed: {MASTER_SEED}; checks: {passed}/{len(C)}")
    for i,c in enumerate(C,1): print(f"[{i:02d}] {'PASS' if c.passed else 'FAIL'} {c.name}: {c.observed}")
    print(f"JSON: {out}")
    return 0 if passed==len(C) else 1

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--json',default='/mnt/data/kernel_pair_universality_attack.json')
    raise SystemExit(main(Path(ap.parse_args().json)))
