import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Synthetic CTMT redshift attack battery
# -------------------------------------
# This is a synthetic stress test, not a physical prediction.
# It demonstrates how the identity tau_coh(T) = delta * T fails when
# specific admissibility components are violated.

c = 299_792_458.0
g = 9.80665
h = 1e-3  # 1 mm
omega = 2.7e15  # rad/s, Sr optical transition scale
T = 1.0  # s
sigma_min = 1.64e-4  # smallest singular value from the coil context (synthetic reuse)

delta = g * h / c**2
base_phase_rate = omega * delta
baseline_tau = delta * T

# Attack A: nonlinear transport distortion
# dphi/dt = omega * delta * (1 + beta * t/T)
def tau_nonlinear(beta, T=T, delta=delta):
    return delta * T * (1.0 + 0.5 * beta)

def eps_nonlinear(beta):
    return tau_nonlinear(beta) / (delta * T) - 1.0

# Attack B: null-sector leakage
# dphi/dt = omega*delta + nu*omega*delta*sin(Omega t)
Omega = 3.0 * np.pi / T

def tau_null_leak(nu, T=T, delta=delta, Omega=Omega):
    return delta * T + nu * delta * (1.0 - np.cos(Omega * T)) / Omega

def eps_null_leak(nu):
    return tau_null_leak(nu) / (delta * T) - 1.0

# Attack C: inversion instability via Tikhonov shrinkage
# r = s^2 / (s^2 + lambda), tau_rec = r * delta*T
def shrinkage_factor(lmbda, s=sigma_min):
    return s**2 / (s**2 + lmbda)

def tau_inversion(lmbda, T=T, delta=delta, s=sigma_min):
    return shrinkage_factor(lmbda, s) * delta * T

def eps_inversion(lmbda, s=sigma_min):
    return shrinkage_factor(lmbda, s) - 1.0

# Attack D: Fisher attenuation + noise (Monte Carlo)
rng = np.random.default_rng(42)

def monte_carlo_fisher_attack(a, sigma_phi=1e-4, npts=200, T=T, omega=omega, delta=delta, nmc=2000):
    t = np.linspace(0.0, T, npts)
    X = np.vstack([np.ones_like(t), t]).T
    XtX_inv = np.linalg.inv(X.T @ X)
    slopes = []
    for _ in range(nmc):
        noise = rng.normal(0.0, sigma_phi, size=npts)
        phi = a * omega * delta * t + noise
        beta_hat = XtX_inv @ (X.T @ phi)
        slope_hat = beta_hat[1]
        delta_hat = slope_hat / omega
        slopes.append(delta_hat)
    slopes = np.array(slopes)
    eps = slopes / delta - 1.0
    F_proxy = (a * omega * T / sigma_phi) ** 2
    return {
        'a': a,
        'sigma_phi': sigma_phi,
        'F_proxy': F_proxy,
        'eps_mean': float(np.mean(eps)),
        'eps_std': float(np.std(eps)),
        'eps_rmse': float(np.sqrt(np.mean(eps**2))),
    }

if __name__ == '__main__':
    beta_vals = np.linspace(0.0, 1.0, 101)
    eps_A = np.array([eps_nonlinear(b) for b in beta_vals])

    nu_vals = np.linspace(0.0, 1.0, 101)
    eps_B = np.array([eps_null_leak(nu) for nu in nu_vals])

    lambda_vals = np.logspace(-12, -4, 200)
    eps_C = np.array([eps_inversion(l) for l in lambda_vals])

    atten_vals = np.array([1.0, 0.7, 0.5, 0.2, 0.1, 0.05, 0.01])
    mc_rows = [monte_carlo_fisher_attack(a=float(a), sigma_phi=1e-4) for a in atten_vals]
    mc_df = pd.DataFrame(mc_rows)

    scenario_rows = [
        {'Scenario': 'baseline', 'Attack strength': 0.0, 'tau_coh_1s': baseline_tau, 'epsilon': 0.0,
         'Comment': 'Exact weak-field identity tau = delta T'},
        {'Scenario': 'nonlinear_transport', 'Attack strength': 0.2, 'tau_coh_1s': tau_nonlinear(0.2), 'epsilon': eps_nonlinear(0.2),
         'Comment': '20% linear-in-time transport distortion'},
        {'Scenario': 'null_leakage', 'Attack strength': 0.2, 'tau_coh_1s': tau_null_leak(0.2), 'epsilon': eps_null_leak(0.2),
         'Comment': '20% oscillatory null leakage in phase-rate channel'},
        {'Scenario': 'inversion_instability', 'Attack strength': 1e-8, 'tau_coh_1s': tau_inversion(1e-8), 'epsilon': eps_inversion(1e-8),
         'Comment': 'Tikhonov regularization above sigma_min^2 shrinks recovery'},
        {'Scenario': 'fisher_attenuation', 'Attack strength': 0.2, 'tau_coh_1s': 0.2 * baseline_tau, 'epsilon': -0.8,
         'Comment': 'Synthetic sensitivity attenuation a=0.2 before recovery'},
    ]
    scenario_df = pd.DataFrame(scenario_rows)

    scenario_df.to_csv('ctmt_redshift_attack_summary.csv', index=False)
    mc_df.to_csv('ctmt_redshift_fisher_monte_carlo.csv', index=False)

    fig, axes = plt.subplots(2, 2, figsize=(12, 9))
    ax = axes[0, 0]
    ax.plot(beta_vals, eps_A)
    ax.set_title('Attack A: Nonlinear transport')
    ax.set_xlabel('Distortion strength beta')
    ax.set_ylabel('Relative deviation epsilon')
    ax.grid(True, alpha=0.3)

    ax = axes[0, 1]
    ax.plot(nu_vals, eps_B)
    ax.set_title('Attack B: Null-sector leakage')
    ax.set_xlabel('Leakage strength nu')
    ax.set_ylabel('Relative deviation epsilon')
    ax.grid(True, alpha=0.3)

    ax = axes[1, 0]
    ax.semilogx(lambda_vals, eps_C)
    ax.set_title('Attack C: Inversion instability')
    ax.set_xlabel('Regularization lambda')
    ax.set_ylabel('Relative deviation epsilon')
    ax.grid(True, alpha=0.3)

    ax = axes[1, 1]
    ax.semilogx(mc_df['F_proxy'], mc_df['eps_rmse'], marker='o')
    ax.set_title('Attack D: Fisher attenuation + noise')
    ax.set_xlabel('Synthetic Fisher proxy F')
    ax.set_ylabel('RMSE of epsilon')
    ax.grid(True, alpha=0.3)

    fig.suptitle('Synthetic CTMT redshift attack battery', fontsize=14)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig('ctmt_redshift_attack_curves.png', dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.bar(scenario_df['Scenario'], scenario_df['epsilon'])
    ax.axhline(0.0, color='black', linewidth=1)
    ax.set_title('Representative relative deviation epsilon by attack scenario')
    ax.set_ylabel('Relative deviation epsilon')
    ax.tick_params(axis='x', rotation=20)
    ax.grid(True, axis='y', alpha=0.3)
    fig.tight_layout()
    fig.savefig('ctmt_redshift_attack_scenarios.png', dpi=180)
    plt.close(fig)

    with open('ctmt_redshift_attack_report.txt', 'w', encoding='utf-8') as f:
        f.write('Synthetic CTMT redshift attack battery\n')
        f.write(f'delta = {delta:.6e}\n')
        f.write(f'omega = {omega:.3e} rad/s\n')
        f.write(f'baseline phase-rate = omega*delta = {base_phase_rate:.6e} rad/s\n')
