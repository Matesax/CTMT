# RG final remainder: hostile battery report

## Verdict
On RG families of locally constant multiplicity type (declared resolved/null splitting, covariance
tensors, structure-preserving bundle isomorphisms) the final remainder is **coherent global
structure of classical type, not a primitive**:

    RG_mu(S)  ~=  C^inf(S, Delta_k)  x  prod_j Euc_{m_j}(S)  x  Euc_{p-r}(S)  x  Euc_{q-r}(S)

local moduli = canonical-correlation functions; global class = Euclidean block bundles
(E_1..E_k, K_R, K_N). This pair is the initial complete natural invariant (unique up to unique
isomorphism); for fixed moduli it is represented by B Aut_mu = prod BO(m_j) x BO(p-r) x BO(q-r),
unique up to homotopy equivalence. Across type-changing walls the remainder is witnessed (forced
w1 monodromy) but not classified: OPEN, which is not the same as primitive.

## Attacks (master seed 20261022; per-attack seed 20261022+101k where randomness is used)
| ID | Target claim (source) | Status | Witness |
|---|---|---|---|
| A01 | no faithful functor into any foundation (Lock Concl.) | REFUTED | forgetful functor; exhaustive F_3 category |
| A02 | residual = nonzero descent class (Lock Concl.) | REFUTED | contractible nerves: 1 class; S3 brute force 1/3/11 = Burnside |
| A03 | local similarity type complete (Global_RG) | SHARPENED | Moebius RG family, constant spectrum/cancorr/Aut, not trivial |
| A04 | global data exhaust remainder | REFUTED | point base, G=1 both, (B,M) differ |
| A05 | dim Aut decreasing in rank; full rank => trivial Aut (Lock Concl. prop:rigidity) | REFUTED | C=I/2: rank 3, dim 3; distinct full rank: Aut=Z2^3; formula exact on 22 rational instances (seed 20261527); 5000-sample sweep blind (seed 20266072) |
| A06 | dim Aut=0 means rigid | REFUTED | Z2^3 over S^1: 8 classes |
| A07 | principal Aut-bundle across types | BOUNDARY | dim Aut 2 -> 0 at t=0 |
| A08 | Cech defect -I = gluing failure (Groupoid GR06) | SHARPENED | filled triangle removable; RP^2 Z4->Z2 obstruction, all 2^15 lifts |
| A09 | holonomy norms certify (GR06) | SHARPENED | Frobenius 1.414 vs 10.607 for the same holonomy (seed 20261931) |
| A10 | naive nerve models | BOUNDARY | 250-degree arcs: Cech H^1=Z2, naive 0 |
| A11 | nontrivial class intrinsic | BOUNDARY | S3 forms: Aut 6 vs 3 |
| A12 | C_RN=0 intrinsic; (G,L,D) natural (Ladder R9) | BOUNDARY | L -> L+k exactly, G and D invariant |
| A13 | smooth descent | BOUNDARY | x^3 / cube root |
| A14 | terminal refinement unique, natural | CONFIRMED | 1296 cases, 82944 naturality checks |
| A15 | strata glue without residual (Ladder R21) | SHARPENED | wall monodromy -1 around collision, +1 away |
| A16 | Global Structure Theorem (numerical) | CONFIRMED | det(hol) = -1, -1 as predicted |
| A17 | coupling rank controls global remainder | SHARPENED | |Forms(S^1)| = 2^kappa: 4,8,16,8,8,4,2 |
| A18 | Fisher blindness only local (Ladder R9) | SHARPENED | same (R,Sigma_R,G), K_N trivial vs Moebius |

Canaries (must be rejected; all rejected): H^1(S^1;Z2) trivial; dim Aut(I/2)=0; distinct full-rank
Aut trivial; L invariant under complement change.

## Reproduce
    pip install -r requirements.txt
    python rg_final_remainder_attacks.py --out OUT
Runtime about 4 s. The manifest (spec + source SHA-256) is written before evaluation; the results
record its hash. Two fresh-process runs produce identical witnesses.

## Limitations
Not blind (same author for claims and fixtures). Finite enumeration and numerical sign witnesses
support the written proofs; they do not replace them. No online literature check was performed;
references are classical. "No primitive" is relative to the declared contract and to H-split,
H-type, H-mor. Classification across walls is open.
