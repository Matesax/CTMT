"""RG final-remainder hostile battery.

Purpose: attack every load-bearing step of the claim that the final remainder of
Resolution Geometry (RG) is either (a) a new primitive or (b) a global/coherent
structure.  Every attack returns an explicit witness (counterexample, exhaustive
enumeration, or exact identity).  Nothing here is fitted; all fixtures are
constructed mathematical objects, not data.

Run:  python rg_final_remainder_attacks.py --out OUTPUT_DIR
Needs: Python 3.10+, numpy, sympy.

Status vocabulary (per attack):
  REFUTED    - a corpus claim is false as stated; witness supplied
  SHARPENED  - a corpus claim survives only in a corrected/stronger form; witness supplied
  CONFIRMED  - claim survives exhaustive/exact attack on the stated domain (not a general proof)
  BOUNDARY   - claim holds on one side of an explicit hypothesis and fails on the other
Canaries are deliberately wrong statements that the harness must reject.

NOT blind: the same author designed claims and fixtures.  The manifest is written
before evaluation and hashed, which documents intent but is not an independent
pre-registration.
"""
import argparse, hashlib, itertools, json, math, pathlib, platform, sys, time
from fractions import Fraction as Fr
from collections import deque

import numpy as np
import sympy as sp

MASTER_SEED = 20261022
RESULTS = []


def seed_for(k):
    return MASTER_SEED + 101 * k


def record(aid, target, source, status, witness, seed=None, details=None):
    RESULTS.append(dict(id=aid, target_claim=target, source=source, status=status,
                        witness=witness, seed=seed, details=details or {}))


def must(cond, msg):
    if not cond:
        raise AssertionError(msg)


# ---------------------------------------------------------------- finite groups
def s3():
    els = list(itertools.permutations(range(3)))
    mul = lambda a, b: tuple(a[b[i]] for i in range(3))          # a after b
    inv = lambda a: tuple(sorted(range(3), key=lambda i: a[i]))
    return els, mul, inv, (0, 1, 2), [(1, 0, 2), (0, 2, 1)]


def z2n(n):
    els = list(itertools.product((0, 1), repeat=n))
    mul = lambda a, b: tuple((x + y) % 2 for x, y in zip(a, b))
    inv = lambda a: a
    gens = [tuple(1 if j == i else 0 for j in range(n)) for i in range(n)]
    return els, mul, inv, tuple([0] * n), gens


def orbit_count(G, V, edges, cocycle_faces=()):
    """Count gauge orbits of G-valued 1-cochains on a graph (edges oriented i->j),
    restricted to cochains satisfying the cocycle condition on listed filled faces
    (i,j,k): g_ij g_jk = g_ik.  Gauge: g_ij -> h_i g_ij h_j^{-1}.  Brute-force BFS."""
    els, mul, inv, e, gens = G
    eidx = {ed: n for n, ed in enumerate(edges)}

    def ok(st):
        return all(mul(st[eidx[(i, j)]], st[eidx[(j, k)]]) == st[eidx[(i, k)]]
                   for (i, j, k) in cocycle_faces)
    states = [st for st in itertools.product(els, repeat=len(edges)) if ok(st)]
    seen, orbits = set(), 0
    for st in states:
        if st in seen:
            continue
        orbits += 1
        dq = deque([st]); seen.add(st)
        while dq:
            cur = dq.popleft()
            for v in range(V):
                for h in gens:
                    new = list(cur)
                    for n, (i, j) in enumerate(edges):
                        g = new[n]
                        if i == v:
                            g = mul(h, g)
                        if j == v:
                            g = mul(g, inv(h))
                        new[n] = g
                    new = tuple(new)
                    if new not in seen:
                        seen.add(new); dq.append(new)
    return orbits, len(states)


def burnside_hom_free(G, n):
    """|Hom(F_n,G)/G| = (1/|G|) sum_g |C(g)|^n."""
    els, mul, inv, e, gens = G
    tot = 0
    for g in els:
        cg = sum(1 for h in els if mul(g, h) == mul(h, g))
        tot += cg ** n
    return Fr(tot, len(els))


# ---------------------------------------------------------------- GF(2) algebra
def gf2_rank(rows):
    rows = [r for r in rows if r]
    rank = 0
    rows = list(rows)
    while rows:
        piv = rows.pop()
        if piv == 0:
            continue
        rank += 1
        lb = piv & -piv
        rows = [r ^ piv if r & lb else r for r in rows]
    return rank


# ================================================================ A01
def A01_faithful_functor():
    """Corpus (Lock Conclusion, Verdict 'As a whole'): no faithful functor RG -> X into
    any single established framework.  Attack: the forgetful functor of any concrete
    category is faithful.  Exhaustive finite RG-type category over F_3."""
    p = 3
    mats = [((a, b), (c, d)) for a, b, c, d in itertools.product(range(p), repeat=4)
            if (a * d - b * c) % p]
    mm = lambda X, Y: tuple(tuple(sum(X[i][k] * Y[k][j] for k in range(2)) % p
                                  for j in range(2)) for i in range(2))
    tr = lambda X: ((X[0][0], X[1][0]), (X[0][1], X[1][1]))
    def line(v):
        return frozenset(tuple((t * x) % p for x in v) for t in range(p))
    def act(T, v):
        return tuple(sum(T[i][k] * v[k] for k in range(2)) % p for i in range(2))
    objs = [(line((1, 0)), ((1, 0), (0, 1))), (line((1, 0)), ((1, 0), (0, 2))),
            (line((0, 1)), ((1, 0), (0, 1))), (line((1, 1)), ((2, 1), (1, 2)))]
    def hom(x, y):
        out = []
        for T in mats:
            if frozenset(act(T, v) for v in x[0]) != y[0]:
                continue
            if mm(mm(tr(T), y[1]), T) != x[1]:
                continue
            out.append(T)
        return out
    counts, faithful, closed = {}, True, True
    H = {(i, j): hom(objs[i], objs[j]) for i in range(4) for j in range(4)}
    for (i, j), hs in H.items():
        counts[f"{i}->{j}"] = len(hs)
        faithful &= len(set(hs)) == len(hs)          # U(f)=U(g) => f=g
        for k in range(4):
            for f in hs:
                for g in H[(j, k)]:
                    closed &= mm(g, f) in H[(i, k)]
    ident = ((1, 0), (0, 1))
    must(all(ident in H[(i, i)] for i in range(4)), "identities")
    must(faithful and closed, "forgetful functor faithful and composition-closed")
    record("A01", "RG as a whole admits no faithful functor into any single foundation",
           "Resolution_Geometry_Lock_Conclusion.tex, Verdict v:whole",
           "REFUTED",
           "Forgetful functor U:(V,R,g)->V is faithful (morphisms ARE structure-preserving "
           "linear maps). Exhaustive F_3 instance: 4 objects, all hom-sets enumerated, "
           "composition closed, U injective on every hom-set.",
           details=dict(hom_counts=counts, GL2_F3=len(mats)))


# ================================================================ A02
def A02_contractible_and_classification():
    """Corpus: residual 'formalized as a nonzero descent class -- RG is a nontrivial
    bundle of foundations'.  Attack: over a contractible nerve every cocycle is a
    coboundary.  Simultaneously verify the classification |forms| = |Hom(pi_1,G)/G|
    by brute force for nonabelian G=S_3, independent of the proof."""
    G = s3()
    tree = orbit_count(G, 4, [(0, 1), (1, 2), (2, 3)])
    filled = orbit_count(G, 3, [(0, 1), (1, 2), (0, 2)], cocycle_faces=[(0, 1, 2)])
    circle = orbit_count(G, 3, [(0, 1), (1, 2), (0, 2)])
    eight = orbit_count(G, 5, [(0, 1), (1, 2), (0, 2), (0, 3), (3, 4), (0, 4)])
    pred = [burnside_hom_free(G, n) for n in (0, 1, 2)]
    must(tree[0] == 1 and filled[0] == 1, "contractible nerves have one class")
    must(circle[0] == pred[1] == 3, "circle: 3 classes = conjugacy classes of S3")
    must(eight[0] == pred[2] == 11, "figure eight: 11 classes (Burnside)")
    record("A02", "The RG residual is a nonzero descent class (RG is a nontrivial bundle)",
           "Resolution_Geometry_Lock_Conclusion.tex, Verdict v:whole",
           "REFUTED",
           "Nonzero class is a property of a family over a base, not of RG: on tree and "
           "filled-simplex nerves (contractible) all S3-cocycles are coboundaries "
           "(1 orbit). Classification cross-check by brute force: circle 3 = |S3 conj|, "
           "figure-eight 11 = Burnside (1/6)sum|C(g)|^2.",
           details=dict(tree=tree, filled_simplex=filled, circle=circle,
                        figure_eight=eight, burnside=[str(x) for x in pred]))


# ================================================================ A03
def A03_mobius_rg_family():
    """Global remainder exists and is invisible to every local invariant.
    O=R^2 trivial, R_t=span u(t), N_t=span w(t), u=(cos t/2, sin t/2), w=u rotated.
    Sigma_t = F S F^T, F=[u w], S=[[1,rho],[rho,1]]: periodic in t (F -> -F)."""
    rho = 0.4
    S = np.array([[1, rho], [rho, 1]])
    def F(t):
        return np.array([[math.cos(t / 2), -math.sin(t / 2)],
                         [math.sin(t / 2), math.cos(t / 2)]])
    ts = np.linspace(0, 2 * math.pi, 721)
    sig = [F(t) @ S @ F(t).T for t in ts]
    periodic = np.max(np.abs(sig[0] - sig[-1]))
    eig = np.array([np.linalg.eigvalsh(m) for m in sig])
    eig_spread = float(np.max(eig.max(0) - eig.min(0)))
    cc = []
    for t, m in zip(ts, sig):
        u, w = F(t)[:, 0], F(t)[:, 1]
        cc.append((u @ m @ w) / math.sqrt((u @ m @ u) * (w @ m @ w)))
    cc_spread = float(max(cc) - min(cc))
    flip = float(F(ts[-1])[:, 0] @ F(ts[0])[:, 0])
    # discrete: 3-arc cover, local frames +-u, Aut={(1,1),(-1,-1)} acting diagonally
    aut = [(a, b) for a in (1, -1) for b in (1, -1) if a * rho * b == rho]
    must(aut == [(1, 1), (-1, -1)], "Aut of rho-coupled (1,1) type")
    trans = [1, 1, -1]                     # edges 01,12,20 ; product = holonomy
    removable = False
    for h in itertools.product((1, -1), repeat=3):
        g = [h[0] * trans[0] * h[1], h[1] * trans[1] * h[2], h[2] * trans[2] * h[0]]
        removable |= all(x == 1 for x in g)
    must(periodic < 1e-12 and eig_spread < 1e-12 and cc_spread < 1e-12, "local invariants")
    must(abs(flip + 1) < 1e-12 and not removable, "nontrivial global form")
    record("A03", "Local invariants (spectra, canonical correlations, Aut) are complete",
           "Global_RG.md sec.4; Atlas similarity fingerprint tau(G)",
           "SHARPENED",
           "Explicit RG family over S^1 with constant spectrum {1-rho,1+rho}, constant "
           "canonical correlation rho, constant Aut=Z2, yet NOT isomorphic to the constant "
           "family: R is the Moebius line bundle (adapted frame returns as -u). "
           "All 8 vertex gauges on the 3-arc nerve fail to remove holonomy (-1,-1).",
           details=dict(rho=rho, sigma_periodicity_err=periodic, eig_spread=eig_spread,
                        cancorr_spread=cc_spread, frame_return_dot=flip))


# ================================================================ A04
def A04_point_base_local_residual():
    """Converse independence: over a point (H^1 trivial) the local residual is nonzero."""
    def G(S):
        a, c, d = S
        return 1 / (a - c * c / d)
    def BM(S):
        a, c, d = S
        return (c / a, d - c * c / a)
    S0 = (Fr(1), Fr(0), Fr(1)); S1 = (Fr(2), Fr(1), Fr(1))
    must(G(S0) == G(S1) == 1 and BM(S0) != BM(S1), "same G, different recovery")
    record("A04", "Global (descent) data alone exhaust the remainder",
           "implicit in 'nonzero descent class' reading", "REFUTED",
           "Base = point (no overlaps, H^1 trivial): Sigma0=I, Sigma1=[[2,1],[1,1]] share "
           "G=1 but (B,M)=(0,1) vs (1/2,1/2). Local layer is not reducible to global layer.",
           details=dict(G=str(G(S0)), BM0=[str(x) for x in BM(S0)],
                        BM1=[str(x) for x in BM(S1)]))


# ================================================================ A05
def aut_dim_exact(SR, SN, C):
    p, q = SR.shape[0], SN.shape[0]
    X = sp.Matrix(p, p, sp.symbols(f"x0:{p*p}"))
    Y = sp.Matrix(q, q, sp.symbols(f"y0:{q*q}"))
    eqs = list(X * SR + SR * X.T) + list(Y * SN + SN * Y.T) + list(X * C + C * Y.T)
    unk = list(X) + list(Y)
    M = sp.Matrix([[sp.diff(e, u) for u in unk] for e in eqs])
    return len(unk) - M.rank()


def predicted_dim(p, q, svals):
    nz = [s for s in svals if s != 0]
    r = len(nz)
    mult = {}
    for s in nz:
        mult[s] = mult.get(s, 0) + 1
    f = lambda m: m * (m - 1) // 2
    return sum(f(m) for m in mult.values()) + f(p - r) + f(q - r)


def cayley(n, rng):
    S = sp.zeros(n, n)
    for i in range(n):
        for j in range(i + 1, n):
            v = sp.Rational(int(rng.integers(-3, 4)), int(rng.integers(1, 4)))
            S[i, j], S[j, i] = v, -v
    I = sp.eye(n)
    return (I - S) * (I + S).inv()


def rand_spd_factor(n, rng):
    P = sp.zeros(n, n)
    for i in range(n):
        P[i, i] = sp.Rational(int(rng.integers(1, 4)), int(rng.integers(1, 3)))
        for j in range(i):
            P[i, j] = sp.Rational(int(rng.integers(-2, 3)), int(rng.integers(1, 3)))
    return P


def A05_rigidity():
    """Corpus Prop. 'Coupling rank controls symmetry dimension': dim Aut decreasing in
    rank C; p=q=3: 6,2,0,0; full-rank coupling rigidifies to the trivial automorphism.
    5000-sample sweep found no counterexample."""
    I3 = sp.eye(3)
    q = sp.Rational
    cases = {
        "C=0": sp.zeros(3, 3),
        "rank1": sp.diag(q(1, 2), 0, 0),
        "rank2_distinct": sp.diag(q(1, 2), q(1, 4), 0),
        "rank3_distinct": sp.diag(q(1, 2), q(1, 4), q(1, 8)),
        "rank2_equal": sp.diag(q(1, 2), q(1, 2), 0),
        "rank3_C=I/2": I3 / 2,
        "rank3_pair_equal": sp.diag(q(1, 2), q(1, 2), q(1, 4)),
    }
    dims = {k: aut_dim_exact(I3, I3, C) for k, C in cases.items()}
    must([dims[k] for k in ("C=0", "rank1", "rank2_distinct", "rank3_distinct")] == [6, 2, 0, 0],
         "generic corpus values reproduce")
    must(dims["rank3_C=I/2"] == 3, "C=I/2 full rank but dim Aut=3")
    must(dims["rank3_C=I/2"] > dims["rank1"], "not decreasing in rank")
    # group level: full rank distinct still has 2^3 sign automorphisms
    D = cases["rank3_distinct"]
    signs = list(itertools.product((1, -1), repeat=3))
    good = [(a, b) for a in signs for b in signs
            if sp.diag(*a) * D * sp.diag(*b).T == D]
    must(len(good) == 8 and all(a == b for a, b in good), "Aut finite = Z2^3, not trivial")
    # sharpened formula on seeded random rational instances, non-whitened blocks
    rng = np.random.default_rng(seed_for(5))
    checks = []
    patterns = [(2, 2, [q(1, 2), q(1, 2)]), (2, 3, [q(1, 3), 0]), (3, 2, [q(1, 2), q(1, 3)]),
                (3, 3, [q(1, 2), q(1, 2), q(1, 2)]), (3, 3, [q(1, 3), q(1, 3), 0]),
                (3, 4, [q(1, 2), q(1, 2), q(1, 5)]), (4, 3, [q(1, 4), 0, 0]),
                (4, 4, [q(1, 2), q(1, 2), q(1, 3), q(1, 3)]), (2, 4, [q(1, 2), q(1, 2)]),
                (4, 2, [0, 0]), (3, 3, [q(1, 2), q(1, 4), q(1, 6)])]
    for rep in range(2):
        for (p_, q_, sv) in patterns:
            r = min(p_, q_)
            Kd = sp.zeros(p_, q_)
            for i in range(r):
                Kd[i, i] = sv[i]
            U, V = cayley(p_, rng), cayley(q_, rng)
            K = U * Kd * V.T
            PR, PN = rand_spd_factor(p_, rng), rand_spd_factor(q_, rng)
            SR, SN = PR * PR.T, PN * PN.T
            C = PR * K * PN.T
            got = aut_dim_exact(SR, SN, C)
            exp = predicted_dim(p_, q_, sv)
            checks.append(dict(p=p_, q=q_, svals=[str(s) for s in sv], got=got, pred=exp))
            must(got == exp, f"dim formula fails at {p_},{q_},{sv}")
    # blindness of random sweeps
    rng2 = np.random.default_rng(seed_for(50))
    def num_dim(C):
        basis = []
        for i in range(3):
            for j in range(i + 1, 3):
                E = np.zeros((3, 3)); E[i, j] = 1; E[j, i] = -1; basis.append(E)
        cols = []
        for k in range(6):
            Xs = basis[k] if k < 3 else np.zeros((3, 3))
            Ys = basis[k - 3] if k >= 3 else np.zeros((3, 3))
            cols.append((Xs @ C + C @ Ys.T).ravel())
        sv_ = np.linalg.svd(np.array(cols).T, compute_uv=False)
        return int(np.sum(sv_ < 1e-9 * max(1, sv_.max())))
    sweep_hits = sum(num_dim(rng2.standard_normal((3, 3))) > 0 for _ in range(5000))
    must(sweep_hits == 0 and num_dim(np.eye(3)) == 3, "sweep blind, exact stratum not")
    record("A05", "dim Aut decreasing in rank C; full-rank coupling rigidifies to trivial Aut",
           "Resolution_Geometry_Lock_Conclusion.tex, Prop. prop:rigidity, Exp. seed 3",
           "REFUTED / SHARPENED",
           "C=I/2 (rank 3) has dim Aut=3 > dim Aut(rank 1)=2; full-rank distinct C has "
           "Aut=Z2^3 (8 sign pairs), not trivial. 5000-sample random sweep (seed "
           f"{seed_for(50)}) finds 0 hits: non-generic strata have measure zero. "
           "Exact replacement: Aut ~= prod O(m_i) x O(p-r) x O(q-r), "
           "dim = sum m_i(m_i-1)/2 + (p-r)(p-r-1)/2 + (q-r)(q-r-1)/2, verified exactly on "
           f"{len(checks)} seeded rational non-whitened instances.",
           seed=seed_for(5), details=dict(dims=dims, formula_checks=checks,
                                          sweep_hits=sweep_hits))


# ================================================================ A06
def A06_dimension_zero_not_rigid_globally():
    G = z2n(3)
    circ = orbit_count(G, 3, [(0, 1), (1, 2), (0, 2)])
    must(circ[0] == 8, "H^1(S^1;Z2^3)=8 classes")
    record("A06", "dim Aut = 0 means the geometry is rigid (no residual freedom)",
           "Resolution_Geometry_Lock_Conclusion.tex sec. Interlock B", "REFUTED",
           "Full-rank distinct coupling: Aut=Z2^3 (dim 0) yet 8 pairwise non-isomorphic "
           "global RG forms over S^1 (brute-force gauge orbits on 3-arc nerve, 512 states). "
           "Dimension zero kills continuous moduli of local symmetry, not global twisting.",
           details=dict(orbits=circ))


# ================================================================ A07
def A07_isotropy_jump():
    I2 = sp.eye(2)
    ts = [0, sp.Rational(1, 8), sp.Rational(1, 4), sp.Rational(1, 2)]
    dims = [aut_dim_exact(I2, I2, sp.diag(t, 0)) for t in ts]
    must(dims == [2, 0, 0, 0], "isotropy jumps at the wall t=0")
    record("A07", "A fixed-type RG atlas is a principal G_RG(tau)-bundle (extended across types)",
           "Global_RG.md sec.2; Groupoid GR04", "BOUNDARY",
           "Family C(t)=diag(t,0), p=q=2: dim Aut = 2 at t=0, 0 for t>0 (exact). Twisted forms "
           "of one model have pointwise isomorphic Aut, so no neighbourhood of t=0 is a "
           "principal-bundle twist of a single model. Principal language holds on each "
           "fixed-type stratum only (corpus GR04 already restricts it).",
           details=dict(t=[str(t) for t in ts], dims=dims))


# ================================================================ A08
RP2_FACES = [(0, 1, 2), (0, 2, 3), (0, 3, 4), (0, 4, 5), (0, 1, 5), (1, 2, 4),
             (2, 3, 5), (1, 3, 4), (2, 4, 5), (1, 3, 5)]


def A08_cocycle_defect():
    # (a) filled triangle, Aut=Z2, transitions are torsor choices: always repairable
    fixable_all = True
    for g01, g12, g02 in itertools.product((1, -1), repeat=3):
        ok = any((g01 * a) * (g12 * b) == g02 * c
                 for a, b, c in itertools.product((1, -1), repeat=3))
        fixable_all &= ok
    must(fixable_all, "filled triangle: every Z2 defect removable by re-choice")
    # (b) rigid canary: Aut trivial => defect is a genuine inconsistency
    rigid_fix = any((1 * a) * (1 * b) == -1 * c for a, b, c in [(1, 1, 1)])
    must(not rigid_fix, "rigid transitions cannot be repaired")
    # (c) RP^2 triangulation: Z4 -> Z2 lifting obstruction in H^2(RP^2;Z2)
    faces = [tuple(sorted(f)) for f in RP2_FACES]
    edges = sorted({(f[a], f[b]) for f in faces for a, b in ((0, 1), (1, 2), (0, 2))})
    eid = {e: n for n, e in enumerate(edges)}
    must(len(edges) == 15 and all(sum(set(e) <= set(f) for f in faces) == 2 for e in edges),
         "RP2 pseudomanifold check")
    d0 = [sum(1 << eid[e] for e in edges if v in e) for v in range(6)]   # rows: vertex -> edges
    d1_cols = []                                                           # edge -> faces mask
    for e in edges:
        d1_cols.append(sum(1 << n for n, f in enumerate(faces) if set(e) <= set(f)))
    def d1(mask):
        out = 0
        for n in range(15):
            if mask >> n & 1:
                out ^= d1_cols[n]
        return out
    # rank computations over GF(2)
    rk0 = gf2_rank(d0)
    ker1 = [m for m in range(1 << 15) if d1(m) == 0]
    dimker1 = int(math.log2(len(ker1)))
    imd1 = {d1(m) for m in range(1 << 15)}
    rk1 = int(math.log2(len(imd1)))
    H1, H2 = dimker1 - rk0, 10 - rk1
    must((H1, H2) == (1, 1), "H^1=H^2=Z2 for RP^2")
    im0 = set()
    for h in range(64):
        m = 0
        for v in range(6):
            if h >> v & 1:
                m ^= d0[v]
        im0.add(m)
    w1 = next(m for m in ker1 if m not in im0)            # nontrivial Z2 cocycle
    # lift to Z4 and compute defect; check defect class independent of lift and nonzero
    def z4_defect(lift):
        out = 0
        for n, (i, j, k) in enumerate(faces):
            val = (lift[eid[(j, k)]] - lift[eid[(i, k)]] + lift[eid[(i, j)]]) % 4
            must(val in (0, 2), "defect lies in 2Z4")
            if val == 2:
                out |= 1 << n
        return out
    base = [(w1 >> n) & 1 for n in range(15)]
    classes = set()
    for extra in range(1 << 15):                           # exhaustive over all 2^15 lifts
        lift = [base[n] + 2 * ((extra >> n) & 1) for n in range(15)]
        dmask = z4_defect(lift)
        classes.add(dmask in imd1)
    must(classes == {False}, "lifting obstruction nonzero for every one of 2^15 lifts")
    # canary: trivial class lifts
    triv = [0] * 15
    must(z4_defect(triv) in imd1, "trivial class lifts")
    record("A08", "Admissible edges with Cech defect Omega=-I signal a gluing failure",
           "RG_-_The_Groupoid_of_Resolution.tex GR06; conversion bundle gluing control",
           "SHARPENED",
           "If transitions are choices inside Isom-torsors (Aut nontrivial), a triple defect "
           "is NOT an obstruction by itself: on a filled triangle all 8 Z2 defects are "
           "removed by re-choosing one edge. It is an obstruction iff its class in H^2 "
           "(abelian band) is nonzero: exact RP^2 witness (6 vertices, H^1=H^2=Z2) where the "
           "Z4->Z2 lifting defect is not a coboundary for any lift. With rigid transitions "
           "(trivial Aut) the defect is a plain local inconsistency (canary).",
           details=dict(H1_RP2=H1, H2_RP2=H2, w1_mask=w1))


# ================================================================ A09
def A09_holonomy_norm():
    rng = np.random.default_rng(seed_for(9))
    phi = float(rng.uniform(0.3, 2.8))
    H = np.array([[math.cos(phi), -math.sin(phi)], [math.sin(phi), math.cos(phi)]])
    P = np.array([[1.0, 3.0], [0.0, 1.0]])
    H2 = P @ H @ np.linalg.inv(P)
    fro = (float(np.linalg.norm(H)), float(np.linalg.norm(H2)))
    ev = (np.sort_complex(np.linalg.eigvals(H)), np.sort_complex(np.linalg.eigvals(H2)))
    M = np.linalg.inv(P).T @ np.linalg.inv(P)            # transported inner product
    w, Vv = np.linalg.eigh(M)
    Mh = Vv @ np.diag(np.sqrt(w)) @ Vv.T
    inv_norm = float(np.linalg.norm(Mh @ H2 @ np.linalg.inv(Mh), 2))
    must(abs(fro[0] - fro[1]) > 0.5, "Frobenius norm is gauge dependent")
    must(np.max(np.abs(ev[0] - ev[1])) < 1e-10 and abs(inv_norm - 1) < 1e-10, "invariants")
    record("A09", "Holonomy norms (4.06, 4.29, 4.00) certify admissible holonomy",
           "RG_-_The_Groupoid_of_Resolution.tex GR06", "SHARPENED",
           "Same holonomy in two charts: Frobenius norms %.3f vs %.3f. Invariants are the "
           "conjugacy class (spectrum) and the operator norm in the transported Sigma-metric "
           "(=1). A matrix norm is evidence only if computed in a Sigma-orthonormal frame." % fro,
           seed=seed_for(9), details=dict(phi=phi, frobenius=fro, invariant_norm=inv_norm))


# ================================================================ A10
def A10_cech_vs_naive_nerve():
    N = 360
    def arc(a, L):
        return {(a + k) % N for k in range(L)}
    U = [arc(0, 250), arc(120, 250), arc(240, 250)]
    def comps(S):
        S = set(S); out = []
        while S:
            x = S.pop(); comp = {x}; dq = [x]
            while dq:
                y = dq.pop()
                for z in ((y + 1) % N, (y - 1) % N):
                    if z in S:
                        S.remove(z); comp.add(z); dq.append(z)
            out.append(frozenset(comp))
        return out
    pairs = [(0, 1), (0, 2), (1, 2)]
    C1 = [(pr, c) for pr in pairs for c in comps(U[pr[0]] & U[pr[1]])]
    C2 = comps(U[0] & U[1] & U[2])
    c1id = {k: n for n, k in enumerate(C1)}
    d0 = []
    for v in range(3):
        m = 0
        for n, ((i, j), c) in enumerate(C1):
            if v in (i, j):
                m |= 1 << n
        d0.append(m)
    def comp_of(pr, kappa):
        return next(n for n, (pp, c) in enumerate(C1) if pp == pr and kappa <= c)
    d1_rows = []
    for kappa in C2:
        d1_rows.append(sum(1 << comp_of(pr, kappa) for pr in pairs))
    n1 = len(C1)
    def d1(mask):
        return tuple(bin(mask & r).count("1") % 2 for r in d1_rows)
    ker = sum(1 for m in range(1 << n1) if not any(d1(m)))
    H1_cech = int(math.log2(ker)) - gf2_rank(d0)
    # naive: one simplex per nonempty intersection -> filled 2-simplex
    naive_H1 = 0
    must(H1_cech == 1 and naive_H1 != H1_cech, "naive nerve wrong on non-Leray cover")
    record("A10", "Finite Z2 gluing controls on nerves represent the base",
           "conversion bundle gluing control; Atlas finite-cover tests", "BOUNDARY",
           "Circle covered by three 250-degree arcs: pairwise intersections have 2 components, "
           "triple intersection 3. Cech with locally constant Z2 (components kept): H^1=Z2 "
           "(correct). Naive nerve (one simplex per nonempty intersection) is a filled "
           "triangle: H^1=0 (wrong). A nerve model is valid only for covers with contractible "
           "intersections (nerve theorem / Leray).",
           details=dict(C1_components=n1, C2_components=len(C2), H1_cech=H1_cech))


# ================================================================ A11
def A11_reference_dependence():
    els, mul, inv, e, gens = s3()
    cyc = (1, 2, 0)
    cent = lambda g: [h for h in els if mul(g, h) == mul(h, g)]
    must(len(cent(e)) == 6 and len(cent(cyc)) == 3, "global Aut differs by reference")
    record("A11", "A 'nontrivial class' is an intrinsic property of one RG object",
           "Global_RG.md: [L] in H^1(U,G_RG)", "BOUNDARY",
           "H^1(S^1;S3) is a pointed SET of 3 elements; the base point is the chosen reference "
           "model. Global automorphism group of the form with holonomy (123) is its centralizer "
           "(order 3) vs S3 (order 6) for the trivial form. 'Trivial' is reference-relative; "
           "for non-abelian Aut there is no group structure and no intrinsic 'difference class'.",
           details=dict(aut_trivial=6, aut_twisted=3))


# ================================================================ A12
def A12_complement_dependence():
    a, c, d, k = sp.symbols("a c d k", real=True)
    Sig = sp.Matrix([[a, c], [c, d]])
    T = sp.Matrix([[1, k], [0, 1]])
    J = sp.Matrix([1, 0])
    Sp = T * Sig * T.T
    must(T * J == J, "T fixes the resolved direction")
    G = sp.simplify((J.T * Sig.inv() * J)[0]); Gp = sp.simplify((J.T * Sp.inv() * J)[0])
    must(sp.simplify(G - Gp) == 0, "G natural")
    must(sp.simplify(Sp[1, 1] - d) == 0, "D natural")
    Lp = sp.simplify(Sp[0, 1] / Sp[1, 1]); L = c / d
    must(sp.simplify(Lp - (L + k)) == 0, "L affine: L' = L + k")
    must(sp.simplify(Sp[0, 1].subs(k, -c / d)) == 0, "C' = 0 reachable by complement choice")
    record("A12", "C_RN = 0 (null block decoupled) is an intrinsic condition; (G,L,D) are natural coordinates",
           "Theorem Ladder R9; conversion bundle sec.2", "BOUNDARY",
           "Observation-coordinate change T=[[1,k],[0,1]] fixes J (resolved sector) and keeps "
           "G and D, but L -> L + k exactly. L lives in an affine space (torsor of R^{p x q}); "
           "k=-C/D makes C'=0. 'C_RN=0' is meaningful only after a DECLARED complement N; "
           "(G,L,D) is a chart, natural only under block-diagonal frame changes.",
           details=dict(L_prime=str(Lp)))


# ================================================================ A13
def A13_smooth_descent():
    qs = [((10.0 ** -k) ** (1 / 3)) / (10.0 ** -k) for k in range(1, 9, 2)]
    must(all(qs[i + 1] > qs[i] for i in range(len(qs) - 1)), "cube root not C^1 at 0")
    record("A13", "Fibre-constant smooth maps descend smoothly",
           "Ladder R2 used with smooth targets", "BOUNDARY",
           "c(x)=x^3, A(x)=x: set-level descent exists (A=cbrt o c) but difference quotients "
           "of cbrt at 0 grow without bound %s. Smooth descent holds when c is a surjective "
           "submersion (classical); fails on singular strata." % [round(x, 1) for x in qs])


# ================================================================ A14
def A14_universal_refinement():
    def canonical(vals):
        seen = {}
        return tuple(seen.setdefault(v, len(seen)) for v in vals)
    def refines(a, b):
        return all(a[i] != a[j] or b[i] == b[j] for i in range(len(a)) for j in range(len(a)))
    def partitions(n):
        for t in itertools.product(range(n), repeat=n):
            if t[0] == 0 and all(t[i] <= 1 + max(t[:i], default=-1) for i in range(n)):
                yield t
    n = 4
    P = list(partitions(n))
    cases = nat = 0
    for c in itertools.product((0, 1), repeat=n):
        for A in itertools.product((0, 1, 2), repeat=n):
            E = canonical(list(zip(c, A)))
            suff = [p for p in P if refines(p, c) and refines(p, A)]
            coarsest = [p for p in suff if all(refines(q, p) for q in suff)]
            must(coarsest == [E], "unique coarsest sufficient partition = E")
            cases += 1
            for f in itertools.product(range(n), repeat=3):
                Ep = {(c[f[i]], A[f[i]]) for i in range(3)}
                must(Ep <= set(zip(c, A)), "naturality: E(X') -> E(X) inclusion")
                nat += 1
    record("A14", "Coarsest sufficient refinement E is unique and natural",
           "RG_residual_lock_report.md sec.2", "CONFIRMED",
           f"Exhaustive on 4 points: {cases} (conversion, ternary task) pairs, all 15 partitions; "
           f"the coarsest sufficient partition exists, is unique and equals ker(c,a). "
           f"{nat} contract-preserving maps f:X'->X induce the inclusion E(X')->E(X).",
           details=dict(cases=cases, naturality_checks=nat))


# ================================================================ A15
def A15_wall_monodromy():
    sbar, eps = 0.5, 0.2
    def K(t, s):
        return sbar * np.eye(2) + eps * np.array([[t, s], [s, -t]])
    def transport(center, radius, n=2000):
        th = np.linspace(0, 2 * math.pi, n + 1)
        v0 = None; v = None; svals = []
        for x in th:
            t, s = center[0] + radius * math.cos(x), center[1] + radius * math.sin(x)
            w, V = np.linalg.eigh(K(t, s))
            svals.append(w)
            top = V[:, 1]
            if v is None:
                v0 = v = top
            else:
                v = top if top @ v > 0 else -top
        sv = np.array(svals)
        return float(v @ v0), float(np.min(sv[:, 1] - sv[:, 0]))
    around, gap1 = transport((0, 0), 1.0)
    away, gap2 = transport((3, 0), 1.0)
    w0 = np.linalg.eigvalsh(K(0, 0))
    spd_ok = all(np.linalg.eigvalsh(np.block([[np.eye(2), K(math.cos(x), math.sin(x))],
                                              [K(math.cos(x), math.sin(x)).T, np.eye(2)]])).min() > 0
                 for x in np.linspace(0, 2 * math.pi, 50))
    must(abs(around + 1) < 1e-9 and abs(away - 1) < 1e-9, "wall carries Z2 monodromy")
    must(abs(w0[0] - w0[1]) < 1e-12 and gap1 > 0.39 and spd_ok, "collision only at wall")
    record("A15", "Across walls, strata glue without residual (stratified gluing is local)",
           "Theorem Ladder R21; Groupoid Level 4", "SHARPENED (new witness)",
           "p=q=2 whitened coupling K=0.5 I + 0.2[[t,s],[s,-t]] over the (t,s)-plane: singular "
           "values 0.5+-0.2 r collide only at the wall r=0 (codim 2, von Neumann-Wigner). The top "
           "singular line bundle over any loop around the wall returns with sign -1 (Moebius), "
           "over a loop not enclosing it with +1. The regular stratum carries a global "
           "remainder FORCED by the wall; the sum of both blocks extends smoothly (Kato).",
           details=dict(around=around, away=away, min_gap_on_loop=gap1))


# ================================================================ A16
def A16_global_structure_theorem_numeric():
    s1, s2 = 0.6, 0.3
    D = np.diag([s1, s1, s2])
    def Q(t):
        c, s = math.cos(t / 2), math.sin(t / 2)
        return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
    n = 3000
    ts = np.linspace(0, 2 * math.pi, n + 1)
    Kt = [Q(t) @ D @ Q(t).T for t in ts]
    must(np.max(np.abs(Kt[0] - Kt[-1])) < 1e-12, "family periodic")
    def proj(Km, target):
        w, V = np.linalg.eigh(Km @ Km.T)
        idx = [i for i in range(3) if abs(w[i] - target ** 2) < 1e-6]
        B = V[:, idx]
        return B @ B.T, len(idx)
    out = {}
    for name, s, m in (("E_0.6", s1, 2), ("E_0.3", s2, 1)):
        P0, r0 = proj(Kt[0], s)
        F0 = np.linalg.svd(P0)[0][:, :m]
        F = F0.copy(); ranks = {r0}
        for Km in Kt[1:]:
            P, r = proj(Km, s); ranks.add(r)
            U_, _, Vt = np.linalg.svd(P @ F, full_matrices=False)
            F = U_ @ Vt                                    # polar: discrete parallel transport
        hol = F0.T @ F
        out[name] = dict(rank=sorted(ranks), det_holonomy=float(np.linalg.det(hol)))
    must(out["E_0.6"]["rank"] == [2] and out["E_0.3"]["rank"] == [1], "constant type")
    must(abs(out["E_0.6"]["det_holonomy"] + 1) < 1e-6 and abs(out["E_0.3"]["det_holonomy"] + 1) < 1e-6,
         "w1 of both singular bundles nonzero, as predicted")
    record("A16", "Global structure theorem: fixed-type RG family = tuple of Euclidean vector bundles",
           "this paper, Theorem 6.2", "CONFIRMED (numerical witness of a proved theorem)",
           "Family K(t)=Q(t/2) diag(0.6,0.6,0.3) Q(t/2)^T over S^1, Q = rotation about e1: type "
           "constant; transported frames give det(hol) = -1 for the rank-2 block and -1 for the "
           "rank-1 block, i.e. (w1(E_1),w1(E_2))=(1,1) as predicted from Q(pi)=diag(1,-1,-1). "
           "The global remainder is the pair of vector-bundle classes, nothing else.",
           details=out)


# ================================================================ A17
def A17_component_count_over_circle():
    """Corollary: |Forms_tau(S^1)| = |pi_0(Aut_tau)| = 2^k(tau), k = number of positive-rank
    blocks.  Lower bound witnessed exactly by block reflections realising every determinant
    character; upper bound is the structure theorem (Aut ~= prod O(m_i) x O(p-r) x O(q-r))."""
    q = sp.Rational
    strata = {"C=0": [0, 0, 0], "rank1": [q(1, 2), 0, 0], "rank2_distinct": [q(1, 2), q(1, 4), 0],
              "rank3_distinct": [q(1, 2), q(1, 4), q(1, 8)], "rank2_equal": [q(1, 2), q(1, 2), 0],
              "rank3_C=I/2": [q(1, 2)] * 3, "rank3_pair_equal": [q(1, 2), q(1, 2), q(1, 4)]}
    out = {}
    for name, sv in strata.items():
        C = sp.diag(*sv)
        groups = {}
        for i, s in enumerate(sv):
            if s != 0:
                groups.setdefault(s, []).append(i)
        blocks = [("S", idx) for idx in groups.values()]
        ker = [i for i, s in enumerate(sv) if s == 0]
        if ker:
            blocks += [("KR", ker), ("KN", ker)]
        k = len(blocks)
        chars = set()
        for b, (kind, idx) in enumerate(blocks):
            a = [1, 1, 1]; bb = [1, 1, 1]
            if kind in ("S", "KR"):
                a[idx[0]] = -1
            if kind in ("S", "KN"):
                bb[idx[0]] = -1
            A, B = sp.diag(*a), sp.diag(*bb)
            must(A * C * B.T == C, f"reflection in Aut for {name}")
            pattern = []
            for kind2, idx2 in blocks:
                M = A if kind2 in ("S", "KR") else B
                pattern.append(1 if math.prod(int(M[i, i]) for i in idx2) < 0 else 0)
            chars.add(tuple(pattern))
        must(len(chars) == k and all(sum(c) == 1 for c in chars), "characters independent")
        out[name] = dict(k=k, forms_over_circle=2 ** k)
    must(out["rank3_C=I/2"]["forms_over_circle"] < out["rank1"]["forms_over_circle"]
         < out["rank2_distinct"]["forms_over_circle"], "non-monotone in rank")
    record("A17", "Global remainder over S^1 is controlled by coupling rank",
           "derived corollary of A05/A07 (no corpus claim)", "SHARPENED",
           "|Forms_tau(S^1)| = 2^k(tau): C=0:4, rank1:8, rank2 distinct:16, rank3 distinct:8, "
           "rank2 equal:8, rank3 with one pair equal:4, C=I/2:2. Block reflections realise every "
           "determinant character exactly. Not monotone in rank: multiplicities, not rank, "
           "control the global remainder.", details=out)


# ================================================================ A18
def A18_global_fisher_blindness():
    """Corollary 6.7: (R, Sigma_R, G) determines sigma, E_j^R, K_R but not the class of K_N.
    p=1, q=2, sigma=1/2. Family 1: N = span(e1, e2) (trivial).  Family 2: N_t = span(e1, u(t)),
    u(t) = (0, cos t/2, sin t/2) (K_N Moebius).  Frames (e1, k) orthonormal, C = [sigma, 0]."""
    sig = 0.5
    def fisher(SR, C, SN):
        return 1.0 / (SR - (C @ np.linalg.inv(SN) @ C.T)[0, 0])
    ts = np.linspace(0, 2 * math.pi, 401)
    G1 = [fisher(1.0, np.array([[sig, 0.0]]), np.eye(2)) for _ in ts]
    G2 = [fisher(1.0, np.array([[sig, 0.0]]), np.eye(2)) for _ in ts]
    u = lambda t: np.array([0.0, math.cos(t / 2), math.sin(t / 2)])
    hol_triv = 1.0
    hol_mob = float(u(ts[-1]) @ u(ts[0]))
    # well-definedness of family 2: C and Sigma_N do not depend on the sign of the K_N frame
    flipC = np.array([[sig, 0.0]]) @ np.diag([1, -1])
    must(np.allclose(flipC, [[sig, 0.0]]) and max(abs(a - b) for a, b in zip(G1, G2)) == 0,
         "identical Fisher data")
    must(hol_triv == 1 and abs(hol_mob + 1) < 1e-12, "different K_N classes")
    record("A18", "Fisher blindness is a local (frame-fibre) phenomenon only",
           "Ladder R9 (Fisher insufficiency), extended globally", "SHARPENED",
           "Two RG families over S^1 with identical (R, Sigma_R, G) at every point "
           "(G=1/(1-sigma^2)=%.4f) whose null-kernel bundles K_N are trivial resp. Moebius: "
           "non-isomorphic. Modulo gauge, the Fisher-relative remainder is exactly the class of "
           "K_N in Vect_{q-r}(S) (Cor. 6.7)." % G1[0], details=dict(G=G1[0], hol_KN=[hol_triv, hol_mob]))


# ================================================================ main
SPEC = [
    ("A01", "no faithful functor", "REFUTED"), ("A02", "nonzero descent class intrinsic", "REFUTED"),
    ("A03", "local invariants complete", "SHARPENED"), ("A04", "global data exhaust remainder", "REFUTED"),
    ("A05", "rank controls dim Aut / rigidity", "REFUTED"), ("A06", "dim 0 => rigid", "REFUTED"),
    ("A07", "principal bundle across strata", "BOUNDARY"), ("A08", "Cech defect = failure", "SHARPENED"),
    ("A09", "holonomy norms invariant", "SHARPENED"), ("A10", "naive nerve valid", "BOUNDARY"),
    ("A11", "class intrinsic", "BOUNDARY"), ("A12", "C_RN=0 intrinsic", "BOUNDARY"),
    ("A13", "smooth descent", "BOUNDARY"), ("A14", "E unique & natural", "CONFIRMED"),
    ("A15", "walls glue without residual", "SHARPENED"), ("A16", "global structure theorem", "CONFIRMED"),
    ("A17", "rank controls global remainder", "SHARPENED"),
    ("A18", "Fisher blindness only local", "SHARPENED"),
]


def canaries():
    """Deliberately false statements; each must be rejected by the same machinery."""
    res = []
    G = z2n(1)
    res.append(("circle Z2 has 1 class", orbit_count(G, 3, [(0, 1), (1, 2), (0, 2)])[0] == 1))
    res.append(("C=I/2 has dim Aut 0", aut_dim_exact(sp.eye(3), sp.eye(3), sp.eye(3) / 2) == 0))
    res.append(("rank-3 distinct Aut trivial",
                sp.diag(-1, -1, -1) * sp.diag(sp.Rational(1, 2), sp.Rational(1, 4), sp.Rational(1, 8))
                * sp.diag(-1, -1, -1) != sp.diag(sp.Rational(1, 2), sp.Rational(1, 4), sp.Rational(1, 8))))
    a_, c_, d_, k_ = sp.symbols("a c d k", positive=True)
    Sp_ = sp.Matrix([[1, k_], [0, 1]]) * sp.Matrix([[a_, c_], [c_, d_]]) * sp.Matrix([[1, 0], [k_, 1]])
    res.append(("L is natural under T", sp.simplify(Sp_[0, 1] / Sp_[1, 1] - c_ / d_) == 0))
    caught = [dict(statement=s, accepted=bool(v), caught=not v) for s, v in res]
    must(all(c["caught"] for c in caught), "a canary was accepted")
    return caught


def main(out):
    out = pathlib.Path(out); out.mkdir(parents=True, exist_ok=True)
    src = pathlib.Path(__file__).read_bytes()
    manifest = dict(master_seed=MASTER_SEED, spec=SPEC, blind=False,
                    data="constructed mathematical fixtures only",
                    source_sha256=hashlib.sha256(src).hexdigest(),
                    written_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
    mtxt = json.dumps(manifest, indent=2, sort_keys=True)
    (out / "rg_final_manifest.json").write_text(mtxt)
    mhash = hashlib.sha256(mtxt.encode()).hexdigest()
    t0 = time.time()
    for fn in (A01_faithful_functor, A02_contractible_and_classification, A03_mobius_rg_family,
               A04_point_base_local_residual, A05_rigidity, A06_dimension_zero_not_rigid_globally,
               A07_isotropy_jump, A08_cocycle_defect, A09_holonomy_norm, A10_cech_vs_naive_nerve,
               A11_reference_dependence, A12_complement_dependence, A13_smooth_descent,
               A14_universal_refinement, A15_wall_monodromy, A16_global_structure_theorem_numeric,
               A17_component_count_over_circle, A18_global_fisher_blindness):
        fn()
    can = canaries()
    for (aid, _, exp), r in zip(SPEC, RESULTS):
        must(r["id"] == aid and exp in r["status"], f"status drift {aid}")
    res = dict(manifest_sha256=mhash, python=sys.version.split()[0], numpy=np.__version__,
               sympy=sp.__version__, platform=platform.platform(), runtime_s=round(time.time() - t0, 2),
               attacks=RESULTS, canaries=can,
               summary=dict(n_attacks=len(RESULTS),
                            by_status={s: sum(r["status"].split()[0] == s for r in RESULTS)
                                       for s in ("REFUTED", "SHARPENED", "CONFIRMED", "BOUNDARY")},
                            canaries_caught=sum(c["caught"] for c in can)),
               verdict=("Final RG remainder on strata of constant multiplicity type = local moduli "
                        "(canonical-correlation functions) + descent data = tuple of "
                        "Euclidean vector bundles (classified by prod BO(m_i)); no primitive "
                        "required. Across walls: forced wall monodromy witnessed; general "
                        "stratified classification OPEN."))
    (out / "rg_final_results.json").write_text(json.dumps(res, indent=2, default=str))
    print(json.dumps(res["summary"], indent=2))
    print(res["verdict"])


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default=".")
    main(ap.parse_args().out)
