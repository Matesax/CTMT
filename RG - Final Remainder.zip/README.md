# RG final remainder bundle
- RG_Final_Remainder_Lock.tex / .pdf  - theorem paper (Global Structure Theorem, universality, gerbe level, walls, ledger, corrections)
- RG_-_Theorem_Ladder_v2.tex / .pdf   - working ladder with Stratum 7 (R30-R44) and corrected R9, R21
- rg_final_remainder_attacks.py       - hostile battery (18 attacks, 4 canaries)
- rg_final_manifest.json              - pre-evaluation manifest (spec, seed, source hash)
- rg_final_results.json               - witnesses, statuses, versions
- RG_final_remainder_report.md        - summary of verdict and attacks
