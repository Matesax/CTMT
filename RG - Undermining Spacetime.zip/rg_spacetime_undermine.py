"""RG spacetime undermine-and-repair dispatch (weak-field GR observables, linear declared model).
Applies the undermine-and-repair lock controller (same semantics as rg_lock_automation.py) to GR spacetime
claims.  Parameters x = (gamma, beta, c_star, c_bh, tau, g_coord, w, r, s); observations y = c0 + a.x +- eps.
The controller never sees truth; a synthetic acquisition harness does.  Linearized, synthetic, declared.
Run: python rg_spacetime_undermine.py --out DIR    (numpy, scipy)
"""
import argparse, hashlib, json, math, pathlib, sys, time
import numpy as np
from scipy.optimize import linprog
from scipy.linalg import null_space

SEED = 20261028
NAMES = ["gamma", "beta", "c_star", "c_bh", "tau", "g_coord", "w", "r", "s"]
IDX = {n: i for i, n in enumerate(NAMES)}
TRUTH = np.array([1.0, 1.0, 0.3, -0.4, 0.2, 0.7, 0.5, 0.25, 0.25])      # GR: gamma = beta = 1; r = kappa*s, kappa = 1
DELTA = 1e-3                                                            # task half-width tolerance
BOX = [(-2.0, 2.0)] * len(NAMES)


def row(coeffs, c0, eps, label, kind="probe"):
    a = np.zeros(len(NAMES))
    for k, v in coeffs.items():
        a[IDX[k]] = v
    return dict(a=a, c0=c0, eps=eps, label=label, kind=kind)


# ---------------------------------------------------------------- protocol catalogue (declared, weak field)
SLOW1 = row({"gamma": 1}, 1e4, 5.0, "slow-probe deflection v/c=0.01 (alpha*b/2m = 1/v^2 + gamma), rel. err 5e-4")
SLOW2 = row({"gamma": 1}, 1111.1, 0.33, "slow-probe deflection v/c=0.03, rel. err 3e-4")
REDSHIFT = row({}, 1.0, 1e-4, "clock redshift (energy channel; independent of gamma)")
LIGHT = row({"gamma": 1}, 1.0, 1e-3, "light deflection (1+gamma)/2 scale")
SHAPIRO = row({"gamma": 1}, 1.0, 2e-5, "Shapiro delay (1+gamma) scale (Cassini-class)")
PERI = row({"gamma": 2 / 3, "beta": -1 / 3}, 2 / 3, 1e-4, "perihelion (2+2gamma-beta)/3 scale")
HELIO = row({"c_star": 1}, 0.0, 1e-4, "helioseismic interior probe (star only)")
CIRCLES = row({"tau": 1}, 0.0, 1e-4, "matched circles / global light paths (topology)")
TIDAL = row({"w": 1, "r": 1}, 0.0, 1e-4, "gradiometer tidal tensor (Weyl-electric + Ricci part)")
SOURCE = row({"s": 1}, 0.0, 1e-4, "local source measurement (stress/density)")
FIELD_EQ = row({"r": 1, "s": -1}, 0.0, 1e-12, "DECLARED field equation r = kappa s (kappa = 1)", kind="declaration")
LOCAL_EXT = [SLOW1, SLOW2, REDSHIFT, LIGHT, SHAPIRO, PERI, TIDAL, SOURCE]


def endpoints(A, d, eps, h, box):
    Aub = np.vstack([A, -A]); bub = np.r_[d + eps, -d + eps]
    lo = linprog(h, A_ub=Aub, b_ub=bub, bounds=box, method="highs")
    hi = linprog(-h, A_ub=Aub, b_ub=bub, bounds=box, method="highs")
    if lo.status == 2 or hi.status == 2:
        return dict(status="INCONSISTENT")
    if not (lo.success and hi.success):
        return dict(status="NUMERIC_UNRESOLVED")
    return dict(status="FEASIBLE", lower=float(h @ lo.x), upper=float(h @ hi.x), x_lower=lo.x, x_upper=hi.x)


def pool_obstruction(A, d, eps, h, pool, box):
    K = np.vstack([A] + ([pool] if len(pool) else []))
    Z = null_space(K, rcond=1e-12)
    if not Z.shape[1] or np.linalg.norm(h @ Z) < 1e-9:
        return None
    Aub = np.vstack([A, -A]); bub = np.r_[d + eps, -d + eps]; zero = np.zeros_like(Aub)
    sol = linprog(np.r_[h, -h], A_ub=np.block([[Aub, zero], [zero, Aub]]), b_ub=np.r_[bub, bub],
                  A_eq=np.hstack([K, -K]), b_eq=np.zeros(len(K)), bounds=box + box, method="highs")
    if not sol.success:
        return None
    n = len(h); a, b = sol.x[:n], sol.x[n:]; gap = float(h @ (b - a))
    return None if gap <= 2 * DELTA else dict(task_gap=gap, x_a=a.tolist(), x_b=b.tolist())


def run_case(name, claim, task, calibration, pool, box=BOX, budget=6, rng=None, note=""):
    h = np.zeros(len(NAMES)); h[IDX[task]] = 1.0
    rows = list(calibration); used = []; history = []
    def measure(rw):
        return float(rw["c0"] + rw["a"] @ TRUTH + rng.uniform(-rw["eps"], rw["eps"]))
    vals = [measure(rw) if rw["kind"] == "probe" else rw["c0"] for rw in rows]
    first = None
    for _ in range(budget + 2):
        A = np.array([rw["a"] for rw in rows]); d = np.array(vals) - np.array([rw["c0"] for rw in rows])
        eps = np.array([rw["eps"] for rw in rows])
        e = endpoints(A, d, eps, h, box)
        if first is None:
            first = e
        if e["status"] != "FEASIBLE":
            history.append(dict(action=e["status"], n_obs=len(rows))); break
        width = e["upper"] - e["lower"]
        if width / 2 <= DELTA:
            history.append(dict(action="LOCK", value=(e["upper"] + e["lower"]) / 2, radius=width / 2, n_obs=len(rows))); break
        avail_idx = [i for i in range(len(pool)) if i not in used]; avail = [pool[i] for i in avail_idx]
        P = np.array([p["a"] for p in avail]) if avail else np.zeros((0, len(NAMES)))
        obs = pool_obstruction(A, d, eps, h, P, box)
        if obs is not None:
            history.append(dict(action="AMBIGUOUS_POOL_FIBRE", interval=[e["lower"], e["upper"]], witness_gap=obs["task_gap"],
                                n_obs=len(rows))); break
        wit = e["x_upper"] - e["x_lower"]
        scores = [abs(p["a"] @ wit) / p["eps"] for p in avail]
        if not avail or max(scores) <= 1e-9:
            history.append(dict(action="AMBIGUOUS_NO_SEPARATING_PROBE", interval=[e["lower"], e["upper"]])); break
        if len(used) >= budget:
            history.append(dict(action="AMBIGUOUS_BUDGET", interval=[e["lower"], e["upper"]])); break
        k = int(np.argmax(scores)); pick = avail[k]; used.append(avail_idx[k])
        rows.append(pick); vals.append(measure(pick))
        history.append(dict(action="ACQUIRE", probe=pick["label"], interval=[e["lower"], e["upper"]]))
    final = history[-1]
    truth_task = float(TRUTH[IDX[task]])
    out = dict(case=name, claim=claim, task=task, note=note, final=final["action"],
               acquired=[hh["probe"] for hh in history if hh["action"] == "ACQUIRE"],
               initial_interval=[first["lower"], first["upper"]] if first and first["status"] == "FEASIBLE" else None,
               history=history)
    if final["action"] == "LOCK":
        out.update(value=final["value"], radius=final["radius"], covers_truth=abs(final["value"] - truth_task) <= final["radius"] + 1e-9)
    return out


def main(outdir):
    out = pathlib.Path(outdir); out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(SEED)
    t0 = time.time()
    nord_box = list(BOX); nord_box[IDX["gamma"]] = (-1.0, -0.98)                 # Nordstrom class: gamma ~ -1
    cases = [
        run_case("G1", "Spatial structure (gamma) is fixed by the box: slow probes, clocks, tidal data", "gamma",
                 [SLOW1, REDSHIFT], [SLOW2, LIGHT, SHAPIRO, PERI], rng=rng,
                 note="box-type calibration leaves gamma broad; repair acquires a light-based probe"),
        run_case("G2", "The nonlinearity of gravity (beta) follows from the metric data", "beta",
                 [SLOW1, REDSHIFT], [LIGHT, SHAPIRO, PERI], rng=rng),
        run_case("G3a", "Exterior observation fixes a star's interior", "c_star", LOCAL_EXT, [LIGHT, SHAPIRO, PERI], rng=rng,
                 note="Birkhoff: no exterior probe touches the interior"),
        run_case("G3b", "...repaired by an interior protocol", "c_star", LOCAL_EXT, [HELIO], rng=rng),
        run_case("G4", "Exterior observation fixes a black-hole interior", "c_bh", LOCAL_EXT,
                 [LIGHT, SHAPIRO, PERI, HELIO, CIRCLES], rng=rng, note="no admissible probe crosses the horizon"),
        run_case("G5a", "Local observation fixes global topology", "tau", LOCAL_EXT, [LIGHT, SHAPIRO, PERI], rng=rng),
        run_case("G5b", "...repaired by global light paths (if within the horizon)", "tau", LOCAL_EXT, [CIRCLES], rng=rng),
        run_case("G6", "Slow-probe data cannot reject a rival theory (Nordstrom class, gamma ~ -1)", "gamma",
                 [SLOW1, REDSHIFT], [LIGHT, SHAPIRO], box=nord_box, rng=rng,
                 note="model box restricted to the Nordstrom class; truth generated with gamma = 1"),
        run_case("G7", "A metric component at a coordinate point is observable", "g_coord", LOCAL_EXT,
                 [LIGHT, SHAPIRO, PERI, HELIO, CIRCLES], rng=rng, note="diffeomorphism gauge: no observable touches it"),
        run_case("G8a", "Tidal data fix the Weyl curvature", "w", [TIDAL, SOURCE], [LIGHT, SHAPIRO, PERI], rng=rng,
                 note="tidal = Weyl + Ricci; Ricci needs a field equation"),
        run_case("G8b", "...repaired by DECLARING the field equation", "w", [TIDAL, SOURCE, FIELD_EQ], [], rng=rng),
    ]
    expect = {"G1": "LOCK", "G2": "LOCK", "G3a": "AMBIGUOUS_POOL_FIBRE", "G3b": "LOCK", "G4": "AMBIGUOUS_POOL_FIBRE",
              "G5a": "AMBIGUOUS_POOL_FIBRE", "G5b": "LOCK", "G6": "INCONSISTENT", "G7": "AMBIGUOUS_POOL_FIBRE",
              "G8a": "AMBIGUOUS_POOL_FIBRE", "G8b": "LOCK"}
    checks = {c["case"]: (c["final"] == expect[c["case"]]) for c in cases}
    checks.update({f"{c['case']} lock covers truth": c["covers_truth"] for c in cases if c["final"] == "LOCK"})
    g1 = next(c for c in cases if c["case"] == "G1")
    checks["G1 initially broad (box blind to structure)"] = g1["initial_interval"][1] - g1["initial_interval"][0] > 1.0
    g6 = next(c for c in cases if c["case"] == "G6")
    checks["G6 slow probes alone do not reject Nordstrom"] = g6["initial_interval"] is not None
    # canary: an untouched parameter must never lock, whatever probes are added
    canary = run_case("C1", "canary: gauge locks if every probe is acquired", "g_coord", LOCAL_EXT + [LIGHT, SHAPIRO, PERI, HELIO, CIRCLES],
                      [], rng=rng)
    checks["canary rejected: gauge never locks"] = canary["final"] != "LOCK"
    if not all(checks.values()):
        raise AssertionError([k for k, v in checks.items() if not v])
    res = dict(seed=SEED, delta=DELTA, truth=dict(zip(NAMES, TRUTH.tolist())), cases=cases, checks=checks,
               python=sys.version.split()[0], numpy=np.__version__, runtime_s=round(time.time() - t0, 2),
               source_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
               scope="linearized weak-field declared model; synthetic acquisitions; not an empirical analysis")
    (out / "rg_spacetime_undermine_results.json").write_text(json.dumps(res, indent=1, default=lambda o: o.tolist()))
    for c in cases:
        print(c["case"], c["final"], c["acquired"], [round(v, 4) for v in (c["initial_interval"] or [])],
              round(c.get("value", float("nan")), 5), c.get("radius"))
    print(json.dumps(checks))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default="."); main(ap.parse_args().out)
