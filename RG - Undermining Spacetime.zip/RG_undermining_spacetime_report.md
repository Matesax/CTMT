# RG: Undermining Spacetime — report

**Thesis.** Spacetime is not refuted. It is demoted, from observed object to a representative selected from an
observational fibre by declarations.

**Method.**
- **Undermine:** a witness pair in one fibre that disagrees on a spacetime claim.
- **Repair:** a new protocol that intersects the fibre.
- **Lock:** the fibre width is within tolerance.

The machinery is imported from two batteries, with their retained failures:
- selection, 562/569;
- lock automation, 892/892 (v1 scored 870/892).

**Dispatch** (weak-field declared model; controller never sees the truth; δ = 1e-3):

| Case | Claim | Result |
|---|---|---|
| G1 | the box fixes spatial structure γ | starts at [−2, 1.16]; one Shapiro probe gives LOCK 1.00001 ± 2e-5 |
| G2 | β from the metric data | perihelion + Shapiro give LOCK 1.0003 ± 3.4e-4 |
| G3a/b | star interior | POOL FIBRE; helioseismology gives LOCK |
| G4 | black-hole interior | POOL FIBRE, permanent |
| G5a/b | global topology | POOL FIBRE; matched circles give LOCK |
| G6 | slow probes reject Nordström | consistent until Shapiro, then INCONSISTENT |
| G7 | metric value at a coordinate point | POOL FIBRE, permanent (gauge) |
| G8a/b | tidal data fix Weyl | POOL FIBRE; declaring the field equation gives LOCK |

**Ledger.**
- **Locked (observable spacetime):** light cones, lapse N, spatial structure h, β, and Weyl-electric curvature
  (given the field equation).
- **Repairable:** a star's interior, and topology within the horizon.
- **Permanent declarations:** gauge values, black-hole interiors, topology beyond the horizon, units.

**Blocked, and stated as such.**
- A physical RG update law.
- "GR built from attractors".
- Strong-field, stationary and dynamical spacetimes.

**Battery.**
- 11 cases, 19 computed checks, 1 canary (the gauge never locks). Seed 20261028.
- Reruns are identical.
- `imported/` holds both uploaded batteries, unchanged.
