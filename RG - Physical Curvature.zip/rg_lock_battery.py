#!/usr/bin/env python3
"""Synthetic RG tests. Separate-process freeze, not external preregistration.
Run: python rg_lock_battery.py. Requires compatible baseline in same folder.
"""
import sys,json,hashlib,subprocess,importlib.util
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp,quad
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('base',ROOT/'rg_physical_curvature_compatible.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
J=np.array([[-1.,1,0],[0,-1,1]])
def B(M,J): return np.linalg.solve(J@M@J.T,J@M).T
def digest(x): return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def dump(n,x): (ROOT/n).write_text(json.dumps(x,indent=2,allow_nan=False,default=lambda o:o.item()))
def load(n): return json.loads((ROOT/n).read_text())
def filehash(n): return hashlib.sha256((ROOT/n).read_bytes()).hexdigest()
def shape(case,u):
 l1,l2,d1,d2,phi,T=case
 return np.array([l1+d1*np.cos(2*np.pi*u),l2+d2*np.cos(2*np.pi*u-phi)]),np.array([-d1*2*np.pi*np.sin(2*np.pi*u),-d2*2*np.pi*np.sin(2*np.pi*u-phi)])
def matrix(q,a,scale): return scale*b.mobility(np.array([0,q[0],sum(q)]),a)
def prediction(c,case):
 def fun(u):
  q,v=shape(case,u);return float(np.mean(B(matrix(q,c['a'],c['scale']),J)@v))
 return quad(fun,0,1,epsabs=1e-12)[0]
def path_length(c,case):
 def speed(u):
  q,v=shape(case,u);M=matrix(q,c['a'],c['scale']);return float(np.sqrt(v@np.linalg.solve(J@M@J.T,v)))
 return quad(speed,0,1,epsabs=1e-11)[0]
def load_integral(c,case):
 def fun(u):
  q,_=shape(case,u);M=matrix(q,c['a'],c['scale']);return case[-1]/float(np.ones(3)@np.linalg.solve(M,np.ones(3)))
 return quad(fun,0,1,epsabs=1e-12)[0]
def oracle(case,a=.055,scale=.8,force=0.,rtol=2e-11,warp=False):
 T=case[-1];q,_=shape(case,0);x0=np.array([0,q[0],sum(q)])
 def rhs(t,x):
  u=t/T;rate=1/T
  if warp: rate=(1+.12*np.cos(2*np.pi*u))/T;u=u+.12*np.sin(2*np.pi*u)/(2*np.pi)
  _,v=shape(case,u);M=scale*b.mobility(x,a)
  A=np.vstack([M[1]-M[0],M[2]-M[1],np.ones(3)])
  return M@np.linalg.solve(A,np.r_[v*rate,force])
 sol=solve_ivp(rhs,(0,T),x0,rtol=rtol,atol=rtol/100);assert sol.success
 return float(np.mean(sol.y[:,-1]-x0))
def calibrate():
 rng=np.random.default_rng(104729);est=[];sc=[];shapes=[(.85,.9),(.85,1.15),(1.,1.),(1.15,.9),(1.15,1.15)];n=120000
 for q in shapes:
  x=np.array([0,q[0],sum(q)]);M=matrix(q,.055,.8)
  z=rng.normal(size=(n,3))@np.linalg.cholesky(M).T;C=z.T@z/n;sc.extend(np.diag(C).tolist())
  for i,j in [(0,1),(0,2),(1,2)]:est.append(float(C[i,j]*abs(x[i]-x[j])/1.5))
 scale=float(np.mean(sc));c=dict(a=float(np.mean(est)/scale),scale=scale,calibration_seed=104729,n_per_shape=n,shapes=shapes,heldout_seed=130363,n_heldout=24,gates=dict(relative_displacement=.08,absolute_displacement=2e-7,relative_time=.04),scope='synthetic parametric Oseen calibration; covariance prefactor anchored; no active loop calibration')
 dump('rg_frozen_calibration.json',c)
 dump('rg_freeze_manifest.json',dict(calibration_sha256=digest(c),runner_sha256=filehash('rg_lock_battery.py'),baseline_sha256=filehash('rg_physical_curvature_compatible.py')))
def predict():
 c=load('rg_frozen_calibration.json');rng=np.random.default_rng(c['heldout_seed']);rows=[]
 for _ in range(c['n_heldout']):
  case=[float(rng.uniform(.9,1.1)),float(rng.uniform(.9,1.1)),float(rng.uniform(.025,.08)),float(rng.uniform(.025,.08)),float(rng.choice([-1,1])*rng.uniform(.5,2.6)),float(rng.uniform(.4,2.5))]
  p=prediction(c,case);K=load_integral(c,case)
  rows.append(dict(case=case,prediction=p,time_at_unit_power=path_length(c,case),loaded_prediction=p+.003*K,stall_force_prediction=-p/K))
 dump('rg_frozen_predictions.json',rows);f=load('rg_freeze_manifest.json');f['predictions_sha256']=digest(rows);dump('rg_freeze_manifest.json',f)
R=[]
def check(id,ok,ev):
 R.append(dict(id=id,passed=bool(ok),evidence=ev));print(('PASS ' if ok else 'FAIL ')+id,flush=True)
def score():
 c=load('rg_frozen_calibration.json');f=load('rg_freeze_manifest.json');rows=load('rg_frozen_predictions.json')
 check('EX01-freeze-integrity',digest(c)==f['calibration_sha256'] and digest(rows)==f['predictions_sha256'] and filehash('rg_lock_battery.py')==f['runner_sha256'] and filehash('rg_physical_curvature_compatible.py')==f['baseline_sha256'],f)
 held=[]
 for row in rows:
  obs=oracle(row['case']);p=row['prediction'];tol=c['gates']['absolute_displacement']+c['gates']['relative_displacement']*abs(obs)
  held.append(dict(**row,oracle=obs,tolerance=tol,relative_error=abs(p-obs)/abs(obs),passed=abs(p-obs)<=tol))
 check('EX02-passive-to-active-heldout',all(x['passed'] for x in held),dict(n=len(held),max_relative_error=max(x['relative_error'] for x in held),rows=held))
 rng=np.random.default_rng(15485863);te=[];se=[]
 for _ in range(40):
  A=rng.normal(size=(4,4));M=A@A.T+np.eye(4);JJ=rng.normal(size=(2,4));dq=rng.normal(size=2);power=float(rng.uniform(.2,2))
  G=np.linalg.inv(JJ@M@JJ.T);ell=float(np.sqrt(dq@G@dq));T=ell/np.sqrt(power)
  lam=np.linalg.solve(JJ@M@JJ.T,dq/T);v=M@JJ.T@lam;E=T*float((JJ.T@lam)@v)
  te.extend([abs(E-power*T),abs(E-ell**2/T)]);se.append(float(np.max(abs(B(7*M,JJ)-B(M,JJ)))))
 check('EX03-time-power-energy',max(te)<1e-10,dict(n=40,max_balance_error=max(te),law='T_min=ell/sqrt(power); E_min=ell^2/T; fixed path'))
 check('EX04-clock-scale-nonidentifiability',max(se)<1e-12,dict(max_B_change=max(se),P_multiplier=7,time_multiplier_at_fixed_power=1/np.sqrt(7)))
 time_rows=[]
 for row in rows:
  exact=path_length(dict(a=.055,scale=.8),row['case']);time_rows.append(dict(predicted=row['time_at_unit_power'],oracle=exact,relative_error=abs(row['time_at_unit_power']/exact-1)))
 check('EX14-frozen-time-holdout',max(x['relative_error'] for x in time_rows)<c['gates']['relative_time'],dict(n=len(time_rows),max_relative_error=max(x['relative_error'] for x in time_rows),rows=time_rows))
 load_rows=[]
 for row in rows:
  actual=oracle(row['case'],force=.003);stalled=oracle(row['case'],force=row['stall_force_prediction']);tol=2e-7+.08*abs(row['prediction'])
  load_rows.append(dict(predicted=row['loaded_prediction'],oracle=actual,stall_force=row['stall_force_prediction'],stall_residual=stalled,tolerance=tol,passed=abs(actual-row['loaded_prediction'])<tol and abs(stalled)<tol))
 check('EX15-frozen-load-stall-holdout',all(x['passed'] for x in load_rows),dict(n=len(load_rows),max_stall_residual=max(abs(x['stall_residual']) for x in load_rows),rows=load_rows))
 case=rows[0]['case']
 def speed(u,cal):
  q,v=shape(case,u);M=matrix(q,cal['a'],cal['scale']);return float(np.sqrt(v@np.linalg.solve(J@M@J.T,v)))
 ell=quad(lambda u:speed(u,c),0,1,epsabs=1e-11)[0];true=dict(a=.055,scale=.8);ell0=quad(lambda u:speed(u,true),0,1,epsabs=1e-11)[0]
 check('EX05-calibrated-loop-time',abs(ell/ell0-1)<c['gates']['relative_time'],dict(predicted_time_at_unit_power=ell,oracle_time_at_unit_power=ell0,relative_error=abs(ell/ell0-1),units='nondimensional model units, not SI seconds'))
 E=quad(lambda u:speed(u,true)**2,0,1,epsabs=1e-11)[0]
 # Independent clock integration from constraint forces and dissipated power.
 def clock_rhs(t,y):
  u=float(y[0]);q,vq=shape(rows[0]['case'],u);M=matrix(q,.055,.8)
  lam=np.linalg.solve(J@M@J.T,vq);force=J.T@lam;vel=M@force
  power=float(force@vel)
  return [1/np.sqrt(power)]
 def finish(t,y):return y[0]-1
 finish.terminal=True;finish.direction=1
 clock=solve_ivp(clock_rhs,(0,2*ell0),[0.],events=finish,rtol=1e-10,atol=1e-12,max_step=ell0/100)
 clocktime=float(clock.t_events[0][0])
 check('EX18-power-controlled-clock-ODE',abs(clocktime-ell0)<1e-8,dict(force_power_ODE_time=clocktime,metric_integral_time=ell0,error=abs(clocktime-ell0)))
 check('EX06-optimal-scheduling',E>=ell0**2*(1-1e-10),dict(uniform_parameter_energy=E,constant_metric_speed_energy=ell0**2,ratio=E/ell0**2))
 case=rows[1]['case'];ref=oracle(case);slow=case.copy();slow[-1]*=3;sv=oracle(slow);wv=oracle(case,warp=True);scaled=oracle(case,scale=5.6)
 check('EX07-rate-and-scalar-invariance',max(abs(sv-ref),abs(wv-ref),abs(scaled-ref))<1e-9,dict(reference=ref,three_times_duration=sv,nonuniform_schedule=wv,seven_times_mobility=scaled))
 def loadmob(t):
  q,_=shape(case,t/case[-1]);M=matrix(q,.055,.8);return 1/float(np.ones(3)@np.linalg.solve(M,np.ones(3)))
 K=quad(loadmob,0,case[-1],epsabs=1e-12)[0];F=.003;loaded=oracle(case,force=F);stall=-ref/K;stalled=oracle(case,force=stall)
 check('EX08-load-and-stall',abs(loaded-(ref+F*K))<1e-9 and abs(stalled)<1e-9,dict(no_load=ref,loaded=loaded,predicted_loaded=ref+F*K,stall_force=stall,stall_displacement=stalled,note='exact model parameters; stall uses scored no-load response, not a frozen blind prediction'))
 me=[];ze=[]
 for _ in range(30):
  xi=np.array([rng.uniform(-2,2),rng.uniform(.7,2.3),rng.uniform(.7,2.3)]);sd=rng.normal(size=2);L=float(rng.uniform(.02,.2));M=b.chain_metric(xi)
  theta=-M[0,1:]@sd/M[0,0]+L/M[0,0];pts=b.chain_points(xi);jac=b.chain_jac(xi);v=np.einsum('pik,k->pi',jac,np.r_[theta,sd]);actual=float(np.sum(pts[:,0]*v[:,1]-pts[:,1]*v[:,0]))
  me.append(abs(actual-L));ze.append(abs(theta-b.theta_dot_angmom(xi,sd)))
 check('EX09-nonzero-momentum',max(me)<1e-7 and min(ze)>1e-3,dict(max_cartesian_momentum_error=max(me),min_omitted_drift_rate=min(ze)))
 side=.15;shift=.8;sq=[(1,0,side),(0,1,side),(-1,0,side),(0,-1,side)];inv=[(0,1,side),(1,0,side),(0,-1,side),(-1,0,side)];state=np.zeros(3)
 for du,dv,T in sq+[(1,0,shift)]+inv+[(-1,0,shift)]:
  sol=solve_ivp(lambda t,y:b.ex_rhs(t,y,du,dv),(0,T),state,rtol=1e-12,atol=1e-14);assert sol.success;state=sol.y[:,-1]
 obs=np.array([state[0],state[1]+state[0]*state[2]])
 check('EX10-zero-area-not-flatness',np.max(abs(obs))<1e-10 and abs(state[2])>1e-4,dict(total_signed_area=0,endpoint=state.tolist(),observation_return_error=float(np.max(abs(obs)))))
 eps=np.array([1.,.1,.01,1e-3]);norms=[float(np.linalg.norm(B(np.eye(2),np.diag([1.,e]))@np.array([0.,1.]))) for e in eps]
 check('EX11-conditioning-gate',np.allclose(norms,1/eps),dict(epsilon=eps.tolist(),response_norm=norms))
 diffs=[abs(oracle(rows[i]['case'],rtol=2e-12)-held[i]['oracle']) for i in range(4)]
 check('EX12-solver-refinement',max(diffs)<1e-9,dict(max_endpoint_change=max(diffs),n=4))
 caught=[]
 for name,mut in [('sign',lambda p:-p),('remove_interaction',lambda p:0.),('double_response',lambda p:2*p)]:
  n=sum(abs(mut(x['prediction'])-x['oracle'])>x['tolerance'] for x in held);caught.append(dict(name=name,caught=n>0,rejected_cases=n))
 changed=json.loads(json.dumps(c));changed['a']*=1.01;altered=json.loads(json.dumps(rows));altered[0]['prediction']=held[0]['oracle']
 caught.extend([dict(name='postfreeze_parameter_change',caught=digest(changed)!=f['calibration_sha256']),dict(name='oracle_leak_into_predictions',caught=digest(altered)!=f['predictions_sha256']),dict(name='clock_from_B_ignoring_scale',caught=abs(1-1/np.sqrt(7))>.04),dict(name='zero_area_implies_zero_holonomy',caught=abs(state[2])>1e-4),dict(name='omit_nonzero_momentum_drift',caught=min(ze)>1e-3)])
 # Local H-resp witness: unobserved common translation preserves shape rates.
 M=matrix([1.,1.],.055,.8);v=B(M,J)@np.array([.2,-.1]);bad=v+.01*np.ones(3);V=np.eye(3)-B(M,J)@J
 check('EX16-local-response-falsifier',np.max(abs(J@bad-J@v))<1e-12 and np.linalg.norm(V@bad)>.01,dict(observation_rate_error=float(np.max(abs(J@bad-J@v))),vertical_response_residual=float(np.linalg.norm(V@bad)),scope='local model falsifier, not experimental H-resp verification'))
 check('EX17-projectability-counterexample',1/(1+0**2)!=1/(1+2**2),dict(F='x',P='diag(1+z^2,1)',same_observation=0,metric_at_z0=1,metric_at_z2=.2,scope='G is along the declared latent lift unless basicness is established'))
 check('EX13-canaries',all(x['caught'] for x in caught),dict(canaries=caught))
 dump('rg_extended_results.json',dict(summary=dict(n_checks=len(R),n_pass=sum(x['passed'] for x in R),synthetic=True,external_blinding=False),checks=R))
 return 0 if all(x['passed'] for x in R) else 1
if __name__=='__main__':
 if len(sys.argv)>1:
  if sys.argv[1]=='calibrate':calibrate()
  elif sys.argv[1]=='predict':predict()
  elif sys.argv[1]=='score':sys.exit(score())
  else:raise SystemExit('unknown stage')
 else:
  for stage in ['calibrate','predict','score']:subprocess.run([sys.executable,__file__,stage],check=True)
