# RG - Physical Curvature (final edition)

    python3 rg_physical_curvature_compatible.py --out baseline.json     # 11/11 (PC11 = status metadata)
    python3 rg_physical_curvature_compatible.py --canary                # 2/2 caught
    python3 rg_lock_battery.py                                          # calibrate -> freeze -> predict -> score: 18/18
    python3 rg_lock_battery.py score                                    # rescore frozen artifacts without regeneration
    python3 rg_pcl_audit.py                                             # independent audit A01-A10 (no shared code): 10/10
    python3 rg_pcl_figure.py                                            # holdout figure from saved records

Rerun from scratch regenerates byte-identical frozen predictions (frozen/).
review_supplement/ holds the audit/repair pack whose corrections are integrated (reciprocity vs flatness; finite-loop
reversal; quartic order; run-specific calibration accuracy; PC11 metadata; temperature vs absolute timing).
historic_first_edition/ keeps the original script unchanged. All evidence is synthetic, within declared models.
