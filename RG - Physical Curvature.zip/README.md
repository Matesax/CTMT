# RG - Physical Curvature: battery PC01-PC11

    python3 rg_physical_curvature_attack.py --figs figs   # ~3-4 min
    python3 rg_physical_curvature_attack.py --canary      # curvature claimed for commuting lift; calibration without HI

11/11 on seeds 20261027, 1, 42, 777, 2026; canary 2/2.
Canonical lift B = P J^T (J P J^T)^-1 (unique minimizer); exact apparatus (dZ = AB/sqrt(L^2+A^2), 9.9995 um);
non-selection (commuting lift); covariance; three-sphere Stokes swimmer (Omega = (a/3)[1/L1^2+1/L2^2-1/(L1+L2)^2],
converges to simulation); scallop theorem as flatness; falling-cat body (RG lift = angular-momentum law);
fluctuation-calibrated connection predicts active swimming (1.0-1.5%); second-order law.
