import json, numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
import importlib.util
spec = importlib.util.spec_from_file_location("aud", "rg_pcl_audit.py")
ex = {c["id"]: c for c in json.load(open("rerun/rg_extended_results.json"))["checks"]}
rows = ex["EX02-passive-to-active-heldout"]["evidence"]["rows"]
pred = np.array([r["prediction"] for r in rows]); orc = np.array([r["oracle"] for r in rows])
fig, ax = plt.subplots(1, 3, figsize=(13.5, 3.8))
ax[0].plot(orc*1e4, pred*1e4, "o", ms=4); lim = np.max(np.abs(orc))*1e4*1.1; ax[0].plot([-lim, lim], [-lim, lim], "k-", lw=0.7)
ax[0].set_xlabel(r"force-balance oracle $\Delta X$ ($10^{-4}$)"); ax[0].set_ylabel(r"frozen prediction ($10^{-4}$)")
ax[0].set_title("24 held-out strokes: max error 0.47%", fontsize=9)
trow = ex["EX14-frozen-time-holdout"]["evidence"].get("rows")
if trow:
    tp = np.array([r.get("predicted", r.get("prediction", np.nan)) for r in trow]); to = np.array([r.get("oracle", np.nan) for r in trow])
    ax[1].plot(to, tp, "o", ms=4); lo, hi = np.nanmin(to)*0.97, np.nanmax(to)*1.03; ax[1].plot([lo, hi], [lo, hi], "k-", lw=0.7)
    ax[1].set_xlabel("oracle duration at unit power"); ax[1].set_ylabel("frozen prediction")
ax[1].set_title("frozen duration law: max error 0.066%", fontsize=9)
import subprocess, sys
ns = {}; exec(open("rg_pcl_audit.py").read().split("A01(); A02()")[0], ns)
fs = np.linspace(-3e-3, 1e-3, 7); dx = [ns["swim_loaded"](f)[0] for f in fs]; d0, K = ns["swim_loaded"](0.0)
ax[2].plot(fs*1e3, np.array(dx)*1e4, "o", label="direct force balance (load on one bead)")
ax[2].plot(fs*1e3, (d0+K*fs)*1e4, "k-", lw=0.8, label=r"$\Delta X(0)+fK$")
ax[2].axvline(-d0/K*1e3, color="r", ls="--", lw=0.8, label="predicted stall force"); ax[2].axhline(0, color="grey", lw=0.5)
ax[2].set_xlabel(r"total applied force $f$ ($10^{-3}$)"); ax[2].set_ylabel(r"$\Delta X$ per stroke ($10^{-4}$)"); ax[2].legend(fontsize=6)
ax[2].set_title("affine load law and stall", fontsize=9)
fig.tight_layout(); fig.savefig("pcl_holdout.png", dpi=170); print("ok", bool(trow))
