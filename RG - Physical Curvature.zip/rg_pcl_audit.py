#!/usr/bin/env python3
"""
Independent audit (A01-A10) of the Physical Curvature lock supplement. Shares no code with rg_lock_battery.py.
  A01 zero signed area does not imply zero holonomy (own two-lobe construction in the exact apparatus)
  A02 reciprocal path (exact retrace) cancels exactly in a curved connection
  A03 duration law: power-capped schedule gives T = ell/sqrt(W); brute-force optimal schedule energy -> ell^2/T
  A04 clock scale: P -> cP leaves B unchanged, scales ell by c^-1/2
  A05 affine loaded response v = B qdot + (I - B J) P f_ext; the vertical part depends only on the TOTAL applied force
  A06 stall law on a direct force-balance swimmer: Delta X(f) linear in f, slope K = int dt / (1^T P^-1 1), stall at -Delta X(0)/K
  A07 rate independence of unloaded displacement; loaded displacement depends on duration
  A08 nonzero angular momentum: theta-dot = (L - M_theta_s s-dot)/M_theta_theta reproduces Cartesian momentum L
  A09 expansion order of ab/sqrt(1+a^2): correction -a^3 b/2, quartic for a = b
  A10 the dissipation metric need not descend: F = x, P = diag(1+z^2, 1) -> G = 1 and 1/5 at the same observation
"""
import json, math, sys
import numpy as np
import sympy as sp
from scipy.integrate import solve_ivp
from scipy.optimize import minimize

R = []


def reg(i, ok, ev): R.append(dict(id=i, passed=bool(ok), evidence=ev)); print(f"[{'PASS' if ok else 'FAIL'}] {i} {json.dumps(ev, default=float)[:170]}")


def lift(P, J): return P@J.T@np.linalg.inv(J@P@J.T)


def app_rhs(s, du, dv):
    J = np.array([[1.0, 0, 0], [s[2], 1, s[0]]]); return lift(np.eye(3), J)@np.array([du, dv])


def walk(s, legs):
    for du, dv, T in legs:
        if T > 0: s = solve_ivp(lambda t, y: app_rhs(y, du, dv), (0, T), s, rtol=1e-12, atol=1e-14).y[:, -1]
    return s


def A01():
    h, c = 0.15, 0.8
    legs = [(1, 0, h), (0, 1, h), (-1, 0, h), (0, -1, h),                    # lobe 1 at u = 0, counterclockwise (+h^2)
            (1, 0, c),                                                      # connector out
            (0, 1, h), (1, 0, h), (0, -1, h), (-1, 0, h),                    # lobe 2 at u = 0.8, clockwise (-h^2)
            (-1, 0, c)]                                                     # connector back
    s = walk(np.zeros(3), legs)
    reg("A01", abs(s[0]) < 1e-12 and abs(s[1]) < 1e-12 and abs(s[2]) > 1e-3,
        dict(signed_area=0.0, observation_return=[s[0], s[1]], residual_z=s[2]))


def A02():
    legs = [(1, 0, 0.3), (0, 1, 0.4), (1, 0, 0.2), (0, 1, 0.1)]
    s = walk(np.zeros(3), legs); s = walk(s, [(-du, -dv, T) for du, dv, T in reversed(legs)])
    reg("A02", np.max(np.abs(s)) < 1e-10, dict(endpoint=list(s)))


# ------------------------------------------------------------------ three-sphere Oseen model (absolute mobility)
def mob(xs, a=0.05):
    M = np.eye(3)
    for i in range(3):
        for j in range(3):
            if i != j: M[i, j] = 1.5*a/abs(xs[i]-xs[j])
    return M


Jsh = np.array([[-1, 1, 0], [0, -1, 1.0]])


def path_h(us, d=0.1, phi=1.2, a=0.05):
    """lift a closed stroke q(u), return h(u) = q'^T G q' along the lifted path."""
    x = np.array([0.0, 1+d, 2+d+d*math.cos(-phi)]); hs = []
    q = lambda u: np.array([1+d*math.cos(2*np.pi*u), 1+d*math.cos(2*np.pi*u-phi)])
    qp = lambda u: np.array([-2*np.pi*d*math.sin(2*np.pi*u), -2*np.pi*d*math.sin(2*np.pi*u-phi)])
    du = us[1]-us[0]
    for u in us:
        L1, L2 = q(u); xs = np.array([0, L1, L1+L2]); P = mob(xs, a); G = np.linalg.inv(Jsh@P@Jsh.T)
        hs.append(float(qp(u)@G@qp(u)))
    return np.array(hs)


def A03():
    N = 400; us = np.linspace(0, 1, N, endpoint=False)+0.5/N; h = path_h(us); du = 1/N
    ell = float(np.sum(np.sqrt(h))*du); W = 2.5
    T_cap = float(np.sum(np.sqrt(h/W))*du)                                   # power-saturated schedule
    T = 1.7
    def E(lt):                                                             # energy for a schedule of dt_k = T softmax(lt)
        dt = T*np.exp(lt)/np.sum(np.exp(lt)); return float(np.sum(h*du**2/dt))
    res = minimize(E, np.zeros(N), method="L-BFGS-B", options=dict(maxiter=4000))
    E_uniform = E(np.zeros(N))
    reg("A03", abs(T_cap-ell/math.sqrt(W)) < 1e-12 and abs(res.fun-ell**2/T)/(ell**2/T) < 1e-5 and E_uniform >= res.fun,
        dict(ell=ell, T_cap=T_cap, ell_over_sqrtW=ell/math.sqrt(W), E_opt=res.fun, ell2_over_T=ell**2/T, E_uniform_ratio=E_uniform/res.fun))


def A04():
    xs = np.array([0, 1.1, 2.0]); P = mob(xs); c = 7.0
    dB = np.max(np.abs(lift(P, Jsh)-lift(c*P, Jsh)))
    q = np.array([0.3, -0.2]); r = math.sqrt(q@np.linalg.inv(Jsh@(c*P)@Jsh.T)@q)/math.sqrt(q@np.linalg.inv(Jsh@P@Jsh.T)@q)
    reg("A04", dB < 1e-12 and abs(r-1/math.sqrt(c)) < 1e-12, dict(B_change=dB, ell_ratio=r, expected=1/math.sqrt(c)))


def A05():
    rng = np.random.default_rng(3); worst, wtot = 0.0, 0.0
    for _ in range(200):
        xs = np.array([0, rng.uniform(0.8, 1.2), 0])+np.array([0, 0, 0]); xs[2] = xs[1]+rng.uniform(0.8, 1.2)
        P = mob(xs); qd = rng.normal(size=2); f = rng.normal(size=3)
        # direct KKT: P^-1 v = J^T lam + f, J v = qd
        K = np.block([[np.linalg.inv(P), -Jsh.T], [Jsh, np.zeros((2, 2))]]); sol = np.linalg.solve(K, np.r_[f, qd]); v = sol[:3]
        aff = lift(P, Jsh)@qd+(np.eye(3)-lift(P, Jsh)@Jsh)@P@f; worst = max(worst, np.max(np.abs(v-aff)))
        f2 = rng.normal(size=3); f2 += (f.sum()-f2.sum())/3                  # same total force, different distribution
        v2 = lift(P, Jsh)@qd+(np.eye(3)-lift(P, Jsh)@Jsh)@P@f2
        one = np.ones(3); vert = lambda w: one@np.linalg.inv(P)@w/(one@np.linalg.inv(P)@one)
        wtot = max(wtot, abs(vert(v)-vert(v2)))
    reg("A05", worst < 1e-12 and wtot < 1e-12, dict(affine_vs_KKT=worst, vertical_dependence_on_distribution=wtot))


def swim_loaded(f, Tdur=1.0, d=0.1, phi=1.2, a=0.05, warp=None):
    """direct force balance: internal forces F (sum 0) + external force f split on bead 1 only; v = M (F + e)."""
    w = 2*np.pi/Tdur
    tau = (lambda t: t) if warp is None else warp
    def qd(t):
        h = 1e-7; u1, u2 = tau(t+h), tau(t-h)
        q = lambda u: np.array([1+d*math.cos(w*u), 1+d*math.cos(w*u-phi)]); return (q(u1)-q(u2))/(2*h)
    def rhs(t, x):
        M = mob(x, a); e = np.array([f, 0, 0])
        A = np.vstack([M[1]-M[0], M[2]-M[1], np.ones(3)]); bvec = np.r_[qd(t)-np.array([(M[1]-M[0])@e, (M[2]-M[1])@e]), 0.0]
        F = np.linalg.solve(A, bvec); return M@(F+e)
    q0 = np.array([1+d, 1+d*math.cos(-phi)]); x0 = np.array([0, q0[0], q0[0]+q0[1]])
    sol = solve_ivp(rhs, (0, Tdur), x0, rtol=1e-11, atol=1e-13, dense_output=True); xf = sol.y[:, -1]
    ts = np.linspace(0, Tdur, 4001); Kint = np.trapezoid([1/(np.ones(3)@np.linalg.inv(mob(sol.sol(t), a))@np.ones(3)) for t in ts], ts)
    return float(np.mean(xf-x0)), float(Kint)


def A06():
    d0, K0 = swim_loaded(0.0); d1, K1 = swim_loaded(1e-3); d2, K2 = swim_loaded(2e-3)
    lin = abs((d2-d0)-2*(d1-d0)) < 1e-3*abs(d1-d0); slope = (d1-d0)/1e-3
    fstall = -d0/K0; ds, _ = swim_loaded(fstall)
    reg("A06", lin and abs(slope-K0)/K0 < 1e-3 and abs(ds) < 1e-3*abs(d0),
        dict(dX0=d0, slope=slope, K=K0, f_stall=fstall, dX_at_stall=ds))


def A07():
    d0, _ = swim_loaded(0.0, Tdur=1.0); d3, _ = swim_loaded(0.0, Tdur=3.0)
    dw, _ = swim_loaded(0.0, Tdur=1.0, warp=lambda t: t+0.08*math.sin(2*np.pi*t)/(2*np.pi))
    l1, _ = swim_loaded(1e-3, Tdur=1.0); l3, _ = swim_loaded(1e-3, Tdur=3.0)
    reg("A07", max(abs(d3-d0), abs(dw-d0)) < 1e-9*max(1, abs(d0))+1e-12 and abs((l3-d3)-3*(l1-d0)) < 0.02*abs(l3-d3),
        dict(unloaded=[d0, d3, dw], loaded_increment_T1=l1-d0, loaded_increment_T3=l3-d3))


def chain_points(xi, ell=0.3):
    th, p1, p2 = xi; e = lambda a: np.array([math.cos(a), math.sin(a)])
    c1, c2 = -0.5*ell*e(th), 0.5*ell*e(th); q0 = c1+ell*e(th+math.pi-p1); q3 = c2+ell*e(th+p2)
    pts = np.array([q0, c1, c2, q3]); return pts-pts.mean(0)


def A08():
    rng = np.random.default_rng(5); worst = 0.0
    for _ in range(30):
        xi = np.array([rng.uniform(0, 6), rng.uniform(0.6, 2.5), rng.uniform(0.6, 2.5)]); sd = rng.normal(size=2); Lval = rng.normal()
        h = 1e-6; Jp = np.stack([(chain_points(xi+h*np.eye(3)[k])-chain_points(xi-h*np.eye(3)[k]))/(2*h) for k in range(3)], -1)
        M = np.einsum("pik,pil->kl", Jp, Jp)
        thd = (Lval-M[0, 1:]@sd)/M[0, 0]; rate = np.r_[thd, sd]
        pts = chain_points(xi); v = np.einsum("pik,k->pi", Jp, rate); Lc = float(np.sum(pts[:, 0]*v[:, 1]-pts[:, 1]*v[:, 0]))
        worst = max(worst, abs(Lc-Lval))
    reg("A08", worst < 1e-8, dict(max_momentum_error=worst))


def A09():
    a, b = sp.symbols("a b", positive=True); ser = sp.series(a*b/sp.sqrt(1+a**2), a, 0, 6).removeO()
    eq = sp.series((a*a/sp.sqrt(1+a**2)), a, 0, 7).removeO()
    reg("A09", sp.simplify(ser-(a*b-a**3*b/2+3*a**5*b/8)) == 0 and sp.Poly(sp.expand(eq-a**2), a).monoms()[-1][0] == 4,
        dict(series=str(ser), equal_sides=str(eq)))


def A10():
    G = lambda z: 1/(1+z**2); reg("A10", G(0) == 1 and abs(G(2)-0.2) < 1e-15, dict(G_z0=G(0), G_z2=G(2)))


A01(); A02(); A03(); A04(); A05(); A06(); A07(); A08(); A09(); A10()
n = sum(r["passed"] for r in R)
json.dump(dict(n_checks=len(R), n_pass=n, results=R), open("rg_pcl_audit_results.json", "w"), indent=2, default=float)
print(f"\n{n}/{len(R)} independent audit checks pass."); sys.exit(0 if n == len(R) else 1)
