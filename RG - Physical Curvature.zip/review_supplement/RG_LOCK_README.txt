RG Physical Curvature: conditional lock evidence

All results are synthetic model tests, not laboratory evidence.
18/18 extended checks pass. Compatible baseline: 11/11, including PC11 metadata.
Freeze is separate-process computational holdout, not external investigator blinding.
Predictor and oracle share the declared Oseen model.

Run from this folder:
python rg_physical_curvature_compatible.py --out baseline.json
python rg_physical_curvature_compatible.py --canary
python rg_lock_battery.py

Re-score existing frozen artifacts without regeneration:
python rg_lock_battery.py score

Compile supplement with pdflatex twice; rg_lock_numbers.tex must be alongside it.
The original PDFs were not modified. The supplement lists required parent-paper corrections.
