"""Does a finite protocol mesh replace the obstruction tower? Test on the persistent-repeat winding family (L131 witness).
Transporter on the inner circle is R((k2-k1) theta); the tower class is its degree. A mesh sees samples theta_j only."""
import math, json
def degree_from_mesh(k, N, adjacency=True):
    angs = [(k * 2 * math.pi * j / N) for j in range(N + 1)]
    if not adjacency:                       # pointwise quotient: each sample is an orbit point; no transport between samples
        return None
    tot = 0.0
    for a, b in zip(angs[:-1], angs[1:]):
        d = (b - a + math.pi) % (2 * math.pi) - math.pi   # shortest step, valid iff true step < pi
        tot += d
    return round(tot / (2 * math.pi))
rows = {}
for k in (0, 1, 2, 5):
    for N in (4, 8, 64):
        rows[f"k={k},N={N}"] = dict(mesh_degree=degree_from_mesh(k, N), true=k,
                                    coverage_ok=(2 * math.pi * abs(k) / N < math.pi))
ok = all((r["mesh_degree"] == r["true"]) == r["coverage_ok"] or (r["mesh_degree"] == r["true"]) for r in rows.values())
alias = {k: v for k, v in rows.items() if not v["coverage_ok"] and v["mesh_degree"] != v["true"]}
print(json.dumps(dict(pointwise_mesh_sees_degree=degree_from_mesh(1, 64, adjacency=False), rows=rows, aliasing_failures=alias), indent=1))
