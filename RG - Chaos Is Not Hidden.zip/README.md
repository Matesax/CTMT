# RG - Chaos Is Not Hidden: the frontier battery CH01-CH07

    python3 rg_chaos_frontier_attack.py --figs figs   # seed 20261007, writes the five figures (~1-2 min)
    python3 rg_chaos_frontier_attack.py --canary      # task substitution (re-observation) and absorption canaries
    python3 coil_audit_mutation.py                    # audit of the chaos/coil attack (needs that script alongside)

7/7 on seeds 20261007, 1, 42, 777, 2026; canary 2/2.
Frontier law: the LOCKED/ESCALATE boundary has slope 1/lambda in log(1/sigma0); protocols shift intercepts only;
Fisher about the past grows with slope 2 lambda; quotient classes grow with slope h. Surrogate models and static
gates are refuted; chaos can be hidden only by changing the declared task, which the canary catches.
