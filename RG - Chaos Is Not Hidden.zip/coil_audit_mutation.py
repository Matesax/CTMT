#!/usr/bin/env python3
"""Audit of rg_chaos_coil_protocol_attack.py: replace the chaotic Sabra dynamics by a smooth quasi-periodic signal of the
same per-shell amplitude. If the gates were sensitive to chaos, the status would change. It does not: LOCKED on both.
Usage: place next to rg_chaos_coil_protocol_attack.py and run (quick config, one seed)."""
import numpy as np, sys
sys.argv = ['x']
import rg_chaos_coil_protocol_attack as C
cfg = C.Config(steps=12000, burn=2000, intervention_step=6500); orig = C.simulate
def periodic(cfg, seed, perturbed=False):
    t, U, k = orig(cfg, seed, perturbed); tt = t[:, None]; amp = np.std(U, axis=0)[None, :]; w = np.arange(1, U.shape[1]+1)[None, :]
    V = amp*np.exp(1j*(w*tt*3.1+0.3*w))*(1+0.2*np.sin(0.7*tt))
    return t, (V*(1+1e-9) if perturbed else V), k
for name, sim in (("chaotic Sabra", orig), ("non-chaotic surrogate", periodic)):
    C.simulate = sim; checks, met, *_ = C.run_seed(cfg, 20261006)
    print(f"{name:24s} status={met['status']}  C01={met['lyapunov']:.4f}  all gates pass={all(c.passed for c in checks)}")
