#!/usr/bin/env python3
"""
RG does not hide chaos: the frontier battery CH01-CH07
======================================================
Claim under attack: "RG hides chaotic complexity inside protocol assumptions and hypotheses."
Test: chaos must appear in quantities a protocol cannot choose. RG's own decision boundaries carry it:
  * forecast frontier  n*(sigma0) = (1/lambda) log(eps/sigma0) + c_protocol   -> slope 1/lambda
  * Fisher about the past  log I_n ~ 2 lambda n                                -> slope 2 lambda
  * quotient growth  log |Q_n(eps)| ~ h n                                        -> slope h
Protocols (sensors, precision, resolution, coverage) shift intercepts only. Slopes are protocol-invariant.

  CH01 forecast frontier slope = 1/lambda (logistic r=4, r=3.9, Henon); periodic r=3.5: no frontier
  CH02 protocol invariance: three sensor protocols, parallel frontiers (intercepts differ, slopes agree)
  CH03 duality: Fisher about the initial state grows with slope 2 lambda; forecast variance grows with 2 lambda
  CH04 quotient growth slope = entropy, invariant across resolutions (2, 4, 8 bins); periodic: flat
  CH05 Lorenz (continuous time): frontier slope = 1/lambda_Lorenz
  CH06 sabotage: a surrogate forecaster certified on in-sample fit hides chaos -> false LOCKs; frontier gate: none
  CH07 static gates are chaos-blind: an instantaneous-inversion gate passes identically on chaotic and periodic
       systems; the frontier gate separates them (the audit of the coil attack, reproduced on maps)

Run:  python3 rg_chaos_frontier_attack.py [--seed 20261007] [--out FILE] [--figs DIR] [--canary]
"""
import argparse, json, math, sys, time, os
import numpy as np

RESULTS, MUT, FIG = [], {}, {}
EPS = 0.05


def f_(x): return float(np.round(float(x), 12))


def _finite(o):
    if isinstance(o, dict): return all(_finite(v) for v in o.values())
    if isinstance(o, (list, tuple)): return all(_finite(v) for v in o)
    if isinstance(o, float): return math.isfinite(o)
    return True


def register(aid, naive, keep, passed, ev, verdict):
    if not _finite(ev): passed, verdict = False, "NONFINITE"
    RESULTS.append(dict(id=aid, naive_claim=naive, rg_claim=keep, passed=bool(passed), verdict=verdict, evidence=ev))
    print(f"[{'PASS' if passed else 'FAIL'}] {aid} {verdict:16s} {keep[:84]}")


# ------------------------------------------------------------------ systems (vectorized over trials)
def logistic(r):
    return dict(step=lambda X: r*X*(1-X), dim=1, deriv=lambda X: r*(1-2*X), name=f"logistic r={r}")


def henon(a=1.4, b=0.3):
    def step(X):
        x, y = X[..., 0], X[..., 1]; return np.stack([1-a*x*x+y, b*x], -1)
    return dict(step=step, dim=2, name="Henon")


def attractor_samples(sysm, M, rng, burn=2000):
    if sysm["dim"] == 1: X = rng.uniform(0.05, 0.95, M)
    else: X = np.tile(np.array([0.1, 0.1]), (M, 1)) + 1e-3*rng.normal(size=(M, 2))
    for _ in range(burn): X = sysm["step"](X)
    return X


def lyapunov(sysm, rng, M=400, N=4000):
    X = attractor_samples(sysm, M, rng)
    if sysm["dim"] == 1:
        s = np.zeros(M)
        for _ in range(N): s += np.log(np.abs(sysm["deriv"](X))+1e-300); X = sysm["step"](X)
        return float(np.mean(s/N))
    v = np.tile(np.array([1.0, 0.0]), (M, 1)); s = np.zeros(M)
    for _ in range(N):
        x = X[:, 0]; J00, J01, J10 = -2*1.4*x, 1.0, 0.3
        v = np.stack([J00*v[:, 0]+J01*v[:, 1], J10*v[:, 0]], -1)
        nv = np.linalg.norm(v, axis=1); s += np.log(nv); v /= nv[:, None]; X = sysm["step"](X)
    return float(np.mean(s/N))


def estimate(X0, sigma0, rng, protocol="direct"):
    """protocol: how the initial state is measured. Returns the estimate."""
    if protocol == "direct":
        return X0 + sigma0*rng.normal(size=X0.shape)
    if protocol == "nonlinear":                      # sensor sin(pi x / 2), 4 readings, inverted
        y = np.sin(np.pi*np.clip(X0, 0, 1)/2)[None] + sigma0*rng.normal(size=(4,)+X0.shape)
        return 2/np.pi*np.arcsin(np.clip(y.mean(0), -1, 1))
    if protocol == "quantized":                      # dithered quantizer with step 30 sigma0, 16 readings averaged
        q = 30*sigma0; d = rng.uniform(-q/2, q/2, size=(16,)+X0.shape)
        return (np.round((X0[None]+d)/q)*q - d).mean(0)
    raise ValueError(protocol)


def frontier(sysm, sigma0, rng, protocol="direct", M=600, nmax=200, cover=0.95):
    """largest horizon n for which the forecast is within EPS for at least `cover` of trials (LOCKED)."""
    X = attractor_samples(sysm, M, rng); Xh = estimate(X, sigma0, rng, protocol)
    last = -1
    for n in range(nmax+1):
        err = np.abs(X-Xh) if sysm["dim"] == 1 else np.linalg.norm(X-Xh, axis=1)
        if np.mean(err <= EPS) >= cover: last = n
        else: break
        X, Xh = sysm["step"](X), sysm["step"](Xh)
        if MUT.get("assimilate"):                      # sabotage: silently re-observe the state every step
            Xh = estimate(X, sigma0, rng, protocol)    # (task changed from forecasting to filtering)
    return last if last < nmax else math.inf


def slope_fit(sig, ns):
    x = np.log(1/np.array(sig)); y = np.array(ns, float); return float(np.polyfit(x, y, 1)[0]), float(np.polyfit(x, y, 1)[1])


SIGMAS = [1e-3, 1e-4, 1e-5, 1e-6, 1e-7, 1e-8, 1e-9, 1e-10]


# ======================================================================= checks
def ftle_prediction(sysm, sigma0, rng, cover, M=4000, nmax=200):
    """linearized prediction of the frontier from finite-time Lyapunov exponents: largest n with
    P(sigma0 |Z| exp(n lambda_n) <= EPS) >= cover."""
    X = attractor_samples(sysm, M, rng); Z = np.abs(rng.normal(size=M)); logD = np.zeros(M); last = -1
    for n in range(nmax+1):
        if np.mean(np.log(sigma0*Z)+logD <= math.log(EPS)) >= cover: last = n
        else: break
        logD += np.log(np.abs(sysm["deriv"](X))+1e-300); X = sysm["step"](X)
    return last


def CH01_frontier(rng):
    """(a) uniformly expanding r=4: 95% frontier slope recovers lambda; (b) non-uniform r=3.9: the 95% frontier is a
    QUANTILE law, predicted from the finite-time exponent distribution, and the 50% frontier recovers lambda;
    (c) Henon: 50% frontier recovers lambda; (d) periodic r=3.5: no frontier.
    (First registration required the 95% slope to equal lambda for every system and failed for r=3.9 and Henon:
    the worst 5% of trajectories expand faster than average at finite horizon.)"""
    out = {}; ok = True
    s4 = logistic(4.0); lam4 = lyapunov(s4, rng); n4 = [frontier(s4, s, rng) for s in SIGMAS]
    if any(v == math.inf for v in n4):                  # frontier vanished on a chaotic system: chaos was hidden
        register("CH01", "Chaotic complexity is absorbed by the protocol.", "Frontier vanished on a chaotic system "
                 "(task substitution or leakage): REJECT.", False, dict(frontier=[str(v) for v in n4]), "HIDDEN-CHAOS")
        return
    l4 = 1/slope_fit(SIGMAS, n4)[0]; ok &= abs(l4-lam4)/lam4 < 0.05
    out["logistic r=4.0 (95%)"] = dict(lambda_true=f_(lam4), lambda_from_frontier=f_(l4), frontier=[int(v) for v in n4])
    FIG.setdefault("frontier", {})["logistic r=4.0 (95%)"] = (SIGMAS, n4, lam4)
    s39 = logistic(3.9); lam39 = lyapunov(s39, rng)
    n95 = [frontier(s39, s, rng) for s in SIGMAS]; p95 = [ftle_prediction(s39, s, rng, 0.95) for s in SIGMAS]
    n50 = [frontier(s39, s, rng, cover=0.5) for s in SIGMAS]; l50 = 1/slope_fit(SIGMAS, n50)[0]; l95 = 1/slope_fit(SIGMAS, n95)[0]
    pred_err = max(abs(a_-b_) for a_, b_ in zip(n95, p95))
    ok &= pred_err <= 2 and abs(l50-lam39)/lam39 < 0.1 and l95 > l50
    out["logistic r=3.9"] = dict(lambda_true=f_(lam39), lambda_95=f_(l95), lambda_50=f_(l50), frontier95=[int(v) for v in n95],
                                 ftle_prediction95=[int(v) for v in p95], max_prediction_error_steps=int(pred_err))
    FIG["frontier"]["logistic r=3.9 (50%)"] = (SIGMAS, n50, lam39)
    sh = henon(); lamh = lyapunov(sh, rng); nh50 = [frontier(sh, s, rng, cover=0.5) for s in SIGMAS]; lh50 = 1/slope_fit(SIGMAS, nh50)[0]
    ok &= abs(lh50-lamh)/lamh < 0.1
    out["Henon (50%)"] = dict(lambda_true=f_(lamh), lambda_50=f_(lh50), frontier=[int(v) for v in nh50])
    FIG["frontier"]["Henon (50%)"] = (SIGMAS, nh50, lamh)
    per = logistic(3.5); nper = [frontier(per, s, rng, nmax=300) for s in (1e-3, 1e-6, 1e-9)]
    transient = frontier(per, 1e-2, rng, nmax=300)      # first registration included 1e-2: a finite transient
    out["logistic r=3.5"] = dict(frontier=[str(v) for v in nper], coarse_precision_transient_at_1em2=str(transient))
    passed = ok and all(v == math.inf for v in nper)
    register("CH01", "Chaotic complexity is absorbed by the protocol; RG certificates hide it.",
             "Chaos is the slope of RG's own decision boundary. Uniform expansion (r=4): the 95% frontier slope recovers "
             "lambda. Non-uniform chaos (r=3.9, Henon): the coverage level selects a quantile of the finite-time exponent; "
             "the 95% frontier is predicted from that distribution within 2 steps and the 50% frontier recovers lambda. "
             "Periodic: no frontier.", passed, dict(by_system=out), "FALSIFIED-naive")


def CH02_protocol_invariance(rng):
    sysm = logistic(3.9); lam = lyapunov(sysm, rng); res = {}
    for p in ("direct", "nonlinear", "quantized"):
        sig = SIGMAS[:-1] if p != "direct" else SIGMAS
        ns = [frontier(sysm, s, rng, protocol=p) for s in sig]; sl, ic = slope_fit(sig, ns)
        res[p] = dict(slope=f_(sl), intercept=f_(ic), lambda_hat=f_(1/sl)); FIG.setdefault("protocols", {})[p] = (sig, ns)
    slopes = [v["slope"] for v in res.values()]; ics = [v["intercept"] for v in res.values()]
    spread = (max(slopes)-min(slopes))/np.mean(slopes); icspread = max(ics)-min(ics)
    if MUT.get("ch02_pretend_absorbed"): spread = 1.0
    passed = spread < 0.1 and icspread > 1.0
    register("CH02", "A cleverer protocol can make the chaotic frontier disappear.",
             "Three sensor protocols (direct, nonlinear sin sensor, dithered quantizer) give parallel frontiers: intercepts "
             "differ by several steps, slopes agree within 10%. The protocol buys a constant number of steps, never a "
             "different rate. lambda is not a protocol choice.", passed,
             dict(lambda_true=f_(lam), by_protocol=res, slope_rel_spread=f_(spread), intercept_spread=f_(icspread)), "FALSIFIED-naive")


def CH03_duality(rng):
    """Fisher information about x0 from n noisy observations y_k = x_k + noise: I_n = sum_k (Df^k)^2 / s^2."""
    out = {}
    for sysm in (logistic(3.9), logistic(3.5)):
        X = attractor_samples(sysm, 400, rng); D = np.ones_like(X); acc = np.zeros_like(X); logI = []
        for n in range(1, 41):
            acc += D**2; logI.append(float(np.median(np.log(acc)))); D = D*sysm["deriv"](X); X = sysm["step"](X)
        sl = float(np.polyfit(np.arange(20, 40), logI[19:39], 1)[0]); out[sysm["name"]] = dict(logFisher_slope=f_(sl))
        FIG.setdefault("duality", {})[sysm["name"]] = logI
    lam = lyapunov(logistic(3.9), rng)
    passed = abs(out["logistic r=3.9"]["logFisher_slope"]-2*lam)/(2*lam) < 0.15 and out["logistic r=3.5"]["logFisher_slope"] < 0.05
    register("CH03", "Chaos only destroys information.",
             "Two faces of one exponent: Fisher information about the initial state grows with slope 2 lambda (the past "
             "becomes more resolvable) while forecast variance grows with the same slope. A periodic system shows neither.",
             passed, dict(lambda_true=f_(lam), by_system=out), "FALSIFIED-naive")


def word_counts(sysm, bins, rng, M=600000, nmax=13):
    X = attractor_samples(sysm, M, rng, burn=500); S = np.zeros((M, nmax), np.int64)
    for n in range(nmax): S[:, n] = np.minimum((X*bins).astype(int), bins-1); X = sysm["step"](X)
    out = []
    for n in range(1, nmax+1):
        w = np.zeros(M, np.int64)
        for j in range(n): w = w*bins+S[:, j]
        out.append(len(np.unique(w)))
    return out


def CH04_quotient_growth(rng):
    res = {}; slopes = []
    for bins in (2, 4, 8):
        c = word_counts(logistic(4.0), bins, rng, nmax=11 if bins == 8 else 13); lc = np.log(c)
        sl = float(np.polyfit(np.arange(6, len(c)+1), lc[5:], 1)[0]); slopes.append(sl); res[str(bins)] = dict(slope=f_(sl), counts=c)
        FIG.setdefault("growth", {})[f"r=4, {bins} bins"] = c
    per = word_counts(logistic(3.5), 8, rng, nmax=11); FIG["growth"]["r=3.5, 8 bins"] = per
    passed = all(abs(s-math.log(2)) < 0.08 for s in slopes) and per[-1] == per[-3]
    register("CH04", "Changing the resolution of the observation changes the complexity RG reports.",
             "The number of quotient classes of the n-step history grows with slope ln 2 = h for 2, 4 and 8 bins alike "
             "(resolution moves the intercept only); a periodic system saturates.", passed,
             dict(r4_by_bins=res, periodic_counts=per, entropy=f_(math.log(2))), "FALSIFIED-naive")


def CH05_lorenz(rng):
    def rhs(X):
        x, y, z = X[:, 0], X[:, 1], X[:, 2]; return np.stack([10*(y-x), x*(28-z)-y, x*y-8/3*z], -1)
    def flow(X, T, dt=0.005):
        for _ in range(int(round(T/dt))):
            k1 = rhs(X); k2 = rhs(X+dt/2*k1); k3 = rhs(X+dt/2*k2); k4 = rhs(X+dt*k3); X = X+dt/6*(k1+2*k2+2*k3+k4)
        return X
    M = 300; X = flow(np.tile([1.0, 1.0, 20.0], (M, 1))+rng.normal(size=(M, 3)), 20.0)
    sig = [1e-2, 1e-4, 1e-6, 1e-8]; tstars = []
    for s in sig:
        A = X.copy(); B = A + s*rng.normal(size=A.shape)/math.sqrt(3); t = 0.0; last = 0.0
        while t < 40:
            if np.mean(np.linalg.norm(A-B, axis=1) <= 1.0) >= 0.95: last = t
            else: break
            A, B = flow(A, 0.1), flow(B, 0.1); t += 0.1
        tstars.append(last)
    sl, _ = slope_fit(sig, tstars); lam_hat = 1/sl
    passed = abs(lam_hat-0.9056)/0.9056 < 0.12
    FIG["lorenz"] = (sig, tstars)
    register("CH05", "The frontier law is an artefact of discrete maps.",
             "For the Lorenz flow the forecast horizon t*(sigma0) has slope 1/lambda with lambda_hat within 12% of the known "
             "0.906.", passed, dict(sigmas=sig, horizons=[f_(v) for v in tstars], lambda_hat=f_(lam_hat), lambda_known=0.9056),
             "FALSIFIED-naive")


def CH06_surrogate(rng):
    """sabotage: an analog (nearest-neighbour) forecaster trained on a long record, certified LOCKED at all horizons
    because its one-step in-sample error is tiny. Held-out multi-step coverage at sigma0 = 1e-6 decides."""
    sysm = logistic(3.9); rec = attractor_samples(sysm, 1, rng)[0]; train = [rec]
    for _ in range(20000): rec = sysm["step"](np.array(rec)); train.append(float(rec))
    train = np.array(train); xs, ys = train[:-1], train[1:]; order = np.argsort(xs); xs, ys = xs[order], ys[order]
    def surrogate(X):                                       # piecewise-linear analog forecaster on 20000 pairs
        return np.interp(X, xs, ys)
    one_step = float(np.median(np.abs(surrogate(xs[::7])-sysm["step"](xs[::7]))))
    claimed = 200                                           # sabotage: one-step fit => certify all horizons
    X = attractor_samples(sysm, 600, rng); Xh = X + 1e-6*rng.normal(size=X.shape); last = -1
    for n in range(claimed+1):
        if np.mean(np.abs(X-Xh) <= EPS) >= 0.95: last = n
        else: break
        X, Xh = sysm["step"](X), surrogate(Xh)
    true_front = frontier(sysm, 1e-6, rng)
    false_locks = claimed - max(last, 0)
    rg_false = 0 if true_front >= 0 else 1
    passed = one_step < 1e-4 and last < 60 and false_locks > 100 and rg_false == 0
    register("CH06", "A good model of the dynamics removes the chaotic frontier.",
             "A surrogate forecaster with tiny one-step error, certified at all horizons by its in-sample fit, holds only "
             "for a finite held-out horizon; the remaining claimed horizons are false LOCKs. RG certifies only up to the "
             "measured frontier.", passed,
             dict(surrogate_one_step_err=f_(one_step), surrogate_heldout_horizon=int(last), true_frontier=int(true_front),
                  false_locks_claimed=int(false_locks)), "FALSIFIED-naive")


def CH07_static_blind(rng):
    """static gate: invert a noisy linear sensor y = A s + noise at equal times (the coil attack's C05). It passes on any
    signal s. The frontier gate needs dynamics."""
    out = {}
    for sysm in (logistic(3.9), logistic(3.5)):
        X = attractor_samples(sysm, 1, rng)[0]; s = []
        for _ in range(3000): X = sysm["step"](np.array(X)); s.append(float(X))
        S = np.c_[s, np.roll(s, 1), np.roll(s, 2)]; A = rng.normal(size=(5, 3)); Y = S@A.T + 1e-3*rng.normal(size=(3000, 5))
        W = np.linalg.lstsq(Y[:2000], S[:2000], rcond=None)[0]; nrmse = float(np.sqrt(np.mean((Y[2000:]@W-S[2000:])**2))/np.std(S))
        fr = frontier(sysm, 1e-6, rng)
        out[sysm["name"]] = dict(static_gate_nrmse=f_(nrmse), static_gate_pass=bool(nrmse < 0.3), frontier=str(fr))
    a, b = out["logistic r=3.9"], out["logistic r=3.5"]
    passed = a["static_gate_pass"] and b["static_gate_pass"] and a["frontier"] != b["frontier"] and b["frontier"] == "inf"
    register("CH07", "Rank, conditioning and held-out inversion gates certify that chaos was handled (uploaded coil attack).",
             "Those gates are static: they pass identically on a chaotic and a periodic system. Only a gate whose decision "
             "depends on the dynamics (the forecast frontier) separates them.", passed, dict(by_system=out), "FALSIFIED-naive")


ATTACKS = [CH01_frontier, CH02_protocol_invariance, CH03_duality, CH04_quotient_growth, CH05_lorenz, CH06_surrogate, CH07_static_blind]


def make_figures(d):
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    os.makedirs(d, exist_ok=True)
    # Fig 1: status map for r=4 and r=3.5
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.8), sharey=True)
    rng = np.random.default_rng(1); grid = np.logspace(-2, -12, 21)
    for k, (r, title) in enumerate(((4.0, "chaotic: logistic r = 4"), (3.5, "periodic: logistic r = 3.5"))):
        sysm = logistic(r); fr = [frontier(sysm, s, rng, nmax=60, M=300) for s in grid]
        Z = np.array([[1 if (f == math.inf or n <= f) else 0 for f in fr] for n in range(61)])
        ax[k].imshow(Z, origin="lower", aspect="auto", extent=[2, 12, 0, 60], cmap="RdYlGn", vmin=-0.3, vmax=1.3)
        if r == 4.0:
            xx = np.linspace(2, 12, 50); ax[k].plot(xx, np.log(EPS/10**(-xx))/math.log(2), "k--", lw=1.2, label=r"$n^*=\log(\varepsilon/\sigma_0)/\lambda$")
            ax[k].legend(loc="upper left", fontsize=8)
        ax[k].set_title(title, fontsize=10); ax[k].set_xlabel(r"declared precision  $\log_{10}(1/\sigma_0)$")
    ax[0].set_ylabel("forecast horizon $n$")
    ax[0].text(9.5, 8, "LOCKED", fontsize=9); ax[0].text(3, 45, "ESCALATE /\nSTRUCTURAL WALL", fontsize=9)
    fig.tight_layout(); fig.savefig(f"{d}/fig1_status_map.png", dpi=170); plt.close(fig)
    # Fig 2: protocols
    fig, ax = plt.subplots(figsize=(5.2, 3.6))
    for p, (sig, ns) in FIG["protocols"].items(): ax.plot(np.log10(1/np.array(sig)), ns, "o-", label=p)
    ax.set_xlabel(r"$\log_{10}(1/\sigma_0)$"); ax.set_ylabel(r"frontier $n^*$"); ax.set_title("protocols shift intercepts, not slopes", fontsize=10)
    ax.legend(fontsize=8); fig.tight_layout(); fig.savefig(f"{d}/fig2_protocols.png", dpi=170); plt.close(fig)
    # Fig 3: duality
    fig, ax = plt.subplots(figsize=(5.2, 3.6))
    for name, logI in FIG["duality"].items(): ax.plot(range(1, len(logI)+1), np.array(logI)/math.log(10), label=f"Fisher about $x_0$, {name}")
    ax.set_xlabel("observation length $n$"); ax.set_ylabel(r"$\log_{10}$ Fisher (median)"); ax.set_title(r"the past becomes resolvable at rate $2\lambda$", fontsize=10)
    ax.legend(fontsize=7); fig.tight_layout(); fig.savefig(f"{d}/fig3_duality.png", dpi=170); plt.close(fig)
    # Fig 4: growth
    fig, ax = plt.subplots(figsize=(5.2, 3.6))
    for name, c in FIG["growth"].items(): ax.semilogy(range(1, len(c)+1), c, "o-", ms=3, label=name)
    ax.set_xlabel("history length $n$"); ax.set_ylabel(r"quotient classes $|Q_n|$"); ax.set_title(r"resolution shifts intercepts; slope $= h$", fontsize=10)
    ax.legend(fontsize=7); fig.tight_layout(); fig.savefig(f"{d}/fig4_growth.png", dpi=170); plt.close(fig)
    # Fig 5: frontiers of three systems + Lorenz
    fig, ax = plt.subplots(figsize=(5.2, 3.6))
    for name, (sig, ns, lam) in FIG["frontier"].items(): ax.plot(np.log(1/np.array(sig)), ns, "o", ms=4, label=f"{name} ($\\lambda$={lam:.3f})")
    for name, (sig, ns, lam) in FIG["frontier"].items():
        xx = np.log(1/np.array(sig)); ax.plot(xx, (xx+math.log(EPS))/lam + (np.mean(ns)-np.mean((xx+math.log(EPS))/lam)), "k-", lw=0.6)
    ax.set_xlabel(r"$\ln(1/\sigma_0)$"); ax.set_ylabel(r"frontier $n^*$"); ax.set_title(r"slope $=1/\lambda$ for every system", fontsize=10)
    ax.legend(fontsize=7); fig.tight_layout(); fig.savefig(f"{d}/fig5_systems.png", dpi=170); plt.close(fig)


def run_all(seed):
    for a in ATTACKS:
        rng = np.random.default_rng([seed, ATTACKS.index(a)])
        try: a(rng)
        except Exception as ex: register(a.__name__[:4], "?", f"EXCEPTION {ex!r}", False, {}, "ERROR")


def canary(seed):
    muts = [("CH02", {"ch02_pretend_absorbed": True}),
            ("CH01", {"assimilate": True})]          # task substitution hides the frontier: must be caught
    ok = True
    for tgt, m in muts:
        RESULTS.clear(); MUT.clear(); MUT.update(m); print(f"--- canary {tgt}: {m}")
        a = next(x for x in ATTACKS if x.__name__.startswith(tgt))
        a(np.random.default_rng([seed, ATTACKS.index(a)])); caught = not RESULTS[-1]["passed"]; ok &= caught
        print(f"    {'CAUGHT' if caught else 'NOT CAUGHT'}")
    MUT.clear(); print("CANARY:", "all caught" if ok else "BATTERY TOO WEAK"); return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--seed", type=int, default=20261007)
    ap.add_argument("--out", default="rg_chaos_frontier_results.json"); ap.add_argument("--figs", default="")
    ap.add_argument("--canary", action="store_true"); a = ap.parse_args()
    if a.canary: sys.exit(canary(a.seed))
    t0 = time.time(); print(f"RG chaos frontier battery, seed {a.seed}\n"); run_all(a.seed)
    if a.figs: make_figures(a.figs)
    n = sum(r["passed"] for r in RESULTS)
    summ = dict(seed=a.seed, n_checks=len(RESULTS), n_pass=n, runtime_s=round(time.time()-t0, 1))
    json.dump(dict(summary=summ, results=RESULTS), open(a.out, "w"), indent=2,
              default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print(f"\n{n}/{len(RESULTS)} pass."); sys.exit(0 if n == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
