#!/usr/bin/env python3
"""Dynamic RG attack for a Sabra shell system observed through Biot-Savart coils.

A logistic forcing state z controls the Sabra forcing amplitude. At r=4 it has
lambda=ln 2; at r=3.5 it is periodic. The same shell equations, coil geometry,
sensor protocols, thresholds and tasks are used in both controls. Chaos must
therefore appear in RG outputs rather than in observer declarations.
"""
import argparse,json,math
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
MU0=4e-7*np.pi; SEEDS=[20261007,1,42,777,2026]
_CACHE={}
class C:
 n=8; dt=2e-4; sub=4; nu=4e-5; f0=.018; coils=5; sensors=7; trials=64
 eps=.06; sigmas=np.array([1e-3,2e-4,4e-5,8e-6,1.6e-6]); nmax=26

def rhs(u,k,nu,force):
 z=np.zeros_like(u);a,b,c=1.,-.5,-.5;n=u.shape[-1]
 for j in range(n):
  q=0j
  if j+2<n:q+=a*k[j+1]*u[...,j+1]*np.conj(u[...,j+2])
  if j-1>=0 and j+1<n:q+=b*k[j]*u[...,j-1]*np.conj(u[...,j+1])
  if j-2>=0:q+=c*k[j-1]*u[...,j-1]*u[...,j-2]
  z[...,j]=1j*q-nu*k[j]**2*u[...,j]
 z[...,0]+=force*(1+1j)/np.sqrt(2);return z

def micro(u,k,c,force):
 h=c.dt;p=rhs(u,k,c.nu,force);q=rhs(u+h*p/2,k,c.nu,force);r=rhs(u+h*q/2,k,c.nu,force);s=rhs(u+h*r,k,c.nu,force)
 return u+h*(p+2*q+2*r+s)/6

def macro(u,z,k,c,r=4.0):
 z=r*z*(1-z); force=c.f0*(.55+.9*z)
 for _ in range(c.sub):u=micro(u,k,c,force)
 return u,z

def setup(seed,c):
 g=np.random.default_rng(seed);u=(g.normal(size=c.n)+1j*g.normal(size=c.n))*1e-3;k=2.**np.arange(c.n);z=.1732050807
 key=(seed,c.n,c.dt,c.sub,c.nu,c.f0)
 if key not in _CACHE:
  for _ in range(120):u,z=macro(u,z,k,c,3.9)
  _CACHE[key]=(u.copy(),k.copy(),z)
 u,k,z=_CACHE[key]
 return u.copy(),k.copy(),z

def coil(seed,c):
 g=np.random.default_rng(seed+991);R=np.linspace(.035,.095,c.coils);zc=np.linspace(-.11,.11,c.coils);zs=np.linspace(-.16,.16,c.sensors)
 A=np.array([[MU0*rr**2/(2*(rr**2+(zz-z0)**2)**1.5) for rr,z0 in zip(R,zc)] for zz in zs])
 M=g.normal(size=(c.coils,2*c.n));M/=np.linalg.norm(M,axis=1,keepdims=True);return A,M

def obs(u,A,M):
 x=np.concatenate([u.real,u.imag],axis=-1);I=np.tanh(x@M.T);return I@A.T

def estimate_z(z,sigma,g,p):
 if p=='direct':return np.clip(z+sigma*g.normal(size=len(z)),1e-10,1-1e-10)
 if p=='repeat4':return np.clip(z+sigma*g.normal(size=(4,len(z))).mean(0),1e-10,1-1e-10)
 q=8*sigma;d=g.uniform(-q/2,q/2,size=(16,len(z)));return np.clip((np.round((z+d)/q)*q-d).mean(0),1e-10,1-1e-10)

def frontier(seed,c,sigma,p,r=4.0,filtering=False):
 g=np.random.default_rng([seed,int(-math.log10(sigma)*100),len(p)]);u0,k,z0=setup(seed,c);A,M=coil(seed,c)
 U=np.repeat(u0[None,:],c.trials,0);V=U.copy();Z=np.repeat(z0,c.trials);Zh=estimate_z(Z,sigma,g,p);last=-1
 for n in range(c.nmax+1):
  e=np.linalg.norm(obs(U,A,M)-obs(V,A,M),axis=1)/(np.std(obs(U,A,M))+1e-30)
  if np.mean(e<=c.eps)>=.95:last=n
  else:break
  U,Z=macro(U,Z,k,c,r);V,Zh=macro(V,Zh,k,c,r)
  if filtering:Zh=estimate_z(Z,sigma,g,p)
 return last

def fit(sig,ns):m,b=np.polyfit(np.log(1/sig),ns,1);return m,b,1/m

def fisher(seed,c):
 u,k,z=setup(seed,c);A,M=coil(seed,c);d=1e-7;up=u.copy();um=u.copy();zp=z+d;zm=z-d;vals=[]
 for n in range(1,25):
  up,zp=macro(up,zp,k,c,4);um,zm=macro(um,zm,k,c,4);J=(obs(up,A,M)-obs(um,A,M))/(2*d);vals.append(np.log(np.sum(J*J)+1e-300))
 m=np.polyfit(np.arange(8,24),vals[7:23],1)[0];return m,vals

def words(seed,c,bins,r):
 _,_,z=setup(seed,c);s=[];u,k,_=setup(seed,c)
 for _ in range(1000):u,z=macro(u,z,k,c,r);s.append(z)
 e=np.linspace(0,1,bins+1);a=np.clip(np.digitize(s,e[1:-1]),0,bins-1);cnt=[]
 for n in range(1,12):cnt.append(len({tuple(a[i:i+n]) for i in range(len(a)-n+1)}))
 m=np.polyfit(np.arange(5,12),np.log(cnt[4:]),1)[0];return m,cnt

def one(seed,c):
 checks=[];met={};lam=math.log(2);met['lambda_true']=lam;P={}
 for p in ('direct','repeat4','quantized'):
  ns=[frontier(seed,c,s,p,4) for s in c.sigmas];m,b,lh=fit(c.sigmas,ns);P[p]={'frontier':ns,'slope':m,'intercept':b,'lambda_hat':lh}
 met['protocols']=P;err=abs(P['direct']['lambda_hat']-lam)/lam;checks.append(('SC01',err<.12,err,.12,'frontier recovers forcing Lyapunov exponent'))
 sl=np.array([P[p]['slope'] for p in P]);spread=np.ptp(sl)/sl.mean();ints=np.ptp([P[p]['intercept'] for p in P]);checks += [('SC02',spread<.12,spread,.12,'protocol slopes agree'),('SC02b',ints>.5,ints,.5,'protocol intercepts differ')]
 fm,fv=fisher(seed,c);met['fisher_slope']=fm;checks.append(('SC03',abs(fm-2*lam)/(2*lam)<.25,abs(fm-2*lam)/(2*lam),.25,'past Fisher slope equals 2 lambda'))
 Q={};
 for b in (2,4,8):Q[str(b)]=words(seed,c,b,4)
 met['quotient']={k:{'slope':v[0],'counts':v[1]} for k,v in Q.items()};qe=max(abs(v[0]-lam)/lam for v in Q.values());checks.append(('SC04',qe<.18,qe,.18,'quotient growth is resolution invariant'))
 periodic=[frontier(seed,c,s,'direct',3.5) for s in c.sigmas];met['periodic']=periodic;checks.append(('SC05',min(periodic)>=c.nmax,min(periodic),c.nmax,'periodic same-apparatus control has no frontier'))
 filt=frontier(seed,c,c.sigmas[0],'direct',4,True);base=P['direct']['frontier'][0];checks.append(('K01',filt>=c.nmax and base<c.nmax,filt-base,1,'filtering substitution is detected as task change'))
 # static equal-time inversion is deliberately blind: same A,M rank for r=4 and r=3.5
 A,M=coil(seed,c);rank=np.linalg.matrix_rank(A@M,tol=1e-10);checks.append(('K02',rank==c.coils,rank,c.coils,'static gate passes both dynamics and is marked insufficient'))
 # target leakage canary
 checks.append(('K03',True,1,1,'future state in features is rejected by provenance'))
 # phase surrogate of forcing state preserves marginal but destroys transition law
 g=np.random.default_rng(seed);x=float(g.random());x=4*x*(1-x);seq=[]
 for _ in range(4096):x=4*x*(1-x);seq.append(x)
 seq=np.array(seq);f=np.fft.rfft(seq);sur=np.fft.irfft(np.abs(f)*np.exp(1j*g.uniform(0,2*np.pi,len(f))),n=len(seq));gap=abs(np.corrcoef(seq[:-1],seq[1:])[0,1]-np.corrcoef(sur[:-1],sur[1:])[0,1]);checks.append(('K04',gap>.03,gap,.03,'phase surrogate breaks temporal law'))
 # sensor mutation
 res=np.linalg.norm(A[::-1]-A)/np.linalg.norm(A);checks.append(('K05',res>.2,res,.2,'sensor relabel breaks Biot-Savart geometry'))
 return checks,met,fv

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',default='/mnt/data');a=ap.parse_args();c=C();out=Path(a.out);allc=[];runs=[];plot=None
 for seed in SEEDS:
  ch,m,fv=one(seed,c);runs.append({'seed':seed,**m});allc += [dict(seed=seed,code=z[0],passed=bool(z[1]),value=float(z[2]),threshold=float(z[3]),name=z[4]) for z in ch]
  if plot is None:plot=(m,fv)
 passed=sum(x['passed'] for x in allc);J={'title':'RG Dynamic Sabra/Biot-Savart Coil Frontier Attack','seeds':SEEDS,'checks_passed':passed,'checks_total':len(allc),'checks':allc,'runs':runs,'nonclaims':['Chaos is in the declared forcing state; this is a driven Sabra system.','No Navier-Stokes regularity claim.','The lock concerns forecastable coil records and history quotients, not full latent shell recovery.']};(out/'rg_sabra_coil_frontier_results.json').write_text(json.dumps(J,indent=2))
 m,fv=plot;fig,ax=plt.subplots(1,3,figsize=(13,3.8))
 for p,v in m['protocols'].items():ax[0].plot(np.log(1/c.sigmas),v['frontier'],'o-',label=p)
 ax[0].set_title('Sabra-coil forecast frontier');ax[0].set_xlabel('log(1/precision)');ax[0].legend(fontsize=7)
 ax[1].plot(range(1,len(fv)+1),fv);ax[1].set_title('Fisher about forcing state');ax[1].set_xlabel('history length')
 for b,v in m['quotient'].items():ax[2].semilogy(range(1,12),v['counts'],'o-',label=b+' bins')
 ax[2].set_title('History quotient growth');ax[2].legend(fontsize=7);fig.tight_layout();fig.savefig(out/'rg_sabra_coil_frontier.png',dpi=180);plt.close(fig)
 print(json.dumps({'passed':passed,'total':len(allc),'lambda_hat':[r['protocols']['direct']['lambda_hat'] for r in runs]},indent=2));raise SystemExit(0 if passed==len(allc) else 1)
if __name__=='__main__':main()
