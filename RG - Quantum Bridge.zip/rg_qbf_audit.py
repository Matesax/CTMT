#!/usr/bin/env python3
"""
Independent audit (H01-H10) of the corrected Quantum Bridge: every key number recomputed with code that shares nothing
with rg_qm_bridge_final_checks.py.
  H01 cavity-mode stress from T^{mu nu} = d^mu phi d^nu phi - (1/2) eta^{mu nu} (d phi)^2 (normal-ordered single mode):
      components, both conservation laws, integrated energy omega n
  H02 squeezed contribution at x = L/12 is sinh^2 r - (sqrt3/2) sinh r cosh r < 0
  H03 PPT boundary of the dephased two-path state (v ~ 0.8558213033) and witness value at v = 0.99
  H04 Hoeffding/union shot count n = ceil(2 L^2/eps^2 log(30/alpha)) = 32206 with L = 1.0034447569
  H05 fourth-moment panel <n^2> = (2/15) sum_k <X^4_{k pi/5}> - <n> - 1/2 on random finite-support states
  H06 two-branch acceleration threshold d* ~ 2.99657e-8 m; d = 1e-6 m is ABOVE the resolution (CONDITIONAL)
  H07 Gaussian width sensitivity at 5 sigma and Jacobian condition numbers (1,2) vs (5,6) sigma
  H08 composition converse fails: O(+-1) equal, T = +-1, H = T^2 descends
  H09 two-level feedback fixed point g* = 0.2512624377, contraction lambda/Delta < 1
  H10 |1> vs thermal(nbar = 1): trace distance 3/4, equal (n, z), number variances 0 and 2
"""
import json, math, sys
import numpy as np
import sympy as sp
from scipy.optimize import brentq
from scipy.special import erf

R = []


def reg(i, ok, ev): R.append(dict(id=i, passed=bool(ok), evidence=ev)); print(f"[{'PASS' if ok else 'FAIL'}] {i} {json.dumps(ev)[:150]}")


def H01():
    t, x, w, L, A, n, zr, zi = sp.symbols("t x omega L A n zr zi", real=True)
    c2 = 1/(2*w); f = sp.sqrt(2/(A*L))*sp.sin(w*x); fp = sp.diff(f, x)
    zt_re = zr*sp.cos(2*w*t)+zi*sp.sin(2*w*t); zt_im = zi*sp.cos(2*w*t)-zr*sp.sin(2*w*t)   # z e^{-2i w t}
    pt2 = c2*f**2*w**2*(2*n-2*zt_re); px2 = c2*fp**2*(2*n+2*zt_re); ptx = 2*c2*f*fp*w*zt_im      # normal-ordered
    T00 = (pt2+px2)/2; T0x = -ptx; Txx = (pt2+px2)/2; Tyy = (pt2-px2)/2
    K = w/(A*L)
    ok = [sp.simplify(T00-K*(n+sp.cos(2*w*x)*zt_re)) == 0, sp.simplify(T0x+K*sp.sin(2*w*x)*zt_im) == 0,
          sp.simplify(Tyy+K*(n*sp.cos(2*w*x)+zt_re)) == 0,
          sp.simplify(sp.diff(T00, t)+sp.diff(T0x, x)) == 0, sp.simplify(sp.diff(T0x, t)+sp.diff(Txx, x)) == 0]
    E = sp.simplify(A*sp.integrate(T00.subs(w, sp.pi/L), (x, 0, L))); ok.append(sp.simplify(E-sp.pi/L*n) == 0)
    reg("H01", all(ok), dict(components_match=ok[:3], conservation=ok[3:5], integrated_energy_omega_n=ok[5]))


def H02():
    r = 0.6; v = math.sinh(r)**2-math.sqrt(3)/2*math.sinh(r)*math.cosh(r); reg("H02", v < 0, dict(value=v))


def bmv_state():
    G, hb = 6.67430e-11, 1.054571817e-34; M, dx, dmin, tt = 1e-14, 250e-6, 200e-6, 2.5
    x1 = (-(dmin/2+dx), -dmin/2); x2 = (dmin/2, dmin/2+dx)
    ph = {(i, j): G*M*M*tt/(hb*abs(x2[j]-x1[i])) for i in range(2) for j in range(2)}
    psi = np.array([np.exp(1j*ph[(i, j)]) for i in range(2) for j in range(2)])/2
    return psi, ph[(0, 0)]+ph[(1, 1)]-ph[(0, 1)]-ph[(1, 0)]


def dephase(rho, v):
    out = rho.copy()
    for a in range(4):
        for b in range(4):
            i, j, k, l = a//2, a % 2, b//2, b % 2; out[a, b] *= v**((i != k)+(j != l))
    return out


def ptB(rho):
    r4 = rho.reshape(2, 2, 2, 2); return r4.transpose(0, 3, 2, 1).reshape(4, 4)


def H03():
    psi, dphi = bmv_state(); rho = np.outer(psi, psi.conj())
    mineig = lambda v: np.linalg.eigvalsh(ptB(dephase(rho, v))).min()
    vstar = brentq(mineig, 0.5, 0.9999)
    w_, U = np.linalg.eigh(ptB(rho)); eta = U[:, 0]; W = ptB(np.outer(eta, eta.conj()))
    wval = float(np.real(np.trace(W@dephase(rho, 0.99))))
    reg("H03", abs(vstar-0.8558213033) < 1e-8 and abs(wval+0.0724051134) < 1e-8, dict(v_star=vstar, witness_v099=wval, dphi=dphi))
    return W


def H04(W):
    P = [np.eye(2), np.array([[0, 1], [1, 0]]), np.array([[0, -1j], [1j, 0]]), np.diag([1, -1])]
    coeff = np.array([[np.real(np.trace(W@np.kron(P[a], P[b])))/4 for b in range(4)] for a in range(4)])
    Lw = float(np.sum(np.abs(coeff))-abs(coeff[0, 0])); n = math.ceil(2*Lw**2/0.02**2*math.log(30/0.05))
    reg("H04", abs(Lw-1.0034447569) < 1e-8 and n == 32206, dict(L=Lw, shots_per_setting=n, total=9*n))


def H05():
    N = 40; a = np.diag(np.sqrt(np.arange(1, N)), 1); ad = a.T; nop = ad@a; rng = np.random.default_rng(7); worst = 0.0
    for _ in range(30):
        A = rng.normal(size=(10, 10))+1j*rng.normal(size=(10, 10)); r10 = A@A.conj().T; r10 /= np.trace(r10).real
        rho = np.zeros((N, N), complex); rho[:10, :10] = r10
        X4 = lambda th: (lambda X: np.real(np.trace(rho@X@X@X@X)))((a*np.exp(-1j*th)+ad*np.exp(1j*th))/math.sqrt(2))
        nn = np.real(np.trace(rho@nop)); n2 = np.real(np.trace(rho@nop@nop))
        est = 2/15*sum(X4(k*np.pi/5) for k in range(5))-nn-0.5; worst = max(worst, abs(est-n2))
    reg("H05", worst < 1e-10, dict(max_error=worst))


def H06():
    G, M, Rr, tau = 6.67430e-11, 1.0, 0.1, 1e-15
    s = lambda d: G*M*d/(2*(Rr**2+d**2/4)**1.5); dstar = brentq(lambda d: s(d)-tau, 1e-12, 1e-3)
    reg("H06", abs(dstar-2.99657e-8)/2.99657e-8 < 1e-5 and s(1e-6) > tau and s(1e-9) < tau,
        dict(d_star=dstar, s_1um=s(1e-6), s_1nm=s(1e-9), status_1um="CONDITIONAL", status_1nm="FORCED"))


def H07():
    Phi = lambda r, M, s: -M*erf(r/(math.sqrt(2)*s))/r
    def J(rs, M=1.0, s=1.0, h=1e-6):
        rows = []
        for r in rs:
            f0 = math.log(abs(Phi(r*s, M, s)))
            dM = (math.log(abs(Phi(r*s, M*math.exp(h), s)))-f0)/h
            ds = (math.log(abs(Phi(r*s, M, s*math.exp(h))))-f0)/h      # radius held fixed in absolute units
            rows.append([dM, ds])
        return np.array(rows)
    def Jfix(rs, h=1e-7):
        rows = []
        for r in rs:
            g = lambda lm, ls: math.log(abs(Phi(r, math.exp(lm), math.exp(ls))))
            rows.append([(g(h, 0)-g(-h, 0))/(2*h), (g(0, h)-g(0, -h))/(2*h)])
        return np.array(rows)
    # analytic sensitivity (first audit used a central difference of log Phi near erf ~ 1: cancellation, 9e-5 relative error)
    sens5 = -5*math.sqrt(2/math.pi)*math.exp(-12.5)/erf(5/math.sqrt(2)); c12 = np.linalg.cond(Jfix([1.0, 2.0])); c56 = np.linalg.cond(Jfix([5.0, 6.0]))
    reg("H07", abs(sens5+1.4867203671e-5) < 1e-9 and abs(c12-5.095) < 0.01 and abs(c56/1.352e5-1) < 0.01,
        dict(dlogPhi_dlogsigma_5sigma=sens5, cond_12=c12, cond_56=c56))


def H08():
    O = {-1: 0, 1: 0}; T = {-1: -1, 1: 1}; H = {k: T[k]**2 for k in T}
    T_descends = all(T[a] == T[b] for a in O for b in O if O[a] == O[b]); H_descends = all(H[a] == H[b] for a in O for b in O if O[a] == O[b])
    reg("H08", (not T_descends) and H_descends, dict(T_descends=T_descends, H_descends=H_descends))


def H09():
    D, b, lam = 1.0, 0.3, 0.2; F = lambda g: b-lam*g/math.sqrt(D**2+g**2); g = 0.0
    for _ in range(200): g = F(g)
    reg("H09", abs(g-0.2512624377) < 1e-9 and lam/D < 1, dict(g_star=g, t=-g/math.sqrt(D**2+g**2), residual=abs(F(g)-g)))


def H10():
    p = np.array([2.0**-(k+1) for k in range(60)]); f1 = np.zeros(60); f1[1] = 1
    td = 0.5*np.sum(np.abs(f1-p)); k = np.arange(60); var_th = float(np.sum(p*k**2)-np.sum(p*k)**2)
    reg("H10", abs(td-0.75) < 1e-12 and abs(var_th-2) < 1e-9, dict(trace_distance=td, var_fock=0.0, var_thermal=var_th))


H01(); H02(); W = H03(); H04(W); H05(); H06(); H07(); H08(); H09(); H10()
n = sum(r["passed"] for r in R); json.dump(dict(n_checks=len(R), n_pass=n, results=R), open("rg_qbf_audit_results.json", "w"), indent=2, default=str)
print(f"\n{n}/{len(R)} independent audit checks pass."); sys.exit(0 if n == len(R) else 1)
