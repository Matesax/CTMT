#!/usr/bin/env python3
"""Replay saved bridge records without generating samples or solving fixed points."""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
from scipy.stats import chi2

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--results',default='rg_qm_bridge_final_results.json');args=ap.parse_args();p=Path(args.results);r=json.loads(p.read_text());root=p.parent
 assert hashlib.sha256((root/'rg_qm_bridge_final_checks.py').read_bytes()).hexdigest()==r['script_sha256']
 raw=root/r['raw_file'];assert hashlib.sha256(raw.read_bytes()).hexdigest()==r['raw_sha256'];a=np.load(raw);e={row['id']:row['evidence'] for row in r['results']}
 x=a['position_samples'];S=np.sum(x*x);sig=np.sqrt(S/x.size);ci=[np.sqrt(S/chi2.ppf(.975,x.size)),np.sqrt(S/chi2.ppf(.025,x.size))]
 assert abs(sig-e['F10']['sigma_hat'])<1e-14 and np.allclose(ci,e['F10']['sigma_95_interval'],rtol=1e-13)
 counts=a['pauli_setting_counts'];coeff=a['witness_coefficients'];est={(0,0):1.};outcomes=np.array([[1,1],[1,-1],[-1,1],[-1,-1]])
 for k,(i,j) in enumerate(( (i,j) for i in range(1,4) for j in range(1,4))):
  f=counts[k]/counts[k].sum();est[i,j]=f@(outcomes[:,0]*outcomes[:,1])
  if j==1:est[i,0]=f@outcomes[:,0]
  if i==1:est[0,j]=f@outcomes[:,1]
 what=sum(coeff[i,j]*est[i,j] for i in range(4) for j in range(4));assert abs(what-e['F23']['witness_estimate'])<1e-14
 rr=a['radial_r'];u=a['radial_u'];phi=a['radial_phi'];h=rr[1]-rr[0];Hu=(1/h**2+rr*rr/2+.2*phi)*u;Hu[:-1]-=.5/h**2*u[1:];Hu[1:]-=.5/h**2*u[:-1];energy=float(u@Hu*h);res=float(np.sqrt(np.sum((Hu-energy*u)**2)*h))
 assert abs(energy-e['F11']['fine']['energy'])<1e-10 and res<1e-7
 assert r['n_checks']==24 and r['n_pass']==24 and all(c['baseline_passed'] and c['caught'] for c in r['mutation_controls'])
 out=dict(all_pass=True,source_and_raw_hashes_verified=True,sigma_hat=float(sig),witness_estimate=float(what),radial_energy=energy,radial_residual=res,records='saved synthetic observations and numerical profile; no regeneration')
 (root/'rg_qm_bridge_verification.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if __name__=='__main__':main()
