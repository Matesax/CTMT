#!/usr/bin/env python3
"""
RG quantum bridge: battery QB01-QB10
====================================
The bridge is a composition of links, each with its own RG status:
  quantum observation law (contexts) -> quantum-source descent (<T>) -> coupling declaration -> geometric route -> geometry
A composite is LOCKED only if every link is (Composition Theorem, QB05); otherwise the status of the weakest link.

  QB01 quantum-source descent: a field mode's energy density at every phase depends only on second moments; three
       homodyne variances are the minimal panel; |1> and the thermal state (nbar = 1) give the same <T> but are different
       states, and differ in stress FLUCTUATIONS (fourth moments)
  QB02 quantum sources violate pointwise energy conditions: squeezed vacuum has negative renormalized energy density at
       some phases while its period average is nonnegative -> energy conditions are declarations of the coupling layer
  QB03 Casimir: one measured component (the force, T^zz) plus declared symmetries (boosts parallel to plates,
       conformal tracelessness) locks the full tensor diag(-1,1,1,-3) pi^2/(720 a^4); without tracelessness: a family
  QB04 contextual stress: global kinetic stress is identified by the momentum context alone; LOCAL kinetic energy density
       needs a declared ordering (two standard densities differ by (hbar^2/4m) rho'', with equal integrals)
  QB05 composition theorem: kernel inclusion composes; an unidentified coupling makes the composite a correspondence
  QB06 geometry walks the bridge: Gaussian ground-state density -> Poisson potential -> weak-field metric -> linearized
       Einstein tensor returns the density exactly (first order); walking back from the exterior field identifies m only:
       the quantum width is behind a STRUCTURAL WALL (Newton shell theorem, e^{-r^2/2 sigma^2})
  QB07 coupling robustness: for a mass in superposition, semiclassical (mean) and outcome-conditioned couplings give the
       SAME mean geometry for every linear observable; they differ only in fluctuations -> coupling FORCED for first
       moments, CONDITIONAL for second moments (Page-Geilker tested the latter)
  QB08 the open plank: gravitationally induced entanglement (BMV) separates quantum from classical (LOCC) coupling;
       concurrence computed for the published parameters; LOCC gives zero
  QB09 resolution walls on the bridge: gravity of Casimir energy, exterior signature of the quantum width
  QB10 bridge status table

Run:  python3 rg_qm_bridge_attack.py [--seed 20261026] [--out FILE] [--figs DIR] [--canary]
"""
import argparse, json, math, sys, time, itertools
import numpy as np
import sympy as sp
from scipy.linalg import expm

RESULTS, MUT = [], {}
HBAR, G_N, C_L = 1.054571817e-34, 6.67430e-11, 299792458.0


def f_(x):
    """12 significant figures (rounding to decimal places erased tiny physical magnitudes such as the Casimir energy)."""
    x = float(x); return float(f"{x:.12g}") if np.isfinite(x) else x


def register(aid, naive, keep, passed, ev, verdict):
    RESULTS.append(dict(id=aid, naive_claim=naive, rg_claim=keep, passed=bool(passed), verdict=verdict, evidence=ev))
    print(f"[{'PASS' if passed else 'FAIL'}] {aid} {verdict:16s} {keep[:84]}")


N = 40
a_op = np.diag(np.sqrt(np.arange(1, N)), 1); ad = a_op.conj().T


def ev(rho, O): return complex(np.trace(rho@O))


def nT00(rho, th):
    """renormalized (normal-ordered) energy density of a single mode at phase th, in units of the mode constant."""
    X = (a_op*np.exp(-1j*th)+ad*np.exp(1j*th))/math.sqrt(2)
    return float(np.real(ev(rho, X@X)))-0.5


def QB01(rng):
    ths = np.linspace(0, np.pi, 25)
    fock1 = np.zeros((N, N)); fock1[1, 1] = 1.0
    nbar = 1.0; p = np.array([(nbar/(1+nbar))**k/(1+nbar) for k in range(N)]); thermal = np.diag(p/p.sum())
    same_T = max(abs(nT00(fock1, t)-nT00(thermal, t)) for t in ths)
    trace_dist = 0.5*np.sum(np.abs(np.linalg.eigvalsh(fock1-thermal)))
    nop = ad@a_op; var_n = lambda rho: float(np.real(ev(rho, nop@nop)-ev(rho, nop)**2))
    fluct = (var_n(fock1), var_n(thermal))
    # minimal panel: three homodyne variances reconstruct <:X_theta^2:> at every phase, for random states
    worst = 0.0
    for _ in range(40):
        A = rng.normal(size=(8, 8))+1j*rng.normal(size=(8, 8)); r8 = A@A.conj().T; r8 /= np.trace(r8).real
        rho = np.zeros((N, N), complex); rho[:8, :8] = r8
        v0, v4, v2 = nT00(rho, 0), nT00(rho, np.pi/4), nT00(rho, np.pi/2)
        n_ = (v0+v2)/2; ReA = (v0-v2)/2; ImA = v4-n_
        for t in ths:
            pred = n_+ReA*math.cos(2*t)+ImA*math.sin(2*t); worst = max(worst, abs(pred-nT00(rho, t)))
    if MUT.get("qb01_energy_identifies_state"): trace_dist = 0.0
    passed = same_T < 1e-10 and trace_dist > 0.3 and worst < 1e-10 and abs(fluct[0]-fluct[1]) > 1
    register("QB01", "Measuring the quantum source's energy identifies its quantum state (or needs full tomography).",
             "Neither: the energy density at every phase depends only on second moments, and three homodyne variances "
             "reconstruct it exactly (error < 1e-10 on random states). |1> and the nbar = 1 thermal state give identical <T> "
             "but are different states (trace distance > 0.3); they differ in stress FLUCTUATIONS (Var n = 0 vs 2), a "
             "fourth-moment task needing a larger panel.", passed,
             dict(max_T_difference=f_(same_T), trace_distance=f_(trace_dist), panel_reconstruction_error=f_(worst),
                  number_variance=[f_(fluct[0]), f_(fluct[1])]), "FALSIFIED-naive")


def QB02(rng):
    r = 0.6; K = r*(a_op@a_op-ad@ad)/2; S = expm(K); vac = np.zeros(N); vac[0] = 1; psi = S@vac; rho = np.outer(psi, psi.conj())
    # half-open grid: a periodic average over a closed grid double-counts the endpoint (first version: bias 1.05e-3)
    ths = np.linspace(0, np.pi, 720, endpoint=False); vals = np.array([nT00(rho, t) for t in ths])
    analytic_min = math.sinh(r)**2-math.sinh(r)*math.cosh(r); avg = float(np.mean(vals))
    coh = np.zeros(N, complex); alpha = 1.2
    for k in range(N): coh[k] = math.exp(-abs(alpha)**2/2)*alpha**k/math.sqrt(math.factorial(k))
    rc = np.outer(coh, coh.conj()); cmin = min(nT00(rc, t) for t in ths)
    passed = vals.min() < -0.1 and abs(vals.min()-analytic_min) < 1e-3 and abs(avg-math.sinh(r)**2) < 1e-3 and cmin > -1e-9
    register("QB02", "Quantum sources obey the classical energy conditions the geometric theorems assume.",
             "They do not pointwise: the squeezed vacuum (r = 0.6) has negative renormalized energy density at some phases "
             "(minimum sinh^2 r - sinh r cosh r, matched), while its period average is sinh^2 r >= 0; a coherent (classical-like) "
             "state never goes negative. Energy conditions belong to the coupling layer and must be declared.", passed,
             dict(min_energy_density=f_(vals.min()), analytic_min=f_(analytic_min), period_average=f_(avg),
                  coherent_state_min=f_(cmin)), "FALSIFIED-naive")


def QB03(rng):
    A, B, a = sp.symbols("A B a", real=True)
    T = sp.diag(-A, A, A, B)                                       # boost invariance parallel to plates: A eta on (t,x,y)
    eta = sp.diag(-1, 1, 1, 1); trace = sp.simplify(sum(eta[i, i]*T[i, i] for i in range(4)))
    Bmeas = -sp.pi**2/(240*a**4)                                     # measured: Casimir pressure (hbar = c = 1)
    solA = sp.solve(sp.Eq(trace, 0).subs(B, Bmeas), A)[0]
    Tfull = T.subs({A: solA, B: Bmeas}); target = sp.pi**2/(720*a**4)*sp.diag(-1, 1, 1, -3)
    ok = sp.simplify(Tfull-target) == sp.zeros(4, 4)
    family = sp.simplify(T.subs(B, Bmeas))                          # without tracelessness: A free
    # gravitational mass-energy of Casimir energy for A = 1 cm^2, a = 1 um (SI)
    E = -math.pi**2*HBAR*C_L*1e-4/(720*(1e-6)**3); dm = E/C_L**2
    passed = ok and family.free_symbols >= {A}
    register("QB03", "A quantum vacuum stress cannot be identified from experiment.",
             "Casimir: the force measures one component (T^zz = -pi^2/(240 a^4)); declared symmetries (boosts parallel to the "
             "plates; conformal tracelessness) then lock the full tensor pi^2/(720 a^4) diag(-1, 1, 1, -3), with negative "
             "energy density. Without tracelessness the other components form a one-parameter family: the declaration is "
             "doing work and is named. (Force measurements agree with theory at the percent level in the literature.)",
             passed, dict(full_tensor_locked=bool(ok), free_without_traceless=str(sorted(map(str, family.free_symbols))),
                          casimir_energy_J=f_(E), mass_equivalent_kg=f_(dm)), "FALSIFIED-naive")


def QB04(rng):
    x, s, hb, m = sp.symbols("x sigma hbar m", positive=True)
    psi = (2*sp.pi*s**2)**sp.Rational(-1, 4)*sp.exp(-x**2/(4*s**2)); rho = psi**2
    t1 = hb**2/(2*m)*sp.diff(psi, x)**2; t2 = -hb**2/(2*m)*psi*sp.diff(psi, x, 2)
    diff = sp.simplify(t1-t2-hb**2/(4*m)*sp.diff(rho, x, 2))
    I1 = sp.simplify(sp.integrate(t1, (x, -sp.oo, sp.oo))); I2 = sp.simplify(sp.integrate(t2, (x, -sp.oo, sp.oo)))
    momentum = sp.simplify(hb**2/(8*m*s**2))                         # <p^2>/2m for the Gaussian
    local_differs = sp.simplify((t1-t2).subs({x: 0})) != 0
    passed = diff == 0 and sp.simplify(I1-I2) == 0 and sp.simplify(I1-momentum) == 0 and local_differs
    register("QB04", "A quantum source has one well-defined local stress tensor read from one experiment.",
             "Position and momentum are incompatible contexts (no joint law, Fine): the GLOBAL kinetic stress <p^2>/2m is "
             "identified by the momentum context alone, but the LOCAL kinetic energy density needs a declared ordering -- two "
             "standard densities differ exactly by (hbar^2/4m) rho'' and integrate to the same total. Local quantum stress is a "
             "CORRESPONDENCE, global stress is LOCKED.", passed,
             dict(difference_identity=str(diff), integrals_equal=bool(sp.simplify(I1-I2) == 0), global_value=str(I1)), "FALSIFIED-naive")


def QB05(rng):
    """finite exhaustive check of the composition theorem."""
    ok, cases, counter = 0, 0, None
    for _ in range(3000):
        n = 5; O = rng.integers(0, 3, n); T = rng.integers(0, 3, n); c = {k: int(rng.integers(0, 3)) for k in range(3)}
        KO = {(i, j) for i in range(n) for j in range(n) if O[i] == O[j]}; KT = {(i, j) for i in range(n) for j in range(n) if T[i] == T[j]}
        if KO <= KT:
            cases += 1; Kc = {(i, j) for i in range(n) for j in range(n) if c[T[i]] == c[T[j]]}; ok += KO <= Kc
    # unidentified coupling: two admissible couplings that differ on the source values -> composite correspondence
    O = np.array([0, 0, 1]); T = np.array([0, 0, 1]); c1 = {0: 0, 1: 1}; c2 = {0: 1, 1: 1}
    geo1 = [c1[t] for t in T]; geo2 = [c2[t] for t in T]; corr = any(g1 != g2 for g1, g2 in zip(geo1, geo2))
    passed = ok == cases and cases > 100 and corr
    register("QB05", "If both endpoints are certified, the bridge is certified.",
             "The Composition Theorem: if K_O <= K_T (source identified) and the coupling is a FIXED map, then K_O <= K_{c o T} "
             "(composite identified) -- verified exhaustively on random finite systems. If the coupling is only declared up to "
             "a class whose members differ on the source values, the composite is a CORRESPONDENCE even with both endpoints "
             "certified. The bridge needs its own link certified.", passed,
             dict(inclusion_cases=cases, composite_inherits=ok, unidentified_coupling_gives_correspondence=bool(corr)), "FALSIFIED-naive")


def einstein_mixed(g, X):
    n = len(X); gi = g.inv()
    Gam = [[[sum(gi[a, d]*(sp.diff(g[d, b], X[c])+sp.diff(g[d, c], X[b])-sp.diff(g[b, c], X[d])) for d in range(n))/2
             for c in range(n)] for b in range(n)] for a in range(n)]
    def Riem(a, b, c, d):
        return sp.diff(Gam[a][b][d], X[c])-sp.diff(Gam[a][b][c], X[d])+sum(Gam[a][c][e]*Gam[e][b][d]-Gam[a][d][e]*Gam[e][b][c] for e in range(n))
    Ric = sp.Matrix(n, n, lambda b, d: sum(Riem(a, b, a, d) for a in range(n)))
    R = sum(gi[a, b]*Ric[a, b] for a in range(n) for b in range(n))
    return gi*(Ric-R*g/2)


def QB06(rng):
    t, r, th, ph, e = sp.symbols("t r theta phi epsilon", positive=True); Phi = sp.Function("Phi")(r)
    g = sp.diag(-(1+2*e*Phi), (1-2*e*Phi), (1-2*e*Phi)*r**2, (1-2*e*Phi)*r**2*sp.sin(th)**2)
    G = einstein_mixed(g, [t, r, th, ph]); Gtt1 = sp.simplify(sp.diff(G[0, 0], e).subs(e, 0))
    lap = sp.diff(Phi, r, 2)+2*sp.diff(Phi, r)/r; first_order = sp.simplify(Gtt1+2*lap) == 0          # G^t_t = -2 eps lap Phi
    m, s = sp.symbols("m sigma", positive=True)
    rho = m*(2*sp.pi*s**2)**sp.Rational(-3, 2)*sp.exp(-r**2/(2*s**2)); PhiG = -m*sp.erf(r/(sp.sqrt(2)*s))/r
    poisson = sp.simplify(sp.diff(PhiG, r, 2)+2*sp.diff(PhiG, r)/r-4*sp.pi*rho) == 0
    walk = sp.simplify(-2*(sp.diff(PhiG, r, 2)+2*sp.diff(PhiG, r)/r)/(-8*sp.pi)-rho) == 0          # geometric route returns rho
    # walking back from outside: d Phi/d sigma relative to Phi at r = 5 sigma (shell theorem wall)
    rel = float(sp.N((sp.diff(PhiG, s)*s/PhiG).subs({r: 5*s, m: 1, s: 1})))
    # quantum observation: sample positions from |psi|^2, estimate sigma, propagate to Phi(r = sigma)
    sig_true = 1.0; xs = rng.normal(0, sig_true, (20000, 3)); sig_hat = float(np.sqrt(np.mean(xs**2)))
    Phi_num = lambda sg, rr: -math.erf(rr/(math.sqrt(2)*sg))/rr
    rel_err = abs(Phi_num(sig_hat, 1.0)-Phi_num(sig_true, 1.0))/abs(Phi_num(sig_true, 1.0))
    passed = first_order and poisson and walk and abs(rel) < 1e-4 and rel_err < 0.01
    register("QB06", "Geometry cannot walk from a quantum state to curvature and back.",
             "It walks forward exactly: a ground-state density (identified from position statistics, sigma to 0.2%) gives the "
             "Poisson potential, the weak-field metric, and the linearized Einstein tensor G^t_t = -2 eps lap Phi, which returns "
             "the density exactly (semiclassical coupling declared). Walking back from the EXTERIOR field identifies m only: "
             "the quantum width enters as e^{-r^2/2 sigma^2} (relative 1e-5 at 5 sigma) -- a STRUCTURAL WALL (shell theorem).",
             passed, dict(linearized_einstein_ok=bool(first_order), poisson_ok=bool(poisson), geometric_route_returns_density=bool(walk),
                          exterior_sigma_sensitivity_at_5sigma=f_(rel), sigma_hat=f_(sig_hat), potential_rel_error=f_(rel_err)),
             "FALSIFIED-naive")


def QB07(rng):
    m, R = 1.0, 0.1                                                   # kg, m (test mass 10 cm away on the y axis)
    rows = []
    for d in (1e-1, 1e-3, 1e-6, 1e-9):
        def ax(xm): v = np.array([xm, 0, 0])-np.array([0, R, 0]); return G_N*m*v[0]/np.linalg.norm(v)**3
        aL, aR = ax(-d/2), ax(d/2); semi = 0.5*aL+0.5*aR; outcome_mean = 0.5*aL+0.5*aR
        outcome_sd = abs(aL-aR)/2
        rows.append(dict(d=d, mean_difference=f_(abs(semi-outcome_mean)), outcome_sd=f_(outcome_sd)))
    tau = 1e-15                                                       # declared acceleration resolution (m/s^2)
    status = {str(rw["d"]): ("FORCED" if rw["outcome_sd"] < tau else "CONDITIONAL") for rw in rows}
    if MUT.get("qb07_claim_identical"): rows[0]["outcome_sd"] = 0.0
    passed = all(rw["mean_difference"] < 1e-25 for rw in rows) and rows[0]["outcome_sd"] > tau and rows[-1]["outcome_sd"] < tau
    register("QB07", "Semiclassical gravity is either right or wrong for all observations.",
             "Coupling is a declared class with a robustness certificate: for a mass in a superposition of separation d, the "
             "semiclassical (mean) and outcome-conditioned couplings predict the SAME mean acceleration for every linear "
             "observable (difference 0), and differ only in fluctuations (sd ~ G m d / R^3). At a declared resolution the "
             "coupling is FORCED for small d and CONDITIONAL for macroscopic d -- the regime Page and Geilker tested.",
             passed, dict(rows=rows, declared_resolution=tau, status_by_separation=status), "FALSIFIED-naive")


def QB08(rng):
    m, dx, d, tt = 1e-14, 250e-6, 200e-6, 2.5                        # BMV-style parameters
    xs1 = (-(d/2+dx), -d/2); xs2 = (d/2, d/2+dx)
    ph = {(i, j): G_N*m*m*tt/(HBAR*abs(xs2[j]-xs1[i])) for i in range(2) for j in range(2)}
    dphi = ph[(0, 0)]+ph[(1, 1)]-ph[(0, 1)]-ph[(1, 0)]
    psi = np.array([np.exp(1j*ph[(i, j)]) for i in range(2) for j in range(2)])/2
    Y = np.array([[0, -1j], [1j, 0]]); YY = np.kron(Y, Y); conc = abs(psi.conj()@YY@psi.conj())
    # classical (LOCC) channel: product phases only -> product state -> concurrence 0
    pc = np.kron(np.array([np.exp(1j*0.3), np.exp(1j*1.1)])/math.sqrt(2), np.array([np.exp(1j*0.7), np.exp(1j*0.2)])/math.sqrt(2))
    conc_locc = abs(pc.conj()@YY@pc.conj())
    passed = conc > 0.05 and conc_locc < 1e-12 and abs(conc-abs(math.sin(dphi/2))) < 1e-9
    register("QB08", "Whether gravity couples quantum mechanically can never be put to an RG test.",
             "It is the bridge's open plank, with its test computed: gravitationally induced entanglement between two masses "
             "in superposition gives concurrence |sin(dphi/2)| for BMV-style parameters, while any classical (LOCC) coupling "
             "gives zero. Status now: CORRESPONDENCE between coupling classes; the experiment that would lock it is specified.",
             passed, dict(phase_difference_rad=f_(dphi), concurrence=f_(conc), locc_concurrence=f_(conc_locc)), "FALSIFIED-naive")


def QB09(rng):
    E = -math.pi**2*HBAR*C_L*1e-4/(720*(1e-6)**3); dm = abs(E)/C_L**2; acc = G_N*dm/0.01**2
    walls = [dict(effect="gravity of Casimir energy (1 cm^2, 1 um gap) at 1 cm", acceleration=f_(acc), resolution=1e-15,
                  status="STRUCTURAL WALL" if acc < 1e-15 else "DETECTABLE", orders_below=f_(math.log10(1e-15/acc))),
             dict(effect="exterior signature of a ground-state width at 5 sigma", relative=1e-5, status="STRUCTURAL WALL[tau] unless tau < 1e-5"),
             dict(effect="BMV entanglement (QB08)", status="within reach of the proposed experiment; CORRESPONDENCE until performed")]
    passed = acc < 1e-30
    register("QB09", "If the bridge is sound, every plank is observable.",
             "Soundness and observability differ: the gravity of Casimir energy is about 22 orders below current acceleration "
             "resolution, and a quantum width is invisible in the exterior field. RG types each plank DETECTED, CORRESPONDENCE "
             "or STRUCTURAL WALL[tau].", passed, dict(walls=walls), "FALSIFIED-naive")


def QB10(rng):
    links = [
        dict(link="quantum observation law (contexts)", status="LOCKED", basis="product law over contexts (L43; Fine)"),
        dict(link="quantum-source descent <T>", status="LOCKED (second moments); CORRESPONDENCE (local ordering)", basis="QB01, QB03, QB04"),
        dict(link="coupling declaration", status="FORCED for first moments; CONDITIONAL for fluctuations; CORRESPONDENCE quantum vs classical",
             basis="QB07, QB08"),
        dict(link="geometric route", status="LOCKED (conditional: Einstein equation, C^2)", basis="QB06; Stress Tensor paper"),
        dict(link="geometry observation back to source", status="m LOCKED; width STRUCTURAL WALL", basis="QB06, QB09"),
    ]
    composite = "LOCKED (conditional) for mean geometry of second-moment-identified sources; CONDITIONAL/CORRESPONDENCE beyond"
    if MUT.get("qb10_lock_everything"): composite = "LOCKED"
    passed = composite != "LOCKED" and any("CORRESPONDENCE" in l_["status"] for l_ in links)
    register("QB10", "The QM-GR bridge is either fully closed or absent.",
             "By the Composition Theorem its status is that of its weakest link: the composite is LOCKED (conditional) for the "
             "mean geometry of sources identified by second moments; fluctuation-sensitive geometry is CONDITIONAL on the "
             "coupling class; quantum versus classical coupling is a CORRESPONDENCE until an entanglement experiment.",
             passed, dict(links=links, composite=composite), "FALSIFIED-naive")


ATTACKS = [QB01, QB02, QB03, QB04, QB05, QB06, QB07, QB08, QB09, QB10]


def make_figures(d):
    import os, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    os.makedirs(d, exist_ok=True); fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    r = 0.6; K = r*(a_op@a_op-ad@ad)/2; S = expm(K); vac = np.zeros(N); vac[0] = 1; psi = S@vac; rho = np.outer(psi, psi.conj())
    ths = np.linspace(0, 2*np.pi, 400)
    ax[0].plot(ths, [nT00(rho, t) for t in ths], label="squeezed vacuum (r = 0.6)")
    coh = np.zeros(N, complex)
    for k in range(N): coh[k] = math.exp(-1.2**2/2)*1.2**k/math.sqrt(math.factorial(k))
    ax[0].plot(ths, [nT00(np.outer(coh, coh.conj()), t) for t in ths], label="coherent state")
    ax[0].axhline(0, color="k", lw=0.6); ax[0].set_xlabel("phase"); ax[0].set_ylabel("renormalized energy density")
    ax[0].legend(fontsize=7); ax[0].set_title("quantum source: negative energy density at some phases", fontsize=9)
    dd = np.logspace(-10, -1, 50); R = 0.1
    sd = [abs(G_N*(-x/2)/np.hypot(x/2, R)**3-G_N*(x/2)/np.hypot(x/2, R)**3)/2 for x in dd]
    ax[1].loglog(dd, sd, label="outcome-conditioned spread")
    ax[1].axhline(1e-15, color="r", ls="--", label="declared resolution")
    ax[1].set_xlabel("superposition separation d (m)"); ax[1].set_ylabel("acceleration spread (m/s$^2$)")
    ax[1].set_title("coupling FORCED (below line) vs CONDITIONAL (above)", fontsize=9); ax[1].legend(fontsize=7)
    fig.tight_layout(); fig.savefig(f"{d}/qb_bridge.png", dpi=170); plt.close(fig)


def run_all(seed):
    for a in ATTACKS:
        rng = np.random.default_rng([seed, ATTACKS.index(a)])
        try: a(rng)
        except Exception as ex:
            import traceback; traceback.print_exc(); register(a.__name__, "?", f"EXCEPTION {ex!r}", False, {}, "ERROR")


def canary(seed):
    ok = True
    for tgt, m in (("QB01", {"qb01_energy_identifies_state": True}), ("QB07", {"qb07_claim_identical": True}), ("QB10", {"qb10_lock_everything": True})):
        RESULTS.clear(); MUT.clear(); MUT.update(m); print(f"--- canary {tgt}: {m}")
        a = next(x for x in ATTACKS if x.__name__ == tgt); a(np.random.default_rng([seed, ATTACKS.index(a)]))
        c = not RESULTS[-1]["passed"]; ok &= c; print(f"    {'CAUGHT' if c else 'NOT CAUGHT'}")
    MUT.clear(); print("CANARY:", "all caught" if ok else "BATTERY TOO WEAK"); return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--seed", type=int, default=20261026)
    ap.add_argument("--out", default="rg_qm_bridge_results.json"); ap.add_argument("--figs", default=""); ap.add_argument("--canary", action="store_true")
    a = ap.parse_args()
    if a.canary: sys.exit(canary(a.seed))
    t0 = time.time(); print(f"RG quantum bridge battery, seed {a.seed}\n"); run_all(a.seed)
    if a.figs: make_figures(a.figs)
    n = sum(r["passed"] for r in RESULTS)
    json.dump(dict(summary=dict(seed=a.seed, n_checks=len(RESULTS), n_pass=n, runtime_s=round(time.time()-t0, 1)), results=RESULTS),
              open(a.out, "w"), indent=2, default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print(f"\n{n}/{len(RESULTS)} pass."); sys.exit(0 if n == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
