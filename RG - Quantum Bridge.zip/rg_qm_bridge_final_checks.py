#!/usr/bin/env python3
"""Final conditional RG-QM bridge. Analytic and synthetic witnesses, not empirical data.
Run: python rg_qm_bridge_final_checks.py --out rg_qm_bridge_final_results.json
Requires numpy, scipy, sympy. No network or original source modifications.
"""
import argparse, json, math, hashlib
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.integrate import cumulative_trapezoid
from scipy.linalg import eigh_tridiagonal
from scipy.special import erf
from scipy.optimize import brentq
G=6.67430e-11;HB=1.054571817e-34;C=299792458.
def partial_transpose(r):return r.reshape(2,2,2,2).transpose(0,3,2,1).reshape(4,4)
def state_bmv(visibility=1.):
 m=1e-14;dx=250e-6;d=200e-6;t=2.5
 x1=np.array([-d/2-dx,-d/2]);x2=np.array([d/2,d/2+dx]);phase=G*m*m*t/(HB*abs(x1[:,None]-x2[None,:]))
 psi=np.exp(1j*phase).reshape(4)/2;rho=np.outer(psi,psi.conj());bits=[(0,0),(0,1),(1,0),(1,1)]
 for i in range(4):
  for j in range(4):rho[i,j]*=visibility**sum(a!=b for a,b in zip(bits[i],bits[j]))
 return rho,float(phase[0,0]+phase[1,1]-phase[0,1]-phase[1,0])
def phi_gaussian(r,s,m=1.):return -m*erf(r/(math.sqrt(2)*s))/r
def sensitivity(r,s):return -math.sqrt(2/math.pi)*(r/s)*math.exp(-r*r/(2*s*s))/erf(r/(math.sqrt(2)*s))
def radial_potential(r,u):
 mass=cumulative_trapezoid(u*u,r,initial=0);outer=cumulative_trapezoid(u*u/r,r,initial=0)
 return -(mass/r+outer[-1]-outer)
def solve_sp(n=800,lam=.2,return_profile=False):
 # Dimensionless trapped Schrodinger-Poisson model, u(0)=u(R)=0.
 R=8.;h=R/(n+1);r=h*np.arange(1,n+1);u=r*np.exp(-r*r/2);u/=math.sqrt(np.sum(u*u)*h)
 for it in range(1000):
  phi=radial_potential(r,u);diag=1/h**2+r*r/2+lam*phi
  e,v=eigh_tridiagonal(diag,np.full(n-1,-.5/h**2),select='i',select_range=(0,0));v=v[:,0];v*=np.sign(np.dot(v,u));v/=math.sqrt(np.sum(v*v)*h)
  diff=math.sqrt(np.sum((v-u)**2)*h)
  if diff<1e-11:u=v;break
  u=.6*u+.4*v;u/=math.sqrt(np.sum(u*u)*h)
 phi=radial_potential(r,u);diag=1/h**2+r*r/2+lam*phi;Hu=diag*u;Hu[:-1]-=.5/h**2*u[1:];Hu[1:]-=.5/h**2*u[:-1]
 energy=float(np.sum(u*Hu)*h);res=math.sqrt(np.sum((Hu-energy*u)**2)*h)
 stats=dict(n=n,lambda_coupling=lam,iterations=it+1,energy=energy,eigen_residual=res,normalization=float(np.sum(u*u)*h),rms_radius=math.sqrt(np.sum(r*r*u*u)*h),tail_probability=float(np.sum(u[r>6]**2)*h),phi_at_1=float(np.interp(1,r,phi)))
 return (stats,r,u,phi) if return_profile else stats
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',default='rg_qm_bridge_final_results.json');args=ap.parse_args();rows=[]
 def check(i,name,ok,**ev):
  rows.append(dict(id=i,name=name,passed=bool(ok),evidence=ev));print(('PASS ' if ok else 'FAIL ')+i+' '+name)
 I=np.eye(2);X=np.array([[0.,1.],[1.,0.]]);Y=np.array([[0.,-1j],[1j,0.]]);Z=np.diag([1.,-1.]);paulis=[I,X,Y,Z]
 # Exact finite-dimensional effect-span criterion and full-rank counterstates.
 E=np.array([I.flatten(),Z.flatten()]);A=X.flatten();res=A-E.T@np.linalg.lstsq(E.T,A,rcond=None)[0];rp=(I+.4*X)/2;rm=(I-.4*X)/2
 check('F01','Target-span criterion has a positive-state counterexample',np.linalg.norm(res)>1 and np.allclose(np.diag(rp),np.diag(rm)) and np.min(np.linalg.eigvalsh(rp))>0,target_gap=float(np.trace((rp-rm)@X)),residual_norm=float(np.linalg.norm(res)))
 # Task image, not weakest intermediate.
 O=[0,0];T=[-1,1];H=[t*t for t in T]
 check('F02','Unresolved intermediate can yield a resolved composite',T[0]!=T[1] and H[0]==H[1],observation=O,intermediate=T,task=H)
 # Raw moment panel and its exact error map.
 B=np.array([[.5,0,.5],[.5,0,-.5],[-.5,1,-.5]]) # q0,qpi4,qpi2 -> n,Re z,Im z
 M=np.array([[1,1,0],[1,0,1],[1,-1,0]])
 check('F03','Raw-moment panel reconstruction and covariance map',np.allclose(B@M,np.eye(3)),inverse_panel=B.tolist(),parameter_covariance_for_unit_panel_noise=(B@B.T).tolist(),coherent_variances=[.5,.5],coherent_raw_X_squared=[.5,2.5])
 # Oscillator total energy differs from normal ordered single quadrature.
 rr=.6;vmin=math.sinh(rr)**2-math.sinh(rr)*math.cosh(rr);total=math.sinh(rr)**2+.5
 check('F04','Negative quadrature proxy is not negative total oscillator energy',vmin<0 and total>0,normal_ordered_quadrature_min=vmin,total_oscillator_energy_in_hbar_omega=total)
 # Linearized Einstein tensor from independent Cartesian derivatives of a general static Phi.
 x,y,z=sp.symbols('x y z',real=True);coords=[sp.Symbol('t'),x,y,z];eta=sp.diag(-1,1,1,1);P=sp.Function('P')(x,y,z);h=sp.diag(-2*P,-2*P,-2*P,-2*P);tr=sum(eta[a,a]*h[a,a] for a in range(4))
 box=lambda f:sum(eta[a,a]*sp.diff(f,coords[a],2) for a in range(4))
 Ric=sp.Matrix(4,4,lambda a,b:sp.simplify((sum(eta[k,k]*(sp.diff(h[k,b],coords[k],coords[a])+sp.diff(h[k,a],coords[k],coords[b])) for k in range(4))-box(h[a,b])-sp.diff(tr,coords[a],coords[b]))/2))
 scalar=sum(eta[a,a]*Ric[a,a] for a in range(4));Ein=sp.simplify(eta*(Ric-eta*scalar/2));lap=sum(sp.diff(P,c,2) for c in [x,y,z]);expected=sp.diag(-2*lap,0,0,0)
 check('F05','All components of static linearized Einstein tensor close',sp.simplify(Ein-expected)==sp.zeros(4),mixed_tensor=str(Ein),units='P=Phi/c^2; source T^0_0=-rho c^2 at leading Newtonian order')
 r,s,m=sp.symbols('r s m',positive=True);pg=-m*sp.erf(r/(sp.sqrt(2)*s))/r;rho=m*(2*sp.pi*s*s)**sp.Rational(-3,2)*sp.exp(-r*r/(2*s*s));pres=sp.simplify(sp.diff(pg,r,2)+2*sp.diff(pg,r)/r-4*sp.pi*rho)
 check('F06','Gaussian Poisson forward and curvature return identity',pres==0,residual=str(pres),scope='G=1 analytic identity; leading Newtonian source only')
 # Distinct harmonic boundary fields share the same local source.
 check('F07','Boundary data are needed for source-to-geometry uniqueness',sp.diff(x,x,2)+sp.diff(x,y,2)+sp.diff(x,z,2)==0 and sp.diff(x,x)==1,harmonic_addition='a*x changes acceleration but not Laplacian; excluded by asymptotic decay')
 # True exact exterior ambiguity vs Gaussian ill-conditioning.
 check('F08','Gaussian finite-radius width sensitivity is nonzero',abs(sensitivity(5,1))>0,relative_width_sensitivity_at_5sigma=sensitivity(5,1),compact_spherical_profiles='same total mass and common exterior: exactly same Newtonian potential')
 # Inverse recover (m,sigma) from two declared finite-radius potential samples.
 def inv(s0=1.2,m0=1.3):
  r1,r2=1.,2.;q1,q2=phi_gaussian(r1,s0,m0),phi_gaussian(r2,s0,m0)
  sh=brentq(lambda ss:phi_gaussian(r1,ss)/phi_gaussian(r2,ss)-q1/q2,.1,5.,xtol=1e-13);mh=q1/phi_gaussian(r1,sh)
  return sh,mh
 sh,mh=inv()
 def Jlog(rs):return np.array([[1.,sensitivity(r,1)] for r in rs])
 near=float(np.linalg.cond(Jlog([1,2])));far=float(np.linalg.cond(Jlog([5,6])))
 check('F09','Two-radius inverse recovers mass and width; far field is ill-conditioned',abs(sh-1.2)<1e-10 and abs(mh-1.3)<1e-10 and far>near*100,recovered_sigma=sh,recovered_mass=mh,relative_jacobian_condition_near=near,relative_jacobian_condition_far=far)
 # Position samples: finite-sample CI uses chi-square, not only delta method.
 from scipy.stats import chi2
 rng=np.random.default_rng(20261021);n=20000;xs=rng.normal(size=(n,3));S=float(np.sum(xs*xs));sig=math.sqrt(S/(3*n));lo=math.sqrt(S/chi2.ppf(.975,3*n));hi=math.sqrt(S/chi2.ppf(.025,3*n));p0=phi_gaussian(1,1);pest=phi_gaussian(1,sig);plo=phi_gaussian(1,lo);phi=phi_gaussian(1,hi)
 check('F10','Position-law confidence interval propagates to potential task',lo<sig<hi and min(plo,phi)<=pest<=max(plo,phi),seed=20261021,n_3d_samples=n,sigma_hat=sig,sigma_95_interval=[lo,hi],potential_hat=pest,potential_95_interval=sorted([plo,phi]),potential_relative_error=abs(pest-p0)/abs(p0),relative_sigma_delta_sd=1/math.sqrt(6*n))
 # Actual self-consistent ground state, not a prescribed Gaussian labelled self-consistent.
 sp400=solve_sp(400);sp800,radial_r,radial_u,radial_phi=solve_sp(800,return_profile=True)
 check('F11','Trapped Schrodinger-Poisson fixed point and mesh check',sp800['eigen_residual']<1e-7 and abs(sp800['normalization']-1)<1e-12 and abs(sp800['energy']-sp400['energy'])<5e-4,coarse=sp400,fine=sp800,scope='dimensionless nonrelativistic mean-field model; not full semiclassical Einstein-QFT')
 # Propagate actual Fock/thermal source fluctuation through a common linear kernel.
 K=np.array([[1.,.2],[.1,.8]]);N=np.array([[2.,.3],[.3,1.]]);C0=np.diag([.4,.1]);full=K@N@K.T+C0
 check('F12','Noise bridge retains source, intrinsic and measurement covariance',np.min(np.linalg.eigvalsh(full))>0 and not np.allclose(full,K@N@K.T),geometry_covariance=full.tolist(),source_number_variance_fock=0.,source_number_variance_thermal=2.,scope='declared linear covariance model, no response law inferred from covariance alone')
 # Correct branch threshold and nonlinear countertask.
 spread=lambda d:G*d/(2*(.1**2+d*d/4)**1.5);root=brentq(lambda d:spread(d)-1e-15,1e-10,1e-6,xtol=1e-22)
 check('F13','Micrometre branch is resolved under the declared toy threshold',spread(1e-6)>1e-15 and spread(1e-9)<1e-15,threshold_small_branch_m=root,sd_at_micrometre=spread(1e-6),sd_at_nanometre=spread(1e-9),scope='hypothetical acceleration resolution, not a current instrument claim')
 check('F14','Linear-mean agreement fails for nonlinear tasks',np.mean(np.array([-1.,1.])**2)!=np.mean([-1.,1.])**2,mean_square=1.,square_mean=0.)
 # Noisy entanglement and a fixed implementable witness.
 ideal,phase=state_bmv();_,vec=np.linalg.eigh(partial_transpose(ideal));v=vec[:,0];W=partial_transpose(np.outer(v,v.conj()));rho_v,_=state_bmv(.99);w=float(np.trace(W@rho_v).real)
 coeff=np.array([[np.trace(W@np.kron(a,b)).real/4 for b in paulis] for a in paulis]);L=float(np.sum(abs(coeff))-abs(coeff[0,0]));Ksettings=15;alpha=.05;eps=.02;sys=.005;shots=math.ceil(2*L*L/eps**2*math.log(2*Ksettings/alpha))
 critical=brentq(lambda vv:np.linalg.eigvalsh(partial_transpose(state_bmv(vv)[0]))[0],.01,.999999)
 check('F15','Dephasing-aware witness and finite-shot budget',w+eps+sys<0 and critical<.99,phase_invariant_rad=phase,ideal_concurrence=abs(math.sin(phase/2)),visibility=.99,witness_expectation=w,critical_visibility_PPT=critical,nonidentity_l1=L,statistical_budget=eps,systematic_budget=sys,alpha=alpha,shots_per_setting_sufficient=shots,total_shots=9*shots,assumptions='independent bounded Pauli shots; known measurement model; all other interactions controlled separately')
 # LOCC null is theorem-backed; numerical examples only test implementation.
 minpt=1.
 for _ in range(50):
  mix=np.zeros((4,4),complex)
  for weight in rng.dirichlet(np.ones(5)):
   a=rng.normal(size=2)+1j*rng.normal(size=2);b=rng.normal(size=2)+1j*rng.normal(size=2);a/=np.linalg.norm(a);b/=np.linalg.norm(b);ab=np.kron(a,b);mix+=weight*np.outer(ab,ab.conj())
  minpt=min(minpt,float(np.linalg.eigvalsh(partial_transpose(mix))[0]))
 check('F16','Separable mixture controls have no negative partial transpose',minpt>=-1e-12,minimum_eigenvalue=minpt,n_synthetic_controls=50)
 # Source conservation is not optional: isolated density plus arbitrary pressure gradient fails.
 check('F17','Conservation gate rejects an unsupported static pressure profile',sp.diff(x*x,x)!=0,nonzero_spatial_divergence=str(sp.diff(x*x,x)),repair='include supporting apparatus or solve the matter equations and conserved total stress')
 # Derivatives require a stronger error topology than amplitude error.
 k=1000.;amp=1/k;second=amp*k*k
 check('F18','Small metric-amplitude error does not control curvature error',amp<.01 and second>100,metric_amplitude=amp,second_derivative_amplitude=second,perturbation='sin(k*x)/k')
 # Self-consistency theorem: contraction, with residual certificate.
 q=.2;b=.3;g=0.
 for _ in range(20):g=b+q*g
 residual=abs(g-(b+q*g));bound=residual/(1-q);truth=b/(1-q)
 check('F19','Declared contraction closes a feedback map with a posteriori bound',abs(g-truth)<=bound+1e-15,contraction=q,fixed_point=truth,iterate=g,residual=residual,error_bound=bound,scope='generic fixed-point witness; no proof that a full semiclassical gravity map contracts')
 # Concrete expectation can be identified although full density matrix is not.
 check('F20','Energy-source descent does not identify a quantum state',.75>0 and 0.!=2.,trace_distance_fock1_thermal_n1=.75,same_mean_n=1.,different_number_variance=[0.,2.])
 # A genuine quantum-source feedback map with a global contraction bound.
 delta=1.;bias=.3;lam=.2
 feedback=lambda gg:bias-lam*gg/math.sqrt(delta*delta+gg*gg)
 gg=0.
 for _ in range(40):gg=feedback(gg)
 rhog=(I-(delta*X+gg*Z)/math.sqrt(delta*delta+gg*gg))/2
 source=float(np.trace(rhog@Z));fixed_res=abs(gg-(bias+lam*source))
 check('F21','Quantum ground-state feedback has a unique conditional fixed point',lam/delta<1 and fixed_res<1e-14 and np.min(np.linalg.eigvalsh(rhog))>-1e-12,delta=delta,bias=bias,coupling=lam,contraction_bound=lam/delta,fixed_point=gg,source_Z=source,residual=fixed_res,scope='dimensionless two-level quantum feedback analogue, not a spacetime gravity model')
 # Raw fourth moments extend the mean-source bridge to a number-variance task.
 nn=24;aa=np.diag(np.sqrt(np.arange(1,nn)),1);ad=aa.T;number=ad@aa
 A=rng.normal(size=(6,6))+1j*rng.normal(size=(6,6));small=A@A.conj().T;small/=np.trace(small);state=np.zeros((nn,nn),complex);state[:6,:6]=small
 fourth=[]
 for theta in np.arange(5)*np.pi/5:
  quad=(aa*np.exp(-1j*theta)+ad*np.exp(1j*theta))/math.sqrt(2);fourth.append(float(np.trace(state@np.linalg.matrix_power(quad,4)).real))
 nmean=float(np.trace(state@number).real);n2=float(np.trace(state@number@number).real);n2panel=2*np.mean(fourth)/3-nmean-.5
 check('F22','Fourth-moment panel walks a source-variance task',abs(n2-n2panel)<1e-11,mean_number=nmean,number_second_moment=n2,reconstructed_second_moment=n2panel,number_variance=n2-nmean*nmean,scope='five raw fourth moments and known canonical single-mode dynamics; finite support avoids cutoff boundary')
 # Execute the registered nine-setting measurement protocol with synthetic multinomial shots.
 witness_counts=[];witness_rng=np.random.default_rng(20261022);est={(0,0):1.};outcomes=[(1,1),(1,-1),(-1,1),(-1,-1)]
 for ii in range(1,4):
  for jj in range(1,4):
   probs=np.array([np.trace(rho_v@np.kron((I+a*paulis[ii])/2,(I+b*paulis[jj])/2)).real for a,b in outcomes]);probs=np.maximum(probs,0);probs/=probs.sum();counts=witness_rng.multinomial(shots,probs);witness_counts.append(counts);freq=counts/shots
   est[ii,jj]=sum(f*a*b for f,(a,b) in zip(freq,outcomes))
   if jj==1:est[ii,0]=sum(f*a for f,(a,b) in zip(freq,outcomes))
   if ii==1:est[0,jj]=sum(f*b for f,(a,b) in zip(freq,outcomes))
 what=float(sum(coeff[ii,jj]*est[ii,jj] for ii in range(4) for jj in range(4)))
 check('F23','Synthetic finite-shot witness walk reaches a negative certified bound',abs(what-w)<eps and what+eps+sys<0,seed=20261022,witness_estimate=what,model_expectation=w,upper_bound=what+eps+sys,shots_per_setting=shots,total_shots=9*shots,union_bound_terms=15,scope='synthetic multinomial observations, not experimental evidence')
 # Physical free-scalar cavity stress: explicit mode functions, not a quadrature proxy.
 tt,xx,LL,AA=sp.symbols('t x L A',positive=True);nr,zr,zi=sp.symbols('n zR zI',real=True);ww=sp.pi/LL
 re=zr*sp.cos(2*ww*tt)+zi*sp.sin(2*ww*tt);im=zi*sp.cos(2*ww*tt)-zr*sp.sin(2*ww*tt)
 energy=ww/(AA*LL)*(nr+sp.cos(2*ww*xx)*re);flux=-ww/(AA*LL)*sp.sin(2*ww*xx)*im
 transverse=-ww/(AA*LL)*(nr*sp.cos(2*ww*xx)+re)
 conservation0=sp.simplify(sp.diff(energy,tt)+sp.diff(flux,xx));conservation1=sp.simplify(sp.diff(flux,tt)+sp.diff(energy,xx));totalE=sp.simplify(AA*sp.integrate(energy,(xx,0,LL)))
 physical_min=math.sinh(.6)**2-math.sqrt(3)/2*math.sinh(.6)*math.cosh(.6)
 check('F24','Raw-moment panel yields an explicitly conserved physical mode stress',conservation0==0 and conservation1==0 and sp.simplify(totalE-ww*nr)==0 and physical_min<0,energy_density=str(energy),flux=str(flux),transverse_pressure=str(transverse),interior_conservation_residuals=[str(conservation0),str(conservation1)],integrated_normal_ordered_energy=str(totalE),negative_local_energy_in_omega_over_volume=physical_min,scope='3+1 minimal massless scalar, one standing mode, periodic transverse area A, Dirichlet ends, vacuum normal ordering, hbar=c=1; wall/support stress separate')
 # Actual mutated predicates: wrong implementation must fail the corresponding acceptance gate.
 gates={
 'exact_width_wall':lambda value:abs(value)>0,
 'micrometre_unresolved':lambda value:value>1e-15,
 'drop_intrinsic_noise':lambda value:np.allclose(value,full),
 'ignore_dephasing':lambda value:np.linalg.eigvalsh(partial_transpose(value))[0]>=-1e-12,
 'weakest_link_necessary':lambda value:value==H,
 'wrong_panel_inverse':lambda value:np.allclose(value@M,np.eye(3)),
 'bad_poisson_potential':lambda value:sp.simplify(sp.diff(value,r,2)+2*sp.diff(value,r)/r-4*sp.pi*rho)==0,
 'omit_backreaction':lambda value:abs(value-(b+q*value))<1e-8}
 mutants={'exact_width_wall':0.,'micrometre_unresolved':0.,'drop_intrinsic_noise':K@N@K.T,'ignore_dephasing':ideal,'weakest_link_necessary':T,'wrong_panel_inverse':np.eye(3),'bad_poisson_potential':-m/r,'omit_backreaction':b}
 baselines={'exact_width_wall':sensitivity(5,1),'micrometre_unresolved':spread(1e-6),'drop_intrinsic_noise':full,'ignore_dephasing':state_bmv(.1)[0],'weakest_link_necessary':H,'wrong_panel_inverse':B,'bad_poisson_potential':pg,'omit_backreaction':truth}
 assert all(bool(gates[key](value)) for key,value in baselines.items())
 controls=[dict(id=key,baseline_passed=True,caught=not bool(gates[key](value))) for key,value in mutants.items()]
 rawpath=Path(args.out).with_suffix('.npz');np.savez_compressed(rawpath,position_samples=xs,pauli_setting_counts=np.array(witness_counts),witness_coefficients=coeff,radial_r=radial_r,radial_u=radial_u,radial_phi=radial_phi)
 result=dict(scope='Conditional mathematical closure and synthetic numerical walks only. No empirical gravity or quantum reconstruction claim.',script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),raw_file=rawpath.name,raw_sha256=hashlib.sha256(rawpath.read_bytes()).hexdigest(),n_checks=len(rows),n_pass=sum(row['passed'] for row in rows),results=rows,mutation_controls=controls,all_mutations_caught=all(c['caught'] for c in controls))
 Path(args.out).write_text(json.dumps(result,indent=2));print(f"{result['n_pass']}/{len(rows)} checks; mutations {sum(c['caught'] for c in controls)}/{len(controls)} caught")
 assert result['n_pass']==len(rows) and result['all_mutations_caught']
if __name__=='__main__':main()
