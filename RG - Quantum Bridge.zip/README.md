# RG - Quantum Bridge: battery QB01-QB10

    python3 rg_qm_bridge_attack.py --figs figs   # exact SymPy + quantum-optics matrices (~1 min)
    python3 rg_qm_bridge_attack.py --canary      # energy-identifies-state; identical couplings; lock everything

10/10 on seeds 20261026, 1, 42, 777, 2026; canary 3/3.
Composition theorem; second-moment source descent (3 homodyne variances); squeezed-vacuum negative energy;
Casimir tensor from one measured component; contextual/ordering correspondence of local stress; exact forward walk
(density -> potential -> linearized Einstein -> density); exterior wall at the quantum width; coupling FORCED for first
moments / CONDITIONAL for fluctuations; BMV entanglement plank (concurrence 0.156 vs 0 for LOCC); resolution walls.
