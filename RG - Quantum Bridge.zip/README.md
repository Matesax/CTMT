# RG - The Quantum Bridge (print edition)

    python3 rg_qm_bridge_final_checks.py --out rg_qm_bridge_final_results.json   # 24 checks + 8 mutations; writes NPZ records
    python3 rg_qm_bridge_verify.py                                               # replay from saved records (hashes checked)
    python3 rg_qbf_audit.py                                                      # independent audit H01-H10 (no shared code)
    python3 rg_qbf_figure.py                                                     # print figure from saved records only

Results: 24/24, mutations 8/8; replay verified (source + raw hashes); audit 10/10.
The first edition (QB01-QB10) is kept in historic_first_edition/ as a baseline, not as validation; its errata are
listed in the paper (weakest-link as characterization, Fine overreach, variances vs raw moments, proxy vs stress,
energy conditions, false structural wall, micrometre threshold, LOCC example, Casimir weighing).
