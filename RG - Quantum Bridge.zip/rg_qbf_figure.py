#!/usr/bin/env python3
"""Print figure from SAVED records (no regeneration) plus analytic curves."""
import json, math, numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy.special import erf
import importlib.util
spec = importlib.util.spec_from_file_location("audit_helpers", "rg_qbf_audit.py")
a = np.load("rg_qm_bridge_final_results.npz"); res = json.load(open("rg_qm_bridge_final_results.json")); e = {r["id"]: r["evidence"] for r in res["results"]}
fig, ax = plt.subplots(1, 3, figsize=(13.5, 3.8))
r, u, phi = a["radial_r"], a["radial_u"], a["radial_phi"]
ax[0].plot(r, u, label="ground state $u(r)$ (saved fixed point)"); ax[0].plot(r, 0.2*phi, label=r"self-potential $\lambda\phi_u(r)$")
ax[0].plot(r, (4/np.sqrt(np.pi))**0.5*r*np.exp(-r**2/2), "k:", lw=0.9, label=r"$\lambda=0$ oscillator")
ax[0].set_xlim(0, 6); ax[0].set_xlabel("r"); ax[0].legend(fontsize=7); ax[0].set_title("Walk II: backreaction fixed point (Schr\u00f6dinger\u2013Poisson)", fontsize=9)
# witness vs dephasing (model), computed with the audit's state construction
G, hb = 6.67430e-11, 1.054571817e-34; M, dx, dmin, tt = 1e-14, 250e-6, 200e-6, 2.5
x1 = (-(dmin/2+dx), -dmin/2); x2 = (dmin/2, dmin/2+dx)
ph = {(i, j): G*M*M*tt/(hb*abs(x2[j]-x1[i])) for i in range(2) for j in range(2)}
psi = np.array([np.exp(1j*ph[(i, j)]) for i in range(2) for j in range(2)])/2; rho = np.outer(psi, psi.conj())
def dephase(rho, v):
    out = rho.copy()
    for p_ in range(4):
        for q in range(4):
            i, j, k, l = p_//2, p_ % 2, q//2, q % 2; out[p_, q] *= v**((i != k)+(j != l))
    return out
ptB = lambda m: m.reshape(2, 2, 2, 2).transpose(0, 3, 2, 1).reshape(4, 4)
w_, U = np.linalg.eigh(ptB(rho)); W = ptB(np.outer(U[:, 0], U[:, 0].conj()))
vs = np.linspace(0.75, 1.0, 200); wv = [np.real(np.trace(W@dephase(rho, v))) for v in vs]
ax[1].plot(vs, wv, label=r"model $\mathrm{Tr}(W\rho_v)$"); ax[1].axhline(0, color="k", lw=0.6)
ax[1].axvline(0.8558213033, color="grey", ls="--", lw=0.8, label="PPT boundary $v^*=0.8558$")
west = e["F23"]["witness_estimate"]; ax[1].errorbar([0.99], [west], yerr=[[0], [0.025]], fmt="o", color="#c62828", capsize=4,
                                                     label="finite-shot estimate + (stat+sys) bound")
ax[1].set_xlabel("visibility $v$"); ax[1].set_ylabel("witness"); ax[1].legend(fontsize=7)
ax[1].set_title("Walk IV: entanglement witness (synthetic, 289 854 shots)", fontsize=9)
rr = np.linspace(0.5, 7, 400); sens = np.abs(rr*np.sqrt(2/np.pi)*np.exp(-rr**2/2)/erf(rr/np.sqrt(2)))
ax[2].semilogy(rr, sens); ax[2].axvline(5, color="grey", ls=":", lw=0.8)
ax[2].set_xlabel(r"$r/\sigma$"); ax[2].set_ylabel(r"$|\partial\log|\Phi|/\partial\log\sigma|$")
ax[2].set_title("Walk I: width is ill-conditioned, never exactly invisible", fontsize=9)
fig.tight_layout(); fig.savefig("qbf_walks.png", dpi=170); print("ok")
