"""Witnesses for 'A World Without Puzzle Pieces'. Exact or deterministic; no random sampling.
P1 parthood is observable-induced: one two-qubit state is a product in one factorization and maximally entangled in another
P2 wholes are not sums of parts: deuteron binding energy; quark current masses are ~1% of the proton mass (PDG values)
P3 elements as fibres of a chemical protocol: chlorine's atomic weight is a mixture of two isotopes that chemistry does not separate
P4 scale separation without 'time as a thing': a fast-slow system closes on the slow variable with error O(epsilon) (ratio of clock counts)
P5 joint closure: a host-microbe toy network closes (a steady state exists) only jointly, not for either part alone
Run: python rg_world_witnesses.py   (numpy, scipy, sympy)
"""
import json, math, hashlib, pathlib
import numpy as np
import sympy as sp
from scipy.integrate import solve_ivp
RES = {}
def must(c, m):
    if not c: raise AssertionError(m)

# P1 observable-induced tensor product structure (Zanardi 2001; Zanardi-Lidar-Lloyd 2004)
H = np.array([[1, 1], [1, -1]]) / math.sqrt(2); CNOT = np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 0, 1], [0, 0, 1, 0]])
bell = CNOT @ np.kron(H, np.eye(2)) @ np.array([1, 0, 0, 0])            # entangled in the computational factorization
def ent_entropy(psi):
    s = np.linalg.svd(psi.reshape(2, 2), compute_uv=False) ** 2; s = s[s > 1e-15]; return float(-(s * np.log2(s)).sum())
W = CNOT @ np.kron(H, np.eye(2))                                         # a second factorization: new 'parts' A' x B' := W (A x B)
psi_in_new_parts = W.conj().T @ bell                                     # the same vector, expressed in the new parts
e_old, e_new = ent_entropy(bell), ent_entropy(psi_in_new_parts)
must(abs(e_old - 1) < 1e-12 and abs(e_new) < 1e-12, "P1")
RES["P1"] = dict(claim="The same state is maximally entangled (1 ebit) for one choice of parts and a product (0 ebit) for another: "
                       "parts are induced by the accessible observables", entropy_old_parts=e_old, entropy_new_parts=e_new, status="PROVED (exact)")
# P2 non-additivity
mp_, mn, md = 938.27208816, 939.56542052, 1875.61294257                   # MeV (CODATA/PDG)
binding = mp_ + mn - md
mu, mdq = 2.16, 4.67                                                      # MeV, PDG quark current masses (MS-bar, 2 GeV)
frac = (2 * mu + mdq) / mp_
must(abs(binding - 2.2246) < 1e-3 and 0.005 < frac < 0.015, "P2")
RES["P2"] = dict(deuteron_binding_MeV=binding, quark_mass_fraction_of_proton=frac,
                 claim="A deuteron weighs 2.22 MeV less than its parts; quark current masses supply ~1% of the proton mass, "
                       "the rest is interaction (QCD) energy", status="COMPUTED (published masses)")
# P3 chlorine
m35, m37, a35, a37 = 34.96885268, 36.96590259, 0.7576, 0.2424
aw = m35 * a35 + m37 * a37
must(abs(aw - 35.453) < 0.002, "P3")
RES["P3"] = dict(atomic_weight=aw, claim="Chemistry reads one element (a fibre containing Cl-35 and Cl-37); mass spectrometry splits it: isotopes are hidden "
                                         "for the chemical protocol, visible to a finer one", status="COMPUTED (published isotope data)")
# P4 Tikhonov: x' = -x + y (slow), eps y' = -(y - x^2/(1 + x^2))  -> reduced: x' = -x + x^2/(1 + x^2)
def fast_slow(eps, T=10.0):
    sol = solve_ivp(lambda t, z: [-z[0] + z[1], -(z[1] - z[0] ** 2 / (1 + z[0] ** 2)) / eps], [0, T], [2.0, 0.0],
                    method="Radau", rtol=1e-10, atol=1e-12, dense_output=True)
    red = solve_ivp(lambda t, z: [-z[0] + z[0] ** 2 / (1 + z[0] ** 2)], [0, T], [2.0], rtol=1e-11, atol=1e-13, dense_output=True)
    ts = np.linspace(1.0, T, 200)
    return float(np.max(np.abs(sol.sol(ts)[0] - red.sol(ts)[0])))
errs = {e: fast_slow(e) for e in (1e-1, 1e-2, 1e-3)}
must(errs[1e-3] < errs[1e-2] < errs[1e-1] and errs[1e-3] < 5e-3, "P4")
RES["P4"] = dict(closure_error_by_eps={str(k): v for k, v in errs.items()},
                 claim="Scale separation is a ratio of relaxation counts (epsilon), not a separate realm: the slow variable closes with error O(epsilon)",
                 status="EXECUTED (Tikhonov; deterministic)")
# P5 joint closure: host H, microbe M, metabolite V (vitamin made only by M), nutrient N (supplied only via H)
# dH = H (V/(1+V) - 0.5) ; dM = M (N/(1+N) - 0.4) ; dV = 0.8 M - 0.3 V ; dN = 0.6 H - 0.2 N - 0.5 M N/(1+N)
Hs, Ms, Vs, Ns = sp.symbols("H M V N", positive=True)
eqs = [Vs / (1 + Vs) - sp.Rational(1, 2), Ns / (1 + Ns) - sp.Rational(2, 5),
       sp.Rational(4, 5) * Ms - sp.Rational(3, 10) * Vs, sp.Rational(3, 5) * Hs - sp.Rational(1, 5) * Ns - sp.Rational(1, 2) * Ms * Ns / (1 + Ns)]
sol = sp.solve(eqs, [Hs, Ms, Vs, Ns], dict=True)
joint = [s_ for s_ in sol if all(v > 0 for v in s_.values())]
host_alone = sp.solve([eqs[0].subs(Vs, 0)], [Hs])                         # without the microbe, V = 0: growth rate -1/2 < 0, no positive steady state
microbe_alone = sp.solve([eqs[1].subs(Ns, 0)], [Ms])                      # without the host, N = 0: growth rate -2/5 < 0
must(len(joint) == 1 and host_alone == [] and microbe_alone == [], "P5")
RES["P5"] = dict(joint_steady_state={str(k): str(v) for k, v in joint[0].items()},
                 claim="Neither host nor microbe has a positive steady state alone; together they close: 'organism' is a closure relative to a declared "
                       "task, and several overlapping closures can be valid at once", status="PROVED (exact algebra; toy model)")
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_world_witnesses_results.json").write_text(json.dumps(RES, indent=1, default=str))
for k, v in RES.items():
    if isinstance(v, dict): print(k, "|", v["status"])
print(errs, joint)
