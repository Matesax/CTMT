# CTMT Automorphism Group Classification

Classification for candidate theorem Mor_CTMT = Aut(G), with G=(R,N,Sigma), and conformal variant Gc=(R,N,[Sigma]).

## Group classification

                       system  n_obs  rank_R  dim_N    cross_rel  strict_lie_dim  conformal_lie_dim  conformal_extra_dim  block_product_dim  block_product_conformal_dim                   strict_group_form                   conformal_group_form  fisher_min    fisher_max  fisher_cond
      coil_axisymmetric_clean     24       3     21 3.759240e-16             213                214                    1                213                          214      O_Σ(R) × O_Σ(N) ≅ O(3) × O(21)         CO_Σ(R,N) ≅ R_+ × O(3) × O(21)    0.011250      1.125000 1.000000e+02
coil_anisotropic_instrumented     24       3     21 2.662227e-16             213                214                    1                213                          214      O_Σ(R) × O_Σ(N) ≅ O(3) × O(21)         CO_Σ(R,N) ≅ R_+ × O(3) × O(21)    0.025000      1.125000 4.500000e+01
        navier_laminar_window     32       8     24 3.340573e-16             304                305                    1                304                          305      O_Σ(R) × O_Σ(N) ≅ O(8) × O(24)         CO_Σ(R,N) ≅ R_+ × O(8) × O(24)    0.022500      0.750000 3.333333e+01
 navier_mixed_sensor_crosscov     32       8     24 6.699301e-02             120                121                    1                304                          305 Stab_Σ(R,N,C_RN), Lie dimension 120 CStab_[Σ](R,N,C_RN), Lie dimension 121    0.026455      0.774495 2.927602e+01
          diffusion_synthetic     28       5     23 3.189548e-16             263                264                    1                263                          264      O_Σ(R) × O_Σ(N) ≅ O(5) × O(23)         CO_Σ(R,N) ≅ R_+ × O(5) × O(23)    0.032143      1.125000 3.500000e+01
 reaction_diffusion_synthetic     28       5     23 6.354464e-02             153                154                    1                263                          264 Stab_Σ(R,N,C_RN), Lie dimension 153 CStab_[Σ](R,N,C_RN), Lie dimension 154    0.119977      1.141358 9.513145e+00
        seismic_local_declust     20       6     14 9.258580e-02              58                 59                    1                106                          107  Stab_Σ(R,N,C_RN), Lie dimension 58  CStab_[Σ](R,N,C_RN), Lie dimension 59    0.036524 154880.211820 4.240489e+06

## Strict vs conformal separation

                          case                                               expected       R_dist       N_dist  strict_sigma_rel  conformal_scale  conformal_residual strict_G conformal_Gc
                      identity                                              pass both 0.000000e+00 0.000000e+00          0.000000         1.000000            0.000000     PASS         PASS
       global_covariance_scale                            fail strict, pass conformal 0.000000e+00 0.000000e+00          3.000000         4.000000            0.000000     FAIL         PASS
null_only_covariance_inflation                            fail both, not global scale 0.000000e+00 0.000000e+00          1.676240         1.561956            1.579236     FAIL         FAIL
   anisotropic_sector_rotation fail strict, generally fail conformal unless conformal 7.466522e-16 6.236071e-16          0.492864         0.878543            0.477664     FAIL         FAIL
          resolved_null_mixing                                              fail both 4.966733e-02 4.966733e-02          0.115951         0.993278            0.115756     FAIL         FAIL

## Core formulas

In an adapted basis O = R ⊕ N, write Sigma = [[Sigma_R, C],[C^T, Sigma_N]]. Strict automorphisms are block maps diag(A,B) satisfying A Sigma_R A^T=Sigma_R, B Sigma_N B^T=Sigma_N, and A C B^T=C. If C=0, Aut(G) ≅ O(Sigma_R) × O(Sigma_N) ≅ O(r) × O(n-r).
Conformal automorphisms satisfy the same equations up to one common positive scale c. If C=0, Aut(Gc) ≅ R_+ × O(r) × O(n-r).