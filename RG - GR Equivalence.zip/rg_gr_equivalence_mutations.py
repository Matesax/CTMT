#!/usr/bin/env python3
"""Mutation suite for rg_gr_equivalence.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. Under one minute.

    python3 -I rg_gr_equivalence_mutations.py
"""
import json, os, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('SA', 'wrong radial factor in the isotropic chart', "lambda x, M: (1 + M / (2 * x)) ** 4, lambda", "lambda x, M: (1 + M / (2 * x)) ** 3, lambda"),
    ('SA', 'no change of chart: the coordinate canary has nothing to detect', "c = rng.uniform(1.3, 1.6)", "c = 1.0; a = a * 0"),
    ('SB', 'stars of unequal mass presented as one exterior', "stars = {Rs: _star(Rs) for Rs in (4.0, 6.0)}", "stars = {Rs: _star(Rs, M=1.0 + 0.01 * (Rs - 4.0)) for Rs in (4.0, 6.0)}"),
    ('SB', 'wave profile that is not a vacuum solution', "H = f * (x ** 2 - y ** 2)", "H = f * (x ** 2 + y ** 2)"),
    ('SC', 'a generic tensor presented as type D', "'D': 0.7 * np.diag([1.0, 1, -2]) + 0j", "'D': 0.7 * np.diag([1.0, 1.2, -2.2]) + 0j"),
    ('SC', 'a rotation in place of the boost', "return np.array([[math.cosh(t), 1j * math.sinh(t), 0], [-1j * math.sinh(t), math.cosh(t), 0], [0, 0, 1]])",
     "return np.array([[math.cos(t), math.sin(t), 0], [-math.sin(t), math.cos(t), 0], [0, 0, 1]]) + 0j"),
    ('SD', 'a triaxial tidal tensor presented as the spherical one', "'static observer near a spherical mass': (_params(np.diag([-2.0, 1.0, 1.0]) + 0j), ())",
     "'static observer near a spherical mass': (_params(np.diag([-2.0, 1.5, 0.5]) + 0j), ())"),
    ('SD', 'a frame component presented as an invariant', "return np.array([t(E @ E), t(B @ B), t(E @ B),", "return np.array([t(E @ E), t(B @ B), E[0, 1] * B[0, 1],"),
    ('SE', 'a garbling that is not stochastic', "K1[[0, 1, 2, 3, 4, 4], range(6)] = 1 ", "K1[[0, 1, 2, 3, 4, 4], range(6)] = 1.1 "),
    ('SE', 'a protocol that is not gauge invariant', "F = np.repeat(p, 3, axis=0) ", "F = np.repeat(p, 3, axis=0); F[1] = F[1][::-1] "),
    ('SF', 'wrong geodesic equation in the second chart', "return [Td, pd, -sg * 2 * (Td * pd + T * pdd), pdd]", "return [Td, pd, -sg * 2 * Td * pd - 2 * T * pdd, pdd]"),
    ('SF', 'wrong transition between the charts', "Jm = sp.Matrix([[1, 0], [1 / T, 1]])", "Jm = sp.Matrix([[1, 0], [-1 / T, 1]])"),
    ('SF', 'one extension presented as two', "sg = 1.0 if chart == 'A' else -1.0", "sg = 1.0"),
]


def main():
    base = open(os.path.join(HERE, 'rg_gr_equivalence.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_gr_equivalence.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_gr_equivalence.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_gr_equivalence_results.json')))['failures']
            except Exception:
                fails = [group] if run.returncode != 0 else []
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
