"""
RG-CHI  --  Coherence-Scaling Estimator
========================================

What this is
------------
A fast, cross-domain engineering estimator that generalizes the CTMT/CHI
"coherence volume" chi = M v^2 / (Phi g h rho) using the mature Resolution
Geometry (RG) reading of what CHI actually was:

    Take logs of Y = k * chi.  Then  log Y = log k + a . log(theta),
    where a is a FIXED exponent covector (a Buckingham-Pi monomial).

In RG terms:
  * chi        = coordinate along the single RESOLVED direction of the
                 log-observation geometry;
  * a          = that resolved direction (row space of the log-Jacobian, rank 1);
  * iso-chi    = the NULL sector (parameter moves that leave Y unchanged);
  * k          = the ANCHOR fixing the offset along the resolved direction;
  * "coherence class" = region where the resolved direction is INDEX-LOCKED
                 (rank-stable) and FLAT (holonomy-trivial) -> one frame -> one k;
  * "seepage"  = the resolved direction drifting/rotating with regime -> a
                 rank/holonomy event that breaks single-anchor transport.

The upgrade over hand-picked CHI: LEARN the exponents from data, and ship a
VALIDITY CERTIFICATE (index-lock / flatness test) that says when single-anchor
transport is safe and flags when you have left the coherence class.

This is dimensional power-law scaling with a principled validity certificate.
It is NOT a physics theory and makes no physical claim.

API
---
    est = RGChi(feature_names=['rho','A','v'])
    est.fit(Theta, Y)                 # learn exponents + certify
    est.report()                      # human-readable summary
    est.anchor(theta0, Y0)            # single-anchor (re)calibration
    yhat, ylo, yhi = est.predict(Theta_new, with_interval=True)
    est.in_class(Theta_new)           # bool mask: inside validated class?
    Xi = est.volatility(chi_series, dt)   # early-warning: d/dt log chi

Pure numpy. O(n * d^2) fit. Scales to large tabular operating logs.
"""
import numpy as np


class RGChi:
    def __init__(self, feature_names=None, fixed_exponents=None):
        """
        feature_names : list[str] of the physical driver columns of Theta.
        fixed_exponents : optional array a to FORCE the classic CHI monomial
                          (e.g. [1,2,-1,-1,-1] for [M,v,Phi,h,rho]); if None,
                          the exponents are learned from data.
        """
        self.feature_names = feature_names
        self.fixed = None if fixed_exponents is None else np.asarray(fixed_exponents, float)
        self.a = None          # learned/!fixed exponent covector (resolved direction)
        self.c = None          # log-offset (log k)
        self.r2 = None
        self.resid_sd = None   # residual sd in log space (for intervals)
        self.cert = None       # certificate dict

    # ---- fit: learn the resolved direction (exponents) in log space ----
    def fit(self, Theta, Y, order_by=None, nwin=4):
        Theta = np.asarray(Theta, float); Y = np.asarray(Y, float).ravel()
        if Theta.ndim == 1:
            Theta = Theta[:, None]
        X = np.log(Theta); y = np.log(Y)
        if self.fixed is not None:
            self.a = self.fixed.copy()
            self.c = np.mean(y - X @ self.a)
        else:
            A = np.column_stack([X, np.ones(len(y))])
            coef, *_ = np.linalg.lstsq(A, y, rcond=None)
            self.a, self.c = coef[:-1], coef[-1]
        resid = y - (X @ self.a + self.c)
        self.resid_sd = float(np.std(resid))
        self.r2 = float(1 - (resid**2).sum() / max(((y - y.mean())**2).sum(), 1e-30))
        self._certify(Theta, Y, order_by, nwin)
        return self

    # ---- validity certificate: index-lock (rank/flatness) of the resolved sector ----
    def _certify(self, Theta, Y, order_by, nwin):
        X = np.log(Theta); y = np.log(Y)
        if order_by is None:
            # order by the resolved coordinate itself (walk along chi)
            order_by = X @ self.a
        idx = np.argsort(np.asarray(order_by, float).ravel())
        k = max(len(idx) // nwin, self.a.size + 2)
        win_a = []
        for w in range(nwin):
            s = idx[w*k:(w+1)*k] if w < nwin-1 else idx[w*k:]
            if len(s) < self.a.size + 2:
                continue
            A = np.column_stack([X[s], np.ones(len(s))])
            coef, *_ = np.linalg.lstsq(A, y[s], rcond=None)
            win_a.append(coef[:-1])
        win_a = np.array(win_a)
        # full-vector exponent drift (captures rotation AND magnitude change)
        drift = float(np.max(np.linalg.norm(win_a - self.a, axis=1)) /
                      (np.linalg.norm(self.a) + 1e-12)) if len(win_a) else np.nan
        # validated range of the resolved coordinate
        chi_log = X @ self.a
        passed = bool(self.r2 > 0.97 and drift < 0.15)
        self.cert = dict(passed=passed, log_r2=self.r2, exponent_drift=drift,
                         window_exponents=win_a,
                         validated_chi_log_range=(float(chi_log.min()), float(chi_log.max())))

    # ---- single-anchor (re)calibration: keep exponents, fix offset from one point ----
    def anchor(self, theta0, Y0):
        theta0 = np.asarray(theta0, float).ravel()
        self.c = float(np.log(Y0) - np.log(theta0) @ self.a)
        return self

    # ---- chi (resolved coordinate) and prediction ----
    def chi(self, Theta):
        Theta = np.asarray(Theta, float)
        if Theta.ndim == 1:
            Theta = Theta[:, None]
        return np.exp(np.log(Theta) @ self.a)

    def predict(self, Theta, with_interval=False, z=1.96):
        Theta = np.asarray(Theta, float)
        if Theta.ndim == 1:
            Theta = Theta[:, None]
        yhat = np.exp(np.log(Theta) @ self.a + self.c)
        if not with_interval:
            return yhat
        f = np.exp(z * self.resid_sd)     # multiplicative interval in log space
        return yhat, yhat / f, yhat * f

    def in_class(self, Theta):
        """Is each new point inside the validated coherence class (resolved-coord range)?"""
        Theta = np.asarray(Theta, float)
        if Theta.ndim == 1:
            Theta = Theta[:, None]
        lo, hi = self.cert['validated_chi_log_range']
        cl = np.log(Theta) @ self.a
        return (cl >= lo) & (cl <= hi)

    # ---- early-warning diagnostics (kept from CHI, now on the resolved coordinate) ----
    @staticmethod
    def volatility(chi_series, dt=1.0):
        """Xi(t) = d/dt log chi : |Xi| large => regime transition / coherence stress."""
        lc = np.log(np.asarray(chi_series, float))
        return np.gradient(lc, dt)

    def report(self):
        nm = self.feature_names or [f"x{i}" for i in range(self.a.size)]
        print("RG-CHI coherence-scaling estimator")
        print("  resolved exponents (a):")
        for n_, ai in zip(nm, self.a):
            print(f"     {n_:>8s} ^ {ai:+.3f}")
        print(f"  log-offset (log k) = {self.c:+.4f}   [k = {np.exp(self.c):.4g}]")
        c = self.cert
        print(f"  certificate: log-R^2={c['log_r2']:.4f}  exponent-drift={c['exponent_drift']*100:.0f}%")
        if c['passed']:
            print("  -> PASS: index-locked & flat; single-anchor transport is valid across the class.")
        else:
            print("  -> FLAG: resolved direction drifts (regime change / non-monomial).")
            print("           single-anchor valid only within a band; per-window exponents:")
            print("          ", np.array2string(c['window_exponents'], prefix="           "))


# ------------------------------------------------------------------ demo
if __name__ == "__main__":
    rng = np.random.default_rng(0); n = 400

    print("="*66, "\nTURBINE (clean power law P = 0.5 Cp rho A v^3)\n", "="*66, sep="")
    rho = rng.uniform(1, 1.3, n); A = rng.uniform(80, 120, n); v = rng.uniform(5, 12, n)
    P = 0.5*0.4*rho*A*v**3*np.exp(0.03*rng.standard_normal(n))
    est = RGChi(['rho', 'A', 'v']).fit(np.column_stack([rho, A, v]), P, order_by=v)
    est.report()
    est.anchor([1.15, 100, 6.0], 0.5*0.4*1.15*100*6**3)
    yh = est.predict(np.column_stack([np.full(50, 1.15), np.full(50, 100.),
                                      np.linspace(5, 12, 50)]))
    print(f"  single-anchor prediction spans P = {yh.min():.0f}..{yh.max():.0f} W\n")

    print("="*66, "\nPITCH-CAPPED TURBINE (regime change -> should FLAG)\n", "="*66, sep="")
    v2 = rng.uniform(5, 16, n)
    Pc = 0.5*0.4*1.15*100*np.where(v2 <= 10, v2**3, 1000*(v2/10)**0.3)*np.exp(0.03*rng.standard_normal(n))
    RGChi(['rho', 'A', 'v']).fit(np.column_stack([np.full(n, 1.15), np.full(n, 100.), v2]), Pc, order_by=v2).report()

    print("\n" + "="*66, "\nFUEL (rolling+aero, not a monomial -> band-limited FLAG)\n", "="*66, sep="")
    v3 = rng.uniform(8, 35, n)
    Pf = (200*v3 + 0.9*v3**3)*np.exp(0.04*rng.standard_normal(n))
    RGChi(['v']).fit(v3.reshape(-1, 1), Pf, order_by=v3).report()
