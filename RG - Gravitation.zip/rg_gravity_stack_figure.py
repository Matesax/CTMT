import math, numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
ns = {}; exec(open("rg_gravity_stack_attack.py").read().split("ATTACKS = [")[0], ns)
fig, ax = plt.subplots(1, 3, figsize=(13.5, 3.8))
gs = np.linspace(0, 2, 41); m, r0 = 1.0, 1000.0
defl = [ns["deflection"](lambda x: 1-2*m/x, lambda x, g=g: 1/(1-2*g*m/x), lambda x: x*x, r0) for g in gs]
grr = [abs(2*m*(g-1)/(r0**2*(2*m-r0))) for g in gs]
ax[0].plot(gs, np.array(defl)/(4*m/r0), label="deflection / (4m/r0)")
ax2 = ax[0].twinx(); ax2.semilogy(gs, np.array(grr)+1e-30, "r--", label="|G^r_r| (vacuum residual)"); ax2.set_ylim(1e-12, 1e-5)
ax[0].axvline(1, color="k", lw=0.6); ax[0].set_xlabel(r"$\gamma$ (clock-invisible family)"); ax[0].set_ylabel("deflection ratio")
ax2.set_ylabel(r"$|G^r{}_r|$", color="r"); ax[0].set_title("clocks cannot fix gamma; the selected vacuum can", fontsize=9)
rcs = np.logspace(-4, -2.4, 9); Mt, Mn = [], []
for rc in rcs:
    Mt.append(ns["tov_polytrope"](100.0, rc)["M"]); Mn.append(ns["tov_newtonian_source"](100.0, rc)["M"])
ax[1].semilogx(rcs, Mt, "o-", label="source route, selected equation (= clock mass)"); ax[1].semilogx(rcs, Mn, "s--", label="pressure-blind Newtonian source")
ax[1].set_xlabel(r"central rest density $\rho_{0c}$"); ax[1].set_ylabel("stellar mass M (geometric)"); ax[1].legend(fontsize=7)
ax[1].set_title("source-clock consilience discriminates", fontsize=9)
C = 299792458.0; au, yr = 1.495978707e11, 365.256363004*86400; GMs = 4*math.pi**2*au**3/yr**2
merc = 6*math.pi*GMs/(C**2*5.7909050e10*(1-0.205630**2))*(36525/87.9691)*180/math.pi*3600
defl_s = 4*GMs/(C**2*6.957e8)*180/math.pi*3600
a, T = 26561.75e3, 43082.05; GMe = 4*math.pi**2*a**3/T**2; frac = 6.969290134e-10-1.5*GMe/(C**2*a); pr = GMe/6.371e6**2*22.5/C**2
pred = [merc/42.98, defl_s/1.75, frac/4.4647e-10, pr/2.46e-15]
ax[2].bar(range(4), pred, color="#2e7d32"); ax[2].axhline(1, color="k", lw=0.7); ax[2].set_ylim(0.98, 1.02)
ax[2].set_xticks(range(4), ["Mercury\nperihelion", "solar\ndeflection", "GPS clock\noffset", "Pound-\nRebka"], fontsize=7)
ax[2].set_ylabel("prediction / published value"); ax[2].set_title("calibrated from Kepler orbits only", fontsize=9)
fig.tight_layout(); fig.savefig("gs_gravity.png", dpi=170); print("ok")
