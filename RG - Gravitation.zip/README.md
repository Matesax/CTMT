# RG - Gravitation: the field equation selected, not postulated

    python3 rg_gravity_stack_attack.py            # GS01-GS12 + RW01-RW04: 16/16 (exact SymPy + ODE; ~3-4 min)
    python3 rg_gravity_stack_attack.py --canary   # pressure-blind source; Ricci-only; Newtonian deflection; no advance: 4/4
    python3 rg_gravity_stack_figure.py            # figure
    cd retained_backend && python3 rg_gravity_battery.py   # supplied backend: 25/25 (+6/6 symbolic), byte-identical rerun

Stack: null data -> conformal class; anchored clocks -> scale; conservation -> motion (Geroch-Jang); consilience under
P1-P5 -> G + Lambda g = kappa T (Lovelock); vacuum -> Schwarzschild (Birkhoff). kappa = unit anchor (provably), Lambda =
window. RW predictions use only Kepler calibrations; published values are literature anchors, not new data.
