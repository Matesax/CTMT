#!/usr/bin/env python3
"""Symbolic spacetime audit from metric derivatives; no backend imports."""
import json
from pathlib import Path
import sympy as s

def compute():
 t,r,th,ph=s.symbols('t r theta phi',real=True);m=s.symbols('m',positive=True)
 coords=[t,r,th,ph];A=1-2*m/r;diag=[-A,1/A,r*r,r*r*s.sin(th)**2]
 n=4;Gamma={}
 def G(a,b,c):return Gamma.get((a,b,c),s.S.Zero)
 for a in range(n):
  for b in range(n):
   for c in range(n):
    z=s.simplify(sum((s.diff(diag[a],coords[c]) if a==b else 0)+(s.diff(diag[a],coords[b]) if a==c else 0)-(s.diff(diag[b],coords[a]) if b==c else 0) for _ in [0])/(2*diag[a]))
    if z!=0:Gamma[a,b,c]=z
 R={}
 for a in range(n):
  for b in range(n):
   for c in range(n):
    for d in range(n):
     z=s.simplify(s.diff(G(a,b,d),coords[c])-s.diff(G(a,b,c),coords[d])+sum(G(a,k,c)*G(k,b,d)-G(a,k,d)*G(k,b,c) for k in range(n)))
     if z!=0:R[a,b,c,d]=z
 Ric=s.Matrix(n,n,lambda b,d:s.simplify(sum(R.get((a,b,a,d),0) for a in range(n))))
 K=s.simplify(sum(z*z*diag[a]/(diag[b]*diag[c]*diag[d]) for (a,b,c,d),z in R.items()))
 # Tidal acceleration = -R^i_{0j0} in the static orthonormal frame.
 tidal=[s.simplify(-R.get((i,0,i,0),0)/A) for i in [1,2,3]]
 torsion=all(s.simplify(G(a,b,c)-G(a,c,b))==0 for a in range(n) for b in range(n) for c in range(n))
 metriccompat=True
 for k in range(n):
  for a in range(n):
   for b in range(n):
    val=(s.diff(diag[a],coords[k]) if a==b else 0)-G(b,k,a)*diag[b]-G(a,k,b)*diag[a]
    metriccompat &= s.trigsimp(s.expand_trig(s.simplify(val)))==0
 # Generic static spherical Einstein tensor, derived from generic Christoffels/Ricci.
 f=s.Function('A')(r);h=s.Function('C')(r);gd=[-f,h,r*r,r*r*s.sin(th)**2];gg={}
 for a in range(n):
  for b in range(n):
   for c in range(n):
    val=((s.diff(gd[a],coords[c]) if a==b else 0)+(s.diff(gd[a],coords[b]) if a==c else 0)-(s.diff(gd[b],coords[a]) if b==c else 0))/(2*gd[a])
    if val!=0:gg[a,b,c]=s.simplify(val)
 def H(a,b,c):return gg.get((a,b,c),s.S.Zero)
 ric=[]
 for b in range(n):
  d=b
  val=sum(s.diff(H(a,b,d),coords[a])-s.diff(H(a,b,a),coords[d])+sum(H(a,k,a)*H(k,b,d)-H(a,k,d)*H(k,b,a) for k in range(n)) for a in range(n))
  ric.append(s.simplify(val))
 scalar=s.simplify(sum(ric[i]/gd[i] for i in range(n)))
 ein=[s.simplify(ric[i]/gd[i]-scalar/2) for i in range(n)]
 tt=(1/h-1)/r**2-s.diff(h,r)/(r*h*h)
 rr=(1/h-1)/r**2+s.diff(f,r)/(r*f*h)
 checks=[dict(id='T01-torsion-free',passed=bool(torsion)),dict(id='T02-metric-compatible',passed=bool(metriccompat)),dict(id='T03-vacuum-all-Ricci-components',passed=Ric==s.zeros(4)),dict(id='T04-Kretschmann',passed=s.simplify(K-48*m*m/r**6)==0),dict(id='T05-tidal-eigenvalues',passed=all(s.simplify(x-y)==0 for x,y in zip(tidal,[2*m/r**3,-m/r**3,-m/r**3]))),dict(id='T06-general-radial-Einstein',passed=s.simplify(ein[0]-tt)==0 and s.simplify(ein[1]-rr)==0)]
 return dict(summary=dict(n_checks=len(checks),n_pass=sum(x['passed'] for x in checks)),checks=checks,evidence=dict(ricci=str(Ric),kretschmann=str(K),tidal=list(map(str,tidal)),Gtt_mixed=str(ein[0]),Grr_mixed=str(ein[1]),nonzero_christoffels=len(Gamma),nonzero_Riemann_components=len(R)))
if __name__=='__main__':
 result=compute();Path(__file__).with_name('rg_gravity_tensor_results.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(result,indent=2));raise SystemExit(0 if all(x['passed'] for x in result['checks']) else 1)
