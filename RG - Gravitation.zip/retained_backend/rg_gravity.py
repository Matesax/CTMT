#!/usr/bin/env python3
"""Conditional RG gravity backend. GR field equations are declared inputs.
Geometric units G=c=1: lengths and coordinate/proper times have length units.
Not a derivation of Einstein gravity from RG, and not a general NR solver.
"""
from dataclasses import dataclass
import math
import numpy as np
from scipy.integrate import quad, solve_ivp, cumulative_trapezoid

def finite(name,x):
    x=float(x)
    if not math.isfinite(x): raise ValueError(name+' must be finite')
    return x

@dataclass(frozen=True)
class SphericalExterior:
    m: float
    def __post_init__(self):
        m=finite('m',self.m)
        if m<0: raise ValueError('m must be nonnegative in this declared branch')
        object.__setattr__(self,'m',m)
    def radius(self,r):
        r=finite('radius',r)
        if r<=2*self.m or r<=0: raise ValueError('outside static exterior chart: require r>2m')
        return r
    def A(self,r): return 1-2*self.m/self.radius(r)
    def C(self,r): return 1/self.A(r)
    def lapse(self,r): return math.sqrt(self.A(r))
    def clock_ratio(self,emitter,receiver):
        return self.lapse(emitter)/self.lapse(receiver)
    def static_acceleration(self,r):
        r=self.radius(r);return self.m/(r*r*self.lapse(r))
    def kretschmann(self,r):
        r=self.radius(r);return 48*self.m**2/r**6
    def tidal_acceleration_eigenvalues(self,r):
        r=self.radius(r);return self.m/r**3*np.array([2.,-1.,-1.])
    def radial_radar(self,r1,r2):
        r1=self.radius(r1);r2=self.radius(r2)
        if r2<=r1: raise ValueError('radar requires r2>r1')
        excess=4*self.m*math.log((r2-2*self.m)/(r1-2*self.m))
        coordinate=2*(r2-r1)+excess
        return dict(coordinate_roundtrip=coordinate,coordinate_excess=excess,
                    station_proper_roundtrip=self.lapse(r1)*coordinate)
    def light_deflection(self,r0):
        r0=self.radius(r0)
        if r0<=3*self.m: raise ValueError('scattering branch requires r0>3m')
        if self.m==0:return 0.
        k=self.m/r0
        # u=r0/r=1-s^2 removes the closest-approach square-root endpoint.
        def f(s): return 2/math.sqrt(2-s*s-2*k*(3-3*s*s+s**4))
        return 2*quad(f,0,1,epsabs=2e-12,epsrel=2e-12)[0]-math.pi
    def periapsis_advance(self,p,e):
        p=finite('semilatus rectum',p);e=finite('eccentricity',e)
        if not 0<e<1: raise ValueError('bound noncircular branch requires 0<e<1')
        if self.m<=0:raise ValueError('bound orbit requires m>0')
        if p<=self.m*(6+2*e):raise ValueError('outside stable bound branch p/m>6+2e')
        z=p/self.m
        return quad(lambda chi:math.sqrt(z/(z-6-2*e*math.cos(chi))),0,2*math.pi,
                    epsabs=2e-12,epsrel=2e-12)[0]-2*math.pi
    def circular_clock(self,r):
        r=self.radius(r)
        if self.m<=0 or r<=6*self.m:raise ValueError('stable circular branch requires m>0 and r>6m')
        T=2*math.pi*math.sqrt(r**3/self.m)
        return dict(coordinate_period=T,proper_period=T*math.sqrt(1-3*self.m/r),
                    proper_rate=math.sqrt(1-3*self.m/r))

def reconstruct_static_metric(clock_rate,radial_null_dt_dr):
    """Requires anchored static time and areal radius; not coordinate-free raw readings."""
    n=finite('clock rate',clock_rate);h=finite('null slope',radial_null_dt_dr)
    if n<=0 or h<=0:raise ValueError('positive lapse and null slope required')
    A=n*n;return dict(A=A,C=A*h*h)

def spherical_vacuum(m,r_outer,r_inner):
    model=SphericalExterior(m);model.radius(r_inner);model.radius(r_outer)
    if r_outer<=r_inner:raise ValueError('outer radius must exceed inner radius')
    def rhs(r,y):
        mass,nu=y
        if r<=2*mass:raise ValueError('static chart boundary')
        return [0.,mass/(r*(r-2*mass))]
    sol=solve_ivp(rhs,(r_outer,r_inner),[m,math.log(model.lapse(r_outer))],
                  rtol=2e-12,atol=2e-14,dense_output=True)
    if not sol.success:raise RuntimeError(sol.message)
    return sol

def constant_density_exact(m,R,r):
    m=finite('mass length',m);R=finite('surface radius',R);r=np.asarray(r,float)
    if m<=0 or R<=9*m/4 or np.any(r<0) or np.any(r>R):
        raise ValueError('regular positive-pressure benchmark requires R>9m/4 and 0<=r<=R')
    rho=3*m/(4*math.pi*R**3);s=math.sqrt(1-2*m/R);u=np.sqrt(1-2*m*r*r/R**3)
    return dict(rho=rho,mass=m*(r/R)**3,pressure=rho*(u-s)/(3*s-u),lapse=(3*s-u)/2)

def solve_tov(rho_of_p,central_pressure,r_max=100.,r_start=1e-6,rtol=1e-10):
    """Static isotropic perfect fluid, Lambda=0. EOS rho is total energy density.
    Central series is leading order; convergence must be checked. No global uniqueness claim.
    """
    pc=finite('central pressure',central_pressure);r_max=finite('r_max',r_max);r_start=finite('r_start',r_start)
    if pc<=0 or not 0<r_start<r_max:raise ValueError('positive central pressure and 0<r_start<r_max required')
    rhoc=finite('central density',rho_of_p(pc))
    if rhoc<=0:raise ValueError('positive central energy density required')
    def rhs(r,y):
        m,p,nu=y;rho=finite('density',rho_of_p(max(float(p),0.)))
        if rho<0 or r<=2*m:raise ValueError('invalid density or static chart lost')
        v=(m+4*math.pi*r**3*p)/(r*(r-2*m))
        return [4*math.pi*r*r*rho,-(rho+p)*v,v]
    def surface(r,y):return y[1]
    surface.terminal=True;surface.direction=-1
    sol=solve_ivp(rhs,(r_start,r_max),[4*math.pi*rhoc*r_start**3/3,pc,0.],
                  events=surface,rtol=rtol,atol=rtol*1e-5,dense_output=True,max_step=.1)
    if not sol.success:raise RuntimeError(sol.message)
    if len(sol.t_events[0])!=1:raise ValueError('no surface found within declared domain')
    R=float(sol.t_events[0][0]);M=float(sol.y_events[0][0,0]);nuR=float(sol.y_events[0][0,2])
    if R<=2*M:raise ValueError('surface not in static exterior')
    shift=.5*math.log(1-2*M/R)-nuR
    return dict(R=R,M=M,lapse_log_shift=shift,solution=sol)

def newton_uniform_sphere(M,R,r):
    r=np.asarray(r,float)
    if M<0 or R<=0 or np.any(r<0):raise ValueError('invalid Newtonian sphere')
    safe=np.maximum(r,np.finfo(float).tiny)
    return np.where(r<=R,-M*(3*R*R-r*r)/(2*R**3),-M/safe)

def newton_spherical_cells(edges,rho):
    """Piecewise-constant spherical density, isolated outer boundary, G=1.
    Mass integration is exact per cell; potential uses trapezoidal acceleration.
    """
    edges=np.asarray(edges,float);rho=np.asarray(rho,float)
    if len(edges)!=len(rho)+1 or edges[0]!=0 or np.any(np.diff(edges)<=0) or np.any(rho<0) or not np.all(np.isfinite(edges)) or not np.all(np.isfinite(rho)):
        raise ValueError('finite increasing radial edges from zero and nonnegative cell densities required')
    mass=np.r_[0.,np.cumsum(4*math.pi*rho*np.diff(edges**3)/3)]
    acc=np.zeros_like(edges);acc[1:]=mass[1:]/edges[1:]**2
    integ=cumulative_trapezoid(acc,edges,initial=0)
    phi=-mass[-1]/edges[-1]-(integ[-1]-integ)
    return dict(radius=edges,mass=mass,potential=phi,acceleration=-acc)

def solve_polytrope_enthalpy(K=100.,rho0c=.001,delta_h=1e-8,rtol=1e-11):
    """Gamma=2 relativistic polytrope; enthalpy regularizes the zero-pressure surface.
    rho0 is rest-mass density, rho=rho0+p is total energy density in G=c=1.
    Central expansion is leading order; delta_h convergence remains required.
    """
    K=finite('K',K);rho0c=finite('rho0c',rho0c);delta_h=finite('delta_h',delta_h)
    if K<=0 or rho0c<=0:raise ValueError('positive K and central rest density required')
    hc=math.log1p(2*K*rho0c)
    if not 0<delta_h<hc/10:raise ValueError('central enthalpy offset outside domain')
    pc=K*rho0c**2;rhoc=rho0c+pc
    r0=math.sqrt(3*delta_h/(2*math.pi*(rhoc+3*pc)))
    m0=4*math.pi*rhoc*r0**3/3
    def rhs(h,y):
        r,m=y;rho0=math.expm1(max(h,0))/(2*K);p=K*rho0**2;rho=rho0+p
        dr=-r*(r-2*m)/(m+4*math.pi*r**3*p)
        return [dr,4*math.pi*r*r*rho*dr]
    sol=solve_ivp(rhs,(hc-delta_h,0),[r0,m0],rtol=rtol,atol=rtol*1e-3,dense_output=True)
    if not sol.success:raise RuntimeError(sol.message)
    R,M=map(float,sol.y[:,-1])
    return dict(R=R,M=M,central_enthalpy=hc,solution=sol)
