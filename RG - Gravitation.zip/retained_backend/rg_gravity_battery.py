#!/usr/bin/env python3
"""RG-to-gravity conditional lock battery. All records are synthetic.
Stages: calibrate -> predict -> tensor audit -> score. No external blinding.
"""
import sys,json,math,hashlib,subprocess,copy
from pathlib import Path
import numpy as np
from scipy.integrate import quad
from rg_gravity import (SphericalExterior,reconstruct_static_metric,spherical_vacuum,
 constant_density_exact,solve_tov,solve_polytrope_enthalpy,newton_uniform_sphere,newton_spherical_cells)
ROOT=Path(__file__).resolve().parent
SOURCES=['rg_gravity.py','rg_gravity_oracle.py','rg_gravity_tensor_audit.py','rg_gravity_battery.py']
def dump(name,x):
 (ROOT/name).write_text(json.dumps(x,indent=2,allow_nan=False,default=lambda o:o.item() if hasattr(o,'item') else str(o)))
def load(name):return json.loads((ROOT/name).read_text())
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def source_hashes():return {n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in SOURCES}

def calibrate():
 # Synthetic bounded-error local clock data, not an experiment or confidence interval.
 r=np.array([25.,40.,70.]);eps=1e-8;true_mass=1.
 observed=1-2*true_mass/r+eps*np.array([.4,-.6,.2])
 intervals=np.c_[r*(1-observed-eps)/2,r*(1-observed+eps)/2]
 lo=float(max(intervals[:,0]));hi=float(min(intervals[:,1]))
 if lo>hi:raise ValueError('empty calibration fibre: incompatible data/model')
 data=dict(radius=r.tolist(),A_observed=observed.tolist(),absolute_A_error_bound=eps,
           origin='synthetic bounded deterministic perturbations; radius and time anchors assumed exact')
 # Broader operational family: A=1-2m/r, C=(1-2 gamma m/r)^-1.
 # Local radial null slopes calibrate gamma, not any lensing outcome.
 radar_r=np.array([30.,55.]);radar_eps=1e-8
 radar_h=1/(1-2/radar_r)+radar_eps*np.array([.3,-.4])
 gamma_ranges=[];gamma_est=[];mh=(lo+hi)/2
 for radius,h in zip(radar_r,radar_h):
  Alo=1-2*hi/radius;Ahi=1-2*lo/radius
  Clo=Alo*(h-radar_eps)**2;Chi=Ahi*(h+radar_eps)**2
  gamma_ranges.append([radius/(2*hi)*(1-1/Clo),radius/(2*lo)*(1-1/Chi)])
  gamma_est.append(radius/(2*mh)*(1-1/((1-2*mh/radius)*h*h)))
 gamma_interval=[float(max(x[0] for x in gamma_ranges)),float(min(x[1] for x in gamma_ranges))]
 if gamma_interval[0]>gamma_interval[1]:raise ValueError('empty operational gamma fibre')
 data['radar_radius']=radar_r.tolist();data['radar_null_slope']=radar_h.tolist();data['radar_slope_error_bound']=radar_eps
 dump('rg_gravity_clock_records.json',data)
 c=dict(m=(lo+hi)/2,m_interval=[lo,hi],gamma=float(np.mean(gamma_est)),gamma_interval=gamma_interval,operational_family='A=1-2m/r, C=1/(1-2 gamma m/r); parametric declaration, not a universal metric family',family='static spherical asymptotically flat Einstein vacuum, Lambda=0',
        field_equations='G_mu_nu=8*pi*T_mu_nu in geometric units; imported closure',
        source_profile='not identified by exterior data',seed=20261021,n_cases=12,
        gates=dict(relative=2e-6,absolute=2e-9,interval_solver_slack=2e-9),
        units='G=c=1; anchored length and time units; m=GM/c^2',
        scope='conditional model inference; not a derivation or empirical selection of GR')
 dump('rg_gravity_calibration.json',c)
 dump('rg_gravity_freeze.json',dict(sources=source_hashes(),calibration_sha256=digest(c),records_sha256=digest(data)))

def tasks(m,case):
 s=SphericalExterior(m);rad=s.radial_radar(case['r1'],case['r2'])
 return dict(deflection=s.light_deflection(case['r0']),precession=s.periapsis_advance(case['p'],case['e']),
             clock_ratio=s.clock_ratio(case['r1'],case['r2']),radial_excess=rad['coordinate_excess'],
             proper_radar=rad['station_proper_roundtrip'],circular_rate=s.circular_clock(case['rc'])['proper_rate'],
             kretschmann=s.kretschmann(case['r0']))

def predict():
 c=load('rg_gravity_calibration.json');rng=np.random.default_rng(c['seed']);rows=[]
 monotone=['deflection','precession','clock_ratio','radial_excess','circular_rate','kretschmann']
 for i in range(c['n_cases']):
  case=dict(r0=float(rng.uniform(7,60)),p=float(rng.uniform(12,80)),e=float(rng.uniform(.15,.65)),
            r1=float(rng.uniform(8,20)),r2=float(rng.uniform(40,120)),rc=float(rng.uniform(10,80)))
  pred=tasks(c['m'],case);ends=[tasks(m,case) for m in c['m_interval']]
  image={k:[min(z[k] for z in ends),max(z[k] for z in ends)] for k in monotone}
  op_lens=alternative_deflection(c['m'],case['r0'],c['gamma'])
  def op_time(m,g):
   return 2*quad(lambda r:1/math.sqrt((1-2*m/r)*(1-2*g*m/r)),case['r1'],case['r2'],epsabs=1e-10)[0]
  corners=[(m,g) for m in c['m_interval'] for g in c['gamma_interval']]
  op_lens_values=[alternative_deflection(m,case['r0'],g) for m,g in corners]
  op_time_values=[op_time(m,g) for m,g in corners]
  rows.append(dict(id=i,case=case,prediction=pred,conditional_task_intervals=image,
    operational_prediction=dict(deflection=op_lens,coordinate_radar=op_time(c['m'],c['gamma'])),
    operational_task_intervals=dict(deflection=[min(op_lens_values),max(op_lens_values)],coordinate_radar=[min(op_time_values),max(op_time_values)])))
 dump('rg_gravity_predictions.json',rows);f=load('rg_gravity_freeze.json');f['predictions_sha256']=digest(rows);dump('rg_gravity_freeze.json',f)

R=[]
def check(id,ok,evidence,kind='numerical conditional-model check'):
 R.append(dict(id=id,passed=bool(ok),kind=kind,evidence=evidence));print(('PASS ' if ok else 'FAIL ')+id,flush=True)

def alternative_deflection(m,r0,gamma):
 # Same lapse A, but radial C_gamma=(1-2 gamma m/r)^-1. Not all are GR vacua.
 A0=1-2*m/r0;k=m/r0
 def fun(s):
  u=1-s*s;A=1-2*k*u;C=1/(1-2*gamma*k*u)
  return 2*math.sqrt(A*C)/math.sqrt(2-s*s-2*k*(3-3*s*s+s**4))
 return 2*quad(fun,0,1,epsabs=1e-11)[0]-math.pi

def score():
 # Oracle is imported only in the scoring process.
 import rg_gravity_oracle as oracle
 c=load('rg_gravity_calibration.json');f=load('rg_gravity_freeze.json');rows=load('rg_gravity_predictions.json');records=load('rg_gravity_clock_records.json')
 intact=(f['sources']==source_hashes() and f['calibration_sha256']==digest(c) and f['records_sha256']==digest(records) and f['predictions_sha256']==digest(rows))
 check('G01-freeze-integrity',intact,dict(manifest=f),kind='procedural integrity check')
 # Positive information/cost metrics cannot be turned Lorentzian by real congruence.
 rng=np.random.default_rng(101);mins=[]
 for _ in range(40):
  X=rng.normal(size=(4,4));P=X@X.T+np.eye(4);D=rng.normal(size=(4,4));mins.append(float(np.linalg.eigvalsh(D@P@D.T).min()))
 check('G02-signature-boundary',min(mins)>0,dict(n=40,min_congruence_eigenvalue=min(mins),reason='Sylvester inertia; Lorentzian structure requires a separate realization'),kind='finite witness accompanying algebraic no-go')
 # Same clocks, different lensing: lapse does not determine spatial curvature.
 alt=[alternative_deflection(1,1000,g) for g in [0.,1.,2.]]
 check('G03-clock-only-gravity-correspondence',max(alt)-min(alt)>1e-3,dict(gamma=[0,1,2],deflection=alt,common_A='1-2m/r',same_clock_law=True),kind='explicit nonidentifiability witness')
 # Conformal ambiguity with fixed clock endpoints and identical null paths/radar.
 r=15.;a=1-2/r;Om=1+.02*math.sin(math.pi*(r-10)/20)**2;Omp=.02*math.pi/20*math.sin(2*math.pi*(r-10)/20)
 delta=a*a*Omp/Om
 check('G04-conformal-null-clock-fibre',abs(delta)>1e-5,dict(Omega_at_stations=[1,1],null_coordinate_slopes_identical=True,radial_rest_acceleration_difference=delta,scope='unparameterized null paths and station-clock radar at r=10,30; interior massive dynamics differ'),kind='explicit nonidentifiability witness')
 # Local metric tomography with ten known timelike tangent directions.
 vs=[np.array([1.,0,0,0])]
 for j in range(3):
  for sign in [-1,1]:
   v=np.array([1.,0,0,0]);v[j+1]=sign*.2;vs.append(v)
 for j,k in [(1,2),(1,3),(2,3)]:
  v=np.array([1.,0,0,0]);v[j]=v[k]=.2;vs.append(v)
 pairs=[(i,j) for i in range(4) for j in range(i,4)]
 D=np.array([[-v[i]*v[j]*(1 if i==j else 2) for i,j in pairs] for v in vs])
 metric=np.diag([-1.2,1.1,.9,1.3]);g=np.array([metric[i,j] for i,j in pairs]);y=D@g;gh=np.linalg.solve(D,y)
 Dstatic=np.tile(D[0],(10,1));rank=np.linalg.matrix_rank(D);rankstatic=np.linalg.matrix_rank(Dstatic)
 check('G05-path-rank-and-reconstruction',rank==10 and rankstatic==1 and max(abs(gh-g))<1e-12,dict(full_rank=int(rank),static_clock_rank=int(rankstatic),condition_number=float(np.linalg.cond(D)),max_metric_error=float(max(abs(gh-g)))),kind='linear local inverse problem, not global spacetime tomography')
 s=SphericalExterior(1);rr=np.geomspace(4,200,60);err=[]
 for r in rr:
  rec=reconstruct_static_metric(s.lapse(r),math.sqrt(s.C(r)/s.A(r)))
  err.append(max(abs(rec['A']-s.A(r)),abs(rec['C']-s.C(r))))
 check('G06-clock-plus-radar-static-reconstruction',max(err)<1e-12,dict(n=60,max_error=max(err),gauge='static time normalized at infinity, areal radius known'))
 # Symbolic tensor audit is kept separate, not pooled as six independent experiments.
 tensor=load('rg_gravity_tensor_results.json')
 check('G07-symbolic-spacetime-curvature',tensor['summary']['n_pass']==tensor['summary']['n_checks'],tensor,kind='symbolic identity audit')
 vac=spherical_vacuum(1,500,4);v=vac.sol(rr);err=float(np.max(abs(np.exp(2*v[1])-(1-2/rr))))
 check('G08-vacuum-field-ODE',err<1e-9,dict(max_A_error=err,mass_variation=float(np.ptp(v[0])),boundary='m=1 and normalized lapse at r=500'))
 # Weak-field limits are tested as convergence, not exact strong-field formulas.
 weak=[]
 for r in [1e3,2e3,4e3]:
  lens=s.light_deflection(r);peri=s.periapsis_advance(r,.3)
  weak.append(dict(radius=r,lens_ratio=lens/(4/r),precession_ratio=peri/(6*math.pi/r),static_acceleration_ratio=s.static_acceleration(r)/(1/r**2)))
 check('G09-Newton-and-weak-field-limits',all(abs(weak[-1][k]-1)<abs(weak[0][k]-1) for k in ['lens_ratio','precession_ratio','static_acceleration_ratio']) and abs(weak[-1]['lens_ratio']-1)<.001,dict(rows=weak))
 # Isolated Newtonian finite-volume radial computation with explicit boundary.
 errs=[];profiles=[]
 for n in [200,400,800]:
  edges=np.linspace(0,4,n+1);cent=(edges[:-1]+edges[1:])/2;rho=np.where(cent<1,3/(4*math.pi),0)
  out=newton_spherical_cells(edges,rho);exact=newton_uniform_sphere(1,1,edges)
  errs.append(float(max(abs(out['potential']-exact))));profiles.append(out)
 check('G10-Newton-Poisson-grid-refinement',errs[2]<errs[1]/3 and errs[1]<errs[0]/3 and errs[2]<2e-5,dict(cells=[200,400,800],max_potential_errors=errs,total_mass=float(profiles[-1]['mass'][-1]),boundary='Phi(4)=-M/4'))
 # Nonlinear source/metric feedback, not a one-way density-to-potential rename.
 exact=constant_density_exact(1,10,0);rho=exact['rho'];star=solve_tov(lambda p:rho,float(exact['pressure']),r_max=20)
 rs=np.linspace(.01,star['R'],120);sol=star['solution'].sol(rs);ana=constant_density_exact(1,10,np.minimum(rs,10))
 pe=float(max(abs(sol[1]-ana['pressure']))/rho);ne=float(max(abs(np.exp(sol[2]+star['lapse_log_shift'])-ana['lapse'])))
 check('G11-TOV-constant-density-exact',abs(star['R']-10)<1e-7 and abs(star['M']-1)<1e-7 and pe<1e-7 and ne<1e-7,dict(R=star['R'],M=star['M'],max_pressure_error_over_density=pe,max_lapse_error=ne,central_pressure=float(exact['pressure']),scope='incompressible analytic benchmark; not a causal material EOS'))
 polys=[solve_polytrope_enthalpy(delta_h=dh) for dh in [1e-7,1e-8,1e-9]]
 polydiff=max(abs(polys[-1][k]-polys[-2][k]) for k in ['R','M'])
 pstar=solve_tov(lambda p:math.sqrt(p/100)+p,.0001,r_max=30,rtol=1e-10)
 check('G12-TOV-polytrope-surface-and-refinement',polydiff<1e-7 and abs(pstar['R']-polys[-1]['R'])/polys[-1]['R']<2e-5,dict(K=100,rho0c=.001,central_pressure=.0001,enthalpy_rows=[dict(delta_h=dh,R=z['R'],M=z['M']) for dh,z in zip([1e-7,1e-8,1e-9],polys)],pressure_coordinate_R=pstar['R'],pressure_coordinate_M=pstar['M'],max_last_enthalpy_change=polydiff,scope='numerical equilibrium, not stability or uniqueness theorem'))
 # Exterior source-profile nonidentification.
 densities=[3/(4*math.pi*R**3) for R in [8,12]]
 check('G13-source-profile-fibre',densities[0]!=densities[1],dict(same_exterior_mass=1,source_radii=[8,12],densities=densities,common_exterior='A=1-2/r, C=1/A for r>12',status='exterior tasks identified; interior profile remains a correspondence'),kind='exact spherical-source ambiguity')
 # Score the frozen multi-observable predictions using a separate equation route.
 scored=[];invariants=[];lapse=oracle.lapse_solution(1)
 for row in rows:
  z=row['case'];nl=oracle.null_deflection(1,z['r0']);orb=oracle.orbit_precession(1,z['p'],z['e']);rad=oracle.radial_null_radar(1,z['r1'],z['r2'])
  cr=math.exp(float(lapse.sol(z['r1'])[0]-lapse.sol(z['r2'])[0]))
  actual=dict(deflection=nl['deflection'],precession=orb['advance'],clock_ratio=cr,radial_excess=rad['coordinate_excess'],proper_radar=rad['station_proper_roundtrip'])
  details={}
  for key,val in actual.items():
   pred=row['prediction'][key];tol=c['gates']['absolute']+c['gates']['relative']*abs(val)
   details[key]=dict(predicted=pred,oracle=val,absolute_error=abs(pred-val),relative_error=abs(pred-val)/abs(val),tolerance=tol,passed=abs(pred-val)<=tol)
  scored.append(dict(id=row['id'],case=z,details=details))
  invariants.append(dict(null_first_integral=nl['first_integral_error'],orbit_first_integral=orb['first_integral_error'],radial_null_norm=rad['null_norm_error'],radial_energy=rad['energy_error']))
 maxerr={k:max(x['details'][k]['relative_error'] for x in scored) for k in scored[0]['details']}
 check('G14-frozen-multitask-holdout',all(d['passed'] for x in scored for d in x['details'].values()),dict(n_cases=len(scored),n_scored_tasks_per_case=5,max_relative_errors=maxerr,rows=scored),kind='synthetic within-GR holdout, not empirical gravity selection')
 # Only analytically monotone tasks get interval endpoint images. Proper radar is excluded.
 intervalchecks=[]
 for row,x in zip(rows,scored):
  for key in ['deflection','precession','clock_ratio','radial_excess']:
   lo,hi=row['conditional_task_intervals'][key];val=x['details'][key]['oracle'];slack=c['gates']['interval_solver_slack']
   intervalchecks.append(dict(case=row['id'],task=key,lo=lo,hi=hi,oracle=val,contains=lo-slack<=val<=hi+slack,relative_diameter=(hi-lo)/abs(val)))
 oprows=[]
 for row,x in zip(rows,scored):
  z=row['case'];rad=oracle.radial_null_radar(1,z['r1'],z['r2'])
  for key,val in [('deflection',x['details']['deflection']['oracle']),('coordinate_radar',rad['coordinate_roundtrip'])]:
   pred=row['operational_prediction'][key];tol=c['gates']['absolute']+c['gates']['relative']*abs(val);lo,hi=row['operational_task_intervals'][key]
   oprows.append(dict(case=row['id'],task=key,predicted=pred,oracle=val,relative_error=abs(pred-val)/abs(val),interval=[lo,hi],passed=abs(pred-val)<tol and lo-2e-9<=val<=hi+2e-9))
 check('G24-operational-metric-to-heldout-gravity',all(x['passed'] for x in oprows) and c['gamma_interval'][0]<=1<=c['gamma_interval'][1] and c['gamma_interval'][0]>0 and c['gamma_interval'][1]<2,
  dict(gamma=c['gamma'],gamma_interval=c['gamma_interval'],n_tasks=len(oprows),max_relative_error=max(x['relative_error'] for x in oprows),rows=oprows,scope='clocks plus local radar calibrated; lensing never fitted; synthetic within declared two-parameter metric family'))
 check('G15-task-image-bounded-calibration',all(x['contains'] for x in intervalchecks),dict(m_interval=c['m_interval'],n_task_intervals=len(intervalchecks),max_relative_diameter=max(x['relative_diameter'] for x in intervalchecks),rows=intervalchecks,scope='conditional deterministic bounded-error image, not a statistical confidence interval'))
 worst={k:max(x[k] for x in invariants) for k in invariants[0]}
 circular=[]
 for row in rows:
  z=oracle.circular_timelike(1,row['case']['rc']);pred=row['prediction']['circular_rate'];tol=c['gates']['absolute']+c['gates']['relative']*abs(z['proper_rate'])
  circular.append(dict(case=row['id'],predicted=pred,oracle=z['proper_rate'],relative_error=abs(pred-z['proper_rate'])/z['proper_rate'],max_radius_drift=z['max_radius_drift'],max_norm_error=z['max_norm_error'],passed=abs(pred-z['proper_rate'])<tol and z['max_norm_error']<1e-9))
 check('G25-frozen-orbiting-proper-clock',all(x['passed'] for x in circular),dict(n_cases=len(circular),max_relative_error=max(x['relative_error'] for x in circular),rows=circular),kind='frozen proper-rate predictions versus full timelike geodesic integration')
 check('G16-geodesic-conservation',max(worst.values())<1e-8,dict(max_errors=worst))
 refine=[]
 for row in rows[:3]:
  z=row['case'];old=scored[row['id']]['details'];a=oracle.null_deflection(1,z['r0'],rtol=2e-13)['deflection'];p=oracle.orbit_precession(1,z['p'],z['e'],rtol=2e-13)['advance'];t=oracle.radial_null_radar(1,z['r1'],z['r2'],rtol=2e-13)['coordinate_excess']
  refine.extend([abs(a-old['deflection']['oracle']),abs(p-old['precession']['oracle']),abs(t-old['radial_excess']['oracle'])])
 check('G17-ODE-tolerance-refinement',max(refine)<1e-8,dict(n_cases=3,max_task_change=max(refine)))
 # Scale gauge: m,r -> k*m,k*r leaves dimensionless clocks and angles unchanged.
 z=rows[0]['case'];k=7.;ss=SphericalExterior(k)
 scaleerr=max(abs(ss.light_deflection(k*z['r0'])-s.light_deflection(z['r0'])),abs(ss.clock_ratio(k*z['r1'],k*z['r2'])-s.clock_ratio(z['r1'],z['r2'])),abs(ss.kretschmann(k*z['r0'])*k**4-s.kretschmann(z['r0'])))
 check('G18-unit-and-coupling-anchors',scaleerr<1e-12,dict(scale=7,max_dimensionless_error=scaleerr,curvature_scaling='K -> K/k^4',mass_inference='only GM/c^2 in an anchored length unit; G and M not separately inferred'))
 # Domain and empty-fibre gates.
 bad=[lambda:SphericalExterior(-1),lambda:s.A(2),lambda:s.light_deflection(3),lambda:s.periapsis_advance(6,.5),lambda:s.circular_clock(5),lambda:constant_density_exact(1,2,0),lambda:reconstruct_static_metric(0,1),lambda:SphericalExterior(float('nan'))]
 caught=0
 for fun in bad:
  try:fun()
  except ValueError:caught+=1
 check('G19-domain-abstention',caught==len(bad),dict(rejected=caught,n_invalid=len(bad),note='chart exclusion is not a claim of physical singularity at r=2m'))
 # Metric amplitude alone does not control curvature derivatives.
 ks=np.array([10.,100.,1000.]);amps=1/ks;second=ks
 check('G20-curvature-regularity-gate',amps[-1]<amps[0] and second[-1]>second[0],dict(k=ks.tolist(),metric_perturbation_amplitude=amps.tolist(),second_derivative_amplitude=second.tolist(),reason='C2 control and inverse-metric bounds needed; not C0 alone'),kind='analytic countersequence witness')
 # Conservation gate: static nonzero density with p=0 fails hydrostatic balance.
 r=5.;m_inside=(r/10)**3;required=-(rho)*(m_inside)/(r*(r-2*m_inside))
 check('G21-source-conservation-falsifier',abs(required)>1e-9,dict(declared_pressure_gradient=0,required_pressure_gradient=required,scope='static dust in this self-gravitating spherical model is inadmissible without extra support'),kind='model inconsistency witness')
 # Mutation tests: all thresholds are inherited from the frozen unmutated score.
 mutations=[]
 for name,key,fn in [('wrong_lensing_factor','deflection',lambda x:.5*x),('reverse_precession','precession',lambda x:-x),('omit_radar_delay','radial_excess',lambda x:0.),('omit_redshift','clock_ratio',lambda x:1.)]:
  rejected=sum(abs(fn(row['prediction'][key])-x['details'][key]['oracle'])>x['details'][key]['tolerance'] for row,x in zip(rows,scored))
  mutations.append(dict(name=name,caught=rejected>0,rejected_cases=rejected))
 cf=copy.deepcopy(c);cf['m']*=1.01;pr=copy.deepcopy(rows);pr[0]['prediction']['deflection']=scored[0]['details']['deflection']['oracle']
 mutations.extend([dict(name='postfreeze_mass_edit',caught=digest(cf)!=f['calibration_sha256']),dict(name='oracle_leak_into_prediction',caught=digest(pr)!=f['predictions_sha256']),dict(name='clocks_determine_spatial_metric',caught=max(alt)-min(alt)>1e-3),dict(name='static_clocks_full_metric_rank',caught=rankstatic<10),dict(name='C0_metric_controls_curvature',caught=second[-1]>second[0]),dict(name='omit_pressure_backreaction',caught=abs(required)>1e-9),dict(name='RG_cost_has_Lorentzian_signature',caught=min(mins)>0),dict(name='exterior_identifies_source_profile',caught=densities[0]!=densities[1])])
 check('G22-canaries-and-negative-controls',all(x['caught'] for x in mutations),dict(n_controls=len(mutations),controls=mutations),kind='mutation checks and explicit negative-control witnesses')
 # Strong-field extrapolation canary: leading weak-field formulas are not exact.
 lens=s.light_deflection(7);peri=s.periapsis_advance(12,.4)
 check('G23-weak-field-domain-falsifier',abs(lens-4/7)/lens>.1 and abs(peri-6*math.pi/12)/peri>.1,dict(r0=7,exact_deflection=lens,weak_deflection=4/7,p=12,e=.4,exact_precession=peri,weak_precession=6*math.pi/12),kind='approximation-domain witness')
 dump('rg_gravity_results.json',dict(summary=dict(n_checks=len(R),n_pass=sum(x['passed'] for x in R),synthetic=True,external_blinding=False,field_equations_derived_from_RG=False),checks=R))
 return 0 if all(x['passed'] for x in R) else 1

if __name__=='__main__':
 if len(sys.argv)>1:
  stage=sys.argv[1]
  if stage=='calibrate':calibrate()
  elif stage=='predict':predict()
  elif stage=='score':raise SystemExit(score())
  else:raise SystemExit('unknown stage')
 else:
  for stage in ['calibrate','predict']:subprocess.run([sys.executable,__file__,stage],check=True)
  subprocess.run([sys.executable,str(ROOT/'rg_gravity_tensor_audit.py')],check=True)
  subprocess.run([sys.executable,__file__,'score'],check=True)
