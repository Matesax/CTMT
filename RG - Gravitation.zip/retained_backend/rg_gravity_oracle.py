#!/usr/bin/env python3
"""Equation-route audit for declared Schwarzschild GR; imports no RG backend.
Different equations do not constitute independent empirical evidence.
"""
import math
import numpy as np
from scipy.integrate import solve_ivp

def null_deflection(m,r0,rtol=2e-12):
    if r0<=3*m:raise ValueError('non-scattering closest approach')
    def rhs(phi,y):return [y[1],-y[0]+3*m*y[0]**2]
    def infinity(phi,y):return y[0]
    infinity.terminal=True;infinity.direction=-1
    sol=solve_ivp(rhs,(0,12),[1/r0,0.],events=infinity,rtol=rtol,atol=rtol*1e-3,max_step=.025)
    if not sol.success or len(sol.t_events[0])!=1:raise RuntimeError('null escape not reached')
    phi=float(sol.t_events[0][0]);u,v=sol.y
    b=r0/math.sqrt(1-2*m/r0)
    invariant=v*v+u*u-2*m*u**3
    return dict(deflection=2*phi-math.pi,first_integral_error=float(np.max(abs(invariant-1/b**2))))

def orbit_precession(m,p,e,rtol=2e-12):
    z=p/m;L2=m*m*z*z/(z-3-e*e)
    def rhs(phi,y):return [y[1],-y[0]+m/L2+3*m*y[0]**2]
    def pericenter(phi,y):return y[1]
    pericenter.direction=-1
    sol=solve_ivp(rhs,(0,30),[(1+e)/p,0.],events=pericenter,rtol=rtol,atol=rtol*1e-3,max_step=.025)
    if not sol.success:raise RuntimeError(sol.message)
    events=sol.t_events[0];events=events[events>1e-6]
    if len(events)==0:raise RuntimeError('next pericenter not found')
    u,v=sol.y;inv=v*v+u*u-2*m*u**3-2*m*u/L2
    return dict(advance=float(events[0]-2*math.pi),first_integral_error=float(np.ptp(inv)))

def radial_null_radar(m,r1,r2,rtol=2e-12):
    # Full radial affine geodesic equations, not the integrated logarithmic formula.
    A1=1-2*m/r1
    def rhs(lam,y):
        t,r,vt,vr=y;A=1-2*m/r;Ap=2*m/r**2
        return [vt,vr,-Ap/A*vt*vr,-A*Ap/2*vt*vt+Ap/(2*A)*vr*vr]
    def arrival(lam,y):return y[1]-r2
    arrival.terminal=True;arrival.direction=1
    sol=solve_ivp(rhs,(0,2*(r2-r1)),[0.,r1,1/A1,1.],events=arrival,
                  rtol=rtol,atol=rtol*1e-2,max_step=(r2-r1)/80)
    if not sol.success or len(sol.t_events[0])!=1:raise RuntimeError('radial arrival not reached')
    time=float(sol.y_events[0][0,0]);t,r,vt,vr=sol.y;A=1-2*m/r
    return dict(coordinate_roundtrip=2*time,coordinate_excess=2*time-2*(r2-r1),
                station_proper_roundtrip=math.sqrt(A1)*2*time,
                null_norm_error=float(np.max(abs(-A*vt*vt+vr*vr/A))),
                energy_error=float(np.ptp(A*vt)))

def lapse_solution(m,rmin=4.,rmax=1000.):
    # Vacuum Einstein radial lapse equation with explicit outer boundary.
    def rhs(r,y):return [m/(r*(r-2*m))]
    sol=solve_ivp(rhs,(rmax,rmin),[.5*math.log(1-2*m/rmax)],rtol=2e-12,atol=2e-14,dense_output=True)
    if not sol.success:raise RuntimeError(sol.message)
    return sol

def circular_timelike(m,r0,rtol=2e-12):
    if r0<=6*m:raise ValueError('stable circular branch only')
    vt=1/math.sqrt(1-3*m/r0);vp=math.sqrt(m/r0**3)*vt
    def rhs(tau,y):
        t,r,phi,ut,ur,up=y;A=1-2*m/r;Ap=2*m/r**2
        return [ut,ur,up,-Ap/A*ut*ur,-A*Ap/2*ut*ut+Ap/(2*A)*ur*ur+A*r*up*up,-2*ur*up/r]
    def finish(tau,y):return y[2]-2*math.pi
    finish.terminal=True;finish.direction=1
    sol=solve_ivp(rhs,(0,2*2*math.pi/vp),[0.,r0,0.,vt,0.,vp],events=finish,rtol=rtol,atol=rtol*1e-2,max_step=(2*math.pi/vp)/100)
    if not sol.success or len(sol.t_events[0])!=1:raise RuntimeError('circular period not reached')
    tau=float(sol.t_events[0][0]);t=float(sol.y_events[0][0,0]);_,r,_,ut,ur,up=sol.y;A=1-2*m/r
    norm=-A*ut*ut+ur*ur/A+r*r*up*up
    return dict(coordinate_period=t,proper_period=tau,proper_rate=tau/t,max_radius_drift=float(max(abs(r-r0))),max_norm_error=float(max(abs(norm+1))))
