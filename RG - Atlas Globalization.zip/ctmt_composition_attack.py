import numpy as np, json, math
import matplotlib.pyplot as plt

rng = np.random.default_rng(20260714)

# Geometry deliberately chosen with a nontrivial stabilizer, so composition is genuinely testable.
# O = R (8) + N (24); C = lambda [I_8 | 0], Sigma_R=I, Sigma_N=I, lambda<1 => SPD.
n = 32
r = 8
q = n-r
lam = 0.06699
Sigma_R = np.eye(r)
Sigma_N = np.eye(q)
C = np.zeros((r,q))
C[:,:r] = lam*np.eye(r)
Sigma = np.block([[Sigma_R, C],[C.T, Sigma_N]])
I = np.eye(n)

# Fisher response J in adapted coordinates: only resolved rows active.
J = np.vstack([np.diag(np.linspace(2.0,0.75,r)), np.zeros((q,r))])
F0 = J.T @ np.linalg.inv(Sigma) @ J

def rot2(t):
    return np.array([[math.cos(t),-math.sin(t)],[math.sin(t),math.cos(t)]])

def embed_rot(m,i,j,t):
    Q=np.eye(m); Q[np.ix_([i,j],[i,j])] = rot2(t); return Q

def rand_rot_r(theta1, theta2):
    A=np.eye(r)
    A[np.ix_([0,1],[0,1])] = rot2(theta1)
    A[np.ix_([2,3],[2,3])] = rot2(theta2)
    return A

def rand_rot_k(size, theta):
    K=np.eye(size)
    if size>=2:
        K[np.ix_([0,1],[0,1])] = rot2(theta)
    return K

def block_diag(A,B):
    return np.block([[A,np.zeros((A.shape[0],B.shape[1]))],[np.zeros((B.shape[0],A.shape[1])),B]])

# Exact automorphism family: M = diag(A, diag(A,K)), with C=lambda[I 0]
def auto(theta1, theta2, thetaK=0.0):
    A = rand_rot_r(theta1, theta2)
    K = rand_rot_k(q-r, thetaK)
    B = block_diag(A, K)
    return block_diag(A,B)

def residual(M):
    return float(np.linalg.norm(M@Sigma@M.T - Sigma,'fro')/np.linalg.norm(Sigma,'fro'))

def sector_mix(M):
    return float(np.linalg.norm(M[:r,r:],'fro') + np.linalg.norm(M[r:,:r],'fro'))

def in_aut(M,tol=1e-10):
    return residual(M)<tol and sector_mix(M)<tol

def fisher_residual(M):
    # transform full covariance but same J to represent Fisher-only check in fixed resolved sensor coordinates
    S = M@Sigma@M.T
    F = J.T @ np.linalg.inv(S) @ J
    return float(np.linalg.norm(F-F0,'fro')/np.linalg.norm(F0,'fro'))

def classify(M,tol=1e-10):
    if in_aut(M,tol):
        if np.linalg.norm(M-I,'fro')<tol: return 'identity_aut'
        return 'nontrivial_aut'
    return 'not_aut'

M1 = auto(0.21, -0.10, 0.07)
M2 = auto(-0.13, 0.18, -0.04)
M3 = auto(0.05, 0.09, 0.12)

# Inadmissible transformations
Mix = I.copy(); Mix[:r,r:r+r] = 0.06*np.eye(r)
NullInfl = block_diag(np.eye(r), 1.08*np.eye(q))
CouplingTwist = block_diag(embed_rot(r,0,1,0.25), np.eye(q))

# Composition attacks
tests=[]

def add(name, factors, expected):
    P=I.copy()
    # right-to-left composition convention: product factors listed in application order
    for M in factors:
        P = M @ P
    tests.append({
        'name':name,
        'factor_classes':[classify(M) for M in factors],
        'factor_aut':[bool(in_aut(M)) for M in factors],
        'product_class':classify(P),
        'product_aut':bool(in_aut(P)),
        'product_covariance_residual':round(residual(P),12),
        'product_sector_mixing':round(sector_mix(P),12),
        'product_identity_distance':round(float(np.linalg.norm(P-I,'fro')),12),
        'product_fisher_residual':round(fisher_residual(P),12),
        'expected':expected
    })

add('aut_closure_M2_after_M1',[M1,M2],'product must remain in Aut(G)')
add('aut_closure_three_factors',[M1,M2,M3],'triple product must remain in Aut(G)')
add('inverse_closure',[M1,np.linalg.inv(M1)],'product identity')
add('left_defect_propagation',[M1,Mix],'inadmissible factor makes composition inadmissible')
add('right_defect_propagation',[Mix,M1],'inadmissible factor makes composition inadmissible')
add('null_inflation_after_aut',[M1,NullInfl],'null covariance scale defect rejected')
add('coupling_twist_after_aut',[M1,CouplingTwist],'coupling orientation defect rejected')
add('defect_cancellation_product_identity',[Mix,np.linalg.inv(Mix)],'product identity but factors fail edge admissibility')
add('fisher_false_composition_null_inflation',[NullInfl,NullInfl],'may preserve Fisher partly but fails CTMT covariance')

# Associativity check
left=(M3@M2)@M1
right=M3@(M2@M1)
assoc_error=float(np.linalg.norm(left-right,'fro'))

# Groupoid cancellation: if a,b and ab admissible, then b admissible? construct exact check; if a,ab admissible then b = a^-1 ab admissible.
AB=M2@M1
recovered=np.linalg.inv(M2)@AB
cancellation_error=float(np.linalg.norm(recovered-M1,'fro'))

# Summary health
summary={
    'system':'CTMT composition attack battery',
    'geometry':{
        'dim_O':n,
        'rank_R':r,
        'dim_N':q,
        'dimensional_closure':bool(n==r+q),
        'coupling_model':'C=lambda[I_r 0]',
        'lambda':lam,
        'Sigma_positive_definite':bool(np.linalg.eigvalsh(Sigma).min()>0),
        'kappa_RN':round(float(np.linalg.norm(C,'fro')/np.sqrt(np.linalg.norm(Sigma_R,'fro')*np.linalg.norm(Sigma_N,'fro'))),6)
    },
    'composition_tests':tests,
    'associativity':{
        'frobenius_error':round(assoc_error,16),
        'passes':bool(assoc_error<1e-12)
    },
    'cancellation':{
        'recovered_factor_error':round(cancellation_error,16),
        'passes':bool(cancellation_error<1e-12)
    },
    'main_findings':[
        'Aut(G) is closed under composition for exact admissible maps.',
        'Associativity is numerically exact to floating precision.',
        'Inverses are admissible and recover identity.',
        'Any inadmissible factor propagates a covariance or sector defect into the product unless hidden by cancellation.',
        'Defect cancellation shows why checking only final monodromy is insufficient; edge admissibility remains necessary.',
        'Fisher-level checks can miss null-sector composition defects; CTMT covariance residual detects them.'
    ]
}

with open('/mnt/data/ctmt_composition_attack_results.json','w') as f:
    json.dump(summary,f,indent=2)

# Plots
names=[t['name'] for t in tests]
cov=[t['product_covariance_residual'] for t in tests]
sec=[t['product_sector_mixing'] for t in tests]
aut=[t['product_aut'] for t in tests]
colors=['green' if a else 'red' for a in aut]

plt.figure(figsize=(12,5))
plt.bar(np.arange(len(names))-0.18,cov,width=0.36,label='covariance residual',color=colors,alpha=0.85)
plt.bar(np.arange(len(names))+0.18,sec,width=0.36,label='sector mixing',color='orange',alpha=0.65)
plt.xticks(range(len(names)),names,rotation=35,ha='right')
plt.ylabel('defect magnitude')
plt.title('Composition attack: closure and defect propagation')
plt.legend(); plt.tight_layout(); plt.savefig('/mnt/data/ctmt_composition_attack_defects.png',dpi=180); plt.close()

# Fisher vs CTMT residual plot
fish=[t['product_fisher_residual'] for t in tests]
plt.figure(figsize=(12,5))
plt.bar(np.arange(len(names))-0.18,fish,width=0.36,label='Fisher residual')
plt.bar(np.arange(len(names))+0.18,cov,width=0.36,label='CTMT covariance residual')
plt.xticks(range(len(names)),names,rotation=35,ha='right')
plt.ylabel('relative residual')
plt.title('Fisher projection vs full CTMT residual under composition')
plt.legend(); plt.tight_layout(); plt.savefig('/mnt/data/ctmt_composition_fisher_vs_ctmt.png',dpi=180); plt.close()

print(json.dumps(summary,indent=2))
