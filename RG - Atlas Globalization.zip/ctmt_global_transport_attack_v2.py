import numpy as np, json, math
import matplotlib.pyplot as plt

rng = np.random.default_rng(20260714)
n=32; r=8; q=n-r
Sigma_R=np.diag(np.linspace(1.0,2.0,r))
Sigma_N=np.diag(np.linspace(0.35,0.95,q))
C0=rng.normal(size=(r,q))
target=0.06699
C=C0*(target*np.sqrt(np.linalg.norm(Sigma_R,'fro')*np.linalg.norm(Sigma_N,'fro'))/np.linalg.norm(C0,'fro'))
Sigma=np.block([[Sigma_R,C],[C.T,Sigma_N]])
I=np.eye(n)

def kappa(C):
    return float(np.linalg.norm(C,'fro')/np.sqrt(np.linalg.norm(Sigma_R,'fro')*np.linalg.norm(Sigma_N,'fro')))

def residual(M,S=Sigma):
    return float(np.linalg.norm(M@S@M.T-S,'fro')/np.linalg.norm(S,'fro'))

def mix(M):
    return float(np.linalg.norm(M[:r,r:],'fro')+np.linalg.norm(M[r:,:r],'fro'))

def is_aut(M,tol=1e-9):
    return residual(M)<tol and mix(M)<tol

def classify_loop(M,tol=1e-9):
    iddist=float(np.linalg.norm(M-I,'fro'))
    if iddist<tol and is_aut(M,tol): return 'cocycle_identity_trivial_transport'
    if is_aut(M,tol): return 'nontrivial_holonomy_in_AutG'
    return 'inadmissible_obstruction_not_in_AutG'

def block_diag(A,B):
    return np.block([[A,np.zeros((A.shape[0],B.shape[1]))],[np.zeros((B.shape[0],A.shape[1])),B]])

def rot2(t):
    return np.array([[math.cos(t),-math.sin(t)],[math.sin(t),math.cos(t)]])

def embed(m,i,j,t):
    Q=np.eye(m); Q[np.ix_([i,j],[i,j])]=rot2(t); return Q

# Exact automorphisms valid for any Sigma: +I, -I.
H_id=I.copy()
H_minus=-I.copy()

# Inadmissible loop products
Mix=I.copy(); Mix[:r,r:r+r]=0.08*np.eye(r)
Twist=block_diag(embed(r,0,1,0.31),np.eye(q))
Infl=block_diag(np.eye(r),1.15*np.eye(q))

# Battery levels
# 1. triple overlap cocycle test: edge admissible true but product identity/nonidentity in exact Aut.
triple_tests=[
    {'name':'triple_exact_cocycle','edges':[I,I,I], 'Omega':I, 'expected':'glues_local_trivial'},
    {'name':'triple_pairwise_admissible_but_cocycle_defect','edges':[I,I,H_minus], 'Omega':H_minus, 'expected':'reject_as_Cech_cocycle_on_triple_overlap'},
    {'name':'triple_inadmissible_sector_mixing','edges':[I,I,Mix], 'Omega':Mix, 'expected':'reject_edge_or_product_not_AutG'},
]

# 2. loop holonomy test on noncontractible loop: product may be nonidentity if in AutG.
loop_tests=[
    {'name':'loop_trivial_holonomy','H':H_id, 'expected':'trivial_bundle_class'},
    {'name':'loop_nontrivial_minus_identity_holonomy','H':H_minus, 'expected':'accepted_nontrivial_holonomy_class'},
    {'name':'loop_coupling_orientation_twist','H':Twist, 'expected':'reject_not_AutG'},
    {'name':'loop_null_inflation','H':Infl, 'expected':'reject_not_AutG_and_amplifies'},
]

triple_results=[]
for t in triple_tests:
    edge_aut=[is_aut(E) for E in t['edges']]
    Om=t['Omega']
    triple_results.append({
        'test':t['name'],
        'edge_admissible':edge_aut,
        'all_edges_admissible':bool(all(edge_aut)),
        'Omega_classification':classify_loop(Om),
        'Omega_identity_distance':round(float(np.linalg.norm(Om-I,'fro')),12),
        'Omega_covariance_residual':round(residual(Om),12),
        'Omega_sector_mixing':round(mix(Om),12),
        'expected':t['expected'],
        'verdict': 'pass' if (t['name']=='triple_exact_cocycle' and np.linalg.norm(Om-I)<1e-9) or (t['name']!='triple_exact_cocycle' and np.linalg.norm(Om-I)>1e-9) else 'check'
    })

loop_results=[]
for t in loop_tests:
    H=t['H']
    loop_results.append({
        'test':t['name'],
        'classification':classify_loop(H),
        'in_AutG':bool(is_aut(H)),
        'identity_distance':round(float(np.linalg.norm(H-I,'fro')),12),
        'covariance_residual':round(residual(H),12),
        'sector_mixing':round(mix(H),12),
        'expected':t['expected']
    })

def amp(M,powers=(1,2,4,8,16,32)):
    return {
        'powers':list(powers),
        'fro_norms':[round(float(np.linalg.norm(np.linalg.matrix_power(M,p),'fro')),6) for p in powers],
        'covariance_residuals':[round(residual(np.linalg.matrix_power(M,p)),6) for p in powers]
    }

summary={
    'system':'CTMT global transport monodromy and cocycle attack battery v2',
    'base_geometry':{'dim_O':n,'rank_R':r,'dim_N':q,'dimensional_closure':bool(n==r+q),'kappa_RN':round(kappa(C),5),'Sigma_positive_definite':bool(np.linalg.eigvalsh(Sigma).min()>0)},
    'important_distinction':{
        'Cech_triple_overlap':'Omega_ijk must be identity for local gluing on triple overlaps',
        'noncontractible_loop':'H_gamma may be nonidentity if it lies in Aut(G); then it is holonomy, not failure'
    },
    'triple_overlap_tests':triple_results,
    'loop_holonomy_tests':loop_results,
    'amplification':{
        'admissible_nontrivial_holonomy_minus_identity':amp(H_minus),
        'inadmissible_null_inflation':amp(Infl)
    },
    'global_transport_verdict':'Battery supports the theorem split: edge admissibility alone is insufficient; Cech cocycle identity is required on triple overlaps; nontrivial loop holonomy is allowed only when the loop product remains in Aut(G); inadmissible sector/covariance distortions are rejected and may amplify under repetition.'
}
with open('/mnt/data/ctmt_global_transport_attack_v2_results.json','w') as f: json.dump(summary,f,indent=2)

# figures
names=[x['test'] for x in triple_results]
omega_id=[x['Omega_identity_distance'] for x in triple_results]
omega_res=[x['Omega_covariance_residual'] for x in triple_results]
plt.figure(figsize=(10,4.5))
plt.bar(np.arange(len(names))-0.18, omega_id, width=0.36, label='identity distance')
plt.bar(np.arange(len(names))+0.18, omega_res, width=0.36, label='covariance residual')
plt.xticks(range(len(names)), names, rotation=25, ha='right')
plt.title('Triple-overlap cocycle obstruction tests')
plt.legend(); plt.tight_layout(); plt.savefig('/mnt/data/ctmt_triple_cocycle_attack.png',dpi=180); plt.close()

names=[x['test'] for x in loop_results]
res=[x['covariance_residual'] for x in loop_results]
colors=['green' if x['in_AutG'] else 'red' for x in loop_results]
plt.figure(figsize=(10,4.5))
plt.bar(range(len(names)),res,color=colors)
plt.xticks(range(len(names)),names,rotation=25,ha='right')
plt.ylabel('relative covariance residual')
plt.title('Loop holonomy acceptance/rejection')
plt.tight_layout(); plt.savefig('/mnt/data/ctmt_loop_holonomy_attack.png',dpi=180); plt.close()

powers=summary['amplification']['admissible_nontrivial_holonomy_minus_identity']['powers']
plt.figure(figsize=(7.5,4.5))
plt.plot(powers, summary['amplification']['admissible_nontrivial_holonomy_minus_identity']['fro_norms'], marker='o', label='admissible H=-I')
plt.plot(powers, summary['amplification']['inadmissible_null_inflation']['fro_norms'], marker='o', label='inadmissible null inflation')
plt.xlabel('loop repetitions'); plt.ylabel('Frobenius norm')
plt.title('Holonomy amplification: bounded vs defective')
plt.grid(alpha=0.3); plt.legend(); plt.tight_layout(); plt.savefig('/mnt/data/ctmt_holonomy_amplification_v2.png',dpi=180); plt.close()

print(json.dumps(summary,indent=2))
