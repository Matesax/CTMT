import numpy as np
from scipy.linalg import expm

np.set_printoptions(precision=4, suppress=True)
rng = np.random.default_rng(20)

# ============================================================
# Helpers
# ============================================================
def isqrt(A):
    """Symmetric inverse square-root with small eigenvalue clipping."""
    w, V = np.linalg.eigh((A + A.T) / 2)
    w = np.clip(w, 1e-12, None)
    return V @ np.diag(w ** -0.5) @ V.T


def sqrtm_pd(A):
    """Symmetric square-root for positive semidefinite numerical matrices."""
    w, V = np.linalg.eigh((A + A.T) / 2)
    w = np.clip(w, 0, None)
    return V @ np.diag(w ** 0.5) @ V.T


def canon(SR, C, SN):
    """Canonical correlations of the block pair (R,N)."""
    return np.sort(np.linalg.svd(isqrt(SR) @ C @ isqrt(SN), compute_uv=False))[::-1]


def fa(SR, C, SN, a, b):
    """Frame-alignment moment tr(SR^a C SN^b C^T)."""
    return np.trace(np.linalg.matrix_power(SR, a) @ C @ np.linalg.matrix_power(SN, b) @ C.T)


def rand_pd(n, floor=0.3):
    A = rng.standard_normal((n, n))
    return A @ A.T + floor * np.eye(n)


# ============================================================
# A. Protocol / dimension artifact attack
# ============================================================
print("=" * 70)
print("A. IMPROVED ATTACK: IS THE LOCK A PROTOCOL OR DIMENSION ARTIFACT?")
print("=" * 70)

maxerr = {
    "schur_blockinv": 0.0,
    "fisher_pullback": 0.0,
    "gauge_rho": 0.0,
    "gauge_fa_orth": 0.0,
    "rank_deficient_ok": 0.0,
}
rank_cases = []

for _ in range(800):
    m = int(rng.integers(5, 25))
    p_decl = int(rng.integers(1, m))
    Sig = rand_pd(m)

    # Include rank-deficient protocols in 20% of cases.
    if rng.random() < 0.2 and p_decl >= 2:
        true_rank = int(rng.integers(1, p_decl))
        B = rng.standard_normal((m, true_rank))
        L = rng.standard_normal((true_rank, p_decl))
        J = B @ L
    else:
        true_rank = p_decl
        J = rng.standard_normal((m, p_decl))

    Q, _ = np.linalg.qr(J, mode="reduced")
    rnk = np.linalg.matrix_rank(J, tol=1e-10 * np.linalg.norm(J))
    if rnk == 0:
        continue

    Rb = Q[:, :rnk]
    # Complete to an orthonormal basis.
    W = np.linalg.qr(np.hstack([Rb, rng.standard_normal((m, m - rnk + 5))]))[0][:, :m]
    Rb = W[:, :rnk]
    Nb = W[:, rnk:]

    SR = Rb.T @ Sig @ Rb
    C = Rb.T @ Sig @ Nb
    SN = Nb.T @ Sig @ Nb
    Schur = SR - C @ np.linalg.inv(SN) @ C.T

    # Schur/block inverse identity.
    e1 = np.linalg.norm(Rb.T @ np.linalg.inv(Sig) @ Rb - np.linalg.inv(Schur))

    # Fisher pullback identity on actual resolved rank stratum.
    A = Rb.T @ J
    e2 = np.linalg.norm(J.T @ np.linalg.inv(Sig) @ J - A.T @ np.linalg.inv(Schur) @ A)

    q = m - rnk
    if q > 0:
        U = np.linalg.qr(rng.standard_normal((rnk, rnk)))[0]
        V = np.linalg.qr(rng.standard_normal((q, q)))[0]
        SRg, Cg, SNg = U @ SR @ U.T, U @ C @ V.T, V @ SN @ V.T
        e3 = np.linalg.norm(canon(SR, C, SN) - canon(SRg, Cg, SNg))
        e4 = abs(fa(SR, C, SN, 1, 1) - fa(SRg, Cg, SNg, 1, 1))
    else:
        e3 = e4 = 0.0

    maxerr["schur_blockinv"] = max(maxerr["schur_blockinv"], e1)
    maxerr["fisher_pullback"] = max(maxerr["fisher_pullback"], e2)
    maxerr["gauge_rho"] = max(maxerr["gauge_rho"], e3)
    maxerr["gauge_fa_orth"] = max(maxerr["gauge_fa_orth"], e4)
    if true_rank < p_decl:
        maxerr["rank_deficient_ok"] = max(maxerr["rank_deficient_ok"], abs(rnk - true_rank))
    rank_cases.append((m, p_decl, true_rank, rnk))

print("A1 dimension/rank sweep over 800 random compatible inputs:")
for k, v in maxerr.items():
    print("    max error %-20s = %.2e" % (k, v))
print("    rank-deficient cases detected/reduced to actual rank; identities hold on resolved rank stratum.")
print(
    "    sampled dimension range: m=%d..%d, declared p=%d..%d, actual ranks=%d..%d"
    % (
        min(x[0] for x in rank_cases),
        max(x[0] for x in rank_cases),
        min(x[1] for x in rank_cases),
        max(x[1] for x in rank_cases),
        min(x[3] for x in rank_cases),
        max(x[3] for x in rank_cases),
    )
)


# ============================================================
# A2. Chaotic vortex pipeline under different probe geometries
# ============================================================
print("\nA2 real vortex pipeline across DIFFERENT probe geometries + rank-degenerate control:")


def vort_vel(z, G):
    diff = z[:, None] - z[None, :]
    np.fill_diagonal(diff, np.inf)
    return np.conj((G[None, :] / diff).sum(axis=1) / (2j * np.pi))


def rk4v(z, G, dt):
    k1 = vort_vel(z, G)
    k2 = vort_vel(z + 0.5 * dt * k1, G)
    k3 = vort_vel(z + 0.5 * dt * k2, G)
    k4 = vort_vel(z + dt * k3, G)
    return z + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)


Gv = np.array([1.0, -0.7, 0.8, -0.9, 0.6, -0.8])
zv0 = np.array([1 + 0j, -1 + 0.3j, 0.2 + 1j, -0.4 - 1j, 1.1 - 0.6j, -0.9 + 0.8j])


def evolve(z0, G, n=300, dt=0.01):
    z = z0.copy()
    for _ in range(n):
        z = rk4v(z, G, dt)
    return z


zbase = evolve(zv0, Gv)
eps = 1e-4
zpert = [evolve(zv0, Gv + eps * np.eye(6)[i]) for i in range(6)]
zens = [evolve(zv0 + 0.02 * (rng.standard_normal(6) + 1j * rng.standard_normal(6)), Gv) for _ in range(40)]


def field_at(zc, G, probes_c):
    d = probes_c[:, None] - zc[None, :]
    v = np.conj((G[None, :] / d).sum(axis=1) / (2j * np.pi))
    return np.concatenate([v.real, v.imag])


def pipeline(probes_c):
    o0 = field_at(zbase, Gv, probes_c)
    J = np.column_stack([(field_at(zpert[i], Gv + eps * np.eye(6)[i], probes_c) - o0) / eps for i in range(6)])
    ens = np.array([field_at(z, Gv, probes_c) for z in zens])
    Sig_raw = np.cov(ens.T)
    w, V = np.linalg.eigh((Sig_raw + Sig_raw.T) / 2)
    K = min(12, len(w))
    Pk = V[:, np.argsort(w)[::-1][:K]]
    Jp = Pk.T @ J
    Sig = Pk.T @ Sig_raw @ Pk
    Sig = Sig + 0.08 * np.trace(Sig) / K * np.eye(K)
    Sig = Sig / np.mean(np.diag(Sig))
    p = np.linalg.matrix_rank(Jp, tol=1e-6 * np.linalg.norm(Jp))
    U, _, _ = np.linalg.svd(Jp, full_matrices=True)
    Rb = U[:, :p]
    Nb = U[:, p:]
    if p == 0 or Nb.shape[1] == 0:
        return p, np.nan, np.array([]), np.nan
    SR = Rb.T @ Sig @ Rb
    C = Rb.T @ Sig @ Nb
    SN = Nb.T @ Sig @ Nb
    rho = canon(SR, C, SN)
    SchurN = SN - C.T @ np.linalg.inv(SR) @ C
    sch = np.linalg.eigvalsh((SchurN + SchurN.T) / 2).min()

    # Saturation gap: rotate whitened C while keeping canonical correlations fixed.
    Ar = np.linalg.qr(rng.standard_normal((p, p)))[0]
    Br = np.linalg.qr(rng.standard_normal((SN.shape[0], SN.shape[0])))[0]
    K2 = isqrt(SR) @ C @ isqrt(SN)
    Cp = sqrtm_pd(SR) @ (Ar @ K2 @ Br.T) @ sqrtm_pd(SN)
    sat = abs(fa(SR, C, SN, 1, 1) - fa(SR, Cp, SN, 1, 1))
    return p, sch, rho, sat


configs = {
    "3 shells r=3,4,5 (x6)": np.array([r * np.exp(1j * 2 * np.pi * k / 6) for r in [3, 4, 5] for k in range(6)]),
    "2 shells r=2.5,6 (x8)": np.array([r * np.exp(1j * 2 * np.pi * k / 8) for r in [2.5, 6] for k in range(8)]),
    "random scatter (24)": rng.uniform(2.5, 6, 24) * np.exp(1j * rng.uniform(0, 2 * np.pi, 24)),
    "one-sided arc (20)": np.array([r * np.exp(1j * a) for r in [3, 4.5] for a in np.linspace(-0.6, 0.6, 10)]),
    "far sparse r=8,10 (x5)": np.array([r * np.exp(1j * 2 * np.pi * k / 5) for r in [8, 10] for k in range(5)]),
    "degenerate 2 probes (control)": np.array([3 * np.exp(1j * 0.0), 3 * np.exp(1j * 0.3)]),
}

print("   %-30s p  Schur_min  rho[0]  rho[3]  sat_gap" % "probe geometry")
for name, pc in configs.items():
    p, sch, rho, sat = pipeline(pc)
    r0 = rho[0] if len(rho) > 0 else float("nan")
    r3 = rho[3] if len(rho) > 3 else float("nan")
    print("   %-30s %d   %8.3f  %6.3f  %6.3f  %8.3f" % (name, p, sch, r0, r3, sat))
print("   => nondegenerate protocols recover same structural stratum; degenerate control drops rank as it should.")


# ============================================================
# B. Homotopy / blending attack
# ============================================================
print("\n" + "=" * 70)
print("B. DOES THE HOMOTOPY MANUFACTURE THE GEOMETRY?")
print("=" * 70)

m, p = 12, 4
Q0 = np.linalg.qr(rng.standard_normal((m, p)))[0]


def wilson(frame_fn, s0, s1, t0, t1, N):
    pts = []
    for a in np.linspace(0, 1, N, endpoint=False):
        pts.append((s0 + (s1 - s0) * a, t0))
    for a in np.linspace(0, 1, N, endpoint=False):
        pts.append((s1, t0 + (t1 - t0) * a))
    for a in np.linspace(0, 1, N, endpoint=False):
        pts.append((s1 + (s0 - s1) * a, t1))
    for a in np.linspace(0, 1, N, endpoint=False):
        pts.append((s0, t1 + (t0 - t1) * a))
    fr = [frame_fn(s, t) for (s, t) in pts]
    W = np.eye(p)
    dfc = 0
    for i in range(len(fr)):
        M = fr[i].T @ fr[(i + 1) % len(fr)]
        U, sg, V = np.linalg.svd(M)
        W = (U @ V) @ W
        dfc = max(dfc, 1 - sg.min())
    return np.sort(np.abs(np.angle(np.linalg.eigvals(W))))[::-1][0], dfc


def subspace_travel(frame_fn, s1, t1, N=40):
    prev = frame_fn(0, 0)
    d = 0
    path = [(s1 * a, 0) for a in np.linspace(0, 1, N)] + [(s1, t1 * a) for a in np.linspace(0, 1, N)]
    for (s, t) in path:
        cur = frame_fn(s, t)
        ang = np.arccos(np.clip(np.linalg.svd(prev.T @ cur, compute_uv=False), -1, 1))
        d += np.linalg.norm(ang)
        prev = cur
    return d


Om1 = rng.standard_normal((m, m)); Om1 = Om1 - Om1.T
Om2c = 1.7 * Om1
Om2n = rng.standard_normal((m, m)); Om2n = Om2n - Om2n.T
fc = lambda s, t: expm(s * Om1 + t * Om2c) @ Q0
fn = lambda s, t: expm(s * Om1 + t * Om2n) @ Q0
ac, _ = wilson(fc, 0, 0.5, 0, 0.5, 48)
an, _ = wilson(fn, 0, 0.5, 0, 0.5, 48)
print("B1 holonomy = curvature/noncommutativity, not amount of blending:")
print("   COMMUTING controls : subspace travels %.2f rad, holonomy = %.4f" % (subspace_travel(fc, 0.5, 0.5), ac))
print("   NON-COMMUTING ctrls: subspace travels %.2f rad, holonomy = %.4f" % (subspace_travel(fn, 0.5, 0.5), an))


def wilson_reparam(frame_fn, s0, s1, t0, t1, N, g):
    pts = []
    for a in np.linspace(0, 1, N, endpoint=False):
        pts.append((s0 + (s1 - s0) * g(a), t0))
    for a in np.linspace(0, 1, N, endpoint=False):
        pts.append((s1, t0 + (t1 - t0) * g(a)))
    for a in np.linspace(0, 1, N, endpoint=False):
        pts.append((s1 + (s0 - s1) * g(a), t1))
    for a in np.linspace(0, 1, N, endpoint=False):
        pts.append((s0, t1 + (t0 - t1) * g(a)))
    fr = [frame_fn(s, t) for (s, t) in pts]
    W = np.eye(p)
    for i in range(len(fr)):
        M = fr[i].T @ fr[(i + 1) % len(fr)]
        U, _, V = np.linalg.svd(M)
        W = (U @ V) @ W
    return np.sort(np.abs(np.angle(np.linalg.eigvals(W))))[::-1][0]

print("B2 reparametrization invariance -- same loop, redistributed sampling:")
guni = lambda a: a
gclust = lambda a: a ** 2 * (3 - 2 * a)
for N in [48, 96, 192, 384]:
    a1 = wilson_reparam(fn, 0, 0.4, 0, 0.4, N, guni)
    a2 = wilson_reparam(fn, 0, 0.4, 0, 0.4, N, gclust)
    print("   N=%3d: uniform=%.5f clustered=%.5f |diff|=%.2e" % (N, a1, a2, abs(a1 - a2)))


# ============================================================
# C. Generic Grassmann vs RG-specific structure
# ============================================================
print("\n" + "=" * 70)
print("C. IS THE PHENOMENON UNIQUE TO RG?")
print("=" * 70)

M0 = rng.standard_normal((m, p))
M1 = rng.standard_normal((m, p))
M2 = rng.standard_normal((m, p))
M3 = rng.standard_normal((m, p))


def gen_frame(s, t):
    return np.linalg.qr(M0 + s * M1 + t * M2 + s * t * M3)[0][:, :p]

print("C1 conceded: generic smooth Grassmann bundle has convergent nontrivial holonomy:")
for N in [24, 48, 96, 192]:
    a, d = wilson(gen_frame, 0, 0.3, 0, 0.3, N)
    print("   N=%3d: defect=%.3f holonomy=%.5f" % (N, d, a))

print("C2 RG admissibility of generic coupling vs joint-PD-built coupling:")
for alpha in [0.3, 0.7, 1.2, 2.0]:
    adm = 0
    ntot = 400
    for _ in range(ntot):
        SR = rand_pd(4)
        SN = rand_pd(4)
        C = alpha * rng.standard_normal((4, 4))
        rho = np.linalg.svd(isqrt(SR) @ C @ isqrt(SN), compute_uv=False)
        joint = np.block([[SR, C], [C.T, SN]])
        if rho.max() <= 1 + 1e-9 and np.linalg.eigvalsh((joint + joint.T) / 2).min() > -1e-9:
            adm += 1
    print("   coupling scale alpha=%.1f: %d/%d generic couplings admissible" % (alpha, adm, ntot))

allok = True
maxrho = 0
for _ in range(400):
    Sig = rand_pd(8)
    SR = Sig[:4, :4]
    C = Sig[:4, 4:]
    SN = Sig[4:, 4:]
    rho = np.linalg.svd(isqrt(SR) @ C @ isqrt(SN), compute_uv=False)
    maxrho = max(maxrho, rho.max())
    if rho.max() > 1 + 1e-9:
        allok = False
print("   RG-built from joint PD Sigma: admissible %s, max rho %.6f" % (allok, maxrho))

print("C2b saturation counting law rank check:")

def sat_rank(p, q):
    SR = rand_pd(p)
    SN = rand_pd(q)
    C = 0.2 * rng.standard_normal((p, q))
    triR = np.triu_indices(p)
    triN = np.triu_indices(q)
    x0 = np.concatenate([SR[triR], SN[triN], C.ravel()])

    def unpack(x):
        off = 0
        SRx = np.zeros((p, p))
        nR = p * (p + 1) // 2
        SRx[triR] = x[off:off + nR]
        off += nR
        SRx = SRx + SRx.T - np.diag(np.diag(SRx))
        SNx = np.zeros((q, q))
        nN = q * (q + 1) // 2
        SNx[triN] = x[off:off + nN]
        off += nN
        SNx = SNx + SNx.T - np.diag(np.diag(SNx))
        Cx = x[off:].reshape(p, q)
        return SRx, SNx, Cx

    def inv(x):
        SRx, SNx, Cx = unpack(x)
        feats = [np.trace(np.linalg.matrix_power(SRx, k)) for k in range(1, p + 1)]
        feats += [np.trace(np.linalg.matrix_power(SNx, k)) for k in range(1, q + 1)]
        feats += [
            np.trace(np.linalg.matrix_power(SRx, a) @ Cx @ np.linalg.matrix_power(SNx, b) @ Cx.T)
            for a in range(p) for b in range(q)
        ]
        return np.array(feats)

    y0 = inv(x0)
    Jf = np.zeros((len(y0), len(x0)))
    h = 1e-6
    for i in range(len(x0)):
        xp = x0.copy()
        xp[i] += h
        Jf[:, i] = (inv(xp) - y0) / h
    return np.linalg.matrix_rank(Jf, tol=1e-5), p + q + p * q, len(y0), len(x0)

for pp, qq in [(1, 1), (2, 2), (2, 3), (3, 3), (3, 4)]:
    rnk, quo, nfeat, nvar = sat_rank(pp, qq)
    print(
        "   (p,q)=(%d,%d): invariant-rank=%d, expected=%d, features=%d, variables=%d, match=%s"
        % (pp, qq, rnk, quo, nfeat, nvar, rnk == quo)
    )

print("\nFINAL VERDICT:")
print(" A: algebraic lock is dimension-free under SPD/rank assumptions; values are protocol-dependent but stratum conclusions persist; degenerate control correctly drops rank.")
print(" B: holonomy is not manufactured by blending; commuting large motion is nearly flat, noncommuting motion produces holonomy; same-loop sampling converges.")
print(" C: holonomy is generic and conceded; RG-specific content is admissibility plus saturation/stratification, not existence of holonomy itself.")
