# RG Physical-Distance Hostile Battery

Target joint: statistical experiment -> RG distance -> physical distance (metre).

## Run
```
python3 rg_physical_distance_attack.py                 # primary run, seed 20260928
python3 rg_physical_distance_attack.py --seed 42       # any seed; per-attack RNG streams
python3 rg_physical_distance_attack.py --canary        # mutation test: sabotage 4 structures, each must be caught
```
Requires numpy, scipy, sympy. Exit code 0 only if every registered check passes.

## Rules the battery enforces on itself
- Each attack registers a NAIVE claim (what a hostile referee attacks) and a SHARPENED claim (what the ladder keeps).
- A check passes only if the observed numbers match the pre-registered prediction of the sharpened claim.
  For naive claims that prediction is "an explicit counterexample exists"; the counterexample is stored in the JSON.
- Any NaN/inf anywhere in the evidence fails the check (a silent-NaN pass was found and removed during development).
- A check that cannot fail is worthless: `--canary` removes the structure behind PD10, PD14, PD15, PD20
  and requires that exactly the targeted check fails.

## Result (seed 20260928)
20/20 checks pass; 11 naive claims falsified with counterexamples.
Seeds 1, 42, 777: 20/20. Canary: 4/4 mutations caught.

| ID | Rung | Verdict | Naive claim attacked |
|---|---|---|---|
| PD01 | P2 (no-go) | FALSIFIED-naive | RG distance d_RG equals physical distance up to a universal constant. |
| PD02 | P2 (no-go) | FALSIFIED-naive | Some calibration function F turns RG distance into physical distance. |
| PD03 | P5 (holds) | HOLDS | Only Gaussian location experiments give distance ratios equal to displacement ratios. |
| PD04 | P3 (boundary) | FALSIFIED-naive | RG distance is the operational distinguishability between two displaced sources. |
| PD05 | P6 (no-go) | HOLDS | A sufficiently rich statistical experiment determines the metre internally. |
| PD06 | P7 (anchor) | HOLDS | Time of flight alone measures distance. |
| PD07 | P7 (anchor) | HOLDS | One-way travel time gives distance. |
| PD08 | P8 (gate) | FALSIFIED-naive | d = int Theta gamma dM recovers physical path length in heterogeneous media from delays alone. |
| PD09 | P4 (gate) | FALSIFIED-naive | The nuisance-efficient metric is canonical and continuous. |
| PD10 | P5 (gate) | FALSIFIED-naive | A flat constant Fisher metric in displacement coordinates is Euclidean up to scale. |
| PD11 | P9 (gate) | FALSIFIED-naive | One anchored unit length calibrates a rank-one channel at all distances. |
| PD12 | P5 (imported) | HOLDS | Any monotone coordinate of displacement is an admissible length scale. |
| PD13 | P8 (gate) | FALSIFIED-naive | Cone + one clock determine physical distances. |
| PD14 | P8 (gate, R23) | HOLDS | A locally calibrated unit globalizes automatically. |
| PD15 | P6/P7 (no-go + anchor) | FALSIFIED-naive | A minimal thermodynamic calibration (k_B T) fixes the physical length unit. |
| PD16 | P7 (anchor) | HOLDS | Any physical calibration constant closes the unit problem. |
| PD17 | P6 (no-go) | HOLDS | Thermodynamic (Fisher-Rao) length supplies a physical unit. |
| PD18 | P6 (imported) | HOLDS | The statistical metric could hide a preferred physical normalization. |
| PD19 | P5 (gate) | FALSIFIED-naive | Flat RG geometry on a chart implies physical Euclidean geometry after one calibration. |
| PD20 | P10 (closure) | FALSIFIED-naive | One anchor per experiment converts RG length into metres. |

## Files
- `rg_physical_distance_attack.py` - the battery
- `rg_physical_distance_results.json` - machine-readable evidence (primary seed)
- `RG_-_Physical_Distance_Ladder.tex/.pdf` - Stratum 7 (rungs R30-R44) and the identification theorem

## Open (not attacked here, marked open on the ladder)
Stationary/non-static GR (radar vs proper distance with Shapiro delay, no canonical spatial metric),
quantum Fisher geometry, non-dominated and infinite-dimensional experiments, and real empirical data.
