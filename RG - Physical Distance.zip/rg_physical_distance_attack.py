#!/usr/bin/env python3
"""
RG Physical-Distance Hostile Attack Battery
===========================================
Target: the step "statistical experiment -> RG distance -> PHYSICAL distance (metre)".

Discipline
----------
* Every attack registers (a) a NAIVE claim that a hostile referee would try to break and
  (b) the SHARPENED claim that the ladder is allowed to keep.
* A check PASSES iff the observed numbers match the pre-registered prediction of the
  sharpened claim. For naive claims the prediction is "counterexample exists", and the
  counterexample itself is printed and stored (it is the evidence, not a failure).
* Deterministic seed. No fitted constants. Every tolerance is declared up front.

Run:  python3 rg_physical_distance_attack.py [--seed 20260928] [--out results.json]
"""
import argparse, json, math, sys, time
import numpy as np
from scipy import integrate, optimize
import sympy as sp

TOL = 1e-9          # algebraic identities
NUM_TOL = 1e-6      # quadrature-based identities
RESULTS = []
MUT = {}            # mutation switches used ONLY by the canary run (--canary); empty in a real run


def _finite(obj):
    """Hostile guard: NaN/inf anywhere in the evidence fails the check (NaN comparisons are False
    and would otherwise let max()/min() gates pass silently)."""
    if isinstance(obj, dict):
        return all(_finite(v) for v in obj.values())
    if isinstance(obj, (list, tuple)):
        return all(_finite(v) for v in obj)
    if isinstance(obj, float):
        return math.isfinite(obj)
    return True


def register(aid, rung, naive, sharpened, passed, evidence, verdict):
    if not _finite(evidence):
        passed, verdict = False, "NONFINITE"
    RESULTS.append(dict(id=aid, rung=rung, naive_claim=naive, sharpened_claim=sharpened,
                        passed=bool(passed), verdict=verdict, evidence=evidence))
    flag = "PASS" if passed else "FAIL"
    print(f"[{flag}] {aid:5s} {verdict:12s} {sharpened[:88]}")


def f(x):  # json-friendly float
    return float(np.round(x, 15))

# ---------------------------------------------------------------- location families
FAMILIES = {
    # name: (pdf(y), analytic Fisher info per sample for unit scale)
    "gaussian": (lambda y: np.exp(-y**2/2)/np.sqrt(2*np.pi), 1.0),
    "laplace":  (lambda y: 0.5*np.exp(-np.abs(y)), 1.0),
    "logistic": (lambda y: 0.25/np.cosh(0.5*y)**2, 1.0/3.0),   # overflow-safe form
    "student3": (lambda y: (6*np.sqrt(3))/(np.pi*(3+y**2)**2)*1.0, 4.0/6.0),
    "cauchy":   (lambda y: 1.0/(np.pi*(1+y**2)), 0.5),
}


def fisher_location_numeric(pdf):
    h = 1e-5
    def integrand(y):
        p = pdf(y)
        if p < 1e-300:
            return 0.0
        dp = (pdf(y+h)-pdf(y-h))/(2*h)
        return dp*dp/p
    val = 0.0
    for a, b in [(-np.inf, -1), (-1, 0), (0, 1), (1, np.inf)]:
        val += integrate.quad(integrand, a, b, limit=400)[0]
    return val


def bhattacharyya(pdf, a):
    g = lambda y: np.sqrt(pdf(y)*pdf(y-a))
    return integrate.quad(g, -np.inf, np.inf, limit=400)[0]

# ======================================================================= ATTACKS

def PD01_scale_noninvariance(rng):
    """d_RG = sqrt(N)*dx/sigma for Gaussian location. Same physical dx, different d_RG;
    same d_RG, different physical dx."""
    dx = 1.0
    grid = [(N, s) for N in (1, 10, 100, 10000) for s in (0.01, 0.1, 1.0)]
    d = {f"N={N},sigma={s}": f(np.sqrt(N)*dx/s) for N, s in grid}
    spread = max(d.values())/min(d.values())
    # equal d_RG, different physical displacement
    dA = np.sqrt(4)*1.0/1.0   # N=4, sigma=1, dx=1
    dB = np.sqrt(1)*2.0/1.0   # N=1, sigma=1, dx=2
    passed = spread > 1e3 and abs(dA-dB) < TOL
    register("PD01", "P2 (no-go)",
             "RG distance d_RG equals physical distance up to a universal constant.",
             "d_RG is experiment-relative: for fixed physical displacement it scales as sqrt(N)/sigma; "
             "equal d_RG can correspond to different physical displacements.",
             passed, dict(d_RG_for_dx_1m=d, spread_factor=f(spread),
                          equal_dRG_pair=dict(A="N=4,sigma=1,dx=1", B="N=1,sigma=1,dx=2", dA=f(dA), dB=f(dB))),
             "FALSIFIED-naive")


def PD02_garbling_nogo(rng):
    """No function F with F(d_RG) = physical distance on a garbling-closed class."""
    N, s = 1, 1.0
    d_of = lambda dx, tau: np.sqrt(N)*dx/np.sqrt(s**2+tau**2)
    d0 = d_of(1.0, 0.0)
    tau_star = optimize.brentq(lambda t: d_of(2.0, t)-d0, 0.0, 100.0)
    taus = np.linspace(0, 50, 2001)
    mono = np.all(np.diff(d_of(1.0, taus)) < 0)
    passed = abs(tau_star-np.sqrt(3)) < 1e-9 and mono and d_of(1.0, 1e6) < 1e-5
    register("PD02", "P2 (no-go)",
             "Some calibration function F turns RG distance into physical distance.",
             "No-go: on any class closed under additive-noise garbling, d_RG takes the same value for "
             "physically different displacements, so no F(d_RG) is a physical distance.",
             passed, dict(dx1_tau0_dRG=f(d0), dx2_tau_star=f(tau_star), dx2_dRG=f(d_of(2.0, tau_star)),
                          strictly_decreasing=bool(mono), limit_tau_1e6=f(d_of(1.0, 1e6))),
             "FALSIFIED-naive")


def PD03_ratio_invariance(rng):
    """Intrinsic Fisher length of a translation-covariant family is sqrt(N*J)*|dx|:
    ratios d(a)/d(b)=|a|/|b| independent of N, family, noise scale, garbling."""
    ev = {}
    worst = 0.0
    for name, (pdf, J_exact) in FAMILIES.items():
        J = fisher_location_numeric(pdf)
        ev[name] = dict(J_numeric=f(J), J_exact=f(J_exact), rel_err=f(abs(J-J_exact)/J_exact))
        worst = max(worst, abs(J-J_exact)/J_exact)
    # NON-tautological test 1: Monte-Carlo score variance at several parameter values (covariance
    # must make it theta-independent). Samples drawn by inverse CDF; score by finite difference.
    samplers = {"gaussian": lambda u: __import__("scipy").stats.norm.ppf(u),
                "logistic": lambda u: np.log(u/(1-u)),
                "cauchy": lambda u: np.tan(np.pi*(u-0.5))}
    mc = {}
    rmax = 0.0
    for name, samp in samplers.items():
        pdf = FAMILIES[name][0]
        vals = []
        for th in (-3.0, 0.0, 2.5, 7.0):
            y = th + samp(rng.uniform(1e-12, 1-1e-12, 400000))
            h = 1e-5
            sc = (np.log(pdf(y-th-h)) - np.log(pdf(y-th+h)))/(2*h)   # d/dtheta log p(y-theta)
            vals.append(float(np.mean(sc**2)))
        mc[name] = [f(v) for v in vals]
        rmax = max(rmax, (max(vals)-min(vals))/np.mean(vals))
    # NON-tautological test 2 (control): a family WITHOUT translation covariance (Poisson rate theta)
    # has metric 1/theta; equal parameter steps get unequal RG lengths.
    dpois = lambda a, b: 2*abs(np.sqrt(b)-np.sqrt(a))
    pois_steps = [f(dpois(1, 2)), f(dpois(2, 3)), f(dpois(10, 11))]
    ev_extra = dict(mc_fisher_at_theta_m3_0_2p5_7=mc, mc_max_rel_spread=f(rmax),
                    poisson_control_equal_steps_lengths=pois_steps)
    passed = worst < 1e-5 and rmax < 0.03 and (pois_steps[0]-pois_steps[2]) > 0.5
    register("PD03", "P5 (holds)",
             "Only Gaussian location experiments give distance ratios equal to displacement ratios.",
             "For every regular translation-covariant family the Fisher metric is theta-independent, so intrinsic "
             "RG length ratios equal displacement ratios for any N, noise scale, family; without covariance "
             "(Poisson control) equal parameter steps get unequal lengths: covariance does the work.",
             passed, dict(fisher_per_family=ev, **ev_extra), "HOLDS")


def PD04_intrinsic_vs_chordal(rng):
    """Finite-separation distinguishability (Bhattacharyya angle) is NOT linear in dx and is
    family dependent; only the intrinsic (infinitesimal, integrated) length is."""
    ev = {}
    viol = []
    for name, (pdf, J) in FAMILIES.items():
        ang = lambda a: 2*np.arccos(min(1.0, bhattacharyya(pdf, a)))
        a = 1.0
        r = ang(2*a)/ang(a)
        sat = ang(200.0)
        ev[name] = dict(chordal_ratio_2a_over_a=f(r), intrinsic_ratio=2.0, angle_at_200=f(sat))
        viol.append(abs(r-2.0))
    passed = min(viol) > 1e-3 and all(v["angle_at_200"] <= np.pi+1e-9 for v in ev.values())
    register("PD04", "P3 (boundary)",
             "RG distance is the operational distinguishability between two displaced sources.",
             "Boundary: intrinsic length is additive; chordal distinguishability (Hellinger/Bhattacharyya "
             "angle) saturates at pi and is family dependent. Physical distance may only be read from "
             "the intrinsic length (or from small-step concatenation), never from a finite divergence.",
             passed, dict(per_family=ev), "FALSIFIED-naive")


def PD05_dilation_fibre(rng):
    """Readout in instrument units u = y/s with s unknown: law depends on (x/s, sigma/s);
    the dilation generator (x, sigma, s) is an exact Fisher null direction."""
    worst_null = 0.0; ranks = []
    for _ in range(200):
        x, sig, s = rng.uniform(0.5, 3), rng.uniform(0.1, 2), rng.uniform(0.1, 10)
        # u ~ N(x/s, (sig/s)^2): Fisher in natural (m, v=std) is diag(1/v^2, 2/v^2)
        m, v = x/s, sig/s
        Jac = np.array([[1/s, 0, -x/s**2], [0, 1/s, -sig/s**2]])
        I = Jac.T @ np.diag([1/v**2, 2/v**2]) @ Jac
        ranks.append(np.linalg.matrix_rank(I, tol=1e-10*np.linalg.norm(I)))
        gen = np.array([x, sig, s]); gen /= np.linalg.norm(gen)
        worst_null = max(worst_null, gen @ I @ gen / np.linalg.norm(I))
    passed = all(r == 2 for r in ranks) and worst_null < 1e-12
    register("PD05", "P6 (no-go)",
             "A sufficiently rich statistical experiment determines the metre internally.",
             "No-go: when the readout unit is not anchored, global dilation (x,sigma,s)->(kx,k sigma,k s) "
             "is an exact kernel-groupoid arrow; the physical unit lies in the observational fibre.",
             passed, dict(fisher_rank_all=sorted(set(int(r) for r in ranks)), max_dilation_quadratic_form=f(worst_null)),
             "HOLDS")


def PD06_anchor_breaks_dilation(rng):
    """Two-way time of flight counted in Cs cycles: k ~ N(2 d nu / v, sk^2).
    With v, nu free: rank 1 of 3. With v=c, nu=Delta nu_Cs exact (SI 2019): d identified in metres.
    Medium with unknown v: (d, v) dilation survives."""
    c = 299792458.0; nu = 9192631770.0
    d, sk = 12.345, 0.3
    grad = lambda d_, v_, n_: np.array([2*n_/v_, -2*d_*n_/v_**2, 2*d_/v_])
    g = grad(d, c, nu)
    I_full = np.outer(g, g)/sk**2
    rank_full = np.linalg.matrix_rank(I_full, tol=1e-12*np.linalg.norm(I_full))
    I_d = (2*nu/c)**2/sk**2
    L_unit = c/nu
    # medium: v unknown, nu fixed
    gm = grad(d, 1480.0, nu)[:2]; Im = np.outer(gm, gm)
    null = np.array([d, 1480.0]); null /= np.linalg.norm(null)
    medium_null = null @ Im @ null/np.linalg.norm(Im)
    passed = rank_full == 1 and I_d > 0 and medium_null < 1e-12
    register("PD06", "P7 (anchor)",
             "Time of flight alone measures distance.",
             "Time of flight identifies distance only after a speed and a clock frequency are fixed "
             "independently; with c and Delta nu_Cs exact by SI definition the length unit c/Delta nu_Cs "
             "is non-circular; in a medium with unanchored v the (d,v) dilation fibre persists.",
             passed, dict(rank_free_v_nu=int(rank_full), fisher_d_when_anchored=f(I_d),
                          length_unit_c_over_nuCs_m=f(L_unit), medium_dilation_form=f(medium_null)),
             "HOLDS")


def PD07_one_way_conventionality(rng):
    """Reichenbach epsilon: out-leg d/c_+ with c_+ = c/(2 eps), back-leg d/c_- with c_- = c/(2(1-eps)).
    Round-trip law is independent of eps; one-way data carry eps only through a synchronization
    convention. Hence the factor 1/2 in d = c*tau/2 is forced, not fitted."""
    c = 1.0; d = 3.7
    eps = rng.uniform(0.05, 0.95, 500)
    rt = d*2*eps/c + d*2*(1-eps)/c
    spread = rt.max()-rt.min()
    # Fisher of eps from round-trip Gaussian timing = (d rt/d eps)^2 / s^2 = 0
    drt = 2*d/c - 2*d/c
    passed = spread < 1e-12 and drt == 0.0
    register("PD07", "P7 (anchor)",
             "One-way travel time gives distance.",
             "Only the round-trip (radar) time is convention free: epsilon has zero Fisher information in "
             "round-trip data; the two-way factor gamma=1/2 is forced by the epsilon-gauge.",
             passed, dict(round_trip_spread_over_eps=f(spread), fisher_eps_round_trip=f(drt**2)),
             "HOLDS")


def PD08_heterogeneous_tomography(rng):
    """(a) 1D slab: travel time T=int dx/v cannot separate thickness and profile.
    (b) 2D straight-ray tomography on an n x n slowness grid: ray-family rank deficit = invisible
    slowness patterns (blind sector); path diversity reduces but does not remove the gauge."""
    L1, v1 = 10.0, 1500.0
    L2, v2 = 20.0, 3000.0
    T1, T2 = L1/v1, L2/v2
    # piecewise profile with the same travel time
    prof = [(4.0, 1000.0), (6.0, 6.0/(T1-0.004))]
    T3 = sum(l/v for l, v in prof)
    n = 4
    def rays(kind):
        rows = []
        for i in range(n):
            if "h" in kind:
                r = np.zeros((n, n)); r[i, :] = 1; rows.append(r.ravel())
            if "v" in kind:
                r = np.zeros((n, n)); r[:, i] = 1; rows.append(r.ravel())
        if "d" in kind:
            for k in range(-(n-1), n):
                r = np.zeros((n, n))
                for i in range(n):
                    j = i+k
                    if 0 <= j < n: r[i, j] = np.sqrt(2)
                rows.append(r.ravel())
                r = np.zeros((n, n))
                for i in range(n):
                    j = n-1-i+k
                    if 0 <= j < n: r[i, j] = np.sqrt(2)
                rows.append(r.ravel())
        return np.array(rows)
    nulls = {}
    for kind in ("h", "hv", "hvd"):
        A = rays(kind)
        nulls[kind] = int(n*n - np.linalg.matrix_rank(A))
    passed = abs(T1-T2) < TOL and abs(T3-T1) < 1e-12 and nulls["h"] > nulls["hv"] > nulls["hvd"] > 0
    register("PD08", "P8 (gate)",
             "d = int Theta gamma dM recovers physical path length in heterogeneous media from delays alone.",
             "Delay data identify only integrated slowness; thickness/profile trade off exactly. Recovering "
             "the profile needs path diversity (tomography) and still leaves an invisible slowness sector "
             "unless ray coverage is complete.",
             passed, dict(slab_T=[f(T1), f(T2), f(T3)], nullity_by_ray_family=nulls, grid=f"{n}x{n}"),
             "FALSIFIED-naive")


def PD09_nuisance_conventions(rng):
    """(a) g_eff invariant under nu' = nu + f(q)  (holds)
       (b) g_eff changes under target redefinition q' = q + b nu  (declared convention)
       (c) g_eff discontinuous at a nuisance rank wall (pseudoinverse), repaired by bounded nuisance."""
    a, rho = 2.0, 0.8
    def I_eps(eps):
        A = np.array([[np.sqrt(a)*rho, np.sqrt(eps)], [np.sqrt(a)*np.sqrt(1-rho**2), 0.0]])
        return A.T @ A
    def geff(I, lam=0.0):
        Inn = I[1, 1] + lam
        return I[0, 0] - I[0, 1]*(1/Inn if Inn > 1e-300 else 0.0)*I[1, 0]
    # (a),(b)
    maxa = 0.0; minb = np.inf
    for _ in range(500):
        M = rng.normal(size=(3, 2)); I = M.T @ M
        k = rng.normal()
        Ta = np.array([[1, 0], [k, 1]])          # nu' = nu + k q  -> coords (q, nu') ; theta = Ta^-1 theta'
        Ja = np.linalg.inv(Ta); Ia = Ja.T @ I @ Ja
        maxa = max(maxa, abs(geff(Ia)-geff(I))/geff(I))
        Tb = np.array([[1, k], [0, 1]])          # q' = q + k nu
        Jb = np.linalg.inv(Tb); Ib = Jb.T @ I @ Jb
        minb = min(minb, abs(geff(Ib)-geff(I))/geff(I) + (0 if abs(k) > 0.05 else 1))
    eps_list = [1e-2, 1e-4, 1e-8, 1e-12]
    lim = [geff(I_eps(e)) for e in eps_list]
    at_wall = geff(I_eps(0.0))
    reg = [geff(I_eps(e), lam=1.0) for e in eps_list]
    passed = (maxa < 1e-10 and minb > 1e-8 and abs(lim[-1]-a*(1-rho**2)) < 1e-6
              and abs(at_wall-a) < 1e-12 and abs(reg[-1]-a) < 1e-6)
    register("PD09", "P4 (gate)",
             "The nuisance-efficient metric is canonical and continuous.",
             "g_eff is invariant under nuisance reparametrization nu->nu+f(q) but depends on the declared "
             "target coordinate, and jumps at a nuisance rank wall: lim g_eff = a(1-rho^2) != a = g_eff(wall). "
             "Continuity is restored only by a declared bound/prior on the nuisance.",
             passed, dict(max_rel_change_nuisance_reparam=f(maxa), min_rel_change_target_redef=f(minb),
                          geff_limit_eps=dict(zip([str(e) for e in eps_list], [f(x) for x in lim])),
                          geff_at_wall=f(at_wall), geff_with_bounded_nuisance=[f(x) for x in reg]),
             "FALSIFIED-naive")


def PD10_isotropy_and_schur(rng):
    """Invariant symmetric bilinear forms under a covariance group: dimension of solution space.
    Translation-only: all constant SPD (dim 3 in 2D, 6 in 3D). C2: dim 3. C4 (2D): dim 1.
    3D C4 about z: dim 2. 3D tetrahedral (irreducible): dim 1.  Anisotropic noise breaks angles."""
    def inv_dim(gens, n):
        basis = []
        for i in range(n):
            for j in range(i, n):
                E = np.zeros((n, n)); E[i, j] = E[j, i] = 1; basis.append(E)
        rows = []
        for R in gens:
            rows.append(np.array([(R.T @ E @ R - E).ravel() for E in basis]).T)
        if not rows:
            return len(basis)
        A = np.vstack(rows)
        return int(len(basis) - np.linalg.matrix_rank(A, tol=1e-10))
    rot2 = lambda t: np.array([[np.cos(t), -np.sin(t)], [np.sin(t), np.cos(t)]])
    Rz = np.array([[0, -1, 0], [1, 0, 0], [0, 0, 1.0]])
    C3 = np.array([[0, 0, 1], [1, 0, 0], [0, 1, 0.0]])       # cyclic axis permutation
    D = np.diag([1, -1, -1.0])                               # 180 deg about x
    dims = {"2D translations only": inv_dim([], 2), "2D C2": inv_dim([rot2(np.pi)], 2),
            "2D C4": inv_dim([rot2(np.pi/2)], 2), "2D SO(2) sample": inv_dim([rot2(0.7)], 2),
            "3D translations only": inv_dim([], 3), "3D C4 about z": inv_dim([Rz], 3),
            "3D tetrahedral <C3,D>": inv_dim([C3, D], 3)}
    # anisotropic noise: physically orthogonal unit displacements
    S = np.diag(MUT.get("pd10_S", [1.0, 9.0])); Ginv = np.linalg.inv(S)
    R = rot2(np.pi/5); u, v = R @ np.array([1, 0.0]), R @ np.array([0, 1.0])
    cosang = u @ Ginv @ v/np.sqrt((u @ Ginv @ u)*(v @ Ginv @ v))
    ang = np.degrees(np.arccos(cosang))
    passed = (dims["2D translations only"] == 3 and dims["2D C2"] == 3 and dims["2D C4"] == 1
              and dims["3D C4 about z"] == 2 and dims["3D tetrahedral <C3,D>"] == 1 and abs(ang-90) > 1)
    register("PD10", "P5 (gate)",
             "A flat constant Fisher metric in displacement coordinates is Euclidean up to scale.",
             "Only if the experiment is covariant under a rotation group acting irreducibly: then every "
             "invariant metric is lambda*delta (Schur). Translation covariance alone leaves an SPD family; "
             "anisotropic noise turns physically orthogonal displacements into RG angle != 90 deg.",
             passed, dict(invariant_form_dimension=dims, anisotropic_RG_angle_deg=f(ang)), "FALSIFIED-naive")


def PD11_beckman_quarles_rank_one(rng):
    """1D: phi(x)=x+0.1 sin(2 pi x) preserves every unit distance but not distance 0.5.
    2D: the same construction breaks unit distances in oblique directions (BQ rigidity)."""
    phi = lambda x: x + 0.1*np.sin(2*np.pi*x)
    xs = rng.uniform(-50, 50, 5000)
    unit_err = np.max(np.abs(np.abs(phi(xs+1)-phi(xs))-1))
    half_err = np.max(np.abs(np.abs(phi(xs+0.5)-phi(xs))-0.5))
    P = lambda p: np.stack([phi(p[:, 0]), p[:, 1]], 1)
    pts = rng.uniform(-10, 10, (5000, 2)); th = rng.uniform(0, 2*np.pi, 5000)
    q = pts + np.stack([np.cos(th), np.sin(th)], 1)
    err2 = np.max(np.abs(np.linalg.norm(P(q)-P(pts), axis=1)-1))
    passed = unit_err < 1e-12 and half_err > 0.1 and err2 > 0.1
    register("PD11", "P9 (gate)",
             "One anchored unit length calibrates a rank-one channel at all distances.",
             "False in rank one: a unit-preserving non-isometry exists. In dimension >= 2 a map preserving "
             "all unit distances is an isometry (Beckman-Quarles), so one anchor suffices there; rank-one "
             "channels additionally need an additivity (concatenation) law.",
             passed, dict(rank1_unit_error=f(unit_err), rank1_half_error=f(half_err), rank2_unit_error=f(err2)),
             "FALSIFIED-naive")


def PD12_concatenation_forces_linearity(rng):
    """Cauchy/Hoelder: psi(a+b)=psi(a)+psi(b), psi monotone -> psi linear. Test nonlinear rulers."""
    cands = {"linear 2.5x": lambda a: 2.5*a, "cubic": lambda a: a**3, "sinh": np.sinh, "x+0.1sin": lambda a: a+0.1*np.sin(a)}
    a = rng.uniform(-2, 2, 4000); b = rng.uniform(-2, 2, 4000)
    defects = {k: f(np.max(np.abs(p(a+b)-p(a)-p(b)))) for k, p in cands.items()}
    passed = defects["linear 2.5x"] < 1e-12 and all(v > 1e-2 for k, v in defects.items() if k != "linear 2.5x")
    register("PD12", "P5 (imported)",
             "Any monotone coordinate of displacement is an admissible length scale.",
             "Only additive (hence linear, unique up to one positive constant) representations of operational "
             "concatenation are length scales; all other monotone rulers violate additivity.",
             passed, dict(additivity_defect=defects), "HOLDS")


def PD13_cone_clock_radar(rng):
    """1+1 static conformally flat metric ds^2 = W(x)^2(-dt^2+dx^2).
    Null rays are Omega-independent. Clock at x=0 with W(0)=1. Radar distance from the clock is
    independent of W elsewhere; proper (rod) distance int_0^X W dx is not. Frequency ratio of
    exchanged signals W(X)/W(0) detects the discrepancy (clock-comparison gate)."""
    X = 2.0
    tests = []
    for _ in range(300):
        k1, k2 = rng.uniform(-0.4, 0.4, 2)
        W = lambda x: np.exp(k1*x + k2*x**2 - 0.0)  # W(0)=1
        radar = 0.5*(2*X)*W(0.0)                     # c=1, proper round-trip time at clock /2
        proper = integrate.quad(W, 0, X)[0]
        red = W(X)/W(0.0)
        tests.append((radar, proper, red))
    tests = np.array(tests)
    radar_spread = np.ptp(tests[:, 0])
    mismatch = np.max(np.abs(tests[:, 0]-tests[:, 1]))
    # constant W (no redshift): agreement
    agree = abs(0.5*2*X*1.0 - X*1.0)
    # correlation: mismatch vanishes iff redshift ratio ~ 1 on path (here both driven by k1,k2)
    passed = radar_spread < 1e-12 and mismatch > 0.1 and agree < 1e-12
    register("PD13", "P8 (gate)",
             "Cone + one clock determine physical distances.",
             "Cone + one clock + exact c fix RADAR distance non-circularly (null rays are conformally "
             "invariant), but radar distance equals rod distance only where the conformal factor is constant, "
             "detected by a trivial exchanged-frequency ratio (no redshift). Otherwise a scale field remains.",
             passed, dict(radar_spread_over_300_factors=f(radar_spread), max_radar_minus_rod=f(mismatch),
                          constant_factor_agreement=f(agree), example_row=[f(v) for v in tests[0]]),
             "FALSIFIED-naive")


def PD14_weyl_scale_holonomy(rng):
    """Unit transported by Weyl 1-form phi: ratio exp(oint phi). Exact phi -> 1; curl -> path dependence."""
    def loop_ratio(phi, R=1.0, n=4000):
        t = np.linspace(0, 2*np.pi, n+1)
        xs, ys = R*np.cos(t), R*np.sin(t)
        dx, dy = np.diff(xs), np.diff(ys)
        xm, ym = 0.5*(xs[1:]+xs[:-1]), 0.5*(ys[1:]+ys[:-1])
        px, py = phi(xm, ym)
        return np.exp(np.sum(px*dx+py*dy))
    k = 0.2
    exact = lambda x, y: (2*x*y + 0.3, x**2 - 0.1)      # d(x^2 y + 0.3x - 0.1y)
    curl = (lambda x, y: (-k*y, k*x)) if not MUT.get("pd14_exact") else (lambda x, y: (2*x*y, x**2))                     # d phi = 2k dx^dy
    r_exact = loop_ratio(exact); r_curl = loop_ratio(curl)
    pred = np.exp(2*k*np.pi)
    passed = abs(r_exact-1) < 1e-6 and abs(r_curl-pred)/pred < 1e-5
    register("PD14", "P8 (gate, R23)",
             "A locally calibrated unit globalizes automatically.",
             "A unit globalizes iff the scale cocycle is exact (zero Weyl holonomy); a curl produces a "
             "second-clock effect exp(2k*Area) and no global metre exists.",
             passed, dict(exact_loop_ratio=f(r_exact), curl_loop_ratio=f(r_curl), predicted=f(pred)), "HOLDS")


def PD15_buckingham_length(rng):
    """Does a set of dimensional constants admit a pure length? Exact rational linear algebra.
    Dimensions over (M, L, T, Theta)."""
    D = {"c": (0, 1, -1, 0), "nu": (0, 0, -1, 0), "h": (1, 2, -1, 0), "kB": (1, 2, -2, -1),
         "T": (0, 0, 0, 1), "m": (1, 0, 0, 0), "g": (0, 1, -2, 0), "e_charge_free": (0, 0, 0, 0)}
    target = sp.Matrix([0, 1, 0, 0])
    def length_from(keys):
        A = sp.Matrix([[D[k][i] for k in keys] for i in range(4)])
        x = sp.symbols(f"x0:{len(keys)}")
        sol = sp.linsolve((A, target), *x)
        if sol == sp.EmptySet:
            return None
        s = list(sol)[0]
        s = [si.subs({xi: 0 for xi in x}) for si in s]
        return {k: str(v) for k, v in zip(keys, s) if v != 0}
    sets = {"thermo {kB,T,m}": MUT.get("pd15_thermo", ["kB", "T", "m"]), "clock+speed {c,nu}": ["c", "nu"],
            "Compton {h,m,c}": ["h", "m", "c"], "thermal de Broglie {h,m,kB,T}": ["h", "m", "kB", "T"],
            "barometric {kB,T,m,g}": ["kB", "T", "m", "g"], "clock only {nu}": ["nu"],
            "action+energy {h,kB,T}": ["h", "kB", "T"]}
    out = {k: length_from(v) for k, v in sets.items()}
    passed = (out["thermo {kB,T,m}"] is None and out["clock only {nu}"] is None and
              out["action+energy {h,kB,T}"] is None and out["clock+speed {c,nu}"] is not None and
              out["thermal de Broglie {h,m,kB,T}"] is not None)
    register("PD15", "P6/P7 (no-go + anchor)",
             "A minimal thermodynamic calibration (k_B T) fixes the physical length unit.",
             "Pure thermodynamics {k_B, T, m} contains no length (only a velocity sqrt(k_B T/m)); a length "
             "requires an action (h) or a clock+speed pair (c, nu). k_B T calibrates energy, not metres.",
             passed, dict(length_exponents=out), "FALSIFIED-naive")


def PD16_traceability_cycles(rng):
    """Anchor routes as dependency graphs; a route is non-circular iff no node depends on 'metre'
    except through SI-defined constants. SI 2019 exact: Delta nu_Cs, c, h, e, k_B, N_A, K_cd."""
    DEFINED = {"nuCs", "c", "h", "e", "kB", "NA"}
    routes = {
        "radar: c + Cs clock": {"metre": ["c", "nuCs", "count"]},
        "thermal de Broglie: h, kB, T(Johnson), m(h/m interferometry)": {
            "metre": ["h", "kB", "T", "m_atom", "count"], "T": ["kB", "h", "e", "count"],
            "m_atom": ["h", "laser_wavelength", "count"], "laser_wavelength": ["c", "nuCs", "count"]},
        "equipartition: <x^2>=kB T/kappa": {"metre": ["kB", "T", "kappa"], "T": ["kB", "h", "e", "count"],
                                              "kappa": ["force", "displacement"], "displacement": ["metre"],
                                              "force": ["h", "nuCs", "c", "count"]},
        "barometric: kB T/(m g)": {"metre": ["kB", "T", "m_atom", "g"], "g": ["metre", "nuCs"],
                                   "T": ["kB", "h", "e", "count"], "m_atom": ["h", "laser_wavelength", "count"],
                                   "laser_wavelength": ["c", "nuCs", "count"]},
        "sound ranging: v_sound * tau": {"metre": ["v_sound", "nuCs"], "v_sound": ["metre", "nuCs"]},
    }
    def circular(G):
        # does 'metre' reach itself?
        seen, stack = set(), list(G.get("metre", []))
        while stack:
            n = stack.pop()
            if n == "metre":
                return True
            if n in seen or n in DEFINED or n == "count":
                continue
            seen.add(n); stack.extend(G.get(n, []))
        return False
    res = {k: ("CIRCULAR" if circular(G) else "non-circular") for k, G in routes.items()}
    passed = (res["radar: c + Cs clock"] == "non-circular" and
              res["thermal de Broglie: h, kB, T(Johnson), m(h/m interferometry)"] == "non-circular" and
              res["equipartition: <x^2>=kB T/kappa"] == "CIRCULAR" and
              res["barometric: kB T/(m g)"] == "CIRCULAR" and res["sound ranging: v_sound * tau"] == "CIRCULAR")
    register("PD16", "P7 (anchor)",
             "Any physical calibration constant closes the unit problem.",
             "Only routes whose dependency graph terminates in SI-defined constants and counts are "
             "non-circular (radar with c+Cs; thermal de Broglie with h,k_B). Routes through a measured "
             "stiffness, g, or medium speed silently re-import the metre.",
             passed, dict(route_status=res, si_defined=sorted(DEFINED)), "HOLDS")


def PD17_thermodynamic_length_unit_blind(rng):
    """Canonical family p_beta(E) ~ exp(-beta E) on a discrete spectrum. Fisher metric in beta is Var(E).
    Thermodynamic length int sqrt(Var E) d beta is invariant under energy-unit change E->aE, beta->beta/a."""
    Es = rng.uniform(0, 5, 12)
    def L(Ev, b0, b1, n=4001):
        bs = np.linspace(b0, b1, n)
        vals = []
        for b in bs:
            w = np.exp(-b*(Ev-Ev.min())); p = w/w.sum()
            m = p @ Ev; vals.append(np.sqrt(p @ (Ev-m)**2))
        return integrate.trapezoid(vals, bs)
    base = L(Es, 0.2, 3.0)
    devs = []
    for a in (1e-3, 0.5, 7.0, 1e4):
        devs.append(abs(L(a*Es, 0.2/a, 3.0/a)-base)/base)
    passed = max(devs) < 1e-6
    register("PD17", "P6 (no-go)",
             "Thermodynamic (Fisher-Rao) length supplies a physical unit.",
             "Thermodynamic length is dimensionless and invariant under energy-unit rescaling; it can bound "
             "dissipation in units of k_B T but carries no length or energy unit by itself.",
             passed, dict(base_length=f(base), max_rel_dev_under_unit_change=f(max(devs))), "HOLDS")


def PD18_cencov_scale(rng):
    """Fisher metric on the simplex is invariant under congruent Markov embeddings; so is c*Fisher.
    The Euclidean metric on probabilities is not. Statistics fixes geometry up to exactly one constant."""
    def fisher(p, u, v): return np.sum(u*v/p)
    def eucl(p, u, v): return np.sum(u*v)
    worstF = 0.0; worstE = 0.0
    for _ in range(500):
        k = int(rng.integers(3, 7)); p = rng.dirichlet(np.ones(k))
        u = rng.normal(size=k); u -= u.mean(); v = rng.normal(size=k); v -= v.mean()
        # congruent embedding: split outcome 0 into (t, 1-t)
        t = rng.uniform(0.05, 0.95)
        emb = lambda x: np.concatenate([[t*x[0], (1-t)*x[0]], x[1:]])
        worstF = max(worstF, abs(fisher(emb(p), emb(u), emb(v))-fisher(p, u, v)))
        worstE = max(worstE, abs(eucl(emb(p), emb(u), emb(v))-eucl(p, u, v)))
    passed = worstF < 1e-10 and worstE > 1e-3
    register("PD18", "P6 (imported)",
             "The statistical metric could hide a preferred physical normalization.",
             "Cencov: Markov-invariant metrics are c*Fisher with c>0 free; the free constant is a convention, "
             "so no statistical construction selects a unit.",
             passed, dict(fisher_embedding_defect=f(worstF), euclid_embedding_defect=f(worstE)), "HOLDS")


def PD19_flat_but_wrong_chart(rng):
    """Mean map mu(x,y)=(x + a y^2, y): Fisher metric J^T J / sigma^2 is flat (K=0 exactly) yet not
    constant in the physical coordinates; RG distance between physical points != lambda*Euclidean.
    'Euclidean in some chart' is not 'Euclidean in the physical chart'."""
    x, y, a = sp.symbols("x y a", real=True)
    mu = sp.Matrix([x + a*y**2, y])
    J = mu.jacobian([x, y]); g = sp.simplify(J.T*J)
    E, F, G = g[0, 0], g[0, 1], g[1, 1]
    # Brioschi formula
    Ex, Ey = sp.diff(E, x), sp.diff(E, y); Fx, Fy = sp.diff(F, x), sp.diff(F, y); Gx, Gy = sp.diff(G, x), sp.diff(G, y)
    Eyy, Gxx, Fxy = sp.diff(E, y, 2), sp.diff(G, x, 2), sp.diff(F, x, y)
    M1 = sp.Matrix([[-Eyy/2+Fxy-Gxx/2, Ex/2, Fx-Ey/2], [Fy-Gx/2, E, F], [Gy/2, F, G]])
    M2 = sp.Matrix([[0, Ey/2, Gx/2], [Ey/2, E, F], [Gx/2, F, G]])
    K = sp.simplify((M1.det()-M2.det())/(E*G-F**2)**2)
    av = 0.4
    P0, P1, P2 = np.array([0, 0.0]), np.array([0, 1.0]), np.array([0, 2.0])
    m = lambda p: np.array([p[0]+av*p[1]**2, p[1]])
    d01 = np.linalg.norm(m(P1)-m(P0)); d12 = np.linalg.norm(m(P2)-m(P1))
    passed = K == 0 and abs(d01-d12) > 0.1
    register("PD19", "P5 (gate)",
             "Flat RG geometry on a chart implies physical Euclidean geometry after one calibration.",
             "Flatness only says Euclidean in SOME chart. The physical chart must be supplied by the "
             "translation automorphisms of the experiment; with a nonlinear response map the metric is flat "
             "but equal physical steps receive unequal RG lengths.",
             passed, dict(gaussian_curvature=str(K), rg_len_equal_physical_steps=[f(d01), f(d12)]),
             "FALSIFIED-naive")


def PD20_calibration_transfer(rng):
    """End-to-end with a hostile twist. Experiment A: linear response (translation covariant).
    Experiment B: mildly nonlinear response mu(x)=x+0.02 x^2 (covariance broken, 1D metric still 'flat').
    Each is calibrated with ONE radar anchor; a SECOND held-out radar anchor must be predicted.
    A passes, B is rejected -> a single anchor is never self-validating."""
    c = 299792458.0; nu = 9192631770.0
    anchors = np.array([1.0, 15.0])                   # metres, known only via radar counts
    counts = 2*anchors*nu/c
    d_radar = c*counts/(2*nu)
    lam = lambda length_fn: length_fn(d_radar[0])/d_radar[0]
    A = lambda d: np.sqrt(100*1.0)/0.05*d                        # RG length from origin, linear
    kb = MUT.get("pd20_nonlin", 0.02)
    B = lambda d: np.sqrt(7/3)/0.8*(d + kb*d**2)               # RG length along nonlinear response
    lamA, lamB = lam(A), lam(B)
    errA = abs(A(d_radar[1])/lamA - d_radar[1])/d_radar[1]
    errB = abs(B(d_radar[1])/lamB - d_radar[1])/d_radar[1]
    raw = abs(A(d_radar[1]) - B(d_radar[1]))
    heldout_tol = 1e-3
    passed = errA < 1e-12 and errB > heldout_tol and raw > 1
    register("PD20", "P10 (closure)",
             "One anchor per experiment converts RG length into metres.",
             "Physical distance = RG length / lambda_E with lambda_E from one radar anchor ONLY if a held-out "
             "second anchor is predicted within tolerance; a covariance-breaking response passes the first anchor "
             "by construction and is caught only by the held-out one.",
             passed, dict(heldout_rel_err_A=f(errA), heldout_rel_err_B=f(errB), tolerance=heldout_tol,
                          lambdaA=f(lamA), lambdaB=f(lamB), raw_rg_disagreement=f(raw)), "FALSIFIED-naive")


ATTACKS = [PD01_scale_noninvariance, PD02_garbling_nogo, PD03_ratio_invariance, PD04_intrinsic_vs_chordal,
           PD05_dilation_fibre, PD06_anchor_breaks_dilation, PD07_one_way_conventionality,
           PD08_heterogeneous_tomography, PD09_nuisance_conventions, PD10_isotropy_and_schur,
           PD11_beckman_quarles_rank_one, PD12_concatenation_forces_linearity, PD13_cone_clock_radar,
           PD14_weyl_scale_holonomy, PD15_buckingham_length, PD16_traceability_cycles,
           PD17_thermodynamic_length_unit_blind, PD18_cencov_scale, PD19_flat_but_wrong_chart,
           PD20_calibration_transfer]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=20260928)
    ap.add_argument("--out", default="rg_physical_distance_results.json")
    ap.add_argument("--canary", action="store_true",
                    help="mutation test: sabotage four attacks and require that exactly those checks FAIL")
    args = ap.parse_args()
    if args.canary:
        return canary(args.seed)
    t0 = time.time()
    print(f"RG physical-distance hostile battery, seed {args.seed}\n")
    for atk in ATTACKS:
        rng = np.random.default_rng([args.seed, ATTACKS.index(atk)])   # per-attack stream: reorder-proof
        try:
            atk(rng)
        except Exception as ex:  # an exception is a failed check, never silently skipped
            register(atk.__name__.split("_")[0], "?", "?", f"EXCEPTION: {ex!r}", False, {}, "ERROR")
    n_pass = sum(r["passed"] for r in RESULTS)
    summary = dict(seed=args.seed, n_checks=len(RESULTS), n_pass=n_pass,
                   naive_claims_falsified=sum(r["verdict"] == "FALSIFIED-naive" and r["passed"] for r in RESULTS),
                   runtime_s=round(time.time()-t0, 2), numpy=np.__version__, sympy=sp.__version__)
    with open(args.out, "w") as fh:
        json.dump(dict(summary=summary, results=RESULTS), fh, indent=2)
    print(f"\n{n_pass}/{len(RESULTS)} registered checks pass; "
          f"{summary['naive_claims_falsified']} naive claims falsified with explicit counterexamples.")
    sys.exit(0 if n_pass == len(RESULTS) else 1)


def canary(seed):
    """A battery that cannot fail is worthless. Each mutation removes the structure a check relies on;
    the corresponding check must then FAIL, and every other check must still PASS."""
    muts = {"PD10": {"pd10_S": [1.0, 1.0]},            # isotropic noise: no angle counterexample
            "PD15": {"pd15_thermo": ["kB", "T", "m", "h"]},  # smuggle h into 'pure thermodynamics'
            "PD20": {"pd20_nonlin": 0.0},              # B made linear: held-out anchor no longer rejects
            "PD14": {"pd14_exact": True}}              # curl removed: no holonomy
    ok = True
    for target, m in muts.items():
        RESULTS.clear(); MUT.clear(); MUT.update(m)
        print(f"--- canary: mutate {target} with {m}")
        for atk in ATTACKS:
            atk(np.random.default_rng([seed, ATTACKS.index(atk)]))
        failed = sorted(r["id"] for r in RESULTS if not r["passed"])
        good = failed == [target]
        ok &= good
        print(f"    failed checks: {failed}  ->  {'CAUGHT' if good else 'NOT CAUGHT'}")
    MUT.clear()
    print("\nCANARY RESULT:", "all mutations caught" if ok else "BATTERY TOO WEAK")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
