# Resolution Geometry — Lock Conclusion: falsification battery

Runnable numerical battery for the paper
**"Resolution Geometry: The Elimination Verdict and the Non-Triviality of the Lock."**

The battery re-derives and **asserts** the paper's load-bearing claims. It is a
falsification harness: if any claim were false, the corresponding test prints `FAIL`
and the process exits with a nonzero code.

## Run

```
python3 battery.py
```

Requires only `numpy`. Blocks are `p = q = 3`. Seeds are fixed
(`numpy default_rng`), so results are reproducible across machines and numpy versions.

## What each test verifies

| Test | Paper claim | Asserts |
|---|---|---|
| **T1 Discrimination** | Leg 1, Prop. 5.9 | Genuine RG holds bridge B2 (`g_F = (Σ_R − CΣ_N⁻¹Cᵀ)⁻¹`) to ~1e-16; a random staple misses it by O(1); separation > 1e6. The lock is **not** satisfied by generic multi-structure data. |
| **T2 Codimension** | Leg 1, Thm. 4.2 | The locked set is a codimension `p(p+1)/2 = 6` submanifold of the 27-dim loose space (measured as the rank of `dF` at a locked point). RG is measure-zero, not "any coherent object". |
| **T3 Triple duty** | Leg 2, Prop. 5.4 | The canonical correlations `ρ` simultaneously give the estimation spectrum, the mutual information (`−½Σ log(1−ρ²)` matches the determinant formula), and a **gauge invariant** (`ρ` unchanged under O(p)×O(q) while the raw coupling changes by O(1)). |
| **T4 Rigidity** | Leg 2, Prop. 5.7 | The coupling rank controls the automorphism-group dimension: `dim Aut = 6, 2, 0, 0` for `rank C = 0,1,2,3`. A statistics object forces a geometry object. Falsification sweep: 0 counterexamples in 5000 full-rank couplings. |

T1 and T4 are the decisive tests. T1 shows the lock is *discriminating* (Leg 1); T4
shows it is *productive* — a statistics→geometry control law no single field produces
(Leg 2). T4b is the single strongest anti-triviality result: an inert coherence order
cannot manufacture a rank-indexed symmetry-rigidity law.

## Expected output (summary)

```
T1  genuine RG max residual ~1e-14, staple min ~0.36, ratio ~1e13   -> PASS
T2  measured codimension = 6                                         -> PASS
T3  MI(ρ) = MI(det); ρ gauge-invariant; raw coupling changes O(1)    -> PASS
T4  dim Aut = [6, 2, 0, 0]; sweep 0/5000                             -> PASS

RESULT: all load-bearing claims verified. Lock stands.
```

Exact decimals (e.g. `ρ = (0.4023, 0.7997, 0.8660)`, `I = 1.291371`) are the values
cited in the paper's Appendix A and are reproduced by these seeds.

## What would falsify the paper

- T1 `FAIL`: a random staple satisfying B2, or a genuine RG that does not — the lock
  would be either vacuous or false.
- T2 `FAIL`: codimension ≠ `p(p+1)/2` — the locked set would not be the thin
  submanifold claimed.
- T3 `FAIL`: `ρ` not gauge-invariant, or the two mutual-information routes
  disagreeing — the triple-duty productivity claim would break.
- T4 `FAIL`: a full-rank coupling admitting a nontrivial automorphism — the
  statistics→geometry control law would break.

None fail. The battery is the paper's own attempt to break it.

## Honest scope

The battery verifies **non-triviality** (genericity + productivity), not
**importance**. Importance is proportional to the length of the productivity list
(currently T3 and T4); it is a scientific judgement, not something a test can settle.
