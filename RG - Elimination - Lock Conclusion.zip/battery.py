#!/usr/bin/env python3
# ============================================================================
#  Resolution Geometry -- Lock Conclusion: falsification battery
#
#  Numerically re-derives and ASSERTS the load-bearing claims of
#  "Resolution Geometry: The Elimination Verdict and the Non-Triviality
#   of the Lock".  numpy-only, self-contained.
#
#  Each test verifies one claim of the paper and prints PASS/FAIL.
#  A nonzero exit code means at least one claim was falsified.
#
#  Claims tested:
#    T1  Discrimination (Leg 1, Prop 5.9): genuine RG holds bridge B2 to
#        ~1e-16; a random staple misses it by O(1); separation > 1e6.
#    T2  Codimension  (Leg 1, Thm 4.2): the locked set is codim p(p+1)/2;
#        measured as rank of dF at a locked point.
#    T3  Triple duty  (Leg 2, Prop 5.4): canonical correlations serve
#        estimation = information = gauge-invariant simultaneously.
#    T4  Rigidity     (Leg 2, Prop 5.7): coupling rank controls Aut(G)
#        dimension (6,2,0,0); falsification sweep finds 0 violations.
#
#  Usage:  python3 battery.py
# ============================================================================

import numpy as np

P, Q = 3, 3                      # resolved / null dimensions used in the paper
FAILS = []

def ok(name, cond, detail=""):
    tag = "PASS" if cond else "FAIL"
    print(f"  [{tag}] {name}" + (f"   {detail}" if detail else ""))
    if not cond:
        FAILS.append(name)
    return cond

# ---- linear-algebra helpers -------------------------------------------------
def spd(n, rng):
    M = rng.standard_normal((n, n))
    return M @ M.T + 0.3 * np.eye(n)

def sym(M):
    return 0.5 * (M + M.T)

def inv_schur_R(SR, C, SN):
    # (Sigma^-1)_RR = (SR - C SN^-1 C^T)^-1   (Fisher = inverse Schur, bridge B2)
    return np.linalg.inv(SR - C @ np.linalg.inv(SN) @ C.T)

def isqrt(A):
    w, V = np.linalg.eigh(A)
    return V @ np.diag(w ** -0.5) @ V.T

def vech(S):
    n = S.shape[0]
    return np.array([S[i, j] for i in range(n) for j in range(i, n)])

def unvech(v, n):
    S = np.zeros((n, n)); k = 0
    for i in range(n):
        for j in range(i, n):
            S[i, j] = v[k]; S[j, i] = v[k]; k += 1
    return S

def so_basis(n):
    B = []
    for i in range(n):
        for j in range(i + 1, n):
            E = np.zeros((n, n)); E[i, j] = 1; E[j, i] = -1; B.append(E)
    return B


# ============================================================================
def test_discrimination():
    print("\nT1  Discrimination  -- is the lock satisfied by accident?")
    rng = np.random.default_rng(11)
    N = 2000

    def genuine_RG():
        Sig = spd(P + Q, rng)
        SR, C, SN = Sig[:P, :P], Sig[:P, P:], Sig[P:, P:]
        J = np.vstack([np.eye(P), np.zeros((Q, P))])
        gF = J.T @ np.linalg.inv(Sig) @ J
        return np.linalg.norm(gF - inv_schur_R(SR, C, SN)) / np.linalg.norm(gF)

    def loose_staple():
        gF = spd(P, rng)                                   # info-metric, drawn independently
        SR, C, SN = spd(P, rng), rng.standard_normal((P, Q)), spd(Q, rng)
        return np.linalg.norm(gF - inv_schur_R(SR, C, SN)) / np.linalg.norm(gF)

    rg = np.array([genuine_RG() for _ in range(N)])
    st = np.array([loose_staple() for _ in range(N)])
    rg_max, st_min = rg.max(), st.min()
    ratio = st_min / rg_max
    print(f"      genuine RG   residual: median {np.median(rg):.2e}  max {rg_max:.2e}")
    print(f"      loose staple residual: median {np.median(st):.3f}   min {st_min:.3f}")
    print(f"      discrimination ratio (staple_min / RG_max) = {ratio:.2e}")
    ok("T1a  genuine RG holds bridge B2 (max residual < 1e-10)", rg_max < 1e-10)
    ok("T1b  loose staple fails bridge B2 (min residual > 0.05)", st_min > 0.05)
    ok("T1c  lock is discriminating (separation > 1e6)", ratio > 1e6)


# ============================================================================
def test_codimension():
    print("\nT2  Codimension     -- how thin is the locked set?")
    rng = np.random.default_rng(11)
    # locked point: choose covariance blocks, set gF = inverse Schur so F = 0
    SR0, C0, SN0 = spd(P, rng), rng.standard_normal((P, Q)), spd(Q, rng)
    gF0 = inv_schur_R(SR0, C0, SN0)

    def F(gF, SR, C, SN):
        return sym(gF - inv_schur_R(SR, C, SN))

    a = P * (P + 1) // 2
    def pack(gF, SR, C, SN):
        return np.concatenate([vech(gF), vech(SR), C.ravel(), vech(SN)])
    def unpack(x):
        b = a + P * (P + 1) // 2; c = b + P * Q
        return (unvech(x[:a], P), unvech(x[a:b], P),
                x[b:c].reshape(P, Q), unvech(x[c:], Q))

    x0 = pack(gF0, SR0, C0, SN0)
    n, m = len(x0), a
    eps = 1e-6
    f0 = vech(F(*unpack(x0)))
    Jac = np.zeros((m, n))
    for k in range(n):
        xk = x0.copy(); xk[k] += eps
        Jac[:, k] = (vech(F(*unpack(xk))) - f0) / eps
    codim = int(np.linalg.matrix_rank(Jac, tol=1e-4))
    expected = P * (P + 1) // 2
    print(f"      loose-space dim = {n},  constraint dim = {m},  measured codim = {codim}")
    ok(f"T2  codimension of locked set = p(p+1)/2 = {expected}", codim == expected,
       f"(measure zero in {n}-dim loose space)")


# ============================================================================
def test_triple_duty():
    print("\nT3  Triple duty     -- does one invariant work across three fields?")
    rng = np.random.default_rng(11)
    Sig = spd(P + Q, rng)
    SR, C, SN = Sig[:P, :P], Sig[:P, P:], Sig[P:, P:]

    K = isqrt(SR) @ C @ isqrt(SN)
    rho = np.sort(np.linalg.svd(K, compute_uv=False))          # (a) estimation
    MI_rho = -0.5 * np.sum(np.log(1 - rho ** 2))               # (b) information
    MI_det = 0.5 * np.log(np.linalg.det(SR) * np.linalg.det(SN) / np.linalg.det(Sig))

    Op, _ = np.linalg.qr(rng.standard_normal((P, P)))          # (c) gauge O(p)xO(q)
    Oq, _ = np.linalg.qr(rng.standard_normal((Q, Q)))
    Cg, SRg, SNg = Op @ C @ Oq.T, Op @ SR @ Op.T, Oq @ SN @ Oq.T
    rho_g = np.sort(np.linalg.svd(isqrt(SRg) @ Cg @ isqrt(SNg), compute_uv=False))
    dC = np.linalg.norm(Cg - C)

    print(f"      canonical correlations rho      = {np.round(rho, 6)}")
    print(f"      mutual info  via rho = {MI_rho:.6f}   via det = {MI_det:.6f}")
    print(f"      gauge: ||C_g - C|| = {dC:.3f}   rho invariant to {np.max(np.abs(rho-rho_g)):.1e}")
    ok("T3a  information content determined by rho (match < 1e-9)", abs(MI_rho - MI_det) < 1e-9)
    ok("T3b  raw coupling changes under gauge (||dC|| > 1)", dC > 1.0)
    ok("T3c  canonical correlations are gauge-invariant (< 1e-9)", np.max(np.abs(rho - rho_g)) < 1e-9)


# ============================================================================
def test_rigidity():
    print("\nT4  Rigidity        -- does coupling (statistics) control symmetry (geometry)?")
    rng = np.random.default_rng(3)
    Bp, Bq = so_basis(P), so_basis(Q)

    def aut_dim(C):
        # Aut algebra with isotropic blocks: {(A,B) in so(p)+so(q) : A C = C B}
        cols = [(A @ C).ravel() for A in Bp] + [(-C @ B).ravel() for B in Bq]
        L = np.array(cols).T
        return (len(Bp) + len(Bq)) - int(np.linalg.matrix_rank(L, tol=1e-9))

    C0 = np.zeros((P, Q))
    C1 = rng.standard_normal((P, 1)) @ rng.standard_normal((1, Q))
    U, V = rng.standard_normal((P, 2)), rng.standard_normal((Q, 2))
    C2 = U @ V.T
    C3 = rng.standard_normal((P, Q))
    dims = [aut_dim(C0), aut_dim(C1), aut_dim(C2), aut_dim(C3)]
    print(f"      dim Aut(G) for rank(C) = 0,1,2,3  ->  {dims}   (expected [6, 2, 0, 0])")

    bad = sum(1 for _ in range(5000) if aut_dim(rng.standard_normal((P, Q))) > 0)
    print(f"      falsification sweep: full-rank C with dim Aut > 0  :  {bad} / 5000")
    ok("T4a  coupling rank controls symmetry dimension ([6,2,0,0])", dims == [6, 2, 0, 0])
    ok("T4b  full coupling => rigidity (0 violations in 5000)", bad == 0)


# ============================================================================
if __name__ == "__main__":
    print("=" * 74)
    print(" Resolution Geometry -- Lock Conclusion: falsification battery")
    print(" numpy", np.__version__, "| dimensions p=q=%d" % P)
    print("=" * 74)
    test_discrimination()
    test_codimension()
    test_triple_duty()
    test_rigidity()
    print("\n" + "=" * 74)
    if FAILS:
        print(f" RESULT: {len(FAILS)} claim(s) FALSIFIED -> {FAILS}")
        print("=" * 74)
        raise SystemExit(1)
    print(" RESULT: all load-bearing claims verified. Lock stands.")
    print("=" * 74)
