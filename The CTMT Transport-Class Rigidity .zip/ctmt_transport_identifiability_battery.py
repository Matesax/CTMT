#!/usr/bin/env python3
"""
CTMT transport identifiability battery
-------------------------------------
Self-contained synthetic companion script for the attacked-coil transport-class
rigidity note. The script recreates the latest reported scenario table, computes
aggregate invariant rates, and generates CSV / JSON / TXT / PNG artifacts.
"""

from pathlib import Path
import json
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


def build_summary_dataframe() -> pd.DataFrame:
    rows = [
        {
            "Scenario": "baseline",
            "Class": "GaugeCandidate",
            "ObservableSimilarity": True,
            "AmplitudeRatioToBaseline": 0.999994457991607,
            "CorrelationToBaseline": 0.9999999895003603,
            "SurviveCount": 5,
            "OverallVerdict": "GAUGE-CLASS",
            "TransportIdentifiable": True,
            "FisherMonotonicity": True,
            "NullCurvature": True,
            "WindingInvariant": True,
            "SelfReferenceStable": True,
            "CencovStable": True,
            "CoherenceRatio": 1.0000000000000007,
            "LambdaMin": 0.0,
            "WindingNumber": 0.9841139197360562,
            "PiErrorBefore": 0.27376097704552516,
            "PiErrorAfter": 0.004637910005686141,
            "CencovClassVar": 9.979886159811442e-07,
        },
        {
            "Scenario": "current_scaling",
            "Class": "GaugeCandidate",
            "ObservableSimilarity": True,
            "AmplitudeRatioToBaseline": 1.0399976495651875,
            "CorrelationToBaseline": 0.9999999900745075,
            "SurviveCount": 5,
            "OverallVerdict": "GAUGE-CLASS",
            "TransportIdentifiable": True,
            "FisherMonotonicity": True,
            "NullCurvature": True,
            "WindingInvariant": True,
            "SelfReferenceStable": True,
            "CencovStable": True,
            "CoherenceRatio": 0.9999999999999991,
            "LambdaMin": 0.0,
            "WindingNumber": 0.9930281600109253,
            "PiErrorBefore": 0.40166163311182457,
            "PiErrorAfter": 0.005872783459003106,
            "CencovClassVar": 9.969585337063587e-07,
        },
        {
            "Scenario": "radius_scaling",
            "Class": "DangerousCompensated",
            "ObservableSimilarity": True,
            "AmplitudeRatioToBaseline": 0.9635008482285827,
            "CorrelationToBaseline": -0.02789452264831054,
            "SurviveCount": 3,
            "OverallVerdict": "NON-GAUGE / STRUCTURAL",
            "TransportIdentifiable": False,
            "FisherMonotonicity": True,
            "NullCurvature": False,
            "WindingInvariant": True,
            "SelfReferenceStable": True,
            "CencovStable": False,
            "CoherenceRatio": 0.9999999999999993,
            "LambdaMin": 7.790563358599895e-12,
            "WindingNumber": 0.9711387909212958,
            "PiErrorBefore": 5.062811602065823,
            "PiErrorAfter": 0.03837844847943961,
            "CencovClassVar": 0.2386007629652559,
        },
        {
            "Scenario": "compensated_attack",
            "Class": "DangerousCompensated",
            "ObservableSimilarity": True,
            "AmplitudeRatioToBaseline": 0.9249526489614971,
            "CorrelationToBaseline": -0.02788492655673159,
            "SurviveCount": 3,
            "OverallVerdict": "NON-GAUGE / STRUCTURAL",
            "TransportIdentifiable": False,
            "FisherMonotonicity": True,
            "NullCurvature": False,
            "WindingInvariant": True,
            "SelfReferenceStable": True,
            "CencovStable": False,
            "CoherenceRatio": 0.9999999999999984,
            "LambdaMin": 1.0644802633820389e-11,
            "WindingNumber": 1.0070650644431374,
            "PiErrorBefore": 7.470436653568715,
            "PiErrorAfter": 0.04514652867071556,
            "CencovClassVar": 0.24236480462289423,
        },
        {
            "Scenario": "causal_violation",
            "Class": "Violation",
            "ObservableSimilarity": True,
            "AmplitudeRatioToBaseline": 1.0132998241901925,
            "CorrelationToBaseline": 0.870797101915247,
            "SurviveCount": 0,
            "OverallVerdict": "NON-GAUGE / STRUCTURAL",
            "TransportIdentifiable": False,
            "FisherMonotonicity": False,
            "NullCurvature": False,
            "WindingInvariant": False,
            "SelfReferenceStable": False,
            "CencovStable": False,
            "CoherenceRatio": 5.1513574560852815,
            "LambdaMin": 1.3713600612589012e-08,
            "WindingNumber": 1.1162522144336398,
            "PiErrorBefore": 10.556389521093154,
            "PiErrorAfter": 1.328978097562306,
            "CencovClassVar": 0.34695310980318494,
        },
        {
            "Scenario": "unit_leak",
            "Class": "Violation",
            "ObservableSimilarity": True,
            "AmplitudeRatioToBaseline": 1.0483200443753455,
            "CorrelationToBaseline": 0.999980602219325,
            "SurviveCount": 0,
            "OverallVerdict": "NON-GAUGE / STRUCTURAL",
            "TransportIdentifiable": False,
            "FisherMonotonicity": False,
            "NullCurvature": False,
            "WindingInvariant": False,
            "SelfReferenceStable": False,
            "CencovStable": False,
            "CoherenceRatio": 1.4026145980694755,
            "LambdaMin": 2.7855192673178672e-08,
            "WindingNumber": 1.1182462492215524,
            "PiErrorBefore": 13.550123111167917,
            "PiErrorAfter": 1.041570446977941,
            "CencovClassVar": 0.332416683769563,
        },
    ]

    columns = [
        "Scenario", "Class", "ObservableSimilarity", "AmplitudeRatioToBaseline", "CorrelationToBaseline",
        "SurviveCount", "OverallVerdict", "TransportIdentifiable", "FisherMonotonicity", "NullCurvature",
        "WindingInvariant", "SelfReferenceStable", "CencovStable", "CoherenceRatio", "LambdaMin",
        "WindingNumber", "PiErrorBefore", "PiErrorAfter", "CencovClassVar"
    ]
    return pd.DataFrame(rows)[columns]


def build_invariant_table(summary_df: pd.DataFrame) -> pd.DataFrame:
    invariant_specs = [
        ("FisherMonotonicity", "Patched Fisher monotonicity"),
        ("NullCurvature", "Null curvature"),
        ("WindingInvariant", "Winding invariance"),
        ("SelfReferenceStable", "Self-reference stability"),
        ("CencovStable", "Quotient-style Cencov stability"),
    ]
    class_order = ["GaugeCandidate", "DangerousCompensated", "Violation"]
    rows = []
    for col, label in invariant_specs:
        row = {"Invariant": label}
        for cls in class_order:
            sub = summary_df[summary_df["Class"] == cls]
            row[f"{cls}Rate"] = float(sub[col].mean())
            row[f"{cls}Count"] = int(sub[col].sum())
            row[f"{cls}Total"] = int(len(sub))
        rows.append(row)
    return pd.DataFrame(rows)


def build_run_summary(summary_df: pd.DataFrame, invariant_df: pd.DataFrame) -> str:
    lines = []
    lines.append("CTMT transport identifiability battery -- synthetic attacked-coil summary")
    lines.append("=" * 72)
    lines.append("")
    lines.append("Scenario-level outcomes:")
    for _, r in summary_df.iterrows():
        lines.append(
            f"- {r['Scenario']}: class={r['Class']}, survive={r['SurviveCount']}, "
            f"verdict={r['OverallVerdict']}, observable_similarity={r['ObservableSimilarity']}, "
            f"transport_identifiable={r['TransportIdentifiable']}"
        )
    lines.append("")
    lines.append("Main tested-class findings:")
    lines.append("- baseline and current_scaling remain gauge-candidate scenarios with full survival (5/5).")
    lines.append("- radius_scaling and compensated_attack preserve the coarse observable screen but remain non-gauge / structural.")
    lines.append("- On the dangerous compensated class, Fisher monotonicity, winding, and self-reference survive, while null curvature and Cencov stability fail.")
    lines.append("- Hard violations (causal_violation, unit_leak) fail all five invariants.")
    lines.append("")
    lines.append("Aggregate attack-wise rates:")
    for _, r in invariant_df.iterrows():
        lines.append(
            f"- {r['Invariant']}: gauge={r['GaugeCandidateRate']:.3f}, "
            f"dangerous={r['DangerousCompensatedRate']:.3f}, violation={r['ViolationRate']:.3f}"
        )
    return "\n".join(lines) + "\n"


def build_dashboard(summary_df: pd.DataFrame, out_path: Path) -> None:
    colors = [
        "#2ca02c" if v == "GAUGE-CLASS" else ("#ff7f0e" if c == "DangerousCompensated" else "#d62728")
        for v, c in zip(summary_df["OverallVerdict"], summary_df["Class"])
    ]
    invariant_cols = ["FisherMonotonicity", "NullCurvature", "WindingInvariant", "SelfReferenceStable", "CencovStable"]
    invariant_labels = [
        "Patched Fisher\nmonotonicity",
        "Null\ncurvature",
        "Winding\ninvariance",
        "Self-reference\nstability",
        "Quotient-style\nCencov stability",
    ]

    fig, axes = plt.subplots(2, 2, figsize=(14, 9))
    ax1, ax2, ax3, ax4 = axes.flatten()

    ax1.bar(summary_df["Scenario"], summary_df["SurviveCount"], color=colors)
    ax1.set_title("Survival count by scenario")
    ax1.set_ylabel("SurviveCount")
    ax1.set_ylim(0, 5.4)
    ax1.tick_params(axis='x', rotation=30)

    inv_mat = summary_df[invariant_cols].astype(int).values
    im = ax2.imshow(inv_mat, aspect='auto', cmap='RdYlGn', vmin=0, vmax=1)
    ax2.set_title("Invariant survival matrix")
    ax2.set_yticks(range(len(summary_df)))
    ax2.set_yticklabels(summary_df["Scenario"])
    ax2.set_xticks(range(len(invariant_labels)))
    ax2.set_xticklabels(invariant_labels)
    for i in range(inv_mat.shape[0]):
        for j in range(inv_mat.shape[1]):
            ax2.text(j, i, str(inv_mat[i, j]), ha='center', va='center', color='black', fontsize=9)
    fig.colorbar(im, ax=ax2, fraction=0.046, pad=0.04)

    x = np.arange(len(summary_df))
    width = 0.38
    ax3.bar(x - width/2, summary_df["AmplitudeRatioToBaseline"], width=width, label="Amplitude ratio")
    ax3.bar(x + width/2, summary_df["CorrelationToBaseline"], width=width, label="Correlation")
    ax3.set_title("Coarse observable diagnostics")
    ax3.set_xticks(x)
    ax3.set_xticklabels(summary_df["Scenario"], rotation=30)
    ax3.axhline(1.0, color='gray', linewidth=1, linestyle='--')
    ax3.legend()

    ax4.scatter(summary_df["LambdaMin"], summary_df["CencovClassVar"], c=colors, s=90)
    for _, r in summary_df.iterrows():
        ax4.annotate(r["Scenario"], (r["LambdaMin"], r["CencovClassVar"]), textcoords="offset points", xytext=(5, 5), fontsize=8)
    ax4.set_title("Structural split: lambda_min vs Cencov class variance")
    ax4.set_xlabel("LambdaMin")
    ax4.set_ylabel("CencovClassVar")
    ax4.set_xscale('symlog', linthresh=1e-12)

    plt.tight_layout()
    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    summary_df = build_summary_dataframe()
    invariant_df = build_invariant_table(summary_df)

    summary_df.to_csv("ctmt_transport_identifiability_summary_final.csv", index=False)
    invariant_df.to_csv("ctmt_transport_identifiability_invariant_table_final.csv", index=False)

    run_summary = build_run_summary(summary_df, invariant_df)
    Path("ctmt_transport_identifiability_run_summary_final.txt").write_text(run_summary, encoding="utf-8")

    report = {
        "summary": summary_df.to_dict(orient="records"),
        "aggregate_invariants": invariant_df.to_dict(orient="records"),
        "main_findings": [
            "Baseline and current scaling are in the same tested gauge-class.",
            "Radius scaling and compensated attack preserve the coarse observable screen while remaining non-gauge / structural.",
            "The decisive non-gauge split is carried by null curvature and quotient-style Cencov stability.",
            "Patched Fisher monotonicity is useful as a coherence control but is not gauge-deciding on this suite.",
        ],
    }
    Path("ctmt_transport_identifiability_report_final.json").write_text(json.dumps(report, indent=2), encoding="utf-8")

    build_dashboard(summary_df, Path("ctmt_transport_identifiability_dashboard_final.png"))


if __name__ == "__main__":
    main()
