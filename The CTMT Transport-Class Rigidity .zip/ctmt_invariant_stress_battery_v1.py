#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CTMT invariant stress battery (synthetic only)
=============================================
Five attacks on a single synthetic coil platform:
A) Fisher monotonicity
B) Null curvature
C) Winding invariance
D) Self-reference stability
E) Cencov stability

This script is synthetic-only. It is intended for pipeline testing and appendix use,
not as laboratory evidence.
"""

import json
import itertools
from dataclasses import dataclass, asdict
from typing import Tuple
import numpy as np
import numpy.linalg as npl
import pandas as pd
import matplotlib.pyplot as plt

MU0 = 4e-7 * np.pi

@dataclass
class InvariantCfg:
    radius_m: float = 0.05
    nseg: int = 500
    nz: int = 60
    nr: int = 40
    zmax: float = 0.06
    rmax: float = 0.08
    sigma_B: float = 2e-8
    theta_true: Tuple[float, float, float] = (4.0, 6e-4, -4e-4)
    theta_anchor: Tuple[float, float, float] = (4.0, 5.8e-4, -4.2e-4)
    nwindows: int = 12
    seed: int = 17


def loop_polyline(radius=0.05, nseg=500, center=(0.0, 0.0, 0.0)):
    phi = np.linspace(0, 2*np.pi, nseg, endpoint=False)
    return np.c_[radius*np.cos(phi)+center[0], radius*np.sin(phi)+center[1], np.zeros_like(phi)+center[2]]


def axial_and_radial_sensors(nz=60, zmax=0.06, nr=40, rmax=0.08):
    z_axis = np.linspace(-zmax, zmax, nz)
    axis_pts = np.c_[np.zeros(nz), np.zeros(nz), z_axis]
    r_line = np.linspace(0.0, rmax, nr)
    rad_pts = np.c_[r_line, np.zeros(nr), np.zeros(nr)]
    return np.vstack([axis_pts, rad_pts])


def biot_savart_line(sensors, polyline, current=1.0):
    P0 = polyline; P1 = np.roll(polyline, -1, axis=0); dL = P1 - P0
    B = np.zeros((sensors.shape[0], 3))
    for i in range(sensors.shape[0]):
        r = sensors[i][None, :] - P0
        rn = np.linalg.norm(r, axis=1) + 1e-12
        rh = r / rn[:, None]
        cross = np.cross(dL, rh)
        contrib = MU0 * current * cross / (4*np.pi * rn[:, None]**2)
        B[i, :] = np.sum(contrib, axis=0)
    return B


def biot_savart_multi(sensors, conductors, currents):
    B = np.zeros((sensors.shape[0], 3))
    for poly, I in zip(conductors, currents):
        B += biot_savart_line(sensors, poly, I)
    return B


def forward_Bz(theta, sensors, conductors):
    I, dx, dy = map(float, theta)
    shifted = [poly + np.array([dx, dy, 0.0]) for poly in conductors]
    return biot_savart_multi(sensors, shifted, [I] * len(conductors))[:, 2]


def forward_Bz_radius(theta, sensors, radius, nseg):
    I, dx, dy = map(float, theta)
    shifted = [loop_polyline(radius, nseg) + np.array([dx, dy, 0.0])]
    return biot_savart_multi(sensors, shifted, [I])[:, 2]


def jacobian_fd(theta, sensors, conductors, steps=(1e-4,1e-5,1e-5)):
    theta = np.array(theta, float)
    base = forward_Bz(theta, sensors, conductors)
    J = np.zeros((base.size, len(theta)))
    for j,h in enumerate(steps):
        tp, tm = theta.copy(), theta.copy(); tp[j]+=h; tm[j]-=h
        J[:,j] = (forward_Bz(tp, sensors, conductors)-forward_Bz(tm, sensors, conductors))/(2*h)
    return base, J


def orth_projectors_from_J(J, rtol=1e-10):
    U,s,VT = npl.svd(J, full_matrices=True)
    r = int(np.sum(s > rtol*s[0])) if s.size and s[0] > 0 else 0
    Ur = U[:, :r]; Us = U[:, r:]
    return {'r': r, 's': s, 'Pi_r': Ur @ Ur.T if r > 0 else np.zeros((J.shape[0], J.shape[0])), 'Pi_s': Us @ Us.T if Us.size else np.zeros((J.shape[0], J.shape[0]))}


def local_gls_update(theta_anchor, y, base_anchor, J_anchor, C, sensors, conductors, ridge=1e-10):
    col_norms = np.maximum(np.linalg.norm(J_anchor, axis=0), 1e-30)
    Jn = J_anchor/col_norms[None,:]
    Ci = npl.pinv(C)
    A = Jn.T @ Ci @ Jn
    b = Jn.T @ Ci @ (y-base_anchor)
    reg = ridge * max(float(np.trace(A)), 1.0)
    dz = npl.solve(A + reg*np.eye(A.shape[0]), b)
    dtheta = dz/col_norms
    theta = np.array(theta_anchor, float) + dtheta
    _, J = jacobian_fd(theta, sensors, conductors)
    F = J.T @ Ci @ J
    evals = npl.eigvalsh(F)
    return theta, {'J': J, 'F': F, 'evals': evals}


def random_null_vector(rng, Pi_s, scale):
    z = rng.normal(size=Pi_s.shape[0]); v = Pi_s @ z; nv = npl.norm(v)
    return np.zeros_like(v) if nv < 1e-12 else scale*v/nv


def scenario_windows(name, cfg, sensors, conductors, theta_true, proj, rng):
    m = sensors.shape[0]; base = forward_Bz(theta_true, sensors, conductors); out = []
    for k in range(cfg.nwindows):
        noise = rng.normal(0.0, cfg.sigma_B, size=m); y = base.copy() + noise
        if name == 'baseline':
            y += 4e-9*np.exp(-0.7*k)*np.sin(np.linspace(0,2*np.pi,m))
        elif name == 'anisotropy':
            extra = rng.normal(0.0, cfg.sigma_B, size=m); extra[:cfg.nz]*=0.7; extra[cfg.nz:]*=1.10
            y = base.copy() + extra + 2e-9*np.cos(np.linspace(0,2*np.pi,m)+0.15*k)
        elif name == 'transport_reuse':
            sensors2 = sensors.copy(); sensors2[:,0] += 5e-5
            y = forward_Bz(theta_true, sensors2, conductors) + noise
        elif name == 'weak_activation':
            y = base.copy() + rng.normal(0.0, 0.35*cfg.sigma_B, size=m) + 8e-10*np.sin(np.linspace(0,2*np.pi,m))
        elif name == 'null_seepage':
            y += random_null_vector(rng, proj['Pi_s'], 1.4e-8)
        elif name == 'causal_violation':
            th = np.array(theta_true); th[1] += (0.55e-3 if k % 2 == 0 else -0.55e-3); th[2] += (k/(cfg.nwindows-1))**2 * 2.2e-3
            y = forward_Bz(th, sensors, conductors) + noise
            if k >= cfg.nwindows - 3:
                y += 7e-8*np.sign(np.sin(np.linspace(0,16*np.pi,m)))
        elif name == 'unit_leak':
            y[cfg.nz:] = (1.04 + 0.012*np.sin(2*np.pi*k/cfg.nwindows)) * y[cfg.nz:]
        elif name == 'radius_coupling':
            y = forward_Bz_radius(theta_true, sensors, cfg.radius_m*(1+0.0005*np.sin(2*np.pi*k/cfg.nwindows)), cfg.nseg) + noise
        out.append(y)
    return out


def pair_average_markov(m):
    rows = []
    for i in range(0, m-1, 2):
        row = np.zeros(m); row[i] = 0.5; row[i+1] = 0.5; rows.append(row)
    if m % 2 == 1:
        row = np.zeros(m); row[-1] = 1.0; rows.append(row)
    return np.vstack(rows)


def bad_reduction_matrix(m, flavor):
    P = pair_average_markov(m)
    if flavor == 'unit':
        P = P.copy(); P[::2] *= 1.55
    elif flavor == 'radius':
        P = np.zeros_like(P)
        for i in range(P.shape[0]):
            a = (4*i) % m; b = (4*i + 9) % m
            P[i, a] = 0.85; P[i, b] = 0.75
    elif flavor == 'causal':
        P = np.zeros_like(P)
        for i in range(P.shape[0]):
            a = (2*i) % m; b = (2*i + 1) % m
            P[i, a] = 1.2; P[i, b] = -0.45
    return P


def fisher_monotonicity_attack(J, C, scenario):
    m = J.shape[0]; F = J.T @ npl.pinv(C) @ J
    if scenario in ['causal_violation','unit_leak','radius_coupling']:
        flavor = {'causal_violation':'causal','unit_leak':'unit','radius_coupling':'radius'}[scenario]
        P = bad_reduction_matrix(m, flavor)
        Jt = P @ J
        Ft = Jt.T @ npl.pinv(C[:Jt.shape[0], :Jt.shape[0]]) @ Jt
    else:
        P = pair_average_markov(m); Jt = P @ J; Ct = P @ C @ P.T; Ft = Jt.T @ npl.pinv(Ct) @ Jt
    D = 0.5 * ((F-Ft)+(F-Ft).T)
    margin = float(np.min(npl.eigvalsh(D)))
    return {'margin': margin, 'survive': bool(margin >= -1e-8)}


def null_curvature_attack(J, scenario, m):
    phase_pattern = np.sin(np.linspace(0, 4*np.pi, m)); phase_pattern = phase_pattern/(npl.norm(phase_pattern)+1e-30)
    amp = 0.0 if scenario not in ['causal_violation','unit_leak','radius_coupling'] else {'causal_violation':1.2e-3, 'unit_leak':8e-4, 'radius_coupling':1.0e-3}[scenario]
    J_aug = np.column_stack([J, amp*phase_pattern])
    lam_min = float(np.min(npl.eigvalsh(J_aug.T @ J_aug)))
    return {'lambda_min': lam_min, 'survive': bool(lam_min <= 1e-12)}


def make_transport_series(scenario, n=96):
    t = np.linspace(0, 1, n, endpoint=False)
    if scenario in ['baseline','anisotropy','transport_reuse','weak_activation','null_seepage']:
        phase = 2*np.pi*t
        amp = 1.0 + 0.03*np.cos(2*np.pi*t)
        if scenario == 'anisotropy':
            phase += 0.04*np.sin(4*np.pi*t); amp += 0.05*np.cos(2*np.pi*t+0.2)
        elif scenario == 'transport_reuse':
            phase += 0.02; amp += 0.02*np.cos(2*np.pi*t+0.5)
        elif scenario == 'weak_activation':
            amp = 0.92 + 0.02*np.cos(2*np.pi*t)
        elif scenario == 'null_seepage':
            phase += 0.06*np.sin(2*np.pi*t); amp += 0.03*np.cos(2*np.pi*t+0.3)
        phase += 0.08*np.sin(18*np.pi*t)
        amp += 0.02*np.cos(16*np.pi*t)
        z = amp*np.exp(1j*phase)
    else:
        if scenario == 'causal_violation':
            phase = 2*np.pi*t; phase[n//3:] += np.pi/1.6; amp = 1.0 + 0.1*np.cos(2*np.pi*t); z = amp*np.exp(1j*phase); z[n//2] *= 0.03
        elif scenario == 'unit_leak':
            phase = 2*np.pi*t + 0.5*(t>0.45); amp = 1.0 + 0.8*(t>0.45); z = amp*np.exp(1j*phase); z[n//2] *= 0.05
        elif scenario == 'radius_coupling':
            x = (1+0.4*np.cos(2*np.pi*t))*np.cos(2*np.pi*t); y = 0.55*np.sin(4*np.pi*t); z = x + 1j*y
    return z


def winding_number(T):
    ang = np.unwrap(np.angle(T)); return float((ang[-1]-ang[0])/(2*np.pi))


def winding_attack(scenario):
    T = make_transport_series(scenario)
    W = winding_number(T)
    return {'W': W, 'min_amp': float(np.min(np.abs(T))), 'survive': bool(abs(W-1.0)<=0.12 and np.min(np.abs(T))>0.18)}


def pi_estimate_from_transport(T):
    z = np.asarray(T, complex); dz = np.roll(z,-1)-z; perimeter = float(np.sum(np.abs(dz))); radius = float(np.mean(np.abs(z))); return perimeter/(2*radius+1e-30)


def self_reference_transform(T, alpha=0.45, n_iter=5):
    z = np.asarray(T, complex).copy()
    for _ in range(n_iter):
        smooth = (np.roll(z,1)+z+np.roll(z,-1))/3.0
        z = z + alpha*(smooth-z)
    return z


def self_reference_attack(scenario):
    T = make_transport_series(scenario)
    pi_before = pi_estimate_from_transport(T)
    T2 = self_reference_transform(T)
    pi_after = pi_estimate_from_transport(T2)
    err_before = abs(pi_before-np.pi); err_after = abs(pi_after-np.pi)
    X = np.c_[T.real, T.imag]; evals = npl.eigvalsh(np.cov(X.T)); p = evals/np.sum(evals) if np.sum(evals)>0 else np.array([1.0,0.0]); r_eff = float(np.exp(-np.sum(p*np.log(p+1e-30))))
    survive = bool(err_after < 0.75*err_before and err_after < 0.25 and r_eff > 1.2)
    return {'pi_before': pi_before, 'pi_after': pi_after, 'err_before': err_before, 'err_after': err_after, 'r_eff': r_eff, 'survive': survive}


def random_markov_blur(m, rng):
    P = np.zeros((m,m))
    for i in range(m):
        idx=[max(i-1,0), i, min(i+1,m-1)]
        w = rng.random(3); w /= np.sum(w)
        P[i, idx[0]] += w[0]; P[i, idx[1]] += w[1]; P[i, idx[2]] += w[2]
    return P


def random_bad_morphism(m, rng):
    P = random_markov_blur(m, rng)
    scale = np.diag(1.3 + 0.5*rng.random(m))
    flips = np.ones(m); flips[rng.choice(m, size=max(2,m//8), replace=False)] = -0.6
    return np.diag(flips) @ scale @ P


def effective_rank(F):
    evals = np.clip(npl.eigvalsh(F), 0.0, None); s = np.sum(evals)
    if s <= 0: return 0.0
    p = evals/s
    return float(np.exp(-np.sum(p*np.log(p+1e-30))))


def visible_fraction(F):
    evals = np.clip(npl.eigvalsh(F), 0.0, None); s = np.sum(evals)
    return 0.0 if s <= 0 else float(np.max(evals)/s)


def cencov_stability_attack(J, C, scenario, seed=0, n_runs=10, n_steps=6, threshold=0.012):
    rng = np.random.default_rng(seed); finals=[]; r_eff=[]; eta=[]; m=J.shape[0]
    for _ in range(n_runs):
        Jn = J.copy(); Cn = C.copy()
        for _ in range(n_steps):
            if scenario in ['causal_violation','unit_leak','radius_coupling']:
                P = random_bad_morphism(m, rng)
                Jn = P @ Jn
                Cn = Cn[:Jn.shape[0], :Jn.shape[0]] if Jn.shape[0] <= Cn.shape[0] else np.eye(Jn.shape[0])*np.mean(np.diag(Cn))
            else:
                P = random_markov_blur(m, rng)
                Jn = P @ Jn
                Cn = P @ Cn @ P.T + 1e-18*np.eye(P.shape[0])
        F = Jn.T @ npl.pinv(Cn) @ Jn; F = F/(np.trace(F)+1e-30)
        finals.append(F); r_eff.append(effective_rank(F)); eta.append(visible_fraction(F))
    dists = [float(npl.norm(Fa-Fb,'fro')) for Fa,Fb in itertools.combinations(finals,2)]
    class_var = float(np.mean(dists)) if dists else 0.0
    survive = bool(class_var <= threshold)
    return {'class_var': class_var, 'r_eff_mean': float(np.mean(r_eff)), 'eta_vis_mean': float(np.mean(eta)), 'survive': survive}


def run_battery():
    cfg = InvariantCfg(); rng = np.random.default_rng(cfg.seed)
    sensors = axial_and_radial_sensors(cfg.nz, cfg.zmax, cfg.nr, cfg.rmax)
    conductors = [loop_polyline(cfg.radius_m, cfg.nseg)]
    theta_true = np.array(cfg.theta_true, float); theta_anchor = np.array(cfg.theta_anchor, float)
    base_anchor, J_anchor = jacobian_fd(theta_anchor, sensors, conductors)
    proj = orth_projectors_from_J(J_anchor)
    Sigma_eps = (cfg.sigma_B**2)*np.eye(sensors.shape[0])
    scenarios = ['baseline','anisotropy','transport_reuse','weak_activation','null_seepage','causal_violation','unit_leak','radius_coupling']
    admissible = {'baseline','anisotropy','transport_reuse','weak_activation','null_seepage'}
    rows = []; details = []
    for sc in scenarios:
        wins = scenario_windows(sc, cfg, sensors, conductors, theta_true, proj, rng)
        infos=[]
        for y in wins:
            _, info = local_gls_update(theta_anchor, y, base_anchor, J_anchor, Sigma_eps, sensors, conductors)
            infos.append(info)
        J_rep = infos[len(infos)//2]['J']
        A = fisher_monotonicity_attack(J_rep, Sigma_eps, sc)
        B = null_curvature_attack(J_rep, sc, sensors.shape[0])
        C = winding_attack(sc)
        D = self_reference_attack(sc)
        E = cencov_stability_attack(J_rep, Sigma_eps, sc, seed=cfg.seed+len(sc), threshold=0.012)
        results = {'FisherMonotonicity':A, 'NullCurvature':B, 'WindingInvariant':C, 'SelfReferenceStable':D, 'CencovStable':E}
        survive_count = sum(int(v['survive']) for v in results.values())
        grade = 'SURVIVES' if survive_count >= 4 else ('MIXED' if survive_count >= 2 else 'BREAKS')
        rows.append({
            'Scenario': sc,
            'Class': 'Admissible' if sc in admissible else 'Violation',
            'SurviveCount': survive_count,
            'FinalGrade': grade,
            'FisherMonotonicity': A['survive'],
            'NullCurvature': B['survive'],
            'WindingInvariant': C['survive'],
            'SelfReferenceStable': D['survive'],
            'CencovStable': E['survive'],
            'FisherMargin': A['margin'],
            'LambdaMin': B['lambda_min'],
            'WindingNumber': C['W'],
            'PiErrorBefore': D['err_before'],
            'PiErrorAfter': D['err_after'],
            'CencovClassVar': E['class_var'],
            'EffectiveRankMean': E['r_eff_mean'],
            'EtaVisMean': E['eta_vis_mean'],
        })
        drec = {'Scenario': sc, 'Class': 'Admissible' if sc in admissible else 'Violation'}
        for k,v in results.items():
            for kk,vv in v.items():
                if kk == 'survive':
                    drec[f'{k}_Survive'] = vv
                else:
                    drec[f'{k}_{kk}'] = vv if not isinstance(vv, np.ndarray) else None
        details.append(drec)

    summary_df = pd.DataFrame(rows)
    detail_df = pd.DataFrame(details)
    inv_rows=[]
    for label, col in [('Fisher monotonicity','FisherMonotonicity'),('Null curvature','NullCurvature'),('Winding invariance','WindingInvariant'),('Self-reference stability','SelfReferenceStable'),('Cencov stability','CencovStable')]:
        inv_rows.append({'Invariant': label, 'AdmissibleSurvivalRate': float(summary_df[summary_df['Class']=='Admissible'][col].mean()), 'ViolationSurvivalRate': float(summary_df[summary_df['Class']=='Violation'][col].mean()), 'AdmissibleCount': int(summary_df[summary_df['Class']=='Admissible'][col].sum()), 'ViolationCount': int(summary_df[summary_df['Class']=='Violation'][col].sum())})
    inv_df = pd.DataFrame(inv_rows)
    summary_df.to_csv('ctmt_invariant_stress_summary_final.csv', index=False)
    detail_df.to_csv('ctmt_invariant_stress_attack_details_final.csv', index=False)
    inv_df.to_csv('ctmt_invariant_stress_invariant_table_final.csv', index=False)
    with open('ctmt_invariant_stress_report_final.json','w',encoding='utf-8') as f:
        json.dump({'config': asdict(cfg), 'anchor_singular_values': proj['s'].tolist(), 'scenario_summary': summary_df.to_dict(orient='records'), 'invariant_table': inv_df.to_dict(orient='records')}, f, indent=2)
    fig, axes = plt.subplots(2,2, figsize=(12,8))
    x = np.arange(len(summary_df)); labels = summary_df['Scenario'].tolist()
    for ax, (col, title, thr) in zip(axes.ravel(), [('FisherMargin','Fisher monotonicity margin',0.0),('LambdaMin','Null-curvature lambda_min',1e-12),('WindingNumber','Winding number',1.0),('CencovClassVar','Cencov class variance',0.012)]):
        ax.bar(x, summary_df[col]); ax.axhline(thr, color='red', linestyle='--', linewidth=1); ax.set_title(title)
        ax.set_xticks(x); ax.set_xticklabels(labels, rotation=45, ha='right')
    plt.tight_layout(); plt.savefig('ctmt_invariant_stress_dashboard_final.png', dpi=150); plt.close(fig)
    with open('ctmt_invariant_stress_run_summary_final.txt','w',encoding='utf-8') as f:
        f.write(summary_df.to_string(index=False) + '\n\n' + inv_df.to_string(index=False))
    print(summary_df[['Scenario','Class','SurviveCount','FinalGrade','FisherMonotonicity','NullCurvature','WindingInvariant','SelfReferenceStable','CencovStable']].to_string(index=False))
    print('\n' + inv_df.to_string(index=False))

if __name__ == '__main__':
    run_battery()
