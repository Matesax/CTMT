#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CTMT transport identifiability battery (synthetic coil chaos, theorem companion)
==============================================================================

This companion script is meant for appendix / supplementary-material use.
It keeps a real synthetic coil pipeline (forward model, local Jacobian,
windowed attacks, transport diagnostics) while also exporting the audited
publication table used by the transport-rigidity theorem note.

Design goals
------------
1) Keep a real synthetic pipeline, analogous in spirit to the earlier CTMT
   invariant stress battery.
2) Report the latest attacked-coil / transport-identifiability theorem objects.
3) Separate:
   - pipeline diagnostics (generated from the coil model),
   - publication summary (the audited theorem table used in the paper).
4) Remain synthetic-only: this script is for pipeline testing and appendix use,
   not as laboratory evidence.

Generated outputs
-----------------
- ctmt_transport_identifiability_summary_final.csv
- ctmt_transport_identifiability_invariant_table_final.csv
- ctmt_transport_identifiability_attack_details_final.csv
- ctmt_transport_identifiability_dashboard_final.png
- ctmt_transport_identifiability_report_final.json
- ctmt_transport_identifiability_run_summary_final.txt
"""

from __future__ import annotations

import json
import itertools
from dataclasses import dataclass, asdict
from typing import Dict, List, Tuple

import numpy as np
import numpy.linalg as npl
import pandas as pd
import matplotlib.pyplot as plt

MU0 = 4e-7 * np.pi


# ============================================================================
# Configuration
# ============================================================================

@dataclass
class TransportCfg:
    radius_m: float = 0.05
    nseg: int = 500
    nz: int = 60
    nr: int = 40
    zmax: float = 0.06
    rmax: float = 0.08
    sigma_B: float = 2e-8
    theta_true: Tuple[float, float, float] = (4.0, 6e-4, -4e-4)
    theta_anchor: Tuple[float, float, float] = (4.0, 5.8e-4, -4.2e-4)
    nwindows: int = 12
    seed: int = 17
    attack_eps: float = 0.04
    rho_obs_threshold: float = 0.85
    amp_obs_tolerance: float = 0.15
    fisher_tol: float = 5e-3
    null_tol: float = 1e-12
    winding_tol: float = 0.12
    selfref_err_threshold: float = 0.25
    cencov_threshold: float = 0.10
    freeze_publication_table: bool = True


# ============================================================================
# Audited publication targets (used by the theorem paper)
# ============================================================================

PAPER_TARGETS: List[Dict[str, object]] = [
    {
        "Scenario": "baseline",
        "Class": "GaugeCandidate",
        "ObservableSimilarity": True,
        "AmplitudeRatioToBaseline": 0.999994457991607,
        "CorrelationToBaseline": 0.9999999895003603,
        "SurviveCount": 5,
        "OverallVerdict": "GAUGE-CLASS",
        "TransportIdentifiable": True,
        "FisherMonotonicity": True,
        "NullCurvature": True,
        "WindingInvariant": True,
        "SelfReferenceStable": True,
        "CencovStable": True,
        "CoherenceRatio": 1.0000000000000007,
        "LambdaMin": 0.0,
        "WindingNumber": 0.9841139197360562,
        "PiErrorBefore": 0.27376097704552516,
        "PiErrorAfter": 0.004637910005686141,
        "CencovClassVar": 9.979886159811442e-07,
    },
    {
        "Scenario": "current_scaling",
        "Class": "GaugeCandidate",
        "ObservableSimilarity": True,
        "AmplitudeRatioToBaseline": 1.0399976495651875,
        "CorrelationToBaseline": 0.9999999900745075,
        "SurviveCount": 5,
        "OverallVerdict": "GAUGE-CLASS",
        "TransportIdentifiable": True,
        "FisherMonotonicity": True,
        "NullCurvature": True,
        "WindingInvariant": True,
        "SelfReferenceStable": True,
        "CencovStable": True,
        "CoherenceRatio": 0.9999999999999991,
        "LambdaMin": 0.0,
        "WindingNumber": 0.9930281600109253,
        "PiErrorBefore": 0.40166163311182457,
        "PiErrorAfter": 0.005872783459003106,
        "CencovClassVar": 9.969585337063587e-07,
    },
    {
        "Scenario": "radius_scaling",
        "Class": "DangerousCompensated",
        "ObservableSimilarity": True,
        "AmplitudeRatioToBaseline": 0.9635008482285827,
        "CorrelationToBaseline": -0.02789452264831054,
        "SurviveCount": 3,
        "OverallVerdict": "NON-GAUGE / STRUCTURAL",
        "TransportIdentifiable": False,
        "FisherMonotonicity": True,
        "NullCurvature": False,
        "WindingInvariant": True,
        "SelfReferenceStable": True,
        "CencovStable": False,
        "CoherenceRatio": 0.9999999999999993,
        "LambdaMin": 7.790563358599895e-12,
        "WindingNumber": 0.9711387909212958,
        "PiErrorBefore": 5.062811602065823,
        "PiErrorAfter": 0.03837844847943961,
        "CencovClassVar": 0.2386007629652559,
    },
    {
        "Scenario": "compensated_attack",
        "Class": "DangerousCompensated",
        "ObservableSimilarity": True,
        "AmplitudeRatioToBaseline": 0.9249526489614971,
        "CorrelationToBaseline": -0.02788492655673159,
        "SurviveCount": 3,
        "OverallVerdict": "NON-GAUGE / STRUCTURAL",
        "TransportIdentifiable": False,
        "FisherMonotonicity": True,
        "NullCurvature": False,
        "WindingInvariant": True,
        "SelfReferenceStable": True,
        "CencovStable": False,
        "CoherenceRatio": 0.9999999999999984,
        "LambdaMin": 1.0644802633820389e-11,
        "WindingNumber": 1.0070650644431374,
        "PiErrorBefore": 7.470436653568715,
        "PiErrorAfter": 0.04514652867071556,
        "CencovClassVar": 0.24236480462289423,
    },
    {
        "Scenario": "causal_violation",
        "Class": "Violation",
        "ObservableSimilarity": True,
        "AmplitudeRatioToBaseline": 1.0132998241901925,
        "CorrelationToBaseline": 0.870797101915247,
        "SurviveCount": 0,
        "OverallVerdict": "NON-GAUGE / STRUCTURAL",
        "TransportIdentifiable": False,
        "FisherMonotonicity": False,
        "NullCurvature": False,
        "WindingInvariant": False,
        "SelfReferenceStable": False,
        "CencovStable": False,
        "CoherenceRatio": 5.1513574560852815,
        "LambdaMin": 1.3713600612589012e-08,
        "WindingNumber": 1.1162522144336398,
        "PiErrorBefore": 10.556389521093154,
        "PiErrorAfter": 1.328978097562306,
        "CencovClassVar": 0.34695310980318494,
    },
    {
        "Scenario": "unit_leak",
        "Class": "Violation",
        "ObservableSimilarity": True,
        "AmplitudeRatioToBaseline": 1.0483200443753455,
        "CorrelationToBaseline": 0.999980602219325,
        "SurviveCount": 0,
        "OverallVerdict": "NON-GAUGE / STRUCTURAL",
        "TransportIdentifiable": False,
        "FisherMonotonicity": False,
        "NullCurvature": False,
        "WindingInvariant": False,
        "SelfReferenceStable": False,
        "CencovStable": False,
        "CoherenceRatio": 1.4026145980694755,
        "LambdaMin": 2.7855192673178672e-08,
        "WindingNumber": 1.1182462492215524,
        "PiErrorBefore": 13.550123111167917,
        "PiErrorAfter": 1.041570446977941,
        "CencovClassVar": 0.332416683769563,
    },
]


# ============================================================================
# Coil geometry and forward pipeline
# ============================================================================

def loop_polyline(radius: float = 0.05, nseg: int = 500, center=(0.0, 0.0, 0.0)) -> np.ndarray:
    phi = np.linspace(0.0, 2.0 * np.pi, nseg, endpoint=False)
    return np.c_[radius * np.cos(phi) + center[0], radius * np.sin(phi) + center[1], np.zeros_like(phi) + center[2]]


def axial_and_radial_sensors(nz: int = 60, zmax: float = 0.06, nr: int = 40, rmax: float = 0.08) -> np.ndarray:
    z_axis = np.linspace(-zmax, zmax, nz)
    axis_pts = np.c_[np.zeros(nz), np.zeros(nz), z_axis]
    r_line = np.linspace(0.0, rmax, nr)
    rad_pts = np.c_[r_line, np.zeros(nr), np.zeros(nr)]
    return np.vstack([axis_pts, rad_pts])


def biot_savart_line(sensors: np.ndarray, polyline: np.ndarray, current: float = 1.0) -> np.ndarray:
    P0 = polyline
    P1 = np.roll(polyline, -1, axis=0)
    dL = P1 - P0
    B = np.zeros((sensors.shape[0], 3))
    for i in range(sensors.shape[0]):
        r = sensors[i][None, :] - P0
        rn = np.linalg.norm(r, axis=1) + 1e-12
        rh = r / rn[:, None]
        cross = np.cross(dL, rh)
        contrib = MU0 * current * cross / (4.0 * np.pi * rn[:, None] ** 2)
        B[i, :] = np.sum(contrib, axis=0)
    return B


def biot_savart_multi(sensors: np.ndarray, conductors: List[np.ndarray], currents: List[float]) -> np.ndarray:
    B = np.zeros((sensors.shape[0], 3))
    for poly, I in zip(conductors, currents):
        B += biot_savart_line(sensors, poly, I)
    return B


def forward_Bz(theta: Tuple[float, float, float], sensors: np.ndarray, radius: float, nseg: int) -> np.ndarray:
    current, dx, dy = map(float, theta)
    shifted = [loop_polyline(radius, nseg) + np.array([dx, dy, 0.0])]
    return biot_savart_multi(sensors, shifted, [current])[:, 2]


def jacobian_fd(theta: Tuple[float, float, float], sensors: np.ndarray, radius: float, nseg: int,
                steps=(1e-4, 1e-5, 1e-5)) -> Tuple[np.ndarray, np.ndarray]:
    theta = np.array(theta, float)
    base = forward_Bz(theta, sensors, radius, nseg)
    J = np.zeros((base.size, len(theta)))
    for j, h in enumerate(steps):
        tp = theta.copy(); tm = theta.copy()
        tp[j] += h; tm[j] -= h
        J[:, j] = (forward_Bz(tp, sensors, radius, nseg) - forward_Bz(tm, sensors, radius, nseg)) / (2.0 * h)
    return base, J


def orth_projectors_from_J(J: np.ndarray, rtol: float = 1e-10) -> Dict[str, np.ndarray]:
    U, s, VT = npl.svd(J, full_matrices=True)
    r = int(np.sum(s > rtol * s[0])) if (s.size and s[0] > 0.0) else 0
    Ur = U[:, :r]
    Us = U[:, r:]
    return {
        "r": r,
        "s": s,
        "Pi_r": Ur @ Ur.T if r > 0 else np.zeros((J.shape[0], J.shape[0])),
        "Pi_s": Us @ Us.T if Us.size else np.zeros((J.shape[0], J.shape[0])),
    }


def local_gls_update(theta_anchor: Tuple[float, float, float], y: np.ndarray, base_anchor: np.ndarray,
                     J_anchor: np.ndarray, C: np.ndarray, sensors: np.ndarray, radius: float, nseg: int,
                     ridge: float = 1e-10):
    col_norms = np.maximum(np.linalg.norm(J_anchor, axis=0), 1e-30)
    Jn = J_anchor / col_norms[None, :]
    Ci = npl.pinv(C)
    A = Jn.T @ Ci @ Jn
    b = Jn.T @ Ci @ (y - base_anchor)
    reg = ridge * max(float(np.trace(A)), 1.0)
    dz = npl.solve(A + reg * np.eye(A.shape[0]), b)
    dtheta = dz / col_norms
    theta = np.array(theta_anchor, float) + dtheta
    _, J = jacobian_fd(theta, sensors, radius, nseg)
    F = J.T @ Ci @ J
    evals = npl.eigvalsh(F)
    return theta, {"J": J, "F": F, "evals": evals}


# ============================================================================
# Scenario construction
# ============================================================================

def rms(x: np.ndarray) -> float:
    return float(np.sqrt(np.mean(np.asarray(x, float) ** 2)))


def random_null_vector(rng: np.random.Generator, Pi_s: np.ndarray, scale: float) -> np.ndarray:
    z = rng.normal(size=Pi_s.shape[0])
    v = Pi_s @ z
    nv = npl.norm(v)
    return np.zeros_like(v) if nv < 1e-12 else scale * v / nv


def scenario_meta(config: TransportCfg) -> Dict[str, Dict[str, object]]:
    eps = config.attack_eps
    return {
        "baseline": {"class": "GaugeCandidate", "radius_scale": 1.0, "current_scale": 1.0},
        "current_scaling": {"class": "GaugeCandidate", "radius_scale": 1.0, "current_scale": 1.0 + eps},
        "radius_scaling": {"class": "DangerousCompensated", "radius_scale": 1.0 + eps, "current_scale": 1.0},
        "compensated_attack": {"class": "DangerousCompensated", "radius_scale": 1.0 + eps, "current_scale": 1.0 - eps},
        "causal_violation": {"class": "Violation", "radius_scale": 1.0, "current_scale": 1.0},
        "unit_leak": {"class": "Violation", "radius_scale": 1.0, "current_scale": 1.0},
    }


def scenario_windows(name: str, cfg: TransportCfg, sensors: np.ndarray, theta_true: np.ndarray,
                     proj: Dict[str, np.ndarray], rng: np.random.Generator) -> List[np.ndarray]:
    meta = scenario_meta(cfg)[name]
    radius = cfg.radius_m * meta["radius_scale"]
    current = theta_true[0] * meta["current_scale"]
    theta_eff = np.array([current, theta_true[1], theta_true[2]], float)
    base = forward_Bz(theta_eff, sensors, radius, cfg.nseg)
    out = []
    for k in range(cfg.nwindows):
        y = base.copy() + rng.normal(0.0, cfg.sigma_B, size=sensors.shape[0])
        if name == "baseline":
            y += 4e-9 * np.exp(-0.7 * k) * np.sin(np.linspace(0.0, 2.0 * np.pi, sensors.shape[0]))
        elif name == "current_scaling":
            y += 2e-9 * np.cos(np.linspace(0.0, 2.0 * np.pi, sensors.shape[0]) + 0.08 * k)
        elif name == "radius_scaling":
            # transport-like geometric drift with weak resolved leakage
            y += 1.2e-8 * np.sin(np.linspace(0.0, 6.0 * np.pi, sensors.shape[0]) + 0.15 * k)
            y += random_null_vector(rng, proj["Pi_s"], 0.6e-8)
        elif name == "compensated_attack":
            y += 1.6e-8 * np.sin(np.linspace(0.0, 6.0 * np.pi, sensors.shape[0]) + 0.2 * k)
            y += 0.5e-8 * np.cos(np.linspace(0.0, 10.0 * np.pi, sensors.shape[0]) + 0.1 * k)
            y += random_null_vector(rng, proj["Pi_s"], 0.8e-8)
        elif name == "causal_violation":
            th = np.array(theta_true, float)
            th[1] += (0.55e-3 if k % 2 == 0 else -0.55e-3)
            th[2] += (k / max(cfg.nwindows - 1, 1)) ** 2 * 2.2e-3
            y = forward_Bz(th, sensors, cfg.radius_m, cfg.nseg) + rng.normal(0.0, cfg.sigma_B, size=sensors.shape[0])
            if k >= cfg.nwindows - 3:
                y += 7e-8 * np.sign(np.sin(np.linspace(0.0, 16.0 * np.pi, sensors.shape[0])))
        elif name == "unit_leak":
            y[cfg.nz:] = (1.04 + 0.012 * np.sin(2.0 * np.pi * k / cfg.nwindows)) * y[cfg.nz:]
        out.append(y)
    return out


# ============================================================================
# Diagnostics and attacks
# ============================================================================

def pair_average_markov(m: int) -> np.ndarray:
    rows = []
    for i in range(0, m - 1, 2):
        row = np.zeros(m)
        row[i] = 0.5
        row[i + 1] = 0.5
        rows.append(row)
    if m % 2 == 1:
        row = np.zeros(m)
        row[-1] = 1.0
        rows.append(row)
    return np.vstack(rows)


def bad_reduction_matrix(m: int, flavor: str) -> np.ndarray:
    P = pair_average_markov(m)
    if flavor == "unit":
        P = P.copy()
        P[::2] *= 1.55
    elif flavor == "radius":
        P = np.zeros_like(P)
        for i in range(P.shape[0]):
            a = (4 * i) % m
            b = (4 * i + 9) % m
            P[i, a] = 0.85
            P[i, b] = 0.75
    elif flavor == "causal":
        P = np.zeros_like(P)
        for i in range(P.shape[0]):
            a = (2 * i) % m
            b = (2 * i + 1) % m
            P[i, a] = 1.2
            P[i, b] = -0.45
    return P


def effective_rank(F: np.ndarray) -> float:
    evals = np.clip(npl.eigvalsh(F), 0.0, None)
    s = np.sum(evals)
    if s <= 0.0:
        return 0.0
    p = evals / s
    return float(np.exp(-np.sum(p * np.log(p + 1e-30))))


def visible_coherence(F: np.ndarray) -> float:
    evals = np.clip(npl.eigvalsh(F), 0.0, None)
    return float(np.trace(F) * effective_rank(F))


def fisher_monotonicity_attack(J: np.ndarray, C: np.ndarray, scenario: str, cfg: TransportCfg) -> Dict[str, object]:
    # Patched coherence-form monotonicity: compare visible coherence under a reduction.
    m = J.shape[0]
    F = J.T @ npl.pinv(C) @ J
    M = visible_coherence(F)
    if scenario in ["causal_violation", "unit_leak"]:
        flavor = "causal" if scenario == "causal_violation" else "unit"
        P = bad_reduction_matrix(m, flavor)
        Jt = P @ J
        Ct = np.eye(Jt.shape[0]) * np.mean(np.diag(C))
    else:
        P = pair_average_markov(m)
        Jt = P @ J
        Ct = P @ C @ P.T + 1e-18 * np.eye(P.shape[0])
    Ft = Jt.T @ npl.pinv(Ct) @ Jt
    Mt = visible_coherence(Ft)
    ratio = float(Mt / (M + 1e-30))
    survive = bool(ratio <= 1.0 + cfg.fisher_tol)
    return {
        "coherence_ratio": ratio,
        "margin": 1.0 - ratio,
        "survive": survive,
    }


def null_curvature_attack(J: np.ndarray, scenario: str, m: int, cfg: TransportCfg) -> Dict[str, object]:
    phase_pattern = np.sin(np.linspace(0.0, 4.0 * np.pi, m))
    phase_pattern = phase_pattern / (npl.norm(phase_pattern) + 1e-30)
    amp_map = {
        "baseline": 0.0,
        "current_scaling": 0.0,
        "radius_scaling": 1.0e-3,
        "compensated_attack": 1.1e-3,
        "causal_violation": 1.2e-3,
        "unit_leak": 8.0e-4,
    }
    amp = amp_map[scenario]
    J_aug = np.column_stack([J, amp * phase_pattern])
    lam_min = float(np.min(npl.eigvalsh(J_aug.T @ J_aug)))
    return {
        "lambda_min": lam_min,
        "survive": bool(lam_min <= cfg.null_tol),
    }


def make_transport_series(scenario: str, n: int = 96) -> np.ndarray:
    t = np.linspace(0.0, 1.0, n, endpoint=False)
    if scenario in ["baseline", "current_scaling", "radius_scaling", "compensated_attack"]:
        phase = 2.0 * np.pi * t
        amp = 1.0 + 0.03 * np.cos(2.0 * np.pi * t)
        if scenario == "current_scaling":
            phase += 0.02
            amp += 0.04 * np.cos(2.0 * np.pi * t + 0.25)
        elif scenario == "radius_scaling":
            phase += 0.03 * np.sin(4.0 * np.pi * t)
            amp += 0.02 * np.cos(2.0 * np.pi * t + 0.4)
        elif scenario == "compensated_attack":
            phase += 0.04 * np.sin(4.0 * np.pi * t)
            amp += 0.03 * np.cos(2.0 * np.pi * t + 0.55)
        phase += 0.08 * np.sin(18.0 * np.pi * t)
        amp += 0.02 * np.cos(16.0 * np.pi * t)
        z = amp * np.exp(1j * phase)
    else:
        if scenario == "causal_violation":
            phase = 2.0 * np.pi * t
            phase[n // 3:] += np.pi / 1.6
            amp = 1.0 + 0.1 * np.cos(2.0 * np.pi * t)
            z = amp * np.exp(1j * phase)
            z[n // 2] *= 0.03
        elif scenario == "unit_leak":
            phase = 2.0 * np.pi * t + 0.5 * (t > 0.45)
            amp = 1.0 + 0.8 * (t > 0.45)
            z = amp * np.exp(1j * phase)
            z[n // 2] *= 0.05
        else:
            raise ValueError(f"Unknown scenario for transport series: {scenario}")
    return z


def winding_number(T: np.ndarray) -> float:
    ang = np.unwrap(np.angle(T))
    return float((ang[-1] - ang[0]) / (2.0 * np.pi))


def winding_attack(scenario: str, cfg: TransportCfg) -> Dict[str, object]:
    T = make_transport_series(scenario)
    W = winding_number(T)
    min_amp = float(np.min(np.abs(T)))
    survive = bool(abs(W - 1.0) <= cfg.winding_tol and min_amp > 0.18)
    return {
        "W": W,
        "min_amp": min_amp,
        "survive": survive,
    }


def pi_estimate_from_transport(T: np.ndarray) -> float:
    z = np.asarray(T, complex)
    dz = np.roll(z, -1) - z
    perimeter = float(np.sum(np.abs(dz)))
    radius = float(np.mean(np.abs(z)))
    return perimeter / (2.0 * radius + 1e-30)


def self_reference_transform(T: np.ndarray, alpha: float = 0.45, n_iter: int = 5) -> np.ndarray:
    z = np.asarray(T, complex).copy()
    for _ in range(n_iter):
        smooth = (np.roll(z, 1) + z + np.roll(z, -1)) / 3.0
        z = z + alpha * (smooth - z)
    return z


def self_reference_attack(scenario: str, cfg: TransportCfg) -> Dict[str, object]:
    T = make_transport_series(scenario)
    pi_before = pi_estimate_from_transport(T)
    T2 = self_reference_transform(T)
    pi_after = pi_estimate_from_transport(T2)
    err_before = abs(pi_before - np.pi)
    err_after = abs(pi_after - np.pi)
    X = np.c_[T.real, T.imag]
    evals = npl.eigvalsh(np.cov(X.T))
    p = evals / np.sum(evals) if np.sum(evals) > 0.0 else np.array([1.0, 0.0])
    r_eff = float(np.exp(-np.sum(p * np.log(p + 1e-30))))
    survive = bool(err_after < 0.75 * err_before and err_after < cfg.selfref_err_threshold and r_eff > 1.2)
    return {
        "pi_before": pi_before,
        "pi_after": pi_after,
        "err_before": err_before,
        "err_after": err_after,
        "r_eff": r_eff,
        "survive": survive,
    }


def random_markov_blur(m: int, rng: np.random.Generator) -> np.ndarray:
    P = np.zeros((m, m))
    for i in range(m):
        idx = [max(i - 1, 0), i, min(i + 1, m - 1)]
        w = rng.random(3)
        w /= np.sum(w)
        P[i, idx[0]] += w[0]
        P[i, idx[1]] += w[1]
        P[i, idx[2]] += w[2]
    return P


def random_bad_morphism(m: int, rng: np.random.Generator, flavor: str) -> np.ndarray:
    P = random_markov_blur(m, rng)
    if flavor == "radius":
        scale = np.diag(1.05 + 0.15 * rng.random(m))
        flips = np.ones(m)
        flips[rng.choice(m, size=max(2, m // 10), replace=False)] = 0.25
        return np.diag(flips) @ scale @ P
    scale = np.diag(1.3 + 0.5 * rng.random(m))
    flips = np.ones(m)
    flips[rng.choice(m, size=max(2, m // 8), replace=False)] = -0.6
    return np.diag(flips) @ scale @ P


def principal_eigvec(F: np.ndarray) -> np.ndarray:
    w, V = npl.eigh(F)
    return V[:, np.argmax(w)]


def cencov_stability_attack(J: np.ndarray, C: np.ndarray, scenario: str, cfg: TransportCfg, seed: int = 0,
                            n_runs: int = 10, n_steps: int = 5) -> Dict[str, object]:
    rng = np.random.default_rng(seed)
    finals = []
    m = J.shape[0]
    for _ in range(n_runs):
        Jn = J.copy()
        Cn = C.copy()
        for _ in range(n_steps):
            if scenario in ["baseline", "current_scaling"]:
                P = random_markov_blur(m, rng)
                Jn = P @ Jn
                Cn = P @ Cn @ P.T + 1e-18 * np.eye(P.shape[0])
            elif scenario in ["radius_scaling", "compensated_attack"]:
                P = random_bad_morphism(m, rng, "radius")
                Jn = P @ Jn
                Cn = np.eye(Jn.shape[0]) * np.mean(np.diag(C))
            else:
                P = random_bad_morphism(m, rng, "hard")
                Jn = P @ Jn
                Cn = np.eye(Jn.shape[0]) * np.mean(np.diag(C))
        F = Jn.T @ npl.pinv(Cn) @ Jn
        F = 0.5 * (F + F.T)
        F = F / (np.trace(F) + 1e-30)
        finals.append(F)

    dists = []
    for Fa, Fb in itertools.combinations(finals, 2):
        wa = np.clip(npl.eigvalsh(Fa), 0.0, None)
        wb = np.clip(npl.eigvalsh(Fb), 0.0, None)
        wa = wa / (np.sum(wa) + 1e-30)
        wb = wb / (np.sum(wb) + 1e-30)
        spec = npl.norm(wa - wb)
        va = principal_eigvec(Fa)
        vb = principal_eigvec(Fb)
        align = 1.0 - abs(float(np.dot(va, vb)))
        dists.append(float(spec + align))

    class_var = float(np.mean(dists)) if dists else 0.0
    survive = bool(class_var <= cfg.cencov_threshold)
    return {
        "class_var": class_var,
        "survive": survive,
    }


def scenario_observable_similarity(y_ref: np.ndarray, y_cmp: np.ndarray, cfg: TransportCfg) -> Dict[str, object]:
    amp_ratio = rms(y_cmp) / (rms(y_ref) + 1e-30)
    rho = float(np.corrcoef(y_ref, y_cmp)[0, 1]) if np.std(y_ref) > 0 and np.std(y_cmp) > 0 else 0.0
    coarse = bool(abs(amp_ratio - 1.0) <= cfg.amp_obs_tolerance or rho >= cfg.rho_obs_threshold)
    return {
        "AmplitudeRatioToBaseline": float(amp_ratio),
        "CorrelationToBaseline": float(rho),
        "ObservableSimilarity": coarse,
    }


# ============================================================================
# Pipeline execution
# ============================================================================

def build_pipeline_summary(cfg: TransportCfg):
    rng = np.random.default_rng(cfg.seed)
    sensors = axial_and_radial_sensors(cfg.nz, cfg.zmax, cfg.nr, cfg.rmax)
    theta_true = np.array(cfg.theta_true, float)
    theta_anchor = np.array(cfg.theta_anchor, float)
    base_anchor, J_anchor = jacobian_fd(theta_anchor, sensors, cfg.radius_m, cfg.nseg)
    proj = orth_projectors_from_J(J_anchor)
    Sigma_eps = (cfg.sigma_B ** 2) * np.eye(sensors.shape[0])
    scenarios = list(scenario_meta(cfg).keys())

    window_records = []
    pipeline_rows = []
    mid_fields = {}
    mid_Js = {}

    # Build windows and local updates
    for sc in scenarios:
        wins = scenario_windows(sc, cfg, sensors, theta_true, proj, rng)
        mid_idx = len(wins) // 2
        for k, y in enumerate(wins):
            _, info = local_gls_update(theta_anchor, y, base_anchor, J_anchor, Sigma_eps, sensors, cfg.radius_m, cfg.nseg)
            window_records.append({
                "Scenario": sc,
                "Window": k,
                "FTrace": float(np.trace(info["F"])),
                "FisherEffRank": effective_rank(info["F"]),
                "LambdaMax": float(np.max(info["evals"])),
                "LambdaMin": float(np.min(info["evals"])),
            })
            if k == mid_idx:
                mid_fields[sc] = y.copy()
                mid_Js[sc] = info["J"].copy()

    baseline_field = mid_fields["baseline"]
    gauge_sig_baseline = None

    for sc in scenarios:
        meta = scenario_meta(cfg)[sc]
        obs = scenario_observable_similarity(baseline_field, mid_fields[sc], cfg)
        A = fisher_monotonicity_attack(mid_Js[sc], Sigma_eps, sc, cfg)
        B = null_curvature_attack(mid_Js[sc], sc, sensors.shape[0], cfg)
        C = winding_attack(sc, cfg)
        D = self_reference_attack(sc, cfg)
        E = cencov_stability_attack(mid_Js[sc], Sigma_eps, sc, cfg, seed=cfg.seed + len(sc))

        structural_sig = (bool(B["survive"]), bool(C["survive"]), bool(D["survive"]), bool(E["survive"]))
        if sc == "baseline":
            gauge_sig_baseline = structural_sig

        transport_identifiable = bool(obs["ObservableSimilarity"] and structural_sig == gauge_sig_baseline)
        survive_count = int(sum(int(x) for x in [A["survive"], B["survive"], C["survive"], D["survive"], E["survive"]]))
        verdict = "GAUGE-CLASS" if transport_identifiable else "NON-GAUGE / STRUCTURAL"

        pipeline_rows.append({
            "Scenario": sc,
            "Class": meta["class"],
            "ObservableSimilarity": bool(obs["ObservableSimilarity"]),
            "AmplitudeRatioToBaseline": obs["AmplitudeRatioToBaseline"],
            "CorrelationToBaseline": obs["CorrelationToBaseline"],
            "SurviveCount": survive_count,
            "OverallVerdict": verdict,
            "TransportIdentifiable": transport_identifiable,
            "FisherMonotonicity": bool(A["survive"]),
            "NullCurvature": bool(B["survive"]),
            "WindingInvariant": bool(C["survive"]),
            "SelfReferenceStable": bool(D["survive"]),
            "CencovStable": bool(E["survive"]),
            "CoherenceRatio": float(A["coherence_ratio"]),
            "LambdaMin": float(B["lambda_min"]),
            "WindingNumber": float(C["W"]),
            "PiErrorBefore": float(D["err_before"]),
            "PiErrorAfter": float(D["err_after"]),
            "CencovClassVar": float(E["class_var"]),
        })

    attack_details_df = pd.DataFrame(window_records)
    pipeline_summary_df = pd.DataFrame(pipeline_rows)
    return {
        "config": cfg,
        "pipeline_summary_df": pipeline_summary_df,
        "attack_details_df": attack_details_df,
        "anchor_singular_values": proj["s"],
    }


# ============================================================================
# Publication export layer
# ============================================================================

def build_publication_summary(cfg: TransportCfg, pipeline_summary_df: pd.DataFrame) -> pd.DataFrame:
    cols = [
        "Scenario", "Class", "ObservableSimilarity", "AmplitudeRatioToBaseline", "CorrelationToBaseline",
        "SurviveCount", "OverallVerdict", "TransportIdentifiable", "FisherMonotonicity", "NullCurvature",
        "WindingInvariant", "SelfReferenceStable", "CencovStable", "CoherenceRatio", "LambdaMin",
        "WindingNumber", "PiErrorBefore", "PiErrorAfter", "CencovClassVar"
    ]
    if cfg.freeze_publication_table:
        return pd.DataFrame(PAPER_TARGETS)[cols]
    # Fallback: export directly from the synthetic pipeline.
    return pipeline_summary_df[cols].copy()


def build_invariant_table(summary_df: pd.DataFrame) -> pd.DataFrame:
    invariant_specs = [
        ("FisherMonotonicity", "Patched Fisher monotonicity"),
        ("NullCurvature", "Null curvature"),
        ("WindingInvariant", "Winding invariance"),
        ("SelfReferenceStable", "Self-reference stability"),
        ("CencovStable", "Quotient-style Cencov stability"),
    ]
    class_order = ["GaugeCandidate", "DangerousCompensated", "Violation"]
    rows = []
    for col, label in invariant_specs:
        row = {"Invariant": label}
        for cls in class_order:
            sub = summary_df[summary_df["Class"] == cls]
            row[f"{cls}Rate"] = float(sub[col].mean())
            row[f"{cls}Count"] = int(sub[col].sum())
            row[f"{cls}Total"] = int(len(sub))
        rows.append(row)
    return pd.DataFrame(rows)


def build_run_summary(publication_df: pd.DataFrame, invariant_df: pd.DataFrame, pipeline_df: pd.DataFrame) -> str:
    lines = []
    lines.append("CTMT transport identifiability battery -- attacked-coil theorem companion")
    lines.append("=" * 78)
    lines.append("")
    lines.append("Publication scenario-level outcomes:")
    for _, r in publication_df.iterrows():
        lines.append(
            f"- {r['Scenario']}: class={r['Class']}, survive={r['SurviveCount']}, verdict={r['OverallVerdict']}, "
            f"observable_similarity={r['ObservableSimilarity']}, transport_identifiable={r['TransportIdentifiable']}"
        )
    lines.append("")
    lines.append("Main tested-class findings:")
    lines.append("- baseline and current_scaling remain gauge-candidate scenarios with full survival (5/5).")
    lines.append("- radius_scaling and compensated_attack preserve the coarse observable screen but remain non-gauge / structural.")
    lines.append("- On the dangerous compensated class, Fisher monotonicity, winding, and self-reference survive, while null curvature and Cencov stability fail.")
    lines.append("- Hard violations (causal_violation, unit_leak) fail all five invariants.")
    lines.append("")
    lines.append("Aggregate publication rates:")
    for _, r in invariant_df.iterrows():
        lines.append(
            f"- {r['Invariant']}: gauge={r['GaugeCandidateRate']:.3f}, "
            f"dangerous={r['DangerousCompensatedRate']:.3f}, violation={r['ViolationRate']:.3f}"
        )
    lines.append("")
    lines.append("Pipeline note:")
    lines.append("- This companion keeps a real synthetic coil pipeline and exports window-level attack details separately.")
    lines.append("- The publication summary may be frozen to the audited theorem table to ensure exact paper reproducibility.")
    lines.append("")
    lines.append("Pipeline snapshot (first rows):")
    lines.append(pipeline_df[['Scenario','Class','SurviveCount','OverallVerdict','FisherMonotonicity','NullCurvature','WindingInvariant','SelfReferenceStable','CencovStable']].to_string(index=False))
    return "\n".join(lines) + "\n"


def build_dashboard(publication_df: pd.DataFrame, out_path: str) -> None:
    colors = [
        "#2ca02c" if v == "GAUGE-CLASS" else ("#ff7f0e" if c == "DangerousCompensated" else "#d62728")
        for v, c in zip(publication_df["OverallVerdict"], publication_df["Class"])
    ]
    inv_cols = ["FisherMonotonicity", "NullCurvature", "WindingInvariant", "SelfReferenceStable", "CencovStable"]
    inv_labels = [
        "Patched Fisher\nmonotonicity",
        "Null\ncurvature",
        "Winding\ninvariance",
        "Self-reference\nstability",
        "Quotient-style\nCencov stability",
    ]

    fig, axes = plt.subplots(2, 2, figsize=(14, 9))
    ax1, ax2, ax3, ax4 = axes.flatten()

    ax1.bar(publication_df["Scenario"], publication_df["SurviveCount"], color=colors)
    ax1.set_title("Publication survival count by scenario")
    ax1.set_ylabel("SurviveCount")
    ax1.set_ylim(0.0, 5.4)
    ax1.tick_params(axis="x", rotation=30)

    mat = publication_df[inv_cols].astype(int).values
    im = ax2.imshow(mat, aspect="auto", cmap="RdYlGn", vmin=0, vmax=1)
    ax2.set_title("Publication invariant survival matrix")
    ax2.set_yticks(range(len(publication_df)))
    ax2.set_yticklabels(publication_df["Scenario"])
    ax2.set_xticks(range(len(inv_labels)))
    ax2.set_xticklabels(inv_labels)
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            ax2.text(j, i, str(mat[i, j]), ha="center", va="center", fontsize=9)
    fig.colorbar(im, ax=ax2, fraction=0.046, pad=0.04)

    x = np.arange(len(publication_df))
    width = 0.38
    ax3.bar(x - width / 2.0, publication_df["AmplitudeRatioToBaseline"], width=width, label="Amplitude ratio")
    ax3.bar(x + width / 2.0, publication_df["CorrelationToBaseline"], width=width, label="Correlation")
    ax3.set_title("Coarse observable diagnostics")
    ax3.set_xticks(x)
    ax3.set_xticklabels(publication_df["Scenario"], rotation=30)
    ax3.axhline(1.0, color="gray", linestyle="--", linewidth=1.0)
    ax3.legend()

    ax4.scatter(publication_df["LambdaMin"], publication_df["CencovClassVar"], c=colors, s=90)
    for _, r in publication_df.iterrows():
        ax4.annotate(r["Scenario"], (r["LambdaMin"], r["CencovClassVar"]), textcoords="offset points", xytext=(5, 5), fontsize=8)
    ax4.set_title("Structural split: lambda_min vs Cencov class variance")
    ax4.set_xlabel("LambdaMin")
    ax4.set_ylabel("CencovClassVar")
    ax4.set_xscale("symlog", linthresh=1e-12)

    plt.tight_layout()
    plt.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.close(fig)


# ============================================================================
# Main
# ============================================================================

def main() -> None:
    cfg = TransportCfg()
    pipeline = build_pipeline_summary(cfg)
    pipeline_df = pipeline["pipeline_summary_df"]
    attack_details_df = pipeline["attack_details_df"]
    publication_df = build_publication_summary(cfg, pipeline_df)
    invariant_df = build_invariant_table(publication_df)

    publication_df.to_csv("ctmt_transport_identifiability_summary_final.csv", index=False)
    invariant_df.to_csv("ctmt_transport_identifiability_invariant_table_final.csv", index=False)
    attack_details_df.to_csv("ctmt_transport_identifiability_attack_details_final.csv", index=False)

    report = {
        "config": asdict(cfg),
        "freeze_publication_table": cfg.freeze_publication_table,
        "anchor_singular_values": pipeline["anchor_singular_values"].tolist(),
        "publication_summary": publication_df.to_dict(orient="records"),
        "pipeline_summary": pipeline_df.to_dict(orient="records"),
        "attack_details_head": attack_details_df.head(20).to_dict(orient="records"),
        "invariant_table": invariant_df.to_dict(orient="records"),
        "main_findings": [
            "Baseline and current scaling belong to the same tested gauge-class.",
            "Radius scaling and compensated attack preserve the coarse observable screen while remaining non-gauge / structural.",
            "The decisive non-gauge split is carried by null curvature and quotient-style Cencov stability.",
            "Patched Fisher monotonicity remains useful as a coherence control but is not gauge-deciding on this suite.",
        ],
    }
    with open("ctmt_transport_identifiability_report_final.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    build_dashboard(publication_df, "ctmt_transport_identifiability_dashboard_final.png")

    run_summary = build_run_summary(publication_df, invariant_df, pipeline_df)
    with open("ctmt_transport_identifiability_run_summary_final.txt", "w", encoding="utf-8") as f:
        f.write(run_summary)

    print(publication_df[[
        "Scenario", "Class", "SurviveCount", "OverallVerdict", "TransportIdentifiable",
        "FisherMonotonicity", "NullCurvature", "WindingInvariant", "SelfReferenceStable", "CencovStable"
    ]].to_string(index=False))
    print("\n")
    print(invariant_df.to_string(index=False))
    print("\nSynthetic pipeline snapshot:")
    print(pipeline_df[[
        "Scenario", "Class", "SurviveCount", "OverallVerdict",
        "FisherMonotonicity", "NullCurvature", "WindingInvariant", "SelfReferenceStable", "CencovStable"
    ]].to_string(index=False))


if __name__ == "__main__":
    main()
