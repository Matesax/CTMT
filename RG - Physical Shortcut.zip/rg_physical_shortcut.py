"""RG physical shortcut lock: what geometry with ordinary (NEC-respecting) matter can and cannot shorten.
P1  light (null) can only be delayed by kinetic sources (first-order theorem; imported from rg_no_shortcut).
P2  massive travellers: transit sign law dt/dl = (1/v)[1 + |Phi|((2+gamma) - 1/v^2)] at first order:
    slow travellers (v^2 < 1/(2+gamma)) ARRIVE EARLIER through a positive-mass well than on the flat reference with the
    same launch energy; fast ones are delayed. Exact geodesic integration of the declared PPN metric.
P3  the sign-flip speed v_c = 1/sqrt(2+gamma) measures gamma (two-speed panel; duality paper).
P4  gravity train: propulsion-free chord transit, T = pi sqrt(R^3/GM), independent of chord length (uniform sphere).
P5  anchored advantage certificates: T_route_upper < T_reference_lower with the same departure event, destination
    worldline and clock, including the coverage-error budget.
Run: python rg_physical_shortcut.py   (numpy, scipy)
"""
import json, math, hashlib, pathlib
import numpy as np
import warnings; warnings.filterwarnings("ignore")
from scipy.integrate import quad, solve_ivp

RES = {}
def must(c, m):
    if not c: raise AssertionError(m)

# ---------------- P2 exact transit time in the declared weak-field metric
def transit_excess(v, gamma, GM=1e-4, b=1.0, L=200.0):
    """ds^2 = -(1+2Phi)dt^2 + (1-2 gamma Phi)dx^2, Phi = -GM/sqrt(x^2+b^2); straight radial path through the centre
    (a geodesic by symmetry). E fixed by the launch speed v at infinity. Returns coordinate-time excess over 2L/v."""
    E = 1 / math.sqrt(1 - v * v)
    def dtdx(x):
        P = -GM / math.sqrt(x * x + b * b); A = 1 + 2 * P; B = 1 - 2 * gamma * P
        return (E / A) / math.sqrt((E * E / A - 1) / B)
    exact = quad(lambda x: dtdx(x) - 1 / v, -L, L, limit=400, epsabs=1e-14, epsrel=1e-12)[0]
    first = quad(lambda x: (1 / v) * (GM / math.sqrt(x * x + b * b)) * ((2 + gamma) - 1 / (v * v)), -L, L, limit=400)[0]
    return exact, first
rows = []
for gamma in (1.0, 0.0):
    vc = 1 / math.sqrt(2 + gamma)
    for v in (0.05, 0.2, 0.4, vc - 0.02, vc + 0.02, 0.8, 0.95, 0.999):
        ex, fo = transit_excess(v, gamma)
        rows.append(dict(gamma=gamma, v=round(v, 4), exact_excess=ex, first_order=fo, sign=("ADVANCE" if ex < 0 else "DELAY")))
        must((ex < 0) == (v < vc), f"sign law gamma={gamma} v={v}")
        must(abs(ex - fo) <= 0.05 * abs(fo) + 1e-9, f"first order gamma={gamma} v={v}")
RES["P2"] = dict(claim="Positive-mass wells advance slow travellers and delay fast ones (same launch energy, same endpoints)",
                 status="LOCKED (first-order theorem; exact metric integration)", rows=rows)

# independent check by integrating the geodesic ODE in proper time (gamma = 1, v = 0.2)
def geodesic_time(v, gamma, GM=1e-4, b=1.0, L=200.0):
    E = 1 / math.sqrt(1 - v * v)
    def rhs(tau, y):
        t, x = y; P = -GM / math.sqrt(x * x + b * b); A = 1 + 2 * P; B = 1 - 2 * gamma * P
        tdot = E / A; xdot = math.sqrt(max((E * E / A - 1) / B, 0.0)); return [tdot, xdot]
    ev = lambda tau, y: y[1] - L; ev.terminal = True
    sol = solve_ivp(rhs, [0, 1e7], [0.0, -L], events=ev, rtol=1e-12, atol=1e-12, max_step=0.5)
    return sol.y_events[0][0][0] - 2 * L / v
g_ode = geodesic_time(0.2, 1.0); g_quad = transit_excess(0.2, 1.0)[0]
must(abs(g_ode - g_quad) < 1e-6 * max(1, abs(g_quad)), "ODE vs quadrature")
RES["P2_crosscheck"] = dict(ode_excess=g_ode, quadrature_excess=g_quad, status="AGREE")

# ---------------- P3 sign-flip speed measures gamma
def flip_speed(gamma):
    lo, hi = 0.3, 0.95
    for _ in range(60):
        mid = (lo + hi) / 2
        if transit_excess(mid, gamma)[0] < 0: lo = mid
        else: hi = mid
    return (lo + hi) / 2
flips = {g: (flip_speed(g), 1 / math.sqrt(2 + g)) for g in (0.0, 0.5, 1.0)}
must(all(abs(a - b) < 2e-3 for a, b in flips.values()), "flip speeds")
RES["P3"] = dict(claim="The advance/delay sign flips at v_c = 1/sqrt(2+gamma): a two-speed transit panel measures gamma",
                 status="LOCKED (first order; exact integration agrees to 2e-3)",
                 flips={str(k): dict(measured=a, predicted=b) for k, (a, b) in flips.items()})

# ---------------- P4 gravity train (uniform sphere, Newtonian; GR corrections ~ GM/(R c^2) ~ 7e-10)
GM_E, R_E = 3.986004418e14, 6.371e6
T_half = math.pi * math.sqrt(R_E ** 3 / GM_E)
chords = {}
for ang in (10, 60, 120, 180):
    d = 2 * R_E * math.sin(math.radians(ang) / 2)                      # chord length
    w = math.sqrt(GM_E / R_E ** 3)
    # SHM along the chord from rest: x(t) = (d/2) cos(w t): arrival at half period, independent of d
    t_arr = math.pi / w
    surface = R_E * math.radians(ang)
    chords[ang] = dict(chord_km=d / 1e3, transit_min=t_arr / 60, surface_speed_needed_km_s=surface / t_arr / 1e3)
must(all(abs(c["transit_min"] - T_half / 60) < 1e-9 for c in chords.values()), "chord independence")
RES["P4"] = dict(claim="Gravity train: propulsion-free chord transit in pi sqrt(R^3/GM), independent of chord",
                 status="LOCKED (Newtonian, uniform density, frictionless, evacuated tunnel; declared)",
                 T_half_min=T_half / 60, chords=chords,
                 note="Non-uniform (PREM-like) Earth gives a shorter antipodal time; tunnel engineering, friction and heat "
                      "are not addressed.")

# ---------------- P5 anchored advantage certificates with a coverage error budget
def certificate(exact_route, reference, budget):
    """route arrival upper bound vs reference lower bound (same departure event, same destination worldline/clock)"""
    return dict(route_upper=exact_route + budget, reference_lower=reference - budget,
                certified=(exact_route + budget) < (reference - budget))
v = 0.2; GM = 1e-4; L = 200.0
ex = transit_excess(v, 1.0, GM=GM, L=L)[0]
cert_slow = certificate(2 * L / v + ex, 2 * L / v, budget=0.25 * abs(ex))           # coverage budget 25% of the effect
cert_fast = certificate(2 * L / 0.95 + transit_excess(0.95, 1.0)[0], 2 * L / 0.95, budget=0.0)
light_ok = True                                                                   # P1: imported theorem
must(cert_slow["certified"] and not cert_fast["certified"], "P5")
RES["P5"] = dict(claim="Anchored advantage certificate (route upper < reference lower)", status="LOCKED for slow transit; REFUSED for fast",
                 slow_v0p2=cert_slow, fast_v0p95=cert_fast,
                 reference="flat route with the same launch energy; the light reference is never beaten (P1)")
RES["P1"] = dict(claim="No null time advance from NEC-respecting (kinetic) sources", status="IMPORTED (rg_no_shortcut.py; Gao-Wald)")
RES["throat"] = dict(claim="Ellis-Bronnikov throat crossing (uploaded coverage-control package)",
                     status="CONDITIONAL ONLY: crossing/arrival windows certified given K1, K2 bounds; source fails NEC; global comparison unresolved")
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_physical_shortcut_results.json").write_text(json.dumps(RES, indent=1, default=float))
for k, v_ in RES.items():
    if isinstance(v_, dict): print(k, v_.get("status", ""))
print({r['v']: r['sign'] for r in rows if r['gamma'] == 1.0}); print(flips); print(round(T_half / 60, 3), cert_slow)
