"""RG no-shortcut lock (linearized GR, declared): kinetic sources can only DELAY light.
For h_bar_ab = 4G * int T_ab(x')/|x-x'| (static or retarded, harmonic gauge), a null ray k = (1, n) has
    delta_t = (1/2) int h_ab k^a k^b dl = 2G int dl int T_ab k^a k^b / |x - x'| d^3x'
because eta_ab k^a k^b = 0. RG kinetic sources T_ab = int p_a p_b dmu give T_ab k^a k^b = int (p.k)^2 dmu >= 0, so
delta_t >= 0 for every ray: no time advance (no shortcut) at first order. Full-GR versions are imported (Gao-Wald;
topological censorship). Run: python rg_no_shortcut.py   (numpy)
"""
import json, math, hashlib, pathlib
import numpy as np
G = 1.0; rng = np.random.default_rng(20261104)
eta = np.diag([-1.0, 1, 1, 1])

def kinetic_T(ms, us):
    """point particles: T^{ab} density weights m u^a u^b / u^0 (positive momentum measure)"""
    return [m * np.outer(u, u) / u[0] for m, u in zip(ms, us)]
def four_velocity(v):
    g = 1 / math.sqrt(1 - v @ v); return g * np.r_[1.0, v]
def null_contraction(T, n):
    k = np.r_[1.0, n]; kl = eta @ k; return float(kl @ T @ kl)
def delay(Ts, xs, n, x0, L=2000.0, N=40001, soft=0.05):
    """first-order coordinate-time delay of a straight null ray x0 + s n, s in [-L, L]"""
    s = np.linspace(-L, L, N); pts = x0[None, :] + s[:, None] * n[None, :]
    tot = np.zeros(N)
    for T, xp in zip(Ts, xs):
        d = np.sqrt(np.sum((pts - xp) ** 2, axis=1) + soft ** 2)
        tot += 2 * G * null_contraction(T, n) / d
    return float(np.trapezoid(tot, s))

# ---- K1 kinetic sources: every ray delayed
mins = []; checks = 0
for trial in range(200):
    npart = rng.integers(1, 6); ms = rng.uniform(0.1, 2, npart)
    vs = [rng.normal(size=3) * rng.uniform(0, 0.95) / math.sqrt(3) for _ in range(npart)]
    vs = [v if np.linalg.norm(v) < 0.99 else v / np.linalg.norm(v) * 0.9 for v in vs]
    us = [four_velocity(v) for v in vs]; Ts = kinetic_T(ms, us)
    xs = [rng.normal(size=3) * 5 for _ in range(npart)]
    n = rng.normal(size=3); n /= np.linalg.norm(n); x0 = rng.normal(size=3) * 5
    dl = delay(Ts, xs, n, x0)
    nec = min(null_contraction(T, n) for T in Ts)
    mins.append(dl); checks += 1
    assert nec >= -1e-12 and dl > 0, (trial, nec, dl)
# ---- K2 closed form check: one static mass, impact parameter b: delay = 2GM * int ds / sqrt(s^2+b^2) ~ 4GM ln(2L/b)
M, b, L = 1.0, 10.0, 2000.0
dl_num = delay(kinetic_T([M], [np.r_[1.0, 0, 0, 0]]), [np.zeros(3)], np.array([1.0, 0, 0]), np.array([0, b, 0.0]), L=L, soft=0.0)
dl_exact = 4 * G * M * math.asinh(L / b)
assert abs(dl_num - dl_exact) / dl_exact < 1e-4
# ---- K3 canary: the throat's phantom source (rho = p_r = -a^2/(l^2+a^2)^2, p_t = +...) violates NEC radially
a = 1.0; ls = np.linspace(-10, 10, 2001)
nec_radial = -2 * a * a / (ls ** 2 + a * a) ** 2          # rho + p_r
assert nec_radial.max() < 0
# a source with T_ab k^a k^b < 0 gives a time ADVANCE at first order
Tneg = np.diag([-1.0, -1.0, 0.3, 0.3])                     # rho = p_x = -1 (radial-like NEC violation along x)
adv = delay([Tneg], [np.zeros(3)], np.array([1.0, 0, 0]), np.array([0, 10.0, 0]), soft=0.0)
assert adv < 0
out = dict(
    K1=dict(claim="Kinetic (RG momentum-law) sources delay every null ray at first order", trials=checks,
            min_delay=min(mins), status="LOCKED (theorem + 200 random multi-particle, moving-source witnesses)"),
    K2=dict(claim="Formula check against the static point-mass Shapiro integral", numeric=dl_num, exact=dl_exact,
            status="LOCKED"),
    K3=dict(claim="A shortcut (time advance) needs T_ab k^a k^b < 0", throat_NEC_max=float(nec_radial.max()),
            advance=adv, status="LOCKED: the uploaded throat's source is exactly of this kind"),
    source_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest())
pathlib.Path("rg_no_shortcut_results.json").write_text(json.dumps(out, indent=1))
print(json.dumps({k: (v if not isinstance(v, dict) else {kk: vv for kk, vv in v.items() if kk != 'claim'}) for k, v in out.items()}, indent=1))
