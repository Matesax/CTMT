#!/usr/bin/env python3
"""Mutation suite for rg_particle_resolution.py.

Each mutation changes one line so that the battery asserts something false. The battery must then report the targeted
group as failed. A mutation that survives is a defect of the battery. Runs in a temporary directory; shipped files are
not modified. Under a minute.

    python3 -I rg_particle_resolution_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
MUTATIONS = [
    ('PA', 'a cell allowed to hold half the quantum at L = 1000', "out[1000]['largest_cell_probability'] < 0.02", "out[1000]['largest_cell_probability'] > 0.5"),
    ('PA', 'an active term in the interferometer', "H = th * (np.exp(1j * ph) * a.conj().T @ b + np.exp(-1j * ph) * b.conj().T @ a)", "H = th * (np.exp(1j * ph) * a.conj().T @ b + np.exp(-1j * ph) * b.conj().T @ a + a @ b + a.conj().T @ b.conj().T)"),
    ('PB', 'the ball given coherence 0.1', "vis = {g: screen(g) for g in (1.0, 0.9, 0.5, 0.0)}", "vis = {g: screen(g if g else 0.1) for g in (1.0, 0.9, 0.5, 0.0)}"),
    ('PC', 'the polarizability misquoted as 4', "polar = sp.Rational(9, 2)", "polar = sp.Rational(4)"),
    ('PD', 'the NIST-17 value misquoted', "'NIST-17 (Kibble)': (6.626069934e-34, 0.000000088e-34)", "'NIST-17 (Kibble)': (6.626070334e-34, 0.000000088e-34)"),
    ('PE', 'the squeezing generator made passive', "S = expm(r * (a @ b - a.conj().T @ b.conj().T))", "S = expm(r * (a.conj().T @ b - b.conj().T @ a))"),
    ('PF', 'one context sign flipped', "sgn = [1, 1, 1, 1, 1, -1]", "sgn = [1, 1, 1, 1, -1, -1]"),
]


def main():
    base = open(os.path.join(HERE, 'rg_particle_resolution.py')).read()
    caught = 0
    for group, name, old, new in MUTATIONS:
        if base.count(old) != 1:
            print(f'{group}  {name}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            open(os.path.join(tmp, 'rg_particle_resolution.py'), 'w').write(base.replace(old, new))
            run = subprocess.run([sys.executable, '-I', 'rg_particle_resolution.py'], cwd=tmp, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(tmp, 'rg_particle_resolution_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']                                     # a crash is a defect of the suite, not a catch
        ok = group in fails
        caught += ok
        print(f"{group}  {name}: {'caught ' + str(fails) if ok else 'SURVIVED'}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
