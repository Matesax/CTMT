#!/usr/bin/env python3
"""Resolution Geometry - One World and the Particle: why probes resolve particles, and what that does not prove.

Claim tested. Protocols that count a conserved quantity give integers that agree across methods whatever the spatial extent
of the state. Agreement of counts is therefore forced by conservation and discreteness, not by localization. Extent is
resolved only by other protocols, which give protocol-dependent sizes or interference; particle number itself becomes
protocol-dependent once a protocol exchanges energy with the vacuum. One state reproduces every protocol (One World).

  PA counting: one quantum in a mode spread over L cells, for any L, gives exactly one click and no coincidence (g2 = 0),
     the same as a localized ball; N quanta in a random mode give total count N after any passive interferometer; canary:
     a classical wave of the same mean gives g2 = 1 and Poisson counts
  PB extent: one quantum in two paths gives fringes of visibility gamma (its coherence); a ball in one path or the other
     gives none, whatever the counting statistics; canary: gamma = 0 reproduces the ball exactly
  PC size: for the hydrogen ground state five size protocols give five radii (a0, 1.5 a0, 1.651 a0, sqrt 3 a0 and an edge
     radius that grows without bound with the threshold), while three energy protocols give one ionization energy; canary:
     a hard ball gives one edge radius for every threshold
  PD One World in metrology: atom counting in silicon spheres (XRCD) and the Kibble balance give the same Planck constant
     through the molar Planck constant; pairwise tensions and Birge ratio; canary: an offset of 1e-7 fails to glue
  PE particle number: a passive transformation conserves the count of every state; an active one (two-mode squeezing)
     gives the vacuum of one mode basis sinh^2 r quanta in the other; with tanh r = exp(-pi omega/a) this is the Unruh
     occupation 1/(exp(2 pi omega/a) - 1) exactly
  PF context-free values: Peres-Mermin square, all 512 value assignments give at most 4, quantum mechanics 6; measured
     5.46(4) on two trapped ions; canary: the classical maximum is attained

Deterministic. Seed 20261131. Writes rg_particle_resolution_results.json.
Run:  python3 -I rg_particle_resolution.py      (numpy, scipy, sympy)
"""
import hashlib, itertools, json, math, os, sys
import numpy as np
import sympy as sp
from scipy.linalg import expm

HERE = os.path.dirname(os.path.abspath(__file__))
SEED = 20261131
R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v):
    return float(f'{float(v):.8g}')


def below(v, b):
    return f'< {b:g}' if abs(v) < b else fl(v)


# ============================================================================================ Fock-space tools
def ladder(cut):
    return np.diag(np.sqrt(np.arange(1, cut)), 1)


def two_mode(cut):
    a = ladder(cut); I = np.eye(cut)
    return np.kron(a, I), np.kron(I, a)


def PA():
    rng = np.random.default_rng(SEED); out = {}
    for L in (2, 10, 1000):
        c = rng.normal(size=L) + 1j * rng.normal(size=L); c /= np.linalg.norm(c)
        p_click = np.abs(c) ** 2                                   # one quantum: exactly one detector clicks
        total_one = float(p_click.sum())
        coincidence = 0.0                                          # <a_i^dag a_j^dag a_j a_i> = 0 for a single quantum
        out[L] = dict(prob_total_count_1=total_one, coincidence=coincidence, largest_cell_probability=float(p_click.max()))
    # N quanta in a random two-mode state, passive interferometer: total count conserved exactly
    cut = 6; a, b = two_mode(cut); N = a.conj().T @ a + b.conj().T @ b
    th, ph = 0.73, 1.1
    H = th * (np.exp(1j * ph) * a.conj().T @ b + np.exp(-1j * ph) * b.conj().T @ a); U = expm(-1j * H)
    psi = np.zeros(cut * cut, complex); psi[3 * cut + 0] = 1.0                    # |3, 0>
    out_state = U @ psi
    probs = {}
    for n1, n2 in itertools.product(range(cut), repeat=2):
        p = abs(out_state[n1 * cut + n2]) ** 2
        if p > 1e-15:
            probs[n1 + n2] = probs.get(n1 + n2, 0.0) + p
    conserved = abs(probs.get(3, 0.0) - 1)
    # canary: coherent field of mean 1 (classical wave) gives Poisson counts and g2 = 1
    nbar = 1.0; p1 = nbar * math.exp(-nbar); g2_coh = 1.0
    ok = all(abs(v['prob_total_count_1'] - 1) < 1e-12 and v['coincidence'] == 0 for v in out.values()) and out[1000]['largest_cell_probability'] < 0.02 \
        and conserved < 1e-12 and abs(p1 - 0.3679) < 1e-3 and g2_coh == 1
    must(ok, 'PA')
    R['PA'] = dict(claim='Counting. One quantum spread over L = 2, 10 or 1000 cells gives exactly one click in total and no coincidence '
                         '(g2 = 0), although no cell holds more than 2 per cent of it for L = 1000. A localized ball gives the same '
                         'counts. Three quanta sent through a passive interferometer give total count 3 with probability 1 (residual '
                         'below 1e-12). Counting protocols therefore agree on "one" and on "three" whatever the extent: the agreement '
                         'is forced by conservation and an integer spectrum. Canary: a classical wave of mean 1 gives one count only '
                         'with probability 0.368 and g2 = 1.',
                   status='computed', single_quantum={str(k): {a_: fl(b_) for a_, b_ in v.items()} for k, v in out.items()},
                   passive_count_conservation=below(conserved, 1e-12), canary_coherent_p1=fl(p1))


def PB():
    x = np.linspace(0, 4 * np.pi, 4001)
    def screen(gamma):
        I = 1 + gamma * np.cos(x); return (I.max() - I.min()) / (I.max() + I.min())
    vis = {g: screen(g) for g in (1.0, 0.9, 0.5, 0.0)}
    # counting statistics of the two models are identical: one click per quantum
    ok = abs(vis[1.0] - 1) < 1e-9 and abs(vis[0.9] - 0.9) < 1e-9 and vis[0.0] < 1e-12
    must(ok, 'PB')
    R['PB'] = dict(claim='Extent. One quantum in an equal superposition of two paths with coherence gamma gives fringe visibility gamma '
                         '(1, 0.9, 0.5 reproduced). A ball that takes one path or the other is the case gamma = 0: no fringes '
                         '(canary), with the same one-click counting as before. Fringes built up one quantum at a time therefore '
                         'measure extent, and they exclude the ball for the interfering degree of freedom. Measured: single electrons '
                         '(Tonomura et al. 1989) and molecules of more than 25 000 Da and 2 000 atoms with more than 90 per cent of '
                         'the expected visibility (Fein et al. 2019).',
                   status='computed (model); MEASURED anchors quoted', visibility={str(k): fl(v) for k, v in vis.items()})


def PC():
    r, f = sp.symbols('r f', positive=True)
    rho = sp.exp(-2 * r) / sp.pi                                   # hydrogen 1s density, a0 = 1
    radial = 4 * sp.pi * r ** 2 * rho
    most_probable = sp.solve(sp.diff(radial, r), r)[0]
    mean_r = sp.integrate(r * radial, (r, 0, sp.oo)); rms = sp.sqrt(sp.integrate(r ** 2 * radial, (r, 0, sp.oo)))
    polar = sp.Rational(9, 2); r_pol = polar ** sp.Rational(1, 3)             # static polarizability 9/2 a0^3 (exact)
    # independent derivation (Dalgarno-Lewis): psi1 = -(r + r^2/2) cos(theta) psi0 solves (H0 - E0) psi1 = -z psi0
    th = sp.Symbol('theta'); psi0 = sp.exp(-r) / sp.sqrt(sp.pi); psi1 = -(r + r ** 2 / 2) * sp.cos(th) * psi0
    lap1 = sp.diff(r ** 2 * sp.diff(psi1, r), r) / r ** 2 + sp.diff(sp.sin(th) * sp.diff(psi1, th), th) / (r ** 2 * sp.sin(th))
    dl_residual = sp.simplify(-lap1 / 2 - psi1 / r + psi1 / 2 + r * sp.cos(th) * psi0)
    alpha_dl = sp.simplify(-2 * sp.integrate(sp.integrate(psi0 * r * sp.cos(th) * psi1 * 2 * sp.pi * r ** 2 * sp.sin(th), (th, 0, sp.pi)), (r, 0, sp.oo)))
    edge = sp.solve(sp.Eq(sp.exp(-2 * r), f), r)[0]                            # density fallen to fraction f of its maximum
    edges = {lab: float(edge.subs(f, t)) for lab, t in (('1e-3', 1e-3), ('1e-6', 1e-6), ('1e-9', 1e-9))}
    radii = dict(most_probable=float(most_probable), mean=float(mean_r), polarizability=float(r_pol), rms=float(rms))
    # energy protocols: Rydberg-series limit, photoionization threshold, virial theorem
    n = sp.Symbol('n', positive=True, integer=True); E_n = -sp.Rational(1, 2) / n ** 2
    series_limit = sp.limit(E_n, n, sp.oo) - E_n.subs(n, 1)
    psi = sp.exp(-r) / sp.sqrt(sp.pi)
    lap = sp.diff(r ** 2 * sp.diff(psi, r), r) / r ** 2
    T = sp.integrate(4 * sp.pi * r ** 2 * psi * (-lap / 2), (r, 0, sp.oo)); V = sp.integrate(4 * sp.pi * r ** 2 * psi ** 2 * (-1 / r), (r, 0, sp.oo))
    threshold = -(T + V); virial = T
    energies = dict(series_limit=float(series_limit), photoionization_threshold=float(threshold), virial_kinetic=float(virial))
    # canary: a hard ball of radius 1 has an edge independent of the threshold
    ball_edges = {lab: 1.0 for lab in ('1e-3', '1e-6', '1e-9')}
    spread = max(radii.values()) / min(radii.values())
    ok = dl_residual == 0 and alpha_dl == polar and abs(spread - math.sqrt(3)) < 1e-12 and len({round(v, 12) for v in energies.values()}) == 1 and abs(energies['series_limit'] - 0.5) < 1e-15 \
        and edges['1e-9'] > 2.9 * edges['1e-3'] and len(set(ball_edges.values())) == 1
    must(ok, 'PC')
    R['PC'] = dict(claim='Size. For the hydrogen ground state, four size protocols give four radii: most probable a0, mean 1.5 a0, '
                         'polarizability radius (9/2)^(1/3) a0 = 1.651 a0 (polarizability derived independently by the Dalgarno-Lewis method), root-mean-square sqrt 3 a0 = 1.732 a0, a spread of sqrt 3. '
                         'An edge radius, where the density falls to a fraction f of its maximum, is ln(1/f)/2 a0 and grows without '
                         'bound: 3.45, 6.91, 10.36 a0 for f = 1e-3, 1e-6, 1e-9. Three energy protocols (series limit, photoionization '
                         'threshold, virial kinetic energy) give one ionization energy, 1/2 hartree, exactly. Energy glues across '
                         'protocols; size does not. Canary: a hard ball has the same edge for every threshold.',
                   status='computed (exact)', radii_a0={k: fl(v) for k, v in radii.items()}, edge_radius_by_threshold={k: fl(v) for k, v in edges.items()},
                   ionization_energy_hartree={k: fl(v) for k, v in energies.items()}, polarizability_dalgarno_lewis=str(alpha_dl))


def PD():
    NAh = 6.62607015e-34 * 6.02214076e23                           # molar Planck constant (exact in the SI since 2019)
    xrcd = {'IAC-11 (XRCD)': (6.02214095e23, 0.00000018e23), 'IAC-15 (XRCD)': (6.02214070e23, 0.00000012e23),
            'IAC-17 (XRCD)': (6.022140526e23, 0.000000070e23), 'NMIJ-17 (XRCD)': (6.02214078e23, 0.00000015e23)}
    h = {k: (NAh / v, NAh / v * s / v) for k, (v, s) in xrcd.items()}
    h.update({'NIST-15 (Kibble)': (6.62606936e-34, 0.00000038e-34), 'NIST-17 (Kibble)': (6.626069934e-34, 0.000000088e-34),
              'NRC-17 (Kibble)': (6.626070133e-34, 0.000000060e-34), 'LNE-17 (Kibble)': (6.62607040e-34, 0.00000038e-34)})
    def glue(d, expand=1.0):
        v = np.array([a for a, _ in d.values()]); s = np.array([b for _, b in d.values()]) * expand; w = 1 / s ** 2
        m = float(np.sum(w * v) / np.sum(w)); chi2 = float(np.sum(w * (v - m) ** 2)); dof = len(v) - 1
        return m, chi2, dof, math.sqrt(chi2 / dof)
    m, chi2, dof, birge = glue(h); _, chi2e, _, birge_e = glue(h, 1.7)
    pair = lambda x, y: abs(h[x][0] - h[y][0]) / math.hypot(h[x][1], h[y][1])
    t1 = pair('NIST-17 (Kibble)', 'IAC-17 (XRCD)'); t2 = pair('NRC-17 (Kibble)', 'IAC-17 (XRCD)')
    spread = (max(v for v, _ in h.values()) - min(v for v, _ in h.values())) / m
    fake = dict(h); fake['NRC-17 (Kibble)'] = (h['NRC-17 (Kibble)'][0] * (1 + 3e-7), h['NRC-17 (Kibble)'][1])
    birge_fake = glue(fake, 1.7)[3]
    ok = abs(t1 - 4.0) < 0.1 and abs(t2 - 2.8) < 0.1 and spread < 2e-7 and birge > 1.3 and birge_e < 1.2 and abs(m / 6.62607015e-34 - 1) < 3e-8 and birge_fake > 3
    must(ok, 'PD')
    R['PD'] = dict(claim='One World in metrology. Counting atoms in enriched silicon spheres (XRCD) and weighing with electrical power '
                         'in Kibble balances use no common apparatus. Through the molar Planck constant N_A h, eight determinations '
                         '(four XRCD, four Kibble) give the Planck constant; all lie within the relative spread below. They glue only '
                         'roughly: NIST-17 against IAC-17 differs by 4.0 standard deviations and NRC-17 against IAC-17 by 2.8, as the '
                         'CODATA task group reported; the set has the Birge ratio below, and with the task group\'s expansion factor '
                         '1.7 it falls to about 1. The weighted mean lies within the relative distance below of the value fixed by the SI '
                         'in 2019. Canary: an offset of 3e-7 on one Kibble value breaks the gluing even after expansion.',
                   status='computed from MEASURED values (Mohr et al. 2018, CODATA 2017 special adjustment)',
                   h_by_protocol={k: [fl(a / 1e-34), fl(b / 1e-34)] for k, (a, b) in h.items()}, nist17_vs_iac17_sigma=fl(t1), nrc17_vs_iac17_sigma=fl(t2),
                   relative_spread=fl(spread), birge_ratio=fl(birge), birge_ratio_expanded_1_7=fl(birge_e), chi2=fl(chi2), dof=dof,
                   mean_vs_si_relative=fl(m / 6.62607015e-34 - 1), canary_birge_expanded=fl(birge_fake))


def PE():
    cut = 40; a, b = two_mode(cut); I = np.eye(cut * cut)
    vac = np.zeros(cut * cut, complex); vac[0] = 1.0
    na, nb = a.conj().T @ a, b.conj().T @ b
    # passive: beam splitter keeps every Fock state's total count
    Ubs = expm(-1j * 0.6 * (a.conj().T @ b + b.conj().T @ a))
    rng = np.random.default_rng(SEED + 4); psi = np.zeros(cut * cut, complex)
    for n1, n2 in ((2, 1), (0, 3), (1, 2)):
        psi[n1 * cut + n2] = rng.normal() + 1j * rng.normal()
    psi /= np.linalg.norm(psi); out = Ubs @ psi
    passive = abs(np.vdot(out, (na + nb) @ out).real - np.vdot(psi, (na + nb) @ psi).real)
    # active: two-mode squeezing; the vacuum of the squeezed modes holds sinh^2 r quanta per original mode
    r = 0.5; S = expm(r * (a @ b - a.conj().T @ b.conj().T)); sq = S @ vac
    n_sq = float(np.vdot(sq, na @ sq).real); exact = math.sinh(r) ** 2
    # Unruh: tanh r = exp(-pi w/a) gives sinh^2 r = 1/(exp(2 pi w/a) - 1)
    x = sp.Symbol('x', positive=True); rr = sp.atanh(sp.exp(-sp.pi * x))
    unruh = sp.simplify(sp.sinh(rr) ** 2 - 1 / (sp.exp(2 * sp.pi * x) - 1))
    ok = passive < 1e-10 and abs(n_sq - exact) < 1e-8 and unruh == 0
    must(ok, 'PE')
    R['PE'] = dict(claim='Particle number. A passive transformation conserves the mean count of any state (residual below). An active '
                         'one, two-mode squeezing with r = 0.5, turns the vacuum of one mode basis into sinh^2 r = 0.2715 quanta per mode '
                         'in the other, so the particle content of one and the same state depends on the protocol. With tanh r = '
                         'exp(-pi omega/a) this occupation equals the Unruh spectrum 1/(exp(2 pi omega/a) - 1) exactly: an accelerated '
                         'detector counts quanta in the inertial vacuum. Measured: photons produced from vacuum by a modulated boundary '
                         '(dynamical Casimir effect, Wilson et al. 2011).',
                   status='computed (Fock space, cutoff 40; symbolic identity); IDENTIFIED (Unruh 1976); MEASURED anchor quoted',
                   passive_count_change=below(passive, 1e-10), squeezed_occupation=fl(n_sq), exact=fl(exact), unruh_identity=str(unruh))


def PF():
    I2 = np.eye(2); X = np.array([[0, 1], [1, 0]]); Y = np.array([[0, -1j], [1j, 0]]); Z = np.diag([1, -1])
    k = np.kron
    obs = [k(X, I2), k(I2, X), k(X, X), k(I2, Y), k(Y, I2), k(Y, Y), k(X, Y), k(Y, X), k(Z, Z)]
    ctx = [(0, 1, 2), (3, 4, 5), (6, 7, 8), (0, 3, 6), (1, 4, 7), (2, 5, 8)]
    sgn = [1, 1, 1, 1, 1, -1]
    comm = max(np.abs(obs[i] @ obs[j] - obs[j] @ obs[i]).max() for c in ctx for i in c for j in c)
    prod = max(np.abs(obs[c[0]] @ obs[c[1]] @ obs[c[2]] - s_ * np.eye(4)).max() for c, s_ in zip(ctx, sgn))
    best = max(sum(s_ * v[c[0]] * v[c[1]] * v[c[2]] for c, s_ in zip(ctx, sgn)) for v in itertools.product((-1, 1), repeat=9))
    quantum = sum(s_ * s_ for s_ in sgn)                           # each context product equals its sign, for every state
    meas, err = 5.46, 0.04
    ok = comm < 1e-12 and prod < 1e-12 and best == 4 and quantum == 6 and (meas - 4) / err > 30
    must(ok, 'PF')
    R['PF'] = dict(claim='Context-free values. Nine observables of a four-level system in six compatible contexts (Peres-Mermin): every '
                         'context commutes and its product equals +1 or -1 (residuals 0). Any assignment of pre-existing values to the '
                         'nine observables, checked over all 512, gives at most 4; quantum mechanics gives 6 for every state. Measured '
                         'on a pair of trapped 40Ca+ ions: 5.46(4) for the singlet and 5.23(5) to 5.46(4) over ten states (Kirchmair et al. '
                         '2009), more than 30 standard deviations above 4. A carrier of context-free values is excluded on a few-atom '
                         'system by measurement, not by argument.',
                   status='computed (exact); MEASURED anchor (Kirchmair et al. 2009); IDENTIFIED (Peres 1990, Mermin 1990)',
                   commutator=below(comm, 1e-12), product=below(prod, 1e-12), classical_max=int(best), quantum_value=quantum, measured=[meas, err])


if __name__ == '__main__':
    for name, fn in (('PA', PA), ('PB', PB), ('PC', PC), ('PD', PD), ('PE', PE), ('PF', PF)):
        try:
            fn()
        except Exception as e:
            must(False, name); R[name] = dict(crash=repr(e))
        print(name, flush=True)
    out = dict(R); out['failures'] = FAILS; out['seed'] = SEED
    out['source_sha256'] = hashlib.sha256(open(os.path.abspath(__file__), 'rb').read()).hexdigest()
    json.dump(out, open(os.path.join(HERE, 'rg_particle_resolution_results.json'), 'w'), indent=1, sort_keys=True)
    print('ALL PASSED' if not FAILS else f'FAILURES: {FAILS}')
    sys.exit(1 if FAILS else 0)
