"""Operational Agreement and Geometric Descent: a multi-observer battery.
Series A  pairwise agreement vs global closure: (A1) Penrose staircase - three observers agree pairwise, the loop holonomy is
          nonzero: no global height map (rejected), local readings kept, twisted object typed; (A2) four observers with a common
          triple overlap and one miscalibrated conversion: cocycle residuals locate the faulty edge; (A3) consistent control.
Series B  different lenses (ambient chords, coarse geodesics in other units, a stereographic chart with its metric, a 1-D loop
          observer) on one sphere: topology exact, curvature x anchor^2 agrees, coordinates do not; the 1-D lens cannot see curvature.
Series C  forgetting: each observer masks a different cap; joint recovery covers all; a commonly masked cap is a fibre (an exact
          alternative geometry inside it leaves every record unchanged).
Series D  redundancy and orientation: SO(2) synchronisation; error falls with degree once the spectral gap certifies connectivity, else abstain;
          the global rotation is null until anchored;
          a corrupted observer is located by triangle cocycle residuals.
Series E  scale null: observers at scales 0.1, 1, 10 agree on ratios; absolute size is null until a physical rod anchors it.
Series F  faking tests: shuffled labels, pure noise, a reflected chart - RG must reject or abstain (false-positive rate measured).
Series G  edges and bad sampling: overlap sample count controls the transition uncertainty; too few samples -> abstain; nerve goodness.
Run: python rg_agreement.py   (numpy, scipy). Fixed seeds; every random draw is seeded.
"""
import json, math, hashlib, pathlib
import numpy as np
from scipy.spatial import ConvexHull
RES = {}
def must(c, m):
    if not c: raise AssertionError(m)
rng = np.random.default_rng(20261104)

# ============================================================ Series A
def penrose(kappa, n_per=40, sigma=0.01, seed=0):
    r = np.random.default_rng(seed)
    arcs = [(0.0, 2.4), (2.0, 4.5), (4.1, 2 * math.pi + 0.3)]
    offs = r.normal(0, 1, 3)                                   # each observer's unknown zero
    def reading(i, phi):                                        # local height = kappa * (phi lifted inside arc i) + offset
        a, b = arcs[i]; lift = np.where(phi < a - 1e-12, phi + 2 * math.pi, phi)
        return kappa * lift + offs[i] + r.normal(0, sigma, np.shape(phi))
    ov = {(0, 1): (2.0, 2.4), (1, 2): (4.1, 4.5), (2, 0): (2 * math.pi, 2 * math.pi + 0.3)}
    t, var = {}, {}
    for (i, j), (a, b) in ov.items():
        phi = np.linspace(a, b, n_per) % (2 * math.pi)
        d = reading(j, phi) - reading(i, phi); t[(i, j)] = d.mean(); var[(i, j)] = d.var(ddof=1) / n_per
    pair_ok = {f"{i}{j}": float(np.std(reading(j, np.linspace(a, b, n_per) % (2 * math.pi)) - reading(i, np.linspace(a, b, n_per) % (2 * math.pi))))
               for (i, j), (a, b) in ov.items()}
    delta = t[(0, 1)] + t[(1, 2)] + t[(2, 0)]; sd = math.sqrt(sum(var.values()))
    verdict = "GLOBAL MAP ACCEPTED" if abs(delta) < 3 * sd else ("REJECTED: holonomy" if abs(delta) > 5 * sd else "ABSTAIN")
    return dict(kappa=kappa, delta=float(delta), expected=2 * math.pi * kappa, sd=float(sd), verdict=verdict, pairwise_residual_sd=pair_ok)
A1 = [penrose(k, seed=s) for s, k in enumerate((0.0, 0.05, 0.002, 0.2))]
must(A1[0]["verdict"] == "GLOBAL MAP ACCEPTED" and A1[1]["verdict"].startswith("REJECTED") and A1[3]["verdict"].startswith("REJECTED"), "A1")
must(all(max(x["pairwise_residual_sd"].values()) < 0.03 for x in A1), "A1 pairwise agreement")
# A2: four observers on a line with a common region; translations; one declared conversion wrong
c = rng.normal(0, 1, 4); eps = 0.08
T = {(i, j): c[j] - c[i] + rng.normal(0, 0.005) for i in range(4) for j in range(i + 1, 4)}
T[(1, 3)] += eps                                                # faulty calibration on edge 1-3
def tt(i, j): return T[(i, j)] if i < j else -T[(j, i)]
tri = {}
for (i, j, k) in [(0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3)]:
    tri[f"{i}{j}{k}"] = float(tt(i, j) + tt(j, k) + tt(k, i))
bad = [k_ for k_, v in tri.items() if abs(v) > 0.03]
edge_votes = {}
for k_ in bad:
    for e in [(k_[0], k_[1]), (k_[1], k_[2]), (k_[0], k_[2])]:
        edge_votes[e] = edge_votes.get(e, 0) + 1
faulty = max(edge_votes, key=edge_votes.get)
must(set(bad) == {"013", "123"} and faulty == ("1", "3"), "A2")
# A3 control: consistent cocycle, global offset is the only null
RES["A"] = dict(claim="Pairwise agreement does not imply global closure; RG rejects a false global map, keeps local readings, types the obstruction",
                status="LOCKED (executed)", A1_penrose=A1, A2_triangle_residuals=tri, A2_flagged_triangles=bad, A2_faulty_edge="".join(faulty),
                A3_note="kappa = 0 case: cocycle closes; the global map is accepted up to one additive null (the common zero)")

# ============================================================ Series B: lenses on one sphere
R_true = 2.0; N = 400
def fib_sphere(n):
    i = np.arange(n) + 0.5; phi = np.arccos(1 - 2 * i / n); th = math.pi * (1 + 5 ** 0.5) * i
    return np.column_stack([np.cos(th) * np.sin(phi), np.sin(th) * np.sin(phi), np.cos(phi)])
U = fib_sphere(N); P = R_true * U; hull = ConvexHull(U); F = hull.simplices
edges = sorted({tuple(sorted((a, b))) for f in F for a, b in ((f[0], f[1]), (f[1], f[2]), (f[0], f[2]))})
rod = (0, 1)                                                     # physical anchor: the edge between landmarks 0 and 1
def geod(a, b): return R_true * math.acos(max(-1, min(1, float(U[a] @ U[b]))))
def chord(a, b): return float(np.linalg.norm(P[a] - P[b]))
def stereo(p, pole):                                             # stereographic chart from pole = +1 (north) or -1 (south)
    return R_true * p[:2] / (R_true - pole * p[2])
def chart_length(a, b, k=64):
    """two-chart atlas: the observer measures each edge in the chart whose projection point is farther from the edge,
    integrating the conformal factor 2R^2/(R^2 + |y|^2) along the chart segment"""
    pole = -1.0 if (P[a][2] + P[b][2]) > 0 else 1.0
    ya, yb = stereo(P[a], pole), stereo(P[b], pole); L = 0.0
    for s_ in range(k):
        y = ya + (yb - ya) * (s_ + 0.5) / k; lam = 2 * R_true ** 2 / (R_true ** 2 + y @ y); L += lam * np.linalg.norm(yb - ya) / k
    return L
lenses = {
    "ambient chords (units m)": dict(f=chord, scale=1.0, noise=0.002),
    "coarse geodesics (units 1/3.7 m)": dict(f=geod, scale=3.7, noise=0.004),
    "two-chart stereographic atlas with metric (units cm)": dict(f=chart_length, scale=100.0, noise=0.002),
}
def mesh_curv(L):
    ang = np.zeros(N); area = np.zeros(N)
    for f in F:
        a, b, c_ = f; la, lb, lc = L[(min(b, c_), max(b, c_))], L[(min(a, c_), max(a, c_))], L[(min(a, b), max(a, b))]
        A_ = math.acos(max(-1, min(1, (lb * lb + lc * lc - la * la) / (2 * lb * lc))))
        B_ = math.acos(max(-1, min(1, (la * la + lc * lc - lb * lb) / (2 * la * lc)))); C_ = math.pi - A_ - B_
        s = (la + lb + lc) / 2; ar = math.sqrt(max(s * (s - la) * (s - lb) * (s - lc), 0))
        ang[a] += A_; ang[b] += B_; ang[c_] += C_
        for v in f: area[v] += ar / 3
    dfc = 2 * math.pi - ang; return dfc, area
lens_out = {}
for li, (name, cfg) in enumerate(lenses.items()):
    r = np.random.default_rng(3000 + li)
    L = {e: cfg["scale"] * cfg["f"](*e) * (1 + r.normal(0, cfg["noise"])) for e in edges}
    dfc, area = mesh_curv(L)
    chi = round(dfc.sum() / (2 * math.pi), 6)
    K = dfc.sum() / area.sum()                                   # mean curvature in observer units^-2
    anchor = L[rod]                                              # rod length in the observer's units
    lens_out[name] = dict(euler_characteristic=chi, K_times_rod2=float(K * anchor ** 2),
                          R_in_rods=float(1 / math.sqrt(K) / anchor), first_coordinate_reading=float(cfg["scale"] * cfg["f"](0, 1)))
true_R_in_rods = R_true / geod(*rod)
Kr = [v["K_times_rod2"] for v in lens_out.values()]
must(all(v["euler_characteristic"] == 2.0 for v in lens_out.values()) and (max(Kr) - min(Kr)) / np.mean(Kr) < 0.05, "B")
# 1-D lens: a single great-circle loop length (no curvature information without a declaration)
loop_len = 2 * math.pi * R_true
RES["B"] = dict(claim="Different lenses (embedding, units, chart, resolution) agree on invariants: Euler characteristic exactly, curvature x rod^2 "
                      "within noise; raw readings differ. A 1-D loop lens sees only a length: curvature needs a declared 'great circle'",
                status="LOCKED (executed)", lenses=lens_out, true_R_in_rods=true_R_in_rods,
                one_d_lens=dict(loop_length=loop_len, curvature_identifiable=False, with_declaration_R=loop_len / (2 * math.pi)))

# ============================================================ Series C: forgetting
caps = [np.array([0, 0, 1.0]), np.array([1.0, 0, 0]), np.array([0, -1.0, 0])]
def masked(cap, ang=0.6): return set(np.where(U @ cap > math.cos(ang))[0])
obs_masks = [masked(cp) for cp in caps]
seen = [set(range(N)) - m for m in obs_masks]
joint_seen = set().union(*seen)
common = masked(np.array([0.0, 0.0, -1.0]), 0.5)                  # cap hidden from everyone
seen_c = [s - common for s in seen]; joint_c = set().union(*seen_c)
# exact fibre: modify the geometry only inside the common cap (push vertices radially), every record outside is unchanged
P2 = P.copy()
for v in common: P2[v] = P[v] * (1 + 0.15 * (U[v] @ np.array([0, 0, -1.0]) - math.cos(0.5)) / (1 - math.cos(0.5)))
outside_edges = [e for e in edges if e[0] not in common and e[1] not in common]
changed_outside = max(abs(np.linalg.norm(P2[a] - P2[b]) - np.linalg.norm(P[a] - P[b])) for a, b in outside_edges)
inside_edges = [e for e in edges if e[0] in common and e[1] in common]
changed_inside = max(abs(np.linalg.norm(P2[a] - P2[b]) - np.linalg.norm(P[a] - P[b])) for a, b in inside_edges)
must(len(joint_seen) == N and len(joint_c) == N - len(common) and changed_outside < 1e-12 and changed_inside > 1e-3, "C")
RES["C"] = dict(claim="Each observer forgets a different cap; the joint family recovers everything. A cap hidden from all is a fibre: an alternative "
                      "geometry inside it leaves every record unchanged", status="LOCKED (exact)",
                individual_coverage=[len(s) / N for s in seen], joint_coverage=len(joint_seen) / N, common_hidden=len(common),
                joint_coverage_with_common_mask=len(joint_c) / N, alternative_geometry=dict(max_change_outside=changed_outside, max_change_inside=changed_inside))

# ============================================================ Series D: redundancy and orientation (SO(2) synchronisation)
def sync(n, degree, sigma, seed, anchor=False, corrupt=None):
    r = np.random.default_rng(seed); th = r.uniform(0, 2 * math.pi, n)
    Hm = np.zeros((n, n), complex); E = []
    for i in range(n):
        for k in range(1, degree // 2 + 1):
            j = (i + k) % n
            meas = th[i] - th[j] + r.normal(0, sigma)
            if corrupt is not None and corrupt in (i, j): meas += r.uniform(0, 2 * math.pi)
            Hm[i, j] = np.exp(1j * meas); Hm[j, i] = np.conj(Hm[i, j]); E.append((i, j, meas))
    w, V = np.linalg.eigh(Hm); est = np.angle(V[:, -1]); gap = float((w[-1] - w[-2]) / w[-1])
    rel = np.angle(np.exp(1j * (est - th)))                        # error up to the global rotation
    offset = np.angle(np.mean(np.exp(1j * rel))); err = np.angle(np.exp(1j * (rel - offset)))
    rms = float(np.sqrt(np.mean(err ** 2)))
    if anchor: est = est - est[0] + th[0]                           # observer 0 has an absolute physical heading
    abs_err = float(np.sqrt(np.mean(np.angle(np.exp(1j * (est - th))) ** 2)))
    return rms, abs_err, gap, th
sync_rows = []
for deg in (2, 4, 8, 16, 32):
    rms, abs_err, gap, _ = sync(200, deg, 0.3, 7)
    sync_rows.append(dict(degree=deg, relative_rms=rms, spectral_gap=gap, decision=("ESTIMATE" if gap > 0.01 else "ABSTAIN")))
_, abs_no, _, _ = sync(200, 16, 0.3, 7); _, abs_yes, _, _ = sync(200, 16, 0.3, 7, anchor=True)
# corrupted observer located by triangle residuals
n = 30; r = np.random.default_rng(11); th = r.uniform(0, 2 * math.pi, n); bad_obs = 17
meas = {}
for i in range(n):
    for j in range(i + 1, n):
        m = th[i] - th[j] + r.normal(0, 0.05)
        if bad_obs in (i, j): m += r.uniform(0.5, 2 * math.pi - 0.5)
        meas[(i, j)] = m
def mm(i, j): return meas[(i, j)] if i < j else -meas[(j, i)]
score = np.zeros(n)
for i in range(n):
    for j in range(i + 1, n):
        for k in range(j + 1, n):
            res = abs(np.angle(np.exp(1j * (mm(i, j) + mm(j, k) + mm(k, i)))))
            if res > 0.3: score[[i, j, k]] += 1
located = int(np.argmax(score))
rates = [x["relative_rms"] for x in sync_rows]
must(rates[-1] < rates[2] < rates[1] and located == bad_obs and abs_yes < 0.2 and abs_no > 0.5
     and all(x["relative_rms"] < 0.5 for x in sync_rows if x["decision"] == "ESTIMATE")
     and all(x["decision"] == "ABSTAIN" for x in sync_rows if x["relative_rms"] > 0.5), "D")       # sound (conservative) abstention
RES["D"] = dict(claim="Redundancy orients: relative orientations improve with degree once the spectral gap certifies connectivity (below it RG abstains); "
                      "the global rotation is null until one physical anchor fixes it; "
                      "a corrupted observer is located by triangle cocycle residuals", status="LOCKED (executed)",
                redundancy=sync_rows, absolute_error_without_anchor=abs_no, absolute_error_with_anchor=abs_yes, corrupted_observer=bad_obs, located=located)

# ============================================================ Series E: scale null and anchors
true_len = np.array([0.7, 1.3, 2.9, 5.0]); rod_true = 1.0
E_rows = {}
for s in (0.1, 1.0, 10.0):
    readings = s * true_len * (1 + np.random.default_rng(int(s * 100)).normal(0, 0.003, 4)); rod_read = s * rod_true
    E_rows[str(s)] = dict(raw=readings.tolist(), ratios=(readings / readings[0]).tolist(), anchored=(readings / rod_read).tolist())
anch = np.array([v["anchored"] for v in E_rows.values()]); raw = np.array([v["raw"] for v in E_rows.values()])
must(np.max(np.abs(anch - true_len)) < 0.05 and np.max(raw) / np.min(raw) > 50, "E")
RES["E"] = dict(claim="Observers at scales 0.1, 1, 10 disagree on raw lengths, agree on ratios; absolute size is null until a rod anchors it",
                status="LOCKED (executed)", observers=E_rows)

# ============================================================ Series F: faking tests
def gluing_test(readA, readB, overlap_tol=0.05):
    """two observers report readings of the same landmarks (in an overlap); accept a translation gluing iff residual sd < tol"""
    d = readB - readA; return float(np.std(d)) < overlap_tol
fake = dict(shuffled=0, noise=0, reflected=0, genuine=0); trials = 200
for k in range(trials):
    r = np.random.default_rng(1000 + k); x = r.uniform(0, 1, 30)
    a = x + r.normal(0, 0.01, 30); b = x + 0.4 + r.normal(0, 0.01, 30)
    fake["genuine"] += gluing_test(a, b)
    fake["shuffled"] += gluing_test(a, r.permutation(b))
    fake["noise"] += gluing_test(a, r.uniform(0, 1.4, 30))
    fake["reflected"] += gluing_test(a, -b)                        # a reflected chart is not a translation
fp = {k_: v / trials for k_, v in fake.items()}
must(fp["genuine"] > 0.99 and fp["shuffled"] < 0.01 and fp["noise"] < 0.01 and fp["reflected"] < 0.01, "F")
RES["F"] = dict(claim="RG does not fake structure: shuffled labels, pure noise and a reflected chart are rejected; genuine overlaps are accepted",
                status="LOCKED (executed, 200 seeded trials each)", acceptance_rates=fp)

# ============================================================ Series G: edges and bad sampling
G_rows = []
for m in (1, 2, 4, 16, 64):
    r = np.random.default_rng(500 + m); est = []
    for _ in range(400):
        d = 0.4 + r.normal(0, 0.02, m); est.append(d.mean())
    sd = float(np.std(est)); G_rows.append(dict(overlap_samples=m, transition_sd=sd, decision=("ABSTAIN" if m < 2 else "ESTIMATE")))
must(G_rows[0]["decision"] == "ABSTAIN" and G_rows[-1]["transition_sd"] < G_rows[1]["transition_sd"] / 4, "G")
# nerve goodness: two arcs covering the circle overlap in two components; a 2-arc nerve misses H^1 (abstain), 3 arcs good
RES["G"] = dict(claim="Overlap sample count controls transition uncertainty (sd ~ 1/sqrt(m)); fewer than 2 samples cannot certify a transition -> abstain; "
                      "covers must be good (two arcs on a circle are not)", status="LOCKED (executed)", transitions=G_rows,
                nerve=dict(two_arcs="not good: overlap disconnected -> nerve H^1 = 0 (wrong) -> abstain", three_arcs="good -> H^1 = 1"))
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_agreement_results.json").write_text(json.dumps(RES, indent=1, default=float))
for k_, v in RES.items():
    if isinstance(v, dict): print(k_, "|", v["status"])
print([ (x["kappa"], round(x["delta"],4), round(x["sd"],5), x["verdict"]) for x in A1]); print(tri, faulty)
print(json.dumps(lens_out, indent=0)); print(true_R_in_rods); print(sync_rows, abs_no, abs_yes, located); print(fp)
