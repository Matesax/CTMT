# RG full computation loop: report

**Loop executed.** Probe histories → blind predictive state → calibrated tensor decoders → probe correction →
held-out tensor forecasts → held-out *test* of the coupling. The coupling is never inserted.

| Step | Result |
|---|---|
| C1 correction | tidal rank 1→6; energy rank 1→10; one held-out probe of each kind |
| C2 forecasts | two separate blind learners per observer (tidal-only, energy-only); tensor forecast error 4e-6 to 5e-3 |
| C3 coupling test | GR form calibrated on training: κ/4πG = 1.000000. Measured held-out residual 7e-6 vs rival 6.5e-3. Forecast level: **GR SELECTED** at 3/4 observers; **CORRESPONDENCE** at O_apo (budget too wide) |
| C4 | circular orbit: GR and rival indistinguishable (identifiability needs a varying ΣT_ii/T00) |
| C5 | local stress fixes only tr E; the traceless (Weyl-electric) part changes 102% from a distant mass |
| C6 | bound sources violate ∂T = 0 at O(G); the Newtonian gravitational stress carries the missing flux (2.4e-5). This is the first nonlinear term, and a pseudo-tensor |
| C7 | 2 canaries rejected (computed) |

**Imported.**
- Tensor identification: 461/461.
- Blind leap: 270/270. Its non-lock stands: minimal state recovery is not established.
- Both sides: 655/655.
- Second-order gate: S1–S6.

**Not established.**
- Full nonlinear GR.
- The Weyl-magnetic part and spatial Riemann components.
- Real data.
- Full GR from RG.

The generator embodies quasi-static linearized GR, so the coupling test validates identifiability and
discrimination, not GR in Nature.

**Battery:** seed 20261101, about 9 s; reruns identical.
