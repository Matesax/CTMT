"""RG full computation loop (synthetic, declared quasi-static linearized generator).
Probe histories -> blind predictive state -> tensor decoders (stress AND curvature, independent) -> probe
correction -> held-out tensor forecasts -> held-out TEST of the gravitational coupling (GR vs a trace-coupled
rival) -> hidden geometric state -> conservation gate and the first nonlinear term.
The truth generator embodies the linearized-GR 00 equation (tr E = 4 pi G (T00 + sum T_ii)) in the quasi-static
limit; the learner and decoders never see it.  This tests identifiability and discrimination, not GR in Nature.
Run: python rg_full_loop.py --out DIR      (numpy, scipy)
"""
import argparse, hashlib, json, math, pathlib, sys, time
import numpy as np
from scipy.integrate import solve_ivp
from scipy.special import erf
from scipy.linalg import null_space

SEED = 20261101
G = 1.0
CFG = dict(m=(0.05, 0.05), sigma=1.5, a=4.0, e=0.5, dt=1.0, samples=2000, train_end=1200, val_end=1500, test_end=1800,
           delay=200, ranks=[20, 40, 60, 80, 100, 140], noise=1e-9, beta=0.5)
RES = {}


def must(c, m):
    if not c:
        raise AssertionError(m)


# ------------------------------------------------------------------ truth generator (audit only)
def orbit(e, n_samples=None, dt=None):
    n_samples = n_samples or CFG["samples"]; dt = dt or CFG["dt"]
    m1, m2 = CFG["m"]; M = m1 + m2; a = CFG["a"]; s = CFG["sigma"]
    r_p = a * (1 - e); r_a = a * (1 + e); mu_ = m1 * m2 / M
    U = lambda r: -G * m1 * m2 * erf(r / (2 * s)) / r                     # Gaussian-blob interaction potential
    if e > 0:     # bound orbit of the SOFTENED potential with the declared peri/apo distances
        v_p = math.sqrt(2 * (U(r_a) - U(r_p)) / (mu_ * (1 - r_p ** 2 / r_a ** 2)))
    else:         # circular orbit of the softened potential
        x = a / (2 * s); dU = G * m1 * m2 * (erf(x) / a ** 2 - (2 / math.sqrt(math.pi)) * math.exp(-x * x) / (2 * s * a))
        v_p = math.sqrt(a * dU / mu_)
    def rhs(t, y):
        d = y[:3] - y[3:6]; r = np.linalg.norm(d)
        # force between two Gaussian blobs of width s: potential -G m1 m2 erf(r/(2s))/r
        x = r / (2 * s)
        dphidr = G * m1 * m2 * (erf(x) / r ** 2 - (2 / math.sqrt(math.pi)) * math.exp(-x * x) / (2 * s * r))
        f = -dphidr * d / r
        return np.r_[y[6:9], y[9:12], f / m1, -f / m2]
    x1 = np.array([r_p * m2 / M, 0, 0]); x2 = np.array([-r_p * m1 / M, 0, 0])
    v1 = np.array([0, v_p * m2 / M, 0]); v2 = np.array([0, -v_p * m1 / M, 0])
    ts = np.arange(n_samples) * dt
    sol = solve_ivp(rhs, [0, ts[-1]], np.r_[x1, x2, v1, v2], t_eval=ts, rtol=1e-11, atol=1e-13, method="DOP853")
    return ts, sol.y.T


def blob_fields(X, centers, vels, masses=None):
    """stress T^{ab} (dust) and tidal E_ij at point X from Gaussian blobs (quasi-static linearized GR)."""
    s = CFG["sigma"]; T = np.zeros((4, 4)); E = np.zeros((3, 3))
    for (c, v, m) in zip(centers, vels, masses if masses is not None else CFG["m"]):
        d = X - c; r = np.linalg.norm(d)
        rho = m / ((2 * math.pi) ** 1.5 * s ** 3) * math.exp(-r * r / (2 * s * s))
        u = np.r_[1.0, v]; T += rho * np.outer(u, u)
        ma = m * (1 + v @ v)                                   # active mass: T00 + sum T_ii for dust
        # Hessian of Phi = -G ma erf(r/(sqrt2 s))/r
        if r < 1e-6:
            kk = (2 / math.sqrt(math.pi)) / (math.sqrt(2) * s * 6 * s * s)
            E += G * ma * 2 * kk * np.eye(3); continue
        x = r / (math.sqrt(2) * s)
        g = erf(x); gp = (2 / math.sqrt(math.pi)) * math.exp(-x * x) / (math.sqrt(2) * s)        # d erf/dr
        gpp = -2 * x / (math.sqrt(2) * s) * gp                                                    # d2 erf/dr2
        f = g / r; fp = gp / r - g / r ** 2; fpp = gpp / r - 2 * gp / r ** 2 + 2 * g / r ** 3
        nhat = d / r
        H = -G * ma * (fpp * np.outer(nhat, nhat) + fp / r * (np.eye(3) - np.outer(nhat, nhat)))
        E += H
    return T, E


# ------------------------------------------------------------------ probes and decoders
TIDAL_POOL = [np.array(v, float) / np.linalg.norm(v) for v in
              ([1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 0], [1, 0, 1], [0, 1, 1], [1, 1, 1], [1, -1, 0])]


def boost_u(dirn, beta):
    if beta == 0:
        return np.r_[1.0, 0, 0, 0]
    n = np.array(dirn, float); n /= np.linalg.norm(n); gm = 1 / math.sqrt(1 - beta ** 2)
    return gm * np.r_[1.0, beta * n]


B = CFG["beta"]
ENERGY_POOL = [boost_u([1, 0, 0], 0)] + [boost_u(d, s * B) for d in ([1, 0, 0], [0, 1, 0], [0, 0, 1]) for s in (1, -1)] \
    + [boost_u(d, B / math.sqrt(2)) for d in ([1, 1, 0], [1, 0, 1], [0, 1, 1])] + [boost_u([1, 1, 1], B), boost_u([1, -1, 0], B)]
ETA = np.diag([-1.0, 1, 1, 1])


def tidal_row(n):
    return np.array([n[0] * n[0], n[1] * n[1], n[2] * n[2], 2 * n[0] * n[1], 2 * n[0] * n[2], 2 * n[1] * n[2]])


def energy_row(u):
    ul = ETA @ u
    return np.array([ul[i] * ul[j] * (1 if i == j else 2) for i in range(4) for j in range(i, 4)])


def vecE(E):
    return np.array([E[0, 0], E[1, 1], E[2, 2], E[0, 1], E[0, 2], E[1, 2]])


def vecT(T):
    return np.array([T[i, j] for i in range(4) for j in range(i, 4)])


def matE(v):
    return np.array([[v[0], v[3], v[4]], [v[3], v[1], v[5]], [v[4], v[5], v[2]]])


def matT(v):
    T = np.zeros((4, 4)); k = 0
    for i in range(4):
        for j in range(i, 4):
            T[i, j] = T[j, i] = v[k]; k += 1
    return T


def acquire(pool_rows, n_target):
    """null-space sensitivity policy (candidate set fixed before data; no truth)."""
    sel = [0]; hist = []
    while True:
        Z = null_space(np.array([pool_rows[i] for i in sel]))
        hist.append(dict(selected=list(sel), rank=n_target - Z.shape[1]))
        if Z.shape[1] == 0:
            break
        scores = [np.linalg.norm(r @ Z) if i not in sel else -1 for i, r in enumerate(pool_rows)]
        sel.append(int(np.argmax(scores)))
    return sel, hist


# ------------------------------------------------------------------ blind learner (delay-embedded linear system id)
def delays(y, L):
    return np.array([y[t - L + 1:t + 1].ravel() for t in range(L - 1, len(y))]).T


def forecast(mdl, hist, steps):
    z = mdl["U"].T @ (((hist[-CFG["delay"]:] - mdl["mu"]) / mdl["sd"]).ravel()); out = []
    p = len(mdl["mu"])
    for _ in range(steps):
        z = mdl["K"] @ z; out.append((mdl["U"] @ z)[-p:] * mdl["sd"] + mdl["mu"])
    return np.array(out)


def fit(train, val):
    mu = train.mean(0); sd = np.maximum(train.std(0), 1e-15); Y = (train - mu) / sd
    D = delays(Y, CFG["delay"]); X, Xp = D[:, :-1], D[:, 1:]
    U, s, Vh = np.linalg.svd(X, full_matrices=False); best = None
    for r in CFG["ranks"]:
        if r > len(s):
            continue
        Ur = U[:, :r]; K = (Ur.T @ Xp @ Vh[:r].T) / s[:r]
        m = dict(mu=mu, sd=sd, U=Ur, K=K, rank=r)
        err = np.linalg.norm(forecast(m, train, len(val)) - val) / np.linalg.norm(val - mu)
        if best is None or err < best[1]:
            best = (m, err)
    return best


# ------------------------------------------------------------------ battery
def run_orbit(e, rng, observers):
    ts, Y = orbit(e)
    c1, c2, v1, v2 = Y[:, 0:3], Y[:, 3:6], Y[:, 6:9], Y[:, 9:12]
    data = {}
    for name, X in observers.items():
        Ts, Es = [], []
        for k in range(len(ts)):
            T, E = blob_fields(X, [c1[k], c2[k]], [v1[k], v2[k]]); Ts.append(T); Es.append(E)
        data[name] = (np.array(Ts), np.array(Es))
    return ts, Y, data


def main(outdir):
    out = pathlib.Path(outdir); out.mkdir(parents=True, exist_ok=True); t0 = time.time()
    rng = np.random.default_rng(SEED)
    m1, m2 = CFG["m"]; M = m1 + m2; a, e = CFG["a"], CFG["e"]
    rp1 = a * (1 - e) * m2 / M; ra1 = a * (1 + e) * m2 / M
    observers = {"O_peri": np.array([rp1, 0, 0.05]), "O_apo": np.array([-ra1, 0, 0.05]),
                 "O_side": np.array([0, a * math.sqrt(1 - e * e) * m2 / M, 0.3]), "O_center": np.array([0.0, 0, 0])}
    # ---------- C1 probe acquisition (correction loop)
    trows = [tidal_row(n) for n in TIDAL_POOL]; erows = [energy_row(u) for u in ENERGY_POOL]
    tsel, thist = acquire(trows, 6); esel, ehist = acquire(erows, 10)
    must(len(tsel) == 6 and len(esel) == 10, "acquisition reaches full rank")
    t_held = [i for i in range(len(TIDAL_POOL)) if i not in tsel][:1]; e_held = [i for i in range(len(ENERGY_POOL)) if i not in esel][:1]
    At = np.array([trows[i] for i in tsel]); Ae = np.array([erows[i] for i in esel])
    RES["C1"] = dict(claim="Probe correction loop reaches full tensor rank without truth",
                     witness=f"tidal pool {len(TIDAL_POOL)} directions: rank progression {[h['rank'] for h in thist]}; energy pool "
                                 f"{len(ENERGY_POOL)} observers: {[h['rank'] for h in ehist]}. Held-out probes: tidal #{t_held}, energy #{e_held}.")
    # ---------- C2-C4 eccentric orbit: blind forecasts, decoders, coupling test
    ts, Y, data = run_orbit(e, rng, observers)
    tr, ve, te = CFG["train_end"], CFG["val_end"], CFG["test_end"]
    per_obs = {}; resid = {"GR": [], "trace-coupled rival": []}; fits = {}
    fitG = {"GR": [], "trace-coupled rival": []}
    for name, (Ts, Es) in data.items():
        yt = np.array([At @ vecE(E) for E in Es]) + rng.uniform(-CFG["noise"], CFG["noise"], (len(Es), 6))
        ye = np.array([Ae @ vecT(T) for T in Ts]) + rng.uniform(-CFG["noise"], CFG["noise"], (len(Ts), 10))
        # two SEPARATE blind learners: curvature history only, stress history only (no shared linear invariant)
        mt, verr_t = fit(yt[:tr], yt[tr:ve]); me, verr_e = fit(ye[:tr], ye[tr:ve])
        pt = forecast(mt, yt[:ve], te - ve); pe = forecast(me, ye[:ve], te - ve)
        Ehat = np.array([matE(np.linalg.solve(At, p)) for p in pt])
        That = np.array([matT(np.linalg.solve(Ae, p)) for p in pe])
        Emeas = np.array([matE(np.linalg.solve(At, p)) for p in yt[ve:te]]); Tmeas = np.array([matT(np.linalg.solve(Ae, p)) for p in ye[ve:te]])
        mdl = dict(rank=(mt["rank"], me["rank"])); verr = max(verr_t, verr_e)
        # hypothesis-free forecast budget, from the VALIDATION window only (models fitted on training only)
        vt = forecast(mt, yt[:tr], ve - tr); vE = forecast(me, ye[:tr], ve - tr)
        Ev = np.array([matE(np.linalg.solve(At, p)) for p in vt]); Tv = np.array([matT(np.linalg.solve(Ae, p)) for p in vE])
        Evm = np.array([matE(np.linalg.solve(At, p)) for p in yt[tr:ve]]); Tvm = np.array([matT(np.linalg.solve(Ae, p)) for p in ye[tr:ve]])
        relmax = lambda a_, b_: float(np.abs(a_ - b_).max() / max(np.abs(b_).max(), 1e-30))
        budget = 3 * max(relmax(np.trace(Ev, axis1=1, axis2=2), np.trace(Evm, axis1=1, axis2=2)),
                         relmax(Tv[:, 0, 0], Tvm[:, 0, 0]), relmax(Tv[:, 1, 1] + Tv[:, 2, 2], Tvm[:, 1, 1] + Tvm[:, 2, 2]))
        # held-out probes predicted from decoded tensors vs measured
        ht = np.array([trows[t_held[0]] @ vecE(E) for E in Ehat]); htm = np.array([trows[t_held[0]] @ vecE(E) for E in Es[ve:te]])
        he = np.array([erows[e_held[0]] @ vecT(T) for T in That]); hem = np.array([erows[e_held[0]] @ vecT(T) for T in Ts[ve:te]])
        tens_err = max(np.linalg.norm(Ehat - Es[ve:te]) / np.linalg.norm(Es[ve:te]), np.linalg.norm(That - Ts[ve:te]) / np.linalg.norm(Ts[ve:te]))
        held_err = max(np.abs(ht - htm).max() / np.abs(htm).max(), np.abs(he - hem).max() / max(np.abs(hem).max(), 1e-30))
        per_obs[name] = dict(rank=mdl["rank"], validation_err=float(verr), forecast_budget=budget,
                             tensor_forecast_err=float(tens_err), heldout_probe_err=float(held_err))
        # independent decoders on TRAINING window -> calibrate kappa for each coupling hypothesis
        Etr = np.array([matE(np.linalg.solve(At, p)) for p in yt[:tr]]); Ttr = np.array([matT(np.linalg.solve(Ae, p)) for p in ye[:tr]])
        for hyp, sgn in (("GR", 1), ("trace-coupled rival", -1)):
            src_tr = Ttr[:, 0, 0] + sgn * (Ttr[:, 1, 1] + Ttr[:, 2, 2]); src_te = That[:, 0, 0] + sgn * (That[:, 1, 1] + That[:, 2, 2])
            src_me = Tmeas[:, 0, 0] + sgn * (Tmeas[:, 1, 1] + Tmeas[:, 2, 2])
            fitG[hyp].append((np.trace(Etr, axis1=1, axis2=2), src_tr, np.trace(Ehat, axis1=1, axis2=2), src_te,
                              np.trace(Emeas, axis1=1, axis2=2), src_me))
    names = list(per_obs)
    for hyp, rows in fitG.items():
        x = np.concatenate([r[1] for r in rows]); yv = np.concatenate([r[0] for r in rows])
        kappa = float(x @ yv / (x @ x))
        per = {}
        for nm, r in zip(names, rows):
            sc = np.abs(r[2]).max()
            per[nm] = dict(forecast_residual=float(np.abs(r[2] - kappa * r[3]).max() / sc),
                           measured_residual=float(np.abs(r[4] - kappa * r[5]).max() / np.abs(r[4]).max()))
        xt = np.concatenate([r[3] for r in rows]); yt_ = np.concatenate([r[2] for r in rows])
        res_test = float(np.abs(yt_ - kappa * xt).max() / np.abs(yt_).max())
        res_train = float(np.abs(yv - kappa * x).max() / np.abs(yv).max())
        xm = np.concatenate([r[5] for r in rows]); ym = np.concatenate([r[4] for r in rows])
        res_meas = float(np.abs(ym - kappa * xm).max() / np.abs(ym).max())
        fits[hyp] = dict(kappa=kappa, kappa_over_4piG=kappa / (4 * math.pi * G), train_residual=res_train,
                         heldout_residual=res_test, heldout_measured_residual=res_meas, per_observer=per)
    worst_tensor = max(v["tensor_forecast_err"] for v in per_obs.values())
    verdict = {}
    for nm in per_obs:
        b = per_obs[nm]["forecast_budget"]
        gr = fits["GR"]["per_observer"][nm]["forecast_residual"]; rv = fits["trace-coupled rival"]["per_observer"][nm]["forecast_residual"]
        verdict[nm] = ("GR SELECTED" if gr <= b < rv else "CORRESPONDENCE" if (gr <= b and rv <= b)
                       else "BOTH REJECTED" if (gr > b and rv > b) else "RIVAL SELECTED")
    meas_ok = all(fits["GR"]["per_observer"][nm]["measured_residual"] < 1e-4 < fits["trace-coupled rival"]["per_observer"][nm]["measured_residual"]
                  for nm in per_obs)
    must(meas_ok and abs(fits["GR"]["kappa_over_4piG"] - 1) < 1e-3 and "RIVAL SELECTED" not in verdict.values()
         and list(verdict.values()).count("GR SELECTED") >= 2, "coupling test eccentric")
    RES["C2"] = dict(claim="Blind predictive state forecasts both tensors on an untouched window",
                     witness=f"Per observer (delay {CFG['delay']}, rank by validation): {per_obs}. Worst relative tensor forecast error "
                             f"{worst_tensor:.2e}; held-out probes (never used to fit) predicted from decoded tensors.", details=per_obs)
    RES["C3"] = dict(claim="Independently decoded stress and curvature satisfy a coupling that was not inserted",
                     witness=f"Coupling scale calibrated on training only (kappa/4piG = {fits['GR']['kappa_over_4piG']:.6f} for the GR form); tested in the untouched window on tensors FORECAST by two separate "
                             f"learners (curvature-only and stress-only histories; measured-tensor residual GR "
                             f"{fits['GR']['heldout_measured_residual']:.1e}, rival {fits['trace-coupled rival']['heldout_measured_residual']:.1e}). "
                             f"GR form tr E = kappa (T00 + sum T_ii): pooled forecast residual "
                             f"{fits['GR']['heldout_residual']:.1e}. Trace-coupled rival tr E = kappa (T00 - sum T_ii): held-out residual "
                             f"{fits['trace-coupled rival']['heldout_residual']:.1e}. Per-observer verdict at the forecast level, "
                             f"with a hypothesis-free budget taken from the validation window: {verdict}.",
                     details=dict(fits=fits, verdict=verdict))
    # ---------- C4 circular orbit: the two couplings form a correspondence
    _, _, data_c = run_orbit(0.0, rng, {"O_peri": np.array([a * m2 / M, 0, 0])})
    Ts, Es = data_c["O_peri"]
    trE = np.trace(Es, axis1=1, axis2=2)
    corr = {}
    for hyp, sgn in (("GR", 1), ("trace-coupled rival", -1)):
        src = Ts[:, 0, 0] + sgn * (Ts[:, 1, 1] + Ts[:, 2, 2]); k_ = src @ trE / (src @ src)
        corr[hyp] = float(np.abs(trE - k_ * src).max() / np.abs(trE).max())
    must(max(corr.values()) < 1e-6, "circular degeneracy")
    RES["C4"] = dict(claim="Any orbit discriminates the coupling", status="REFUTED: circular orbits leave a correspondence",
                     witness=f"Circular orbit (|v| constant): after calibrating kappa, GR residual {corr['GR']:.1e} and rival residual "
                             f"{corr['trace-coupled rival']:.1e}: T00 + sum T_ii and T00 - sum T_ii are proportional. Discrimination needs "
                             "a varying stress-to-energy ratio (eccentricity, pressure).", details=corr)
    # ---------- C5 hidden geometric state: local stress fixes tr E only
    X = observers["O_peri"]; c = [Y[0, 0:3], Y[0, 3:6]]; v = [Y[0, 6:9], Y[0, 9:12]]
    T_a, E_a = blob_fields(X, c, v)
    T_b, E_b = blob_fields(X, c + [np.array([0.0, 40.0, 0])], v + [np.zeros(3)], list(CFG["m"]) + [50.0])  # add a distant heavy mass
    dT = np.abs(T_a - T_b).max() / np.abs(T_a).max(); dtr = abs(np.trace(E_a) - np.trace(E_b)) / abs(np.trace(E_a))
    tl = lambda E_: E_ - np.trace(E_) / 3 * np.eye(3)
    dW = np.linalg.norm(tl(E_a) - tl(E_b)) / np.linalg.norm(tl(E_a))
    must(dT < 1e-6 and dtr < 1e-6 and dW > 1e-3, "hidden geometric state")
    RES["C5"] = dict(claim="Local stress determines local curvature", status="REFUTED: only the trace (Ricci part)",
                     witness=f"Adding a distant heavy mass (m = 50 at 40 units): local stress changes by {dT:.1e}, tr E by {dtr:.1e}, "
                             f"but the traceless (Weyl-electric) tidal part changes by {dW:.1%}. The traceless part is the geometric hidden "
                             "state, fixed by distant sources or waves, never by local stress.")
    # ---------- C6 conservation gate and the first nonlinear term (gravitational stress, pseudo-tensor)
    s_small = 0.3; d = 6.0; mA = mB = 0.05
    def g_field(P):
        tot = np.zeros(3)
        for cpos, m in ((np.array([-d / 2, 0, 0]), mA), (np.array([d / 2, 0, 0]), mB)):
            r_ = P - cpos; r = np.linalg.norm(r_); x = r / (math.sqrt(2) * s_small)
            enc = erf(x) - (2 / math.sqrt(math.pi)) * x * math.exp(-x * x)
            tot += -G * m * enc * r_ / r ** 3
        return tot
    # gravitational stress flux through a sphere of radius 2.5 around blob A
    R = 2.5; nth, nph = 120, 240
    th = (np.arange(nth) + 0.5) * math.pi / nth; ph = (np.arange(nph) + 0.5) * 2 * math.pi / nph
    flux = np.zeros(3)
    for t_ in th:
        for p_ in ph:
            n_ = np.array([math.sin(t_) * math.cos(p_), math.sin(t_) * math.sin(p_), math.cos(t_)])
            gg = g_field(np.array([-d / 2, 0, 0]) + R * n_)
            tij = (np.outer(gg, gg) - 0.5 * np.eye(3) * (gg @ gg)) / (4 * math.pi * G)
            flux += tij @ n_ * R * R * math.sin(t_) * (math.pi / nth) * (2 * math.pi / nph)
    force = mA * g_field(np.array([-d / 2, 0, 0]) + 1e-9) if False else mA * (-G * mB * np.array([-d, 0, 0]) / d ** 3)
    rel_err = float(np.linalg.norm(-flux - force) / np.linalg.norm(force))      # dP_A/dt = -oint t.n dS
    must(rel_err < 1e-3, "gravitational stress carries the momentum flux")
    RES["C6"] = dict(claim="The linear coupling is consistent for gravitationally interacting sources",
                     status="REFUTED at O(G): nonlinear completion required; first term computed",
                     witness=f"Bound sources do not conserve T (dP_A/dt = m_A g = {force[0]:.3e} along x), contradicting the linearized "
                             f"Bianchi identity. The Newtonian gravitational stress t_ij = (g_i g_j - delta_ij g^2/2)/4piG through a sphere "
                             f"around blob A carries exactly that momentum: -oint t.n dS = {-flux[0]:.3e} (relative error {rel_err:.1e}), restoring "
                             "conservation of T + t: the first nonlinear (Deser) term. t_ij is built from g, which a freely falling observer "
                             "can transform away: it is a pseudo-tensor, not a local tensor observable.",
                     details=dict(flux=flux.tolist(), force=force.tolist()))
    # ---------- C7 canaries
    can = {}
    yrand = rng.permutation(np.arange(10))
    Ae_bad = Ae[yrand[:9]]
    can["nine energy observers identify T (rank)"] = np.linalg.matrix_rank(Ae_bad) == 10
    can["rival coupling passes the eccentric test"] = fits["trace-coupled rival"]["heldout_residual"] < 1e-3
    must(not any(can.values()), "canary accepted")
    RES["C7"] = dict(claim="canaries", status="all rejected", witness=str(can))
    res = dict(seed=SEED, config=CFG, results=RES, runtime_s=round(time.time() - t0, 1), python=sys.version.split()[0],
               numpy=np.__version__, source_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
               scope="synthetic; quasi-static linearized-GR generator (audit only); learner/decoders blind to it")
    (out / "rg_full_loop_results.json").write_text(json.dumps(res, indent=1, default=float))
    for k_, v_ in RES.items():
        print(k_, v_.get("status", ""), "|", v_["witness"][:330])


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default="."); main(ap.parse_args().out)
