import numpy as np
from scipy.linalg import expm
np.set_printoptions(precision=4,suppress=True)
rng=np.random.default_rng(30)
def isqrt(A):
    w,V=np.linalg.eigh(A);w=np.clip(w,1e-12,None);return V@np.diag(w**-0.5)@V.T

print("="*72)
print("PILLAR 1 -- INFORMATION: the coherent object sees what independent probes discard")
print("="*72)
# resolved+null coupled by C; predict the UNOBSERVED null sector from resolved measurements
p,q=6,6
print(" task: infer the un-probed (null) sector from the probed (resolved) sector.")
print(" independent probes have no cross-sector model -> best error = prior null variance.")
print(" coherent geometry conditions via coupling -> error = Schur complement.\n")
print("  coupling strength ||C||   indep. error   RG error   info recovered")
for scale in [0.0,0.3,0.6,0.9]:
    recs=[]
    for _ in range(200):
        SR=rng.standard_normal((p,p));SR=SR@SR.T+0.5*np.eye(p)
        SN=rng.standard_normal((q,q));SN=SN@SN.T+0.5*np.eye(q)
        # build admissible coupling of controlled strength
        Craw=rng.standard_normal((p,q))
        C=scale*isqrt(np.eye(p))  # placeholder
        # scale coupling so canonical correlations ~ scale (admissible)
        U1=np.linalg.qr(rng.standard_normal((p,p)))[0];V1=np.linalg.qr(rng.standard_normal((q,q)))[0]
        r=np.clip(scale*np.linspace(1,0.3,min(p,q)),0,0.98)
        Kc=np.zeros((p,q));Kc[:min(p,q),:min(p,q)]=np.diag(r)
        SRs=isqrt(SR);SNs=isqrt(SN)
        # C such that whitened coupling = U1 Kc V1^T
        C=np.linalg.inv(SRs)@ (U1@Kc@V1.T) @np.linalg.inv(SNs)
        Schur=SN-C.T@np.linalg.inv(SR)@C
        recs.append(1-np.trace(Schur)/np.trace(SN))
    ind=1.0; rgv=1-np.mean(recs)
    print("       %.2f (rho~%.2f)        %.3f          %.3f       %.0f%%"%(
        scale,scale,ind,rgv,100*np.mean(recs)))
print("  => at zero coupling RG=independent (no gain, honest); the coherent object's")
print("     advantage IS the coupling that independent probes structurally cannot use.")
print("  (classical root: Gauss-Markov/conditional Gaussian. RG makes it coordinate-free")
print("   and one facet of a single object -- see Pillars 2-3 for the non-classical necessity.)")

print("\n"+"="*72)
print("PILLAR 2 -- CONSISTENCY: an error every LOCAL check passes, only the whole object sees")
print("="*72)
m,p=12,4
Q0=np.linalg.qr(rng.standard_normal((m,p)))[0]
Om1=rng.standard_normal((m,m));Om1=Om1-Om1.T
Om2=rng.standard_normal((m,m));Om2=Om2-Om2.T
def frame(a,b,k): return expm(k*(a*Om1+b*Om2))@Q0
def loop_frames(k,N):   # rectangle loop in 2D condition space (a,b)
    pts=[]
    for x in np.linspace(0,1,N,endpoint=False): pts.append((x,0))
    for x in np.linspace(0,1,N,endpoint=False): pts.append((1,x))
    for x in np.linspace(0,1,N,endpoint=False): pts.append((1-x,1))
    for x in np.linspace(0,1,N,endpoint=False): pts.append((0,1-x))
    return [frame(a,b,k) for (a,b) in pts]
print(" practice: calibrate adjacent conditions pairwise, combine around a cycle.")
print(" the standard local sanity check = 'do adjacent frames match?' (overlap ~ 1).\n")
print("  curvature k   min adjacent overlap   GLOBAL holonomy   spurious effect on a reference")
for k in [0.0,0.15,0.30,0.5]:
    fr=loop_frames(k,60); Wpair=np.eye(p); mino=1.0
    for i in range(len(fr)):
        M=fr[i].T@fr[(i+1)%len(fr)];U,s,V=np.linalg.svd(M);Wpair=(U@V)@Wpair;mino=min(mino,s.min())
    r=rng.standard_normal(p);r/=np.linalg.norm(r)
    spurious=np.linalg.norm(Wpair@r-r)
    holo=np.sort(np.abs(np.angle(np.linalg.eigvals(Wpair))))[::-1][0]
    print("     %.2f          %.4f  (looks fine)     %.4f rad        %.1f%% of the reference"%(
        k,mino,holo,100*spurious))
print(" => local pairwise checks stay ~0.999 (calibration 'passes') while the loop")
print("    accumulates a real rotation. A researcher comparing start vs end (same condition!)")
print("    sees a spurious change of up to tens of %% -- a FALSE effect from geometry alone.")
print("    Only assembling the whole cycle as one object exposes it; RG returns it exactly,")
print("    and at k=0 (flat) reports 0 -- certifying independent probes are safe there.")

print("\n"+"="*72)
print("PILLAR 3 -- REPRODUCIBILITY: raw quantities don't travel between labs; invariants do")
print("="*72)
p,q=5,5
Sig=rng.standard_normal((p+q,p+q));Sig=Sig@Sig.T+0.5*np.eye(p+q)
SR=Sig[:p,:p];C=Sig[:p,p:];SN=Sig[p:,p:]
def canon(SR,C,SN): return np.sort(np.linalg.svd(isqrt(SR)@C@isqrt(SN),compute_uv=False))[::-1]
rho0=canon(SR,C,SN)
print(" same system, two labs with different (valid) probe frames = a gauge (U,V):\n")
print("  lab   raw coupling entry C[0,0]   raw ||C||    canonical correlations (RG invariant)")
for lab in range(3):
    U=np.linalg.qr(rng.standard_normal((p,p)))[0];V=np.linalg.qr(rng.standard_normal((q,q)))[0]
    Cg=U@C@V.T
    print("   %d          %+.3f                %.3f      %s"%(lab+1,Cg[0,0],np.linalg.norm(Cg),np.round(canon(U@SR@U.T,Cg,V@SN@V.T),3)))
print(" => raw entries and loadings differ completely between labs (irreproducible);")
print("    the RG invariants are identical to 3 decimals. Reporting raw quantities")
print("    manufactures false non-replication; only the invariants are comparable.")

print("\n"+"="*72)
print("THE NECESSITY CHAIN (what forces RG through the academic path)")
print("="*72)
print(" 1. Probe one sector, one condition, never combine   -> independent probes suffice.")
print(" 2. Want the UN-probed sector                        -> need coupling  (Pillar 1).")
print(" 3. Combine across conditions                        -> need transport+holonomy (Pillar 2).")
print(" 4. Compare across labs/setups                       -> need gauge invariants (Pillar 3).")
print(" 5. These are ONE object, not three patches: doing them piecemeal reinvents RG,")
print("    incompletely and inconsistently.")
print(" 6. RG is self-limiting: flat & decoupled => it returns 0 and certifies probes safe;")
print("    curved/coupled => it returns the exact correction. Zero cost when unneeded.")
