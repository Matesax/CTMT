# CTMT chaotic coil extraction (vacuum Biot-Savart, structural ratio mu0)

Windows: 98
Rank(unique): [2, 3] (mode=3)
kappa(median [IQR]): 4.99e+08 [9.01e+07, 3.51e+09]
Monotonicity: total violations across tests = 0, rate=0.00%
Composability rel. spectral diff (median): 1.028e-14
Acceptance band coverage (95% band, median): 96.50%