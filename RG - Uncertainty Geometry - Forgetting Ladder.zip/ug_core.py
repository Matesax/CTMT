"""Uncertainty Geometry core: exact operators used by the attack battery.

Design rule: every LOCK is a statement about an operator (transfer operator,
flow, Markov kernel).  Samples are used only as a REFUTATION channel.
All arithmetic that carries a lock is exact (fractions / integers) where the
operator allows it; floating point is labelled as such.
"""
from fractions import Fraction
import numpy as np

SEEDS = [20261010, 1, 42, 777]

# ---------------------------------------------------------------- tent map
def tent_P_step(v):
    """Exact Perron-Frobenius operator of the tent map T(x)=1-|2x-1| on a
    dyadic step density of level L (list of 2^L values).  Returns the image
    re-expressed at the same level L (it is in fact of level L-1).
        (Pf)(x) = (f(x/2) + f(1-x/2))/2
    For x in level-(L-1) cell j: x/2 in level-L cell j, 1-x/2 in cell 2^L-1-j.
    """
    n = len(v); half = n // 2
    w = [(v[j] + v[n - 1 - j]) / 2 for j in range(half)]
    out = []
    for x in w:
        out.extend([x, x])
    return out

def tent_P_float(v):
    v = np.asarray(v, float); n = len(v); half = n // 2
    w = 0.5 * (v[:half] + v[::-1][:half])
    return np.repeat(w, 2)

def variation(v):
    """Essential total variation of a step function on [0,1] (exact if v exact)."""
    return sum(abs(v[i + 1] - v[i]) for i in range(len(v) - 1))

def tv_step(v, w):
    """TV distance between two step densities on the same dyadic level."""
    n = len(v)
    return sum(abs(a - b) for a, b in zip(v, w)) / (2 * n)

def normalize_exact(ints):
    ints = [int(a) for a in ints]; s = sum(ints); n = len(ints)
    return [Fraction(a * n, s) for a in ints]   # mean value 1 => integral 1

def tent_bv_bound(n, var_diff):
    """Rung R38: TV(P^n f, P^n g) <= 2^{-n-2} Var(f-g)  (sharp)."""
    return Fraction(var_diff) / (2 ** (n + 2)) if isinstance(var_diff, Fraction) else var_diff / 2 ** (n + 2)

# ---------------------------------------------------------------- cat map lattice
def cat_perm(N, A=((2, 1), (1, 1))):
    """Discrete toral automorphism on Z_N^2 as an index permutation."""
    x, y = np.meshgrid(np.arange(N), np.arange(N), indexing='ij')
    X = (A[0][0] * x + A[0][1] * y) % N
    Y = (A[1][0] * x + A[1][1] * y) % N
    return (X * N + Y).ravel()

def push(mass, perm):
    """Exact pushforward of an integer mass vector under an index map."""
    out = np.zeros_like(mass)
    np.add.at(out, perm, mass)
    return out

def tv_int(a, b):
    """Exact TV of two integer mass vectors with equal total, as Fraction."""
    return Fraction(int(np.abs(a - b).sum()), 2 * int(a.sum()))

def block_obs(mass, N, B):
    return mass.reshape(N // B, B, N // B, B).sum(axis=(1, 3)).ravel()

# ---------------------------------------------------------------- Markov kernels
def dobrushin(K):
    """delta(K) = 1/2 max_{i,j} sum_k |K_ik - K_jk|."""
    M = K.shape[0]; best = 0.0
    for i in range(M):
        best = max(best, 0.5 * np.abs(K[i] - K).sum(axis=1).max())
    return best

# ---------------------------------------------------------------- 2D Galerkin NS
class NS2D:
    """Exact-dealiased Fourier-Galerkin 2D incompressible NS (rotational form).
    State: Fourier coefficients (norm='forward') of shape (..., 2, n, n).
    Norm convention: ||u||^2 = mean_x |u|^2 = sum_k |c_k|^2."""
    def __init__(self, n, nu, force_amp=0.0):
        self.n = n; self.nu = nu
        k = np.fft.fftfreq(n) * n
        self.K = np.array(np.meshgrid(k, k, indexing='ij'))
        self.k2 = (self.K ** 2).sum(0)
        self.den = np.where(self.k2 == 0, 1, self.k2)
        self.mask = np.all(np.abs(self.K) < n / 3, axis=0) & (self.k2 > 0)
        x = np.arange(n) * 2 * np.pi / n
        X, Y = np.meshgrid(x, x, indexing='ij')
        tg = np.stack([np.sin(X) * np.cos(Y), -np.cos(X) * np.sin(Y)])
        self.tg = self.fft(tg)
        self.f = force_amp * self.tg
        # sqrt(sum_k |k|^2) over the Galerkin support (both velocity components share it)
        self.sqrtK2 = float(np.sqrt(self.k2[self.mask].sum()))
    def fft(self, u): return np.fft.fftn(u, axes=(-2, -1), norm='forward')
    def ifft(self, u): return np.fft.ifftn(u, axes=(-2, -1), norm='forward')
    def project(self, u):
        dot = (u * self.K).sum(axis=-3, keepdims=True)
        return u - self.K * dot / self.den
    def rhs(self, u):
        v = self.ifft(u).real
        w = self.ifft(1j * (self.K[0] * u[..., 1, :, :] - self.K[1] * u[..., 0, :, :])).real
        cross = np.stack([v[..., 1, :, :] * w, -v[..., 0, :, :] * w], axis=-3)
        z = self.project(self.fft(cross)) * self.mask
        return z - self.nu * self.k2 * u + self.f
    def norm(self, u):
        return np.sqrt((np.abs(u) ** 2).sum(axis=(-3, -2, -1)))
    def rk4(self, u, h):
        a = self.rhs(u); b = self.rhs(u + h * a / 2); c = self.rhs(u + h * b / 2); d = self.rhs(u + h * c)
        return u + h * (a + 2 * b + 2 * c + d) / 6
    def run(self, u, T, h, every=1):
        steps = int(round(abs(T) / abs(h))); h = np.sign(T) * abs(T) / steps
        out = [u.copy()]; ts = [0.0]
        for i in range(steps):
            u = self.rk4(u, h)
            if (i + 1) % every == 0 or i == steps - 1:
                out.append(u.copy()); ts.append((i + 1) * h)
        return np.array(ts), np.array(out)
    def shell_field(self, rng, rmin, rmax, energy, family='gaussian'):
        """Real divergence-free perturbation supported in rmin<=|k|<=rmax, with
        ||u||^2/2 = energy.  Families differ in coefficient law."""
        u = np.zeros((2, self.n, self.n), complex)
        r = np.sqrt(self.k2)
        sel = self.mask & (r >= rmin) & (r <= rmax)
        idx = np.argwhere(sel)
        for (i, j) in idx:
            ki, kj = int(self.K[0, i, j]), int(self.K[1, i, j])
            if (ki, kj) < (0, 0) or (ki == 0 and kj == 0):
                continue
            if family == 'gaussian':
                a = rng.normal(size=2) + 1j * rng.normal(size=2)
            elif family == 'phase':
                a = np.exp(2j * np.pi * rng.uniform(size=2))
            elif family == 'sparse':
                a = (rng.uniform() < 0.3) * (rng.normal(size=2) + 1j * rng.normal(size=2))
            elif family == 'sign':
                a = rng.choice([-1, 1], size=2) + 1j * rng.choice([-1, 1], size=2)
            else:
                raise ValueError(family)
            u[:, i, j] = a
            u[:, (-i) % self.n, (-j) % self.n] = np.conj(a)
        u = self.project(u) * self.mask
        nrm = self.norm(u)
        if nrm == 0:   # degenerate draw: declared fallback, reported by caller
            return self.shell_field(rng, rmin, rmax, energy, 'gaussian')[0], True
        return u * np.sqrt(2 * energy) / nrm, False
