# RG – Uncertainty Geometry: The Forgetting Ladder — hostile battery

Every claim is attacked; nothing is trusted. A ladder rung is accepted only if
(1) the attack fails to break it AND (2) a deliberate mutation is detected by the same test
(a test that cannot fail does not count).

## Run
    pip install numpy scipy matplotlib
    python run_all.py --out results      # ~100 s, one core
    python make_figures.py

Seeds: 20261010, 1, 42, 777. Exact rationals / integers for the tent and cat-map operators.
Numerical gates are tied to the margin of the claim, not to fixed tolerances.

## Modules (attacks/)
| id | rung | target |
|----|------|--------|
| A01 | R33 | TV rigidity under bijections (cat lattice, exact integers) |
| A02 | R33 | forced 2D Galerkin NS at prior parameters is injective (round trip) |
| A03 | R34,R35 | forgetting = fibre migration; exact recurrence of finite bijections |
| A04 | R36 | no uniform forgetting over a.c. laws (exact closed form) |
| A05 | R38 | **mixing lock**: TV <= 2^-(n+2) Var(f-g), sharp (exact rationals + adversarial search) |
| A06 | R38 | logistic r=4 via conjugacy; prior Prop.1 numbers vs certified bound |
| A07 | R36,R47 | float declarations are atomic; zero diameter with TV~1 error |
| A08 | R42,R34 | cat-map weak forgetting frontier; un-forgetting witness |
| A09 | R39 | Galerkin NS W1 contraction lock; gate G_N = S|f|/nu^2 at prior parameters |
| A10 | R40 | Dobrushin block lock; one-step coefficient of local noise is 1 |
| A11 | R41 | functional type: time averages vs fixed-time laws |
| A12 | R43 | DKW coverage; Le Cam TV no-go; prior scale sweep = noise floor |
| A13 | R45 | wall correspondence = fibre saturation identity |
| A14 | audit | canaries in the supplied NS code (4 tautologies) |
| A15 | audit | supplied ZIP vs RG_NS_Audited_Ladder.pdf provenance |

`prior/` holds the supplied files audited by A14/A15 (unchanged copies).
`results/ug_results.json` holds every witness, seed, mutation outcome, environment and source hashes.
`paper/` holds the LaTeX source and PDF.

## Verdict of this run
14/14 ladder targets survived with detected mutations. Prior claims broken: A06b, A11b, A12c, A14, A15.
Open by theorem: forced deterministic NS forgetting (R46).
