"""A13 / R45  Wall correspondence = fibre saturation (forced, not empirical).
Target: y=b^2+eps.  For every replication, the full preimage of the y-confidence set covers b
iff the y-set covers b^2.  Hence its coverage EQUALS the observation coverage identically
(R2/R3), and the positive-branch Wald coverage of b=-0.5 is 0 by construction.
Prior claim clarified: Stress Sec.7 coverage 0.9534 vs 0 is an identity of the kernel pair,
not evidence produced by the battery.  Includes the wall itself (b=0)."""
import numpy as np
from ug_core import SEEDS
from attacks.common import result

def run():
    sig, z = 0.02, 1.959963984540054; wit = []; ok = True
    for s in SEEDS:
        rng = np.random.default_rng(s)
        for b in [-0.5, -0.1, 0.0, 0.3]:
            y = b * b + sig * rng.normal(size=20000); lo, hi = y - z * sig, y + z * sig
            cov_y = (lo <= b * b) & (b * b <= hi)
            # preimage of [lo,hi] under b->b^2: {b: lo<=b^2<=hi}
            pre = (b * b >= lo) & (b * b <= hi)
            bh = np.sqrt(np.maximum(y, 1e-12)); half = z * sig / (2 * bh)
            wald = (bh - half <= b) & (b <= bh + half)
            ident = bool(np.all(pre == cov_y)); ok &= ident
            wit.append({'seed': s, 'b': b, 'coverage_preimage': float(pre.mean()), 'coverage_y': float(cov_y.mean()),
                        'identity_every_replication': ident, 'wald_positive_branch_coverage': float(wald.mean())})
    # sensitivity: positive-branch-only 'preimage' must break the identity for b<0
    rng = np.random.default_rng(SEEDS[0]); b = -0.5; y = b * b + sig * rng.normal(size=2000)
    lo, hi = y - z * sig, y + z * sig
    pos = (np.sqrt(np.maximum(lo, 0)) <= b) & (b <= np.sqrt(np.maximum(hi, 0)))
    detected = bool(np.any(pos != ((lo <= b * b) & (b * b <= hi))))
    return result('A13', 'R45', 'forced', 'Preimage coverage equals observation coverage in every replication (including the wall b=0)',
                  ok, SEEDS, wit, sensitivity={'mutation': 'positive-branch-only preimage', 'detected': detected},
                  refutes=['Stress Sec.7 reports the 0.9534 vs 0 contrast as an empirical finding; it is forced by R2 and the coverage of the y-interval'])
