"""A06 / R38 transported to logistic r=4 (conjugacy), and attack on the prior
'registered mixing certificate' (Stress paper, Prop. 1).
Target 1 (lock): h(x)=sin^2(pi x/2) conjugates tent T to logistic L: L o h = h o T.
   Hence for logistic laws rho, sigma with pulled-back tent densities
   f_rho = (rho o h) h',  TV(L^n#rho, L^n#sigma) <= 2^{-(n+2)} Var(f_rho - f_sigma).
Target 2 (prior claim): the prior battery's late-window TV 0.02143 / W1 0.00442 /
   entropy spread 0.00861 at n~60 measure the population declaration distance.
Attack: compute Var of the pulled-back prior-style declarations (uniform,
   Gaussian, bimodal: parameters are DECLARED here because the prior script was
   not supplied), evaluate the certified bound at n=60, and cross-check the
   bound on step approximations with exact tent transfer and an L1 enclosure."""
import numpy as np
from scipy.stats import norm
from ug_core import tent_P_float, SEEDS
from attacks.common import result

h = lambda x: np.sin(np.pi * x / 2) ** 2
dh = lambda x: (np.pi / 2) * np.sin(np.pi * x)

def decl(name):
    if name == 'uniform': return lambda y: np.ones_like(y)
    if name == 'gaussian':
        Z = norm.cdf(.5 / .15) - norm.cdf(-.5 / .15)
        return lambda y: norm.pdf((y - .5) / .15) / .15 / Z
    if name == 'bimodal':
        Z = 0.5 * sum(norm.cdf((1 - c) / .07) - norm.cdf(-c / .07) for c in (.25, .75))
        return lambda y: 0.5 * (norm.pdf((y - .25) / .07) + norm.pdf((y - .75) / .07)) / .07 / Z
    raise ValueError

def pulled(name, G):
    x = (np.arange(G) + .5) / G
    return decl(name)(h(x)) * dh(x)

def run():
    names = ['uniform', 'gaussian', 'bimodal']
    xs = np.linspace(0, 1, 2001)
    conj_err = float(np.max(np.abs(4 * h(xs) * (1 - h(xs)) - h(1 - np.abs(2 * xs - 1)))))
    # variation with refinement (grid variation is a lower bound converging to Var)
    var = {}
    for G in [2 ** 12, 2 ** 16, 2 ** 20]:
        F = {n: pulled(n, G) for n in names}
        var[G] = {f'{a}|{b}': float(np.abs(np.diff(F[a] - F[b])).sum()) for i, a in enumerate(names) for b in names[i + 1:]}
    V = max(var[2 ** 20].values())
    bound60 = V / 2 ** 62
    # enclosure cross-check at level L: TV(P^n f, P^n g) <= TV(P^n f_L,P^n g_L) + (||f-f_L||+||g-g_L||)/2
    L = 16; G = 2 ** L; F = {n: pulled(n, 2 ** 20).reshape(G, -1).mean(axis=1) for n in names}
    rows = []; ok = conj_err < 1e-14
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            f, g = F[a] / F[a].mean(), F[b] / F[b].mean(); Vd = var[2 ** 20][f'{a}|{b}']
            for n in range(0, 15):
                t = 0.5 * np.abs(f - g).mean(); bnd = Vd / 2 ** (n + 2)
                ok &= t <= bnd * (1 + 1e-9) + 1e-12
                if n in (0, 2, 5, 10, 14): rows.append({'pair': f'{a}|{b}', 'n': n, 'TV_step_approx': float(t), 'bound': bnd})
                f, g = tent_P_float(f), tent_P_float(g)
    prior = {'late_TV': 0.02143, 'late_W1': 0.00442, 'entropy_spread': 0.00861, 'n': 60}
    prior_is_population = prior['late_TV'] <= bound60   # False => reported numbers cannot be population TV
    lock = result('A06', 'R38 (transported)', 'lock (gated: BV pull-back)', 'Logistic r=4: TV(L^n#rho,L^n#sigma) <= 2^-(n+2) Var(f_rho - f_sigma) via conjugacy',
                  bool(ok), SEEDS, {'conjugacy_max_err': conj_err, 'Var_pullback_by_grid': var, 'certified_TV_bound_n60': bound60, 'rows': rows},
                  sensitivity={'mutation': 'use logistic densities directly (no pull-back Jacobian h\')', 'detected': None},
                  boundary="Declarations must have BV pull-back; Diracs/atomic float laws are outside (A07).")
    # sensitivity for the lock: dropping the Jacobian breaks the conjugacy-transported identity
    x = (np.arange(4096) + .5) / 4096; wrong = decl('uniform')(h(x)); lock['sensitivity']['detected'] = bool(abs(wrong.mean() - 1) < 1e-9 and abs(pulled('uniform', 4096).mean() - 1) < 1e-3 and np.abs(wrong - pulled('uniform', 4096)).max() > .1)
    prior_res = result('A06b', 'P-Stress Prop.1', 'prior-claim', 'Prior late-window TV/W1/entropy values (n~60) are population declaration distances',
                       bool(prior_is_population), SEEDS, {'certified_population_TV_bound_n60': bound60, 'prior_reported': prior},
                       refutes=['Stress Prop.1 as an evidence statement: its numbers exceed the certified population value by >1e15; they are estimator noise (see A12c)'],
                       boundary='The prior CONCLUSION (logistic forgets, involution does not) is TRUE, but is now forced by R38/R33, not by the registered statistics.')
    return [lock, prior_res]
