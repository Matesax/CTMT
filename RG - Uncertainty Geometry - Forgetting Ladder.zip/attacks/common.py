import json, numpy as np
from fractions import Fraction
def jsonable(x):
    if isinstance(x, Fraction): return {'fraction': f'{x.numerator}/{x.denominator}', 'float': float(x)}
    if isinstance(x, (np.integer,)): return int(x)
    if isinstance(x, (np.floating,)): return float(x)
    if isinstance(x, np.ndarray): return [jsonable(v) for v in x.tolist()]
    if isinstance(x, (list, tuple)): return [jsonable(v) for v in x]
    if isinstance(x, dict): return {str(k): jsonable(v) for k, v in x.items()}
    if isinstance(x, (bool, np.bool_)): return bool(x)
    return x
def result(id, rung, kind, target, survived, seeds, witness, sensitivity=None, refutes=None, boundary=None):
    """survived=True: the attack failed to break `target`.
    sensitivity: dict(mutation=..., detected=bool) -- proves the test CAN fail."""
    return jsonable(dict(id=id, rung=rung, kind=kind, target=target,
                         outcome='SURVIVED' if survived else 'BROKEN', seeds=seeds,
                         witness=witness, sensitivity=sensitivity, refutes=refutes or [], boundary=boundary))
