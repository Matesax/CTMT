"""A02 / R33 applied to Galerkin NS.
Target: the forced 2D Galerkin NS flow at the prior paper's parameters is a
bijection on its phase space over the horizon (it is a smooth ODE flow).
Attack: forward T then backward T with RK4; demand recovery to the RK4 error
level, convergent under timestep halving.  If recovery failed (beyond
discretisation error) the flow would not be numerically injective.
Consequence (R33): full-state TV between any two declared ensembles is EXACTLY
constant in time for the exact Galerkin flow; any 'forgetting' must live in an
observation quotient (R34) or in a weak metric via contraction (R39)."""
import numpy as np
from ug_core import NS2D, SEEDS
from attacks.common import result

def run():
    wit = []
    ok = True
    for s in SEEDS:
        rng = np.random.default_rng(s)
        ns = NS2D(16, nu=0.025, force_amp=0.05)
        u0 = ns.tg.copy()
        p, _ = ns.shell_field(rng, 3, 4.5, 0.012)
        u0 = u0 + p
        errs = {}
        for h in [0.04, 0.02, 0.01]:
            _, U = ns.run(u0, 2.0, h, every=10**9)
            _, V = ns.run(U[-1], -2.0, h, every=10**9)
            errs[h] = float(ns.norm(V[-1] - u0) / ns.norm(u0))
        conv = errs[0.04] / errs[0.02]
        wit.append({'seed': s, 'roundtrip_rel_err': errs, 'halving_ratio': conv})
        ok &= errs[0.01] < 1e-8 and conv > 8
    # sensitivity: a deliberately non-injective map (projection onto low modes) must fail roundtrip
    ns = NS2D(16, 0.025, 0.05); rng = np.random.default_rng(SEEDS[0]); p, _ = ns.shell_field(rng, 3, 4.5, 0.012)
    u0 = ns.tg + p; low = (ns.k2 <= 4)
    _, U = ns.run(u0 * low, 2.0, 0.01, every=10**9); _, V = ns.run(U[-1], -2.0, 0.01, every=10**9)
    mut = float(ns.norm(V[-1] - u0) / ns.norm(u0))
    return result('A02', 'R33', 'no-go (applied)', 'Forced 2D Galerkin NS (nu=0.025, 0.05 TG forcing, T=2) is injective: roundtrip recovers the state to RK4 order',
                  ok, SEEDS, wit, sensitivity={'mutation': 'insert low-mode projection (non-injective) before the flow', 'detected': mut > 1e-3, 'roundtrip_rel_err': mut},
                  refutes=['The prior NS ladder could in principle certify full-state TV forgetting at its parameters'])
