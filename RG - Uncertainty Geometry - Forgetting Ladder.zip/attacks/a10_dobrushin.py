"""A10 / R40  Markov (Dobrushin) lock, and why determinism defeats it.
Target: for a Markov kernel K, TV(mu K^n, nu K^n) <= delta(K)^n TV(mu,nu), with
   delta(K) = 1/2 max_{i,j} ||K(i,.) - K(j,.)||_1; equality attained at n=1 by the maximising Diracs.
   Every deterministic kernel with two distinct images has delta = 1 (no uniform TV contraction):
   forgetting in TV needs either noise (here) or a regularity class (R37/R38).
Attack: rotation by 7 cells on a 60-cell circle (deterministic, delta=1) vs the same rotation
followed by uniform noise on +-3 cells; random laws, 4 seeds, n<=40."""
import numpy as np
from ug_core import dobrushin, SEEDS
from attacks.common import result

def run():
    M, s0, w = 60, 7, 3
    R = np.roll(np.eye(M), s0, axis=1)
    Nz = np.zeros((M, M))
    for i in range(M):
        for d in range(-w, w + 1): Nz[i, (i + d) % M] += 1 / (2 * w + 1)
    K = R @ Nz
    dR, d1 = dobrushin(R), dobrushin(K)
    # one-step coefficient of LOCAL noise is 1 (disjoint row supports): the lock must use K^m
    m0 = 1; Km = K.copy()
    while dobrushin(Km) >= 1 - 1e-12:
        m0 += 1; Km = Km @ K
    # choose the block length with the best per-step rate (declared search range m <= 60)
    rates = {}; P = np.eye(M)
    for mm in range(1, 61):
        P = P @ K; rates[mm] = dobrushin(P) ** (1 / mm)
    m = min(rates, key=rates.get); Km = np.linalg.matrix_power(K, m)
    dK = rates[m]
    wit = {'delta_rotation': dR, 'delta_one_step_noisy': d1, 'first_contracting_block': m0, 'block_m': m, 'delta_K^m': dobrushin(Km), 'per_step_rate': dK, 'cases': []}
    ok = abs(dR - 1) < 1e-15 and abs(d1 - 1) < 1e-15 and dobrushin(Km) < 1
    for s in SEEDS:
        rng = np.random.default_rng(s)
        for _ in range(20):
            mu, nu = rng.dirichlet(np.ones(M) * .3), rng.dirichlet(np.ones(M) * .3)
            t0 = .5 * np.abs(mu - nu).sum(); a, b = mu, nu; worst = 0
            ar, br = mu, nu; rigid = True
            for n in range(1, 241):
                a, b = a @ K, b @ K; t = .5 * np.abs(a - b).sum(); worst = max(worst, t / (dobrushin(Km) ** (n // m) * t0))
                ar, br = ar @ R, br @ R; rigid &= abs(.5 * np.abs(ar - br).sum() - t0) < 1e-12
            ok &= worst <= 1 + 1e-9 and rigid
        wit['cases'].append({'seed': s, 'max_ratio_TV/(delta^n TV0)': float(worst), 'rotation_TV_rigid': bool(rigid)})
    # equality witness at n=m: maximising Diracs for the m-block
    i, j = 0, 0; best = -1
    for a_ in range(M):
        v = .5 * np.abs(Km[a_] - Km).sum(axis=1); b_ = int(v.argmax())
        if v[b_] > best: best, i, j = v[b_], a_, b_
    e1, e2 = np.eye(M)[i], np.eye(M)[j]; eqv = .5 * np.abs(e1 @ Km - e2 @ Km).sum()
    wit['equality_block'] = {'i': i, 'j': j, 'TV_m': float(eqv), 'delta_K^m': dobrushin(Km)}
    ok &= abs(eqv - dobrushin(Km)) < 1e-12
    detected = eqv > 0.9 * dobrushin(Km)  # overclaim 0.9*delta(K^m) refuted by the Dirac witness
    return result('A10', 'R40', 'lock (gated: Markov noise) + no-go (deterministic delta=1)',
                  'TV(mu K^n,nu K^n) <= delta(K^m)^floor(n/m) TV(mu,nu), sharp at n=m; one-step delta of local noise is 1; deterministic rotation has delta=1 and is TV-rigid',
                  bool(ok), SEEDS, wit, sensitivity={'mutation': 'overclaim 0.9*delta(K^m)', 'detected': bool(detected)},
                  refutes=['One-step Dobrushin coefficient < 1 whenever noise is present (false for local noise: delta(K)=1, block m needed)', 'Forgetting is a property of chaos; here a non-chaotic rotation forgets once noise is added and a chaotic invertible map never does in TV'])
