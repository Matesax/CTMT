"""A04 / R36  No uniform forgetting without a declared regularity class.
Target (no-go): for the exact (mixing) tent map, over the family of all
absolutely continuous laws, sup TV(T^n#mu, T^n#nu) = 1 for EVERY n.
Witness (exact): f_k = 2^k 1[0,2^-k] vs Lebesgue: TV(P^n f_k, 1) = 1 - 2^{n-k} (n<=k).
So 'the system is mixing' never certifies a uniform forecast frontier.  Mixing is
pointwise in the law; uniformity is a declaration (R37/R38).
Also transported to logistic r=4 by the conjugacy h(x)=sin^2(pi x/2)."""
from fractions import Fraction
import numpy as np
from ug_core import tent_P_step, tv_step, SEEDS
from attacks.common import result

def run():
    L = 14; ones = [Fraction(1)] * (2 ** L); rows = []; ok = True
    for k in [4, 8, 12, 14]:
        f = [Fraction(2 ** k) if i < 2 ** (L - k) else Fraction(0) for i in range(2 ** L)]
        g = f
        for n in range(0, k + 1):
            t = tv_step(g, ones); exact = 1 - Fraction(2 ** n, 2 ** k)
            if t != exact: ok = False
            if n in (0, k // 2, k - 1, k): rows.append({'k': k, 'n': n, 'TV': t, 'closed_form': exact})
            g = tent_P_step(g)
    # sup over k at fixed n: for every n there is k with TV >= 1-2^{-m}
    sup_rows = [{'n': n, 'TV_with_k=n+10': 1 - Fraction(1, 2 ** 10)} for n in [1, 10, 100, 1000]]
    # sensitivity: if the identity were false (e.g. claim TV = 1-2^{n-k+1}) the exact check flags it
    f = [Fraction(2 ** 6) if i < 2 ** (L - 6) else Fraction(0) for i in range(2 ** L)]
    wrong = tv_step(tent_P_step(f), ones) != 1 - Fraction(2 ** 2, 2 ** 6)
    return result('A04', 'R36', 'no-go', 'For a mixing map, sup over a.c. declarations of the propagated TV diameter equals 1 at every finite n',
                  ok, SEEDS, {'exact_rows': rows, 'sup_witness': sup_rows, 'arithmetic': 'exact rationals, dyadic level 14'},
                  sensitivity={'mutation': 'shift closed form by one step', 'detected': bool(wrong)},
                  refutes=['Mixing (or positive Lyapunov exponent) by itself locks declaration forgetting',
                           'A finite list of declared laws certifies forgetting over the admissible class'])
