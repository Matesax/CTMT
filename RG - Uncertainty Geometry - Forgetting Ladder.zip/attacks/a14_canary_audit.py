"""A14  Canary audit of the SUPPLIED code (ns_uncertainty_battery.py in NS_Uncertainty_Reproducibility.zip).
Target (prior claim): '36 caught mutations in 36 trials' measures detector sensitivity.
Attack: parse the canary dictionary with ast; for each canary evaluate its 'mutation_caught'
expression under adversarial environments in which the pipeline is BROKEN (one family, one
scale, zero rank, negative chaos slope, arbitrary stored results).  An expression that stays
True in every environment cannot fail: it is a tautology, not a canary."""
import ast, os, numpy as np
from attacks.common import result

SRC = os.path.join(os.path.dirname(__file__), '..', 'prior', 'ns_uncertainty_battery.py')

class FakeNS:
    def __init__(self, nu): self.nu = nu

def classify(expr_src, names):
    pipeline = {'div', 'support', 'transfer', 'good', 'bad', 'goodalias', 'badalias', 'wasserstein_distance', 'a', 'b'}
    if names & {'div', 'support', 'transfer'}: return 'PIPELINE', None
    if names & {'a', 'b', 'wasserstein_distance'}: return 'FIXTURE (literal arrays inside the canary block)', None
    envs = []
    for fam in ([], ['x'], ['g', 'p', 's', 'h'], ['g'] * 50):
        for nu in (1e-6, 0.04, 10.0):
            for mu in (0.0, 0.05, 1.0):
                envs.append({'FAMILIES': fam, 'ns': FakeNS(nu), 'np': np, 'len': len,
                             'results': {'configs': {'3D_24': {'min_upper': mu, 'max_empirical_W1': 1 - mu}}, 'sabra': {'finite_time_slope': -1.0}}})
    vals = set()
    for e in envs:
        try: vals.add(bool(eval(expr_src, {}, e)))
        except Exception as ex: vals.add('error')
    if names & {'results'}: return ('STORED-RESULT REREAD' if len(vals) > 1 else 'TAUTOLOGY'), sorted(map(str, vals))
    return ('TAUTOLOGY' if vals == {True} else 'ENV-DEPENDENT'), sorted(map(str, vals))

def run():
    tree = ast.parse(open(SRC).read()); rows = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and getattr(node.targets[0], 'id', None) == 'cases':
            for k, v in zip(node.value.keys, node.value.values):
                mut = v.elts[1]; src = ast.unparse(mut)
                names = {n.id for n in ast.walk(mut) if isinstance(n, ast.Name)}
                cls, vals = classify(src, names)
                rows.append({'canary': k.value, 'mutation_expr': src, 'class': cls, 'values_over_envs': vals})
    taut = [r for r in rows if r['class'] in ('TAUTOLOGY',)]
    real = [r for r in rows if r['class'] == 'PIPELINE']
    return result('A14', 'P-NS canaries', 'audit', "Supplied canaries measure detector sensitivity ('36/36 caught')",
                  len(taut) == 0, [20261010, 1, 42, 777],
                  {'canaries': rows, 'n_tautological': len(taut), 'n_pipeline': len(real),
                   'trials_that_could_fail': 4 * len(real), 'trials_reported': 36},
                  sensitivity={'mutation': 'evaluate a genuine pipeline canary under the same harness', 'detected': len(real) > 0},
                  refutes=['36/36 as a sensitivity count: only pipeline canaries can fail; the others are constant or reread stored output'])
