"""A08 / R42 + R34  Invertible hyperbolic forgetting is weak, scale-dependent and NON-monotone.
Continuum cat map A=[[2,1],[1,1]] on T^2.  P f = f o A^{-1}; on Fourier modes k -> A^{-T}k = A^{-1}k.
Target 1 (R42 lock, gated: band-limited declarations): densities 1+sum_{0<|k|_inf<=K0} c_k e_k
   are forgotten EXACTLY on the observed window |k|_inf<=K after a finite exit time n*(K0,K),
   while TV stays constant (R33).  n* grows like log K / log lambda: the frontier is scale-bound.
Target 2 (R34 consequence, no-go): observed forgetting is not monotone.  A declaration
   difference that is INVISIBLE in the window at t=0 (k = A^m k0, |k| large) becomes visible
   at t=m.  Initially matched observables can acquire declaration dependence.
Exact integer arithmetic (Python ints)."""
import numpy as np
from ug_core import SEEDS
from attacks.common import result

Ainv = ((1, -1), (-1, 2)); A = ((2, 1), (1, 1))
def mul(M, k): return (M[0][0] * k[0] + M[0][1] * k[1], M[1][0] * k[0] + M[1][1] * k[1])
def ninf(k): return max(abs(k[0]), abs(k[1]))

def exit_time(K0, K, horizon=400):
    ks = [(a, b) for a in range(-K0, K0 + 1) for b in range(-K0, K0 + 1) if (a, b) != (0, 0)]
    last_inside = 0
    for k in ks:
        q = k
        for m in range(1, horizon + 1):
            q = mul(Ainv, q)
            if ninf(q) <= K: last_inside = max(last_inside, m)
    return last_inside + 1

def run():
    lam = (3 + 5 ** .5) / 2
    table = []
    for K in [1, 4, 16, 64, 256, 1024]:
        n = exit_time(2, K); table.append({'K0': 2, 'K': K, 'exit_time': n, 'log(K)/log(lambda)': float(np.log(max(K, 1)) / np.log(lam))})
    mono = all(table[i]['exit_time'] <= table[i + 1]['exit_time'] for i in range(len(table) - 1))
    # un-forgetting witness: k = A^m k0 is outside the window at t=0 and equals k0 at t=m
    wit = []; ok = mono
    for s in SEEDS:
        rng = np.random.default_rng(s); m = int(rng.integers(5, 12))
        k0 = (int(rng.integers(1, 3)), int(rng.integers(-2, 3)))
        k = k0
        for _ in range(m): k = mul(A, k)
        q = k; vis = []
        for t in range(m + 1):
            vis.append(ninf(q) <= 2); q = mul(Ainv, q)
        wit.append({'seed': s, 'k0': k0, 'm': m, 'k_initial': k, 'visible_at_t0': vis[0], 'visible_at_t=m': vis[m]})
        ok &= (not vis[0]) and vis[m]
    # sensitivity: with the (wrong) forward transport k -> A k the window would be reached from k0 never; detect
    k = (1, 0); q = k; back = []
    for t in range(10): q = mul(A, q); back.append(ninf(q) <= 2)
    det = not all(back)
    return result('A08', 'R42,R34', 'lock (gated: band-limited) + no-go (monotonicity)',
                  'Cat map: band-limited declarations are forgotten exactly on window K after n*(K) ~ log K/log lambda; hidden differences can surface later',
                  bool(ok), SEEDS, {'exit_table': table, 'unforgetting_witnesses': wit},
                  sensitivity={'mutation': 'transport modes forward (k->Ak)', 'detected': bool(det)},
                  refutes=['Observed declaration distance is monotone non-increasing in time',
                           'An initially matched observable cannot later carry declaration dependence (NS paper treated this as an open empirical question; it is a structural possibility)'])
