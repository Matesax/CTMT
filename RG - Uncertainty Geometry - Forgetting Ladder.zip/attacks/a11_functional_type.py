"""A11 / R41  The requested functional decides which ergodic property is needed.
Target 1 (lock, uniform over ALL declarations incl. Diracs): time-average functionals
   involution x->1-x, g(x)=x:  |avg_n - 1/2| <= 1/(2n)   (equality for x=0, n odd)
   rotation by alpha, g=cos 2 pi x:  |avg_n| <= 1/(n |sin pi alpha|)
   while the FIXED-TIME functional E[g(x_n)] keeps the declaration forever.
Target 2 (no-go): positive Lyapunov exponent does not force time averages for all declarations:
   logistic r=4 Dirac at the fixed point 3/4 has time average 3/4; a.c. declarations give 1/2.
Prior claim attacked: Stress paper Fig. 'long-run sample mean' 0.2 vs 0.8 for the involution.
   Under the time-average reading this is false (both 1/2); it holds only as a fixed-time or
   even-time functional.  The functional type was undeclared."""
import numpy as np
from ug_core import SEEDS
from attacks.common import result

def run():
    alpha = (5 ** .5 - 1) / 2; wit = []; ok = True
    for s in SEEDS:
        rng = np.random.default_rng(s); x0 = rng.uniform(size=5000)
        rows = {}
        for n in [11, 101, 1001, 10001]:
            # involution: orbit x,1-x,x,...
            k = np.arange(n); orb = np.where(k[:, None] % 2 == 0, x0[None], 1 - x0[None])
            inv = np.abs(orb.mean(0) - .5).max() * 2 * n
            th = 2 * np.pi * (x0[None] + k[:, None] * alpha)
            rot = np.abs(np.cos(th).mean(0)).max() * n * abs(np.sin(np.pi * alpha))
            rows[n] = {'involution_scaled': float(inv), 'rotation_scaled': float(rot)}
            ok &= inv <= 1 + 1e-9 and rot <= 1 + 1e-6
        # fixed-time functional: two declarations, n even
        muA, muB = rng.beta(2, 8, 20000), rng.beta(8, 2, 20000)
        fixed = float(abs(muA.mean() - muB.mean()))
        # time average of the same two declarations, computed along orbits (n = 10001)
        n = 10001; kk = np.arange(n) % 2
        ta = lambda z: ((n + 1) // 2 * z + (n // 2) * (1 - z)) / n
        tav = float(abs(ta(muA).mean() - ta(muB).mean()))
        wit.append({'seed': s, 'scaled_bounds(<=1)': rows, 'fixed_time_declaration_gap': fixed, 'time_average_declaration_gap_n10001': tav, 'bound_1/n': 1 / n})
        ok &= tav <= 1 / n + 1e-12
    # logistic Dirac at 3/4 (exact float fixed point) vs a.c. declaration
    x = 0.75; avg_fp = 0.0
    for _ in range(100000): avg_fp += x; x = 4 * x * (1 - x)
    avg_fp /= 100000
    y = np.random.default_rng(SEEDS[0]).uniform(.01, .99, 200); acc = np.zeros_like(y)
    for _ in range(100000): acc += y; y = 4 * y * (1 - y)
    avg_ac = float(np.median(acc / 100000))
    wit.append({'logistic_time_avg_Dirac_3/4': avg_fp, 'logistic_time_avg_ac_median': avg_ac})
    ok &= avg_fp == 0.75 and abs(avg_ac - .5) < .02
    # sensitivity: overclaim involution 1/(4n): x=0, odd n gives exactly 1/(2n)
    n = 11; orb = np.array([0.0 if j % 2 == 0 else 1.0 for j in range(n)]); detected = abs(orb.mean() - .5) > 1 / (4 * n)
    lock = result('A11', 'R41', 'lock (uniform, incl. Diracs) + no-go', 'Time-average functionals forget declarations under unique ergodicity with explicit uniform rate; fixed-time functionals do not; chaos is not uniquely ergodic',
                  bool(ok), SEEDS, wit, sensitivity={'mutation': 'overclaim involution rate 1/(4n)', 'detected': bool(detected)},
                  refutes=['Positive Lyapunov exponent forces declaration-independence of long-run averages for all declarations'])
    prior = result('A11b', 'P-Stress Sec.6', 'prior-claim', "Involution 'long-run sample mean' depends on the declaration (0.2 vs 0.8)",
                   False, SEEDS, {'time_average_any_declaration': 0.5, 'bound': '1/(2n)'},
                   boundary='True only for a fixed-time (or parity-subsampled) functional; the prior text did not declare the functional type.')
    return [lock, prior]
