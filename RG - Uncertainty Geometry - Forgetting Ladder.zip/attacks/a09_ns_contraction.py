"""A09 / R39  Contraction lock for 2D Galerkin Navier-Stokes (W1, full state), with its gate.
Theorem under attack (exact Galerkin ODE, mean-zero, exact 2/3 dealiasing):
   ||u(t)|| <= rho(t) := e^{-nu t} R0 + (|f|/nu)(1-e^{-nu t})     for every ||u0|| <= R0,
   d/dt ||w||^2 <= 2(-nu + S ||u||) ||w||^2,  S = sqrt(sum_{k in support}|k|^2),
   hence Lip(Phi_t | ball R0) <= Lambda(t) := exp(-nu t + S int_0^t rho),
   and for ANY two declared laws on the ball:  W1(Phi_t#mu, Phi_t#nu) <= Lambda(t) W1(mu,nu).
   Uses: <(u.grad)w,w>=0 (exact for dealiased Galerkin), Poincare |grad w|>=|w| (mean zero),
   ||grad u||_inf <= S ||u|| (Cauchy-Schwarz on the finite support).
The lock is about the operator: it needs NO samples and covers every declaration on the ball.
Attack: (i) deterministic pair test, all member pairs, 4 families x 6 members, 4 seeds, all saved
times: ||Phi x - Phi y|| <= Lambda(t)||x-y||; (ii) sharpness pair (R0 -> 0, |k|=1 perturbation);
(iii) timestep halving; (iv) gate at the PRIOR paper's parameters (nu=0.025, forced): the
certificate rate must be reported as ABSENT, not tuned.  Sensitivity: overclaim rate 2nu."""
import numpy as np
from ug_core import NS2D, SEEDS
from attacks.common import result

FAM = ['gaussian', 'phase', 'sparse', 'sign']

def Lam(ns, t, R0, fnorm):
    nu, S = ns.nu, ns.sqrtK2
    integ = R0 * (1 - np.exp(-nu * t)) / nu + (fnorm / nu) * (t - (1 - np.exp(-nu * t)) / nu)
    return np.exp(-nu * t + S * integ)

def run():
    nu, T, h = 0.1, 120.0, 0.05
    out = {'regime': {'nu': nu, 'forcing': 0.0, 'T': T, 'dt': h}, 'seeds': []}; ok = True
    for s in SEEDS:
        rng = np.random.default_rng(s); ns = NS2D(16, nu, 0.0)
        base = ns.tg * (0.008 / ns.norm(ns.tg))
        mem = []; degenerate = 0
        for fam in FAM:
            for _ in range(6):
                p, d = ns.shell_field(rng, 3, 4.5, 0.5 * 0.002 ** 2, fam); degenerate += d
                mem.append(base + p)
        U0 = np.array(mem); R0 = float(ns.norm(U0).max())
        ts, U = ns.run(U0, T, h, every=80)
        L = Lam(ns, ts, R0, 0.0)
        worst = 0.0
        D0 = np.array([[ns.norm(U0[i] - U0[j]) for j in range(len(U0))] for i in range(len(U0))])
        for ti, t in enumerate(ts):
            if t == 0: continue
            Ut = U[ti]
            for i in range(len(U0)):
                d = ns.norm(Ut[i] - Ut[i + 1:]) ; d0 = D0[i, i + 1:]
                if len(d): worst = max(worst, float(np.max(d / (L[ti] * d0))))
        # W1 between families on the full state: certified bound and empirical coupled value
        r = 0.002
        certW1 = 2 * r * L
        fam_idx = np.arange(len(U0)).reshape(4, 6)
        emp = float(max(np.mean(ns.norm(U[-1][fam_idx[a]] - U[-1][fam_idx[b]])) for a in range(4) for b in range(a)))
        # timestep halving on the quantity actually tested (a pair distance), all saved times
        _, Uh = ns.run(U0[:2], T, h / 2, every=160)
        dh_ = ns.norm(Uh[:, 0] - Uh[:, 1]); dH = ns.norm(U[:, 0] - U[:, 1])
        dt_rel = float(np.max(np.abs(dh_ - dH) / dh_))
        tstar = float(ts[np.argmax(certW1 <= 1e-4)]) if np.any(certW1 <= 1e-4) else None
        out['seeds'].append({'seed': s, 'R0': R0, 'S': ns.sqrtK2, 'Lambda_T': float(L[-1]), 'max_ratio_actual/certified': worst,
                             'certified_W1_T': float(certW1[-1]), 'empirical_coupled_W1_T': emp, 'frontier_t(W1<=1e-4)': tstar,
                             'dt_halving_rel': dt_rel, 'degenerate_redraws': int(degenerate)})
        # numerical gate tied to the margin of the claim, not to an arbitrary tolerance
        ok &= worst * (1 + 10 * dt_rel) <= 1
    # sharpness: R0 -> 0, perturbation on |k|=1 mode
    ns = NS2D(16, nu, 0.0); x = ns.tg * 1e-6 / ns.norm(ns.tg)
    e = np.zeros_like(x); i1 = np.argwhere((ns.K[0] == 0) & (ns.K[1] == 1))[0]
    e[0, i1[0], i1[1]] = 1; e[0, (-i1[0]) % 16, (-i1[1]) % 16] = 1; e = ns.project(e) * ns.mask; e *= 1e-7 / ns.norm(e)
    ts, P = ns.run(np.array([x, x + e]), 30.0, h, every=20)
    R0 = float(max(ns.norm(x), ns.norm(x + e))); L = Lam(ns, ts, R0, 0.0)
    ratio = (ns.norm(P[:, 1] - P[:, 0]) / ns.norm(e) / L)[1:]
    _, Ph = ns.run(np.array([x, x + e]), 30.0, h / 2, every=40)
    sharp_dt = float(np.max(np.abs(ns.norm(Ph[:, 1] - Ph[:, 0]) - ns.norm(P[:, 1] - P[:, 0])) / ns.norm(Ph[:, 1] - Ph[:, 0])))
    sharp = {'dt_halving_rel': sharp_dt, 'margin': float(1 - ratio.max()), 'min_ratio': float(ratio.min()), 'final_ratio': float(ratio[-1]), 't': ts.tolist(), 'actual_over_initial': (ns.norm(P[:, 1] - P[:, 0]) / ns.norm(e)).tolist(), 'Lambda': L.tolist()}
    ok &= ratio.max() * (1 + 10 * sharp_dt) <= 1
    # sensitivity: overclaim with rate 2nu
    over = (ns.norm(P[:, 1] - P[:, 0]) / ns.norm(e) / (np.exp(-2 * nu * ts) * L / np.exp(-nu * ts)))[1:]
    detected = bool(over.max() > 1.01)
    # GATE at prior paper parameters
    nsp = NS2D(16, 0.025, 0.05); fnorm = float(nsp.norm(nsp.f)); rng = np.random.default_rng(SEEDS[0])
    p, _ = nsp.shell_field(rng, 3, 4.5, 0.012); u0 = nsp.tg + p; R0p = float(nsp.norm(u0))
    rate_lower = -nsp.nu + nsp.sqrtK2 * min(R0p, fnorm / nsp.nu)
    v0 = u0 + 1e-6 * p / nsp.norm(p)
    ts2, Q = nsp.run(np.array([u0, v0]), 2.0, 0.04, every=5)
    sep = nsp.norm(Q[:, 1] - Q[:, 0]); slope = float(np.polyfit(ts2, np.log(sep), 1)[0])
    gate = {'nu': 0.025, 'forcing_norm': fnorm, 'R0': R0p, '|f|/nu': fnorm / 0.025, 'S': nsp.sqrtK2,
            'certificate_exponent_rate_at_least': rate_lower, 'certificate_available': rate_lower < 0,
            'measured_finite_window_slope': slope}
    out['sharpness'] = sharp; out['prior_regime_gate'] = gate
    return result('A09', 'R39', 'lock (gated: energy ball / small Grashof)',
                  'Galerkin NS: W1(Phi_t#mu,Phi_t#nu) <= Lambda(t) W1(mu,nu) for every declaration on the ball; certificate absent at prior parameters',
                  bool(ok and not gate['certificate_available']), SEEDS, out,
                  sensitivity={'mutation': 'overclaim contraction rate 2nu', 'detected': detected},
                  refutes=['A negative finite-window separation slope certifies contraction/forgetting (prior: slope<0 at nu=0.025, certificate rate > 0)'],
                  boundary='Lock holds in the dissipative gate; the forced prior regime is outside every certificate route of this ladder (R46 open).')
