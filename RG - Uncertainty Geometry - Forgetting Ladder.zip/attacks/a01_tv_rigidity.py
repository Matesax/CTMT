"""A01 / R33  TV rigidity under bijections.
Target: for a bijection C, TV(C^n#mu, C^n#nu) = TV(mu, nu) for every n.
Attack: exact integer pushforwards under the discrete cat map on Z_N^2, random
laws (4 seeds), all n up to the period.  Refutes the naive claim
'chaotic (hyperbolic, mixing) dynamics forgets declarations in TV'.
Sensitivity: replace the bijection by a non-injective map; the test must fire."""
import numpy as np
from ug_core import cat_perm, push, tv_int, SEEDS
from attacks.common import result

def period(perm):
    p = perm.copy(); idx = np.arange(len(perm)); n = 1
    while not np.array_equal(p, idx):
        p = perm[p]; n += 1
    return n

def check(perm, mu, nu, nmax):
    t0 = tv_int(mu, nu); bad = []
    a, b = mu.copy(), nu.copy()
    for n in range(1, nmax + 1):
        a, b = push(a, perm), push(b, perm)
        t = tv_int(a, b)
        if t != t0: bad.append((n, t)); break
    return t0, bad

def run():
    N = 64; perm = cat_perm(N); per = period(perm)
    assert len(np.unique(perm)) == N * N
    wit = {'N': N, 'period': per, 'cases': []}
    ok = True
    for s in SEEDS:
        rng = np.random.default_rng(s)
        for kind in ['dirichlet', 'block']:
            if kind == 'dirichlet':
                mu = rng.integers(0, 50, N * N); nu = rng.integers(0, 50, N * N)
                # equalize totals exactly
                d = int(mu.sum() - nu.sum()); nu[0] += max(d, 0); mu[0] += max(-d, 0)
            else:
                mu = np.zeros(N * N, np.int64); nu = np.zeros(N * N, np.int64)
                m = mu.reshape(N, N); m[:8, :8] = 1; v = nu.reshape(N, N); v[8:16, :8] = 1
            t0, bad = check(perm, mu, nu, per)
            wit['cases'].append({'seed': s, 'law': kind, 'TV0': t0, 'violations': bad})
            ok &= not bad
    # sensitivity: non-injective map (x,y)->(2x, y)
    x, y = np.meshgrid(np.arange(N), np.arange(N), indexing='ij')
    bad_perm = (((2 * x) % N) * N + y).ravel()
    rng = np.random.default_rng(SEEDS[0])
    mu = rng.integers(0, 50, N * N); nu = rng.integers(0, 50, N * N); d = int(mu.sum() - nu.sum()); nu[0] += max(d, 0); mu[0] += max(-d, 0)
    _, bad = check(bad_perm, mu, nu, 5)
    return result('A01', 'R33', 'no-go', 'TV between pushforwards is invariant under every bijection (invertible chaos never forgets in TV)',
                  ok, SEEDS, wit, sensitivity={'mutation': 'non-injective (x,y)->(2x,y)', 'detected': bool(bad), 'first_change': bad},
                  refutes=['Hyperbolic/mixing invertible dynamics forgets the input declaration in TV',
                           'Galerkin NS / Sabra full-state laws can lose declaration information in TV (both are ODE flows, hence bijections)'])
