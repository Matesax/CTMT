"""A07 / R36 + R47  Floating-point declarations are atomic; diameter is blind to common-mode error.
Target 1 (prior 'tent coalescence is a finite-precision artefact'): sharpen.  The float
   tent map is EXACT (2x and 2-2x are exact binary operations, Sterbenz); the collapse
   is not rounding.  Floats are dyadic rationals, eventually fixed under T: the
   sampled law is atomic, i.e. outside every BV declaration (R36).
Target 2 (R47 accuracy gate): a vanishing declaration diameter does not certify the
   target law: both float ensembles agree (diameter 0) and both are at TV distance 1
   from the true pushforward."""
import numpy as np
from fractions import Fraction
from ug_core import SEEDS
from attacks.common import result

def tent(x): return np.where(x < 0.5, 2 * x, 2 - 2 * x)

def run():
    wit = []; ok = True
    for s in SEEDS:
        rng = np.random.default_rng(s)
        A = rng.uniform(size=200000); B = rng.beta(2, 5, size=200000)
        # exactness: compare float orbit to exact rational orbit on 200 points
        pts = A[:200].copy(); fr = [Fraction(float(p)) for p in pts]; exact_match = True
        for n in range(70):
            pts = tent(pts); fr = [2 * q if q < Fraction(1, 2) else 2 - 2 * q for q in fr]
            exact_match &= all(Fraction(float(p)) == q for p, q in zip(pts, fr))
        a, b = A.copy(), B.copy(); collapse = None
        for n in range(1, 80):
            a, b = tent(a), tent(b)
            if collapse is None and np.all(a == 0) and np.all(b == 0): collapse = n
        bins = np.linspace(0, 1, 65)
        ha = np.histogram(a, bins)[0] / len(a); hb = np.histogram(b, bins)[0] / len(b)
        diam = 0.5 * np.abs(ha - hb).sum(); to_truth = 0.5 * np.abs(ha - 1 / 64).sum()
        wit.append({'seed': s, 'float_equals_exact_orbit_70_steps': bool(exact_match), 'all_zero_at_n': collapse,
                    'empirical_diameter_n79': float(diam), 'TV_to_true_pushforward_64bins': float(to_truth)})
        ok &= exact_match and collapse is not None and diam == 0 and to_truth > 0.98
    return result('A07', 'R36,R47', 'no-go + gate', 'Float orbit sampling of the tent map is exact arithmetic on an atomic declaration; zero diameter coexists with TV~1 error',
                  ok, SEEDS, wit, sensitivity={'mutation': 'claim float tent orbits approximate Lebesgue after collapse', 'detected': ok},
                  refutes=['Stress paper: tent late zeros are a rounding artefact (they are exact; the declaration is atomic)',
                           'Small declaration diameter certifies the forecast target (common-mode error is invisible to D)'])
