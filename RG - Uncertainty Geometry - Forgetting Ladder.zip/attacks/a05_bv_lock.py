"""A05 / R38  THE MIXING LOCK (tent map, BV declaration), sharpened.
Target: for densities f,g in BV[0,1]:
     TV(T^n#f, T^n#g) <= 2^{-(n+2)} Var(f-g)     for all n >= 0,
and the constant is attained (equality) for every n.
Proof chain under attack, each link tested separately and exactly:
  (L1) Var(P h) <= Var(h)/2                         (Lasota-Yorke, linear branches)
  (L2) zero-mean h:  ||h||_1 <= Var(h)/2            (sharpened from ||h||_1 <= Var h)
  (L3) TV = ||.||_1 / 2 ;  P preserves the mean.
Attack: exact rationals on dyadic level 10; random, sparse, spiky, oscillating,
monotone declarations (4 seeds); adversarial hill-climb on the ratio
TV/bound, re-verified in exact arithmetic.  Sensitivity: an overclaimed
constant 2^{-(n+3)} must be refuted by the battery's own witness."""
from fractions import Fraction
import numpy as np
from ug_core import tent_P_step, tent_P_float, variation, tv_step, normalize_exact, SEEDS
from attacks.common import result

L = 10; M = 2 ** L

def families(rng):
    out = {}
    out['random'] = rng.integers(1, 100, M)
    sp = np.ones(M, np.int64); sp[rng.integers(0, M, 5)] += rng.integers(100, 2000, 5); out['spiky'] = sp
    out['sparse'] = (rng.uniform(size=M) < 0.05).astype(np.int64) * rng.integers(1, 50, M) + (rng.uniform(size=M) < 1e-9)
    if out['sparse'].sum() == 0: out['sparse'][0] = 1
    out['monotone'] = np.sort(rng.integers(0, 1000, M))
    osc = 500 + (rng.integers(1, 400) * np.sign(np.sin(2 * np.pi * rng.integers(1, 64) * (np.arange(M) + .5) / M))).astype(np.int64)
    out['oscillating'] = np.maximum(osc, 0)
    return {k: normalize_exact(v) for k, v in out.items()}

def check_pair(f, g, nmax=L + 1):
    h = [a - b for a, b in zip(f, g)]; V0 = variation(h); rows = []; ok = True
    a, b = f, g
    for n in range(nmax + 1):
        t = tv_step(a, b); bound = V0 / 2 ** (n + 2)
        hn = [x - y for x, y in zip(a, b)]; Vn = variation(hn); l1 = sum(abs(x) for x in hn) / M
        link1 = True if n == 0 else Vn <= Vprev / 2
        link2 = l1 <= Vn / 2
        ok &= (t <= bound) and link1 and link2
        rows.append((n, t, bound, link1, link2)); Vprev = Vn
        a, b = tent_P_step(a), tent_P_step(b)
    return ok, rows, V0

def hill_climb(rng, n, iters=3000):
    f = rng.uniform(0.1, 2, M); g = rng.uniform(0.1, 2, M)
    def ratio(f, g):
        f = f / f.mean(); g = g / g.mean(); h = f - g; V = np.abs(np.diff(h)).sum()
        a, b = f, g
        for _ in range(n): a, b = tent_P_float(a), tent_P_float(b)
        return 0.5 * np.abs(a - b).mean() / (V / 2 ** (n + 2))
    best = ratio(f, g)
    for _ in range(iters):
        f2, g2 = f.copy(), g.copy()
        if rng.uniform() < 0.5:
            i = rng.integers(0, M); w = rng.integers(1, 64); f2[i:i + w] *= rng.uniform(0, 3)
        else:
            i = rng.integers(0, M); w = rng.integers(1, 64); g2[i:i + w] *= rng.uniform(0, 3)
        f2 = np.maximum(f2, 1e-6); g2 = np.maximum(g2, 1e-6)
        r = ratio(f2, g2)
        if r > best: best, f, g = r, f2, g2
    # exact re-verification of the best candidate (rationalised)
    fi = np.round(f / f.min() * 1000).astype(np.int64); gi = np.round(g / g.min() * 1000).astype(np.int64)
    fe, ge = normalize_exact(fi), normalize_exact(gi)
    ok, rows, _ = check_pair(fe, ge, nmax=n)
    return float(best), ok, float(rows[n][1] / rows[n][2]) if rows[n][2] else 0.0

def run():
    wit = {'pairs': [], 'hill_climb': [], 'equality_witness': []}; ok = True; maxratio = 0.0
    for s in SEEDS:
        rng = np.random.default_rng(s); fam = families(rng); keys = list(fam)
        for i in range(len(keys)):
            for j in range(i + 1, len(keys)):
                good, rows, V0 = check_pair(fam[keys[i]], fam[keys[j]])
                ok &= good
                r = max((float(t / b) for (_, t, b, _, _) in rows if b > 0), default=0)
                maxratio = max(maxratio, r)
                wit['pairs'].append({'seed': s, 'pair': f'{keys[i]}|{keys[j]}', 'Var(f-g)': float(V0), 'max_TV/bound': r,
                                     'TV_n': [float(t) for (_, t, _, _, _) in rows[:8]]})
        for n in [1, 3, 6]:
            hb, hok, hex_ = hill_climb(np.random.default_rng(s + n), n)
            ok &= hok; maxratio = max(maxratio, hex_)
            wit['hill_climb'].append({'seed': s, 'n': n, 'best_float_ratio': hb, 'exact_ratio': hex_, 'exact_bound_holds': hok})
    # equality witness: f = 2^{n+1} 1[0,2^{-n-1}], g = 1  ->  TV_n = bound_n exactly
    ones = [Fraction(1)] * M; eq = True
    for n in range(0, L):
        f = [Fraction(2 ** (n + 1)) if i < M // 2 ** (n + 1) else Fraction(0) for i in range(M)]
        a = f
        for _ in range(n): a = tent_P_step(a)
        t = tv_step(a, ones); b = variation([x - 1 for x in f]) / 2 ** (n + 2)
        wit['equality_witness'].append({'n': n, 'TV': t, 'bound': b}); eq &= (t == b)
    # sensitivity: overclaim 2^{-(n+3)}
    detected = any(Fraction(w['TV']['fraction']) > Fraction(w['bound']['fraction']) / 2 if isinstance(w['TV'], dict) else w['TV'] > w['bound'] / 2 for w in wit['equality_witness'])
    wit['max_ratio_found'] = maxratio
    return result('A05', 'R38', 'lock (gated: BV declaration)', 'Tent map: TV(T^n#f,T^n#g) <= 2^-(n+2) Var(f-g), attained for every n',
                  ok and eq, SEEDS, wit, sensitivity={'mutation': 'overclaim constant 2^-(n+3)', 'detected': bool(detected)},
                  boundary='Rate requires Var(f-g)<inf. Concentrating declarations (A04) have unbounded Var and are exactly where uniformity fails.')
