"""A03 / R34 + R35  Forgetting is fibre migration; finite invertible states recur.
R34 target: for a bijection C and observation O,
      TV(O#C^n#mu, O#C^n#nu) == TV((O o C^n)#mu, (O o C^n)#nu)   (pulled-back observation at time 0)
   and the kernel pair of O o C^n is (C^n x C^n)^{-1} R_O: |fibres| unchanged, fibres moved.
R35 target: on a finite state space a bijection is periodic, so the observed
   declaration distance returns EXACTLY to its initial value at the period.
   'Observed forgetting' of a finite invertible computation is always temporary.
Attack: exact integers, block observation 8x8 cells on Z_64^2, 4 seeds."""
import numpy as np
from ug_core import cat_perm, push, tv_int, block_obs, SEEDS
from attacks.a01_tv_rigidity import period
from attacks.common import result

def run():
    N, B = 64, 8; perm = cat_perm(N); per = period(perm)
    wit = {'N': N, 'block': B, 'period': per, 'cases': []}; ok = True
    for s in SEEDS:
        rng = np.random.default_rng(s)
        mu = np.zeros(N * N, np.int64); nu = np.zeros(N * N, np.int64)
        # two declarations differing only INSIDE coarse cells is invisible at t=0; use visible difference
        i0, j0 = rng.integers(0, N // B, 2)
        i1, j1 = (i0 + 1 + rng.integers(0, N // B - 1)) % (N // B), j0
        mu.reshape(N, N)[i0*B:(i0+1)*B, j0*B:(j0+1)*B] = 1
        nu.reshape(N, N)[i1*B:(i1+1)*B, j1*B:(j1+1)*B] = 1
        a, b = mu.copy(), nu.copy(); Cn = np.arange(N * N)
        Dobs = []; ident = True
        for n in range(per + 1):
            if n:
                a, b = push(a, perm), push(b, perm); Cn = perm[Cn]
            d = tv_int(block_obs(a, N, B), block_obs(b, N, B))
            # pulled-back observation O o C^n at time 0
            lab = (Cn // N // B) * (N // B) + (Cn % N) // B
            pa = np.bincount(lab, weights=mu, minlength=(N // B) ** 2).astype(np.int64)
            pb = np.bincount(lab, weights=nu, minlength=(N // B) ** 2).astype(np.int64)
            ident &= (tv_int(pa, pb) == d)
            Dobs.append(d)
        rec = Dobs[per] == Dobs[0]
        wit['cases'].append({'seed': s, 'D_obs_0': Dobs[0], 'D_obs_min': min(Dobs), 'argmin': int(np.argmin([float(x) for x in Dobs])),
                             'D_obs_at_period': Dobs[per], 'identity_R34_all_n': bool(ident), 'recurrence_R35': bool(rec),
                             'trace': [float(x) for x in Dobs]})
        ok &= ident and rec
    # sensitivity: if the identity is tested with the WRONG pull-back (O o C^{n+1}) it must fail somewhere
    rng = np.random.default_rng(SEEDS[0]); mu = rng.integers(0, 9, N*N); nu = rng.integers(0, 9, N*N)
    d = int(mu.sum()-nu.sum()); nu[0] += max(d,0); mu[0] += max(-d,0)
    a = push(mu, perm); b = push(nu, perm); C2 = perm[perm]
    lab = (C2 // N // B) * (N // B) + (C2 % N) // B
    pa = np.bincount(lab, weights=mu, minlength=(N//B)**2).astype(np.int64); pb = np.bincount(lab, weights=nu, minlength=(N//B)**2).astype(np.int64)
    detected = tv_int(pa, pb) != tv_int(block_obs(a, N, B), block_obs(b, N, B))
    return result('A03', 'R34,R35', 'forced + no-go', 'Observed forgetting = migration of the declaration difference into fibres of O o C^n; finite bijective computations recur exactly',
                  ok, SEEDS, wit, sensitivity={'mutation': 'pull back with C^{n+1} instead of C^n', 'detected': bool(detected)},
                  refutes=['A finite-precision / finite-lattice deterministic invertible computation can certify permanent forgetting'])
