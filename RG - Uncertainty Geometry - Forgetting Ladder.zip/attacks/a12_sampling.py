"""A12 / R43  Samples refute; operators lock.
(a) Target (lock, imported DKW-Massart): for bounded scalar outputs the simultaneous
    W1 certificate covers at >= 1-alpha.  Also recomputes the prior constants
    (eps_m = 0.670984, m >= 2162).
(b) Target (no-go): TV-equivalence is NOT certifiable from finite samples without a
    regularity declaration.  Le Cam construction: P uniform on M cells, Q_S uniform on a
    random half S.  TV(P,Q_S)=1/2, yet any test based on m draws has power <= alpha + 1.5 m^2/M.
(c) Prior claim attacked (Stress Sec.5): 'chaotic logistic TV ranges 0.00877 -> 0.04160 from
    8 to 512 bins' is a scale effect.  Attack: the SAME-LAW null of the plug-in TV grows like
    sqrt(B/N); with the population value certified < 5e-18 (A06), the reported curve is the
    estimator's noise floor."""
import numpy as np
from scipy.stats import beta, ks_2samp
from ug_core import SEEDS
from attacks.common import result

def splitmix(x):
    with np.errstate(over='ignore'):
        z = (x + np.uint64(0x9E3779B97F4A7C15))
        z = (z ^ (z >> np.uint64(30))) * np.uint64(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> np.uint64(27))) * np.uint64(0x94D049BB133111EB)
        return z ^ (z >> np.uint64(31))

def plug_tv(x, y, B):
    e = np.linspace(0, 1, B + 1); return 0.5 * np.abs(np.histogram(x, e)[0] / len(x) - np.histogram(y, e)[0] / len(y)).sum()

def run():
    out = []
    # (a)
    m, alpha, laws = 12, 0.05, [beta(2, 5), beta(5, 2), beta(1, 1), beta(2, 2)]
    K = len(laws); eps = np.sqrt(np.log(2 * K / alpha) / (2 * m)); cov = []
    grid = np.linspace(0, 1, 4001)
    for s in SEEDS:
        rng = np.random.default_rng(s); hit = 0; R = 4000
        for _ in range(R):
            good = True
            for L in laws:
                x = np.sort(L.rvs(m, random_state=rng)); Fe = np.searchsorted(x, grid, side='right') / m
                if np.abs(Fe - L.cdf(grid)).max() > eps: good = False; break
            hit += good
        cov.append(hit / R)
    Kp = 4 * 11 * 4; ap = 0.05 / 7; epsp = np.sqrt(np.log(2 * Kp / ap) / (2 * 12)); mreq = int(np.ceil(np.log(2 * Kp / ap) / (2 * 0.05 ** 2)))
    out.append(result('A12a', 'R43 (imported)', 'lock (imported DKW)', 'Simultaneous DKW/W1 certificate covers at >= 1-alpha; prior constants reproduce',
                      bool(min(cov) >= 1 - alpha and abs(epsp - 0.670984) < 1e-6 and mreq == 2162), SEEDS,
                      {'m': m, 'K': K, 'eps': float(eps), 'simultaneous_coverage_by_seed': cov, 'prior_eps_recomputed': float(epsp), 'prior_m_required': mreq},
                      sensitivity={'mutation': 'drop the union bound (use log(2/alpha))', 'detected': None}))
    # sensitivity (a): without union bound coverage should drop below 1-alpha
    eps1 = np.sqrt(np.log(2 / alpha) / (2 * m)); rng = np.random.default_rng(SEEDS[0]); hit = 0
    for _ in range(4000):
        good = True
        for L in laws:
            x = np.sort(L.rvs(m, random_state=rng)); Fe = np.searchsorted(x, grid, side='right') / m
            if np.abs(Fe - L.cdf(grid)).max() > eps1: good = False; break
        hit += good
    out[-1]['sensitivity']['detected'] = bool(hit / 4000 < 1 - alpha); out[-1]['sensitivity']['coverage_without_union'] = hit / 4000
    # (b)
    Mcells = np.uint64(2 ** 40); msz = 500; reps = 600; rows = []
    for s in SEEDS:
        rng = np.random.default_rng(s); salt = np.uint64(rng.integers(1, 2 ** 62))
        def drawQ(n):
            res = np.empty(0, np.uint64)
            while len(res) < n:
                c = rng.integers(0, 2 ** 40, 4 * n, dtype=np.uint64); keep = (splitmix(c ^ salt) & np.uint64(1)) == 1
                res = np.concatenate([res, c[keep]])
            return res[:n]
        H0, H1 = [], []
        for _ in range(reps):
            ref = rng.integers(0, 2 ** 40, msz, dtype=np.uint64) / float(Mcells)
            xP = rng.integers(0, 2 ** 40, msz, dtype=np.uint64) / float(Mcells)
            xQ = drawQ(msz) / float(Mcells)
            H0.append(plug_tv(xP, ref, 32)); H1.append(plug_tv(xQ, ref, 32))
        thr = np.quantile(H0, 0.95); power = float(np.mean(np.array(H1) > thr))
        rows.append({'seed': s, 'power_at_level_0.05': power, 'KS_p_H0_vs_H1': float(ks_2samp(H0, H1).pvalue),
                     'LeCam_power_cap': 0.05 + 1.5 * msz ** 2 / 2 ** 40, 'TV(P,Q_S)': 0.5})
    okb = all(r['power_at_level_0.05'] < 0.12 for r in rows)
    out.append(result('A12b', 'R43', 'no-go', 'No finite-sample procedure certifies TV-equivalence without a regularity declaration (Le Cam two-point/mixture)',
                      okb, SEEDS, rows, sensitivity={'mutation': 'coarse cells M=64 (regular class)', 'detected': None}))
    # sensitivity (b): with M=64 (TV=1/2 now resolvable at m=500), the same test must have high power
    rng = np.random.default_rng(SEEDS[0]); S = rng.permutation(64)[:32]; H0, H1 = [], []
    for _ in range(300):
        ref = rng.uniform(size=msz); xP = rng.uniform(size=msz); xQ = (rng.choice(S, msz) + rng.uniform(size=msz)) / 64
        H0.append(plug_tv(xP, ref, 64)); H1.append(plug_tv(xQ, ref, 64))
    out[-1]['sensitivity']['detected'] = bool(np.mean(np.array(H1) > np.quantile(H0, .95)) > .9)
    # (c)
    bins = [8, 16, 32, 64, 128, 256, 512]; table = {}
    rng = np.random.default_rng(SEEDS[0]); arc = lambda n: np.sin(np.pi * rng.uniform(size=n) / 2) ** 2
    for N in [10000, 20000, 50000, 100000, 200000]:
        vals = []
        for B in bins:
            v = [max(plug_tv(a, b, B), plug_tv(a, c, B), plug_tv(b, c, B)) for a, b, c in ((arc(N), arc(N), arc(N)) for _ in range(12))]
            vals.append(float(np.mean(v)))
        table[N] = vals
    prior = (0.00877, 0.04160)
    fit = min(table, key=lambda N: (np.log(table[N][0] / prior[0])) ** 2 + (np.log(table[N][-1] / prior[1])) ** 2)
    out.append(result('A12c', 'P-Stress Sec.5', 'prior-claim', 'Prior TV growth 0.00877 -> 0.04160 (8 -> 512 bins) is a property of the propagated laws',
                      False, SEEDS, {'same_law_null_max_of_3_pairs': {str(k): v for k, v in table.items()}, 'bins': bins,
                                     'best_matching_N_per_ensemble': fit, 'prior_reported': prior, 'certified_population_TV_n60': '< 4.5e-18 (A06)'},
                      boundary='Prior script and N were not supplied; the fit is an inference. Whatever N was, the population value is certified < 4.5e-18, so any reported value is noise.'))
    return out
