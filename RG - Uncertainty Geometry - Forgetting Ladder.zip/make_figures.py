"""Figures from results/ug_results.json (plus exact recomputation for Fig. 1)."""
import json, sys, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from fractions import Fraction
from ug_core import tent_P_step, tv_step, variation, normalize_exact
R = {x['id']: x for x in json.load(open('results/ug_results.json'))['results']}
plt.rcParams.update({'font.size': 9})
# Fig 1: mixing lock (exact) + no-uniform counterexample
fig, ax = plt.subplots(1, 2, figsize=(10, 3.6)); L = 10; M = 2 ** L; ones = [Fraction(1)] * M
rng = np.random.default_rng(20261010)
for lab, f in [('random BV pair', normalize_exact(rng.integers(1, 100, M))), ('spiky pair', normalize_exact(np.r_[np.ones(M - 8, int), [3000] * 8]))]:
    g = normalize_exact(rng.integers(1, 100, M)); V = variation([a - b for a, b in zip(f, g)]); tv, bd = [], []
    a, b = f, g
    for n in range(L): tv.append(float(tv_step(a, b))); bd.append(float(V / 2 ** (n + 2))); a, b = tent_P_step(a), tent_P_step(b)
    ax[0].semilogy(range(L), tv, 'o-', ms=3, label=f'{lab}: exact TV'); ax[0].semilogy(range(L), bd, '--', label=f'{lab}: bound $2^{{-(n+2)}}$Var')
eq = R['A05']['witness']['equality_witness']; ax[0].semilogy([w['n'] for w in eq], [w['TV']['float'] for w in eq], 'k*', ms=7, label='equality witness (TV = bound)')
ax[0].text(0.3, 2e-5, 'level-10 step laws: TV = 0 exactly at n = 10', fontsize=7); ax[0].set_ylim(1e-5, 1e3); ax[0].set(xlabel='n', ylabel='TV between propagated declarations', title='R38: mixing lock on a BV declaration (exact rationals)'); ax[0].legend(fontsize=6)
for k in [4, 8, 12, 14]:
    n = np.arange(0, k + 1); ax[1].plot(n, 1 - 2.0 ** (n - k), 'o-', ms=3, label=f'$f_k=2^k1_{{[0,2^{{-k}}]}}$, k={k}')
ax[1].axhline(1, color='k', lw=.5); ax[1].set(xlabel='n', ylabel='TV$(P^nf_k,1)$', title='R36: no uniform forgetting over all a.c. laws'); ax[1].legend(fontsize=7)
fig.tight_layout(); fig.savefig('figures/fig1_mixing_lock.png', dpi=180); plt.close(fig)
# Fig 2: cat lattice: full-state TV rigid, observed TV migrates and recurs
fig, ax = plt.subplots(1, 2, figsize=(10, 3.4)); w = R['A03']['witness']
for c in w['cases']: ax[0].plot(c['trace'], lw=1, label=f"seed {c['seed']}")
ax[0].axhline(1.0, color='k', ls='--', lw=.8, label='full-state TV (constant, R33)'); ax[0].axvline(w['period'], color='r', ls=':', label=f"period {w['period']}")
ax[0].set(xlabel='n', ylabel='TV of 8x8-block observation', title='R34/R35: forgetting = fibre migration, then exact recurrence'); ax[0].legend(fontsize=6)
t = R['A08']['witness']['exit_table']; ax[1].semilogx([r['K'] for r in t], [r['exit_time'] for r in t], 'o-', label='exact exit time n*(K)')
ax[1].semilogx([r['K'] for r in t], [r['log(K)/log(lambda)'] + 2 for r in t], '--', label='log K / log $\\lambda$ + 2')
ax[1].set(xlabel='observed window K', ylabel='steps', title='R42: weak forgetting frontier is scale-bound'); ax[1].legend(fontsize=7)
fig.tight_layout(); fig.savefig('figures/fig2_fibre_migration.png', dpi=180); plt.close(fig)
# Fig 3: NS contraction lock
s = R['A09']['witness']['sharpness']; fig, ax = plt.subplots(1, 1, figsize=(5.2, 3.4))
ax.semilogy(s['t'], s['Lambda'], 'k--', label='certified $\\Lambda(t)$'); ax.semilogy(s['t'], s['actual_over_initial'], 'C0', label='sharp pair (|k|=1)')
ax.set(xlabel='t', ylabel='separation / initial', title='R39: Galerkin NS contraction lock (dissipative gate)'); ax.legend(fontsize=7)
fig.tight_layout(); fig.savefig('figures/fig3_ns_contraction.png', dpi=180); plt.close(fig)
# Fig 4: noise floor
c = R['A12c']['witness']; fig, ax = plt.subplots(1, 1, figsize=(5.2, 3.4))
for N, v in c['same_law_null_max_of_3_pairs'].items(): ax.loglog(c['bins'], v, '-', lw=1, label=f'same-law null, N={N}')
ax.loglog([8, 512], c['prior_reported'], 'ks', label='prior reported (8, 512 bins)')
ax.set(xlabel='bins', ylabel='plug-in TV', title='Prior "scale sweep" = estimator noise floor'); ax.legend(fontsize=6)
fig.tight_layout(); fig.savefig('figures/fig4_noise_floor.png', dpi=180); plt.close(fig)
print('figures ok')
