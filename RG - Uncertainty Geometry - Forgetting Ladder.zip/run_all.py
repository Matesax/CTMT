"""Run the full hostile battery.  Usage:  python run_all.py  [--out results]
Every attack returns: id, rung, kind, target, outcome (SURVIVED|BROKEN), seeds, witness,
sensitivity (mutation that MUST be detected -> proves the test can fail), refutes, boundary.
A ladder rung is accepted only if outcome==SURVIVED AND sensitivity.detected is True."""
import json, sys, time, hashlib, platform, os, importlib
import numpy as np, scipy
OUT = sys.argv[sys.argv.index('--out') + 1] if '--out' in sys.argv else 'results'
MODS = ['a01_tv_rigidity', 'a02_ns_invertible', 'a03_fibre_migration', 'a04_no_uniform', 'a05_bv_lock',
        'a06_logistic_transport', 'a07_float_atomic', 'a08_cat_weak', 'a09_ns_contraction', 'a10_dobrushin',
        'a11_functional_type', 'a12_sampling', 'a13_fold', 'a14_canary_audit', 'a15_provenance']

def main():
    os.makedirs(OUT, exist_ok=True); allres = []; t0 = time.time()
    for m in MODS:
        t = time.time(); r = importlib.import_module('attacks.' + m).run()
        r = r if isinstance(r, list) else [r]
        for x in r:
            x['runtime_s'] = round(time.time() - t, 2); allres.append(x)
            sens = x.get('sensitivity') or {}
            print(f"{x['id']:5s} {x['rung']:22s} {x['outcome']:9s} sens={sens.get('detected')}  {x['target'][:90]}", flush=True)
    ladder_ok = [x for x in allres if x['kind'] not in ('prior-claim', 'audit')]
    summary = {'ladder_rungs_tested': len(ladder_ok),
               'ladder_rungs_survived_with_sensitivity': sum(x['outcome'] == 'SURVIVED' and (x['sensitivity'] or {}).get('detected') is True for x in ladder_ok),
               'prior_claims_or_audits_tested': len(allres) - len(ladder_ok),
               'prior_claims_broken': [x['id'] for x in allres if x['kind'] in ('prior-claim', 'audit') and x['outcome'] == 'BROKEN'],
               'runtime_s': round(time.time() - t0, 1)}
    env = {'python': platform.python_version(), 'numpy': np.__version__, 'scipy': scipy.__version__, 'platform': platform.platform()}
    src = {f: hashlib.sha256(open(f, 'rb').read()).hexdigest() for f in ['ug_core.py', 'run_all.py'] + ['attacks/' + m + '.py' for m in MODS] + ['attacks/common.py']}
    json.dump({'summary': summary, 'environment': env, 'source_sha256': src, 'results': allres}, open(f'{OUT}/ug_results.json', 'w'), indent=1)
    print(json.dumps(summary, indent=1))
if __name__ == '__main__': main()
