import json, numpy as np
from ns_uncertainty_battery import NS,modes,build_inputs,state_from,OUT
from pathlib import Path
p=Path(OUT); r=json.load(open(p/'ns_results.json')); audit={}
for d,n in [(2,32),(3,24)]:
 ns=NS(d,n);base,dirs,coeff=build_inputs(d,8)
 us=[state_from(ns,base,dirs,c) for c in coeff]
 per=[ns.diag(u)['nonlinear_energy'] for u in us]
 low=ns.k2<=4
 derivative=np.linalg.norm((ns.rhs(us[1])-ns.rhs(us[0]))*low)
 small=NS(d,18);large=NS(d,36);dic=modes(d,np.random.default_rng(12),5,1)
 a=small.nonlinear(small.embed(dic));b=large.nonlinear(large.embed(dic));err=0.;norm=0.
 for idx in np.ndindex(*([18]*d)):
  k=tuple(int(small.K[j][idx]) for j in range(d))
  if not small.mask[idx]:continue
  aa=a[(slice(None),)+idx];bb=b[(slice(None),)+tuple(x%36 for x in k)]
  err+=np.linalg.norm(aa-bb)**2;norm+=np.linalg.norm(bb)**2
 audit[str(d)+'D']={'initial_member_max_nonlinear_energy_defect':float(max(per)),'low_mode_rhs_difference':float(derivative),'padded_nonlinear_reference_relative':float(np.sqrt(err/norm))}
assert all(a['initial_member_max_nonlinear_energy_defect']<1e-10 and a['padded_nonlinear_reference_relative']<1e-10 for a in audit.values())
r['secondary_audit']=audit
json.dump(r,open(p/'ns_results.json','w'),indent=2)
print(json.dumps(audit,indent=2))
