# Executed uncertainty-transport audit

This is a low-resolution finite Fourier-Galerkin pilot, not a high-Re turbulent DNS validation.

## Reproduction
Dependencies: Python, NumPy, SciPy, Matplotlib. Default output directory in the battery is `/mnt/data`; change OUT for another environment. Create that directory before execution.

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python ns_uncertainty_battery.py
python ns_secondary_check.py
pdflatex NS_Uncertainty_Audit.tex
```

The battery uses trusted local pickle checkpoints. The package deliberately excludes pickle checkpoints. A fresh run recomputes all configurations. If execution is interrupted, completed configurations can be resumed. Do not load untrusted pickle files.

## Evidence
- Six PDE configurations, four families, eight independent members per family, one primary physical seed.
- Sabra rung: pair sensitivity and conservation controls only, not an uncertainty ensemble.
- Nine canaries, four control seeds. Some guards repeat deterministic tests.
- Initial dealias stimulus missed four mutations. The retained initial report documents this. Final near-cutoff stimulus catches them without changing thresholds.
- ns_trajectories.npz contains scalar observations, not full velocity fields.
- MC slope is conditional empirical resampling, not an independent PDE ensemble-size sweep.
- Secondary check validates padded nonlinear convolution and initial per-member energy transfer.

## Verdict
Numerical pilot gates pass; targeted canaries pass after repair; coarse-state factorization fails in finite-model witnesses. Statistical equivalence, mixing, asymptotic PDE chaos, and turbulent DNS remain unlocked. Full RG atlas/holonomy and global rank certification are not executed.
