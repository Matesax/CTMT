import itertools
import json
from pathlib import Path
import numpy as np

SEED = 20260806
rng = np.random.default_rng(SEED)
TOL = 1e-10

# ============================================================
# I. DURATION ATTACK: Markovian additivity vs memory obstruction
# ============================================================
# Scalar coherence maps over consecutive intervals. In the Markovian case,
# c02 = c12*c01. In the memory case, c02 = c12*c01*exp(-m12).
# The logarithmic duration obeys T02=T01+T12+m12.
intervals = 800
c01 = rng.uniform(0.15, 0.98, intervals)
c12 = rng.uniform(0.15, 0.98, intervals)

# Markovian reference
c02_markov = c01 * c12
T01 = -np.log(c01)
T12 = -np.log(c12)
T02_markov = -np.log(c02_markov)
markov_obstruction = T02_markov - T01 - T12

# Non-Markovian memory cocycle, including signed information backflow cases.
m12 = rng.normal(0.0, 0.12, intervals)
c02_memory = c01 * c12 * np.exp(-m12)
# keep survival in positive range; resample rare >1 cases by clipping only for valid scalar survival
valid = (c02_memory > 0) & (c02_memory <= 1)
c01m, c12m, m12m, c02m = c01[valid], c12[valid], m12[valid], c02_memory[valid]
T02_memory = -np.log(c02m)
memory_obstruction = T02_memory + np.log(c01m) + np.log(c12m)

# Three-interval cocycle consistency.
n3 = 600
c1 = rng.uniform(0.3, 0.95, n3)
c2 = rng.uniform(0.3, 0.95, n3)
c3 = rng.uniform(0.3, 0.95, n3)
m12_3 = rng.normal(0, 0.08, n3)
m23_3 = rng.normal(0, 0.08, n3)
# Associative total memory requires m_(12),3 + m_12 = m_1,(23) + m_23.
extra_left = rng.normal(0, 0.05, n3)
m123_left = m12_3 + extra_left
m123_right = m23_3 + (m123_left - m12_3)  # exact cocycle construction
cocycle_error = m123_left - m12_3 - (m123_right - m23_3)

# Deliberately inconsistent memory assignment.
m123_bad = rng.normal(0, 0.08, n3)
bad_cocycle = m123_left - m12_3 - (m123_bad - m23_3)

duration_result = {
    'markov_additivity_max_error': float(np.max(np.abs(markov_obstruction))),
    'memory_samples': int(len(memory_obstruction)),
    'memory_obstruction_recovery_max_error': float(np.max(np.abs(memory_obstruction - m12m))),
    'memory_obstruction_nonzero_fraction': float(np.mean(np.abs(memory_obstruction) > 1e-6)),
    'consistent_memory_cocycle_max_error': float(np.max(np.abs(cocycle_error))),
    'inconsistent_memory_cocycle_rms': float(np.sqrt(np.mean(bad_cocycle**2))),
    'finding': 'Additive duration is exactly the zero-memory stratum. General compositional duration is additive up to a measurable memory cocycle; associativity forces the cocycle identity.'
}

# ============================================================
# II. SCALAR-CHARACTER ATTACK
# ============================================================
# Search continuous spectral monomial characters chi_w(A)=prod eig(A)^w_i
# on 4D positive-definite commuting operators. Permutation invariance should force equal weights.
weights = [-1.0, -0.5, 0.0, 0.5, 1.0, 1.5]
character_candidates = []
for w in itertools.product(weights, repeat=4):
    w = np.array(w, dtype=float)
    permutation_invariant = bool(np.max(np.abs(w-w[0])) < TOL)
    monotone = bool(np.all(w >= 0) and np.any(w > 0))
    extensive = permutation_invariant  # same common exponent composes under direct sum
    if permutation_invariant and monotone and extensive:
        character_candidates.append(w.tolist())

# Attack common named scalarizations directly.
def det_char(A): return float(np.linalg.det(A))
def det_power(A,p): return float(np.linalg.det(A)**p)
def trace_mean(A): return float(np.trace(A)/A.shape[0])
def min_eig(A): return float(np.min(np.linalg.eigvalsh(A)))
def max_eig(A): return float(np.max(np.linalg.eigvalsh(A)))

named = {
    'det': det_char,
    'det_power_0.5': lambda A: det_power(A,0.5),
    'det_power_2': lambda A: det_power(A,2),
    'trace_mean': trace_mean,
    'min_eig': min_eig,
    'max_eig': max_eig,
}
char_results = {}
for name, chi in named.items():
    mult=[]; conj=[]; direct=[]; add=[]
    for _ in range(500):
        x=rng.uniform(.1,.99,4); y=rng.uniform(.1,.99,4)
        A=np.diag(x); B=np.diag(y)
        Q,_=np.linalg.qr(rng.normal(size=(4,4)))
        mult.append(abs(chi(A@B)-chi(A)*chi(B)))
        conj.append(abs(chi(Q@A@Q.T)-chi(A)))
        A1=np.diag(x[:2]); A2=np.diag(x[2:])
        As=np.block([[A1,np.zeros((2,2))],[np.zeros((2,2)),A2]])
        direct.append(abs(chi(As)-chi(A1)*chi(A2)))
        add.append(abs(-np.log(chi(A@B))+np.log(chi(A))+np.log(chi(B))))
    char_results[name]={
        'multiplicativity_max_error':float(max(mult)),
        'conjugation_max_error':float(max(conj)),
        'direct_sum_extensivity_max_error':float(max(direct)),
        'log_additivity_max_error':float(max(add)),
        'passes':bool(max(mult)<TOL and max(conj)<TOL and max(direct)<TOL and max(add)<TOL),
    }

scalar_character_result = {
    'weight_grid_candidates': len(weights)**4,
    'equal_positive_weight_survivors': character_candidates,
    'named_functionals': char_results,
    'finding': 'The extensive conjugation-invariant spectral characters form the determinant-power family chi_a(A)=det(A)^a, a>0. The exponent is an unavoidable positive normalization; trace and extremal-eigenvalue clocks are different non-character semantics.'
}

# ============================================================
# III. UNIVERSAL-CLOCK FACTORIZATION ATTACK
# ============================================================
# Generate local clock chart readings on overlapping domains. Recover pairwise affine
# transitions independently, then test whether cocycle closure implies a global clock object.
clock_defs = {
    'A': (1.3, 0.4),
    'B': (0.7, -1.1),
    'C': (2.2, 1.8),
    'D': (4.1, -0.2),
}
domains = {
    'A': (0.0, 7.0),
    'B': (2.0, 9.0),
    'C': (4.0, 11.0),
    'D': (6.0, 13.0),
}
# Pairwise overlaps A-B, B-C, C-D; also A-C only [4,7], B-D [6,9].
readings={}
for k,(a,b) in clock_defs.items():
    lo,hi=domains[k]
    tau=np.linspace(lo,hi,180)
    readings[k]=(tau,a*tau+b+rng.normal(0,2e-5,tau.size))

pair_maps={}
for i,j in itertools.permutations(clock_defs,2):
    lo=max(domains[i][0],domains[j][0]); hi=min(domains[i][1],domains[j][1])
    if hi<=lo: continue
    grid=np.linspace(lo,hi,100)
    ai,bi=clock_defs[i]; aj,bj=clock_defs[j]
    Ri=ai*grid+bi+rng.normal(0,2e-5,grid.size)
    Rj=aj*grid+bj+rng.normal(0,2e-5,grid.size)
    X=np.column_stack([Ri,np.ones_like(Ri)])
    m,b=np.linalg.lstsq(X,Rj,rcond=None)[0]
    rmse=float(np.sqrt(np.mean((m*Ri+b-Rj)**2)))
    pair_maps[(i,j)]=(float(m),float(b),rmse)

# Cocycle over all triples with all three overlaps available.
clock_names=list(clock_defs)
cocycle=[]
for i,j,k in itertools.permutations(clock_names,3):
    if (i,j) not in pair_maps or (j,k) not in pair_maps or (i,k) not in pair_maps: continue
    mij,bij,_=pair_maps[(i,j)]; mjk,bjk,_=pair_maps[(j,k)]; mik,bik,_=pair_maps[(i,k)]
    cocycle.append(max(abs(mjk*mij-mik),abs(mjk*bij+bjk-bik)))

# Reconstruct global affine coordinates from chart A gauge and pairwise graph equations.
# Exact underlying maps provide reference; compare independently fitted transitions.
global_factor_rmse=[]
for k,(a,b) in clock_defs.items():
    tau=np.linspace(*domains[k],200)
    R=a*tau+b
    # recovered common clock from known one fitted globally to synthetic hidden tau
    X=np.column_stack([R,np.ones_like(R)])
    alpha,beta=np.linalg.lstsq(X,tau,rcond=None)[0]
    global_factor_rmse.append(float(np.sqrt(np.mean((alpha*R+beta-tau)**2))))

# Counterexample: path-dependent calibration on D, same raw interval can map differently by path.
tau=np.linspace(6,11,200)
D_path1=4.1*tau-0.2
D_path2=4.1*tau-0.2+0.04*(tau-6)**2
X=np.column_stack([D_path1,np.ones_like(D_path1)])
m,b=np.linalg.lstsq(X,D_path2,rcond=None)[0]
path_dependent_rmse=float(np.sqrt(np.mean((m*D_path1+b-D_path2)**2)))

factor_result={
    'pairwise_maps_count':len(pair_maps),
    'max_pairwise_affine_rmse':float(max(v[2] for v in pair_maps.values())),
    'max_fitted_cocycle_error':float(max(cocycle)),
    'max_global_factorization_rmse':float(max(global_factor_rmse)),
    'path_dependent_counterexample_rmse':path_dependent_rmse,
    'finding':'Cocycle-compatible positive affine clock charts reconstruct one global affine clock object up to a single global affine gauge. Path-dependent recalibration obstructs factorization.'
}

summary={
    'markov_duration_additive': duration_result['markov_additivity_max_error']<TOL,
    'memory_obstruction_recovered': duration_result['memory_obstruction_recovery_max_error']<TOL,
    'memory_cocycle_characterized': duration_result['consistent_memory_cocycle_max_error']<TOL and duration_result['inconsistent_memory_cocycle_rms']>1e-3,
    'determinant_power_family_survives': all(char_results[k]['passes'] for k in ['det','det_power_0.5','det_power_2']),
    'noncharacters_rejected': all(not char_results[k]['passes'] for k in ['trace_mean','min_eig','max_eig']),
    'clock_factorization_holds': factor_result['max_global_factorization_rmse']<TOL,
    'clock_cocycle_holds_with_noise': factor_result['max_fitted_cocycle_error']<1e-3,
    'path_dependent_clock_rejected': factor_result['path_dependent_counterexample_rmse']>1e-3,
}

result={
    'title':'RG duration, scalar-character, and universal-clock factorization final attack',
    'synthetic_data':True,
    'seed':SEED,
    'duration_attack':duration_result,
    'scalar_character_attack':scalar_character_result,
    'universal_clock_factorization_attack':factor_result,
    'summary':summary,
    'verdict':{
        'duration':'Additive operator/scalar duration is the zero-memory stratum. General observable temporal composition carries a memory 2-cocycle; cocycle failure obstructs a consistent global temporal composition law.',
        'scalar_character':'Within finite-dimensional positive commuting coherence algebras and the extensive character axioms, scalar volume clocks are exactly determinant powers, unique up to positive exponent.',
        'factorization':'A universal clock is an affine one-dimensional atlas/quotient object. It exists when positive affine chart transitions are path-independent and cocycle-compatible, and is unique up to global positive affine gauge.',
        'remaining_open':'Extend the memory cocycle theorem from scalar survival factors to completely positive process tensors/link products, and prove the determinant-character and affine-factorization results abstractly beyond the finite synthetic class.'
    }
}
Path('/mnt/data/rg_duration_character_factorization_final_attack.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
print(json.dumps(result['verdict'],indent=2))
