import json
from pathlib import Path
import numpy as np

SEED = 20260806
rng = np.random.default_rng(SEED)
EPS = 1e-10

# Synthetic falsification battery. Units c=1. Reference observable model: Minkowski metric (-,+,+,+).
eta = np.diag([-1.0, 1.0, 1.0, 1.0])

# -----------------------------------------------------------------------------
# Level 1: clock existence -- additive parameter and compositional evolution.
# -----------------------------------------------------------------------------
t_pairs = rng.uniform(0.01, 4.0, size=(1200, 2))
kappa = 0.73
clock_candidates = {
    "proper_time": lambda t: t,
    "scaled_time": lambda t: 2.4*t,
    "quadratic": lambda t: t*t,
    "sqrt": lambda t: np.sqrt(t),
    "log1p": lambda t: np.log1p(t),
}
level1 = {}
for name, f in clock_candidates.items():
    errs = np.abs(f(t_pairs[:,0]+t_pairs[:,1])-f(t_pairs[:,0])-f(t_pairs[:,1]))
    level1[name] = {"max_additivity_error": float(errs.max()), "passes": bool(errs.max() < EPS)}
semigroup_err = np.max(np.abs(np.exp(-kappa*(t_pairs[:,0]+t_pairs[:,1])) - np.exp(-kappa*t_pairs[:,0])*np.exp(-kappa*t_pairs[:,1])))
level1["coherence_semigroup"] = {"max_composition_error": float(semigroup_err), "passes": bool(semigroup_err < EPS)}

# -----------------------------------------------------------------------------
# Level 2 and 4: universality after one affine calibration, across mechanisms.
# -----------------------------------------------------------------------------
tau_train = np.linspace(0, 8, 80)
tau_test = np.linspace(0.05, 9.95, 160)
mechanisms = {
    "atomic_A": (1.0000, 0.12, 2e-4),
    "atomic_B": (0.9994, -0.31, 3e-4),
    "oscillator": (3.70, 1.20, 8e-4),
    "particle_decay_logclock": (0.42, -0.20, 1.2e-3),
}
level2_4 = {}
for name, (a,b,sigma) in mechanisms.items():
    y_train = a*tau_train+b+rng.normal(0,sigma,size=tau_train.size)
    A = np.column_stack([y_train, np.ones_like(y_train)])
    alpha,beta = np.linalg.lstsq(A,tau_train,rcond=None)[0]
    y_test = a*tau_test+b+rng.normal(0,sigma,size=tau_test.size)
    pred = alpha*y_test+beta
    rmse = float(np.sqrt(np.mean((pred-tau_test)**2)))
    level2_4[name] = {"calibration_alpha":float(alpha),"calibration_beta":float(beta),"heldout_rmse":rmse,"passes":bool(rmse<0.01)}
# Deliberately nonuniversal mechanism: nonlinear drift cannot be removed by affine calibration.
y_train = tau_train + 0.025*tau_train**2
A = np.column_stack([y_train,np.ones_like(y_train)])
alpha,beta=np.linalg.lstsq(A,tau_train,rcond=None)[0]
y_test=tau_test+0.025*tau_test**2
rmse=float(np.sqrt(np.mean((alpha*y_test+beta-tau_test)**2)))
level2_4["nonlinear_drift_counterexample"]={"heldout_rmse":rmse,"passes":bool(rmse<0.01)}

# -----------------------------------------------------------------------------
# Level 3: path dependence -- same endpoints in coordinate time, different worldlines.
# Inertial rest path tau=T. Out-and-back constant speed path tau=T sqrt(1-v^2).
# -----------------------------------------------------------------------------
Tvals=np.array([2.0,5.0,10.0,20.0])
velocities=np.array([0.2,0.5,0.8])
path_rows=[]
max_formula_error=0.0
for T in Tvals:
    for v in velocities:
        tau_rest=T
        tau_travel=T*np.sqrt(1-v*v)
        # numerical integral with piecewise velocity magnitude v
        dt=T/20000
        tau_num=np.sum(np.full(20000,dt*np.sqrt(1-v*v)))
        err=abs(tau_num-tau_travel); max_formula_error=max(max_formula_error,err)
        path_rows.append({"T":float(T),"v":float(v),"tau_rest":float(tau_rest),"tau_travel":float(tau_travel),"difference":float(tau_rest-tau_travel)})
level3={"max_numerical_vs_analytic_error":float(max_formula_error),"all_nonzero_path_differences":bool(all(r["difference"]>0 for r in path_rows)),"passes":bool(max_formula_error<1e-10 and all(r["difference"]>0 for r in path_rows)),"examples":path_rows}

# -----------------------------------------------------------------------------
# Level 5: metric reconstruction from observed interval data.
# ds2 = dx^T g dx. Recover 10 independent symmetric coefficients.
# -----------------------------------------------------------------------------
N=4000
X=rng.normal(size=(N,4))
# Ensure broad temporal/spatial span.
def design(dx):
    t,x,y,z=dx.T
    return np.column_stack([t*t,x*x,y*y,z*z,2*t*x,2*t*y,2*t*z,2*x*y,2*x*z,2*y*z])
D=design(X)
gtrue=np.array([-1,1,1,1,0,0,0,0,0,0],float)
ds2=D@gtrue
noise=rng.normal(0,2e-4,size=N)
ghat=np.linalg.lstsq(D,ds2+noise,rcond=None)[0]
Ghat=np.array([[ghat[0],ghat[4],ghat[5],ghat[6]],[ghat[4],ghat[1],ghat[7],ghat[8]],[ghat[5],ghat[7],ghat[2],ghat[9]],[ghat[6],ghat[8],ghat[9],ghat[3]]])
eigs=np.linalg.eigvalsh(Ghat)
signature=(int(np.sum(eigs<0)),int(np.sum(eigs>0)),int(np.sum(np.abs(eigs)<=1e-8)))
metric_relerr=float(np.linalg.norm(Ghat-eta)/np.linalg.norm(eta))
level5={"samples":N,"relative_metric_error":metric_relerr,"reconstructed_eigenvalues":eigs.tolist(),"signature_negative_positive_zero":list(signature),"passes":bool(metric_relerr<1e-4 and signature==(1,3,0))}

# -----------------------------------------------------------------------------
# Level 6: causal compatibility -- sign of interval vs reachability and proper time.
# -----------------------------------------------------------------------------
M=5000
DX=rng.normal(size=(M,4))
interval=np.einsum('ni,ij,nj->n',DX,eta,DX)
causal_metric=interval<=0
# Independent propagation predicate in c=1 units: |spatial displacement| <= |dt|.
causal_signal=np.linalg.norm(DX[:,1:],axis=1)<=np.abs(DX[:,0])
agreement=float(np.mean(causal_metric==causal_signal))
timelike=interval<0
proper=np.sqrt(np.maximum(0,-interval))
level6={"samples":M,"causal_agreement":agreement,"timelike_positive_proper_time":bool(np.all(proper[timelike]>0)),"spacelike_zero_proper_time_under_real_timelike_clock":bool(np.all(proper[~timelike]==0)),"passes":bool(agreement==1.0)}

# -----------------------------------------------------------------------------
# Countermodels of time dimensionality: identical complete declared observations.
# Model A: 4D Lorentzian events.
# Model B: 6D hidden product, observations project to first 4 coordinates.
# Model C: redundant 5D gauge embedding with q=t+x+y+z, projected back.
# Model D: finite relational table storing only coincidence, interval, causal and clock data.
# -----------------------------------------------------------------------------
E=120
coords4=rng.normal(size=(E,4))
hidden=rng.normal(size=(E,2))
coords6=np.column_stack([coords4,hidden])
q=np.sum(coords4,axis=1,keepdims=True)
coords5=np.column_stack([coords4,q])
# all pairwise declared observable summaries
def obs_from_4(c):
    diff=c[:,None,:]-c[None,:,:]
    s2=np.einsum('...i,ij,...j->...',diff,eta,diff)
    causal=s2<=0
    clock=np.sqrt(np.maximum(0,-s2))
    coincidence=np.linalg.norm(diff,axis=-1)<1e-12
    return s2,causal,clock,coincidence
obs4=obs_from_4(coords4)
obs6=obs_from_4(coords6[:,:4])
obs5=obs_from_4(coords5[:,:4])
# relational model is defined to be the same complete finite observable table.
obsrel=tuple(np.array(x,copy=True) for x in obs4)

def maxdiff(A,B):
    return max(float(np.max(np.abs(a.astype(float)-b.astype(float)))) for a,b in zip(A,B))
counter={
 "4D_vs_6D_hidden_product_max_observable_difference":maxdiff(obs4,obs6),
 "4D_vs_5D_redundant_gauge_max_observable_difference":maxdiff(obs4,obs5),
 "4D_vs_relational_table_max_observable_difference":maxdiff(obs4,obsrel),
 "latent_dimensions":[4,6,5,"non-manifold finite relation"],
 "observable_metric_rank":int(np.linalg.matrix_rank(eta)),
 "all_indistinguishable_under_declared_experiment":bool(maxdiff(obs4,obs6)<EPS and maxdiff(obs4,obs5)<EPS and maxdiff(obs4,obsrel)<EPS),
}

# Enlarge experiment with hidden-coordinate sensor: separates 6D model, demonstrating relativity to experiment.
hidden_observable_variance=float(np.var(coords6[:,4:]))
counter["enlarged_experiment_separates_hidden_extension"] = bool(hidden_observable_variance>1e-6)

summary={
 "level1_clock_existence": bool(level1['proper_time']['passes'] and level1['coherence_semigroup']['passes'] and not level1['quadratic']['passes']),
 "level2_clock_universality": bool(all(level2_4[k]['passes'] for k in mechanisms)),
 "level3_path_dependence": level3['passes'],
 "level4_cross_mechanism_universality": bool(all(level2_4[k]['passes'] for k in mechanisms) and not level2_4['nonlinear_drift_counterexample']['passes']),
 "level5_metric_reconstruction": level5['passes'],
 "level6_causal_compatibility": level6['passes'],
 "dimension_countermodel": counter['all_indistinguishable_under_declared_experiment'],
}

result={
 "title":"RG six-level clock and spacetime-dimensionality attack",
 "synthetic_data":True,
 "seed":SEED,
 "units":"c=1",
 "level1":level1,
 "level2_and_4":level2_4,
 "level3":level3,
 "level5":level5,
 "level6":level6,
 "dimension_countermodels":counter,
 "summary":summary,
 "verdict":{
   "clock_geometry":"All six positive levels pass in the synthetic Lorentzian reference model; the nonlinear drift control fails universality as intended.",
   "dimensionality":"The declared clock/causal/interval experiment reconstructs observable rank four and Lorentzian signature, but cannot identify latent dimension or manifold ontology: exact 4D, 5D redundant, 6D hidden-product, and finite relational realizations are observationally identical.",
   "falsifiable_boundary":"An enlarged experiment that observes a hidden coordinate separates the 6D extension; non-identifiability is relative to the declared experiment, not absolute.",
   "nonclaim":"This synthetic battery does not validate RG coherence time against physical clocks or real gravitational/velocity clock data."
 }
}
Path('/mnt/data/rg_time_dimension_attack.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
print(json.dumps(result['verdict'],indent=2))
