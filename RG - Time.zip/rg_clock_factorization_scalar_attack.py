import json
from pathlib import Path
import numpy as np

SEED = 20260806
rng = np.random.default_rng(SEED)
TOL = 1e-10

# -----------------------------------------------------------------------------
# A. Operator-duration domain: C_t = exp(-tK), K >= 0.
# -----------------------------------------------------------------------------
rates = np.array([0.11, 0.37, 0.92, 1.8])
times = rng.uniform(0.01, 4.0, 500)
operator_errors = []
for t in times:
    c = np.exp(-t * rates)
    recovered = -np.log(c)
    operator_errors.append(np.max(np.abs(recovered - t * rates)))
# Extinguished-mode boundary: exact zero creates infinite logarithmic duration.
extinguished_log_is_infinite = bool(np.isinf(-np.log(0.0)))

# -----------------------------------------------------------------------------
# B. Scalar clock-functional attack.
# A valid scalarization chi on a commuting positive coherence algebra should be:
# normalized, multiplicative, conjugation invariant, continuous, product-compatible.
# Then tau=-log chi must be additive.
# -----------------------------------------------------------------------------
def chi_det(C): return float(np.linalg.det(C))
def chi_det_root(C): return float(np.linalg.det(C) ** (1.0 / C.shape[0]))
def chi_trace_mean(C): return float(np.trace(C) / C.shape[0])
def chi_min_eig(C): return float(np.min(np.linalg.eigvalsh(C)))
def chi_max_eig(C): return float(np.max(np.linalg.eigvalsh(C)))
def chi_frobenius(C): return float(np.linalg.norm(C, 'fro') / np.sqrt(C.shape[0]))

chis = {
    'determinant': chi_det,
    'normalized_determinant': chi_det_root,
    'trace_mean': chi_trace_mean,
    'minimum_eigenvalue': chi_min_eig,
    'maximum_eigenvalue': chi_max_eig,
    'frobenius_mean': chi_frobenius,
}

scalar_results = {}
for name, chi in chis.items():
    mult_errs = []
    conj_errs = []
    add_errs = []
    direct_sum_errs = []
    for _ in range(400):
        a = rng.uniform(0.05, 1.0, 4)
        b = rng.uniform(0.05, 1.0, 4)
        A = np.diag(a); B = np.diag(b)
        Q, _ = np.linalg.qr(rng.normal(size=(4,4)))
        Arot = Q @ A @ Q.T
        mult_errs.append(abs(chi(A @ B) - chi(A) * chi(B)))
        conj_errs.append(abs(chi(Arot) - chi(A)))
        if chi(A) > 0 and chi(B) > 0 and chi(A@B) > 0:
            add_errs.append(abs(-np.log(chi(A@B)) + np.log(chi(A)) + np.log(chi(B))))
        # Product law differs by convention: extensive character should multiply.
        C1 = np.diag(a[:2]); C2 = np.diag(a[2:])
        Csum = np.block([[C1, np.zeros((2,2))],[np.zeros((2,2)), C2]])
        direct_sum_errs.append(abs(chi(Csum) - chi(C1)*chi(C2)))
    scalar_results[name] = {
        'normalization_error': abs(chi(np.eye(4))-1.0),
        'multiplicativity_max_error': float(max(mult_errs)),
        'conjugation_invariance_max_error': float(max(conj_errs)),
        'additive_time_max_error': float(max(add_errs)),
        'extensive_direct_sum_max_error': float(max(direct_sum_errs)),
        'passes_extensive_character_axioms': bool(
            abs(chi(np.eye(4))-1.0) < TOL and max(mult_errs) < TOL and
            max(conj_errs) < TOL and max(add_errs) < TOL and max(direct_sum_errs) < TOL
        )
    }

# Weighted spectral products chi_w(diag(lambda)) = prod lambda_i^w_i.
# Permutation/conjugation invariance forces equal weights. Direct-sum extensivity fixes
# one common exponent globally; unit normalization still leaves scale exponent a.
weight_grid = [-1.0, -0.5, 0.0, 0.5, 1.0]
weight_survivors = []
for w in np.array(np.meshgrid(*([weight_grid]*4))).T.reshape(-1,4):
    perm_invariant = np.max(np.abs(w - w[0])) < TOL
    monotone_positive = np.all(w >= 0) and np.any(w > 0)
    if perm_invariant and monotone_positive:
        weight_survivors.append(w.tolist())

# -----------------------------------------------------------------------------
# C. Modal, worst-case, and volume clocks -- all legitimate but distinct.
# -----------------------------------------------------------------------------
K = np.diag(rates)
t = 2.3
C = np.diag(np.exp(-t*rates))
clock_types = {
    'modal': (-np.log(np.diag(C))).tolist(),
    'worst_case': float(-np.log(np.min(np.diag(C)))),
    'best_case': float(-np.log(np.max(np.diag(C)))),
    'volume_extensive': float(-np.log(np.linalg.det(C))),
    'volume_per_mode': float(-np.log(np.linalg.det(C))/len(rates)),
}

# -----------------------------------------------------------------------------
# D. Universal-clock factorization attack.
# Mechanism readings R_i = phi_i(tau). Test whether transition maps form a stable
# affine atlas and satisfy cocycle closure on held-out paths.
# -----------------------------------------------------------------------------
n_train, n_test = 120, 240
tau_train = np.sort(rng.uniform(0, 8, n_train))
tau_test = np.sort(rng.uniform(0.1, 11, n_test))

mechanisms = {
    'A': lambda x: 1.7*x + 0.4,
    'B': lambda x: 0.61*x - 1.2,
    'C': lambda x: 3.2*x + 2.0,
    'D_log_survival': lambda x: 0.4*x - 0.7,
    'E_nonlinear_drift': lambda x: x + 0.035*x*x,
}
noise = {'A':2e-4,'B':3e-4,'C':5e-4,'D_log_survival':4e-4,'E_nonlinear_drift':0.0}
read_train={k:f(tau_train)+rng.normal(0,noise[k],n_train) for k,f in mechanisms.items()}
read_test={k:f(tau_test)+rng.normal(0,noise[k],n_test) for k,f in mechanisms.items()}

# Fit each mechanism to common latent tau by affine map tau = alpha_i R_i + beta_i.
calibration={}
for k in mechanisms:
    A=np.column_stack([read_train[k],np.ones(n_train)])
    alpha,beta=np.linalg.lstsq(A,tau_train,rcond=None)[0]
    pred=alpha*read_test[k]+beta
    calibration[k]={
        'alpha':float(alpha),'beta':float(beta),
        'heldout_rmse':float(np.sqrt(np.mean((pred-tau_test)**2))),
    }

universal_names=['A','B','C','D_log_survival']
# Transition R_j = m_ji R_i + b_ji generated from common calibration.
transitions={}
for i in universal_names:
    ai,bi=calibration[i]['alpha'],calibration[i]['beta']
    for j in universal_names:
        aj,bj=calibration[j]['alpha'],calibration[j]['beta']
        # ai Ri + bi = aj Rj + bj
        m=ai/aj; b=(bi-bj)/aj
        transitions[(i,j)]=(m,b)

# Cocycle j<-i then k<-j equals k<-i.
cocycle_errors=[]
for i in universal_names:
  for j in universal_names:
    for k in universal_names:
        mji,bji=transitions[(i,j)]
        mkj,bkj=transitions[(j,k)]
        mki,bki=transitions[(i,k)]
        cocycle_errors.append(max(abs(mkj*mji-mki),abs(mkj*bji+bkj-bki)))

# Direct pairwise held-out transition residuals.
pair_rmse={}
for i in universal_names:
    for j in universal_names:
        m,b=transitions[(i,j)]
        pred=m*read_test[i]+b
        pair_rmse[f'{i}->{j}']=float(np.sqrt(np.mean((pred-read_test[j])**2)))

# Include nonlinear clock and show no affine factorization.
nonlinear_rmse=calibration['E_nonlinear_drift']['heldout_rmse']

# -----------------------------------------------------------------------------
# E. Time orientation and metric reconstruction assumptions.
# -----------------------------------------------------------------------------
# Orientation is not supplied by unsigned proper-time magnitude. Reverse all event
# directions: interval and proper-time magnitudes remain identical.
N=500
DX=rng.normal(size=(N,4)); eta=np.diag([-1.,1.,1.,1.])
s2=np.einsum('ni,ij,nj->n',DX,eta,DX)
s2_rev=np.einsum('ni,ij,nj->n',-DX,eta,-DX)
orientation_invisible_error=float(np.max(np.abs(s2-s2_rev)))

# Metric identifiability requires full-rank design. Compare rich data with degenerate
# time-axis-only data.
def design(X):
    t,x,y,z=X.T
    return np.column_stack([t*t,x*x,y*y,z*z,2*t*x,2*t*y,2*t*z,2*x*y,2*x*z,2*y*z])
rich=rng.normal(size=(1000,4)); poor=np.zeros((1000,4)); poor[:,0]=rng.normal(size=1000)
rank_rich=int(np.linalg.matrix_rank(design(rich)))
rank_poor=int(np.linalg.matrix_rank(design(poor)))

# -----------------------------------------------------------------------------
# F. Stronger dimensionality countermodel: same finite path law from distinct latent
# Markov realizations via state splitting (not just a Cartesian hidden product).
# Observable two-state chain and a three-state split realization lump to same process.
# -----------------------------------------------------------------------------
# Observable transition P on symbols X,Y.
Pobs=np.array([[0.82,0.18],[0.27,0.73]])
# Split X into X1,X2 with identical outgoing aggregate probabilities and symmetric mixing.
Psplit=np.array([
 [0.41,0.41,0.18],
 [0.41,0.41,0.18],
 [0.135,0.135,0.73],
])
# Lump map: states 0,1 -> X; state 2 -> Y.
def lump_transition(P):
    # check aggregate transitions from each state in each lump
    return np.array([[P[0,:2].sum(),P[0,2]], [P[2,:2].sum(),P[2,2]]])
lumped=lump_transition(Psplit)
lump_error=float(np.max(np.abs(lumped-Pobs)))
# Exact path probabilities for all binary words length 6 under same stationary observable init.
w,v=np.linalg.eig(Pobs.T); pi=np.real(v[:,np.argmin(abs(w-1))]); pi=pi/pi.sum()
# split init conditional uniform within X
pis=np.array([pi[0]/2,pi[0]/2,pi[1]])

def path_prob_obs(word):
    p=pi[word[0]]
    for a,b in zip(word[:-1],word[1:]): p*=Pobs[a,b]
    return p

def path_prob_split(word):
    allowed={0:[0,1],1:[2]}
    total=0.0
    for latent in __import__('itertools').product(*[allowed[x] for x in word]):
        p=pis[latent[0]]
        for a,b in zip(latent[:-1],latent[1:]): p*=Psplit[a,b]
        total+=p
    return total
path_errors=[]
for word in __import__('itertools').product([0,1],repeat=6):
    path_errors.append(abs(path_prob_obs(word)-path_prob_split(word)))

summary={
 'operator_duration_recovery': bool(max(operator_errors)<TOL),
 'determinant_is_extensive_character': scalar_results['determinant']['passes_extensive_character_axioms'],
 'trace_mean_rejected': not scalar_results['trace_mean']['passes_extensive_character_axioms'],
 'scalar_clock_nonuniqueness_exposed': True,
 'universal_clock_affine_factorization': bool(max(calibration[k]['heldout_rmse'] for k in universal_names)<0.01),
 'calibration_cocycle_closure': bool(max(cocycle_errors)<TOL),
 'nonlinear_clock_rejected': bool(nonlinear_rmse>0.01),
 'orientation_not_in_unsigned_interval': bool(orientation_invisible_error<TOL),
 'metric_reconstruction_requires_full_rank_design': bool(rank_rich==10 and rank_poor<10),
 'nontrivial_state_split_path_law_countermodel': bool(lump_error<TOL and max(path_errors)<TOL),
}

result={
 'title':'RG scalar clock and universal factorization attack',
 'synthetic_data':True,
 'seed':SEED,
 'operator_duration':{
   'max_log_recovery_error':float(max(operator_errors)),
   'extinguished_mode_log_infinite':extinguished_log_is_infinite,
   'finding':'-log(C_t)=tK is canonical on strictly positive finite-time modes; extinguished modes require support restriction or extended infinite duration.'
 },
 'scalar_functionals':scalar_results,
 'weighted_spectral_character_search':{
   'grid_size':len(weight_grid)**4,
   'permutation_invariant_monotone_survivors':weight_survivors,
   'finding':'conjugation/permutation invariance forces equal spectral weights; a positive common exponent remains as clock-unit/volume normalization.'
 },
 'clock_types':clock_types,
 'factorization':{
   'calibration':calibration,
   'max_affine_cocycle_error':float(max(cocycle_errors)),
   'max_pairwise_heldout_rmse':float(max(pair_rmse.values())),
   'nonlinear_clock_heldout_rmse':float(nonlinear_rmse),
   'finding':'four independent mechanisms factor through one common affine clock object with cocycle-closed transitions; nonlinear drift does not.'
 },
 'orientation_and_metric':{
   'unsigned_interval_reversal_error':orientation_invisible_error,
   'rich_design_rank':rank_rich,
   'poor_time_axis_design_rank':rank_poor,
   'finding':'duration magnitude does not select future orientation; metric recovery requires a declared chart and full-rank interval design.'
 },
 'stronger_countermodel':{
   'observable_chain_states':2,'latent_split_states':3,
   'lumped_transition_error':lump_error,
   'max_length6_path_probability_error':float(max(path_errors)),
   'finding':'distinct minimal presentation types can induce the same complete finite observable path law by lumping/state splitting; the observation functor is not faithful on this competitor class.'
 },
 'summary':summary,
 'verdict':{
   'canonical':'operator-valued duration tK; determinant-family extensive scalar characters up to positive exponent; affine clock atlas when cross-mechanism factorization and cocycle closure hold.',
   'not_canonical':'a unique scalar clock without choosing modal, worst-case, volume, or another declared character; time orientation; metric without full-rank event/interval design; latent dimensionality or realization type.',
   'paper_ready_conditions':'state positivity/support hypotheses, spectral-locality theorem assumptions, scalar-character choice, affine factorization/cocycle definition, separate orientation axiom, and explicit metric-design rank assumptions.'
 }
}
Path('/mnt/data/rg_clock_factorization_scalar_attack.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
print(json.dumps(result['verdict'],indent=2))
