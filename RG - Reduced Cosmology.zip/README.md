# Reduced Cosmology in Resolution Geometry: The H0 Unit Hole, the Dark Room and Declaration-Carried Locks

An application companion with no physical claim. Paper: `RG - Reduced Cosmology.pdf` (source
`RG_Reduced_Cosmology.tex`). The programme's main print and README are in `Resolution Geometry.pdf` and `README.md`.

| File | What it is |
|---|---|
| `rg_cosmology.py` | the library: exact rational flat LCDM, curved LCDM contrasts with a rational replay, the interval cover for wCDM and CPL, leaf replay, high-precision forward evaluation, the continuation pair, the dark room, the gluing toy, dimensional typing |
| `rg_units.py` | unit tools (Fisher kernels), shared with the dimensional-closure companion |
| `fixture/records.json` | the frozen record: E(z) at seven redshifts, bound 0.0015, synthetic (flat CPL, m = 0.31, w0 = −0.9, wa = 0.28) |
| `rg_cosmology_battery.py` | groups KA–KI; writes `rg_cosmology_battery_results.json` |
| `rg_cosmology_battery_mutations.py` | nineteen one-line falsifications; each must fail its target group |

```
pip install -r requirements.txt            # numpy, scipy, mpmath, sympy
python3 -I rg_cosmology_battery.py          # about 9 s; byte-identical on rerun
python3 -I rg_cosmology_battery_mutations.py --jobs 2
```

Verdicts, each with a certificate:
- **Units.** E(z) leaves the H0 unit hole; radial BAO with a luminosity proxy leaves the anchor direction (1, −1, 1); anchors close both.
- **Status grammar.** A kept cell is not a member: a corner rule reports an interval on a certified-empty family at 75 of 200 bounds.
- **Exclusions with critical margins.** Flat ΛCDM 18.38×, curved ΛCDM with calibration 7.09×, wCDM 2.86× the declared bound.
- **CPL lock.** E(3) is LOCKED_CONDITIONAL in two boxes but NOT_FORCED once the continuation after the last record is free (two members with identical records, E(3) apart by ≥ 0.226). The lock is carried by the declaration.
- **The dark room.** Every dust fraction below 0.3545 reproduces E(z) exactly (non-phantom: below 0.3230), so expansion records cannot decide dark matter (Kunz's dark degeneracy).
- **One World as a joint fibre.** A clock, BAO and a luminosity proxy glue; a conflicting clock empties the joint fibre (toy).

Author: Matěj Rada, MatejRada@email.cz. License: CC BY-NC-ND 4.0.
