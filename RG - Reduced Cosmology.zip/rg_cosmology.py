#!/usr/bin/env python3
"""Resolution Geometry - reduced cosmology as computation (late-time flat or curved FLRW background, no perturbations).

Records are values of the dimensionless expansion function E(z) = H(z)/H0 with an absolute bound eps. Every verdict is
typed:
  EXCLUDED              a complete cover of the declared box in which every leaf is separated from the records
  FEASIBLE              a point verified against every record (exact rationals or interval arithmetic)
  LOCKED_CONDITIONAL    a verified point and an outer task enclosure of diameter <= tolerance
  NOT_FORCED            two verified members whose task values differ by more than the tolerance
  UNDECIDED             none of the above at the declared depth
  OUTSIDE_DOMAIN        the request needs a response the reduced model does not contain
A retained cell is never evidence of feasibility.

  flat_exact            flat LCDM: E^2 = 1 + m((1+z)^3 - 1) is affine in m, so feasibility is an exact rational interval
  flat_critical         exact rational bracket of the smallest uniform bound at which flat LCDM is feasible
  corner_rule           the earlier corner-cover rule without a witness (kept as a counterexample)
  curved_status         curved LCDM with a redshift-scale nuisance: per eta-cell a separating contrast proposed by an LP
                        and checked over the whole cell in interval arithmetic; replay_curved repeats it in rationals
  cover                 wCDM / CPL: interval contraction of the matter fraction (E^2 = D + m(X - D) is affine in m and
                        increasing in D) over cells of (w0, wa); leaves, witnesses, outer task enclosure
  leaves_complete       replay: the retained and discarded leaves partition the root box
  mp_E                  high-precision forward evaluation (independent of the interval code)
  tail_pair             two members that share the whole history on z <= 2.2 and differ only in the continuation
  dark_room             the background dark degeneracy: for each dust fraction m with a positive residual, the residual
                        history that reproduces E(z) exactly; reconstruction by integrating the conservation equation
  gluing_toy            exact rational compatibility of a clock, radial BAO and a luminosity proxy with a gain

numpy, scipy, mpmath. Deterministic.
"""
import math
from fractions import Fraction as F
import numpy as np
from mpmath import iv, mp
from scipy.optimize import linprog, minimize

iv.dps = 32
Z = [0.2, 0.4, 0.7, 1.0, 1.4, 1.8, 2.2]
ZT = 3.0


def I(x): return iv.mpf(str(x))
def interval(a, b): return iv.mpf([I(a).a, I(b).b])
def join(a, b): return iv.mpf([a.a, b.b])
def ends(x): return [math.nextafter(float(x.a), -math.inf), math.nextafter(float(x.b), math.inf)]


# ------------------------------------------------------------------ flat LCDM, exact
def flat_exact(Y, eps, z=Z, box=('0.2', '0.4')):
    q = F(str(eps)); lo, hi = F(box[0]), F(box[1])
    for zz, y in zip(z, Y):
        x = (1 + F(str(zz))) ** 3 - 1; y = F(str(y))
        lo = max(lo, ((y - q) ** 2 - 1) / x); hi = min(hi, ((y + q) ** 2 - 1) / x)
    if lo > hi:
        return {'status': 'EXCLUDED', 'max_lower': lo, 'min_upper': hi}
    return {'status': 'FEASIBLE', 'matter': [lo, hi], 'witness': (lo + hi) / 2}


def flat_member(Y, eps, m, z=Z):
    """Exact check that E(z) = sqrt(1 + m((1+z)^3 - 1)) lies within eps of every record (E >= 0)."""
    q = F(str(eps)); m = F(m)
    return all((F(str(y)) - q) ** 2 <= 1 + m * ((1 + F(str(zz))) ** 3 - 1) <= (F(str(y)) + q) ** 2 for zz, y in zip(z, Y))


def flat_critical(Y, steps=60):
    lo, hi = F(0), F(1, 10)
    for _ in range(steps):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if flat_exact(Y, mid)['status'] == 'EXCLUDED' else (lo, mid)
    return lo, hi


# ------------------------------------------------------------------ the corner rule without a witness (counterexample)
def _E(fn, z, p): return np.sqrt(fn(np.asarray(z, float), np.atleast_2d(np.asarray(p, float))))[0]
def s_flat(z, p): om = p[..., 0, None]; x = 1 + z; return om * x ** 3 + (1 - om)


def corner_rule(Y, eps, box=((0.2, 0.4),), tol=2e-4, initial=8, fn=s_flat):
    """Cells are dropped when a record range misses its window; a cell is kept at small size. INTERVAL means only that
    some cell was kept."""
    import heapq
    box = np.asarray(box, float); width = box[:, 1] - box[:, 0]; q = []; ctr = 0; Y = np.asarray(Y, float)
    axes = [np.linspace(box[i, 0], box[i, 1], initial + 1) for i in range(len(box))]
    for ix in np.ndindex(*([initial] * len(box))):
        lo = np.array([axes[i][ix[i]] for i in range(len(box))]); hi = np.array([axes[i][ix[i] + 1] for i in range(len(box))])
        heapq.heappush(q, (0., ctr, lo, hi)); ctr += 1
    kept = 0
    while q:
        _, _, lo, hi = heapq.heappop(q)
        c = np.array(np.meshgrid(*[[lo[i], hi[i]] for i in range(len(lo))], indexing='ij')).reshape(len(lo), -1).T
        R = np.array([_E(fn, Z, p) for p in c])
        if np.any(R.max(0) < Y - eps) or np.any(R.min(0) > Y + eps):
            continue
        S = fn(np.array([ZT]), c)[:, 0]; tl, tu = float(np.sqrt(S.min())), float(np.sqrt(S.max()))
        if tu - tl <= tol and np.max((hi - lo) / width) <= .125:
            kept += 1; continue
        i = int(np.argmax((hi - lo) / width)); mid = (lo[i] + hi[i]) / 2; h1 = hi.copy(); h1[i] = mid; l2 = lo.copy(); l2[i] = mid
        heapq.heappush(q, (-(tu - tl), ctr, lo, h1)); ctr += 1; heapq.heappush(q, (-(tu - tl), ctr, l2, hi)); ctr += 1
    return 'INTERVAL' if kept else 'EXCLUDED'


# ------------------------------------------------------------------ curved LCDM with a redshift-scale nuisance
def _records(Y, eps): return [((I(y) - I(eps)) ** 2, (I(y) + I(eps)) ** 2) for y in Y]


def curved_status(Y, eps, depth=12, mbox=(.2, .4), kbox=(-.08, .08), ebox=(-.01, .01)):
    obs = _records(Y, eps); queue = [(ebox[0], ebox[1], 0)]; certs = []; unresolved = 0; n = len(Z)
    while queue:
        l, h, d = queue.pop(); mid = (l + h) / 2; xx = 1 + np.array(Z) * (1 + mid); A = np.c_[xx ** 3 - 1, xx ** 2 - 1]
        ll = (np.array(Y) - eps) ** 2; uu = (np.array(Y) + eps) ** 2
        sol = linprog([0, 0, 1], A_ub=np.c_[np.r_[A, -A], -np.ones(2 * n)], b_ub=np.r_[uu - 1, 1 - ll],
                      bounds=[mbox, kbox, (None, None)], method='highs')
        if not sol.success:
            unresolved += 1; continue
        weights = [float(v) for v in (-sol.ineqlin.marginals[:n] + sol.ineqlin.marginals[n:])]
        x = [1 + I(z) * (1 + interval(l, h)) for z in Z]
        v = sum(I(w) * (t ** 3 - 1) for w, t in zip(weights, x)); u = sum(I(w) * (t ** 2 - 1) for w, t in zip(weights, x))
        mod = sum(I(w) for w in weights) + interval(*mbox) * v + interval(*kbox) * u
        diff = mod - sum(I(w) * join(a, b) for w, (a, b) in zip(weights, obs))
        if diff.a > 0 or diff.b < 0:
            certs.append({'eta': [l, h], 'contrast': weights}); continue
        p = (float(sol.x[0]), float(sol.x[1]), mid)
        if curved_member(Y, eps, p):
            return {'status': 'FEASIBLE', 'witness': list(p)}
        if d == depth:
            unresolved += 1; continue
        queue.extend([(l, mid, d + 1), (mid, h, d + 1)])
    return {'status': 'UNDECIDED' if unresolved else 'EXCLUDED', 'certificates': certs}


def curved_member(Y, eps, p):
    m, k, eta = (I(v) for v in p); obs = _records(Y, eps)
    vals = [1 + m * (t ** 3 - 1) + k * (t ** 2 - 1) for t in [1 + I(z) * (1 + eta) for z in Z]]
    return all(v.a >= a.b and v.b <= b.a for v, (a, b) in zip(vals, obs))


def replay_curved(Y, eps, certs, mbox=('0.2', '0.4'), kbox=('-0.08', '0.08'), ebox=('-0.01', '0.01')):
    """Exact rational replay: the certified eta cells tile the nuisance interval and every contrast separates."""
    q = lambda v: F(str(v)); z = [q(t) for t in Z]; y = [q(t) for t in Y]; e = q(eps); prev = q(ebox[0])
    for c in sorted(certs, key=lambda c: c['eta']):
        l, h = map(q, c['eta'])
        if l != prev:
            return False
        prev = h; w = [q(v) for v in c['contrast']]; cfs = []
        for k in (3, 2):
            terms = [sorted([v * ((1 + t * (1 + s)) ** k - 1) for s in (l, h)]) for v, t in zip(w, z)]
            cfs.append([sum(t[j] for t in terms) for j in (0, 1)])
        a = [x * c_ for x in (q(mbox[0]), q(mbox[1])) for c_ in cfs[0]]; b = [x * c_ for x in (q(kbox[0]), q(kbox[1])) for c_ in cfs[1]]
        rows = [sorted([v * (t - e) ** 2, v * (t + e) ** 2]) for v, t in zip(w, y)]
        lower = sum(w) + min(a) + min(b) - sum(t[1] for t in rows); upper = sum(w) + max(a) + max(b) - sum(t[0] for t in rows)
        if not (lower > 0 or upper < 0):
            return False
    return prev == q(ebox[1])


# ------------------------------------------------------------------ wCDM and CPL: interval cover
def _logs(zs):
    L = [3 * iv.ln(1 + I(z)) for z in zs]; B = [l - 3 * I(z) / (1 + I(z)) for l, z in zip(L, zs)]
    return [(1 + I(z)) ** 3 for z in zs], L, B


X_, L_, B_ = _logs(Z + [ZT])


def _dark(j, w, wa): return iv.exp(L_[j] * (1 + w) + B_[j] * wa)


def member(Y, eps, p):
    """Interval check of a (m, w0, wa) point against every record; returns (ok, E(3) enclosure)."""
    obs = _records(Y, eps); m, w, wa = (I(v) for v in p)
    v = [m * X_[j] + (1 - m) * _dark(j, w, wa) for j in range(len(Z) + 1)]
    return all(x.a >= a.b and x.b <= b.a for x, (a, b) in zip(v, obs)), ends(iv.sqrt(v[-1]))


def cover(Y, eps, box, depth, tol=0.05):
    """box = [(m), (w0), (wa)]; wa = (0, 0) for wCDM. Splits alternate w0 / wa (w0 only for wCDM)."""
    obs = _records(Y, eps); mb, wb, ab = box; q = [(wb[0], wb[1], ab[0], ab[1], 0)]; ret = []; rej = []; wit = []
    while q:
        wl, wh, al, ah, d = q.pop(); w = interval(wl, wh); a = interval(al, ah); ml, mh = I(mb[0]).a, I(mb[1]).b; reason = None
        for j, (ylo, yhi) in enumerate(obs):
            de = _dark(j, w, a); x = X_[j]
            if not x.a > de.b:
                continue                                          # contract only where the denominator is certified positive
            ml = max(ml, ((ylo - de.b) / (x - de.b)).a); mh = min(mh, ((yhi - de.a) / (x - de.a)).b)
            if ml > mh:
                reason = j; break
        if reason is not None:
            rej.append((wl, wh, al, ah)); continue
        if d == depth:
            de = _dark(len(Z), w, a); vv = [v * X_[-1] + (1 - v) * t for v in (ml, mh) for t in (de.a, de.b)]
            task = ends(iv.sqrt(join(min(v.a for v in vv), max(v.b for v in vv))))
            ret.append((wl, wh, al, ah, float(ml), float(mh), *task))
            p = [(float(ml) + float(mh)) / 2, (wl + wh) / 2, (al + ah) / 2]; ok, val = member(Y, eps, p)
            if ok:
                wit.append((*p, *val))
            continue
        if ab[0] == ab[1] or d % 2 == 0:
            s = (wl + wh) / 2; q.extend([(wl, s, al, ah, d + 1), (s, wh, al, ah, d + 1)])
        else:
            s = (al + ah) / 2; q.extend([(wl, wh, al, s, d + 1), (wl, wh, s, ah, d + 1)])
    out = {'retained': ret, 'discarded': rej, 'witnesses': wit}
    if not ret:
        return {**out, 'status': 'EXCLUDED'}
    L = min(r[-2] for r in ret); H = max(r[-1] for r in ret); out.update(outer=[L, H], outer_width=H - L)
    if not wit:
        return {**out, 'status': 'UNDECIDED'}
    lo = min(wit, key=lambda p: p[-1]); hi = max(wit, key=lambda p: p[-2]); out['inner_width_lower_bound'] = hi[-2] - lo[-1]
    if (I(H) - I(L)).b <= I(tol).a:
        st = 'LOCKED_CONDITIONAL'
    elif (I(hi[-2]) - I(lo[-1])).a > I(tol).b:
        st = 'NOT_FORCED'
    else:
        st = 'FEASIBLE'
    return {**out, 'status': st}


def leaves_complete(box, depth, leaves):
    """Replay: the leaves (w0, wa cells) partition the root box under the splitting rule."""
    (wl, wh), (al, ah) = box[1], box[2]; remaining = set(tuple(r[:4]) for r in leaves); stack = [(wl, wh, al, ah, 0)]
    while stack:
        a, h, c, g, d = stack.pop()
        if (a, h, c, g) in remaining:
            remaining.remove((a, h, c, g)); continue
        if d >= depth:
            return False
        if al == ah or d % 2 == 0:
            s = (a + h) / 2; stack.extend([(a, s, c, g, d + 1), (s, h, c, g, d + 1)])
        else:
            s = (c + g) / 2; stack.extend([(a, h, c, s, d + 1), (a, h, s, g, d + 1)])
    return not remaining


def mp_E(p, z, dps=70):
    mp.dps = dps; m, w, wa = (mp.mpf(str(v)) for v in p); z = mp.mpf(str(z))
    return mp.sqrt(m * (1 + z) ** 3 + (1 - m) * (1 + z) ** (3 * (1 + w + wa)) * mp.exp(-3 * wa * z / (1 + z)))


# ------------------------------------------------------------------ continuation beyond the last record
def tail_pair(p=(.31, -.9, .28), tail_w=(-2, 0), zlast=2.2):
    m, w, wa = (I(v) for v in p); last = _dark(len(Z) - 1, w, wa); a = I(1 + ZT) / (1 + I(zlast))
    T = [iv.sqrt(I(p[0]) * (1 + I(ZT)) ** 3 + (1 - I(p[0])) * last * iv.exp(3 * (1 + I(wt)) * iv.ln(a))) for wt in tail_w]
    return [ends(t) for t in T], ends(T[1] - T[0])[0]


def E_continued(p, wt, z, zlast=2.2):
    """E(z) for the CPL history up to zlast continued with constant w = wt (density continuous at zlast)."""
    m, w0, wa = p; x = 1 + z
    if z <= zlast:
        return float(_E(lambda zz, pp: pp[..., 0, None] * (1 + zz) ** 3 + (1 - pp[..., 0, None]) * (1 + zz) ** (3 * (1 + pp[..., 1, None] + pp[..., 2, None])) * np.exp(-3 * pp[..., 2, None] * zz / (1 + zz)), [z], p)[0])
    xl = 1 + zlast; dl = xl ** (3 * (1 + w0 + wa)) * math.exp(-3 * wa * zlast / xl)
    return math.sqrt(m * x ** 3 + (1 - m) * dl * (x / xl) ** (3 * (1 + wt)))


# ------------------------------------------------------------------ the dark room
def S_cpl(z, p=(.31, -.9, .28)):
    m, w0, wa = p; x = 1 + np.asarray(z, float)
    return m * x ** 3 + (1 - m) * x ** (3 * (1 + w0 + wa)) * np.exp(-3 * wa * (x - 1) / x)


def dark_room(m_alt, p=(.31, -.9, .28), zmax=2.2, n=4001):
    """Residual D = S - m_alt x^3 and w = -1 + x D'/(3D) (analytic derivative); reconstruct D by integrating
    dlnD/dlnx = 3(1 + w) from D(0) = 1 - m_alt and return the worst relative error of the reconstructed S."""
    m, w0, wa = p; z = np.linspace(0, zmax, n); x = 1 + z
    dS = m * 3 * x ** 2 + (1 - m) * S_cpl(z, (0, w0, wa)) * (3 * (1 + w0 + wa) / x - 3 * wa / x ** 2)
    D = S_cpl(z, p) - m_alt * x ** 3; Dp = dS - 3 * m_alt * x ** 2
    if np.any(D <= 0):
        return {'positive': False, 'min_residual': float(D.min())}
    w = -1 + x * Dp / (3 * D); f = 3 * (1 + w); lx = np.log(x)
    integral = np.r_[0, np.cumsum((f[1:] + f[:-1]) / 2 * np.diff(lx))]
    Drec = (1 - m_alt) * np.exp(integral) if m_alt < 1 else None
    err = float(np.max(np.abs(m_alt * x ** 3 + Drec - S_cpl(z, p)) / S_cpl(z, p)))
    return {'positive': True, 'w_range': [float(w.min()), float(w.max())], 'w0': float(w[0]), 'w_last': float(w[-1]),
            'reconstruction_error': err}


def positivity_sup(p=(.31, -.9, .28), zmax=2.2):
    """sup of admissible dust fractions: min over [0, zmax] of S/x^3. S/x^3 = m + (1-m) DE/x^3 decreases where the
    residual w < 0, so the minimum is at zmax when w0 + wa z/(1+z) < 0 on [0, zmax]."""
    m, w0, wa = p; wmax = max(w0, w0 + wa * zmax / (1 + zmax))
    x = 1 + I(zmax); de = x ** (3 * (1 + I(w0) + I(wa))) * iv.exp(-3 * I(wa) * I(zmax) / x)
    return ends(I(m) + (1 - I(m)) * de / x ** 3), wmax < 0


# ------------------------------------------------------------------ gluing: clock, radial BAO, luminosity proxy
def gluing_toy(conflict=(F(295, 4), F(297, 4))):
    c0 = F(300000); rd = (F(149), F(151)); qr = (F('0.139'), F('0.141')); sn = (F('0.99'), F('1.01'))
    gain = (F('0.00022'), F('0.00025')); cc = (F(279, 4), F(281, 4))
    inter = lambda *r: (max(a for a, b in r), min(b for a, b in r))
    bao = (qr[0] * c0 / (4 * rd[1]), qr[1] * c0 / (4 * rd[0])); si = (gain[0] * c0 / sn[1], gain[1] * c0 / sn[0])
    common = inter(cc, bao, si); clash = inter(cc, bao, si, conflict)
    witness_ok = cc[0] <= 70 <= cc[1] and qr[0] <= 4 * 70 * 150 / c0 <= qr[1] and sn[0] <= F(7, 30000) * c0 / 70 <= sn[1]
    return {'common': common, 'nonempty': common[0] <= common[1], 'conflict': clash, 'conflict_empty': clash[0] > clash[1],
            'witness_ok': witness_ok}


def channels(logH0, logrd, loggain, zc=1.0, chi=0.5, c=299792.458, with_clock=True):
    """Log responses at z = 1 for E = (1+z)^2: clock H, radial BAO H rd / c, luminosity proxy gain c (1+z) chi / H0."""
    H0, rd, g = math.exp(logH0), math.exp(logrd), math.exp(loggain); H = H0 * (1 + zc) ** 2
    out = [math.log(H * rd / c), math.log(g * c * (1 + zc) * chi / H0)]
    return np.array(([math.log(H)] if with_clock else []) + out)


# ------------------------------------------------------------------ dimensional typing of the response expressions
import ast as _ast

EXPR = {'H': 'H0*sqrt(S)', 'E': 'H/H0', 'bao': 'H*rd/c', 'distance': 'c*chi/H0', 'sn_proxy': 'distance*gain',
        'wrong_sum': 'H0+S', 'wrong_exp': 'exp(H0)', 'wrong_bao': 'H*rd'}
TABLE = {'H0': (0, -1), 'S': (0, 0), 'H': (0, -1), 'rd': (1, 0), 'c': (1, -1), 'chi': (0, 0), 'distance': (1, 0), 'gain': (-1, 0)}
TARGET = {'H': (0, -1), 'E': (0, 0), 'bao': (0, 0), 'distance': (1, 0), 'sn_proxy': (0, 0)}


def dim_of(expr, table=TABLE):
    """(length, time) exponents of an expression, or None when it is malformed (unlike addends, dimensioned argument)."""
    def go(n):
        if isinstance(n, _ast.Expression): return go(n.body)
        if isinstance(n, _ast.Name): return tuple(F(v) for v in table[n.id])
        if isinstance(n, _ast.Call):
            a = go(n.args[0])
            if a is None: return None
            if n.func.id == 'sqrt': return tuple(v / 2 for v in a)
            return a if all(v == 0 for v in a) else None             # exp, log: dimensionless argument only
        a, b = go(n.left), go(n.right)
        if a is None or b is None: return None
        if isinstance(n.op, _ast.Add): return a if a == b else None
        return tuple(x + (y if isinstance(n.op, _ast.Mult) else -y) for x, y in zip(a, b))
    return go(_ast.parse(expr, mode='eval'))


def typed(name, table=TABLE):
    d = dim_of(EXPR[name], table)
    return d is not None and d == tuple(F(v) for v in TARGET.get(name, (0, 0)))
