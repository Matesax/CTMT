#!/usr/bin/env python3
"""Mutation suite for rg_cosmology_battery.py.

Each mutation changes one line of the library (or of the battery's reference computation) so that a claim of the
reduced-cosmology paper becomes false. It is caught only when the targeted group fails; the battery is run on that
group alone. A survivor is a defect of the battery; a crash is a defect of the suite, not a catch. Runs in temporary
copies.

    python3 -I rg_cosmology_battery_mutations.py [--jobs 2] [--only UA,UB]
"""
import argparse, json, os, shutil, subprocess, sys, tempfile
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
NAME = 'rg_cosmology_battery'
LIB = 'rg_cosmology.py'
BAT = NAME + '.py'
MUTATIONS = [  # (group, description, file, old, new)
    ('KA', 'unlike addends accepted', LIB, 'if isinstance(n.op, _ast.Add): return a if a == b else None', 'if isinstance(n.op, _ast.Add): return a'),
    ('KA', 'exponential of a dimensioned argument accepted', LIB, 'return a if all(v == 0 for v in a) else None', 'return a'),
    ('KA', 'E record made absolute (H in place of H/H0)', BAT, 'Erec = lambda q: np.array([float(C.mp_E(q[1:], z, 30)) for z in C.Z])',
     'Erec = lambda q: np.array([math.exp(q[0]) * float(C.mp_E(q[1:], z, 30)) for z in C.Z])'),
    ('KA', 'radial BAO without its ruler', LIB, 'out = [math.log(H * rd / c),', 'out = [math.log(H / c),'),
    ('KB', 'exact flat rule with a slack', LIB, "    if lo > hi:\n        return {'status': 'EXCLUDED', 'max_lower'", "    if lo > hi + F(1, 1000):\n        return {'status': 'EXCLUDED', 'max_lower'"),
    ('KB', 'corner rule made to require a witness (the counterexample disappears)', LIB, '            kept += 1; continue',
     '            kept += int(np.max(np.abs(_E(fn, Z, (lo + hi) / 2) - Y)) <= eps); continue'),
    ('KC', 'upper rational bound with a doubled error', LIB, 'hi = min(hi, ((y + q) ** 2 - 1) / x)', 'hi = min(hi, ((y + 2 * q) ** 2 - 1) / x)'),
    ('KD', 'contrast accepted without the interval check', LIB, '        if diff.a > 0 or diff.b < 0:', '        if True:'),
    ('KD', 'curved model without the curvature term', BAT, 'return np.sqrt(1 + m * (x ** 3 - 1) + k * (x ** 2 - 1))', 'return np.sqrt(1 + m * (x ** 3 - 1))'),
    ('KE', 'matter lower bound contracted with the wrong end of D', LIB, 'ml = max(ml, ((ylo - de.b) / (x - de.b)).a)', 'ml = max(ml, ((ylo - de.a) / (x - de.a)).a)'),
    ('KE', 'discarded leaves not recorded', LIB, '            rej.append((wl, wh, al, ah)); continue', '            continue'),
    ('KF', 'task enclosure from one end of D only', LIB, 'for v in (ml, mh) for t in (de.a, de.b)]', 'for v in (ml, mh) for t in (de.a,)]'),
    ('KF', 'outer interval taken from the witnesses', LIB, 'L = min(r[-2] for r in ret); H = max(r[-1] for r in ret)',
     'L = min(w[-2] for w in wit) if wit else 0.; H = max(w[-1] for w in wit) if wit else 0.'),
    ('KG', 'continuation range narrowed to [-1.1, -0.9]', LIB, 'def tail_pair(p=(.31, -.9, .28), tail_w=(-2, 0), zlast=2.2):', 'def tail_pair(p=(.31, -.9, .28), tail_w=(-1.1, -0.9), zlast=2.2):'),
    ('KG', 'continuation begins before the last record', LIB, '    if z <= zlast:', '    if z <= zlast - 0.5:'),
    ('KH', 'residual equation of state with the wrong sign', LIB, 'w = -1 + x * Dp / (3 * D)', 'w = -1 - x * Dp / (3 * D)'),
    ('KH', 'positivity supremum taken at z = 0', LIB, 'x = 1 + I(zmax); de = x', 'x = 1 + I(0); de = x'),
    ('KI', 'conflicting clock overlaps the others', LIB, 'def gluing_toy(conflict=(F(295, 4), F(297, 4))):', 'def gluing_toy(conflict=(F(280, 4), F(297, 4))):'),
    ('KI', 'joint witness with a wrong ruler', LIB, 'qr[0] <= 4 * 70 * 150 / c0 <= qr[1]', 'qr[0] <= 4 * 70 * 160 / c0 <= qr[1]'),
]


def run(mut):
    group, desc, rel, old, new = mut
    base = open(os.path.join(HERE, rel)).read()
    if base.count(old) != 1:
        return group, desc, 'anchor not found exactly once -> SUITE DEFECT', False
    with tempfile.TemporaryDirectory() as tmp:
        work = os.path.join(tmp, 'b')
        shutil.copytree(HERE, work, ignore=shutil.ignore_patterns('__pycache__', NAME + '_results.json', NAME + '_mutations.py',
                                                                  '*.log', 'paper', '*.zip', 'r[0-9]*.json', 'RG_*bundle*', 'run*.log'))
        open(os.path.join(work, rel), 'w').write(base.replace(old, new))
        env = dict(os.environ, RG_COSMO_GROUPS=group)
        subprocess.run([sys.executable, '-I', NAME + '.py'], cwd=work, capture_output=True, text=True, env=env)
        try:
            fails = json.load(open(os.path.join(work, NAME + '_results.json')))['failures']
        except Exception:
            fails = ['CRASHED']
    ok = group in fails
    return group, desc, ('caught ' if ok else 'SURVIVED ') + str(fails), ok


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--jobs', type=int, default=2); ap.add_argument('--only', default='')
    a = ap.parse_args(); sel = [m for m in MUTATIONS if not a.only or m[0] in a.only.split(',')]
    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(run, sel))
    for g, d, msg, _ in res:
        print(f'{g}  {d}: {msg}', flush=True)
    caught = sum(r[3] for r in res)
    print(f'{caught} / {len(sel)} caught')
    return 0 if caught == len(sel) else 1


if __name__ == '__main__':
    sys.exit(main())
