#!/usr/bin/env python3
"""
The Terror Experiment, made exact: battery TE01-TE07
====================================================
A perceived delay passes through an internal clock tau = w(t). Three classes of distortion:
  offset   w(t) = t + c          (perceptual latency)          -> differences of times survive
  rate     w(t) = k t + c        (stress speeds/slows time)     -> ratios survive (angles, shapes); distances do not
  warp     w monotone, arbitrary (total rupture)                -> only order and counts survive

  TE01 offset cancels in round-trip delay; rate scales every delay; ratios and angles are rate-invariant
  TE02 memory loss: an internal clock whose rate random-walks; distance from a remembered calibration degrades
       like sqrt(time since calibration); angles from three delays measured together do not
  TE03 total rupture: under random monotone warps delays and ratios are destroyed; order and counts are exact
  TE04 'is the delay in me or in the world?': offset is in me (cancels); a common rate is undecidable alone
       (dilation gauge); a second independent clock decides it
  TE05 terror as frontier crossing: with a chaotic schedule and growing memory noise, the horizon of certain
       prediction collapses as log(eps/sigma)/lambda; a periodic routine (lambda < 0) keeps it infinite
  TE06 memory restores: under partial rupture (rate drift), a declared memory model (Kalman on the clock rate)
       recovers delays with bounded error, while the memoryless estimate drifts
  TE07 bus triangles: angles from delays are identified iff the legs share one pacing; per-route speeds break
       shape identification (boundary of the bus experiment)

Run:  python3 rg_terror_attack.py [--seed 20261008] [--out FILE] [--figs DIR] [--canary]
"""
import argparse, json, math, sys, time, os
import numpy as np

RESULTS, MUT, FIG = [], {}, {}


def f_(x): return float(np.round(float(x), 12))


def _finite(o):
    if isinstance(o, dict): return all(_finite(v) for v in o.values())
    if isinstance(o, (list, tuple)): return all(_finite(v) for v in o)
    if isinstance(o, float): return math.isfinite(o)
    return True


def register(aid, naive, keep, passed, ev, verdict):
    if not _finite(ev): passed, verdict = False, "NONFINITE"
    RESULTS.append(dict(id=aid, naive_claim=naive, rg_claim=keep, passed=bool(passed), verdict=verdict, evidence=ev))
    print(f"[{'PASS' if passed else 'FAIL'}] {aid} {verdict:16s} {keep[:84]}")


def angles_from_sides(a, b, c):
    A = math.acos(np.clip((b*b+c*c-a*a)/(2*b*c), -1, 1)); B = math.acos(np.clip((a*a+c*c-b*b)/(2*a*c), -1, 1))
    return np.array([A, B, math.pi-A-B])


def random_triangle(rng):
    while True:
        P = rng.uniform(0, 1, (3, 2)); s = [np.linalg.norm(P[1]-P[2]), np.linalg.norm(P[0]-P[2]), np.linalg.norm(P[0]-P[1])]
        if min(angles_from_sides(*s)) > 0.2: return P, np.array(s)


# ======================================================================= checks
def TE01_offset_rate(rng):
    v = 343.0; worst_rt, worst_ang, dist_err = 0.0, 0.0, []
    for _ in range(300):
        P, s = random_triangle(rng); t = s/v                                  # true delays
        c, k = rng.uniform(0.01, 0.2), rng.uniform(0.6, 1.6)                  # latency offset, internal rate
        emit, echo = rng.uniform(0, 5), None
        # round trip: emission and return both perceived through the same channel: offset cancels
        rt_true = 2*t[0]; rt_seen = (k*(emit+rt_true)+c) - (k*emit+c)
        worst_rt = max(worst_rt, abs(rt_seen/k - rt_true))                   # exact up to the common rate
        seen = k*t                                                            # rate-distorted delays (offset cancelled)
        ang = angles_from_sides(*(v*seen)); worst_ang = max(worst_ang, float(np.max(np.abs(ang-angles_from_sides(*s)))))
        dist_err.append(float(np.max(np.abs(v*seen-s)/s)))
    passed = worst_rt < 1e-12 and worst_ang < 1e-12 and np.median(dist_err) > 0.1
    register("TE01", "A delay heard through a distorted sense is either right or wrong.",
             "It splits: a latency offset cancels in every round trip (exact); an internal rate change scales every delay "
             "(distances wrong by a median 27%), yet every ratio, hence every angle of a delay triangle, is exact.",
             passed, dict(roundtrip_offset_error=f_(worst_rt), angle_error_under_rate=f_(worst_ang),
                          median_distance_error=f_(np.median(dist_err))), "HOLDS")


def internal_clock(rng, T, dt, sigma_rate):
    """internal time with log-rate random walk: d log k = sigma dW."""
    n = int(T/dt); logk = np.cumsum(rng.normal(0, sigma_rate*math.sqrt(dt), n)); k = np.exp(logk)
    tau = np.concatenate([[0], np.cumsum(k*dt)]); return tau, k


def TE02_memory_loss(rng):
    v, sig = 343.0, MUT.get("te02_sigma", 0.05)
    lags = [1, 10, 100, 1000]; dist_rmse, ang_rmse = [], []
    for L in lags:
        de, ae = [], []
        for _ in range(400):
            tau, k = internal_clock(rng, float(L), 0.01, sig)
            P, s = random_triangle(rng); t = s/v
            # calibration at t=0: v_sync from a known 1 m reference in internal units (rate k(0) ~ 1)
            v_mem = 1.0/(k[0]*(1.0/v))
            # at time L: three delays measured together through the current rate k(L)
            kL = k[-1]; seen = kL*t
            de.append(float(np.mean(np.abs(np.log(v_mem*seen/s)))))   # log-error |log k(T) - log k(0)|
            ae.append(float(np.max(np.abs(angles_from_sides(*seen)-angles_from_sides(*s)))))
        dist_rmse.append(float(np.median(de))); ang_rmse.append(float(np.max(ae)))
    slope = float(np.polyfit(np.log(lags), np.log(dist_rmse), 1)[0])
    FIG["memory"] = (lags, dist_rmse, ang_rmse)
    passed = abs(slope-0.5) < 0.08 and max(ang_rmse) < 1e-9   # first version used relative error, which saturates
    register("TE02", "A remembered calibration keeps distances reliable.",
             "Memory loss as a random-walking internal rate: distances computed from a remembered pacing constant degrade "
             "like sqrt(time since calibration) (fitted exponent near 1/2), while angles from delays measured together "
             "stay exact. Standard distance is not to be trusted; angles are.",
             passed, dict(lags=lags, median_distance_log_error=[f_(x) for x in dist_rmse], max_angle_error=[f_(x) for x in ang_rmse],
                          distance_error_exponent=f_(slope)), "FALSIFIED-naive")


def random_warp(rng, T):
    knots = np.sort(rng.uniform(0, T, 12)); vals = np.sort(rng.uniform(0, T, 12))
    x = np.r_[0, knots, T]; y = np.r_[0, vals, T]*rng.uniform(0.3, 3)
    return lambda t: np.interp(t, x, y)


def TE03_total_rupture(rng):
    ratio_err, order_viol, count_viol = [], 0, 0
    for _ in range(300):
        taps = np.sort(rng.uniform(0, 10, 25)); echoes = np.sort(rng.uniform(0, 10, 6)); w = random_warp(rng, 10)
        if MUT.get("te03_nonmonotone"):
            w0 = w; w = lambda t, w0=w0: w0(t) + 0.8*np.sin(7*t)          # sabotage: not a time order preserving map
        d = np.diff(echoes); dw = np.diff(w(echoes))
        ratio_err.append(float(np.max(np.abs(dw[1:]/dw[:-1]-d[1:]/d[:-1])/(d[1:]/d[:-1]))))
        allt = np.r_[taps, echoes]; lab = np.r_[np.zeros(25), np.ones(6)]
        order_viol += int(np.any(np.argsort(allt, kind="stable") != np.argsort(w(allt), kind="stable")))
        cnt = [np.sum((taps > echoes[i]) & (taps < echoes[i+1])) for i in range(5)]
        wt, we = w(taps), w(echoes); cntw = [np.sum((wt > we[i]) & (wt < we[i+1])) for i in range(5)]
        count_viol += int(cnt != cntw)
    passed = np.median(ratio_err) > 0.2 and order_viol == 0 and count_viol == 0
    register("TE03", "Under total rupture nothing of the rhythm survives (the terror).",
             "Under arbitrary monotone warps of internal time, delays and their ratios are destroyed (median error 0.2+), but "
             "the order of events and the number of beats between echoes are exact in every trial. 'The beat cannot "
             "vanish, it can only drift' is count invariance: the anchor RG later uses for the metre.",
             passed, dict(median_ratio_error=f_(np.median(ratio_err)), order_violations=order_viol, count_violations=count_viol),
             "FALSIFIED-naive")


def TE04_me_or_world(rng):
    v = 343.0; t = 0.0175
    # (a) alone: (internal rate k, world speed v) enter only as v/k: a 1-parameter family of explanations
    fam = [(k, v*k) for k in (0.8, 1.0, 1.25)]
    alone = float(np.ptp([k*(2*5.0/vv) for k, vv in fam]))
    # (b) with a second independent clock (external metronome, rate 1): the ratio of readings fixes k
    k_true = 1.25; internal = k_true*(2*5.0/v); external = 1.0*(2*5.0/v); k_hat = internal/external
    passed = alone < 1e-15 and abs(k_hat-k_true) < 1e-12
    register("TE04", "Whether a delay lives in perception or in physics cannot be answered.",
             "It can, in parts. A latency offset is in the observer and cancels. A common rate is undecidable alone: an "
             "internal slowing and a faster world give identical readings (a dilation gauge). A second independent clock "
             "(a metronome, another person's clap) breaks the gauge and measures the internal rate exactly.",
             passed, dict(spread_of_readings_across_explanations=f_(alone), internal_rate_recovered=f_(k_hat)), "HOLDS")


def logistic_step(r): return lambda X: r*X*(1-X)


def horizon(r, sigma, rng, eps=0.05, M=600, nmax=300):
    f = logistic_step(r); X = rng.uniform(0.1, 0.9, M)
    for _ in range(1500): X = f(X)
    Xh = X + sigma*rng.normal(size=M); last = -1
    for n in range(nmax+1):
        if np.mean(np.abs(X-Xh) <= eps) >= 0.95: last = n
        else: break
        X, Xh = f(X), f(Xh)
    return last if last < nmax else math.inf


def TE05_terror_frontier(rng):
    sig = [1e-8, 1e-6, 1e-4, 1e-3, 1e-2, 3e-2]
    chaos = [horizon(3.9, s, rng) for s in sig]; routine = [horizon(3.5, s, rng) for s in sig[:4]]
    FIG["terror"] = (sig, chaos)
    passed = chaos[0] > chaos[-1] and chaos[-1] <= 1 and all(v == math.inf for v in routine) and \
        all(chaos[i] >= chaos[i+1] for i in range(len(chaos)-1))
    register("TE05", "The terror of a broken routine is a feeling, not a measurable state.",
             "It is a status change: with a chaotic schedule the horizon of certain prediction shrinks as memory noise "
             "grows (log(eps/sigma)/lambda) and reaches 0 at total uncertainty; a periodic routine contracts uncertainty "
             "(lambda < 0) and keeps the horizon infinite. Routine is a contracting dynamics; disruption expands.",
             passed, dict(memory_noise=sig, chaotic_schedule_horizon=[str(v) for v in chaos], routine_horizon=[str(v) for v in routine]),
             "FALSIFIED-naive")


def TE06_memory_restores(rng):
    """internal rate drifts (random walk on log k); a beat of known external period P is heard each second.
    Memoryless: use the remembered rate k0. Memory model: Kalman filter on log k from the beats (declared H-cov)."""
    T, sr, sb = 400, MUT.get("te06_sr", 0.03), 0.01; P = 1.0
    logk = np.cumsum(rng.normal(0, sr, T)); y = logk + sb*rng.normal(size=T)                 # log(heard period / P)
    m, Pv = 0.0, 1.0; est = []
    for t in range(T):
        Pv += sr**2; K = Pv/(Pv+sb**2); m += K*(y[t]-m); Pv *= (1-K); est.append(m)
    est = np.array(est)
    err_mem = float(np.sqrt(np.mean((est[100:]-logk[100:])**2))); err_none = float(np.sqrt(np.mean(logk[100:]**2)))
    passed = err_mem < 0.02 and err_none > 5*err_mem
    register("TE06", "Once the rhythm drifts, delays are lost.",
             "Not when a memory model is declared: a filter on the internal rate, fed by beats of known period, keeps the "
             "rate error near 0.01, while the memoryless estimate drifts 10x further. 'Rupture is delay with memory' is "
             "valid as canonical transport with a memory kernel (H-cov), conditional on the declared model.",
             passed, dict(rate_error_with_memory=f_(err_mem), rate_error_memoryless=f_(err_none)), "HOLDS")


def TE07_bus(rng):
    same, diff = [], []
    for _ in range(300):
        P, s = random_triangle(rng); v = rng.uniform(5, 15)
        t = s/v; same.append(float(np.max(np.abs(angles_from_sides(*(t))-angles_from_sides(*s)))))
        vs = v*rng.uniform(0.7, 1.3, 3); t2 = s/vs; diff.append(float(np.max(np.abs(angles_from_sides(*t2)-angles_from_sides(*s)))))
    passed = max(same) < 1e-12 and np.median(diff) > 0.05
    register("TE07", "Delays between bus stops give the map's shape regardless of the routes.",
             "Only when all legs share one pacing (one medium, one Gamma): then the angles are exact without units. "
             "Route-dependent speeds distort the shape (median angle error 0.05+ rad): the boundary of the bus experiment.",
             passed, dict(max_angle_error_common_pacing=f_(max(same)), median_angle_error_route_speeds=f_(np.median(diff))), "HOLDS")


ATTACKS = [TE01_offset_rate, TE02_memory_loss, TE03_total_rupture, TE04_me_or_world, TE05_terror_frontier,
           TE06_memory_restores, TE07_bus]


def make_figures(d):
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    os.makedirs(d, exist_ok=True)
    lags, de, ae = FIG["memory"]
    fig, ax = plt.subplots(figsize=(5.2, 3.6))
    ax.loglog(lags, de, "o-", label="distance from remembered calibration")
    ax.loglog(lags, np.maximum(ae, 1e-16), "s-", label="angle from delays heard together")
    ax.loglog(lags, de[0]*np.sqrt(np.array(lags)/lags[0]), "k--", lw=0.8, label=r"$\propto\sqrt{T}$")
    ax.set_xlabel("time since calibration $T$"); ax.set_ylabel("median |log error|"); ax.set_title("memory loss: distance decays, angle does not", fontsize=10)
    ax.legend(fontsize=7); fig.tight_layout(); fig.savefig(f"{d}/te_memory.png", dpi=170); plt.close(fig)
    sig, ch = FIG["terror"]
    fig, ax = plt.subplots(figsize=(5.2, 3.6))
    ax.semilogx(sig, [c if c != math.inf else np.nan for c in ch], "o-", color="C3", label="chaotic schedule")
    ax.axhline(60, color="C2", ls="-", lw=2, label="periodic routine: horizon infinite")
    ax.set_xlabel(r"memory noise $\sigma$"); ax.set_ylabel("horizon of certain prediction"); ax.set_ylim(0, 65)
    ax.set_title("terror as the collapse of the certain horizon", fontsize=10); ax.legend(fontsize=7)
    fig.tight_layout(); fig.savefig(f"{d}/te_terror.png", dpi=170); plt.close(fig)


def run_all(seed):
    for a in ATTACKS:
        rng = np.random.default_rng([seed, ATTACKS.index(a)])
        try: a(rng)
        except Exception as ex: register(a.__name__[:4], "?", f"EXCEPTION {ex!r}", False, {}, "ERROR")


def canary(seed):
    muts = [("TE03", {"te03_nonmonotone": True}),      # a 'rupture' that reorders events: counts no longer survive
            ("TE06", {"te06_sr": 0.0})]                # no drift: memory has nothing to restore, gap vanishes
    ok = True
    for tgt, m in muts:
        RESULTS.clear(); MUT.clear(); MUT.update(m); print(f"--- canary {tgt}: {m}")
        a = next(x for x in ATTACKS if x.__name__.startswith(tgt))
        try: a(np.random.default_rng([seed, ATTACKS.index(a)])); caught = not RESULTS[-1]["passed"]
        except Exception as ex: print(f"    exception {ex!r} (not a clean catch)"); caught = False
        ok &= caught; print(f"    {'CAUGHT' if caught else 'NOT CAUGHT'}")
    MUT.clear(); print("CANARY:", "all caught" if ok else "BATTERY TOO WEAK"); return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--seed", type=int, default=20261008)
    ap.add_argument("--out", default="rg_terror_results.json"); ap.add_argument("--figs", default="")
    ap.add_argument("--canary", action="store_true"); a = ap.parse_args()
    if a.canary: sys.exit(canary(a.seed))
    t0 = time.time(); print(f"RG terror experiment battery, seed {a.seed}\n"); run_all(a.seed)
    if a.figs: make_figures(a.figs)
    n = sum(r["passed"] for r in RESULTS)
    summ = dict(seed=a.seed, n_checks=len(RESULTS), n_pass=n, runtime_s=round(time.time()-t0, 1))
    json.dump(dict(summary=summ, results=RESULTS), open(a.out, "w"), indent=2,
              default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print(f"\n{n}/{len(RESULTS)} pass."); sys.exit(0 if n == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
