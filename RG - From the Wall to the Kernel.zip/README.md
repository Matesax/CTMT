# RG - From the Wall to the Kernel: origin paper and the Terror battery TE01-TE07

    python3 rg_terror_attack.py --figs figs   # seed 20261008
    python3 rg_terror_attack.py --canary      # reordering rupture and drift-free clock; each must fail

7/7 on seeds 20261008, 1, 42, 777, 2026; canary 2/2.
Offset cancels in round trips; rate preserves ratios and angles, not distances; total rupture preserves only order and counts;
memory loss degrades remembered distance like sqrt(T) while angles stay exact; terror as collapse of the certain horizon under a
chaotic schedule; routine as contraction; memory restores under a declared model; bus triangles need one shared pacing.
