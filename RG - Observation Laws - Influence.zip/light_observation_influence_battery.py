"""Operational light-observation influence battery.
Seed 20260819. This is an observational two-path model, not a derivation of QM.
Run: python light_observation_influence_battery.py
"""
import numpy as np, json
from pathlib import Path
SEED=20260819; N=20000
rng=np.random.default_rng(SEED)
phi=rng.uniform(-np.pi,np.pi,N); A=rng.uniform(.35,1.65,N); B=rng.uniform(.35,1.65,N)
D=rng.uniform(0,1,N); eta=np.sqrt(1-D**2); alpha=rng.uniform(-np.pi,np.pi,N); sigma=rng.uniform(0,1.5,N)
base=A*A+B*B; cross=2*A*B
coherent=base+cross*np.cos(phi)
marker=base+cross*eta*np.cos(phi)
feedback=base+cross*np.cos(phi+alpha)
stochastic=base+cross*np.exp(-.5*sigma**2)*np.cos(phi+alpha)
V0=cross/base; Vm=eta*V0; Vf=V0; Vs=np.exp(-.5*sigma**2)*V0
checks={}
def add(name, ok, detail): checks[name]={"passed":bool(ok),"detail":detail}
add("nonnegative_coherent", coherent.min()>=-1e-12, f"min={coherent.min():.6g}")
add("nonnegative_marker", marker.min()>=-1e-12, f"min={marker.min():.6g}")
add("protocol_changes_law", np.mean(np.abs(marker-coherent))>1e-2, f"MAD={np.mean(np.abs(marker-coherent)):.6g}")
add("protocol_reduces_visibility", np.all(Vm<=V0+1e-12), f"mean_delta={np.mean(Vm-V0):.6g}")
add("visibility_distinguishability_identity", np.max(np.abs((Vm/V0)**2+D**2-1))<1e-10, "Vrel^2+D^2=1")
add("deterministic_feedback_shifts_not_damps", np.max(np.abs(Vf-V0))<1e-12, "visibility unchanged")
add("unresolved_feedback_can_damp", np.all(Vs<=V0+1e-12), f"mean_delta={np.mean(Vs-V0):.6g}")
# Conditional complementary patterns preserve the unconditional sum.
pe=rng.uniform(-np.pi,np.pi,N); c=rng.uniform(.1,.95,N)
Ip=.5*(1+c*np.cos(pe)); Im=.5*(1-c*np.cos(pe))
add("conditional_patterns", np.std(Ip)>.05 and np.std(Im)>.05, "complementary fringes")
add("unconditioned_sum_invariant", np.max(np.abs(Ip+Im-1))<1e-12, "sum=1")
# Silent hidden extension.
h=rng.normal(size=(N,5)); ext=marker+0*h[:,0]
add("silent_hidden_extension", np.array_equal(ext,marker), "five hidden coordinates invisible")
mse_coarse=float(np.mean((coherent-marker)**2)); mse_protocol=float(np.mean((marker-marker)**2))
add("reject_passive_coarse_graining", mse_coarse>mse_protocol+1e-8, f"MSE={mse_coarse:.6g} vs {mse_protocol:.6g}")
result={"seed":SEED,"samples":N,"checks":checks,"passed":sum(x["passed"] for x in checks.values()),"total":len(checks),
"verdict":{"coarse_graining":"post-law only; cannot explain changed pre-readout interference law",
"protocol_dependence":"changes retained cross-term",
"feedback":"changes later phase/continuation; unresolved feedback can damp ensembles",
"conditioning":"changes conditional partitions, not unconditional sum",
"latent_ontology":"not identified"}}
result["all_passed"]=result["passed"]==result["total"]
Path("light_observation_influence_battery_standalone.json").write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
