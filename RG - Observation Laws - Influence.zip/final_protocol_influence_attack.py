"""Final protocol-influence and matched-marginal non-identifiability attack.
Seed 20260819. Operational two-path laws; not a derivation of quantum mechanics.
"""
import json
from pathlib import Path
import numpy as np

SEED = 20260819
N = 240000
BINS = 160
rng = np.random.default_rng(SEED)

# Controlled phase scan and heterogeneous but known amplitudes.
phi = rng.uniform(-np.pi, np.pi, N)
A = rng.uniform(0.55, 1.45, N)
B = rng.uniform(0.55, 1.45, N)
base = A*A + B*B
cross = 2*A*B
eta = rng.uniform(0.08, 0.98, N)

# Three mechanisms with exactly matched unconditional first-order laws.
I_direct = base + cross * eta * np.cos(phi)
sigma = np.sqrt(-2.0 * np.log(eta))
theta = np.arccos(eta)
I_gaussian_expectation = base + cross * np.exp(-0.5*sigma*sigma) * np.cos(phi)
I_symmetric_expectation = base + cross * np.cos(theta) * np.cos(phi)

# Single-run hidden phases for mechanisms B/C; their ensemble means match A.
alpha_gaussian = rng.normal(0.0, sigma)
sign = rng.choice(np.array([-1.0, 1.0]), size=N)
alpha_symmetric = sign * theta
I_gaussian_run = base + cross*np.cos(phi + alpha_gaussian)
I_symmetric_run = base + cross*np.cos(phi + alpha_symmetric)

# Normalized residual Y = (I-base)/cross. Under direct attenuation it is deterministic;
# under hidden phase mechanisms it fluctuates conditionally on (phi, eta).
y_direct = eta*np.cos(phi)
y_gauss = np.cos(phi + alpha_gaussian)
y_sym = np.cos(phi + alpha_symmetric)

# Complementary record channels for symmetric mechanism. If the hidden sign is recorded,
# conditioned means are distinct and mechanism becomes identifiable.
y_sym_plus = np.cos(phi + theta)
y_sym_minus = np.cos(phi - theta)

checks = {}
def add(name, passed, detail, value=None, threshold=None):
    d = {"passed": bool(passed), "detail": detail}
    if value is not None: d["value"] = float(value)
    if threshold is not None: d["threshold"] = float(threshold)
    checks[name] = d

max_ag = np.max(np.abs(I_direct-I_gaussian_expectation))
max_as = np.max(np.abs(I_direct-I_symmetric_expectation))
add("matched_marginal_direct_vs_gaussian", max_ag < 1e-12,
    "Analytic unconditional intensity laws coincide.", max_ag, 1e-12)
add("matched_marginal_direct_vs_symmetric", max_as < 1e-12,
    "Analytic unconditional intensity laws coincide.", max_as, 1e-12)

# Bin empirical single-run mechanisms by (phi, eta), compare means to direct law.
phi_edges = np.linspace(-np.pi, np.pi, 21)
eta_edges = np.linspace(0.08, 0.98, 11)
mean_errors_g=[]; mean_errors_s=[]; var_g=[]; var_s=[]; var_d=[]
for i in range(len(phi_edges)-1):
    for j in range(len(eta_edges)-1):
        m=(phi>=phi_edges[i])&(phi<phi_edges[i+1])&(eta>=eta_edges[j])&(eta<eta_edges[j+1])
        if m.sum() >= 500:
            target=np.mean(y_direct[m])
            mean_errors_g.append(np.mean(y_gauss[m])-target)
            mean_errors_s.append(np.mean(y_sym[m])-target)
            var_g.append(np.var(y_gauss[m]-eta[m]*np.cos(phi[m])))
            var_s.append(np.var(y_sym[m]-eta[m]*np.cos(phi[m])))
            var_d.append(np.var(y_direct[m]-eta[m]*np.cos(phi[m])))
rmse_g=float(np.sqrt(np.mean(np.square(mean_errors_g))))
rmse_s=float(np.sqrt(np.mean(np.square(mean_errors_s))))
add("empirical_gaussian_mean_matches", rmse_g < 0.025,
    "Binned empirical mean matches direct attenuation.", rmse_g, 0.025)
add("empirical_symmetric_mean_matches", rmse_s < 0.025,
    "Binned empirical mean matches direct attenuation.", rmse_s, 0.025)

# First marginal cannot identify mechanism.
first_order_spread=max(max_ag,max_as)
add("first_order_mechanism_nonidentifiability", first_order_spread < 1e-12,
    "Three distinct mechanisms have the same first-order phase-scan law.", first_order_spread, 1e-12)

# Repeated/conditional measurements distinguish via residual variance and fourth moment.
res_g=y_gauss-y_direct; res_s=y_sym-y_direct; res_d=y_direct-y_direct
vg=float(np.mean(np.square(res_g))); vs=float(np.mean(np.square(res_s))); vd=float(np.mean(np.square(res_d)))
add("repeat_statistics_separate_direct_from_gaussian", vg > 0.02,
    "Gaussian hidden phase has nonzero conditional residual variance.", vg, 0.02)
add("repeat_statistics_separate_direct_from_symmetric", vs > 0.02,
    "Symmetric hidden phase has nonzero conditional residual variance.", vs, 0.02)

m4g=float(np.mean(res_g**4)); m4s=float(np.mean(res_s**4))
ratio=abs(m4g-m4s)/max(m4g,m4s)
add("higher_residual_moment_separates_hidden_mechanisms", ratio > 0.08,
    "Fourth residual moments distinguish Gaussian and two-point phase mixtures.", ratio, 0.08)

# With sign record, conditioned channels are separated; without it they average to direct law.
cond_sep=float(np.mean(np.abs(y_sym_plus-y_sym_minus)))
cond_avg=np.max(np.abs(0.5*(y_sym_plus+y_sym_minus)-y_direct))
add("record_conditioning_separates_symmetric_channels", cond_sep > 0.1,
    "Recorded phase-sign channels have different conditional laws.", cond_sep, 0.1)
add("forgetting_record_restores_matched_marginal", cond_avg < 1e-12,
    "Averaging complementary channels exactly restores the direct marginal.", cond_avg, 1e-12)

# Passive detector coarse-graining cannot alter a pre-readout law, but can erase distinctions afterward.
# Here a two-bin phase readout is applied to all mechanisms' already generated laws.
bin_id=(phi>=0).astype(int)
def bin_mean(y): return np.array([np.mean(y[bin_id==k]) for k in (0,1)])
coarse_direct=bin_mean(y_direct)
coarse_expect_g=bin_mean(np.exp(-0.5*sigma*sigma)*np.cos(phi))
coarse_expect_s=bin_mean(np.cos(theta)*np.cos(phi))
coarse_err=max(np.max(np.abs(coarse_direct-coarse_expect_g)),np.max(np.abs(coarse_direct-coarse_expect_s)))
add("post_readout_coarse_graining_preserves_matched_status", coarse_err < 1e-12,
    "A common readout map cannot recover a distinction absent from its input marginal.", coarse_err, 1e-12)

# Protocol quotient: define five named protocols by observable coefficient gamma.
protocols={
    "open": complex(1.0,0.0),
    "marker_A": complex(0.6,0.0),
    "marker_B_same_law": complex(0.6,0.0),
    "phase_shift": complex(0.6*np.cos(0.7),0.6*np.sin(0.7)),
    "blocked": complex(0.0,0.0),
}
classes=[]; used=set(); tol=1e-12
for p,g in protocols.items():
    if p in used: continue
    cls=[q for q,h in protocols.items() if abs(g-h)<tol]
    used.update(cls); classes.append(cls)
add("protocol_quotient_merges_same_observable_effect", any(len(c)>1 for c in classes),
    f"Protocol effect classes={classes}")
add("protocol_quotient_separates_phase_and_magnitude", len(classes)==4,
    f"Five named protocols produce four observable-effect classes.", len(classes), 4)

# Causal order safeguard: later conditioning only partitions stored records.
stored_unconditional=0.5*(y_sym_plus+y_sym_minus)
later_recombined=0.5*y_sym_plus+0.5*y_sym_minus
retro=np.max(np.abs(stored_unconditional-later_recombined))
add("conditioning_no_retroactive_marginal_change", retro < 1e-12,
    "Conditioning changes sublaws; recombination preserves the stored marginal.", retro, 1e-12)

# Silent latent extension remains unidentifiable.
hidden=rng.normal(size=(N,7))
extended=I_direct+0.0*hidden[:,0]
hidden_err=np.max(np.abs(extended-I_direct))
add("silent_latent_extension_invariant", hidden_err < 1e-15,
    "Seven silent latent coordinates leave the law unchanged.", hidden_err, 1e-15)

passed=sum(v["passed"] for v in checks.values()); total=len(checks)
result={
    "seed":SEED,"samples":N,"checks":checks,"passed":passed,"total":total,"all_passed":passed==total,
    "metrics":{
        "empirical_mean_rmse_gaussian":rmse_g,"empirical_mean_rmse_symmetric":rmse_s,
        "residual_variance_gaussian":vg,"residual_variance_symmetric":vs,
        "fourth_moment_gaussian":m4g,"fourth_moment_symmetric":m4s,
        "fourth_moment_relative_gap":ratio,"conditioned_channel_mean_absolute_separation":cond_sep
    },
    "protocol_effect_classes":classes,
    "verdict":{
        "single_marginal":"Insufficient: direct attenuation, Gaussian phase mixing, and symmetric phase mixing are exactly matched.",
        "minimal_additional_structure":"Repeated conditional statistics separate direct attenuation from hidden phase mixtures; a recorded marker channel separates complementary sublaws; higher residual moments distinguish tested hidden mixtures.",
        "coarse_graining":"A post-readout map cannot explain a changed pre-readout law and cannot recover mechanism distinctions absent from the input marginal.",
        "protocol_influence":"Represent by the protocol-indexed observable law or complex interference coefficient, not by an untyped subtraction of abstract laws.",
        "back_action":"Requires a record-dependent transition kernel and is not implied by visibility reduction alone.",
        "ontology":"Not identified; silent latent extensions survive all observable tests."
    }
}
Path('/mnt/data/final_protocol_influence_attack.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({"passed":passed,"total":total,"all_passed":passed==total,"metrics":result["metrics"],"classes":classes},indent=2))
