import json, hashlib
from pathlib import Path
import numpy as np, pandas as pd
import h5py
from scipy.stats import kurtosis
from scipy.linalg import subspace_angles

FILES={'H1':'/mnt/data/H-H1_GWOSC_O4a_16KHZ_R1-1368424448-4096.hdf5.txt','L1':'/mnt/data/L-L1_GWOSC_O4a_16KHZ_R1-1368977408-4096.hdf5.txt'}
FS=16384; WSEC=4; NWIN=FS*WSEC; BLOCK_WINDOWS=64
BANDS=[(20,80),(80,300),(300,1000),(1000,2048),(2048,4096),(4096,8192)]
FEATS=['log_std','log_maxabs','log_kurtosis']+[f'logP_{a}_{b}' for a,b in BANDS]
EPS=[1e-2,1e-3,1e-4]

def sha(p):
 h=hashlib.sha256();
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()

def extract(det,p):
 rows=[]; freqs=np.fft.rfftfreq(NWIN,1/FS); masks=[(freqs>=a)&(freqs<(b if b<FS/2 else b+1)) for a,b in BANDS]
 with h5py.File(p,'r') as f:
  d=f['strain/Strain']; gps=int(f['meta/GPSstart'][()]); dur=int(f['meta/Duration'][()])
  for j in range(len(d)//NWIN):
   x=np.asarray(d[j*NWIN:(j+1)*NWIN],float)
   ps=np.abs(np.fft.rfft(x))**2/NWIN**2
   kap=kurtosis(x,fisher=False,bias=False)
   vals=[np.log(np.std(x)+1e-40),np.log(np.max(np.abs(x))+1e-40),np.log(kap+1e-40)]
   bp=[float(ps[m].sum()) for m in masks]; vals += [np.log(v+1e-80) for v in bp]
   rho=sum((2*np.pi*np.sqrt(a*b))**2*v for (a,b),v in zip(BANDS,bp))
   rows.append([det,j,gps+j*WSEC,j//BLOCK_WINDOWS,*vals,np.log(rho+1e-80)])
 return pd.DataFrame(rows,columns=['detector','window','gps','block',*FEATS,'log_rho']),gps,dur

def cov(A): return np.cov(A,rowvar=False)
def eig(C):
 e,V=np.linalg.eigh(C); ix=np.argsort(e)[::-1]; return e[ix],V[:,ix]
def spec(C):
 e,_=eig(C); r=e/e[0]; p=e/e.sum()
 return {'relative_eigenvalues':r.tolist(),'ranks':{str(x):int((r>x).sum()) for x in EPS},'participation_rank':float(1/(p@p)),'entropy_rank':float(np.exp(-(p*np.log(p+1e-300)).sum()))}
def powm(C,p):
 e,V=np.linalg.eigh((C+C.T)/2); e=np.maximum(e,1e-12); return (V*(e**p))@V.T
def bures_map(CH,CL):
 h=powm(CH,.5); return powm(CH,-.5)@powm(h@CL@h,.5)@powm(CH,-.5)
def relerr(A,B): return float(np.linalg.norm(A-B,'fro')/np.linalg.norm(B,'fro'))
def tensor_stats(df,mu,sd):
 out=[]
 for b,g in df.groupby('block'):
  Z=(g[FEATS].to_numpy()-mu)/sd; C=cov(Z); e,V=eig(C); k=int(np.searchsorted(np.cumsum(e)/e.sum(),.95)+1)
  out.append((int(b),C,e,V,k))
 return out

frames=[]; meta={}
for d,p in FILES.items():
 f,gps,dur=extract(d,p); frames.append(f); meta[d]={'gps':gps,'duration':dur,'sha256':sha(p)}
F=pd.concat(frames,ignore_index=True); F.to_csv('/mnt/data/rg_h1_l1_tensor_features.csv',index=False)
D={d:F[F.detector==d].copy() for d in FILES}
# detector-global standardization (each independently), preserving correlation tensors
norm={}; blocks={}; overall={}
for d,df in D.items():
 mu=df[FEATS].mean().to_numpy(); sd=df[FEATS].std(ddof=1).to_numpy(); norm[d]=(mu,sd)
 Z=(df[FEATS].to_numpy()-mu)/sd; overall[d]=cov(Z); blocks[d]=tensor_stats(df,mu,sd)
# local proper 95% sector stability between adjacent blocks
local={}
for d in FILES:
 angles=[]; ks=[]
 for _,C,e,V,k in blocks[d]: ks.append(k)
 kstar=int(np.median(ks))
 for a,b in zip(blocks[d][:-1],blocks[d][1:]): angles.append(float(subspace_angles(a[3][:,:kstar],b[3][:,:kstar]).max()))
 local[d]={'spectrum':spec(overall[d]),'block_k95':ks,'median_k95':kstar,'adjacent_max_angles_rad':angles,'median_adjacent_max_angle_rad':float(np.median(angles)),'max_adjacent_max_angle_rad':float(np.max(angles))}
# train/test covariance transport: first 8 blocks train, last 8 held out
train_ids=set(range(8)); test_ids=set(range(8,16))
def avgC(d,ids): return np.mean([x[1] for x in blocks[d] if x[0] in ids],axis=0)
CHtr,CLtr=avgC('H1',train_ids),avgC('L1',train_ids); A=bures_map(CHtr,CLtr)
diag=np.diag(np.sqrt(np.diag(CLtr)/np.diag(CHtr)))
# random orthogonal controls, deterministic
rng=np.random.default_rng(31072026); random_maps=[]
for _ in range(1000):
 Q,_=np.linalg.qr(rng.normal(size=(9,9))); random_maps.append(Q)
held=[]
for bh,bl in zip([x for x in blocks['H1'] if x[0] in test_ids],[x for x in blocks['L1'] if x[0] in test_ids]):
 C1,C2=bh[1],bl[1]
 vals={'block':bh[0],'identity':relerr(C1,C2),'diagonal':relerr(diag@C1@diag.T,C2),'bures':relerr(A@C1@A.T,C2)}
 errs=[relerr(Q@C1@Q.T,C2) for Q in random_maps]
 vals['random_median']=float(np.median(errs)); vals['random_best']=float(np.min(errs)); vals['bures_random_percentile']=float(np.mean(np.array(errs)<=vals['bures'])*100)
 held.append(vals)
# Null mixing: compare transport keeping rank at eps 1e-2 and adding rejected dimensions
rH=spec(CHtr)['ranks']['0.01']; eH,VH=eig(CHtr); eL,VL=eig(CLtr)
null=[]
for k in range(rH,10):
 # map eigenbasis with variance scaling through first k; identity zero outside => projected tensor
 Ak=VL[:,:k]@np.diag(np.sqrt(eL[:k]/eH[:k]))@VH[:,:k].T
 es=[]
 for bh,bl in zip([x for x in blocks['H1'] if x[0] in test_ids],[x for x in blocks['L1'] if x[0] in test_ids]): es.append(relerr(Ak@bh[1]@Ak.T,bl[1]))
 null.append({'retained_k':k,'mean_test_error':float(np.mean(es))})
# placement reconstruction
rhoerr={}
for d,df in D.items():
 rr=np.zeros(len(df))
 for a,b in BANDS: rr+=(2*np.pi*np.sqrt(a*b))**2*np.exp(df[f'logP_{a}_{b}'].to_numpy())
 rhoerr[d]=float(np.max(np.abs(np.log(rr)-df.log_rho.to_numpy())))
# permutation negative control of target blocks (all derangements-ish random)
perm=[]
Ls=[x for x in blocks['L1'] if x[0] in test_ids]; Hs=[x for x in blocks['H1'] if x[0] in test_ids]
obs=float(np.mean([x['bures'] for x in held]))
for _ in range(10000):
 idx=rng.permutation(len(Ls)); perm.append(np.mean([relerr(A@Hs[i][1]@A.T,Ls[idx[i]][1]) for i in range(len(Hs))]))
results={'metadata':meta,'feature_names':FEATS,'bands_hz':BANDS,'window_seconds':WSEC,'block_seconds':WSEC*BLOCK_WINDOWS,'overall':{d:local[d] for d in FILES},'transport':{'train_blocks':sorted(train_ids),'test_blocks':sorted(test_ids),'heldout':held,'means':{k:float(np.mean([x[k] for x in held])) for k in ['identity','diagonal','bures','random_median','random_best']},'observed_bures_mean':obs,'permutation_p_le':float((1+np.sum(np.array(perm)<=obs))/(1+len(perm))),'permutation_median':float(np.median(perm))},'null_mixing':null,'placement_log_error':rhoerr}
Path('/mnt/data/rg_h1_l1_tensor_attack_results.json').write_text(json.dumps(results,indent=2))
Path('/mnt/data/rg_h1_l1_tensor_attack_summary.txt').write_text(json.dumps(results,indent=2))
print(json.dumps({'overall':results['overall'],'transport':results['transport'],'null_mixing':null,'placement':rhoerr},indent=2))
