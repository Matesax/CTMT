# RG H1-L1 tensor and degeneracy attack

## Result

The attack supports detector-local automated observable tensors and nontrivial proper-subspace dynamics, but it does not support unique physical H1-to-L1 transport from these unmatched records.

- H1 ranks: 7 at 1e-2; 9 at 1e-3. Median 95% block dimension: 5.
- L1 ranks: 5 at 1e-2; 8 at 1e-3. Median 95% block dimension: 3.
- Median adjacent proper-subspace angle: H1 0.34736 rad; L1 0.11131 rad.
- Held-out covariance error: identity 0.56740; diagonal 0.61643; fitted Bures map 0.48356.
- The Bures result is not pairing-specific: permutation p=0.91551 and permuted median error 0.44121.
- Retaining 7, 8, or 9 directions gives errors 0.43932, 0.43896, and 0.43911: rejected directions do not materially help, but uniqueness is not established.
- Placement reconstruction error is 1.42e-14 for both detectors.

## Correct interpretation

The tensors can be constructed reproducibly and transported statistically better than identity on ordinally paired held-out blocks. However, because the records are noncontemporaneous and the observed pairing performs no better than random target-block permutations, the learned map is a detector-distribution alignment, not a physical common-source transport. A physical-direction or unique tensor-transport claim still requires contemporaneous H1-L1 data containing common events, hardware/software injections, or response functions.
