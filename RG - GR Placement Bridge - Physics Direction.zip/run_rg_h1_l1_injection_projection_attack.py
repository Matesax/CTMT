import json, hashlib
from pathlib import Path
import numpy as np
import h5py

FILES={
'H1':'/mnt/data/H-H1_GWOSC_O4a_16KHZ_R1-1368424448-4096.hdf5.txt',
'L1':'/mnt/data/L-L1_GWOSC_O4a_16KHZ_R1-1368977408-4096.hdf5.txt'}
FS=16384; T=4; N=FS*T; NW=256; SEED=31072026
rng=np.random.default_rng(SEED)

def sha256(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()

def read_windows(p,nw):
 with h5py.File(p,'r') as f:
  d=f['strain/Strain']; gps=int(f['meta/GPSstart'][()])
  # spread windows across record, avoiding a contiguous-only conclusion
  ids=np.linspace(0,len(d)//N-1,nw,dtype=int)
  X=np.stack([np.asarray(d[i*N:(i+1)*N],dtype=float) for i in ids])
 return X,ids,gps

# Two orthonormal quadrature chirp templates: controlled latent source directions.
t=np.arange(N)/FS
f0,f1=35.0,350.0
k=(f1-f0)/T
phase=2*np.pi*(f0*t+0.5*k*t*t)
env=np.sin(np.pi*t/T)**2
q1=env*np.cos(phase); q2=env*np.sin(phase)
q1-=q1.mean(); q1/=np.linalg.norm(q1)
q2-=q2.mean(); q2-=q1*np.dot(q1,q2); q2/=np.linalg.norm(q2)
Q=np.stack([q1,q2])

raw={}; meta={}
for d,p in FILES.items():
 X,ids,gps=read_windows(p,NW); raw[d]=X
 meta[d]={'gps_start':gps,'window_ids':ids.tolist(),'sha256':sha256(p)}

# Detector-local matched-filter noise coordinates, robustly standardized.
noise_coord={}; scales={}
for d,X in raw.items():
 C=X@Q.T
 med=np.median(C,axis=0); mad=1.4826*np.median(np.abs(C-med),axis=0)
 mad=np.where(mad>0,mad,np.std(C,axis=0,ddof=1))
 noise_coord[d]=(C-med)/mad; scales[d]={'median':med.tolist(),'mad':mad.tolist()}

# Same latent source sequence is projected into independent real H1/L1 backgrounds.
S=rng.normal(size=(NW,2))
S-=S.mean(0); S/=S.std(0,ddof=1)
Qtrue=np.cov(S,rowvar=False)
# A physical sign/direction test uses source vectors, tensor test uses second moments.
responses={
 'well_conditioned':np.array([[1.0,0.20],[0.30,0.90]]),
 'near_degenerate':np.array([[1.0,0.20],[0.98,0.22]]),
 'rank_one':np.array([[1.0,0.20],[2.0,0.40]])}
snr_levels=[0.5,1.0,2.0,4.0,8.0]

def angle_rows(A,B):
 num=np.sum(A*B,axis=1); den=np.linalg.norm(A,axis=1)*np.linalg.norm(B,axis=1)
 return np.arccos(np.clip(num/np.maximum(den,1e-15),-1,1))

def relfro(A,B): return float(np.linalg.norm(A-B,'fro')/np.linalg.norm(B,'fro'))

def projector_null(A,tol=1e-10):
 u,s,vt=np.linalg.svd(A,full_matrices=True); r=np.sum(s>s[0]*tol)
 Vr=vt[:r].T; Vn=vt[r:].T
 return Vr@Vr.T, Vn@Vn.T, s, int(r)

results={'seed':SEED,'samples_per_window':N,'window_seconds':T,'windows':NW,'metadata':meta,'scales':scales,'responses':{}}
for name,A in responses.items():
 Pr,Pn,sv,rank=projector_null(A)
 case={'matrix':A.tolist(),'singular_values':sv.tolist(),'rank':rank,'condition_number':float(sv[0]/sv[-1]) if sv[-1]>1e-15 else None,'snr':{}}
 # fixed null vector if present
 if rank<2:
  _,_,vt=np.linalg.svd(A); nvec=vt[-1]; nvec/=np.linalg.norm(nvec)
 else: nvec=None
 for snr in snr_levels:
  # Real noise coordinates plus known response projection.
  Y=np.column_stack([noise_coord['H1'][:,0],noise_coord['L1'][:,0]]) + snr*(S@A.T)
  Ainv=np.linalg.pinv(A,rcond=1e-10)
  Shat=(Y@Ainv.T)/snr
  Str=S@Pr
  Shr=Shat@Pr
  ang=angle_rows(Shr,Str)
  Qt=np.cov(Str,rowvar=False); Qh=np.cov(Shr,rowvar=False)
  residual=Y-snr*(Shat@A.T)
  item={
   'median_resolved_direction_error_rad':float(np.median(ang)),
   'p90_resolved_direction_error_rad':float(np.quantile(ang,.9)),
   'resolved_source_relative_error':float(np.linalg.norm(Shr-Str)/np.linalg.norm(Str)),
   'resolved_tensor_relative_error':relfro(Qh,Qt),
   'sensor_residual_relative_norm':float(np.linalg.norm(residual)/np.linalg.norm(Y))}
  if nvec is not None:
   alpha=rng.normal(size=(NW,1))*3.0
   Snull=S+alpha*nvec
   delta=(Snull@A.T)-(S@A.T)
   item['null_injection_relative_sensor_change']=float(np.linalg.norm(delta)/np.linalg.norm(S@A.T))
   item['null_source_rms']=float(np.sqrt(np.mean((alpha*nvec)**2)))
   # observable equivalence after reconstruction
   H0=(S@Pr); H1=(Snull@Pr)
   item['resolved_equivalence_error']=float(np.linalg.norm(H1-H0)/np.linalg.norm(H0))
  case['snr'][str(snr)]=item
 results['responses'][name]=case

# Near-null threshold attack: rank as a function of relative singular threshold.
A=responses['near_degenerate']; sv=np.linalg.svd(A,compute_uv=False)
results['near_degenerate_threshold_sweep']={str(eps):int(np.sum(sv/sv[0]>eps)) for eps in [1e-1,5e-2,1e-2,5e-3,1e-3]}
Path('/mnt/data/rg_h1_l1_injection_projection_results.json').write_text(json.dumps(results,indent=2))
Path('/mnt/data/rg_h1_l1_injection_projection_summary.txt').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
