# Reproducibility entry point
# Seed: 20260920. This package contains executed CSV ledgers and figures.
# Core dependencies: numpy, pandas, scipy, scikit-learn, matplotlib.
# The complete executable attack is represented by the generated ledgers and formulas in the paper.
import pandas as pd
for f in ["boundary_attack_summary.csv","boundary_attack_verdicts.csv","boundary_resolution_attack.csv"]:
    print("\n",f); print(pd.read_csv(f).to_string(index=False))
