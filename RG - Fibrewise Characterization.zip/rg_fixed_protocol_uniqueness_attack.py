import itertools
import json
from pathlib import Path
import numpy as np

SEED = 20260805
rng = np.random.default_rng(SEED)

# One fixed declared admissible experiment (E, Gamma).
# Work in a G-orthonormal information eigenbasis; all protocol data are frozen.
lambda_info = np.array([0.18, 0.42, 0.91, 1.37, 2.15, 3.80])
tau = 1.0
nuisance = np.array([False, True, False, False, False, True])
stable = np.array([True, True, True, True, True, True])
conditioned = np.array([True, True, False, True, True, True])
coarse_graining_compatible = np.array([True, True, True, True, False, True])
transport_compatible = np.array([True, True, True, True, True, True])

resolved_mask = lambda_info > tau
gate_mask = (~nuisance & stable & conditioned & coarse_graining_compatible & transport_compatible)
canonical_admissible = resolved_mask & gate_mask

# Exhaust all hard spectral observable-sector assignments in this fixed protocol.
# A candidate is represented by a binary projector mask and a final admissible mask.
projector_masks = [np.array(x, dtype=bool) for x in itertools.product([False, True], repeat=6)]
sector_masks = [np.array(x, dtype=bool) for x in itertools.product([False, True], repeat=6)]

# Ledger counts after successively imposing fixed-protocol RG observation rules.
counts = {
    'all_competitors': 0,
    'extensional_and_spectral': 0,
    'hard_projector_axioms': 0,
    'threshold_consistency': 0,
    'gate_soundness': 0,
    'gate_completeness': 0,
    'transport_naturality': 0,
    'product_composition': 0,
    'final_survivors': 0,
}

survivors = []
near_misses = {k: None for k in [
    'threshold_consistency', 'gate_soundness', 'gate_completeness',
    'transport_naturality', 'product_composition'
]}

# Fixed nontrivial experiment automorphism: swap equal-role coordinates 0 and 1 only
# for a separate duplicated test object. Main spectrum is simple, so commuting hard
# projectors are exactly spectral masks. Naturality is tested on a transported copy.
perm = np.array([2, 0, 1, 5, 3, 4])
invperm = np.argsort(perm)

for pm in projector_masks:
    for wm in sector_masks:
        counts['all_competitors'] += 1

        # E1 and S3: representative-independent, information-compatible spectral maps.
        # In this eigenbasis every binary mask is a spectral hard map.
        counts['extensional_and_spectral'] += 1

        # S1/S2: binary diagonal maps are idempotent and G-self-adjoint.
        counts['hard_projector_axioms'] += 1

        # S4: the fixed tau forces the resolved projector exactly.
        if not np.array_equal(pm, resolved_mask):
            if near_misses['threshold_consistency'] is None:
                near_misses['threshold_consistency'] = {'P': pm.tolist(), 'W': wm.tolist()}
            continue
        counts['threshold_consistency'] += 1

        # Gate soundness: W may contain no direction rejected by P or Gamma.
        allowed = pm & gate_mask
        if np.any(wm & ~allowed):
            if near_misses['gate_soundness'] is None:
                near_misses['gate_soundness'] = {'P': pm.tolist(), 'W': wm.tolist()}
            continue
        counts['gate_soundness'] += 1

        # Gate completeness/maximality: every direction accepted by all declared gates
        # must be retained. Without this axiom, arbitrary strict subspaces survive.
        if not np.array_equal(wm, allowed):
            if near_misses['gate_completeness'] is None:
                near_misses['gate_completeness'] = {'P': pm.tolist(), 'W': wm.tolist()}
            continue
        counts['gate_completeness'] += 1

        # E2: transport the complete fixed protocol and require conjugate masks.
        pm_t = pm[invperm]
        wm_t = wm[invperm]
        canonical_pm_t = resolved_mask[invperm]
        canonical_wm_t = canonical_admissible[invperm]
        if not (np.array_equal(pm_t, canonical_pm_t) and np.array_equal(wm_t, canonical_wm_t)):
            if near_misses['transport_naturality'] is None:
                near_misses['transport_naturality'] = {'P': pm.tolist(), 'W': wm.tolist()}
            continue
        counts['transport_naturality'] += 1

        # Product consistency: direct sum with a fixed two-mode experiment.
        lam_b = np.array([0.7, 1.8])
        nuis_b = np.array([False, False])
        gates_b = np.array([True, True])
        p_b = lam_b > tau
        w_b = p_b & ~nuis_b & gates_b
        direct_p = np.concatenate([pm, p_b])
        direct_w = np.concatenate([wm, w_b])
        canonical_direct_p = np.concatenate([resolved_mask, p_b])
        canonical_direct_w = np.concatenate([canonical_admissible, w_b])
        if not (np.array_equal(direct_p, canonical_direct_p) and np.array_equal(direct_w, canonical_direct_w)):
            if near_misses['product_composition'] is None:
                near_misses['product_composition'] = {'P': pm.tolist(), 'W': wm.tolist()}
            continue
        counts['product_composition'] += 1
        counts['final_survivors'] += 1
        survivors.append({'P': pm.tolist(), 'W': wm.tolist()})

# Independence witness: after the projector is fixed, count sectors under soundness only
# versus soundness + completeness.
allowed = canonical_admissible
sound_sectors = [m for m in sector_masks if not np.any(m & ~allowed)]
complete_sectors = [m for m in sound_sectors if np.array_equal(m, allowed)]

# Continuous non-spectral/oblique alternatives are attacked numerically.
def random_orthogonal(n):
    q, r = np.linalg.qr(rng.normal(size=(n, n)))
    q = q @ np.diag(np.sign(np.diag(r)))
    return q

oblique_failures = []
for _ in range(128):
    q = random_orthogonal(6)
    d = np.diag(canonical_admissible.astype(float))
    # Similarity by a nonorthogonal shear: idempotent but generally not self-adjoint/commuting.
    s = np.eye(6) + 0.2 * rng.normal(size=(6, 6))
    while abs(np.linalg.det(s)) < 1e-4:
        s = np.eye(6) + 0.2 * rng.normal(size=(6, 6))
    p = s @ d @ np.linalg.inv(s)
    oblique_failures.append({
        'idempotence': float(np.linalg.norm(p @ p - p)),
        'self_adjointness': float(np.linalg.norm(p.T - p)),
        'information_commutator': float(np.linalg.norm(p @ np.diag(lambda_info) - np.diag(lambda_info) @ p)),
    })

result = {
    'title': 'Fixed-protocol RG observable-geometry uniqueness attack',
    'seed': SEED,
    'fixed_protocol': {
        'information_spectrum': lambda_info.tolist(),
        'tau': tau,
        'nuisance_mask': nuisance.tolist(),
        'stability_mask': stable.tolist(),
        'conditioning_mask': conditioned.tolist(),
        'coarse_graining_mask': coarse_graining_compatible.tolist(),
        'transport_mask': transport_compatible.tolist(),
        'canonical_resolved_mask': resolved_mask.tolist(),
        'canonical_admissible_mask': canonical_admissible.tolist(),
    },
    'exhaustive_counts': counts,
    'final_survivors': survivors,
    'independence': {
        'sound_sectors_without_completeness': len(sound_sectors),
        'sectors_with_soundness_and_completeness': len(complete_sectors),
        'finding': 'Gate soundness alone does not characterize W_obs|adm; maximal gate completeness is necessary.'
    },
    'continuous_attack_128_oblique_projectors': {
        'max_idempotence_error': max(x['idempotence'] for x in oblique_failures),
        'min_self_adjointness_error': min(x['self_adjointness'] for x in oblique_failures),
        'min_information_commutator': min(x['information_commutator'] for x in oblique_failures),
        'survivors_all_projector_rules': sum(
            x['idempotence'] < 1e-10 and x['self_adjointness'] < 1e-10 and x['information_commutator'] < 1e-10
            for x in oblique_failures
        )
    },
    'admissibility_ledger': {
        'primitive': '(E,Gamma), not E alone',
        'quotient': 'forced by observational extensionality',
        'metric': 'Fisher-Rao forced only in the stated regular finite classical metric module',
        'hard_resolved_projector': 'unique conditional on fixed F,G,tau off the discriminant',
        'admissible_sector': 'unique only if gate soundness is paired with gate completeness/maximality',
        'transported_copies': 'unique up to natural isomorphism when the full protocol is transported',
        'global_atlas': 'unique relative to the declared transition data and cocycle; not across different connections/holonomy classes',
        'protocol_selection': 'outside theorem; no claim that E selects Gamma'
    },
    'verdict': {
        'finite_fixed_protocol_uniqueness': counts['final_survivors'] == 1,
        'survivor': survivors[0] if len(survivors) == 1 else None,
        'missing_axiom_detected': 'gate completeness/maximality',
        'theorem_supported': 'For a fixed RG-admissible (E,Gamma), the finite hard-spectral local observable geometry is unique under extensionality, the Fisher module, hard-projector axioms, gate soundness plus completeness, natural transport, and product composition.',
        'not_supported': [
            'protocol-free uniqueness',
            'selection of Gamma from E',
            'infinite-dimensional or singular uniqueness',
            'uniqueness across undeclared transport/holonomy classes'
        ]
    }
}

out = Path('/mnt/data/rg_fixed_protocol_uniqueness_attack.json')
out.write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(counts, indent=2))
print(json.dumps(result['independence'], indent=2))
print(json.dumps(result['verdict'], indent=2))
