import numpy as np
np.set_printoptions(precision=6, suppress=True)

def idx(t, x, Nt, Nx):
    return t * Nx + x

def build_operator(Nt, Nx, theta, m2=0.7, kind="euclidean"):
    N = Nt * Nx
    Lt = np.zeros((N, N)); Lx = np.zeros((N, N))
    for t in range(Nt):
        for x in range(Nx):
            p = idx(t, x, Nt, Nx)
            Lt[p, p] += 2
            Lt[p, idx((t - 1) % Nt, x, Nt, Nx)] -= 1
            Lt[p, idx((t + 1) % Nt, x, Nt, Nx)] -= 1
            Lx[p, p] += 2
            Lx[p, idx(t, (x - 1) % Nx, Nt, Nx)] -= 1
            Lx[p, idx(t, (x + 1) % Nx, Nt, Nx)] -= 1
    mass = m2 * np.diag(np.exp(2 * theta.reshape(-1)))
    if kind == "euclidean":
        A = Lt + Lx + mass
    elif kind == "lorentzian":
        A = -Lt + Lx + mass
    else:
        raise ValueError(kind)
    return 0.5 * (A + A.T)

def split_checker(Nt, Nx):
    R, N = [], []
    for t in range(Nt):
        for x in range(Nx):
            (R if (t + x) % 2 == 0 else N).append(idx(t, x, Nt, Nx))
    return np.array(R, dtype=int), np.array(N, dtype=int)

def resolved_field(R, Nt, Nx):
    vals = []
    for p in R:
        t, x = p // Nx, p % Nx
        vals.append(np.cos(2*np.pi*x/Nx - 2*np.pi*t/Nt) + 0.25*np.sin(4*np.pi*x/Nx + 0.7))
    return np.array(vals)

def schur(A, R, N):
    ARR = A[np.ix_(R, R)]
    ARN = A[np.ix_(R, N)]
    ANR = A[np.ix_(N, R)]
    ANN = A[np.ix_(N, N)]
    return ARR - ARN @ np.linalg.solve(ANN, ANR)

def eliminate(A, R, N, r):
    ANR = A[np.ix_(N, R)]
    ANN = A[np.ix_(N, N)]
    nstar = -np.linalg.solve(ANN, ANR @ r)
    phi = np.zeros(A.shape[0])
    phi[R] = r; phi[N] = nstar
    return phi, nstar

def action(A, phi):
    return 0.5 * float(phi @ A @ phi)

def run(Nt=16, Nx=16, kind="euclidean", h=1e-6):
    T, X = np.meshgrid(np.arange(Nt), np.arange(Nx), indexing="ij")
    theta = 0.18*np.cos(2*np.pi*X/Nx) + 0.07*np.sin(2*np.pi*T/Nt + 0.3)
    R, N = split_checker(Nt, Nx)
    r = resolved_field(R, Nt, Nx)
    A = build_operator(Nt, Nx, theta, kind=kind)
    Aeff = schur(A, R, N)
    phi, nstar = eliminate(A, R, N, r)
    Wobs = 0.5 * float(r @ Aeff @ r)
    Sfull = action(A, phi)
    # local derivative probes
    rng = np.random.default_rng(12345)
    probes = rng.choice(np.arange(Nt*Nx), size=12, replace=False)
    maxerr = 0.0
    for p in probes:
        E = np.zeros_like(theta); E.reshape(-1)[p] = 1.0
        def W(theta2):
            A2 = build_operator(Nt, Nx, theta2, kind=kind)
            Aeff2 = schur(A2, R, N)
            return 0.5 * float(r @ Aeff2 @ r)
        def F(theta2):
            A2 = build_operator(Nt, Nx, theta2, kind=kind)
            phi2, _ = eliminate(A2, R, N, r)
            return action(A2, phi2)
        dW = (W(theta + h*E) - W(theta - h*E)) / (2*h)
        dF = (F(theta + h*E) - F(theta - h*E)) / (2*h)
        maxerr = max(maxerr, abs(dW - dF))
    ANN = A[np.ix_(N, N)]
    return {
        "kind": kind,
        "grid": (Nt, Nx),
        "cond_A_NN": np.linalg.cond(ANN),
        "elim_error": abs(Wobs - Sfull),
        "local_gradient_max_error": maxerr,
        "negative_modes_A": int(np.sum(np.linalg.eigvalsh(A) < -1e-10)),
        "negative_modes_Aeff": int(np.sum(np.linalg.eigvalsh(Aeff) < -1e-10)),
    }

if __name__ == "__main__":
    for kind in ["euclidean", "lorentzian"]:
        for N in [8, 12, 16]:
            print(run(N, N, kind))
