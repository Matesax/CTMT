import numpy as np
np.set_printoptions(precision=6, suppress=True)

def D(a,h,axis):
    return (np.roll(a,-1,axis=axis)-np.roll(a,1,axis=axis))/(2*h)

def scalar_stress_variational(phi, dt, dx):
    """Automated stress from scalar action L=-1/2 eta^{ab} d_a phi d_b phi in eta=(-,+).
    Returns contravariant components (T00,T01,T10,T11). No manual coherence->pressure map.
    """
    phit = D(phi, dt, 0)
    phix = D(phi, dx, 1)
    T00 = 0.5*(phit**2 + phix**2)
    T01 = -phit*phix
    T10 = T01.copy()
    T11 = 0.5*(phit**2 + phix**2)
    return T00,T01,T10,T11

def div_norm(T, dt, dx):
    T00,T01,T10,T11 = T
    div0 = D(T00,dt,0) + D(T01,dx,1)
    div1 = D(T10,dt,0) + D(T11,dx,1)
    return float(np.sqrt(np.mean(div0**2 + div1**2)))

def tensor_norm(T):
    return float(np.sqrt(np.mean(sum(A*A for A in T))))

def tensor_diff_norm(A,B):
    return float(np.sqrt(np.mean(sum((A[i]-B[i])**2 for i in range(4)))))

def addT(A,B):
    return tuple(A[i]+B[i] for i in range(4))

def subT(A,B):
    return tuple(A[i]-B[i] for i in range(4))

def manual_map(phiN, dt, dx, lam=0.6):
    # A deliberately tempting but non-variational map: hidden energy scalar -> density/pressure by hand.
    TN = scalar_stress_variational(phiN, dt, dx)
    EN = TN[0]
    Z = np.zeros_like(EN)
    return lam*EN, Z, Z, 0.18*EN

def build_grid(N):
    L=2*np.pi
    t=np.linspace(0,L,N,endpoint=False)
    x=np.linspace(0,L,N,endpoint=False)
    dt=L/N; dx=L/N
    T,X=np.meshgrid(t,x,indexing='ij')
    return T,X,dt,dx

def build_field(T,X, eps=0.20, reparam_scale=1.0, offshell=False):
    # resolved mode: on-shell right-moving massless scalar
    phiR = np.cos(2*(X-T))
    if offshell:
        # deliberately violates massless equation -> should trigger exchange current rather than conservation
        phiN_phys = eps*np.cos(3*X - 1.7*T + 0.4)
    else:
        # on-shell hidden mode -> closed conservative sector
        phiN_phys = eps*np.cos(3*(X-T)+0.4)
    # Hidden coordinate representation y=s*phiN; quotient inverse recovers physical phiN=y/s.
    y_hidden = reparam_scale*phiN_phys
    return phiR, phiN_phys, y_hidden

def run_case(N=256, eps=0.20, scale=1.0, offshell=False):
    T,X,dt,dx = build_grid(N)
    phiR, phiN_phys, y = build_field(T,X,eps=eps,reparam_scale=scale,offshell=offshell)
    # automated quotient-aware inverse: physical hidden field is y/scale
    phiN_inv = y/scale
    phi_full = phiR + phiN_inv

    T_R = scalar_stress_variational(phiR,dt,dx)
    T_full_auto = scalar_stress_variational(phi_full,dt,dx)
    Delta_auto = subT(T_full_auto,T_R)
    T_eff_auto = addT(T_R,Delta_auto)

    T_manual_delta = manual_map(y,dt,dx)       # wrong: uses hidden coordinate y directly
    T_eff_manual = addT(T_R,T_manual_delta)

    return {
        'N': N,
        'eps': eps,
        'scale': scale,
        'offshell': offshell,
        'gate1_symmetry_auto': float(np.sqrt(np.mean((T_eff_auto[1]-T_eff_auto[2])**2))),
        'gate1_symmetry_manual': float(np.sqrt(np.mean((T_eff_manual[1]-T_eff_manual[2])**2))),
        'gate2_null_delta_norm_auto': tensor_norm(Delta_auto),
        'gate3_div_R': div_norm(T_R,dt,dx),
        'gate3_div_full_auto': div_norm(T_full_auto,dt,dx),
        'gate3_div_eff_auto': div_norm(T_eff_auto,dt,dx),
        'gate3_div_eff_manual': div_norm(T_eff_manual,dt,dx),
        'gate5_known_recovery_auto': tensor_diff_norm(T_eff_auto,T_full_auto),
        'gate5_known_recovery_manual': tensor_diff_norm(T_eff_manual,T_full_auto),
        'gate6_nontrivial_delta_norm_auto': tensor_norm(Delta_auto),
        'manual_delta_norm': tensor_norm(T_manual_delta),
    }

def summarize():
    print('FINAL MASSLESS SCALAR AUTOMATED GR-SYMBOL PIPELINE BATTERY')
    print('\nA. Closed on-shell hidden sector: conservation should hold')
    for N in [64,128,256,512]:
        r=run_case(N=N,eps=0.20,scale=1.0,offshell=False)
        print(r)
    print('\nB. Null reduction eps=0: correction must vanish')
    for N in [128,256]:
        r=run_case(N=N,eps=0.0,scale=1.0,offshell=False)
        print(r)
    print('\nC. Hidden-coordinate quotient attack: scale y=s*phi_N. Auto must be invariant; manual should fail')
    r1=run_case(N=256,eps=0.20,scale=1.0,offshell=False)
    r3=run_case(N=256,eps=0.20,scale=3.0,offshell=False)
    print('scale1', r1)
    print('scale3', r3)
    print('manual_norm_ratio=', r3['manual_delta_norm']/r1['manual_delta_norm'])
    print('auto_delta_ratio=', r3['gate6_nontrivial_delta_norm_auto']/r1['gate6_nontrivial_delta_norm_auto'])
    print('manual_div_ratio=', r3['gate3_div_eff_manual']/r1['gate3_div_eff_manual'])
    print('auto_div_ratio=', r3['gate3_div_eff_auto']/r1['gate3_div_eff_auto'])
    print('\nD. Off-shell hidden sector: conservation should fail and be classified as exchange current required')
    for N in [128,256]:
        r=run_case(N=N,eps=0.20,scale=1.0,offshell=True)
        print(r)

if __name__ == '__main__':
    summarize()
