"""
RG-GR source-side automation battery (corrected & annotated).

HONEST READING OF WHAT EACH GATE TESTS
--------------------------------------
The 'auto' effective tensor is  T_eff_auto = T[phi_R] + (T[phi_full]-T[phi_R]) = T[phi_full].
So by construction it EQUALS the full variational tensor. Therefore:
  * gate5 'recovery' and the eps=0 'null reduction' are DEFINITIONAL consistency checks,
    not independent tests (they must pass by algebra);
  * 'auto conservation on-shell' is the STANDARD field-theory fact that the variational
    stress tensor of an on-shell field is conserved -- not an RG result;
  * the only DISCRIMINATING comparison is against the hand-built 'manual' map, which fails
    the structural gates. That is a rejection-of-ad-hoc-assignment result, on ONE sector.
Test D is corrected here: the original off-shell mode cos(3x-1.7t) is NOT periodic in the
2*pi time-box, so roll-based derivatives hit a boundary discontinuity and the 'divergence'
diverges with grid size (artifact). A box-periodic off-shell mode gives a convergent
exchange current, which is the honest quantity.
"""
import numpy as np
np.set_printoptions(precision=6, suppress=True)

def D(a,h,axis): return (np.roll(a,-1,axis=axis)-np.roll(a,1,axis=axis))/(2*h)
def stress(phi,dt,dx):
    pt=D(phi,dt,0); px=D(phi,dx,1)
    e=0.5*(pt**2+px**2); f=-pt*px
    return e,f,f,e
def divn(T,dt,dx):
    T00,T01,T10,T11=T
    return float(np.sqrt(np.mean((D(T00,dt,0)+D(T01,dx,1))**2+(D(T10,dt,0)+D(T11,dx,1))**2)))
def tnorm(T): return float(np.sqrt(np.mean(sum(A*A for A in T))))
def tdiff(A,B): return float(np.sqrt(np.mean(sum((A[i]-B[i])**2 for i in range(4)))))
def grid(N):
    L=2*np.pi; t=np.linspace(0,L,N,endpoint=False); x=np.linspace(0,L,N,endpoint=False)
    T,X=np.meshgrid(t,x,indexing='ij'); return T,X,L/N,L/N
def manual_delta(EN): return EN*0.6, np.zeros_like(EN), np.zeros_like(EN), 0.18*EN

def run(N=256, eps=0.2, scale=1.0, off_omega=None):
    T,X,dt,dx=grid(N)
    phiR=np.cos(2*(X-T))
    if off_omega is None: phiN=eps*np.cos(3*(X-T)+0.4)          # on-shell hidden mode
    else:                 phiN=eps*np.cos(3*X-off_omega*T+0.4)  # off-shell (box-periodic if off_omega integer)
    y=scale*phiN                                                # hidden COORDINATE (reparametrized)
    phiN_inv=y/scale                                            # quotient-aware inverse -> physical field
    T_R=stress(phiR,dt,dx); T_full=stress(phiR+phiN_inv,dt,dx)
    T_eff_auto=T_full                                           # = T_R + (T_full - T_R), definitionally
    EN_manual=stress(y,dt,dx)[0]                                # manual map uses the RAW coordinate y (wrong)
    dman=manual_delta(EN_manual); T_eff_man=tuple(T_R[i]+dman[i] for i in range(4))
    return dict(N=N,eps=eps,scale=scale,
        div_auto=divn(T_eff_auto,dt,dx), div_manual=divn(T_eff_man,dt,dx),
        recovery_auto=tdiff(T_eff_auto,T_full), recovery_manual=tdiff(T_eff_man,T_full),
        manual_delta_norm=tnorm(dman))

print("A. on-shell closed sector (auto conserved = standard; manual has divergence floor):")
for N in [64,128,256,512]:
    r=run(N=N); print(f"   N={N:4d}  div_auto={r['div_auto']:.2e}  div_manual={r['div_manual']:.4f}"
                       f"  rec_auto={r['recovery_auto']:.1e}  rec_manual={r['recovery_manual']:.3f}")
print("B. null reduction eps=0 (definitional: auto delta must vanish):")
for N in [128,256]:
    r=run(N=N,eps=0.0); print(f"   N={N:4d}  div_auto={r['div_auto']:.2e}  recovery_auto={r['recovery_auto']:.1e}")
print("C. hidden-coordinate quotient y=s*phiN (auto invariant by design; manual scales ~ s^2):")
r1=run(scale=1.0); r3=run(scale=3.0)
print(f"   manual_delta_norm ratio (s=3/s=1) = {r3['manual_delta_norm']/r1['manual_delta_norm']:.2f}  (=9=s^2)")
print(f"   auto div ratio = {r3['div_auto']/r1['div_auto']:.3f}  (=1, invariant)")
print("D. off-shell exchange current -- CORRECTED to box-periodic mode (convergent, not artifact):")
for om,tag in [(1.7,'1.7t NON-periodic (artifact)'),(2.0,'2t box-periodic (honest)')]:
    vals=[run(N=N,off_omega=om)['div_auto'] for N in [128,256,512]]
    print(f"   {tag:32s} div_auto @128/256/512 = {vals[0]:.3f} / {vals[1]:.3f} / {vals[2]:.3f}")
print("   -> honest exchange current is the convergent ~1.43; the growing 10/43/208 is a periodicity artifact.")
