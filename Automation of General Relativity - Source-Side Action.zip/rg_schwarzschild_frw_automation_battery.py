import numpy as np
from scipy.optimize import minimize, brentq
np.set_printoptions(precision=6, suppress=True)

def idx(t,x,Nt,Nx): return t*Nx+x

def split_checker(Nt,Nx):
    R=[]; N=[]
    for t in range(Nt):
        for x in range(Nx):
            (R if (t+x)%2==0 else N).append(idx(t,x,Nt,Nx))
    return np.array(R,dtype=int), np.array(N,dtype=int)

def resolved_field(R,Nt,Nx,amp=0.48):
    vals=[]
    for p in R:
        t=p//Nx; x=p%Nx
        vals.append(amp*np.cos(2*np.pi*x/Nx-2*np.pi*t/Nt)+0.13*np.sin(4*np.pi*x/Nx+0.4))
    return np.array(vals)

def build_weighted_K(Nt,Nx,wt_face,wx_face,periodic_x=True):
    N=Nt*Nx; K=np.zeros((N,N))
    for t in range(Nt):
        for x in range(Nx):
            i=idx(t,x,Nt,Nx); j=idx((t+1)%Nt,x,Nt,Nx)
            w=wt_face[t,x]
            K[i,i]+=w; K[j,j]+=w; K[i,j]-=w; K[j,i]-=w
    xmax=Nx if periodic_x else Nx-1
    for t in range(Nt):
        for x in range(xmax):
            i=idx(t,x,Nt,Nx); j=idx(t,(x+1)%Nx,Nt,Nx)
            w=wx_face[t,x if x<Nx-1 else 0]
            K[i,i]+=w; K[j,j]+=w; K[i,j]-=w; K[j,i]-=w
    return 0.5*(K+K.T)

def minimize_hidden(K,pot_weight,theta_param,R,Nidx,r,m2=0.7,lam=0.12,n0=None,scale=1.0):
    Vw=pot_weight.reshape(-1)*np.exp(2*theta_param.reshape(-1))
    total=K.shape[0]
    if n0 is None: n0=np.zeros(len(Nidx))
    z0=scale*n0
    def unpack(z): return z/scale
    def fun(z):
        n=unpack(z); phi=np.zeros(total); phi[R]=r; phi[Nidx]=n
        return 0.5*float(phi@K@phi)+float(np.sum(Vw*(0.5*m2*phi**2+0.25*lam*phi**4)))
    def jac(z):
        n=unpack(z); phi=np.zeros(total); phi[R]=r; phi[Nidx]=n
        grad=K@phi+Vw*(m2*phi+lam*phi**3)
        return grad[Nidx]/scale
    res=minimize(fun,z0,jac=jac,method='L-BFGS-B',options={'gtol':1e-12,'ftol':1e-14,'maxiter':2000})
    return res.fun, unpack(res.x), res, Vw

def envelope_check(K,pot_base,R,Nidx,r,Nt,Nx,nstar,sites,h=1e-5):
    theta0=np.zeros((Nt,Nx))
    _,_,_,Vw0=minimize_hidden(K,pot_base,theta0,R,Nidx,r,n0=nstar)
    phi=np.zeros(Nt*Nx); phi[R]=r; phi[Nidx]=nstar
    errs=[]; vals=[]
    for p in sites:
        E=np.zeros((Nt,Nx)); E.reshape(-1)[p]=1.0
        Wp,_,_,_=minimize_hidden(K,pot_base,theta0+h*E,R,Nidx,r,n0=nstar)
        Wm,_,_,_=minimize_hidden(K,pot_base,theta0-h*E,R,Nidx,r,n0=nstar)
        fd=(Wp-Wm)/(2*h)
        ex=2*Vw0[p]*(0.5*0.7*phi[p]**2+0.25*0.12*phi[p]**4)
        errs.append(abs(fd-ex)); vals.append(abs(ex))
    return max(errs), max(errs)/(1e-12+max(vals))

def frw_background(Nt,Nx):
    eta=np.arange(Nt)
    a=1.0+0.22*np.sin(2*np.pi*eta/Nt+0.2)+0.08*np.cos(4*np.pi*eta/Nt)
    wt=np.ones((Nt,Nx)); wx=np.ones((Nt,Nx)); pot=np.repeat((a*a)[:,None],Nx,axis=1)
    return wt,wx,pot,{'a_min':float(a.min()),'a_max':float(a.max())},True

def tortoise(r,M): return r+2*M*np.log(r/(2*M)-1)

def invert_tortoise(rs,M):
    lo=2*M*(1+1e-10); hi=max(10*M,rs+10*M)
    while tortoise(hi,M)<rs: hi*=2
    return brentq(lambda r: tortoise(r,M)-rs,lo,hi,maxiter=100)

def schwarzschild_background(Nt,Nx,M=1.0,rmin=6.0,rmax=20.0):
    rs_min=tortoise(rmin,M); rs_max=tortoise(rmax,M)
    rstars=np.linspace(rs_min,rs_max,Nx)
    r=np.array([invert_tortoise(s,M) for s in rstars])
    f=1-2*M/r
    r2=r*r
    wt=np.repeat(r2[None,:],Nt,axis=0)
    r2face=np.zeros(Nx)
    for x in range(Nx-1): r2face[x]=0.5*(r2[x]+r2[x+1])
    r2face[-1]=r2face[-2]
    wx=np.repeat(r2face[None,:],Nt,axis=0)
    pot=np.repeat((r2*f)[None,:],Nt,axis=0)
    meta={'r_min':float(r.min()),'r_max':float(r.max()),'f_min':float(f.min()),'f_max':float(f.max())}
    return wt,wx,pot,meta,False

def run_case(background,Nt,Nx):
    if background=='FRW': wt,wx,pot,meta,periodic_x=frw_background(Nt,Nx)
    else: wt,wx,pot,meta,periodic_x=schwarzschild_background(Nt,Nx)
    K=build_weighted_K(Nt,Nx,wt,wx,periodic_x=periodic_x)
    R,Nidx=split_checker(Nt,Nx); r=resolved_field(R,Nt,Nx)
    theta0=np.zeros((Nt,Nx))
    W,nstar,res,Vw=minimize_hidden(K,pot,theta0,R,Nidx,r)
    phi=np.zeros(Nt*Nx); phi[R]=r; phi[Nidx]=nstar
    grad=K@phi+Vw*(0.7*phi+0.12*phi**3)
    stat=float(np.linalg.norm(grad[Nidx],np.inf))
    rel_stat=stat/(1.0+float(np.linalg.norm(grad, np.inf)))
    rng=np.random.default_rng(271828)
    sites=np.sort(rng.choice(np.arange(Nt*Nx),size=12,replace=False))
    env_abs,env_rel=envelope_check(K,pot,R,Nidx,r,Nt,Nx,nstar,sites,h=1e-5)
    W3,n3,_,_=minimize_hidden(K,pot,theta0,R,Nidx,r,n0=nstar,scale=3.0)
    K0=K.copy(); K0[np.ix_(R,Nidx)]=0; K0[np.ix_(Nidx,R)]=0
    W0,n0,_,Vw0=minimize_hidden(K0,pot,theta0,R,Nidx,r)
    phi0=np.zeros(Nt*Nx); phi0[R]=r
    resolved_only=0.5*float(phi0@K0@phi0)+float(np.sum(Vw0*(0.5*0.7*phi0**2+0.25*0.12*phi0**4)))
    return dict(background=background,grid=f'{Nt}x{Nx}',Wobs=float(W),success=bool(res.success),
                stationarity_inf=stat,stationarity_rel=rel_stat,envelope_abs=float(env_abs),envelope_rel=float(env_rel),
                quotient_W_error_s3=float(abs(W3-W)),quotient_phiN_rel_error_s3=float(np.linalg.norm(n3-nstar)/(1e-12+np.linalg.norm(nstar))),
                null_hidden_norm=float(np.linalg.norm(n0)),null_action_error=float(abs(W0-resolved_only)),**meta)

if __name__=='__main__':
    for bg in ['FRW','Schwarzschild']:
        for N in [8,10,12]:
            print(run_case(bg,N,N))
