from pathlib import Path
from bs4 import BeautifulSoup
import ast,json,hashlib,subprocess,os
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--source',default='RMI + Terror Kernel.txt');ap.add_argument('--out',default='archive_rerun');args=ap.parse_args()
root=Path(args.out);root.mkdir(exist_ok=True,parents=True);work=root;dest=work/'embedded';dest.mkdir(exist_ok=True)
p=Path(args.source); raw=p.read_text(); soup=BeautifulSoup(raw,'html.parser')
sections=[]
for i,sec in enumerate(soup.find_all('section')):
 text=sec.get_text('\n',strip=True);(work/f'archive_section_{i}.txt').write_text(text)
 sections.append(dict(index=i,title=sec.find(['h2','h3']).get_text(' ',strip=True),characters=len(text),headings=[h.get_text(' ',strip=True) for h in sec.find_all(['h2','h3','h4'])]))
blocks=[]
for i,pre in enumerate(soup.find_all('pre')):
 code=pre.get_text(); file=dest/f'block_{i:02d}.py';file.write_text(code)
 prev=pre.find_previous(['h2','h3','h4']);row=dict(index=i,heading=prev.get_text(' ',strip=True) if prev else None,sha256=hashlib.sha256(code.encode()).hexdigest(),characters=len(code))
 try:
  tree=ast.parse(code);row['python_syntax']=True;row['functions']=[n.name for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.ClassDef))]
 except SyntaxError as e:row['python_syntax']=False;row['syntax_error']=str(e)
 if i in [4,7,8,9,10,21,25,28,29,30]:
  try:
   r=subprocess.run(['python',str(file)],cwd=dest,capture_output=True,text=True,timeout=20,env={**os.environ,'MPLBACKEND':'Agg','OPENBLAS_NUM_THREADS':'1'})
   (dest/f'block_{i:02d}.log').write_text(r.stdout+'\nSTDERR\n'+r.stderr)
   row['execution']=dict(exit_code=r.returncode,stdout_tail=r.stdout[-1000:],stderr_tail=r.stderr[-1000:])
  except subprocess.TimeoutExpired:row['execution']=dict(status='timeout after 20 s')
 blocks.append(row)
result=dict(source=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),lines=len(raw.splitlines()),sections=sections,blocks=blocks,execution_scope='Ten selected blocks invoked independently, including one definitions-only block; all 31 syntax-inventoried. No fragments repaired.')
(root/'rg_origin_archive_audit.json').write_text(json.dumps(result,indent=2))
print('Archive:',len(sections),'sections;',len(blocks),'code blocks;',sum(b['python_syntax'] for b in blocks),'parse as Python; ten execution attempts.')
for b in blocks:
 if 'execution' in b:print(b['index'],b['execution'].get('exit_code',b['execution'].get('status')))
