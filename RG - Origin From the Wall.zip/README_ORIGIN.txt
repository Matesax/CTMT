RG ORIGIN PAPER

Main files:
  RG_Origin_From_the_Wall.tex
  RG_Origin_From_the_Wall.pdf

Scope: retrospective intellectual and mathematical genealogy. Recollections,
archival formulas, and explanatory reconstructions are distinguished. This is
not a dated priority history or an empirical wall-tap dataset.

Build: pdflatex RG_Origin_From_the_Wall.tex (run twice).
Witnesses: python rg_origin_checks.py --out .
Requirements for witnesses: Python, NumPy, SciPy.

The archive audit inventories 31 blocks, of which 26 parse as Python.
Ten selected blocks were invoked independently: nine exit zero, one NameError.
Block 30 only loads definitions; it does not exercise its functions.
No original fragments were silently repaired. See JSON and execution logs.

To repeat archive extraction against your original source:
python rg_origin_audit_archive.py --source "RMI + Terror Kernel.txt" --out archive_rerun
Requires BeautifulSoup and the dependencies imported by the original examples.
The original archive and source PDFs are not bundled; their hashes are recorded.

Fourteen companion witnesses pass. They are mathematical examples, not
empirical data or proof of the whole RG programme.
