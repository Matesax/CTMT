#!/usr/bin/env python3
"""Analytic/numerical witnesses for the RG origin paper. Not empirical data.
Run: python rg_origin_checks.py --out .
"""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
from scipy.linalg import expm

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',default='.');args=ap.parse_args();out=Path(args.out);out.mkdir(exist_ok=True,parents=True)
 rows=[]
 def add(i,name,ok,**e):rows.append(dict(id=i,name=name,passed=bool(ok),evidence=e))
 # Perfect phase agreement, but only the sum is observed.
 J=np.array([[1.,1.]]); order=abs(np.mean(np.exp(1j*np.zeros(2))))
 add('OC01','Coherent aggregate is not identifiable',order==1 and np.linalg.matrix_rank(J)==1,order_parameter=order,rank=int(np.linalg.matrix_rank(J)),latent_dimension=2,equal_means=[1+2,0+3])
 # Labelled antiphase channels: order parameter zero, full-rank amplitude map.
 phases=np.array([0.,np.pi]); J=np.diag([1.,-1.]);order=abs(np.mean(np.exp(1j*phases)))
 add('OC02','Phase cancellation does not preclude labelled identification',order<1e-14 and np.linalg.matrix_rank(J)==2,order_parameter=order,rank=2,protocol='two separately observed signed channels')
 # Power spectrum erases absolute shift.
 h=np.zeros(64);h[4]=1;h[8]=.4;h2=np.roll(h,7)
 defect=float(np.max(abs(abs(np.fft.fft(h))**2-abs(np.fft.fft(h2))**2)))
 add('OC03','Power spectrum does not determine delay',defect<1e-12,power_defect=defect,shift_samples=7)
 # Regularization chooses among a true fibre.
 A=np.array([[1.,1.]]);y=np.array([3.]);R1=np.diag([1.,1.]);R2=np.diag([1.,4.]);lam=1e-5
 k1=np.linalg.solve(A.T@A+lam*R1,A.T@y);k2=np.linalg.solve(A.T@A+lam*R2,A.T@y)
 add('OC04','Regularized uniqueness is not observational uniqueness',np.linalg.norm(k1-k2)>.5 and abs((A@k1-A@k2)[0])<1e-4,solution1=k1.tolist(),solution2=k2.tolist(),prediction_difference=float(abs((A@k1-A@k2)[0])))
 # Local rank does not give global separation; x^3 has zero derivative but injective.
 add('OC05','Rank and global separation differ',True,square_equal_values=[(-2.)**2,2.**2],square_derivatives=[-4.,4.],cube_derivative_at_zero=0.,cube_injective=True)
 # Statistical null is not a Lorentz null direction.
 F=np.diag([1.,0.]);eta=np.diag([1.,-1.]);v=np.array([1.,1.]);w=np.array([0.,1.])
 add('OC06','Statistical and causal nulls differ',np.linalg.norm(F@w)==0 and v@eta@v==0 and np.linalg.norm(eta@v)>0,fisher_kernel_vector=w.tolist(),lorentz_null_vector=v.tolist(),lorentz_radical_dimension=0)
 # Flat Gaussian Fisher line changes with noise, physical length does not.
 sig=np.array([1.,2.,10.]);D=100.;lf=D/sig
 add('OC07','Flat Fisher geometry does not fix metres',np.ptp(lf)>0,physical_length_m=D,noise_sd_m=sig.tolist(),fisher_lengths=lf.tolist(),curvature='zero for every noise scale')
 # Common error is invisible to route agreement.
 estimates=np.array([5.,5.,5.])+2;truth=5.
 add('OC08','Route agreement cannot detect common bias',np.ptp(estimates)==0 and np.mean(estimates)-truth==2,route_values=estimates.tolist(),truth=truth,common_bias=2.)
 # Correlated driving creates covariance without dynamical feedback.
 B=np.diag([-1.,-2.]);Q=np.array([[1.,.4],[.4,1.]])
 from scipy.linalg import solve_continuous_lyapunov
 C=solve_continuous_lyapunov(B,-Q)
 add('OC09','Covariance is not a feedback kernel',abs(C[0,1])>.01 and B[0,1]*B[1,0]==0,cross_covariance=float(C[0,1]),feedback_kernel=0.)
 # Elimination formula, nonzero bidirectional coupling.
 A=np.array([[-1.,.3],[.2,-2.]])
 from scipy.integrate import solve_ivp
 t=np.linspace(0,1,101);full=solve_ivp(lambda t,x:A@x,[0,1],[1.,0.],t_eval=t,rtol=1e-11,atol=1e-12).y
 # memory auxiliary z'=xR-2z; xR'=-xR+.06z
 reduced=solve_ivp(lambda t,x:np.array([-x[0]+.06*x[1],x[0]-2*x[1]]),[0,1],[1.,0.],t_eval=t,rtol=1e-11,atol=1e-12).y
 err=float(np.max(abs(full[0]-reduced[0])))
 add('OC10','Elimination produces conditional memory',err<1e-9,max_resolved_error=err,memory_kernel='0.06 exp(-2 t)')
 # Gauge shear changes lift while preserving observation.
 J=np.array([[1.,0.]]);S=np.array([[1.,0.],[3.,1.]]);b=np.array([1.,0.])
 add('OC11','Observable law does not select latent lift',np.max(abs(J@S-J))==0 and np.linalg.norm(S@b-b)>0,law_change=float(np.max(abs(J@S-J))),lift_change=float(np.linalg.norm(S@b-b)))
 # Invariant metrics under exchange not selected.
 p=np.linspace(.1,.9,9);ratio=1/(p*(1-p))
 add('OC12','Relabelling invariance is not metric uniqueness',np.max(abs(ratio-ratio[::-1]))<1e-12 and np.ptp(ratio)>1,metric_ratio_range=[float(min(ratio)),float(max(ratio))])
 # Cone alone scale ambiguity.
 eta=np.diag([1.,-1.]);ray=np.array([1.,1.])
 add('OC13','Cone does not determine scale',ray@eta@ray==0 and ray@(7*eta)@ray==0,scales=[1.,7.],same_null_ray=True)
 # Non-transitive threshold relation.
 add('OC14','Threshold closeness is not exact equivalence',.75<=1 and .75<=1 and 1.5>1,points=[0.,.75,1.5],threshold=1.)
 result=dict(origin='mathematical witnesses, no observational dataset',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),checks=rows,all_pass=all(r['passed'] for r in rows))
 (out/'rg_origin_checks.json').write_text(json.dumps(result,indent=2));print('Origin witnesses:',sum(r['passed'] for r in rows),'/',len(rows))
 assert result['all_pass']
if __name__=='__main__':main()
