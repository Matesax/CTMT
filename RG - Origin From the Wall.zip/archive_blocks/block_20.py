import numpy as np
import pandas as pd

# Number of samples
N = 10000

# Parameters
omega = np.random.normal(loc=2.42e15, scale=1.0e13, size=N)
sigma = 0.3  # rupture volatility
Xi = np.random.lognormal(mean=0.0, sigma=sigma, size=N)  # rupture field
Sstar = 6.626e-34 / (2 * np.pi)  # action scale [J·s]
Cphys = 1.0  # normalized prefactor

# Phase model
tau = 1.0e-9  # delay [s]
alpha = 2.0e-30  # curvature [J·s·Hz⁻²]
Phi = omega * tau + alpha * omega**2

# Terror kernel (real part)
T = Cphys * Xi * np.cos(Phi / Sstar)

# Diagnostics
mean_T = T.mean()
std_T = T.std()
R = std_T / np.abs(mean_T)

print(f"Mean T[K]: {mean_T:.5e}")
print(f"Std deviation: {std_T:.5e}")
print(f"Rupture ratio R: {R:.3f}")

# Save to CSV
df = pd.DataFrame({
    "omega": omega,
    "Xi": Xi,
    "Phi": Phi,
    "TerrorKernel": T
})
df.to_csv("terror_kernel.csv", index=False)
print("CSV saved as terror_kernel.csv")
