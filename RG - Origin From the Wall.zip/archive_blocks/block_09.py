#!/usr/bin/env python3
"""TUCF demonstration: temporal kernel, uncertainty propagation, rupture masking,
χ² diagnostics, information proxy, and invariant flux tracking."""
import numpy as np, math
from scipy.signal import get_window, correlate
np.random.seed(0)
# --- Parameters ---
fs = 2000; T = 2.0
t = np.linspace(0, T, int(fs*T), endpoint=False)
f0 = 20.0; ω = 2*np.pi*f0
Δt = 0.2; Nw = int(Δt*fs); hop = Nw//4
window = get_window('hann', Nw)
σ_noise = 0.05; τ = 1.5; ε_stab = 1e-10
# --- Synthetic signal with rupture ---
env = 1+0.3*np.sin(2*np.pi*0.2*t)
sig = env*np.sin(ω*t)
mask = (t>0.8)&(t<1.1)
rupt_factor = np.ones_like(t)
rupt_factor[mask] = np.random.lognormal(0,0.8,mask.sum())
sig_r = sig*rupt_factor
sig_r[int(1.4*fs):int(1.4*fs)+5]+=2*np.hanning(5)
obs = sig_r + np.random.normal(scale=σ_noise,size=sig.shape)
# --- Sliding windows ---
idxs = np.arange(0,len(t)-Nw+1,hop)
chi2, info, Φ, vol = [], [], [], []
for i in idxs:
    w = slice(i,i+Nw); tt = t[w]
    o = obs[w]*window
    A = (np.sin(ω*tt)[:,None]*window[:,None])
    amp = np.linalg.solve(A.T@A+ε_stab*np.eye(1),A.T@o)
    pred = (A@amp).ravel()
    res = o-pred
    var = σ_noise**2
    χ2 = np.mean((res/var**0.5)**2)
    chi2.append(χ2)
    v = np.std(res)/(np.mean(np.abs(pred))+1e-12); vol.append(v)
    if v>=τ: maskf=0
    else: maskf=1
    pwr = np.abs(np.fft.rfft(o))
    pwr/=pwr.sum()+1e-12
    H=-np.sum(pwr*np.log(pwr+1e-12))/np.log(len(pwr)+1e-12)
    info.append((1-H)*maskf)
    corr=correlate(o,pred,mode='full')
    lag=np.argmax(np.abs(corr))-(len(o)-1)
    Δt_est=lag/fs
    coh=np.abs(np.mean(np.exp(1j*np.angle(np.fft.fft(o+1e-12)))))
    v_sync=340.0
    Φ.append(v_sync*abs(Δt_est)*coh)
print("Mean χ²:",np.mean(chi2))
print("Mean info proxy:",np.mean(info))
print("Mean Φ_inv:",np.mean(Φ))
print("Max volatility:",max(vol))
