# Given: dataset of displacements x at times t
import numpy as np
from scipy.optimize import curve_fit

def gaussian(x, sigma):
    return np.exp(-x**2 / (2*sigma**2))

# 1. Fit Gaussian to histogram
counts, bins = np.histogram(x_data, bins=50, density=True)
bin_centers = 0.5 * (bins[1:] + bins[:-1])
popt, _ = curve_fit(gaussian, bin_centers, counts)
sigma_est = popt[0]

# 2. Compute diffusion coefficient
D_est = sigma_est**2 / (2 * t)

# 3. Map to kernel parameters
sigma_kernel = (M1 * Theta)**2 / gamma * t
