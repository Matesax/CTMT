# CRSC demo: coherence kernel, rupture manifold, uncertainty propagation, forecasting, recovery
import numpy as np
from numpy.linalg import inv, eigvals, norm
np.random.seed(2)

# --- simple linear forward model (A ~ Jacobian) ---
A = np.array([[1.0, 0.4, -0.2, 0.0],
              [0.3, 1.1,  0.05, 0.1],
              [-0.1,0.2,  0.9, 0.05],
              [0.0, 0.0,  0.2, 1.0]])   # 4 observables, 4 kernel params
p, n = A.shape[1], A.shape[0]

# true kernel parameters and noise
kappa_true = np.array([0.7, -0.3, 0.25, 0.1])
sigma_noise = 0.02
Ceps = np.eye(n) * sigma_noise**2

# observed signal (before rupture)
O_clean = A @ kappa_true
O = O_clean + np.random.multivariate_normal(np.zeros(n), Ceps)

# --- impose a localized rupture on channel 1 and 2 (multiplicative LN) ---
rupt_idx = [0,1]
rupt_scale = 1.2
rupt_factor = np.ones(n)
rupt_factor[rupt_idx] = np.random.lognormal(mean=0.0, sigma=0.8, size=len(rupt_idx))
O_rupt = O * rupt_factor

# --- compute local Hessian / Fisher H = J^T Ceps^{-1} J ---
H = A.T @ inv(Ceps) @ A
eig_H = np.sort(np.real(eigvals(H)))
lambda_min = eig_H[0]

# --- rupture indicator and volatility ---
lambda_crit = 0.5
r = lambda_crit / (lambda_min + 1e-12)
sigma0 = 1.0
sigma_rupt = np.log1p(r) * np.ones(n)
sigma_rupt[rupt_idx] *= rupt_scale

# --- coherence kernel (dimensionless) ---
K_coh = np.exp(-sigma_rupt / sigma0)

# --- rupture-modified covariance ---
gamma_rupt = 1.0
Q_rupt = gamma_rupt * np.diag(sigma_rupt**2)
C_kappa_prior = np.eye(p) * 0.05
C_kappa_rupt = (K_coh[:,None] * C_kappa_prior) * K_coh[None,:] + Q_rupt[:p,:p]

# --- RIP reconstruction with rupture weighting ---
W = np.diag(K_coh)
A_ter = W @ A
O_ter = W @ O_rupt
eps_stab = 1e-8
lhs = A_ter.T @ inv(Ceps + eps_stab*np.eye(n)) @ A_ter + eps_stab*np.eye(p)
rhs = A_ter.T @ inv(Ceps + eps_stab*np.eye(n)) @ O_ter
kappa_rec = inv(lhs) @ rhs

# --- predicted observable & residuals ---
O_rec = A @ kappa_rec
res = O_rupt - O_rec

# --- rupture flux (simple proxy) ---
v_sync = 340.0
Delta_t = 0.12
def spectral_entropy(x):
    P = np.abs(np.fft.rfft(x))**2
    P = P / (P.sum() + 1e-12)
    return -np.sum(P * np.log(P + 1e-12))
info_clean = spectral_entropy(O_clean)
info_rupt  = spectral_entropy(O_rupt)
C_info = 1.0 - (info_rupt / (info_clean + 1e-12))
Phi_rupt = (1.0 - C_info) * v_sync * Delta_t

# --- rupture forecast (finite-difference proxy) ---
H_norm = norm(H, ord='fro')
a1, a2 = 0.7, 0.3
d_info_dt = (info_rupt - info_clean) / 0.01
d_Hinv_dt = 0.0  # placeholder
sigma_rupt_dot = a1 * (-d_info_dt) + a2 * d_Hinv_dt
sigma_rupt_forecast = sigma_rupt + 0.01 * sigma_rupt_dot

# --- recovery / invertibility check ---
F = A_ter.copy()
reg = 1e-6
F_inv = inv(F.T @ F + reg*np.eye(p)) @ F.T
recov_norm = norm(F_inv, ord=2)
kappa_max = 1e4
recoverable = recov_norm < kappa_max

# --- Reporting ---
print("=== CRSC demo results ===")
print("rupture indices:", rupt_idx)
print("rupture factors:", np.round(rupt_factor, 4))
print("lambda_min(H) =", np.round(lambda_min, 6))
print("sigma_rupt =", np.round(sigma_rupt, 4))
print("K_coh =", np.round(K_coh, 4))
print("kappa_rec =", np.round(kappa_rec, 4))
print("residual norm ||res|| =", np.round(norm(res), 6))
print("C_info =", np.round(C_info, 6))
print("Phi_rupt =", np.round(Phi_rupt, 6))
print("sigma_rupt forecast =", np.round(sigma_rupt_forecast, 6))
print("regularized inverse norm =", np.round(recov_norm, 6))
print("recoverable?", recoverable)
