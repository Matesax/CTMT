
# sketch for per-realization time integration
for n in range(N):
    Xi_n = sample_Xi_time_series()
    eps_n = sample_eps_time_series()        # small positive mean
    # integrand(t') = Xi_n(t') * C_phys(t') * Mtilde(omega) * exp(i*Phi(t,t')/S - eps_n(t'))
    integrand = Xi_n * C_phys * Mtilde * np.exp(1j*Phi_dt/Sstar) * np.exp(-eps_n)
    T_n = np.trapz(integrand, t_grid) + sample_eta()
    diagnostics[n] = compute_diagnostics(T_n, integrand, eps_n)
# accept/reweight based on diagnostics, then form ensemble stats
