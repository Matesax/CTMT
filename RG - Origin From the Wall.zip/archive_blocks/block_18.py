
# per-realization regulated factor (sketch)
eps = np.random.normal(loc=eps_mean, scale=eps_sigma, size=(N, ...))
Xi = sample_Xi(...)
Phi = compute_Phi(...)
Sstar = ...
F = Xi * np.exp(1j * Phi / Sstar) * np.exp(-eps)   # regulated per-realization factor
# build K^{(n)}, compute diagnostics, accept/reject, then assemble ensemble
