
import numpy as np

N = 10000
masses = np.random.uniform(1.0, 10.0, N)        # Ensemble weights
sigma_phi = np.random.normal(0.01, 0.005, N)    # Phase volatility field

Xi_mass = np.sum(masses * sigma_phi)
print("Mass-weighted rupture index =", Xi_mass)
