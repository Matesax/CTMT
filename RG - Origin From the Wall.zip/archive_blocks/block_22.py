
import numpy as np

# Parameters
tau = 0.9
S_star = 1
pi_true = np.pi
sigma_0 = 0.6
alpha = 0.5
rounds = 6

# Track π accuracy across rounds
pi_estimates = []
errors = []

for r in range(rounds):
    sigma_r = sigma_0 * (alpha ** r)
    rho_coh = np.exp(sigma_r**2 / 2) * (np.sin(pi_true * tau / S_star) / (pi_true * tau / S_star))
    pi_est = pi_true * tau / S_star * rho_coh / np.exp(sigma_r**2 / 2)
    pi_estimates.append(pi_est)
    errors.append(abs(pi_est - pi_true))

# Display results
for r, (est, err) in enumerate(zip(pi_estimates, errors)):
    print(f"Round {r+1}: π ≈ {est:.10f}, error ≈ {err:.2e}")
