import numpy as np
from numpy.linalg import inv

# --- Forward map and synthetic data ---
np.random.seed(42)
A = np.array([[1.0, 0.5],
              [0.3, 1.2]])
kappa_true = np.array([0.8, -0.4])

sigma_noise = 0.02
Ceps = np.eye(2) * sigma_noise**2
O = A @ kappa_true + np.random.multivariate_normal(mean=np.zeros(2), cov=Ceps)

# --- Regularization ---
lambda_reg = 1e-2
R = np.eye(2)

# --- RIP: reciprocal operator and reconstruction ---
F_star = inv(A.T @ inv(Ceps) @ A + lambda_reg * R.T @ R) @ (A.T @ inv(Ceps))
kappa_rec = F_star @ O

# --- Posterior covariance (linear) ---
C_kappa_lin = inv(A.T @ inv(Ceps) @ A + lambda_reg * R.T @ R)
std_kappa = np.sqrt(np.diag(C_kappa_lin))

# --- χ² normalized residual diagnostic ---
res = O - A @ kappa_rec
chi2 = (res.T @ inv(Ceps) @ res) / (O.size - kappa_rec.size)

# --- ICM proxy: spectral entropy-based compression (simple surrogate) ---
def entropy_power(x):
    p = np.abs(x)**2
    p_sum = p.sum()
    if p_sum == 0:
        return 0.0
    p /= p_sum
    return -np.sum(p * np.log(p + 1e-12))

E_pred = entropy_power(A @ kappa_rec)
E_obs  = entropy_power(O)
C_info = 1.0 - E_pred / (E_obs + 1e-12)

# --- MKP update with χ-coherence calibration and uncertainty propagation ---
# Placeholder χ-coherence measures (replace with CTMT χ-estimates):
chi_meas = 0.8
chi_pred = 0.6
alpha = chi_meas / (chi_pred + chi_meas + 1e-12)  # bounded in [0,1]

O_pred = A @ kappa_rec
O_next = A @ kappa_true + np.random.multivariate_normal(np.zeros(2), Ceps)
O_mkp = O_pred + alpha * (O - O_pred)

# Uncertainty of prediction: Var[\hat O] = alpha^2 Var[O] + (1-alpha)^2 Var[F[kappa]]
C_O = Ceps  # measurement covariance
C_Fk = A @ C_kappa_lin @ A.T  # propagated model prediction covariance
C_Ohat = alpha**2 * C_O + (1 - alpha)**2 * C_Fk
std_Ohat = np.sqrt(np.diag(C_Ohat))

# --- Invariant flux ---
Delta_t = 0.12  # s
rho_coh = 0.94  # coherence density (dimensionless surrogate)
v_sync = 343.0  # m/s (speed of sound)
Phi_inv = v_sync * Delta_t * rho_coh

# Flux relative uncertainty from component uncertainties (example values)
sigma_v = 1.0
sigma_dt = 0.005
sigma_rho = 0.02
rel_var_phi = (sigma_v / v_sync)**2 + (sigma_dt / Delta_t)**2 + (sigma_rho / rho_coh)**2
sigma_phi = abs(Phi_inv) * np.sqrt(rel_var_phi)

# --- Reporting ---
print("RIP κ_rec =", kappa_rec)
print("Posterior std(κ) =", std_kappa)
print("χ² normalized residual =", chi2)

print("ICM C_info =", C_info)

print("MKP prediction =", O_mkp)
print("MKP std per component =", std_Ohat)

print("Invariant flux Φ_inv =", Phi_inv)
print("Invariant flux uncertainty σ_Φ =", sigma_phi)
