# Redundancy aggregation
O_red = redundancy{O1, O2}

# Rigidity filtering
O_rig = rigidity[f]
