
# %% [markdown]
#  Jupyter notebook: Symbolic + numeric derivation for kernel assembly, stationary phase, and anchor checks
#
#  This notebook is runnable. It:
#  - Declares conventions and symbols (sympy)
#  - Implements algebraic factorization M = C_phys * Mtilde and solves unit-balance exponents for a chosen observable
#  - Derives 3D EM mode density (k-space → ν) and recovers Planck spectral law
#  - Performs stationary-phase expansion symbolically for a simple model Φ(ω)
#  - Computes Hessian, prefactor, and verifies unit closure
#  - Runs numeric anchor substitution and Monte Carlo uncertainty propagation
#
#  Replace example numeric anchors with your measured values where noted.
#  Required packages: sympy, numpy, scipy. Install if needed: pip install sympy numpy scipy

# %% [markdown]
### Imports and numeric constants

# %% code
import math
import numpy as np
from math import pi
import sympy as sp
from sympy import symbols, Matrix, sqrt, simplify, Rational
from scipy import integrate

# Fundamental constants (examples; replace or treat as symbols in symbolic sections)
kB_val = 1.380649e-23          # J/K
h_val = 6.62607015e-34         # J*s
hbar_val = h_val / (2*pi)
c_val = 299792458.0            # m/s

# %% [markdown]
### Symbol declarations (symbolic algebra setup)

# %% code
# Spectral and kernel symbols
n, d = symbols('n d', integer=True, positive=True)
Sstar = symbols('Sstar')                 # emergent action scale [J*s]
Phi0 = symbols('Phi0')                   # Φ at stationary point [J*s]
omega = sp.symbols('omega', real=True)   # generic spectral variable
nu = symbols('nu')                       # cycle frequency
k = symbols('k')                         # wavevector magnitude
V = symbols('V')                         # volume [m^3]
L = symbols('L')                         # characteristic length [m]

# C_phys template exponents (to be solved by unit balance)
nc, nL = symbols('nc nL', integer=True)

# Envelope symbols
Mtilde = symbols('Mtilde')               # dimensionless shape (symbolic placeholder)

# Hessian / stationary-phase
# For symbolic stationary-phase we will use a simple scalar or diagonal example H
h11, h22, h33 = symbols('h11 h22 h33')   # Hessian diagonal entries in example

# %% [markdown]
### Algebraic factorization rule and canonical C_phys template (symbolic)
# Solve exponents by unit balance for target observable: spectral energy density u(ν) [J m^-3 Hz^-1].

# %% code
# Template: C_phys = kB*T / Sstar * (2π)^(-d) * c^(-nc) * L^(-nL)
T = symbols('T')  # temperature [K]
C_phys_template = (kB_val * T) / Sstar * (2*pi)**(-d) * sp.Symbol('c')**(-nc) * L**(-nL)
sp.pretty_print(C_phys_template)

# Note: Above uses numeric kB_val for clarity in mixed symbolic/numeric manipulation.
# In a pure symbolic derivation replace kB_val with symbol kB.

# %% [markdown]
### 3D EM mode density derivation (symbolic → numeric sketch)
# Using Fourier inverse normalization (2π)^(-3), derive modes per volume in shell [k, k+dk].

# %% code
# Mode counting expression (symbolic)
modes_per_vol_per_dk = V / (2*pi)**3 * 4*pi * k**2
sp.simplify(modes_per_vol_per_dk)

# Convert k -> ν for photons: ω = c k, ν = ω/(2π) => k = 2π ν / c, dk = 2π dν / c
nu_sym = symbols('nu_sym')
c_sym = symbols('c_sym')
k_from_nu = 2*pi*nu_sym / c_sym
dk_dnu = 2*pi / c_sym
modes_per_vol_per_dnu = (V / (2*pi)**3) * 4*pi * k_from_nu**2 * dk_dnu
modes_per_vol_per_dnu_simpl = sp.simplify(modes_per_vol_per_dnu)
sp.pretty_print(modes_per_vol_per_dnu_simpl)

# Show cancellation of (2π)^3
# Result should be V * 4π * ν^2 / c^3
sp.expand(modes_per_vol_per_dnu_simpl)

# %% [markdown]
### Recover Planck spectral density (symbolic steps)
# u(ν,T) = (modes_per_vol_per_dν / V) * (energy per mode = h ν) * occupancy BE
# Include factor 2 for photon polarizations and factor 1/volume division

# %% code
# Symbolic expression
h, kB_s = symbols('h kB_s')
nu_s = symbols('nu_s', positive=True)
modes_per_vol_per_dnu_expr = (4*pi * nu_s**2) / c_sym**3   # per volume
# include polarizations factor 2 -> 8π ν^2 / c^3
energy_per_mode = h * nu_s
BE = 1 / (sp.exp(h*nu_s/(kB_s*T)) - 1)
u_nu = (8*pi * h * nu_s**3 / c_sym**3) * BE
sp.pretty_print(u_nu)

# Change variable x = h ν / (kB T) to integrate total energy density
x = symbols('x', positive=True)
# u(T) integral symbolic prefactor:
prefactor_uT = 8*pi * kB_s**4 / (h**3 * c_sym**3)
sp.pretty_print(prefactor_uT)

# Integral ∫ x^3/(e^x-1) dx = π^4/15 (will be used numerically)

# %% [markdown]
### Stationary-phase: symbolic scalar example and prefactor derivation
# Use scalar ω (n=1) example with Φ(ω) = Φ0 + 1/2 H (ω-ω0)^2 to show change of variables and prefactor.

# %% code
# Scalar Hessian H (units [Φ]/[ω]^2)
H = symbols('H')
n_val = 1
# Leading-order integral I ≈ C_phys * Mtilde(ω0) * exp(iΦ0/S*) * (2π S*)^{n/2} / sqrt(|det H|)
prefactor_scalar = (2*pi*Sstar)**(Rational(n_val,2)) / sqrt(abs(H))
sp.pretty_print(prefactor_scalar)

# Confirm units: Sstar^(n/2) has same units as sqrt(det H) for cancellation when multiplied with measure dω

# %% [markdown]
### Symbolic Hessian matrix example (n=3 diagonal) and determinant
# Demonstrate determinant scaling and stationary-phase prefactor for n=3.

# %% code
Hmat = Matrix.diag(h11, h22, h33)
detH = sp.simplify(Hmat.det())
prefactor_3d = (2*pi*Sstar)**(Rational(3,2)) / sqrt(abs(detH))
sp.pretty_print(detH)
sp.pretty_print(prefactor_3d)

# %% [markdown]
### Concrete numeric example: compute stationary-phase prefactor for a simple model
# Example model: Φ(ω) = ω τ + α ω^2 ; choose scalar ω, compute H = d^2Φ/dω^2 = 2α.
# Use numeric anchors for α, τ and Sstar = ħ.

# %% code
# Numeric anchors (example values)
tau = 1e-6                     # s (example synchrony delay)
alpha = 1e-34                  # J*s^3 (choose units so Φ has J*s units: α * ω^2 must be J*s)
Sstar_num = hbar_val           # identify S_* = ħ for demo

# For scalar model Φ = ω*tau + 1/2 * 2α ω^2 => second derivative H = 2α
H_num = 2.0 * alpha
# prefactor numeric
prefactor_num = (2*pi*Sstar_num)**0.5 / math.sqrt(abs(H_num))
print("Scalar stationary-phase prefactor (numeric):", prefactor_num)

# %% [markdown]
### Numeric anchor substitution and Monte Carlo uncertainty propagation
# Compute c from displacement law and compare to v_sync anchor using Monte Carlo.

# %% code
# Example numeric anchors (replace with your measured values)
nu_Cs = 9_192_631_770.0            # Hz (Cs)
M1 = 3.26e-2                       # m (example)
v_sync_Cs = M1 * nu_Cs             # m/s

lambda_peak = 1.063e-3             # m (CMB)
T_cmb = 2.725                      # K
kB = 1.380649e-23                  # J/K
h_meas = 6.62607015e-34            # J*s (Planck constant)
Sstar_from_h = h_meas / (2.0 * math.pi)

c_from_displacement = 2.821 * kB * lambda_peak * T_cmb / Sstar_from_h

print("v_sync_Cs (m/s):", v_sync_Cs)
print("c_from_displacement (m/s):", c_from_displacement)
print("relative diff:", abs(c_from_displacement - v_sync_Cs) / ((c_from_displacement + v_sync_Cs)/2))

# Monte Carlo propagation for v_sync = M1 * nu with uncertainties
N = 20000
M1_mean, M1_sigma = M1, abs(M1)*1e-4   # example relative uncertainty 0.01%
nu_mean, nu_sigma = nu_Cs, 1e-1        # example absolute uncertainty
M1_samples = np.random.normal(M1_mean, M1_sigma, N)
nu_samples = np.random.normal(nu_mean, nu_sigma, N)
v_samples = M1_samples * nu_samples
print("v_sync mean (MC):", v_samples.mean(), "std:", v_samples.std())

# Monte Carlo for c_from_displacement using uncertainties in lambda_peak and T
lambda_mean, lambda_sigma = lambda_peak, lambda_peak*1e-4
T_mean, T_sigma = T_cmb, 1e-3
lambda_samps = np.random.normal(lambda_mean, lambda_sigma, N)
T_samps = np.random.normal(T_mean, T_sigma, N)
c_samps = 2.821 * kB * lambda_samps * T_samps / Sstar_from_h
print("c_from_displacement mean (MC):", c_samps.mean(), "std:", c_samps.std())

# %% [markdown]
### Diagnostic outputs and checks
# Print symbolic-to-numeric consistency checks and remind where to replace anchors.

# %% code
print("\nSymbolic checks/info:")
print("- Mode density derivation produced 4π ν^2 / c^3 per volume (polarization factor added separately).")
print("- Stationary-phase prefactor scales as (2π S_*)^{n/2} / sqrt(|det H|).")
print("- Replace example anchors with your measured values for final reported numbers.")
