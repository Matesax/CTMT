
import numpy as np

N = 10000
sigma = 0.3
Xi_samples = np.random.lognormal(mean=0.0, sigma=sigma, size=N)
Mtilde = np.ones(N)
Phi = np.random.uniform(0, 2*np.pi, N)
Sstar = 6.626e-34 / (2*np.pi)

T_samples = Xi_samples * Mtilde * np.exp(1j * Phi / Sstar)
R = np.var(T_samples) / np.abs(np.mean(T_samples))
print("Rupture ratio R =", R)
