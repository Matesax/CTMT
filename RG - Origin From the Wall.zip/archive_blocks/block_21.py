import numpy as np

# Parameters
N = 10000  # ensemble size
omega = np.array([1, 2, 3])  # frequency components
t = 1
S_star = 1
C_phys = 1

# Synthetic rupture fields and regulators
Xi = np.random.normal(loc=1.0, scale=0.1, size=(N, len(omega)))  # rupture field
epsilon = np.random.normal(loc=0.01, scale=0.005, size=(N, len(omega)))  # regulator

# Phase kernel
Phi = np.outer(np.ones(N), omega * t)  # shape (N, len(omega))

# Terror kernel realizations
K_terror = C_phys * np.sum(Xi * np.exp(1j * Phi - epsilon), axis=1)

# RMI kernel (no rupture)
K_rmi = C_phys * np.sum(np.exp(1j * Phi), axis=1)

# Coherence gain Γ
Gamma = np.mean(np.abs(K_terror)) / np.mean(np.abs(K_rmi))

# Rupture ratio R(t)
T_n = np.sum(Xi * np.exp(-epsilon), axis=1)
R_t = np.var(T_n) / np.abs(np.mean(T_n))

# Lyapunov exponent estimate (log divergence over time)
delta_K = np.abs(K_terror - K_rmi)
Lambda = np.mean(np.log(delta_K + 1e-8)) / t  # avoid log(0)

# Output summary
print(f"Coherence gain Γ ≈ {Gamma:.4f}")
print(f"Rupture ratio R(t) ≈ {R_t:.4f}")
print(f"Estimated Lyapunov exponent Λ ≈ {Lambda:.4f}")
