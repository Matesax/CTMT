
# Example Python snippet to compute c from displacement law and compare to v_sync anchor
import math
import numpy as np

# Anchors (example values)
nu_Cs = 9_192_631_770.0            # Hz (Cs hyperfine)
M1 = 3.26e-2                       # m (measured cavity hop)
v_sync_Cs = M1 * nu_Cs             # m/s

lambda_peak = 1.063e-3             # m (CMB λ_peak)
T_cmb = 2.725                      # K
kB = 1.380649e-23                  # J/K
h_meas = 6.62607015e-34            # J*s  (anchor or measured S_meas if available)
Sstar = h_meas / (2.0 * math.pi)   # J*s (identify S_* = ħ if h_meas = h)

# displacement relation c = (2.821 * kB * λ_peak * T) / S_*
c_from_displacement = 2.821 * kB * lambda_peak * T_cmb / Sstar

print("v_sync_Cs (m/s):", v_sync_Cs)
print("c_from_displacement (m/s):", c_from_displacement)
# Compute relative difference
rel_diff = abs(c_from_displacement - v_sync_Cs) / ((c_from_displacement + v_sync_Cs)/2)
print("relative difference:", rel_diff)
