
def renormalize(X_C, dlnX_dlnrho, epsilon_dim):
    """CTMT renormalization between closure classes."""
    return X_C * (1 + epsilon_dim * dlnX_dlnrho)
