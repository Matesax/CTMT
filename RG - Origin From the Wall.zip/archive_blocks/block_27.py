# Compute rupture manifold basis from Fisher curvature H
eigvals_H, eigvecs_H = np.linalg.eigh(H)

lambda_crit = 0.5
rupture_mask = eigvals_H < lambda_crit

# Columns of M_rupt span the rupture manifold
M_rupt = eigvecs_H[:, rupture_mask]

print("Rupture manifold dimension:", M_rupt.shape[1])
print("Basis vectors:\n", M_rupt)
