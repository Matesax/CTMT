
import numpy as np

N = 20000
# Gaussian draws around anchors (example uncertainties)
M1_mean, M1_sigma = 3.26e-2, 3.26e-5   # 0.1% rel unc
nu_mean, nu_sigma = 9_192_631_770.0, 1e0 # assume tiny
M1_samples = np.random.normal(M1_mean, M1_sigma, N)
nu_samples = np.random.normal(nu_mean, nu_sigma, N)
v_samples = M1_samples * nu_samples
v_mean, v_std = v_samples.mean(), v_samples.std()
print("v_sync mean,std", v_mean, v_std)
  