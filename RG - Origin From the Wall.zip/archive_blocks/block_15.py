
import numpy as np

# Number of samples
N = 10000

# Log-normal rupture field parameters (μ=0, σ=0.2)
mu, sigma = 0.0, 0.2
Xi_samples = np.random.lognormal(mean=mu, sigma=sigma, size=N)

# Coherent kernel (normalized)
K_samples = np.ones(N)

# Apply modulation
T_samples = Xi_samples * K_samples

# Compute rupture ratio
R = np.var(T_samples) / np.abs(np.mean(T_samples))
print("Rupture ratio R =", R)
