<script>
function generateTerrorCSV(samples = 10000) {
    const omegaMean = 2.42e15, omegaStd = 1.0e13;
    const sigma = 0.3;  // rupture volatility
    const Sstar = 6.626e-34 / (2 * Math.PI);  // action scale [J·s]
    const Cphys = 1.0;  // physical prefactor (normalized)
    let ruptureSum = 0, ruptureSqSum = 0;
    let csv = "omega,Xi,Phi,TerrorKernel\n";

    function randn(mean, std) {
        let u = 0, v = 0;
        while (u === 0) u = Math.random();
        while (v === 0) v = Math.random();
        return mean + std * Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
    }

    for (let i = 0; i < samples; i++) {
        const omega = randn(omegaMean, omegaStd);
        const Xi = Math.exp(sigma * randn(0, 1));  // log-normal rupture
        const Phi = omega * 1.0e-9 + 2.0 * omega * omega * 1.0e-30;  // phase model
        const T = Cphys * Xi * Math.cos(Phi / Sstar);  // terror kernel (real part)
        ruptureSum += T;
        ruptureSqSum += T * T;
        csv += `${omega.toExponential()},${Xi.toExponential()},${Phi.toExponential()},${T.toExponential()}\n`;
    }

    const meanT = ruptureSum / samples;
    const stdT = Math.sqrt((ruptureSqSum / samples) - (meanT * meanT));
    const R = stdT / Math.abs(meanT);

    console.log(`Mean T[K]: ${meanT.toExponential()}`);
    console.log(`Std deviation: ${stdT.toExponential()}`);
    console.log(`Rupture ratio R: ${R.toFixed(3)}`);

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "terror_kernel.csv";
    link.click();
}
</script>
<button onclick="generateTerrorCSV()">Download Terror Kernel CSV</button>
