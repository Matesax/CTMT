<script>
function generateAlphaCSV(samples = 10000) {
	const gammaMean = 1.00e13, gammaStd = 5.0e11;
	const omegaMean = 2.42e15, omegaStd = 1.0e13;
	const vsyncMean = 1.46e14, vsyncStd = 1.0e13;
	const GMean = 6.27e-2, GStd = 1.5e-3;
	const c = 3.00e8, Ccal = 1.0;

	function randn(mean, std) {
		let u = 0, v = 0;
		while (u === 0) u = Math.random();
		while (v === 0) v = Math.random();
		return mean + std * Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
	}

	let alphaSum = 0, alphaSqSum = 0;
	let csv = "gamma,omega_star,v_sync,Gfactor,alpha\n";

	for (let i = 0; i < samples; i++) {
		const gamma = randn(gammaMean, gammaStd);
		const omega = randn(omegaMean, omegaStd);
		const vsync = randn(vsyncMean, vsyncStd);
		const Gfactor = randn(GMean, GStd);
		const alpha = Ccal * (gamma / omega) * (vsync / c) / Gfactor;

		alphaSum += alpha;
		alphaSqSum += alpha * alpha;

		csv += `${gamma.toExponential()},${omega.toExponential()},${vsync.toExponential()},${Gfactor.toExponential()},${alpha.toExponential()}\n`;
	}

	const meanAlpha = alphaSum / samples;
	const stdAlpha = Math.sqrt((alphaSqSum / samples) - (meanAlpha * meanAlpha));

	console.log(`Mean alpha: ${meanAlpha.toExponential()}`);
	console.log(`Std deviation: ${stdAlpha.toExponential()}`);

	const blob = new Blob([csv], { type: "text/csv" });
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = "monte_carlo_alpha.csv";
	link.click();
}
</script>
<button onclick="generateAlphaCSV()">Download Monte Carlo CSV</button>
