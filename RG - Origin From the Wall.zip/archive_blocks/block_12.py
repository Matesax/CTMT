import numpy as np
import pandas as pd

# Number of samples
N = 10000

# Monte Carlo sampling
gamma = np.random.normal(loc=1.00e13, scale=5.0e11, size=N)
omega = np.random.normal(loc=2.42e15, scale=1.0e13, size=N)
vsync = np.random.normal(loc=1.46e14, scale=1.0e13, size=N)
Gfactor = np.random.normal(loc=6.27e-2, scale=1.5e-3, size=N)

# Constants
c = 3.00e8  # speed of light in m/s
Ccal = 1.0  # calibration constant

# Compute alpha
alpha = Ccal * (gamma / omega) * (vsync / c) / Gfactor

# Output statistics
print(f"Mean alpha: {alpha.mean():.5e}")
print(f"Std deviation: {alpha.std():.5e}")  # Expected: alpha ≈ 7.30e-3 ± 2.5e-5

# Save results to CSV
df = pd.DataFrame({
	"gamma": gamma,
	"omega_star": omega,
	"v_sync": vsync,
	"Gfactor": Gfactor,
	"alpha": alpha
})
df.to_csv("monte_carlo_alpha.csv", index=False)
print("CSV saved as monte_carlo_alpha.csv")
