def estimate_jacobian(Yw, theta):
    # Yw: whitened features [trials × features]
    # theta: controls [trials × controls]
    Yc = Yw - Yw.mean(axis=0, keepdims=True)
    thetac = theta - theta.mean(axis=0, keepdims=True)
    J = np.linalg.lstsq(thetac, Yc, rcond=None)[0]  # [controls × features]
    return J

def fisher_curvature(Y, theta):
    Yw, S = prewhiten(Y)
    J = estimate_jacobian(Yw, theta)
    H = J.T @ J
    s = np.linalg.svd(H, compute_uv=False)
    return H, s, S

def variance_ratio(var_locked, var_free):
    return var_locked / (var_free + 1e-12)

def covariance_ratio(cov_locked, cov_free):
    return abs(cov_locked) / (abs(cov_free) + 1e-12)

def rupture_flag(s, lambda_crit_scale=0.2):
    med = np.median(s)
    return (np.min(s) < lambda_crit_scale * med)
