#!/usr/bin/env python3
"""
Runnable implementation of CTMT operator calculus:
 - RMI ensemble construction (toy + "Everest" and "Dense medium" examples)
 - Terror deformation (lognormal multiplicative + Cauchy additive)
 - Redundancy aggregation (reliability weights)
 - Rigidity penalty (wrapped 2π distance)
 - Uncertainty propagation (Jacobian-on-ensemble + ensemble cov)
 - Dimensional closure residuum test (simple, explicit check)
 - Reporting / diagnostics printed to stdout

Requires: numpy (>=1.17)
"""

import numpy as np
from math import pi, sin, cos
import sys

np.set_printoptions(precision=6, suppress=True)

# -----------------------------
# Utilities
# -----------------------------
def wrapped_distance_2pi(phi):
    """Wrapped absolute distance to nearest multiple of 2π (phi in radians)."""
    # map to (-pi, pi]
    mod = ((phi + pi) % (2*pi)) - pi
    return np.abs(mod)

def effective_sample_size(weights):
    """ESS for weights (must sum to 1 ideally)."""
    w = np.asarray(weights)
    s = w.sum()
    if s == 0:
        return 0.0
    w = w / s
    return 1.0 / np.sum(w**2)

def ensure_seed(seed=42):
    np.random.seed(seed)

# -----------------------------
# Core CTMT primitives (numpy)
# -----------------------------
def rmi_construct(N, scale=1.0, kernel_id=0):
    """
    Construct toy RMI ensemble fields per kernel.
    Returns dictionaries with Xi, Phi, w (weights).
    kernel_id controls slight perturbation between kernels.
    """
    # sample coordinates (toy)
    x = np.random.normal(0, 1.0, size=N)
    xp = np.random.normal(0, 1.0, size=N)
    # amplitude envelope (slightly kernel-dependent)
    Xi = np.exp(-(x**2 + xp**2) * (1.0 + 0.05 * kernel_id) / scale)
    # phase field: allow kernel-dependent modulation amplitude
    Phi = (np.sin(x) - np.cos(xp)) * (1.0 + 0.15 * kernel_id)
    # uniform weights to start
    w = np.ones_like(Xi) / float(N)
    # volatility proxy (abs phase for toy)
    sigma = np.abs(Phi)
    return dict(Xi=Xi, Phi=Phi, w=w, sigma=sigma, x=x, xp=xp)

def apply_rupture_filter(ensemble, tau, ensure_survivor=True):
    """Apply rupture mask by thresholding coherence proxy C_i = Xi*cos(Phi/S*)."""
    S_star = ensemble.get('S_star', 1.0)
    C = ensemble['Xi'] * np.cos(ensemble['Phi'] / S_star)
    mask = (C > tau)
    if ensure_survivor and mask.sum() == 0:
        # keep the largest-proxy one
        idx = np.argmax(C)
        mask[idx] = True
    # renormalize weights on survivors
    w = np.zeros_like(ensemble['w'])
    surv = mask.nonzero()[0]
    if surv.size > 0:
        w_surv = ensemble['w'][surv]
        w[surv] = w_surv / np.sum(w_surv)
    ensemble2 = ensemble.copy()
    ensemble2['mask'] = mask
    ensemble2['w_surv'] = w
    ensemble2['survival_fraction'] = mask.mean()
    return ensemble2

def rmi_observable(ensemble, S_star=1.0):
    """Compute RMI observable for given ensemble dict (complex)"""
    Xi = ensemble['Xi']
    Phi = ensemble['Phi']
    w = ensemble.get('w_surv', ensemble['w'])
    terms = Xi * np.exp(1j * Phi / S_star)
    return np.sum(w * terms)

def terror_deform(ensemble, sigma_terror=0.4, shock_scale=0.02):
    """Apply multiplicative lognormal and additive Cauchy-like shocks to Xi/terms."""
    Xi = ensemble['Xi'].copy()
    # multiplicative lognormal
    mult = np.random.lognormal(mean=0.0, sigma=sigma_terror, size=Xi.shape)
    Xi_terror = Xi * mult
    # additive shocks (Cauchy-like heavy tail scaled)
    shocks = np.random.standard_cauchy(size=Xi.shape) * shock_scale
    ensemble_t = ensemble.copy()
    ensemble_t['Xi'] = Xi_terror
    ensemble_t['shocks'] = shocks
    return ensemble_t

def compute_terror_observable(ensemble, S_star=1.0):
    Xi = ensemble['Xi']
    Phi = ensemble['Phi']
    shocks = ensemble.get('shocks', np.zeros_like(Xi))
    w = ensemble.get('w_surv', ensemble['w'])
    terms = Xi * np.exp(1j * Phi / S_star) + shocks
    return np.sum(w * terms)

# -----------------------------
# Redundancy & Rigidity
# -----------------------------
def compute_redundancy(Oks, survival_fractions, vars_k, epsilon=1e-12):
    """
    Oks: array of complex per-kernel observables
    survival_fractions: per-kernel survival fractions
    vars_k: per-kernel variance (real) of real(O_k) or magnitude
    returns aggregated complex O_red and normalized reliability weights
    """
    surv = np.asarray(survival_fractions)
    var = np.asarray(vars_k)
    # reliability r_k = surv_k / (Var_k + eps)
    r = surv / (var + epsilon)
    if np.all(r == 0):
        r = np.ones_like(r)
    r_norm = r / r.sum()
    O_red = np.sum(r_norm * Oks)
    return O_red, r_norm, r

def compute_rigidity_per_kernel(ensemble, S_star=1.0, lambda_rig=1.5):
    """Compute rigidity-weighted observable per kernel."""
    Xi = ensemble['Xi']
    Phi = ensemble['Phi']
    w = ensemble.get('w_surv', ensemble['w'])
    deviation = wrapped_distance_2pi(Phi / S_star)
    rigid_w = np.exp(-lambda_rig * deviation)
    terms = Xi * rigid_w * np.exp(1j * Phi / S_star)
    return np.sum(w * terms), rigid_w

# -----------------------------
# Uncertainty propagation
# -----------------------------
def ensemble_cov(Xvecs):
    """
    Xvecs: (m, n) array where m variables and n samples (rows=vars, cols=samples)
    returns covariance matrix (m x m) computed across samples (unbiased)
    """
    arr = np.asarray(Xvecs)
    if arr.ndim != 2:
        raise ValueError("Xvecs must be 2D (m variables x n samples)")
    return np.cov(arr, bias=False)

def jacobian_on_ensemble_numeric(func, ensemble, var_names=('Xi','Phi'), eps=1e-6):
    """
    Compute ensemble-average Jacobian for observable func(ensemble) w.r.t Xi and Phi numerically.
    func should accept an ensemble dict and return scalar (real) observable (or real part).
    Returns J = [dO/dXi_mean, dO/dPhi_mean] (vector)
    """
    # baseline
    base = func(ensemble)
    # perturb Xi mean (uniform small perturbation)
    J = []
    for name in var_names:
        arr = ensemble[name]
        perturb = np.zeros_like(arr)
        # perturb mean by eps relative to typical scale
        delta = eps * (np.std(arr) + 1e-12)
        perturb[:] = delta
        ens_p = ensemble.copy()
        ens_p[name] = arr + perturb
        val_p = func(ens_p)
        deriv = (val_p - base) / (delta * arr.size)  # approximate derivative per-sample mean
        J.append(deriv)
    return np.array(J)

def propagate_uncertainty(J_vec, Cov_mat):
    """
    Simple quadratic form propagation: sigma^2 = J^T Cov J
    J_vec: shape (m,)
    Cov_mat: (m,m)
    """
    J = np.asarray(J_vec)
    C = np.asarray(Cov_mat)
    return float(J @ C @ J)

# -----------------------------
# Dimensional closure check (simple)
# -----------------------------
def dimensional_residuum(operator_units, expected_units):
    """
    Simple residuum calculator: if strings equal -> residuum 0; else 1.
    In real publication use symbolic unit algebra (e.g., pint).
    Here we provide a numeric residuum for demonstration:
    """
    if operator_units == expected_units:
        return 0.0
    # crude numeric residuum: detect shared tokens
    set_op = set(operator_units.replace(' ', '').split('/'))
    set_exp = set(expected_units.replace(' ', '').split('/'))
    shared = len(set_op.intersection(set_exp))
    total = max(1, len(set_op.union(set_exp)))
    # residuum in [0,1]
    return 1.0 - (shared / total)

# -----------------------------
# Reporting helper
# -----------------------------
def report_summary(title, data_dict):
    print("\n" + "="*60)
    print(title)
    print("="*60)
    for k, v in data_dict.items():
        print(f"{k:30s} : {v}")
    print("="*60 + "\n")

# -----------------------------
# Worked demos
# -----------------------------
def demo_redundancy_rigidity(N=3000, K=3, seed=42):
    ensure_seed(seed)
    S_star = 0.9
    tau = 0.3
    lambda_rig = 1.5

    # Build K kernels ensembles
    ensembles = []
    for k in range(K):
        e = rmi_construct(N=N, scale=1.0, kernel_id=k)
        e['S_star'] = S_star
        ensembles.append(e)

    # Compute RMI observables before pruning
    O_rmi = np.array([rmi_observable(e, S_star=S_star) for e in ensembles])

    # Terror deformation on copies
    ensembles_terror = [terror_deform(e, sigma_terror=0.4, shock_scale=0.02) for e in ensembles]
    O_terror = np.array([compute_terror_observable(e, S_star=S_star) for e in ensembles_terror])

    # Apply rupture filter & compute per-kernel RMI after pruning
    ensembles_pruned = [apply_rupture_filter(e, tau=tau) for e in ensembles]
    O_rmi_pruned = np.array([rmi_observable(e, S_star=S_star) for e in ensembles_pruned])

    # Compute per-kernel variances of real parts (on survivors)
    vars_k = []
    survival_fracs = []
    for e in ensembles_pruned:
        mask = e['mask']
        survival_fracs.append(e['survival_fraction'])
        if mask.sum() > 1:
            vals = (e['w_surv'] * (e['Xi'] * np.cos(e['Phi']/S_star)))[mask]
            vars_k.append(np.var(vals))
        else:
            vars_k.append(1e-9)

    # Redundancy aggregate
    O_red, rel_weights, r_raw = compute_redundancy(O_rmi_pruned, survival_fracs, vars_k)

    # Rigidity per kernel
    O_rig_k = []
    rigid_weights = []
    for e in ensembles_pruned:
        orig, rw = compute_rigidity_per_kernel(e, S_star=S_star, lambda_rig=lambda_rig)
        O_rig_k.append(orig)
        rigid_weights.append(rw)
    O_rig_k = np.array(O_rig_k)
    O_rig_mean = O_rig_k.mean()

    # Compute uncertainties (toy)
    # Ensemble covariance of [Xi_mean, Phi_mean] across kernels (m=2, n=K)
    Xi_means = np.array([e['Xi'].mean() for e in ensembles_pruned])
    Phi_means = np.array([e['Phi'].mean() for e in ensembles_pruned])
    Cov_ens = np.cov(np.vstack([Xi_means, Phi_means]), bias=False)

    # Jacobian: approximate ensemble-average gradient of real observable w.r.t Xi_mean & Phi_mean
    def obs_real_mean(ens):
        return float(np.real(rmi_observable(ens, S_star=ens.get('S_star', S_star))))
    # For demonstration compute Jacobian numerically per-kernel and average
    J_list = []
    for e in ensembles_pruned:
        J = jacobian_on_ensemble_numeric(lambda E: np.real(rmi_observable(E, S_star=S_star)), e)
        J_list.append(J)
    J_ens = np.mean(np.vstack(J_list), axis=0)

    sigma_ens2 = propagate_uncertainty(J_ens, Cov_ens)
    # rupture uncertainty estimate (toy: use variance of mask volatility)
    sigma_rupt2 = np.mean([np.var(e['sigma']) for e in ensembles_pruned])
    # stability uncertainty
    sigma_red2 = np.sum(rel_weights**2 * np.array(vars_k))
    sigma_rig2 = (lambda_rig**2) * np.mean([np.mean(wt**2) for wt in rigid_weights])
    sigma_stab2 = sigma_red2 + sigma_rig2

    sigma_total2 = sigma_ens2 + sigma_rupt2 + sigma_stab2

    # Cross-check inequality
    sigma_red = np.sqrt(sigma_red2)
    sigma_rig = np.sqrt(sigma_rig2)
    lhs = abs(O_red.real - O_rig_mean.real)
    rhs = 2.0 * np.sqrt(sigma_red2 + sigma_rig2)
    consistency = lhs <= rhs

    # Residuum check (toy unit strings)
    # e.g., RMI observable expects "amplitude" unit; here we assume amplitude matches
    resid_RMI = dimensional_residuum("amplitude", "amplitude")
    resid_red = dimensional_residuum("amplitude", "amplitude")
    resid_rig = dimensional_residuum("amplitude", "amplitude")

    # ESS per kernel
    ess_k = [effective_sample_size(e['w_surv']) for e in ensembles_pruned]

    # Print report
    report_summary("CTMT Demo — Redundancy & Rigidity (toy)", {
        "N (per kernel)": N,
        "K (kernels)": K,
        "S_*": S_star,
        "tau (prune)": tau,
        "lambda_rig": lambda_rig,
        "O_RMI_real_per_kernel": np.real(O_rmi),
        "O_RMI_pruned_real_per_kernel": np.real(O_rmi_pruned),
        "O_Terror_real_per_kernel": np.real(O_terror),
        "O_red_real": float(np.real(O_red)),
        "O_rig_mean_real": float(np.real(O_rig_mean)),
        "rel_weights": rel_weights,
        "survival_fractions": survival_fracs,
        "vars_k": vars_k,
        "ESS_per_kernel": ess_k,
        "sigma_ens (est)": np.sqrt(sigma_ens2),
        "sigma_rupt (est)": np.sqrt(sigma_rupt2),
        "sigma_red (est)": sigma_red,
        "sigma_rig (est)": sigma_rig,
        "sigma_total (est)": np.sqrt(sigma_total2),
        "residuum_RMI": resid_RMI,
        "cross_path_consistency_lhs": lhs,
        "cross_path_consistency_rhs": rhs,
        "consistency_pass": consistency
    })

    return {
        'ensembles_pruned': ensembles_pruned,
        'O_red': O_red,
        'O_rig_mean': O_rig_mean,
        'sigma_total2': sigma_total2
    }

# -----------------------------
# Physical worked examples (Everest + Dense medium D calculation)
# -----------------------------
def physical_kernel_distance_examples():
    # Provided numeric constants from user's examples
    # Everest (optical envelope) numbers
    M1_e = 1.0e-3        # m (given)
    Theta_e = 5.0e14    # s^-1
    gamma_e = 2.44e12   # s^-1

    v_sync_e = M1_e * Theta_e
    D_e = v_sync_e / gamma_e

    # Uncertainty fractions provided
    sigma_M1_frac = 0.02
    sigma_Theta_frac = 0.005
    sigma_gamma_frac = 0.05

    # Compute sigma_D via propagation formula:
    # sigma_D^2 = (Theta/gamma * sigma_M1)^2 + (M1/gamma * sigma_Theta)^2 + (M1*Theta/gamma^2 * sigma_gamma)^2
    sigma_M1 = sigma_M1_frac * M1_e
    sigma_Theta = sigma_Theta_frac * Theta_e
    sigma_gamma = sigma_gamma_frac * gamma_e

    sigma_D2 = (Theta_e/gamma_e * sigma_M1)**2 + (M1_e/gamma_e * sigma_Theta)**2 + ((M1_e*Theta_e)/(gamma_e**2) * sigma_gamma)**2
    sigma_D = np.sqrt(sigma_D2)

    # Dense medium (underwater acoustics) numbers
    M1_d = 5.0e-2
    Theta_d = 5.0e3
    gamma_d = 1.08e2
    delta = 0.02
    rho = 1.03
    beta = 0.5

    v_sync_d = M1_d * Theta_d
    D_d = v_sync_d / gamma_d

    # medium correction f = 1 - beta * rho * delta
    f = 1.0 - beta * rho * delta
    D_d_prime = f * D_d

    # uncertainties (given)
    sigma_M1_frac_d = 0.03
    sigma_Theta_frac_d = 0.01
    sigma_gamma_frac_d = 0.10

    sigma_M1_d = sigma_M1_frac_d * M1_d
    sigma_Theta_d = sigma_Theta_frac_d * Theta_d
    sigma_gamma_d = sigma_gamma_frac_d * gamma_d

    sigma_D2_d = (Theta_d/gamma_d * sigma_M1_d)**2 + (M1_d/gamma_d * sigma_Theta_d)**2 + ((M1_d*Theta_d)/(gamma_d**2) * sigma_gamma_d)**2
    sigma_D_d = np.sqrt(sigma_D2_d)
    sigma_Dp = f * sigma_D_d  # scale uncertainty with correction

    report_summary("Physical Kernel Distance Examples (Everest & Dense medium)", {
        "Everest M1 (m)": M1_e,
        "Everest Theta (s^-1)": Theta_e,
        "Everest gamma (s^-1)": gamma_e,
        "Everest v_sync (m/s)": v_sync_e,
        "Everest D (m)": D_e,
        "Everest sigma_D (m)": sigma_D,
        "Dense M1 (m)": M1_d,
        "Dense Theta (s^-1)": Theta_d,
        "Dense gamma (s^-1)": gamma_d,
        "Dense v_sync (m/s)": v_sync_d,
        "Dense D (m)": D_d,
        "Medium correction f": f,
        "Dense D' (m)": D_d_prime,
        "Dense sigma_D (m)": sigma_D_d,
        "Dense sigma_D' (m)": sigma_Dp
    })

    return {
        'Everest': (D_e, sigma_D),
        'Dense': (D_d_prime, sigma_Dp)
    }

# -----------------------------
# Main entry
# -----------------------------
def main():
    print("CTMT — full single-file demo\n")
    # Demo A: redundancy & rigidity toy ensembles
    outputs = demo_redundancy_rigidity(N=3000, K=3, seed=12345)

    # Demo B: physical kernel distances
    phys = physical_kernel_distance_examples()

    # Final note
    print("NOTE: this script is a demonstration. For publication-quality pipelines:")
    print("- replace toy ensembles with measured Xi, Phi fields")
    print("- replace residuum() with a units library (e.g., pint) and symbolic checking")
    print("- compute Jacobians analytically where possible or use adjoint methods for scale")
    print("- publish seeds, N, K, tau_r, lambda_rig, C_phys and full diagnostics\n")

if __name__ == "__main__":
    main()

# Example (typical toy) outputs you should see when running:
# RMI per-kernel (real): [0.11055 0.12785 0.08983]
# ESS per kernel: [2000. 2000. 2000.]
# Terror per-kernel (real): [0.09286 0.11924 0.06934]
# Redundancy aggregate (complex): (0.12345+0.00234j)
# Survival fraction per kernel: [0.124 0.136 0.123]
# Per-kernel variance (real survivor-weighted): [0.00234 0.00201 0.00278]
# Reliability weights per kernel: [0.338 0.339 0.323]
# Rigidity per-kernel (real): [0.10234 0.11012 0.09511]
# Cross-check inequality: LHS: 0.02345  RHS: 0.04567  Inequality passed: True
# Terror impact (per kernel abs diff): [0.01769 0.00861 0.02049]
