# Linear Tikhonov inversion
Input: A, O, R, C_epsilon
Select lambda via L-curve, GCV, or discrepancy principle
Solve: (A^T C_epsilon^{-1} A + lambda R^T R) k = A^T C_epsilon^{-1} O
Estimate posterior covariance via iterative solver or trace estimator
Check chi^2 ≈ 1

# Nonlinear Gauss–Newton
Initialize k0
for n in 0..N_iter:
    r = O - F(k_n)
    J = Jacobian(F, k_n)  # via adjoint products
    Solve: (J^T C_epsilon^{-1} J + lambda R^T R) delta = J^T C_epsilon^{-1} r
    Update: k_{n+1} = k_n + delta
    if ||delta|| small → convergence
Estimate covariance from Gauss–Newton Hessian
