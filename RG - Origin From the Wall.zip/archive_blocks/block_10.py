# Joint FMC ⊗ TUCF demonstration (Jupyter notebook cell)

import numpy as np
from scipy.signal import get_window, correlate
from numpy.fft import rfft
np.random.seed(1)

# Spatial anchors
anchors = np.array([0.0, 0.5, 1.0])     # 3 sensors
c = 340.0                               # wave speed

# Synthetic spatial forward map (Green's function)
def Kx(x, x0):
    r = np.abs(x - x0)
    return 1/(r+1e-6)

# Temporal parameters
fs = 2000
T = 2.0
t = np.linspace(0, T, int(T*fs), endpoint=False)
f0 = 18
ω = 2*np.pi*f0

# Create spatiotemporal field
field = np.sin(ω*t)                     # temporal carrier

# Spatial projection
O_space = np.vstack([Kx(anchors[i], 0.0) * field for i in range(len(anchors))])

# Temporal rupture
mask_t = (t>0.9)&(t<1.2)
rupt = np.random.lognormal(0,0.7,mask_t.sum())
field_r = field.copy()
field_r[mask_t] *= rupt

O = np.vstack([Kx(anchors[i],0.0)*field_r for i in range(len(anchors))])
O += 0.03*np.random.randn(*O.shape)

# TUCF window parameters
Δt = 0.15
Nw = int(fs*Δt)
hop = Nw//3
win = get_window('hann', Nw)

chi2_joint = []
entropy_joint = []
rupt_joint = []

for start in range(0, len(t)-Nw, hop):
    idx = slice(start, start+Nw)
    
    # Spatial aggregation: sum over anchors (FMC compression)
    Y = np.sum(O[:,idx], axis=0)
    Y *= win

    # Temporal prediction: reconstruct amplitude via LS
    basis = np.sin(ω * t[idx]) * win
    A = basis[:,None]
    amp = np.linalg.solve(A.T@A + 1e-10*np.eye(1), A.T@Y)
    pred = (A@amp).ravel()

    # Residual & chi2
    res = Y - pred
    chi2_joint.append(np.mean((res/0.03)**2))

    # Spectral entropy (temporal)
    p = np.abs(rfft(Y))
    p /= p.sum()+1e-12
    H = -np.sum(p*np.log(p+1e-12))/np.log(len(p)+1e-12)

    entropy_joint.append(H)

    # Joint rupture indication: volatility × curvature
    vol = np.std(res) / (np.mean(np.abs(pred))+1e-12)
    rupt_joint.append(vol * H)

print("mean χ²_joint:", np.mean(chi2_joint))
print("mean entropy:", np.mean(entropy_joint))
print("max rupture indicator:", np.max(rupt_joint))
