
CTMT Run — Redundancy & Rigidity demo
Seed: 2025
Ensemble size: N = 2000
Kernels: K = 3
S_* (dimensionless demo) = 1.0
Rupture threshold (coherence proxy) = 0.1
Terror: multiplicative lognormal sigma = 0.40; shock_scale = 0.02
Outputs:
- RMI mean real: (value)
- Terror mean real: (value)
- Redundancy aggregate magnitude: (value)
- Rigidity mean real: (value)
- Survival fractions per kernel: (values)
- ESS before/after pruning: (values)
Inequality (|O_red-O_rig| <= 2 sqrt(...)): pass/fail
