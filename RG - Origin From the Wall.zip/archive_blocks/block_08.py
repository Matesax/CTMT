import numpy as np
from numpy.linalg import inv, cholesky

np.random.seed(7)

# --- Geometry and kernel-origin setup ---
A = np.array([[1.0, 0.5, -0.2],
              [0.3, 1.2,  0.1],
              [-0.1, 0.2, 0.9]])     # forward/Jacobian at current iterate
p = A.shape[1]                       # number of kernel parameters
n = A.shape[0]                       # number of observables

kappa_true = np.array([0.8, -0.4, 0.3])
sigma_noise = 0.03
Ceps = np.eye(n) * sigma_noise**2
O = A @ kappa_true + np.random.multivariate_normal(mean=np.zeros(n), cov=Ceps)

# Regularization and numerical safeguard
lambda_reg = 5e-3
R = np.eye(p)
eps_stab = 1e-8   # jitter for stability

# --- RIP: reciprocal operator, reconstruction, and posterior covariance ---
M = A.T @ inv(Ceps) @ A + lambda_reg * R.T @ R
F_star = inv(M + eps_stab*np.eye(p)) @ (A.T @ inv(Ceps))
kappa_rec = F_star @ O

C_kappa = inv(M + eps_stab*np.eye(p))
std_kappa = np.sqrt(np.diag(C_kappa))

# χ² normalized residual diagnostic (guard DOF)
res = O - A @ kappa_rec
if n > p:
    chi2 = (res.T @ inv(Ceps) @ res) / (n - p)
else:
    chi2 = np.nan  # undefined; use CV or hat-matrix trace in practice

# Predicted observable covariance (linearized)
C_O_pred = A @ C_kappa @ A.T + Ceps
std_O_pred = np.sqrt(np.diag(C_O_pred))

# --- ICM proxy: entropy-based compression surrogate ---
def entropy_power(x):
    pwr = np.abs(x)**2
    p = np.clip(pwr / (pwr.sum() + 1e-12), 1e-12, 1.0)
    return -np.sum(p * np.log(p))

E_pred = entropy_power(A @ kappa_rec)
E_obs  = entropy_power(O)
C_info = 1.0 - E_pred / (E_obs + 1e-12)

# --- MKP: coherence-calibrated adaptive prediction + uncertainty ---
chi_meas = 0.8
chi_pred = 0.6
alpha = chi_meas / (chi_pred + chi_meas + 1e-12)  # in [0,1]

O_pred = A @ kappa_rec
O_mkp = O_pred + alpha * (O - O_pred)

C_Ohat = alpha**2 * Ceps + (1 - alpha)**2 * (A @ C_kappa @ A.T)
std_Ohat = np.sqrt(np.diag(C_Ohat))

# --- Invariant flux (Φ_inv) with uncertainty example values ---
Delta_t = 0.12   # s
rho_coh = 0.94   # dimensionless coherence density
v_sync  = 343.0  # m/s
Phi_inv = v_sync * Delta_t * rho_coh  # note: units = m; normalize by area/density for m^-2

sigma_v = 1.0
sigma_dt = 0.005
sigma_rho = 0.02
rel_var_phi = (sigma_v / v_sync)**2 + (sigma_dt / Delta_t)**2 + (sigma_rho / rho_coh)**2
sigma_phi = abs(Phi_inv) * np.sqrt(rel_var_phi)

# --- Terror variants: rupture-aware mask on channels (residual-driven) ---
residual = O - A @ kappa_rec
worst_idx = int(np.argmax(np.abs(residual)))
W_tau = np.eye(n); W_tau[worst_idx, worst_idx] = 0.0

A_ter = W_tau @ A
O_ter = W_tau @ O
Ceps_ter = W_tau @ Ceps @ W_tau

# Pre-whitened metric
W = cholesky(inv(Ceps_ter + eps_stab*np.eye(n)))
Jw_ter = W @ A_ter
rw_ter = W @ (O_ter - A_ter @ kappa_rec)

M_ter = Jw_ter.T @ Jw_ter + lambda_reg * R.T @ R
delta_kappa = inv(M_ter + eps_stab*np.eye(p)) @ (Jw_ter.T @ rw_ter)
kappa_ter = kappa_rec + delta_kappa
C_kappa_ter = inv(M_ter + eps_stab*np.eye(p))
std_kappa_ter = np.sqrt(np.diag(C_kappa_ter))

# Terror-aware MKP gain (placeholder χ; replace with estimator)
chi_meas_ter = 0.7
chi_pred_ter = 0.5
alpha_ter = chi_meas_ter / (chi_pred_ter + chi_meas_ter + 1e-12)

O_pred_ter = A_ter @ kappa_ter
O_mkp_ter  = O_pred_ter + alpha_ter * (O_ter - O_pred_ter)
C_Ohat_ter = alpha_ter**2 * Ceps_ter + (1 - alpha_ter)**2 * (A_ter @ C_kappa_ter @ A_ter.T)
std_Ohat_ter = np.sqrt(np.diag(C_Ohat_ter))

# --- Reporting ---
print("RIP κ_rec =", kappa_rec)
print("Posterior std(κ) =", std_kappa)
print("χ² normalized residual =", chi2)

print("ICM C_info =", C_info)
print("MKP prediction =", O_mkp)
print("MKP std per channel =", std_Ohat)

print("Invariant flux Φ_inv =", Phi_inv)
print("Invariant flux uncertainty σ_Φ =", sigma_phi)

print("\\n--- Terror variants ---")
print("Masked channel index =", worst_idx)
print("Terror RIP κ_rec =", kappa_ter)
print("Terror posterior std(κ) =", std_kappa_ter)
print("Terror ICM C_info =", 1.0 - entropy_power(W_tau @ (A @ kappa_ter)) / (entropy_power(O_ter) + 1e-12))
print("Terror MKP prediction =", O_mkp_ter)
print("Terror MKP std per channel =", std_Ohat_ter)
