# Resolution Geometry (RG)

*formerly CTMT*

**Resolution Geometry is the geometry of what a declared family of observation protocols can distinguish, and of every structure that this distinguishability forces.**

The primitive is the equality-of-law relation of a joint observation law. That relation is a groupoid, and its orbit space is the observable quotient. The stabilizer of the law, taken modulo its gauge part, is an effective symmetry group that acts faithfully on the quotient.

Every further structure is added in a fixed order. Each addition is either forced by the preceding objects, imported from an established theorem, or conditioned on a named and testable hypothesis. The structures, in order, are:

- differential and stratified structure;
- statistical, quantum and probabilistic structure;
- causal and characteristic structure;
- scale and transport;
- duration and dynamics;
- calibrated physical distance.

What remains after every gate is certified is **not a new primitive**. On second-order strata of constant canonical-correlation multiplicity, the final remainder is global structure of a classical kind. It consists of local canonical-correlation moduli together with a tuple of Euclidean block bundles. This pair is the initial complete natural invariant, and it is classified by $\prod_j B\mathrm O(m_j)\times B\mathrm O(p-r)\times B\mathrm O(q-r)$.

The statement of record is **`Resolution Geometry.pdf`**, the closed print edition of November 2026 (59 pages). It reads every layer twice: through the established theorem it matches, and natively from records and counts (Section 16, *Records first: the native chain*). Its hypothesis table gives the status of every declared hypothesis on records, its companion map is grouped and cited, and its appendix is the full battery. It is a ladder of **134 rungs, L0–L133**, with backward-only dependencies, proofs or precise citations for every step, a computational-complexity section, and **two** remaining open problems, both outside RG proper. The second-order remainder across walls is closed (L129–L131): hidden-room descent where chamber stabilizers are discrete, an obstruction tower in general, and a no-go for any constructible exit-path classification. The ladder is closed: later results are companion papers that attach to rungs and add none. Directly after the ladder, **the atlas** (Section 23, with the companion `RG - Realization Atlas.pdf`) charts concrete systems through nine layers:
- A1: exact gluing;
- A2: structured descent;
- A3: metric charts;
- A4: walls;
- A5: equivariant charts;
- A6: global classes;
- A7: stability;
- A8: physical anchors;
- A9: a registry of certified realizations.

Pointwise, the second-order data are classified completely (L124–L128):
- Two triples (R, N, C) are equivalent under the declared-metric gauge O(p)×O(q) iff all ordered word traces of an associated symmetric tuple agree. This holds on every stratum.
- On simple-spectrum strata, the classification reduces to spectra, coupling magnitudes and cycle signs in H¹(G; F₂). These loop values are real hidden values, not gauge.
- In Lorentzian geometry, scalar invariants do not separate curvature, so a declared observer is required.
- No classification selects a dynamics.

---

## The native chain

Records alone give each layer without a latent manifold:

- **metric**: the record width (local minimax precision per record) is Fisher on one protocol, monotone under garbling by simulation, scale fixed by counting; on quantum states it is the minimal Petz metric on every finite grouping of copies;
- **manifold**: the record image carries a canonical filtration into smooth strata (o-minimal regular locus); the manifold of the differential layer is its regular part, its dimension a covering exponent (1.000, 2.015, 2.944 on tori of laws; 1.981 for a three-angle family depending on two combinations), its volume a record count (covering ratio 0.3723 against Fisher volume ratio 0.3695; area ratio 0.828 is not it);
- **regularity** is a record test at a resolution: link and tangent-cone tests flag exactly the six non-manifold points of a composite record set and not a cubed presentation wall; a loop of size s is a crossing at resolution s/4 and invisible at 12s; latent Fisher rank errs both ways;
- **units** are counts (exact scale cocycle), the **cone** comes from order and count of events and glues at a resolution, **dynamics** is the flow of the record Hessian.

Of 25 declared hypotheses: 5 discharged (H-mono, H-task, H-int for counted units, H-resp, H-min), 10 record tests, 1 anchor (H-SI), 9 irreducible (tested only by frozen predictions).

## One battery

`RG_full_battery.zip` reruns every witness: 35 batteries (print: native chain and print audit; 22 companion batteries; 11 attacks), 309 groups, each battery in a temporary copy with `python3 -I`, requiring exit 0, no failures and byte-identical results; `--mutations` runs every mutation suite: 309 of 309 one-line falsifications caught (a crash is a defect, not a catch). See its `LEDGER.md`.

## The object

An observation system consists of three parts:

- a latent space $X$;
- protocols $F_i : X \to Y_i$, valued in spaces of observable laws;
- a declared relabeling group $\Psi$.

The joint law is

$$
F = (F_i)_{i \in I} : X \longrightarrow Y = \prod_i Y_i .
$$

Its kernel groupoid and quotient are

$$
\mathcal K = X \times_Y X, \qquad \pi : X \longrightarrow Q = X / \mathcal K \cong \mathrm{im}\, F .
$$

The stabilizer of the law, its gauge part (the bisections of $\mathcal K$), and the effective symmetry group fit into one exact sequence:

$$
1 \longrightarrow \mathrm{Gau} \longrightarrow \mathrm{Stab} \longrightarrow \Gamma \longrightarrow 1 .
$$

A **natural module** is a pullback $M = F^{*}\mu$ of a relabeling-invariant structure on law space. Examples are observable invariants, clock readings, record counts, the Fisher tensor and law-defined cones. On a regular stratum every natural module descends and is $\Gamma$-invariant:

$$
M = \pi^{\ast} \bar M, \qquad \gamma^{\ast} \bar M = \bar M \quad \text{for all } \gamma \in \Gamma .
$$

Representative independence, basicness and projectability of law-defined modules are therefore theorems, not hypotheses. What remains is either declared or empirical:

- the protocols, the task and the admissible class;
- the content of $\Gamma$, tested by equality of laws;
- regularity of the stratum;
- latent (non-natural) data;
- anchors and held-out validation.

---

## The calculus: how RG computes

RG is used as a short sequence of operations. Each operation has a precise criterion and a typed failure mode.

| Step | Operation | Criterion | Rung |
|---|---|---|---|
| 1 | **Declare** protocols, relabelings, task, admissible class, hypotheses | the declarations are fixed before the output is seen | L0, H-adm |
| 2 | **Quotient** by equality of laws | a task $T$ is law-determined iff $\mathcal K_F \subseteq \mathcal K_T$; then $T = \bar T \circ \pi$ | L1–L2 |
| 3 | **Combine** protocols | $\mathcal K_{(F_i)} = \bigcap_i \mathcal K_{F_i}$; under model uncertainty, take the equivalence closure of the union | L3, L14 |
| 4 | **Select** panels | the complete antichain of inclusion-minimal sufficient panels; ties retained | L12 |
| 5 | **Descend** natural modules | basic and $\Gamma$-invariant automatically; Fisher radical $= \ker DF$ | L19–L20, L28 |
| 6 | **Reduce** nuisance | efficient metric by Schur complement | L34 |
| 7 | **Stratify and specialize** at walls | specialization map iff $\mathcal K_\varepsilon \subseteq \mathcal K_0$; correspondence otherwise | L21–L27 |
| 8 | **Certify** in declared precision units | rank (double escalation), Hellinger, forgetting (operator bound over a class), frontier | L47, L37, L57, L90 |
| 9 | **Anchor** | a counted channel removes the dilation fibre; SI radar anchor; held-out validation | L94–L109 |
| 10 | **Dispatch** | exactly one status: LOCKED, ESCALATE, CORRESPONDENCE, VACUOUS, INCONSISTENT, STRUCTURAL WALL[ε] or OUTSIDE DOMAIN | L112–L115 |
| 11 | **Report the remainder** | multiplicity type, local moduli and block-bundle classes (e.g. $w_1$ on loops), not local invariants alone; linking monodromy near walls | L116–L123 |

Five formulas carry most of the weight:

$$
\text{descent:}\quad T = \bar T\circ\pi \iff \mathcal K_F \subseteq \mathcal K_T
\qquad\qquad
\text{efficient metric:}\quad g_{\mathrm{eff}} = I_{\theta\theta} - I_{\theta\eta} I_{\eta\eta}^{-1} I_{\eta\theta}
$$

$$
\text{forecast frontier:}\quad n^\ast(\sigma_0) = \frac{\log(\varepsilon/\sigma_0)}{\lambda} + c_P
\qquad\qquad
\text{non-circularity:}\quad \sup_{\mu,\nu \in \mathcal A} d\big(\Phi_{t\sharp}\mu,\Phi_{t\sharp}\nu\big) \le \tau
$$

$$
\text{soundness:}\quad \Pr(\text{false LOCKED}) \le \sum_{g} \alpha_g .
$$

A result is **LOCKED** only when every gate of the requested module is certified. Otherwise RG returns either the exact observable correspondence or a typed abstention. The exact correspondence is the least sound set of jointly attainable outputs, with joint witnesses retained; "maximal" means maximally informative, not largest. **No admitted request ever requires choosing between alternatives the protocol cannot tell apart.**

---

## The ladder at a glance

| Stratum | Rungs | Main results |
|---|---|---|
| Exact | L0–L5 | kernel groupoid; universal factorization; joint kernel is the intersection of protocol kernels; garbling enlarges the kernel; the exact layer fixes no metric, order, cone, scale or unit |
| Symmetry | L6–L11 | exact sequence with faithful $\Gamma$; non-splitting; count rigidity; orbit–quotient comparison; saturation hierarchy; coherent completeness |
| Observable sector | L12–L17 | complete minimal-panel selector; no task-free isotropic selector; more protocols intersect, more models close; common model-blind decoder; a coupled law refines its marginals; confidence-set bridge; tolerance is not a groupoid |
| Differential and strata | L18–L27 | tangent sequence; natural descent; slices and tangent cones; kernel upper semicontinuity; specialization iff kernel inclusion; symmetry descent through the normalizer; stratified quotient category |
| Second order and quantum | L28–L43 | Fisher is natural; descent does not select, Fisher selected under H-mono or experiment-level descent (Čencov; derived in `RG - Cencov Theorem.pdf`); covariance is not determined by Fisher; quotient dimension $p+q+pq$ under the declared-metric contract; efficient metric; data processing; Hellinger specialization; Petz family gate; task lock (SLD, BKM, WY); nonparametric Petz identification; quantum walls; trace rule; contextual protocols (Fine) |
| Ignorance | L44–L48 | persistent null; sensor, precision and representation nulls; finite-sample reconstruction; rank walls are never certified from finite data; exact law equality is not uniformly certifiable from finite samples |
| Uncertainty and forgetting | L49–L58 | uncertainty splits along the quotient; de Finetti; LAN and branch selection; TV rigidity; no uniform forgetting without a class; sharp BV mixing lock; Navier–Stokes contraction gate; Dobrushin blocks; samples refute and operators lock; non-circularity certificate; non-dominated and infinite-dimensional strata |
| Statistical distance | L59–L63 | RG distance is representative-free, chart-free and dimensionless; monotone under garbling; no angle in rank one; finite divergences are not rulers; experiment-relative |
| Order, cone and residual | L64–L73 | reachability; projective typing; realization branches; conformal ray; Lorentz forcing; tame reduction; no finite linear classification; duality; hyperbolic lock; wild class |
| Scale and transport | L74–L80 | scale cocycle; strict transport; induced connection; entropy selects no connection; no law-natural connection; canonical connection under declared covariance |
| Duration and dynamics | L81–L89 | clock transition groupoid; affine clocks; path independence; coherence duration; noiseless finite histories; kernel-count entropy; Ruelle and Pesin locks; typed dynamical certificates; cone-field criterion |
| Chaos frontier | L90–L93 | frontier slope $1/\lambda$; duality $2\lambda$; quotient growth $h$; information cost of $\lambda/\ln 2$ bits per certified step; clock distortion classes |
| Physical distance | L94–L109 | no internal unit; counted channels; count loss; ratio scale; two-point invariant; metric proportionality; anchor budget; unit-distance rigidity; radar and rod distance; stationary slices and Sagnac holonomy; non-stationary no-go; media; ergodic transfer; identification theorem |
| Assembly | L110 | kernel–stabilizer theorem and compatibility equations |
| Global transport and closure | L111–L115 | global transport; dispatcher totality; composite soundness; window-indexed walls; maximal closure |
| Final remainder | L116–L123 | task residual and terminal sufficient refinement; the coupling is complement-relative; coupling stabilizer $\prod\mathrm O(m_j)\times\mathrm O(p-r)\times\mathrm O(q-r)$ (multiplicities, not rank, control symmetry); Global Structure Theorem (stack, twisted forms $\check H^1$, block-bundle equivalence, initial invariant, classifying space); consequences ($2^\kappa$ classes over $S^1$, Fisher remainder $[K_N]$); gluing class in $\check H^2$; forced wall monodromy; no new primitive |
| Local classification | L124–L128 | complete word-trace classifier of (R,N,C) modulo O(p)×O(q) on every stratum; simple-spectrum sign chart $H^1(G;\mathbb F_2)$; shorter descriptors and joint tasks; Lorentzian scalar invariants fail (vacuum plane wave), so curvature classification is observer-relative; classification selects no dynamics |
| Remainder across walls | L129–L131 | hidden-room descent (discrete chamber stabilizers: lifted wall rooms, link functions modulo a constant, holonomies); no constructible exit-path classification (continuous crossing moduli, functional link moduli, pointwise rooms insufficient); obstruction tower (transporter section; germ steps plus cell classes in $[S^{r-1},H_\tau]$; 3-cells unobstructed; base dimension ≤ 3 needs only π₀ and π₁) |
| Open | L132–L133 | enumeration of tame characteristic types (external); uniform forgetting for forced deterministic turbulence |

Each rung has exactly one status: **F** forced, **I** imported, **H** hypothesis-conditioned (the hypothesis is named), **Γ** conditional on the effective symmetry group, **N** no-go, or **O** open.

**Named hypotheses:**
- regularity and nuisance: `H-reg`, `H-nuis`, `H-sens`;
- declared groupoids: `H-sound`, `H-compl`, `H-coh`;
- cone, scale and anchors: `H-top`, `H-int`, `H-SI`, `H-med`, `H-val`;
- walls: `H-unif`, `H-hell`;
- task and latent data: `H-task`, `H-cov`;
- physical response: `H-resp` (the system moves by the minimum-P⁻¹ lift: overdamped bodies with P = mobility, free bodies with zero conserved momentum with P = inverse inertia);
- probability and uncertainty: `H-stat`, `H-exch`, `H-adm`;
- selection principle: `H-mono` (metrics may not increase under Markov morphisms; selects Fisher by Čencov);
- symmetry: `H-Γ`;
- final remainder:
  - `H-split`: the resolved/null splitting is declared, as $N=\ker J^{*}$;
  - `H-type`: the coupling rank and the canonical-correlation multiplicities are locally constant;
  - the $\check H^2$ gluing class additionally assumes an abelian automorphism band.

Each is stated in the paper together with the test that falsifies it.

---

## Frontier examples

These are worked results from the module batteries. Each is reproducible from its ZIP with fixed seeds and mutation canaries.

**Chaos is not hidden (L90–L93).** The boundary between LOCKED and ESCALATE forecasts is a straight line of slope $1/\lambda$ in the log of the declared precision. A protocol moves only its intercept. Recovered across five seeds:

| System | true λ | λ recovered from RG's own frontier |
|---|---|---|
| logistic, r = 4 | 0.693 | 0.674 – 0.696 |
| logistic, r = 3.9 (median frontier) | 0.496 | 0.496 – 0.509 |
| Hénon | 0.420 | 0.414 – 0.421 |
| Lorenz flow | 0.906 | 0.87 – 0.93 |

Other measured quantities:
- **Protocol invariance:** three sensor protocols give slopes within 1–7% of each other, with intercepts about 4 steps apart.
- **Past and quotient:** Fisher information about the past grows at $2\lambda$ (1.015 against 0.993), and observable quotients grow at $h$ (0.6931 at 2, 4 and 8 bins).
- **Information cost:** each certified step costs $\lambda/\ln 2$ bits of initial precision (Brudno, Pesin).
- **Hiding chaos:** the only way is to change the task, for example by re-observing the state, which is a declaration and is caught.

See `RG - Chaos Is Not Hidden.pdf` and `RG - Chaos Frontier Status Map.png`.

**The final remainder (L116–L123) and its local classifier (L124–L128).** The question was whether what survives all local repairs is a new primitive or global structure. On constant-type strata it is global structure. The battery runs 18 attacks and 4 canaries with master seed 20261022; every canary is rejected, and fresh-process reruns give identical results.
- **Rigidity refuted:** $C=\tfrac12 I_3$ has rank 3 and $\dim\mathrm{Aut}=3$, more than $\dim\mathrm{Aut}=2$ at rank 1.
- **Dimension zero is not trivial:** distinct full-rank correlations give $\mathrm{Aut}\cong\mathbb Z_2^3$, which has dimension 0 but 8 elements.
- **Random sweeps miss strata:** 5000 Gaussian couplings find no counterexample, because the bad stratum has measure zero.
- **Local invariants are incomplete:** a Möbius RG family over $S^1$ has constant spectrum, constant canonical correlation and constant Aut, yet is globally nontrivial.
- **Contractible bases are trivial:** brute-force gauge orbits for $S_3$ give 1, 3 and 11 classes on a tree, a circle and a figure eight, as predicted.
- **A $-I$ triple defect is not by itself a gluing failure:**
  - on a filled triangle it can always be removed by re-choosing a transition;
  - on $\mathbb RP^2$ it cannot: the $\mathbb Z_4\to\mathbb Z_2$ lifting defect survives all $2^{15}$ lifts.
- **Forced wall monodromy:** around a codimension-2 collision of canonical correlations, the singular line bundle returns with sign $-1$; around a loop that does not enclose the wall it returns with $+1$.

See `RG - Final Remainder.pdf` and `RG_final_remainder_bundle.zip`.

**The wall–tap experiment (origin, L0–L115 on one system).** The experiment is declared as five cumulative acoustic protocols.
- **Saturation:** unresolved directions fall 5, 4, 3, 2, 2 by kernel intersection, and close only with length and gain anchors.
- **Hidden fold:** the rhythm channel hides an exact $\mathbb Z_2$ fold, $b \leftrightarrow 2d(x)-b$, on 56% of the domain. It is a wall inside the regular stratum, removed only by a new signed channel.
- **Matched wall:** specialization holds under Hellinger continuity, with Fisher rank 3 → 1 and Cramér–Rao bound $O(\varepsilon^{-2})$.
- **Medium:** wind turns echo distance into the acoustic Landau–Lifshitz metric.
- **Closure:** 3000 random requests per seed gave 0 false LOCKED; seven sabotaged certificates each produced false locks.

See `RG - Wall-Tap Experiment.pdf`.

**Distance versus angle (L93).** Perceived time can be distorted in three ways, and each preserves a different amount:
- **offset:** preserves differences;
- **rate:** preserves ratios and angles, not distances;
- **warp** (total rupture): preserves only order and counts.

Under memory loss, a remembered distance calibration degrades like $\sqrt T$ (measured exponent 0.494–0.510), while angles from delays measured together stay exact. See `RG - From the Wall to the Kernel.pdf`.

**Quantum task changes holonomy (L38–L43).** On the same qubit slice the SLD metric (estimation) has curvature +1, while the BKM metric (Stein testing) is negatively curved. Metric selection is task-relative, and so is observable transport. No noncontextual hidden values exist: 0 of 512 assignments satisfy the Peres–Mermin square, and Fine's criterion agrees with linear programming on 60/60 random boxes.

**Uncertainty is not a primitive (L49–L58).** Two priors merge on the quotient as $1/n$ and stay apart along the kernel (0.312 at every sample size). On a declared class of bounded variation, mixing locks with a sharp constant:

$$
\mathrm{TV}(T^n_\sharp\mu_f, T^n_\sharp\mu_g) \le 2^{-(n+2)}\,\mathrm{Var}(f-g),
$$

attained exactly at every $n$. Over a finite list of declarations nothing is certified. See `RG - Uncertainty Geometry.pdf` and `RG - Uncertainty Geometry - Forgetting Ladder.pdf`.

**Latent transport is declared (L79–L80).** Vertical shears preserve the law and map any connection to any other. Under a declared covariance, the Kalman/RTS connection is canonical. Its latent holonomy around a closed observed loop scales as the loop's area, and it depends on the declared covariance.

---

## Crossing into physics (real data)

RG does not claim assumption-free physical values; no framework can (Duhem–Quine; Le Cam, L56). It certifies a
**physical value conditional on a computed residual assumption set**, by agreement of independent routes.

- **`RG - Real Measurements.pdf`:** real GEONET dual-frequency GPS data.
  - One calibration is made on station A and frozen. It then serves station B, the baseline, uncertainty coverage and the swap.
  - Every RG layer is ablated: removing the Sagnac term gives 27.6 m, the relativistic clock term 8.7 m, frequency diversity 5.9 m, and the clock nuisance more than 10⁵ m.
- **`RG - Crossing into Physics.pdf`:** the consilience engine.
  - **Routes:** four routes to one baseline split into two contradicting clusters, so the status is CORRESPONDENCE.
  - **Tie-break:** it is resolved only by pre-registered tests of each cluster's distinctive assumption. The phase cluster's integer ambiguities pass (chance about 10⁻⁴); the code cluster's whiteness is falsified by constant per-satellite biases (z up to 9).
  - **Result:** 3335.3913 ± 0.0034 m, LOCKED conditional on five listed assumptions.
  - **Curvature:** physical-curvature effects are typed by resolution. Sagnac and the relativistic clock term are detected; the Shapiro double difference is a STRUCTURAL WALL at 3.5 mm.

- **`RG - Stress Tensor.pdf`:** the stress tensor as an RG target.
  - **Two routes:** a geometric route (the Einstein tensor of a metric resolved to second order) and a source route (field stresses, or the kinetic moments ∫ pᵃpᵇ f dΠ). Their agreement is the field equation, read as a consilience test.
  - **Exact results:**
    - the Schwarzschild exterior has curvature but T = 0;
    - Reissner–Nordström geometry equals the Maxwell stress, and a wrong charge is INCONSISTENT;
    - on FLRW, the radiation and dust routes agree with the geometric route;
    - a massless scalar and a stiff fluid give the same background (a source CORRESPONDENCE);
    - the radiation stress given only its energy is the set {S ⪰ 0, tr S = ε};
    - ℓ ≤ 2 angular harmonics are the minimal sufficient panel;
    - metric agreement does not control stress, so a C² certificate is required;
    - stress anisotropy is forgotten exactly as (1−s)ⁿ.
  - **Not claimed:** that GR does not need spacetime. The metric can be an RG output, but the field equation is imported (Lovelock).

- **`RG - Quantum Bridge.pdf` (print edition, supersedes the first edition):** the passage from quantum observations to geometry as a conditional, task-level construction.
  - **Exact certificate:** the final task is constant on the complete admissible fibre. Identifying every intermediate link is sufficient, not necessary; the first edition's weakest-link rule is demoted to a conservative sufficient rule.
  - **Repairs:**
    - raw second moments replace centred variances;
    - the quadrature proxy is separated from physical stress, with an explicit conserved cavity-mode stress;
    - the Gaussian width is ill-conditioned, not a structural wall;
    - the micrometre superposition is CONDITIONAL, not FORCED.
  - **Walks:**
    - Gaussian, forward and back;
    - backreaction (contraction theorem; Schrödinger–Poisson fixed point);
    - a fourth-moment source task;
    - a finite-shot, dephasing-aware entanglement witness with a negative certified bound (synthetic).
  - **Checks:** 24/24 checks, 8/8 mutations, a replay verifier, and an independent 10/10 audit.
  - **Open:** coupling selection, and full curved-background semiclassical closure.

- **`RG - Physical Curvature.pdf` (final edition):** RG doing physics with its own geometry, with no GR or QM imported.
  - **The object:** the canonical connection B = PJᵀ(JPJᵀ)⁻¹ (L80). It is a law of motion under H-resp, which holds exactly for overdamped bodies (P = mobility) and for free bodies with zero conserved momentum (P = inverse inertia).
  - **Geometry:**
    - holonomy is area times curvature, to leading order;
    - an exact apparatus gives 9.9995 µm;
    - three-sphere swimmer curvature (a/3)[L₁⁻² + L₂⁻² − (L₁+L₂)⁻²];
    - a falling-cat body reorients by −0.2748 rad;
    - reciprocal strokes cancel exactly (Purcell), while zero signed area does not imply zero holonomy.
  - **Duration:** T_min = ℓ/√W and E_min = ℓ²/T. Unloaded displacement is rate-independent, and the connection alone supplies no absolute clock.
  - **Load:** the response is affine, v = Bq̇ + (I−BJ)Pf_ext, giving a linear load law with a stall force. Nonzero momentum adds a drift.
  - **Evidence:**
    - original battery: 10 physical checks plus 1 status check;
    - passive-fluctuation calibration predicts active swimming within 0.15–6.4% over ten runs;
    - frozen holdout on 24 strokes: displacement 0.47%, duration 0.066%, stall residual 2.3×10⁻⁶;
    - 18/18 checks pass, canaries 10/10, and the independent audit passes 10/10.
  - **Not claimed:** spacetime curvature, laboratory validation, or priority over the gauge theory of deformable bodies.

- **`RG - Gravitation.pdf`:** gravity computed on RG's terms, with Einstein's equation selected rather than postulated.
  - **The stack:**
    - null data give the conformal class (cone stratum), and anchored clocks give its scale;
    - conservation gives the motion of matter (Geroch–Jang);
    - consilience under locality, metric-only, second order, identical divergence-freedom and D = 4 gives G + Λg = κT (Lovelock);
    - spherical vacuum is Schwarzschild (Birkhoff), and the rr equation excludes the clock-invisible γ-family.
  - **Countermodels:** the Ricci-only law is inconsistent; f(R) is fourth order; Gauss–Bonnet survives only in D ≥ 5; a pressure-blind source law is refuted by clocks.
  - **Calibrations:** κ = 8πG is provably only a unit anchor (TOV homology; exterior tasks need just m = GM/c²), and Λ is a window.
  - **Predictions:** calibrated from Kepler orbits alone, the stack predicts Mercury's perihelion advance (42.98″/cy), the solar deflection (1.751″), the GPS clock frequency (10.22999999543 MHz) and the Pound–Rebka shift (2.46×10⁻¹⁵).
  - **Checks:** the retained backend passes 25/25 (byte-identical rerun), and the stack battery passes 16/16 with canaries 4/4.

## Computational complexity

| Task | Cost |
|---|---|
| kernel of a finite law table | linear hashing, union–find |
| minimal sufficient panels | output can be $\binom{m}{\lfloor m/2\rfloor}$ (Shamir threshold system); a panel of size ≤ k is NP-complete (Minimum Test Collection) |
| stratification of a semialgebraic law | doubly exponential in dimension (cylindrical decomposition) |
| rank certificate | $O(d^3)$ per escalation level |
| coupling stabilizer and multiplicity type | $O((p+q)^3)$ (SVD) |
| Čech gluing on a finite atlas | $O(\#\text{triples}\cdot d^3)$; the obstruction is the cohomology class, not the raw defect |
| certified chaotic forecast to horizon $n$ | at least $n\lambda/\ln 2$ bits of initial data |
| TV certificate without a declared class | impossible from finite samples (Le Cam) |
| Monte Carlo on a FORCED output | $O(\tau^{-2})$ draws |

Exactness is cheap at the exact layer. It is expensive in exactly three places, each reported where it arises:
- selection;
- stratification;
- chaos.

---

## How to read the corpus

1. **`Resolution Geometry.pdf`**: the statement of record (print edition).
2. **`RG - The Groupoid of Resolution.pdf`**: the theory as one groupoid climbing the ladder, bottom-up and top-down, showing what each hypothesis does to it.
3. **`RG - Final Remainder.pdf`**: what is left after every local repair, why it is global structure and not a primitive, and where that answer stops.
4. **`RG - From the Wall to the Kernel.pdf`**: the origin and progress account, including the Terror experiment made exact.
5. **Module papers**, listed below, each with a same-stem ZIP containing its hostile battery.
6. **Historic syntheses**: development record only.

**Statement-of-record rule.** Where a module paper and `Resolution Geometry.pdf` differ in scope, hypotheses or status, the ladder governs. **Citing:** cite the rung (for example "RG, L90"), not the module paper.

**Notation.** In the ladder, $\Gamma$ is the effective symmetry group $\mathrm{Stab}/\mathrm{Gau}$. The early characterization papers use $\Gamma$ for the admissibility protocol, which this README writes $\Pi$.

---

## The atlas (after the ladder)

The ladder states what RG proves. The atlas states how a concrete system is **charted**.

A layer fixes three things:
- the structure carried by charts;
- the compatibility condition on overlaps;
- the query it answers.

A certificate is the layer's answer for one realization. It is one of: CERTIFIED, OBSTRUCTED, SINGULAR, TWISTED, CONDITIONED, CORRESPONDENCE, or NOT TESTED. Certificates answer different queries and are never merged into one verdict.

| Layer | Structure | Content | Rungs |
|---|---|---|---|
| A1 | sets, equality of laws | effective gluing; descent iff every fibre graph is connected; conversion iff kernel inclusion (5,651 contracts) | L0–L5, L9, L12–L15 |
| A2 | submersion, tensors | tensors descend iff basic (horizontal and invariant) | L18–L20 |
| A3 | Fisher metric | radical = ker DF; tensorial chart change; chart-free distance | L28–L35, L59–L63 |
| A4 | strata, walls | specialization iff kernel inclusion; Cramér–Rao ∝ ε⁻²; forced monodromy | L21–L27, L37, L122 |
| A5 | symmetry | gauge trivial on Q; Γ-equivariant charts; slices at cone points | L6–L11, L25 |
| A6 | global classes | twisted forms H¹; Leray covers; H² gluing class | L111, L119–L122 |
| A7 | error budgets | chain drift ≤ kδ; certified holonomy; Lipschitz constant 1/ε near walls; finite-sample charts as confidence sets | L16, L44–L48, L114 |
| A8 | anchors | dilation fibre; counted channel fixes the metre | L94–L109 |
| A9 | registry | ten realizations, from a finite law map to the full computation loop | all |

## Companion papers (attached to the closed ladder)

| Companion | Attaches at | Content and status |
|---|---|---|
| `RG - Physical Path.pdf` | L28–L32, L119 | stress symbol, kinetic cone, energy conditions forced, defect charge conservation; source-remainder no-go for gravity |
| `RG - Gravity Duality.pdf` | L80, L102–L104 | Jacobi pencil (h, N); Newton fails exactly when structure is resolved |
| `RG - Light as Emission.pdf` | L102–L105 | projection formula; the mirror image as a quotient point |
| `RG - Cornering.pdf` | L13, L43, L49–L57, L94 | floating box as a resolution window; luck typed: relative, gated physical, ontological |
| `RG - Undermining Spacetime.pdf` | L2, L27, L119 | spacetime as a selected representative; permanent fibres |
| `RG - Both Sides.pdf` | L19, L117–L119 | hidden versus null; Einstein operator selected; second order by H-min plus data |
| `RG - Full Computation.pdf` | L12, L16, L47, L124 | tensors from probe histories; coupling tested on held-out data; first nonlinear term |
| `RG - Ladder Organization.pdf` | all | second edition, for L0–L133 and 56 companions. Regenerated views: metro map, 98 hand-overs between 50 branch pairs, 30 walls, gates, longest chains, anti-ladders (unchanged for L0–L123), audience readings, 12 pipelines. New instruments: anti-connectors (common cone and meets of two results), destructor (what falls with a rung or gate, rungs and companions), dispatcher (typed status and missing gates under a declaration profile). Unity audit against a scattered-toolkit null: all 51 non-meta companions rest on L0, L1, L2, L6, L9, L18 (L21 in all but the record metric); no branch hangs from the root; connected without the root; 98.3 % of cross-branch rung pairs share more than L0 (null: 27 components, 17 root-only branches, 0 %). Five executable walks from the wall-tap (unit, gauge, wall, cone and clock, protocol) built on one construction: hole dimension of six root laws by five unrelated methods, every row constant, mixed pipeline caught; 43 ladder edges witnessed (22 hand-overs) in 12 of 18 branches, each checked against the print. One World typed as a gluing statement at L43 with a falsifier (classical section iff CHSH ≤ 2; one quantum state at 2√2; PR box excluded). Six audit findings: A1 and A2 proposed, not applied (A2 now 103 rungs, all 50 companions); A3 applied by discharge (H-resp reduced to H-cov), A4 (attachments of three companions) and A6 (companion table) applied. Four rungs carry the class D (L29, L39, L74, L80). 11 witness groups, 16 mutations caught, byte-identical |
| `RG - Realization Atlas.pdf` | all (Section 23 of the print) | layers A1–A9: contract, theorem, witness and boundary per layer; registry of ten realizations with per-layer certificates; battery `rg_atlas_full.py`, which reruns layer 1 |
| `RG - Information Loss.pdf` | L0–L16, L129–L131 | contract-relative classification of information loss; star rooms K_v\∏K_v/S_i^∞ for compact gauges; uniform-limit criterion at isolated points |
| `RG - Physical Shortcut.pdf` | L64–L68, L102–L109 | anchored arrival advantage; transit sign law v_c = 1/√(2+γ); gravity train; no advance of light under NEC |
| `RG - Mesh Spacetime.pdf` | L111, L119, L131 | curvature as gluing defect of local systems; mesh closure under coverage, obstruction tower as completion |
| `RG - GR Without Spacetime.pdf` | L2, L19, L117–L119 | every GR prediction descends to local data, a selected law and relational readouts; spacetime is a representative |
| `RG - Spectral Identifiability.pdf` | L122, L129–L131 | the first complete instance of RG's information-loss rule: sharp eigenline moduli; exactly n−1 extra analyzers; exact noisy holonomy threshold max(π/N, π/2−2α) for every estimator; rank-m orientation holonomy; the continuous holonomy is not finitely identifiable; statistical rate; simulated coupled-oscillator readout |
| `RG - GR Conditional Naturality.pdf` | L19, L117–L119 | GR+Λ is the unique consistent theory for a single massless spin-2 field that is local, Lorentz-invariant and parity-even, with ≤2 derivatives in D=4 (cubic vertex computed; all orders imported). Each declaration is tested on real data: Pantheon+ (Λ measured, Λ=0 rejected), binary pulsars (extra radiation <1.6e-4), GW170817 (c_T=c to 1e-15), Cassini (BD ω>4e4). D=4 and ≤2 derivatives remain untested |
| `RG - GR Adversarial Brief.pdf` | all physics companions | ten counts against spacetime realism and universality, each with direct and indirect evidence, the strongest defence, and a typed verdict. GR is acquitted as a predictive law: its nonlinear self-coupling is measured (β = 1 ± 2.5e-5, carrying −14.33″ of Mercury's 42.98″/cy), and its radiation and structure sectors are pinned. Conceded: substantival spacetime, derivability of the field equation, universality (singularities; two-loop R³). Contested: dark sector, D = 4. The honest exit is structural, effective realism |
| `RG - Composition Rigidity.pdf` | L2, L12, L38–L43 | RG's native gates (composition descent, extension completeness, in-family closure, continuous extension-stable reversibility), frozen by hash before any run, cut an atlas of operational theories strictly to complex QM, with obstruction certificates. Extension-complete transformation quotient ⇔ local tomography (real QM: identity ~ transpose locally). Extension-stable qubit dynamics = SO(3) = PU(2), with Hamiltonian generators. All 300 random polygon theories eliminated. Unrestricted uniqueness imported (Hardy; Chiribella–D'Ariano–Perinotti; Masanes–Müller) |
| `RG - Quantum Mechanics.pdf` | L35, L38–L43, L53–L55, L128 | the quantum print. Rigidity (complex QM unique on the frozen atlas); trace rule as effect-quotient descent; Petz sufficiency as RG's descent theorem with modulus Θ(Δ^½); task-declared metrics (SLD = estimation, BKM = relative-entropy Hessian, WY = 8 × skew information); extension gate = complete positivity, forcing unitary and GKLS classes (GKLS criterion 120/120); hidden vs null in the Heisenberg picture; non-Markovian memory, environment ≥ max Choi rank; H identification with 3M+1 samples, sharp alias at 3M. H is selected, not derived — the same theorem shape as GR. Includes an adversarial ledger for quantum realism (PBR as the defence) |
| `RG - GR-QM Multiscale.pdf` | L64–L68, L102–L109, L38–L43 | consolidated GR–QM protocol paper (supersedes "GR-QM Experiments"). Eight protocols with explicit admission/abstention; spectral mass–field degeneracy (rank one); joint reversal ≠ reduced recovery; neutron shape/scale covariance; Ramsey shot-noise inference (9 admitted, 27 abstained); 35 aggregate checks, passing in two environments; conditional six-row audit Q = 3.37, p = 0.761; Pantheon+ refit Ω_m = 0.3326 |
| `RG - Cencov Theorem.pdf` | L28–L29, L35, L38–L41 | Čencov's theorem derived from RG's experiment-level descent: a Markov map has a Markov left inverse iff it is a congruent splitting, so a continuous positive descending metric is c·Fisher (one constant across all dimensions), equivalent to H-mono. Necessity of each hypothesis (continuity open). Quantitative e^{±2ε} stability, recovery calculus, and no-gos. Quantum descent keeps every Petz metric and selects none, which forces the L39 task lock. RG exists because of Čencov: the classical layer is forced, and the rest is needed exactly where uniqueness ends |
| `RG - Hessian Theorem.pdf` | L28–L29, L35, L38–L41 | Hessian Čencov: every divergence that vanishes on the diagonal, is C², nondegenerate, and monotone under all Markov maps has Hessian c·Fisher (for f-divergences c = f''(1)). Fisher = Hessian of negentropy = Hessian of the log-partition (Legendre-inverse); KL = Bregman of both. Ignorance converts exactly: KL loss = integrated Hessian deficit = conditional score variance; recovery TV ≤ √(L/2); CR inflation Δ/(F_in F_out); F_β = k_B T² C_V gives the thermometry floor ΔT ≥ T√(k_B/(n C_V)). Quantum: descending divergences give the Petz band (BKM = Hess negentropy, SLD = 2 Hess(−log F), WY = 4 Hess(−log affinity)). Exact symbolic battery, no random sampling |
| `RG - Rooting Closure.pdf` | L53–L55, L129–L133 | how much RG's root (Čencov + Hessian) closes by itself. Local comparability makes wall invariants (fibres, orders, RLCT rates) divergence-independent; one local forgetting rate (squared maximal correlation), with the finite rates a band; invertible dynamics never forgets (chaos forgets only through the protocol); exact Markov-partition chaos (doubling map: 1 bit/step); chaos amplifies parameter Fisher at e^{2λn}. L133 closed for stochastic forcing (Hairer–Mattingly), reduced to uniform mixing for deterministic forcing; L132 local rate types closed, global enumeration not reached; Čencov continuity closed for Hessian metrics. Not reached: field equations, the Hamiltonian, the Petz bound, quantum walls, finite panels |
| `RG - Structural Closure.pdf` | L53–L55, L122, L129–L133, A1–A9 | RG's global layer placed in recognized frameworks, with RG corollaries proved: o-minimality (RG objects definable; finitely many fibre types and a finite atlas per tame family; a gauge crosses a singular point iff definable-curve limits agree, so rays fail and curves suffice; moduli are power laws with rational exponents); nerve theorem (coverage conditions = good covers; exact mesh and holonomy closure); Čech descent and obstruction theory; von Neumann–Wigner codimension 2 and monodromy −1; Birkhoff–Hopf tanh(Δ/4) forgetting, uniform for forced protocols; Lasota–Yorke spectral gap. Tameness is necessary (sin(1/θ) canary). Uniform tame enumeration and deterministic mixing are not reached |
| `RG - Engagement Case.pdf` | all | the paper for the reader who intends to decline. Twelve exact silent failures of standard tools (Fisher-equal but non-equivalent experiments; ray-wise limits; correlated "independent" rows; unitary-but-irreversible reductions; coordinate components as predictions; the equivalence-principle half-deflection; real-QM identity vs transpose; …), each caught by a named RG object. Four pairwise-distinct kinds of ignorance (null, hidden, room, obstruction). Seven dilemmas from cited theorems (Čencov, hole argument + Choquet-Bruhat–Geroch, Lovelock + Goroff–Sagnotti, Petz, nerve, Hardt, data processing + Kalman). Objection matrix, falsifiers, novelty ledger |
| `RG - Perfect Window.pdf` | all | the first-exposure paper. Part I: ten plain scenes (keyhole, identical rooms, better instrument, observer inside, two questions, notebook, horizon, building of rooms, tomorrow, four kinds of dark). Part II: each scene as a formal layer, with proof, internal critique loops, the silent failure of the old tool, and the RG object that catches it. Assembly: the No-Perfect-Window theorem — refinement never implies completeness; six checkable obstacles (symmetry, capacity, horizon, global class, reduced access, chaotic precision); with the measured Λ > 0, every comoving observer has a 16.2 Gly event horizon. Eight disciplinary critiques with a corrections log; the burden of proof is converted |
| `RG - Monotonicity and Lorentz Sign.pdf` | L28–L29, L35, L38–L41, L64–L68 | why frameworks agree on monotonicity and Fisher. Simulation (Blackwell; f-divergences as mixtures of decision values) forces monotonicity; descent forces Fisher, a weaker hypothesis than monotonicity; LAN makes Fisher the large-sample universal; the second law is data processing. Fisher can never be Lorentzian, and negative observed information is not a signature. The Lorentz sign comes from Koszul–Vinberg cone characteristic functions (radial reflection −(α/q)Hess q), the qubit cone (det(tI+x·σ) = t²−\|x\|², SL(2,C)), and hyperbolicity: one declared non-monotone direction plus a positive block supplied by monotone geometry. The ledger separates the Fisher sign, the signature convention and the curvature sign; the supplied battery's wrong-sign certificate is a Type-S error at near-null truth (expected 1.44, observed 1). Companion: the user's protocol package |
| `RG - Operational Agreement.pdf` | L0–L19, L94–L109, L129–L131, A6 | the Operational Agreement and Geometric Descent Principle: six conditions under which many observers have reconstructed the same geometry, proved by gluing and Čech descent (global chart iff the class vanishes; no global object if the cocycle fails). Seven executed series: Penrose staircase (pairwise agreement, holonomy 0.309 → false global map rejected); a miscalibrated conversion located from triangle residuals; three lenses on one sphere (χ = 2 exactly, curvature × rod² within 0.5%, raw readings ×100 apart); forgetting (~91% each, 100% joint; a commonly hidden cap is an exact fibre); orientation by redundancy with spectral-gap abstention; scale and rotation nulls until anchored; no faked structure (0/200); thin overlaps → abstain |
| `RG - Experiments Simulation Descent.pdf` | L0–L19, L28–L35, L53–L55, L64–L68 | the structural (Čencov-style) derivation, as pure mathematics. Experiments are distributions of posterior beliefs: garbling = conditional averaging, simulation = convex order = dominance in every decision task (Blackwell–Sherman–Stein, proved via Farkas); equality = recoverability by one map; the category of experiments with lossless morphisms = congruent splittings, whose posetal reflection is the poset of Bayes-plausible measures; descent = factorization through it. The bounded quotient is compact Hausdorff with a closed order, metrized by Le Cam's distance (proved). Non-idealized Čencov: approximate descent gives e^{±2ε}; Le Cam closeness controls Fisher iff derivatives are controlled. Basic tensors descend; filtrations develop information monotonically (martingale); physical time is monotone only with a fixed reference. Lorentz bridge: cone dilation forces log-homogeneity; the radial reflection has Lorentz inertia; quadratic exactly for rank-two symmetric cones (spin factors, including the qubit cone) |
| `RG - Wall-Tap Structural.pdf` | L1–L22, L46, L52, L70–L82 | the wall-tap delay as theorems. Influence, identification and reported latency are separated. Mediation: equal intervention laws and optimal error ½ before the mediated arrival, nonincreasing afterwards; the delay structure is a Lawvere metric (Randers under wind) that fixes order, not seconds. Eikonal origin: first arrival = acoustic geodesic distance; image sources; positivity needs c < ∞, D > 0 and a clock. Topology: exact onset is fragile even in TV; threshold times are stable iff the crossing is strict. The fold is an orbifold point (zero normal derivative, ε^{1/2} modulus), split by a signed channel. Symmetry generators are exact Fisher null vectors (dilation, gain–contrast), and anchors break exactly these; Woodward timing E β²/σ²; wall information ∝ ε². T_c = (τ_d/2) ln[(θ/(1−θ)) a²τ_d/(2e₀τ_p)], dilation-covariant: 35.58 ms is a room constant |
| `RG - Topology.pdf` | L0–L22, L35, L129–L131 | a path to topology beside the star (Gelfand–Naimark) construction: from experiments, via the resolution interior 𝔯_𝒫(A) (where A can be confirmed by the protocols). From four operational axioms (finite records, parallel composition, declared error, abstention), the verifiable propositions are closed under finite conjunction and countable disjunction; for finite-outcome protocols they are exactly the preimages of open sets of the law map, so 𝔯 is a Kuratowski interior. The T₀ quotient is the observational (ignorance) quotient; a monotone functor from the Blackwell order, invariant under lossless re-descriptions, not faithful; one-sided detectors give non-Hausdorff topologies (Sierpiński), with exact onset lower semicontinuous. Reach: every second-countable T₀ space (one-sided protocols), every separable metrizable space (coins); physical observation topologies are second countable. Meets the star path on the commutative Hausdorff case |
| `RG - Tides.pdf` | L1–L22, L53–L55, L129–L131 | tides as an RG test with real data (UTide example gauge can1998: 8,760 hourly values, 1998). Exact lunar forcing (1.128/1.074/−0.550 µm s⁻²; quadrupole (2,−1,−1); equilibrium +0.357/−0.179 m; Sun/Moon 0.459; M2 12.4206 h); the quadrupole sees the axis, not the direction (RP²), and odd terms (M3 = 6.8 cm here) resolve it. Theorems: unique damped response; basin fibre (harmonic constants fix only H(ω_k); two rooms agree exactly there and differ off-band); Rayleigh resolution (K1/P1 needs 182.6 d) and inference as a declaration (P1/K1 0.403 vs equilibrium 0.331); prediction ceiling. Out-of-sample skill 0.762 (RMSE 0.217 m), non-tidal floor 0.172 m (80% of the error), 88% of the residual is subtidal; hidden, not null: the record's memory nowcasts 0.217 → 0.062 m at 1 h; i.i.d. 95% band covers 91.9% |
| `RG - One World.pdf` | L38–L43, L53–L55 | the quantum–classical divide as a change of protocol on one entity: a spin j under one Hamiltonian. Means follow the classical law exactly for Lie-algebraic H; a sharp parity protocol violates Leggett–Garg (K ≈ 1.19 for j = 5…40); a coarse sign protocol of resolution 2√j satisfies it and is nearly non-invasive (5×10⁻⁵ vs 0.47 at j = 40). Twisting dynamics shows a coarse-grained quantum reversal at t = πj (−1 vs classical +1) that an unobserved environment erases, so classicality needs coarse read-out plus environment bookkeeping. Collapse = protocol record with a unitary dilation. Conclusion: no physical divide is required (conditional on universal QM); the measurement problem and gravity-scale tests remain open |
| `RG - World Without Puzzle Pieces.pdf` | L0–L22, L53–L55, L129–L131 | the RG world picture, preserving every working result. Parts are observable-induced quotients that close (one state: 1 ebit for one choice of parts, 0 for another); wholes are not sums (deuteron −2.2246 MeV; quark masses ≈ 0.96% of the proton); constituents depend on probe resolution (DGLAP, confinement); elements are chemical fibres (Cl 35.453 as a mixture; isotopes hidden for chemistry); scale separation is a ratio of clock counts (closure error O(ε)); organisms are task-relative closures (host and microbe close only jointly), so the bacterium is inside (position), separate (replication) and part of a composite (metabolism) at once. Viruses, transfer and illness typed; quantum effects are what fine protocols read of one law; consciousness not claimed |
| `RG - From the Wall-Tap.pdf` | L0–L41, L53–L55, L64–L68, L129–L131 | the standalone derivation: one experiment (tap, wait, record) and declared assumptions, with complete proofs and established names given only afterwards. Records → stochastic processing; exact laws → descent and the predictive quotient; simulation → monotone risk; reversible refinements = disjoint splittings (225 maps, 24 recoverable); finite records → topology of confirmation (hybrid bound + elementary verifier), Hausdorff on the quotient; overlapping observers → gluing iff every cycle holonomy is trivial; declared regularity → forced c·Fisher (and e^{±2ε} when non-ideal); exact sum-of-squares deficit → Hessian selection, error bound, monotone development, confirmation identity; a Lorentz sign only from a radial declaration. Five obstructions; full assumption ledger |
| `RG - Ignorance Before Uncertainty.pdf` | L0–L22, L28–L41, L53–L55 | the structural uncertainty paper. Hierarchy: ignorance (fibres; needs only records) → uncertainty (+ a declared quantification) → probability (+ stable repetition) → geometry (+ regularity) → quantum (+ noncommuting positivity). Ignorance and uncertainty are independent, and ignorance is the infinite-data residue (fibre floor at every n), so RG's order is correct. Uncertainty ≠ probability; the canonical spread is the posterior law (scalar spreads are task functionals; Monte Carlo samples laws); uncertainty geometry is the dual of Fisher (F⁻¹, contravariant), not standalone. Floors: fibre, two-point, Cramér–Rao (with nuisance), singular-wall n^{-1/4}, Fano, resolution, confirmation, distribution-free width; quantum: preparation (Robertson; qubit Var X + Var Z ≥ 1; H(X)+H(Z) ≥ 1 bit), joint measurement, estimation (QFI N vs N²). Luck belongs to a realization, uncertainty to a law, ignorance to a protocol |
| `RG - Source of Gravity.pdf` | L64–L68, L94–L109 | non-spacetime attractors and the source of gravity. Three meanings of attractor kept apart. On any connected relational network (no coordinates or metric): exact balance from local exchange; shift-blind, reciprocal, isotropic response = Laplacian; the Poisson constraint is a global attractor of relaxation modulo the gauge constant (5 random starts to 5×10⁻¹²; spectral-gap rate); decisive two-source test matches κL⁺Δρ to 5×10⁻¹³, coupling-off control gives 0; 3-D point source a/r + b (4πa = 1.055, box-corrected), force ∝ r⁻². No-go: conservative dynamics has no attractor (Liouville), so SCAR's negative result is a theorem; the scalar attractor fails light bending (0″ vs 1.751″). Tensor sector selected, not attracted: spin-2 gauge invariance and Bianchi force conservation; Lovelock (imported) under a declared cone, universal coupling and D = 4; Einstein–Hilbert is the large-scale attractor of local actions. Answer: B (consistency selector) |
| `RG - Physical Dynamics.pdf` | L64–L68, L94–L109 | physical dynamics, locked. RG principles lifted to the tensor: relabeling-null (gauge), reciprocity (self-adjoint), balance (divergence-free). On the general 5-coefficient two-derivative operator, any two force −2A·G⁽¹⁾; each alone leaves a 2-dim family; mass forbidden; linearized Ricci is gauge invariant but not divergence-free (symbolic, generic functions). GB EL ≡ 0 in 4-D, second order in 5-D; R² fourth order. Every vacuum Einstein metric solves R + αR² − 2Λ (SdS witness, Weyl ≠ 0). Global theorem: every expanding flat homogeneous vacuum solution converges to the de Sitter Einstein state, also above the plateau (48 runs, ≤5.7×10⁻¹²). Linear: scalaron decouples, decays at 3H/2 − √max(9H²/4 − m², 0) (fits within 2.1×10⁻³H), gravitons conserved (normal attraction, Liouville-consistent). Weak field: Yukawa 1/3, γ(r); Cassini range ≤1.1×10⁸ m, torsion balance sub-mm. Corrections to Source of Gravity: passivity must be declared; gauge alone does not give conservation. Declared: tensor field, cone, locality, two derivatives, D = 4, universal coupling, G, Λ |
| `RG - Tensor Derivation.pdf` | L64–L68, L94–L109 | standalone print of the full tensor chain (supersedes General Tensor). Records → protocol-profile metric (continuity without spacetime; realizes interval, circle, Cantor set: selects no geometry) → descent criterion and predictive metric d_β (exact identity, 1/β-Lipschitz, zero set = predictive quotient, completion) → walls: fold, waiting time, zero-support conditioning (2δ/ε bound and its failure) → balance on graphs and chain-map refinement → Gate A (realization, first-variation control: sin(nx)/n stress defect, admissibility: Burgers entropy +2/3) → Gate B reduced to a quadratic realization of free signature (p, q); second edition derives the rest: predictive closure (Lipschitz update) forces min(p, q) = 1 (definite and ultrahyperbolic forms Hadamard ill-posed, all (p, q) with p, q ≤ 4 sampled); propagation needs D ≥ 4 (G⁽¹⁾ selection holds in D = 3–6, D(D−3)/2 polarizations, Weyl ≡ 0 for a generic 3-D metric, zero static force in D = 3, G ≡ 0 in D = 2); stable record carriers need D ≤ 4 (Newtonian and Tangherlini orbits, Gauss-law atoms scale-invariant at n = 4 and unbounded below at n ≥ 5) ⇒ (1, 3); continuous-time lattice gives only an effective cone, u_r = J_2r(2t) → relabeling response = Hilbert tensor off shell (scalar, interacting scalars, Maxwell) ⇒ soldering, symmetry, source = cut flux; improvement freedom ξ_ij Rφ_iφ_j; universal coupling incl. disconnected sectors; compensator rank ⇒ one symmetric tensor = record metric; Koszul; Noether II; correction: totally antisymmetric torsion is invisible to stress, box and autoparallels ⇒ null by descent for bosonic records (Gate C for spinors); five-coefficient selection ⇒ G⁽¹⁾; field momentum ⇒ self-coupling; Deser/Wald/BDGH/Lovelock imported; destructor table (γ = 1/(D−3)), orbits, ghost, R + αR² embedding and weak field. 35 groups, byte-identical |
| `RG - Coherence Geometry.pdf` | L1, L27–L29, L35, L38–L41 | does coherence deserve its own geometry? Six criteria fixed in advance (identification, irreducibility, intrinsic structure, metric lock, morphisms, collapse loci); all pass under two conditions: non-simplicial record cone and declared frame. Maximal frame complete iff simplex; Peirce gap k d(d−1)/2 (k = 1, 2, 4); collisions for population, X–Z, scalar and magnitude records, d² settings complete. Dephasing = conditional expectation = twirl over Z2/U(1)/Sp(1); coherence = fibre over the population simplex (uncertainty geometry = base). Fibres of dephasing are unions of gauge orbits; gauge classes = populations, magnitudes, support graph, holonomy in U(1)^b1 (60 sparse states, b1 ≤ 10, gauge reconstruction); quaternionic holonomy non-abelian; holonomy changes admissible magnitude 1/3 → 1/6. Čencov holds on base, Petz freedom confined to the fibre (max/SLD up to 218); task lock: resolution (sup over protocols) selects SLD/Bures, Stein BKM, Chernoff WY. Berry curvature |C| = 1 on the total pure stratum (toric: populations = moment map, fixed-population fibres Lagrangian); Uhlmann curvature zero on commuting families; Gill–Massar joint obstruction; Kähler pure stratum, Schrödinger = Hamiltonian flow. C_r monotone iff MIO. Coherence = resolvability of the reference orbit (degenerate canary). local tomography admits classical k = 0 and, among non-simplicial cones, only complex (tensor composition) (real QM with modified composition noted). Classical waves realize the same geometry. 15 groups, byte-identical |
| `RG - Quantum Gravity.pdf` | L1–L2, L19, L38–L48, L64–L68, L94–L109 | third edition: conditional derivation of low-energy quantum gravity with an explicit dependency ladder. Descent criterion; polytope rigidity, composition identity K(ab) − K(a)K(b) = −k(k−2)/4·ab(a−1)(b−1), Masanes–Müller reconstruction; coherence fibres versus orbits; joint SLD obstruction; positive-pullback no-go; signature and dimension derived (predictive closure ⇒ Lorentzian; D(D−3)/2 polarizations, Weyl ≡ 0 in 3-D ⇒ D ≥ 4; Newtonian/Tangherlini orbits and quantum Gauss-law bound states ⇒ D ≤ 4); calibrated volume fixes the conformal factor; Dirac walk with exact cone, free Dirac bound TaP|M|, graded locality, number-current balance; Ward identity and improvements; linear Einstein selection, universal coupling; anomaly arithmetic; EFT with Riem³ = 96M³/r⁹ witness; relational observables and truncation defect; TV/KL discrimination (resource-relative); universal action quantum from exchange balance; thermal spectrum in n space dimensions (Wien roots x = n(1 − e^(−x)), b(n), T^(n+1)); n = 3 witnessed by absolute radiometry (Quinn–Martin σ at 0.93σ, exponent offset < 3.4×10⁻⁴); correction: the FIRAS-shape witness is withdrawn as circular; entangling phase Θ, negativity 0.078, LOCC canary; CNOT canary withdraws the classical–quantum exclusion. Third edition adds two sections. Kernel existence: for S = ½xᵀAx a degenerate A has a kernel only on the quotient by ker A, a definite A admits both e^(−S) and e^(iS) (phase e^(iπn/4)), an indefinite A admits no positive weight w(S) (level shells of infinite measure) and only the amplitude, (2π)^(n/2)|det A|^(−1/2)e^(iπ(p−q)/4) with covariance iA⁻¹; linearized gravity has D gauge zeros and exactly one negative direction, −(D−1)(D−2)/2·p² ((5,1) for D = 4, the conformal-factor problem); the free generating functional exists iff the source is conserved. Interacting 3+1 limit, typed: uniform discrete H¹ ⊂ L⁶ makes the cubic force Lipschitz on the energy space (endpoint: fails for p > 6 and in four space dimensions); classical quartic lattice field with smooth well-prepared data converges at rate a² with first and second source variations (ratios 3.90, 3.97, 4.02 at λ = 3); predictor a²E₁ (residual 36 %, 8.7 %, 2.3 %), dispersion ω² = m² + κk² − (κa²/12)Σkᵢ⁴ with direction factor 1, ½, ⅓, spacing bound a < 1.0×10⁸ ℓ_Pl for the nearest-neighbour stencil from E_QG,2 > 6×10⁻⁸ E_Pl (realization-specific: the improved stencil has no a² term); obstructions: alternating defect with energy 6κA² invisible to low records, laminate with effective tensor diag(1, 1, ¾), two-limit sequences; quantum scalar: zero-point ⟨q²⟩ ∼ a⁻² breaks the classical hypothesis, triviality imported (Aizenman–Duminil-Copin), λ(μ) ≤ 1/(b ln(Λ/μ)), measured λ = 0.1293 < 0.168 (scalar-only, Planck cutoff); gauge sectors remain open. 30 groups, byte-identical; 13 mutations of the new groups all caught |
| `RG - Observer Bounds.pdf` | L28, L34–L35, L38–L39, L64–L68, L81–L109 | does the limited observer do physical work? Dynamics map with status labels (derived, identified, witnessed, conditional, open): RG derives the form of known low-energy dynamics, predicts no new force, particle or constant. Five ceilings in one ledger (Cramér–Rao incl. Margolus–Levitin, Landauer, Bekenstein, cone + event horizon, resolution horizon). de Sitter E = TS exact: horizon energy = Landauer cost of horizon capacity (Padmanabhan equipartition, identified; Schwarzschild factor 2 canary). P1 grounded by measured Λ via the N-bound: log10 bits ≤ 122.679 ± 0.008 (conditional). Planck 2018: age 13.795 Gyr, particle horizon 46.14 Gly, event horizon 16.69 Gly at z = 1.871, reach 4.73 %; EdS canary. Photon rocket to Andromeda 28.6 yr at mass ratio 6.9×10¹². Witnesses: n = 3 by radiometry; FIRAS differential null is n-independent (circularity canary); D = 4 by GW polarizations and GW170817 damping (D = 5 excluded at 14σ); one ħ: Rb–g−2 2.15σ, Rb–Cs 5.49σ (Birge 3.9), qBounce 1.5 %. TUR proved as Cramér–Rao (Fisher ≤ Σ/2, 120 networks); clock ceiling ΔS_tick/2k_B. Resolution horizon finite iff p < 3, decade-gain ratio 10^((p−3)/2) = 0.215 at −5/3. Walk parity: 1-D and palindromic 3-D even, sequential 3-D linear with f = n_x n_y n_z; GRB 090510 recomputed 1.193 E_Pl; sequential walk at ℓ_P excluded for 26 % of orientations. Predictions with falsifiers: no linear delay (octupolar pattern if wrong), α convergence, clock ceiling, diminishing forecast returns, D = 4 at larger distance. 12 groups, 6 mutations caught, byte-identical |
| `RG - GR Automation.pdf` | L28–L35, L104–L106, L117, L120 | the locked pipeline (M, g) + (B, Σ, S) → (F, H_g) → (P_R, P_N) → A_RN → W_obs → T_obs on static regions, every arrow a theorem. Hole = ker B; the Killing energy form supplies the complement RG left declared (L117). Resolved sector = span of the detector's Green functions; health spectrum = spec(Σ⁻¹G), a complete congruence invariant on V/ker B; mesh-independent iff detectors are bounded on the energy space (1-D order h²; 2-D point probe grows ln 2/2π per halving: inadmissible). Identified with the likelihood-informed subspace (energy form = prior precision), Ky Fan, representer theorem, Kalman. Groupoid of the hole Morita equivalent to the quotient (finite witness; non-free canary). dP_R = −P_N H⁻¹(dH)P_R is purely the N←R block and equals the mixed stress matrix element; full-sector holonomy exactly trivial, truncation gives 0.0112, rotating detector −1 (Möbius, [K_N]); isometries leave the spectrum invariant, deformation-tensor rate verified in closed form. W_obs = quotient energy, E = W_obs + E_N (one-sided deficit, monotone refinement); envelope identity holds at fixed readings and fails in metric-dependent frames (omitted step, multiplier term); T_obs conserved off the detector, jump = detector force (Bianchi needs the detector). Schwarzschild shells: G_ij = min(u_i, u_j)/8πM with u = −ln(1 − 2M/r), capacitance 8πM/u₀, horizon wall, closed-form transport amplitude a(2M/r₀) = 0.0962 at 8M (hand-seeded 0.134 withdrawn). Exterior holes: null densities Δψ, multipole law, balayage vs L² complement; Birkhoff rank 1, two TOV interiors, Buchdahl wall. Lorentzian wall: indefinite forms have no split. Objections table; six predictions with falsifiers. 17 groups, 12 mutations caught, byte-identical |
| `RG - Tensor Frontier.pdf` | L1–L2, L28, L35, L64–L68, L94–L95, L117, L120 | second edition: forecast horizons, the tensor and the observer's boundary. The predictive metric d_β = (1−β)Σβⁿeₙ is the generating function of the forecast-error profile, with (1−β)εβ^n_ε ≤ d_β ≤ ε + β^n_ε; the exponent is the critical discount (Hölder exponent min(1, ln(1/β)/λ); doubling map 1, 1, 0.737, 0.415, 0.152). Upper boundary: no forecaster of a Gaussian record exceeds 2Φ(ε/s_n) − 1 (bound 0.7334; alternatives 0.585–0.732; second-record canary 0.884). Second-order law n_q = L/λ − z_q√(DL/λ³) + O(1) (exact binomial −3.129 → −3.139; skew tent −1.449 vs −1.446); the logistic map at r = 4 is a coboundary (variance π²/6, D = 0). Hole cap (horizons 15, 18, 18, 18, 18) and closure certificate in d steps (Kalman, identified). Refinement law: growth (2/a)√(min(p,q) − 1), horizon ∝ a unless Lorentzian; isometries of a positive form do not grow, growing directions of an indefinite form are null and paired; interacting quartic field in 3+1 has a spacing-independent bound. Tensor: slope 1/λ for every record (seven records, 1.428571); tidal tensor E = −Φ̈(0), exponents √(−eᵢ) (Schwarzschild diag(−2, 1, 1)M/r³, de Sitter −H²·1, matter era +2/(9t²)·1; Newtonian tide is the same tensor); Fisher volume law ∂²ₜ ln det I = −2 Ric(u,u), Liouville canary; the response law is the volume law for all observers (Baez–Bunn, identified); observer rank 1, 3, 6, 10, flux hole. Light ring: azimuth slope 0.9998 in ln(1/δ), e^(−π) per half orbit; Leaver ladder −ω_I/(λ_c/2) = 0.9245 (l = 2) … 0.9974 (l = 12); GW150914 remnant: 2/λ_c = 3.80 ms, imported Kerr fit 248.4 Hz / 4.06 ms, published 251 ± 8 Hz / 4.0 ± 0.3 ms (a GR prediction the data are consistent with, not an independent measurement). Sources: E δ² ≤ ε² + √((1−q)m₄), sharp; forecast deficit tr(MΣₙ) ≥ 0 at twice the exponent. Second edition adds the causal frontier. Causal cap: for an exact cone of speed C the exterior of a record of radius R is closed exactly up to n = R/C (leakage 0 before, cos^R θ after), and for a massless carrier the horizon is R/C at every precision and sensitivity, so C = dR/dH. Front, group, threshold: the front is at the cone speed for every mass; bulk and threshold arrivals are not (speed by sensitivity 0.598 → 0.719 → 0.777 → 0.993 for θ = 0.8). Frontier ≤ invariant speed K, and an observer-independent carrier attains it (von Ignatowsky and the reply loop, identified; reply arrives 0.547 before the question at 4K, 0.8K). Audit of the supplied seven-gate programme (regenerated exactly, 3.7497161154): the precursor scenario passes without the true value (it is a frontier at 3.7955); a truly locked frontier passes for 106 of 200 seeds only (linearity gate at the noise level); the covariance check cannot fail; a medium at rest passes all seven. Added gates: boost (medium 3.7502 → 3.6367 at 0.2 c_s) and maximality. Published raw data: Evenson et al. 1972 gives 53 835.1286(2) krypton wavelengths per caesium period; four determinations 1926–1972 agree with the adopted value (χ² = 3.8 for 4); microwave vs infrared (1.5 ± 3.3)×10⁻⁷; isotropy 2×10⁻¹⁸; observer velocity 2×10⁻¹³; source velocity 2×10⁻⁹; gravitational vs electromagnetic carrier −3×10⁻¹⁵ … +7×10⁻¹⁶ (reproduced from the 1.74 s delay). Rejected: exponent × boundary radius = c (holds for de Sitter and the Schwarzschild light ring, 0.5 and 0.64 elsewhere). 17 groups, byte-identical; 22 mutations caught |
| `RG - Magnetism.pdf` | L1–L2, L28, L64–L68, L94–L95, L117, L120 | Maxwell from a count, a phase and the cone; Biot–Savart as the static kernel. Conditional on two premises (P1: a conserved count whose carriers have phase records; P2: linear local vacuum response). Count ⇒ dG = J by the Poincaré lemma (4-D cochain complex, Betti (1,0,0,0,0); on the 4-torus, (1,4,6,4,1), a uniform charge has no excitation). Local phase is a hole, the record is the holonomy, F = dA (flat connection with loop reading 0.6 and F = 0). Maps on 2-forms commuting with the Lorentz group: dimension 2 (identity, Hodge star); rotations only: 4; hence G = λ⋆F, ε₀μ₀K² = 1, two polarizations at speed K; medium canary (0.765 K, 0.538 K for a moving observer). Descent selects a + b = 0, m = 0; one null and D − 1 positive directions (probability kernel on the quotient, unlike gravity); conserved source = existence; Gauss flux radius-independent iff massless. Biot–Savart = pseudo-inverse of curl–curl on the quotient: lattice Ampère, Coulomb gauge, energy identities to 1e-15; lattice loop field extrapolates to 7.19185 against continuum-with-images 7.19211 (3.6e-5; 1.5e-3 without the image term); loop on/off axis, dipole limit, linking numbers 1, 2, 0; parallel wires 2.0000e-7 N/m; exponent canary ρ^(−q). Representer: Neumann = Maxwell formula = flux (3e-15), reciprocity, least energy with Schur term 5.385, force = gradient of mutual inductance (1e-10), self-inductance diverging as μ₀R ln(1/a). Frontier in statics: boosted line charge gives μ₀I/2πρ exactly, force ratio β², μ₀ = 1/(ε₀K²) → 0 as K → ∞; single point-charge law wrong by (1−β²)^(−1/2) − 1. Data: static determinations of the frontier 3.1e8 m/s (1855) and 299 788 ± 30 km/s (1907, pull −0.15); α = Z₀/(2R_K), α⁻¹ = 137.035999177(21); photon mass < 1e-18 eV; linear response fails at 6e-27 at 1e7 V/m. 9 groups, byte-identical; 14 mutations caught |
| `RG - Light Ring.pdf` | L1–L2, L28, L35, L64–L68, L94–L95, L117, L120 | Hearing and seeing the light ring: one orbit, three records. Lock test of the joint relation shadow ↔ photon subrings ↔ ringdown. An unstable closed null orbit carries a frequency Ω and a forecast exponent λ; the shadow radius is 1/Ω, each further half orbit is demagnified by exp(−πλ/Ω) and delayed by π/Ω, and the ringdown is (l+½)Ω − i(n+½)λ in the eikonal limit (imported). No field equation of the background enters: ray tracing on Schwarzschild, Reissner–Nordström (Q = 0.8) and Bardeen (g = 0.5) gives b_c·Ω = 1 and azimuth slopes 0.99995, 1.12312, 1.08968 against Ω/λ = 1, 1.12317, 1.08974; the Schwarzschild factor e^−π is wrong by 41 % on the charged geometry. The single-mode relations fail at l = 2 by 22, 19 and 22 %. Mode ladder: two modes remove the leading correction whatever its coefficient; from l = 2, 3 the pair is recovered to 0.8 % and 0.4 % (gravitational), 4e-4 (light), 5e-5 (scalar); the error coefficient on the scale 1/(L₁²L₂²) is bounded (< 0.65) and constant to 8 % for the frequency, while plain mode spacing is not (13 → 48). Seeing from hearing: time-domain evolution (validated against Leaver to 2e-4 and 2e-3) predicts the shadow from two ringdown modes to 3e-4 and the subring exponent to 2e-3 on both non-Schwarzschild geometries; cross-geometry canary 8 %. One cone: the pairs heard and seen agree if light and gravitational waves share one cone (light vs gravity ladders agree to 0.75 %; two-cone canary 12 %); failure case identified in Einstein–Lovelock gravity; the converse is not claimed. Causal cap: a bump of height 1e-3 at distance 150 changes the signal by exactly 0 before the numerical cone, by < 1e-9 before the crossing time, leaves the prompt-window frequency unchanged, and returns as an echo delayed by 240.4 (predicted 240) at 1.2 % of the peak. Counts: 0, 1, 2 subrings at dynamic range 10, 100, 1000; 1.5, 2.3, 3.1 cycles at signal-to-noise 10, 30, 100. Forward numbers: Sgr A* shadow 53.3 μas (measured 0.92 ± 0.09 of it), half-orbit delay 345 s, zero-spin ringdown 2.81 mHz decaying in 238 s; GW150914 remnant: 366 km, subring factor 0.133, half-orbit delay 3.83 ms. Verdict: locks as a kinematic relation and a quantified test design; not new physics. Battery: 5 groups (LA–LE), each with a canary; 10 mutations caught. Bundle: `RG_light_ring_bundle.zip`. |
| `RG - GR Equivalence.pdf` | L1–L2, L4, L6, L9, L21–L24, L35, L64 | Where Resolution Geometry equals general relativity: a structural equivalence battery (SE-1 to SE-8) on the translation Ψ from models of general relativity with a covariant protocol to observation systems. Three versions of the theory are declared: all Lorentzian solutions; globally hyperbolic developments; either one with detector models and post-processing. Translation: gauge orbits lie in every covariant kernel (H-sound), so the quotient is a quotient of the moduli space and RG is never finer (six operational records of Schwarzschild agree in three charts to 1e-8, as does the Fisher information of the mass; the chart coordinate of the light ring takes the values 3, 1.866, 2.142). Holes: equality iff the protocol is complete (H-compl); stars of radius 4M and 6M with equal mass have identical exterior records and interior records differing by 23 % and 20 %; a plane-fronted wave has zero curvature invariants and tidal tensor diag(−f/2, f/2). Walls: for a compact group the rank of any invariant record is at most dim N^H (slice bound), attained at four points (generic 7; static observer near a spherical mass 2; plane wave 5, discrete symmetry; flat 0). Petrov types under complex rotations: rank and stabilizer I (2, 0), II (2, 0), D (1, 1), III (2, 0), N (1, 1), O (0, 3); walls are D, N, O; II and III are holes because their orbits are not closed (approach as e^−2t under a boost). With an observer the group is compact and nine rotation invariants separate these types; they are records of the pair (field, observer). Composition: the bare theory is a groupoid, RG is not; with post-processing adjoined composition is preserved; quotient sizes 4 → 3 → 2 → 2 under garblings, noise reduces total variation to 18 % without changing the kernel; two filtrations over one moduli set are related by none of 24 relabelings. Transport: a map inside the domain of dependence (proper time 1 − 1/e in two charts of Misner space to 1e-9); beyond the Cauchy horizon one datum has two flat extensions with opposite records, and closed timelike curves. Verdict: on this domain RG is general relativity as a deterministic initial-value theory with covariant detector models, organized by resolution; no physical difference found. Battery: 6 groups (SA–SF), each with a canary; 13 mutations caught. Bundle: `RG_gr_equivalence_bundle.zip`. |
| `RG - Gravity Closure.pdf` | L1–L2, L9, L64–L68, L94–L95 | From records to the Einstein equation, with the remaining premises named. Links 1–6 come from the companions: descent; the metric from clocks and radar; Lorentzian form and D = 4; symmetric, universally coupled source with the record metric as its compensator; the linear response G⁽¹⁾ from any two of relabeling-null, reciprocity and balance; the first self-coupling step. Balance and reciprocity are lifted to the full response, and Lovelock's theorem closes the nonlinear completion without any order-by-order construction, under two hypotheses: H1, the full response is local and of second order, the class of its linearization; H2, the metric is the only long-range gravitational field. Lanczos tensor ≤ 4×10⁻¹⁵ of the curvature scale in D = 4, of order one in D = 5, 6 (random algebraic curvature tensors, both signatures). Countermodels obeying every other premise: R + αR² (symmetric and divergence-free on a generic homogeneous metric, but fourth order), nonlocal gravity, Brans–Dicke (Cassini: ω ≥ 39 998). The torsion balance confines the R² Yukawa force below the sub-millimetre scale (bound read for strength 1, not 1/3). Ricci-only canary. Anchors G (a unit) and Λ. Kepler-anchored predictions: Mercury 42.98″/cy, deflection 1.7512″, GPS offset 4.4646×10⁻¹⁰ (factory 10.22999999543 MHz), Pound–Rebka 2.455×10⁻¹⁵. Tidal transfer: five channels predict a sixth up to c(n)·tr E with c ∝ z(x+y−z), and tr E = R₀₀ = 4πG(ρ+3p), so a generic direction tests the time-time vacuum equation locally; the supplied direction (1,2,3) lies on c = 0. Structural match with GR collected from the companions. No deviation predicted. Battery: 5 groups (CA–CE), each with a canary; 7 mutations caught. Bundle: `RG_gravity_closure_bundle.zip`. |
| `RG - Ringdown Light Ring.pdf` | L1–L2, L28, L35, L64–L68, L94–L95 | The light ring of a black-hole remnant read from ringdown harmonics, with no field equation. The instability exponent comes from two ℓ = m harmonics: λ̂ = 2(L₂²|Im ω₂| − L₁²|Im ω₁|)/(L₂² − L₁²), L = ℓ + ½. On exact Kerr modes (qnm 0.4.4, spins 0–0.9) it is within 2 % for ℓ = 2, 4 and converges (0.2 % at ℓ = 6, 8). A form assuming a 1/L damping correction reaches 4.6 % and does not converge. The orbital frequency needs three harmonics on a spinning hole: the ℓ = m modes carry a spin offset c₀ of order one (−0.015 at a = 0.3, −0.11 at a = 0.9; effective inclination m/L). Richardson on ℓ = 2, 3, 4 is within 1.5 %; two-mode forms are biased by up to 13 %. Single-mode readings are off by 5–24 % (canaries). GW250114, from the published (2,2,0) and (4,4,0) reconstructions: λ̂ = 400 s⁻¹ (90 %: 203–1225). The Kerr light ring inferred from (2,2,0) alone (a = 0.685, 67.5 M☉ redshifted) gives 527 s⁻¹ (473–583), with Ω/2π = 133 Hz. Consistent; the error is about 80 %. Forecast (Fisher, white noise): σ_λ/λ ≈ 2.84/ρ₄₄₀, so a 5 % test needs ρ₄₄₀ ≈ 57 and a 1 % test ρ₄₄₀ ≈ 284; GW250114 had 3.6. A Reissner–Nordström fit to the fundamental mode of Bardeen and 1/r³-deformed geometries returns their light ring to 0.12 %, while the metric differs by up to 1.4 %; a one-parameter fit misses λ by up to 26 %. Anti-reduction section: the number comes from detector data and could have contradicted Kerr. No deviation claimed. Battery: 7 groups (KA–KG), each with a canary; 9 mutations caught. Bundle: `RG_ringdown_light_ring_bundle.zip`. |
| `RG - GR Derivation.pdf` | L1–L2, L9, L64–L68, L80, L94–L95 | Standalone derivation of general relativity from records of light signals, clocks, free fall and gyroscopes, written for two readers (geometer and laboratory physicist). Metric: the causal order fixes the conformal class (Hawking–King–McCarthy, Malament); exactly, 11 rational null directions fix a Lorentzian form up to a factor and 8 do not; one clock fixes the factor; no second-clock effect; MICROSCOPE fixes one metric for all matter; Ehrenfest orbit stability and D(D−3)/2 wave modes leave D = 4. Unit lemma: a change of unit is g ↦ λ²g; a natural, local law, smooth at flat space and unit-free is, in normal coordinates, a polynomial with Σ k·m_k = q − p − w. Connection theorem: Levi-Civita in every dimension and signature, with compatibility and torsion-freeness as results. Alternatives need a length (ε^a_bc: weight 1; ∂R terms: weight −2), are singular in vacuum (ε∇R/R; Schwarzschild R = 0), or need another field. Lorentz route: no invariant rank-3 tensor under so(1,3), so(4), so(1,4), so(2), one under so(3); finite rational certificate. Free fall fixes a metric connection only up to 24 / 4 / 0 components (exact). Field theorem: with balance the response is αG_ab in every D ≥ 3; equivariant maps curvature → symmetric tensors have dimension 2 (exact). Every further term carries a length: Λ (measured), R² (below 38.6 µm), Weyl² (ghost), ℓ²□. Unit-free countermodels: Brans–Dicke (Cassini ω ≥ 39 998) and nonlocal gravity. Cross-checks: Lovelock (Lanczos zero in D = 4 only), Fierz–Pauli (1, −1, 1, 1, −1), R² fourth order. Newtonian limit G_00 = 2∇²φ gives 8πG. Fermi–Walker theorem for torque-free gyroscopes: Thomas angle 2π(1 − γ) and geodetic angle 2π(1 − √(1 − 3M/r)) to 1e-8; parity-odd countermodel shifts the Thomas angle −0.972 → −1.039 rad. Tests: perihelion 42.98″, deflection 1.7512″, GPS 4.4646×10⁻¹⁰, Pound–Rebka 2.455×10⁻¹⁵, Gravity Probe B 6621 against 6601.8 ± 18.3 mas/yr (signed 95 % interval for an extra rate [−6.17, +4.85]×10⁻¹⁵ s⁻¹). Premise ledger and limits included. No deviation predicted. Battery: 7 groups (RA–RF, RD2), each with a canary; 13 mutations caught. Bundle: `RG_gr_derivation_bundle.zip`. Rebuilt as the final print (18 pages): a section 'From finitely many records' at the realization premise (order and count give volume 0.500, proper time 1.006 with the Baik–Deift–Johansson correction, dimension 2.01/2.98/4.01, conformal factor to 1.6 %, curvature in mean by layer counts: de Sitter 1.9998, anti-de Sitter −2.0002 at ρ = 10⁵; one event's estimate fluctuates by 48 000; counting resolves only the trace, order the rest; Poisson counts boost-invariant, lattice not), a remark that the Einstein–Hilbert density is in mean a count, and an appendix 'Path to quantum mechanics' (record metric of states, task collapse on finite groupings, direction obstruction and classical limit; no-go: the Lorentzian form is the mass shell, not a record metric; what quantum gravity inherits and what is open). Three batteries in the bundle: RA–RF (13/13), SA–SG (9/9), CA–CH (12/12). |
| `RG - One World and the Particle.pdf` | L1–L6, L15, L38–L43, L94–L95 | Agreement of experiments on atomic numbers, separated into One World (one state reproduces every protocol law) and the ball (a localized carrier of protocol-independent values). One World in metrology: XRCD atom counting and Kibble balances, no shared apparatus, give one Planck constant through N_A h; eight CODATA 2017 inputs lie within 1.6×10⁻⁷, the mean within 1.0×10⁻⁹ of the 2019 SI value; NIST-17 vs IAC-17 4.0σ, NRC-17 vs IAC-17 2.8σ, Birge 1.83, 1.08 after the expansion 1.7. Counting theorem: a conserved integer charge gives the same count for every passive protocol whatever the extent (one quantum over 1000 cells: one click, g² = 0, no cell above 0.7 %). Extent: fringe visibility equals coherence, the ball is γ = 0 (single electrons; molecules of 2000 atoms, >90 % of expected visibility). Size: hydrogen radii 1, 1.5, 1.651 (Dalgarno–Lewis), √3 a0 and an edge growing as ½ ln(1/f); ionization energy ½ hartree by three protocols. Peres–Mermin: context-free values ≤ 4 over 512 assignments, quantum 6, measured 5.46(4) on two ⁴⁰Ca⁺ ions. Particle number: passive protocols conserve it, two-mode squeezing gives sinh² r, and with tanh r = e^(−πω/a) this is the Unruh spectrum exactly; dynamical Casimir effect observed. Particles read as symmetry labels (Wigner), integer conserved counts and local clicks. No new prediction claimed; the requirements for one are stated. Battery: 6 groups (PA–PF), each with a canary; 7 mutations caught. Bundle: `RG_one_world_particle_bundle.zip`. |
| `RG - Forced Predictions.pdf` | L1–L4, L19, L47–L49 | What incomplete records already determine, certified before the measurement. A target (the outcome probability of a protocol never run) is forced iff it is constant on the admissible set: record fibre at stated confidence intersected with the physical cone. Minimax: the midpoint of the admissible range [ℓ, u] has error (u − ℓ)/2 and no predictor does better, however its inputs are frozen. Coverage is simultaneous over all targets, so selecting targets after the calibration is free (300 repetitions with adaptive selection: coverage 1.0 against nominal 0.95). A held-out outcome outside its shot-noise-widened interval rejects the declaration at level α_c + α_t (drift of 0.35 rad flagged on 83 targets, none without drift). Boundary law for the Bloch ball: positivity bounds an unmeasured coordinate's size, never its sign, and forces it iff the radial deficit is ≤ 1 − √(1 − 4ε²) ≈ 2ε² (z_max = 0.037678, exact to 10⁻⁹, √(2δ) to 0.02 %; interior canary: nothing certified at any shot count). Transfer through known channels: after amplitude damping 2, 4, 32, 60 of 60 targets certified at γ = 0, 0.5, 0.9, 0.99, scored independently by Kraus operators. Frozen pipeline in three processes with a SHA-256 root and the oracle sealed during prediction: 200/200 truths and frequencies covered, 80/80 targets blind to the unresolved coordinate certified, largest certified error 0.0082, 5/5 tamperings rejected; a confident prior certifies 68 false predictions, the admissible set none. Battery: 8 groups (FA–FH), each with a canary; 12 mutations caught. Bundle: `RG_forced_predictions_bundle.zip`. |
| `RG - Record Metric.pdf` | L4, L28, L29, L35, L36, L38, L39 | Čencov's theorem with monotonicity as output, classical and quantum. The metric is defined as what records certify (local minimax precision per record, uniform over a neighbourhood). One protocol: Fisher (Hájek–Le Cam), unit fixed by counting (a 2J forecast covers 0.836 against 0.95; Hodges superefficiency covers 1.0 at its point and 0 near it). Monotonicity under processing and channels is a theorem by simulation; Čencov's characterization becomes a consistency check. Quantum envelope sup_A J_A = tr(ρL²) by one Cauchy–Schwarz step, attained by the eigenbasis of L; classical as the commuting case; the minimal Petz metric and the only one records attain; a family not closed under symmetry has a non-quadratic envelope. Tasks collapse on records: on any fixed number of copies the local metric of every measured f-divergence is f''(1)/2 · g_SLD and of measured Chernoff g_SLD/8 (proof by a uniform ratio bound); two copies give 0.40500 per copy against g/2 = 0.405, not g_KM/2 = 0.662; Kubo–Mori and Wigner–Yanase arise only from copies → ∞ at fixed separation before separation → 0 (the uniform bound grows like e^{ncε} − 1). Direction obstruction is a capacity deficit: classical records ≤ min(m − 1, n), the full record attains n, a classical single readout has trace exactly 1, quantum ≤ d − 1 (Gill–Massar); on pure states the residue is tr(ρ[L_i, L_j]) = 8i Im Q, the Berry curvature, closed to 6×10⁻⁷. Distances are attained pairwise (Fuchs–Caves; geodesic 1.23112 vs 2 arccos F = 1.23117). Spin-j coherent states, j = ½ … 20: sphere of radius √(2j), obstruction exactly half the area form, Chern number 2j, coherent measurement exactly G/2 in each direction (proved). Battery: 8 groups (CA–CH), each with a control; 12 mutations caught. Bundle: `RG_record_metric_bundle.zip`. |
| `RG - Programme Closure.pdf` | L29, L39, L66, L74 | The programme closed on RG's own rules (descent, counting unit, balance, gluing, frozen prediction). All 23 declared hypotheses of the ladder classified: discharged 5 (H-mono by record width; H-task on finite groupings, with the order of limits for collective tasks as residual declaration; H-min by the unit lemma; H-int for counted units; H-resp reduced to H-cov by the response lift of Record Dynamics), record tests 8 (H-top, H-sound, H-coh, H-exch, H-stat, H-val, H-sens, H-med), anchor 1 (H-SI), irreducible 9 (H-compl, H-unif, H-hell, H-adm, H-reg, H-nuis, H-type, H-split, H-cov), each with a pair of record-equivalent worlds or a no-go; irreducible declarations can be refuted by frozen predictions and never certified. New: counted units have an exact scale cocycle (holonomy 1 to rounding on 122 loops with Poisson counts; Weyl control e^0.8), so a second-clock effect is a gluing test between clocks and event counts. Realization as gluing: Myrheim–Meyer and midpoint dimensions agree for sprinkles in 2, 3, 4D (0.002, 0.052, 0.019) and on nested scales (0.023); Kleitman–Rothschild fails (0.506; chains do not grow); a frame is detected by bounded valence (Poisson future links 9.15 → 10.59 → 12.55 for 2·10³ → 2·10⁵ events, grid exactly 2); BDJ spread law confirmed (0.507 vs 0.500). Refuted by the battery and dropped: chain-slope dimension (biased at these sizes), grid chain-spread test. Battery: 4 groups (PA–PD), 7 mutations caught; bundle also carries the record-metric and GR-derivation batteries. Bundle: `RG_programme_closure_bundle.zip`. |
| `RG - Record Dynamics.pdf` | L80, L90, L111 | The structure the quotient is a slice of: the native tensor as a flow. The record Hessian (Fisher information of the state given the records so far) obeys dI/dt = −AᵀI − IA − IQI + CᵀR⁻¹C: transport, ignorance inflow, record gain; an independent batch posterior agrees to 5·10⁻⁶ (transposing the transport changes it by 35 %); balance law d ln det I/dt = −2 tr A − tr(QI) + tr(I⁻¹CᵀR⁻¹C). Hamiltonian flows keep det I (to 10⁻⁸) while stretching I (condition 5·10⁴); records only raise I, inflow only lowers it. The dynamic hidden room is ∩ₖ ker CAᵏ, the invariant part of the static kernel: a flow that carries every direction into one recorded coordinate resolves all three; a block that never reaches the record stays at its prior. Sign of time: inverting the tensor maps its flow onto the covariance flow with generator −Aᵀ and records exchanged with inflow (JP = 1 to 10⁻⁷; without the reversal the product is off by 71). Frontier law: records are counts with finitely many bits; a forecast is held iff the bit rate exceeds Σ log₂|λᵢ⁺| (all 12 scalar cases; diag(2.5, 1.8): every 2-bit allocation fails, (2,1) holds, (1,2) and (3,0) fail); with no inflow a steady stream delivers exactly Σ ln|λᵢ⁺| (40 systems to 10⁻⁶). Tidal frontier: free fall needs records at √(2GM/r³)/ln 2 bits/s at least: 2.53·10⁻³ at the Earth's surface, 1.28·10⁻³ at the Sun's, 2.12·10⁴ at a neutron star's; on the deviation equation 0.5 and 1 bits/s fail and 2 and 4 hold around 1.44. The minimum-P⁻¹ lift is the Gaussian posterior mean, so H-resp reduces to H-cov. Battery: 8 groups (HA–HH), each with a control; 9 mutations caught. Bundle: `RG_record_dynamics_bundle.zip`. |
| `RG - Record Gaps.pdf` | L80, L90, L102–L104 | Record dynamics applied to the Duality of Gravity and to quantum gravity. Verdict: no new dynamics; six places where Newton, Einstein and quantum mechanics charge different record costs. (1) Timing lifts the single-speed no-go: on a static field with flat structure, Newton in Φ_kin reproduces every path (exit directions to 10⁻⁸ rad in independent integrations), but the Einstein coordinate speed is exactly N² times Newton's (to 10⁻⁷) and arrival is later by 29–56 m/c; a clock record refutes Newton at one speed. (2) Orbit frontier: Newton's circular orbits never cost records; Einstein's do inside 6m (κ² = (m/r³)(1 − 6m/r), to 1.4·10⁻⁷), 1172 bits/s at 5m around 10 M_sun. (3) Tidal tensor on a circular orbit (m/r³) diag(−(2r−3m)/(r−3m), r/(r−3m), 1) from the symbolic Riemann tensor, to 10⁻⁹; radial record rate exceeds Newton's by 1.04 … 5.57 from 20m to 3.05m, divergent at the light ring; radial infall exactly Newtonian. (4) Volume ceiling: quantum position records tie inflow to gain, Q_pp = (ħ²/4) G_xx, so det V = (ħ/2)² stays exact for efficient records (free, harmonic, tidal dynamics) while classical records drive it to 10⁻⁸ of that. (5) Tracking limit ħ sinh(2λτ)/(2mλ) for uncorrelated position records: 3.3·10⁻¹⁶ m for 1 kg in Earth free fall over one e-fold; a squeezed state beats it (protocol limit). (6) Geometry frontier 3·2^(−1/3)(ℓ_P²L)^(1/3): 1.5·10⁻²³ m at 1 m, 7.7·10⁻¹⁵ m at the Hubble length (Salecker–Wigner, Ng–van Dam; heuristic). The one-loop correction to the potential moves the tidal record rate by 10⁻⁶⁹ at 1 m: the gap is in the records, not the dynamics. Battery: 6 groups (QA–QF), each with a control; 7 mutations caught; first-draft sign error and closed-form constant caught by the battery. Bundle: `RG_record_gaps_bundle.zip`. |
| `RG - Record Prediction on LIGO Strain.pdf` | L1–L4, L15–L16, L47–L50, L108 | Guidance paper: a complete record-prediction study on public O4a strain (H1, L1; 4096 s from GPS 1368993792). Hashed stage chain with completion marker; positive controls in real noise (common signal found at amplitudes 0.1–1.0 with lag +64 samples, identity control bit-exact, 150 Hz line raises the target 82-fold); noise floor of the two-detector statistic equals the record-count law 1/√(2·N_windows·N_bins) within 5%. Primary score H1 −0.1058, L1 +0.4940 nats per window; H1 intervals 87.7%. The predictor-only gate proposed to predict the asymmetry is refuted (rejects both detectors, any time-ordered split, every block length). Post hoc: 37 of 55 H1 misses in one seven-minute stretch with predictors and quality bits normal. Proposition: no predictor-only gate certifies coverage (witness 93.5% vs 59.4%); conformal coverage needs exchangeability; the Parseval forced set is vacuous by 10⁶–10⁹. Seventeen rules of use; registered-test template for O4c. No physical claim. Battery 11 groups, 12/12 mutations. |

Quantum mechanics has the same theorem shape: the class is forced (complex QM, unitary/GKLS dynamics, Petz descent, task-declared metric) and the Hamiltonian is identifiable but selected (`RG - Quantum Mechanics.pdf`). GR does **not need spacetime** as an independent object: every prediction descends to local data, a selected law and relational readouts, and spacetime is a representative unique up to isometry (`RG - GR Without Spacetime.pdf`). Full GR is still **not** derived from RG. The field equation is selected (Lovelock, H-min) or measured, and its nonlinear completion is open beyond its first term.

## Module papers by stratum

Every battery registers naive and sharpened claims, uses fixed seeds, fails on non-finite evidence, and carries **mutation canaries**: a check that cannot fail is not counted. Batteries are falsification witnesses, not premises of proofs.

| Stratum | Rungs | Papers (same-stem ZIP = battery) |
|---|---|---|
| Foundation | all | `Resolution Geometry.pdf`; `RG - Final Locks.zip` |
| Groupoid and assembly | L0–L11, L110 | `RG - The Groupoid of Resolution.pdf`; `RG - Assembly at the Kernel.pdf`; `Assembly of Resolution Geometry.pdf`; `RG - Functorial Resolution Geometry.pdf`; `RG - Saturation.pdf`; `RG - Kernel pair root and limits.pdf`; `RG - Quotients.pdf`; `RG - Observation Laws.pdf` |
| Observable sector | L12–L17 | `RG - Observable Sector.pdf`; `RG - Source Automation.pdf` |
| Differential, strata, walls | L18–L27 | `RG - Stratified Specialization.pdf`; `RG - Made Visible.pdf`; `RG - Atlas Globalization.pdf`; `RG - Gluing Test.pdf` |
| Second order and quantum | L28–L43 | `RG - Quantum Metric Selection.pdf`; `RG - Fibrewise Characterization.pdf`; `RG - Fibrewise Characterization - QM.pdf`; `RG - Axioms.pdf`; `RG - Covariance Geometry.pdf`; `RG - Reconstruction Identifiability.pdf`; `RG - Blind Sector.pdf` |
| Ignorance | L44–L47 | `RG - Ignorance.pdf`; `RG - Observation Limit.pdf`; `RG - Null Resolution Depth.pdf`; `RG - Entropy.pdf` |
| Uncertainty and forgetting | L49–L58 | `RG - Uncertainty Geometry.pdf`; `RG - Uncertainty Geometry - Forgetting Ladder.pdf` |
| Statistical distance | L59–L63 | `RG - Distance and Angles.pdf` |
| Order, cone, residual | L64–L73 | `RG - Residual Characteristic Geometry.pdf`; `RG - Cone.pdf`; `RG - Cone - Closure.pdf`; `RG - GR Signature Emergence.pdf` |
| Scale and transport | L74–L80 | `RG - Canonical Transport.pdf`; `RG - Atlas Globalization.pdf` |
| Duration, dynamics, chaos | L81–L93 | `RG - Chaos Is Not Hidden.pdf`; `RG - Chaotic Experiments.pdf`; `RG - Time.pdf`; `RG - Operational Duration.pdf`; `RG - Operational Duration Boundary.pdf`; `RG - GR Time.pdf` |
| Physical distance | L94–L109 | `RG - Physical Distance.pdf` (battery: `RG_Physical_Distance_Attack_Bundle.zip`); `RG - Wall-Tap Delay.pdf` |
| Global transport and closure | L111–L115 | `RG - Maximal Closure.pdf`; `RG - Canonical Transport.pdf` |
| Final remainder, local classification, walls | L116–L131 | `RG - Final Remainder.pdf` (battery: `RG_final_remainder_bundle.zip`; earlier stages: `RG_conversion_search_bundle.zip`, `RG_threshold_attack_bundle.zip`, `RG_residual_lock_bundle.zip`); local classifier: `rg_full_classification_package.zip`; walls: `RG_obstruction_tower_bundle.zip` (hidden-room audit, L131 lock attempt, obstruction-tower lock) |
| Origin experiment | all | `RG - Wall-Tap Experiment.pdf`; `RG - From the Wall to the Kernel.pdf` |

---

## Physics interface

**Physical distance (L94–L109).** RG distance is dimensionless and experiment-relative, and no function of it alone is a physical distance. Suppose the following hold on a regular static slice:
- Euclidean motions are in $\Gamma$, with irreducible isotropy;
- a counted two-way timing channel with exact SI constants is part of the joint law;
- the medium is resolved;
- a held-out anchor is predicted.

Then

$$
\bar g_{\mathcal E} = \lambda_{\mathcal E}^{2}\, h, \qquad d_{\mathrm{phys}} = \frac{d_{RG}^{\mathcal E}}{\lambda_{\mathcal E}}, \qquad d_{\mathrm{rad}} = \frac{c}{2\,\Delta\nu_{\mathrm{Cs}}}\, n_{\mathrm{Cs}} .
$$

Stationary slices carry the Landau–Lifshitz radar metric, and loop synchronization there has Sagnac holonomy. Non-stationary slices carry no time-independent radar metric (no-go). The unit enters only through the counted channel.

**Duration (L81–L84).** Clock readouts with equal kernels form one transition groupoid. A stabilizer time flow makes the transitions affine. Path independence holds iff the kernel of the increment is contained in the kernel of the clock.

**Cone (L64–L73).** A regular quadratic cone gives a conformal ray. Lorentz isotropy in $\Gamma$ (dimension at least 2+1) forces the light cone. Otherwise the characteristic set falls into one of three classes:
- **tame-typed**, with finite stratified data;
- **hyperbolically locked**, which is what well-posed propagation forces;
- **wild**, with window certificates only.

**GR placement and automation.** These are bounded constructive bridges, not a general solver: `RG - GR Placement Bridge*.pdf`, `Automation of General Relativity - *.pdf`, `RG - Source Automation.pdf`. A fail-closed result (for example, the H1–L1 records failing the declared injection-veto gate) is an intended output.

---

## Problem status

### Closed

| Problem | Resolution | Rungs |
|---|---|---|
| Observable domain | equality-of-law quotient, universal factorization | L1–L2 |
| Coupling of protocols | joint kernel is the intersection | L3 |
| Shared symmetry | Gau → Stab → Γ; faithful action on Q | L6–L7 |
| Observable-sector selection | complete minimal-panel antichain; ties retained; no task-free isotropic selector | L12–L13 |
| Robust observability | protocols intersect, models close their union; common decoder via cross-model collisions | L14 |
| Coupled versus marginal detector laws | coupled law refines marginals; pairing is not coupling | L15 |
| Set-valued inference | confidence-set bridge; point answers need a certified radius | L16 |
| Basicness and projectability | automatic by natural descent of a fixed law-space structure | L19–L20 |
| Metric selection | descent does not select; Fisher selected under H-mono or experiment-level descent (Čencov; derived in `RG - Cencov Theorem.pdf`) | L29 |
| Establishment of exact laws | exact law equality is not uniformly certifiable from finite samples; data enter through confidence correspondences | L48 |
| Walls | kernel upper semicontinuity; specialization iff kernel inclusion; normalizer descent; stratified category | L21–L27 |
| Distinguishability across walls | Hellinger (Le Cam) specialization; weak convergence insufficient | L37 |
| Fisher layer | natural; radical = observational vertical; does not determine covariance (relative to the declared complement); quotient dimension p+q+pq under the declared-metric contract; globally, the Fisher-relative remainder is the null-kernel bundle class $[K_N]$ | L28–L32, L120 |
| Quantum metric | Petz family gate; task lock; nonparametric identification; wall specialization iff f(0) > 0 | L38–L41 |
| Contextual quantum protocols | trace rule; no noncontextual hidden values; product law over contexts (Fine) | L42–L43 |
| Finite-data rank walls | never certified; full-rank or upper-bound certificates only | L47 |
| Primitive of uncertainty | indistinguishability; uncertainty splits along the quotient; kernel prior never forgotten | L49 |
| Probability, LAN, Monte Carlo | de Finetti; Gaussian propagation = LAN limit (fails across folds); Monte Carlo objective only on FORCED outputs | L50–L51, L57 |
| Forgetting of declarations | TV rigidity under bijections; no uniform forgetting without a class; sharp BV lock; NS contraction gate; Dobrushin; samples refute, operators lock | L52–L56 |
| Non-circularity | certificate over a declared admissible class | L57 |
| Non-dominated, infinite-dimensional, path-space | pairwise domination; Feldman–Hájek / Cameron–Martin geometry | L58 |
| Residual characteristic branch | tame reduction; no finite linear classification; duality; hyperbolic lock; wild class | L69–L73 |
| Latent connection | not law-natural; canonical under declared covariance (Kalman/RTS); curvature = latent holonomy; wall coherence | L79–L80 |
| Operational duration | clock groupoid; affine under time flow; path independence | L81–L83 |
| Noiseless chaos | stratified-regular finite histories; entropy from kernel counts; Ruelle and Pesin locks; typed certificates | L85–L88 |
| Nonuniform dynamical transport | global cone field iff uniform hyperbolicity (no-go otherwise); window-typed certificates | L89 |
| Chaos versus declarations | frontier law; duality; quotient growth; information cost | L90–L92 |
| Delay, distance, angle | offset, rate and warp classes; angles survive rate change, counts survive warp | L93 |
| Unit and physical distance | no internal unit; counted channel; anchors; identification theorem | L94–L109 |
| Non-static slices | stationary: Landau–Lifshitz plus Sagnac; non-stationary: no-go | L104–L106 |
| Assembly | kernel–stabilizer theorem | L110 |
| Global transport | observable atlas closed; latent transport canonical under declared data; closed is not trivial, since the atlas still has an isomorphism class (L119) | L111 |
| Closure | dispatcher totality; composite soundness ≤ Σαg; window-indexed walls; maximal closure with the exact correspondence | L112–L115 |
| Task residual | descent iff every fibre's output set is a singleton; terminal sufficient refinement, unique and natural; joint witnesses required | L116 |
| Coupling symmetry | stabilizer $\prod\mathrm O(m_j)\times\mathrm O(p-r)\times\mathrm O(q-r)$ under the covariance-only contract; multiplicities, not rank, control it | L117–L118 |
| Final remainder on constant-type strata | local moduli plus Euclidean block bundles; initial complete natural invariant; classifying space; $\check H^2$ gluing class; no new primitive | L119–L123 |
| Local classification of second-order data | word traces complete under O(p)×O(q) on every stratum; sign chart $H^1(G;\mathbb F_2)$ on simple strata; observer-relative classification for Lorentzian curvature | L124–L128 |
| Second-order remainder across walls | hidden-room descent (discrete stabilizers); no constructible classification; obstruction tower in general | L129–L131 |

### Open problems of the ladder

1. **Tame type enumeration (L132, external).** Enumerate the tame types of degree-d characteristic cones. For plane curves this is the first part of Hilbert's sixteenth problem (known for d ≤ 7). It is a problem of real algebraic geometry, not of RG.
2. **Forced deterministic turbulence (L133).** Above the Galerkin gate $G_N \ge 1$, no rung certifies uniform forgetting. TV is rigid, the contraction gate fails, and there is no noise and no expanding non-invertible transfer operator. With stochastic forcing, ergodicity is known only qualitatively (Hairer–Mattingly). An explicit uniform constant over a declared class is open.
The former third problem, the **second-order remainder across walls**, is closed by L129–L131. The conjectured constructible stack over exit paths does not exist: walls carry continuous crossing moduli and functional link moduli. The classification is an obstruction tower:
- **Germ steps:** lifted wall rooms and link functions.
- **Cell steps:** classes in homotopy groups of the block stabilizers.

What remains is classical homotopy computation, not RG.

### Declarations by design (not open problems)

- **Protocol, task and admissible class.** RG does not derive which question an observer must ask. This is a theorem, not a gap: there is no task-free equivariant selector (L13). Given a task, selection is exact (L12). Given a declared class, non-circularity is certified (L57).
- **Latent data.** A connection, prior or covariance is declared or reported as undetermined (L79–L80).
- **Anchors.** The unit enters only through counted channels and SI definitions (L94–L102).
- **Second-order contract.** Declaring only the covariance tensors and declaring the observation metric as well are different contracts, with different remainders. The resolved/null complement is declared (`H-split`).

### Research directions beyond the ladder

These are extensions with new content. They are not gaps in the ladder's proofs.

- **Observable stress tensor:** a sector map with uniqueness, conservation and gauge independence, keeping *not identifiable* distinct from *identified as zero*.
- **Physical versus protocol coupling:** attribution by intervention and independent instrumentation.
- **Higher-order geometry near discriminants:** curvature, normal holonomy, second fundamental form.
- **Classifications:** the pointwise orbit space under the declared-metric contract, $O(p)\times O(q)$, is now closed (L124). Still open:
  - its global bundle form;
  - minimal coordinates on every degenerate stratum;
  - the enumeration of flat observable classes by character data.
- **Nonlinear gravity:** the cubic bootstrap. Complete invariants give the ansatz basis, and conservation plus descent constrain it order by order.
- **Continuous entropy:** continuous differential-entropy decompositions beyond kernel counts and finite-resolution quotient growth.
- **Wild-class invariants:** operationally stable invariants beyond count exponent, box dimension and Cantor–Bendixson rank.
- **Benchmarks:** a preregistered fixed-gate benchmark suite with held-out and deliberately failing datasets.

---

## Scope and non-claims

1. **No geometry of latent reality.** RG describes the distinctions supported by declared protocols. Latent representatives exist, but observation does not select them.
2. **No protocol-free uniqueness.** The quotient is universal. Protocols, relabelings, tasks, nuisance and admissible classes are declared.
3. **Domains of the metric layer.** The metric module depends on the domain:
   - **Classical, regular, finite:** Fisher–Rao is selected (Čencov).
   - **Quantum:** the Petz member is selected by the declared task.
   - **Non-dominated or infinite-dimensional:** the Fisher layer is absent, or reduces to Cameron–Martin geometry.
4. **No Fisher = spacetime identity.** On a certified static slice, Fisher is *proportional* to the physical spatial metric, under named hypotheses.
5. **No internal unit.** Statistics, flatness and thermodynamic length supply no metre.
6. **No automatic Lorentzian structure.** Lorentzian structure requires the quadratic gate or sufficient isotropy in Γ.
7. **No field equations.** No Einstein equation, matter dynamics or quantum measurement law is derived.
8. **No physical coupling by default.** Resolved–null correlation is a protocol-metric property; attribution needs intervention.
9. **No theorem from batteries.** Theorem status comes from proofs and cited theorems; batteries are falsification witnesses.
10. **No prediction beyond the frontier.** RG does not forecast chaos beyond its horizon. It certifies where the horizon lies and what extending it costs.
11. **No intrinsic global class.** A nonzero global class belongs to a family over a topologically nontrivial base, not to RG. Over a contractible base it vanishes (L120).

---

## Novelty calibration

Every RG component reduces to established mathematics:

- **Quotients and symmetry:** equality-of-law quotients and Lie groupoids; Schur's lemma.
- **Statistics:** Fisher–Rao geometry and Čencov uniqueness; Le Cam, Blackwell and LAN; Bernstein–von Mises; de Finetti; Lehmann–Scheffé minimal sufficiency.
- **Quantum:** Petz, Gleason, Busch and Fine.
- **Ergodic theory and dynamics:** Oseledets, Pesin, Ruelle and Brudno; Lasota–Yorke and Dobrushin; Feldman–Hájek.
- **Geometry and characteristics:** o-minimal and semialgebraic stratification (Hardt, Collins); Gårding hyperbolicity.
- **Descent and global structure:**
  - stacks and nonabelian cohomology (Giraud), and twisted forms (Serre);
  - classifying spaces (Steenrod, Milnor);
  - canonical correlations (Hotelling);
  - Riesz spectral projections (Kato);
  - the von Neumann–Wigner crossing rule.
- **Physics and measurement:** Malament–Hawking reconstruction; Beckman–Quarles; Cauchy–Hölder ratio scales; Landau–Lifshitz radar metric; the SI definitions.
- **Complexity:** Garey–Johnson; Shamir.

RG claims no new primitive and no new branch of mathematics. On constant-type strata this is now a theorem (L123, under `H-split` and `H-type`), not only a remark. Its content is identification: every component of the remainder is a named classical object with a universal property. Across walls it is answered by an obstruction tower (L129–L131). Every ingredient is classical: one-sided limits of subspace configurations, and homotopy groups of orthogonal groups. RG's contribution has three parts:

- a protocol-explicit, dependency-typed assembly of these components into one geometry of partial observability;
- the kernel–stabilizer mechanism, which makes all modules share one symmetry group;
- explicit failure conditions for every step, each backed by a hostile battery with mutation canaries.

---

## Honesty ledger

The surviving framework depends on keeping negative results visible.

- **Kolmogorov turbulence from Fisher-rank loss:** retired.
- **Constants or π-factors from flexible kernels:** retired as reparametrization.
- **Emergent spacetime, gravity from Fisher geometry, nodes of presence, quantum or biological identifications:** not part of RG.
- **RG distance as physical distance:** refuted. Physical distance needs the identification theorem (L109).
- **Independent module gates:** superseded by natural descent (L19–L20).
- **"Natural, hence forced" (first rigidity paper):** withdrawn after an external critique. Descent fixes a structure once its law-space definition is fixed; selection needs a characterization (H-mono for Fisher) or a declaration. Also repaired:
  - the radical theorem now requires nondegeneracy on the image tangent (indefinite counterexample);
  - minimal panels need a finite index set;
  - Γ is the liftable, presentation-relative symmetry;
  - countermodels show non-omissibility, not necessity;
  - H-unif is split into a theorem part and a certification part.
  
  See `RG - Rigidity.pdf` (Conditional Rigidity).
- **"Presentation or thresholds control the output":** answered in `RG - Presentation and Thresholds.pdf`.
  - Observable results and the observable symmetry Γ_obs are presentation-invariant, while the liftable Γ is presentation-relative.
  - Thresholds are unavoidable (Le Cam) and act as a monotone filtration, reported as critical margins.
- **Real-data registrations:** several expectations failed on contact with real data, and all are kept on record in `RG - Real Measurements.pdf` and `RG - Crossing into Physics.pdf`.
  - a coverage gate was mis-specified;
  - calibration was expected to age within the hour, and did not;
  - a medium sign was expected positive, and came out negative (instrument biases);
  - all four routes were claimed to agree, and do not;
  - the "right" cluster was hard-coded, which is smuggling, and the engine caught it;
  - a tie-break test was used that had no power against a constant bias.
- **Resolved–null coupling as the primary law invariant:** cut. It vanishes identically under the whitening (Čencov) metric. It is the relative position of a declared protocol metric, and its efficiency theorem is data processing. The coupling coordinate also moves affinely under a change of complement, $L\mapsto L+K$ (L117).
- **Principal Aut(G)-bundle over a varying operating point:** cut. It exists only on level sets of varying invariants; the law-natural structure group is O(r)×O(q). Across a type change no single-model description exists on any neighbourhood (L122).
- **Local automorphisms as symmetries:** cut. Jet isotropy need not integrate to a law symmetry.
- **"Coupling rank controls symmetry dimension; full-rank coupling rigidifies to the trivial automorphism" (Lock Conclusion):** refuted.
  - Witness: $C=\tfrac12 I_3$ has rank 3 and $\dim\mathrm{Aut}=3$.
  - Distinct full-rank correlations give $\mathrm{Aut}\cong\mathbb Z_2^3$, not the trivial group.
  - The supporting 5000-sample sweep could not see the measure-zero stratum.
  - Replaced by the multiplicity formula (L118).
- **"RG admits no faithful functor into any single foundation":** withdrawn. Forgetful functors are faithful.
- **"The residual is a nonzero descent class; RG is a nontrivial bundle of foundations":** withdrawn. Over a contractible base the class vanishes. The remainder is classified instead by local moduli plus block bundles (L119–L120).
- **"Admissible edges with Čech defect −I signal a gluing failure":** sharpened.
  - When transitions are choices, the defect is an obstruction only through its $\check H^2$ class.
  - The class is removable on a filled triangle and not removable on $\mathbb RP^2$ (L121).
- **"The cosmic microwave background spectrum witnesses three space dimensions" (Quantum Gravity, second edition, first printing):** withdrawn as circular. FIRAS nulls the sky against a blackbody calibrator whose spectrum is computed with Planck's law; the null vanishes for every n. Replaced by absolute radiometry of the T⁴ law and by gravitational dimension witnesses (Observer Bounds).
- **Seeded transport amplitudes and capture tables (GR automation notes, July 2026):** withdrawn as evidence. The reported block norms equalled an input amplitude, and capture 1.000 against random 0.25 is a pair of identities. Replaced by blocks computed from the metric, with a closed form on Schwarzschild (GR Automation).
- **Envelope identity "at fixed resolved field":** sharpened. It holds at fixed detector readings and fails in metric-dependent frames; the general identity carries a multiplier term (GR Automation).
- **Attachment rungs of Quantum Gravity, Observer Bounds and Coherence Geometry:** corrected. They were declared as L1, L38–L39 (and L27), which understated what those papers use; their inherited budgets were too small. Found by the companion register of the Ladder Organization (audit A4).
- **"Interacting 3+1 limit: open" (Quantum Gravity, second edition):** replaced by five typed rows. Proved in a class (classical quartic field, smooth well-prepared data, uniform lattice), predicted (lattice error), matching data (isotropy, defect-freedom), closed negatively (quantum one-component scalar, imported theorem), open (gauge sectors). Not claimed: an interacting quantum field in four dimensions, convergence for finite-energy data, triviality of the four-component field, anything about gauge sectors.
- **Kernel existence (Quantum Gravity, third edition):** the statement that a Lorentzian action admits only an amplitude is conditional on the weight over histories being a function of the action. It does not derive the Born rule or the reconstruction conditions, and the gravitational statement is at quadratic order only.
- **Scalar-coupling witness:** the number m_H < 143 GeV uses the scalar self-coupling alone at one loop. It is not the Standard-Model bound (180 ± 4 ± 5 GeV at two loops, Hambye–Riesselmann) and says nothing about vacuum stability.
- **Tensor Frontier, scope:** the response law is used, not derived; the equivalence with the volume law is Baez and Bunn's, identified. The upper-boundary theorem is proved for Gaussian records only. The second-order law is proved for independent increments; for deterministic maps it needs an imported central limit theorem. Nonlinear horizons are computed, not enclosed.
- **Ringdown witness (Tensor Frontier):** the values 251 ± 8 Hz and 4.0 ± 0.3 ms are the published GR prediction from the inferred remnant, with which the post-merger data are consistent; they are not an independent measurement of the light-ring exponent. The Kerr fit is imported and was checked here only at zero spin (1.4 % and 0.9 % against computed Leaver values). The decay time alone does not discriminate the spin.
- **Supplied frontier analysis, corrections:** its nonlinear run (logistic map, r = 4) cannot show the square-root correction, because that map is a coboundary; its 'growing correction' has the closed coefficient −z_q√(D/λ³); its law bounds all forecasters, not one.
- **Speed of light as the frontier (Tensor Frontier, second edition):** consistent at the published bounds, not proved; a bound is not an identity. Linearity over distance was not evaluated on raw data. The value in units is not derivable (no internal unit); only the raw number against independent standards is measured. All statements concern two-way speeds.
- **Data provenance (Tensor Frontier, second edition):** published values and bounds, not reanalysed raw records. Three of the four historical determinations come from a secondary table (Usenet Physics FAQ). The distance (26 Mpc) and emission lag (10 s) used to reproduce the gravitational-carrier bound are recalled, not verified; the bound itself was verified.
- **Supplied raw-frontier programme:** its 7/7 lock is seed-dependent (106 of 200 seeds), one of its gates needs the true value, its covariance check is an identity plus noise, and its gates are passed by a wave of a medium. It is a design sketch for a measurement, not evidence.
- **Magnetism, scope:** Maxwell's equations are derived conditionally. Two premises are not supplied by Resolution Geometry: that a conserved count exists whose carriers have phase records, and that the vacuum responds linearly and locally (the second is known to fail at relative order 6e-27 in laboratory fields). Lorentz invariance is taken from the Tensor Derivation and Tensor Frontier prints with their conditions. The value of α, the existence of charge and charge quantization are not derivable here. Media, radiation and field quantization are not treated.
- **Magnetism, data:** the mutual consistency of the 2022 values of μ₀, ε₀ and α is a consistency of quoted digits, not a test (since 2019 μ₀ is obtained from α). The 1907 static value comes from a secondary table; the α determinations are those of Observer Bounds and were not re-verified; the copper numbers are illustrative; the lattice convergence is an extrapolation over four grids, not an error bound.
- **Light Ring, scope:** the joint relation is a consequence of general relativity with minimally coupled light; no deviation from that theory is claimed and none is predicted. The geodesic statements are the strong-deflection limit and the photon-ring analysis (identified); the eikonal ringdown relation is imported; the expansion behind the mode ladder is assumed in WKB form and checked numerically, not proved; no literature search was made for the ladder estimator and no novelty is claimed for it. Rotation is treated only through the equatorial light ring; non-stationary geometry and overtones are not treated. One cone implies equal pairs; the converse is not claimed.
- **Light Ring, data:** there is no joint test. No black hole has both an image and a ringdown, and none is in sight. The GW150914 ringdown values are the published prediction from the inferred remnant, as in Tensor Frontier; the Sgr A* values are quoted from the literature; the fluid experiment is quoted from its preprint. Time-domain frequencies are accurate to 2e-4 and 2e-3, and the comparisons inherit that.
- **GR Equivalence, scope:** the equivalence with the initial-value theory with detector models holds by the construction of the translation; it states that nothing is left over on either side and is not a deep theorem. Observation systems are a wider class than models of general relativity, and no intrinsic condition is known that characterizes the image (underdetermined). The slice bound is proved for compact groups in finite dimension; the Lorentz case is computed at a point; the conical structure at symmetric solutions of the full theory is imported and holds for compact Cauchy surfaces. The transport witness is a flat two-dimensional space with test pulses; the four-dimensional vacuum case (Taub–NUT) is imported. RG does not prohibit solutions with Cauchy horizons; it abstains beyond them. Strong cosmic censorship is not decided.
- **GR Equivalence, limits:** maps of the bare theory are declared to be diffeomorphisms, acting on fields, sources and detectors together; isometric embeddings of regions and asymptotic symmetries are not treated. The nine observer invariants are a chosen set whose rank equals the bound at the four points tested; that they generate all invariants is not claimed. One cone for all carriers is not imposed by general relativity without minimal coupling. The field equation is not derived. Quantum measurement is outside the declared domain.
- **Gravity Closure, scope:** the nonlinear completion is closed by Lovelock's theorem, imported, not re-proved; the battery checks the dimensional identity behind it, not the theorem. H1 (locality and second order) and H2 (no further long-range gravitational field) are hypotheses, not derived. Each has a countermodel that obeys every native principle. Second order and field content are restricted by measurement; locality is declared, with no measured bound used. The torsion-balance bound is quoted for Yukawa strength 1; the R² strength 1/3 is not read off. Measured values for the classical tests are quoted, not re-analysed. The tidal transfer assumes colocated, calibrated detectors and is identified with the Laplace condition of gradiometry. No deviation from general relativity is claimed or predicted.
- **Ringdown Light Ring, scope:** the eikonal correspondence alone does not identify Ω or λ from finitely many harmonics: an exact finite-mode collision (q(L) = ∏(1 − L_i/L)) shifts the asymptotic values by 0.03 and 0.02 without changing any observed mode (group KG). Each estimate therefore needs a bound on the finite-ℓ remainder; the sharp bounds are Σ|w_i|ε_i and Σ|u_i|ε_i (Σ|w_i| = 7). The bound is computed from exact modes for Kerr only and must be derived for any other class. Agreement of two extrapolation forms is not a bound. methods-and-measurement paper; no deviation from Kerr is claimed and none is found. The physics is the eikonal correspondence (identified: Cardoso et al. 2009, Dolan 2010), which can fail in theories with non-minimal coupling. The GW250114 inputs are parametrized-Kerr reconstructions with Kerr-centred priors. They are modelled as split normals without correlations, not re-analysed from strain. The (4,4,0) mode has log₁₀ B = 0.54 in its favour, which is weak support. The forecast assumes isolated modes in white noise and is a lower bound; no detector curve is used. The family-fit group is static and uses a scalar test field; its horizons agree to 0.9 %, so it does not separate the horizon from the light ring, and spinning non-Kerr families are not tested. Novelty of the estimator is not certified: arXiv:2103.08104, 2309.02560, 2205.02433, 2504.05014 and 0908.0329 were searched, and none contains a multi-harmonic extraction applied to data. The mutation suite found one defect while the print was written: a 1/L damping ladder was replaced by the convergent L² form.
- **GR Derivation, scope:** classical: with ħ, the Planck length is an available anchor, so ℓ_P²-suppressed curvature terms are not excluded. The continuum behind finitely many records, locality, smoothness at flat space, 'metric alone' and torque-free gyroscopes are premises, each with a countermodel. Nonlocal gravity and Brans–Dicke need no new length and are excluded only by premise; Cassini restricts Brans–Dicke. A totally antisymmetric torsion is invisible to free fall and is excluded only by 'metric alone'. The parity-odd gyroscope term vanishes on geodesics, so Gravity Probe B does not test it. The causal-order theorems and Lovelock's theorem are imported. The curvature-to-response count is exact for so(1,3) only. Measured values are quoted, not re-analysed. The Gravity Probe B model uses a spherical Earth and a circular orbit. Global questions (Cauchy horizons, the initial-value problem) are outside the paper. The realization premise is narrowed, not removed: order and count recover the geometry of records produced by a continuum; that physical record sets are of that kind is assumed (typical large orders are not manifold-like). Curvature from counting holds in mean only and is checked in 1+1 dimensions. The quantum appendix derives no quantum dynamics of geometry; Λ ~ V^(−1/2) is cited as a heuristic needing unimodular conjugacy.
- **One World and the Particle, scope:** every result is standard quantum theory or metrology read as gluing of records; no new prediction. Measured values are quoted, not re-analysed, and metrology correlations are ignored. The counting and interference propositions use ideal detectors and pure states. The Peres–Mermin measurement uses two ions, not one atom. Atoms are not claimed not to exist: counts and symmetry labels are real invariants. Nonlocal or contextual hidden-variable realism is not excluded. The tensions named as places to look (NIST-17 vs IAC-17; Cs vs Rb fine-structure constant) are not predicted by any RG principle.
- **Forced Predictions, scope:** guarantees hold under the declared state space, cone, record law and stationarity; a drift smaller than the shot-noise radius can pass unflagged. All runs are simulations of one two-level system with box-shaped Hoeffding calibration regions (conservative: coverage 1.0 against 0.95). The commitment is local: it proves files were not altered, not when they were made; an outside test needs an external time-stamp before the target data exist, ideally with a third party holding them. The commitment adds no predictive power. Any method respecting the same admissible set gets the same intervals; the advantage shown is over plug-in and prior-based certification. The minimax core is the radius of information and the Chebyshev centre (Traub–Woźniakowski; Milanese–Vicino), with partial identification (Manski) and quantum region estimators (Christandl–Renner; Faist–Renner) as neighbours. Higher dimensions need a semidefinite solver; the boundary law is specific to the Bloch ball.
- **Record Metric, scope:** the input is closure of the protocol family (processing, repetition, preparation by channels) and regularity (differentiability in quadratic mean); monotonicity is output relative to these. The task-collapse theorem needs a full-rank reference state and covers fixed groupings with vanishing separation; the resolution-scale regime of testing (separation ~ 1/√n, quantum local asymptotic normality) is not analysed. Joint attainability with collective measurements (weak commutativity) and the Holevo bound are cited, not simulated. Checks are finite-dimensional (up to 41 levels). The spacetime metric is not derived; the idealized-geometry section gives the mechanism for statistical records of states. Components are established results (Hájek–Le Cam, Čencov, Petz, Braunstein–Caves, Fuchs–Caves, Gill–Massar, Hiai–Petz, Audenaert et al., Matsumoto, Ragy et al., Provost–Vallée); the contribution is the reversed logic, the order-of-limits identification of tasks, the capacity reading of the direction obstruction, and its survival as a symplectic form in the classical limit. Ladder rungs L29 and L39 keep their H-gated status; their text now records the record-width route and the order-of-limits result.
- **Programme Closure, scope:** the classification rests on the gates as stated in the ladder; a gate stated differently could change class. Gluing is a sufficient record test for continuum-likeness at a resolution on RG's rules, not a theorem that an order embeds; tolerances are calibrated on sprinkles of up to 3000 events (4000 nested, 2·10⁵ for valence and spread); frame and spread checks are in 1+1 dimensions. The record tests for H-sound, H-coh, H-exch, H-stat, H-val, H-sens and H-med are stated, not run; H-top is run. Quantum mechanics is bridged conditionally on the declared order of limits for collective tasks; no dynamics of records (which record sets occur) and no quantum dynamics of geometry are derived.
- **Record Dynamics, scope:** the flow is exact for linear dynamics with Gaussian inflow and records; nonlinear statements hold locally along trajectories and are not checked. The frontier law needs records of finite information; channel capacities of real instruments are not computed. The tidal record rate is a Newtonian lower bound combining the tidal tensor with the data-rate theorem; not measured, no relativistic corrections. The sign-of-time duality shows both choices are consistent; which one nature makes is an observation. The covariance itself remains declared. Components are Kalman–Bucy filtering, Kalman observability and duality, the data-rate theorem (Nair–Evans; Tatikonda–Mitter) and the steady-state entropy identity; the contribution is their reading as the dynamics of RG's native tensor, the tidal record rate, and the reduction of H-resp.
- **Record Gaps, scope:** no deviation from Newton, general relativity or quantum mechanics is predicted; the paper types where their record costs differ. Static spherical fields and test bodies only; rotation, radiation and self-gravity not treated. The timing gap uses distant-clock time. The tracking limit and the geometry frontier assume uncorrelated position records and weaken with correlated or back-action-evading records; the geometry frontier is heuristic. The volume ceiling is checked for Gaussian states under linear dynamics and holds in general by Robertson–Schrödinger. The frontier law used is the data-rate theorem, already a ladder rung for chaos (λ/ln 2 bits per step); Record Dynamics now says so.
- **Record Prediction on LIGO Strain, scope:** retrospective guidance on one 4096 s stretch per detector at the start of O4a; reconstruction of a same-window record, not forecasting; no physical or RG-specific advantage claimed; hardware-injection recovery not run (independent parameters not supplied); the battery recomputes every number from shipped artifacts, while raw strain (about 1 GB) is bound by hashes only.
- **Holonomy norms as certificates:** sharpened. Matrix norms depend on the frame; the invariants are conjugacy classes and Σ-orthonormal norms (L121).
- **Naive nerves as gluing models:** sharpened. Čech computations need Leray covers; a non-Leray cover of $S^1$ gives the wrong $H^1$ (L121).
- **"Delay is the invariant":** corrected. Delays scale under rate change; ratios, angles and counts are the invariants.
- **CHI coherence volume:** audited.
  - Its bottleneck inequality is reversed: the harmonic mean is at least the minimum.
  - Its Fisher-rank seal is blind to misspecification.
  - Density cancels in the wind example.
  - The condition-number hazard is retained as a rank-wall indicator.
- **Monte Carlo as the source of uncertainty:** superseded. Monte Carlo is the integration engine for FORCED outputs, not the lock.
- **Forgetting over finite lists of declarations:** corrected. Locks are suprema over declared classes (L53–L57).
- **"Maximal correspondence":** corrected to the exact correspondence. It is the least sound set of jointly attainable outputs, with joint witnesses retained, because separate marginals lose correlation (L116).
- **Earlier wall–tap regular quotient (x, r, b):** corrected to (x, r, |b − d|), because of the Z₂ fold.
- **Earlier batteries:** several checks could not fail and are replaced by computed, canaried checks.
  - Literal `True` checks; class indices used as features; hand-set dispatcher booleans; vacuous invertible-law inclusion tests.
  - The chaos/coil attack, which passes on a non-chaotic surrogate.
- **"Certified luck expansion 3.5×" (luck v2):** retracted. It was an i.i.d. projection with an entropy-coded seed estimate. The final luck battery issues **no** physical certificate: 0 bits, with 8 named gates open.
- **Hidden-dynamics observer:** a sign error on sine modes, plus a Hankel matrix that flattened the output channels. Both were found by audit and corrected in `RG - Both Sides.pdf`. "Null" was reworded to "operationally null for the protocol".
- **Single joint learner in the full computation loop:** it would pass the coupling test trivially, because linear invariants of the training data propagate. It was replaced by separate curvature-only and stress-only learners.
- **Entrywise loop products at degenerate eigenvalues:** not gauge-invariant. Replaced by word traces (L124).
- **Wall-atlas closure v1:** circular (the theorem restated its hypothesis), and its battery tested a gauge artifact (the "merged parity" changes under independent eigenline flips). Rejected.
- **Wall closure v2:** the local normal form (P1) and the constructible germ gauge sheaf (P2) are refuted, not merely open. Witnesses: crossing angles, functional link moduli, and germ stalks that depend on the family (L130).
- **Hidden-room closure:** two typing defects. The chamber frame shapes are not invariant, and pointwise rooms are insufficient (u/2 vs |u|/2); rooms must be lifted. A persistent repeated block in 2×2 already needs a π₁ class (|k| winding). Corrected in L129–L131. The L132 battery file was not available, so its claims were replicated independently.
- **Minimal hidden-state recovery (blind leap):** not established. Validation-selected ranks were 8–10 for a 6-dimensional generator.
- **Earlier synthesis papers as foundation:** superseded by `Resolution Geometry.pdf`.

Correction records remain in the repository.

---

## Repository policy

The repository preserves the full development record: foundations, module papers, batteries, corrections, superseded formulations and retired claims. Older files are not deleted or silently rewritten.

| Label | Meaning |
|---|---|
| `[foundation]` | statement of record: `Resolution Geometry.pdf` |
| `[module]` | extended proofs and batteries for one stratum; governed by the foundation |
| `[supported]` | constructive bridge, implementation, or real-data demonstration |
| `[historic]` | superseded presentation retained as development record |
| `[retired]` | withdrawn claim retained so the correction is visible |

**Historic syntheses** `[historic]`:
- `RG - Theorem Ladder.pdf`, `RG_-_Theorem_Ladder_Final.pdf` (the earlier ladders, L0–L62 and L0–L94);
- `RG - Theorem Ladder v2.pdf` (working ladder; its Stratum 7, R30–R44, is L116–L123 of the print edition; its wall conjecture is refuted by L130);
- `RG - Complete Framework.pdf`, `RG - Synthesis.pdf`, `RG - Fundamental Theorem.pdf`, `RG - Locked Foundation.pdf`, `RG - Atlas.pdf`;
- `Resolution Geometry of Observation Systems.pdf`, `The CTMT - Automorphisms of Resolution.pdf`;
- `The CTMT - Testament of 22 years.pdf`.

**Falsification and necessity studies** `[supported]`:
- `RG - Necessity.pdf`, `RG - OMNI Necessity.pdf`, `RG - Seismic Necessity.pdf`;
- `RG - Hole Rejection.pdf`, `RG - Undermine Attacks.pdf`, `RG - Undermine Attacks Improved.pdf`, `RG - Final Chaotic Test.pdf`;
- `RG - CHI Reduction.pdf`, `RG - Elemental Characterization.pdf`.

**Real-data studies** `[supported]`:
- OMNI space weather;
- USGS seismic catalogue;
- IGRF geomagnetic models;
- H1–L1 gravitational-wave strain (fail-closed injection gate);
- ECG;
- optical measurement systems.

These test individual strata. They are not proofs of universality.

**Historic, pre-rigorous and retired (quarantined):**
- Chronotopic Theory of Matter and Time (I–IV, CHI, Causality, Seepage);
- original Chronotopic Metric Theory papers;
- retired physics attempts;
- pre-rigorous notes.

---

## Origins

RG began as a coherence project: an attempt to force structure on whatever holds physical description together. CTMT was the first forced model. CTMT-Metric was the second, obtained by falsifying CTMT with Fisher geometry. RG is the third: the part that survived.

The childhood wall–tap experiment, which asked whether a delay lives in the observer or in the world, is now worked through the whole ladder, and its answers are exact:
- latency cancels;
- a common rate is undecidable without a second clock;
- angles survive a change of rate;
- counts survive total rupture.

See `RG - From the Wall to the Kernel.pdf` and `RG - Wall-Tap Experiment.pdf`.

---

## Citation and license

DOI: [10.5281/zenodo.23152797](https://doi.org/10.5281/zenodo.23152797)
Author: **Matěj Rada**
License: **CC BY-NC-ND 4.0**

Historic CTMT: DOI [10.5281/zenodo.18229539](https://doi.org/10.5281/zenodo.18229539) · OSF [10.17605/OSF.IO/RFE8N](https://osf.io/RFE8N/)

Counterexamples and attempts to break the theorems are welcome. A clean failure under the stated hypotheses is a contribution.
