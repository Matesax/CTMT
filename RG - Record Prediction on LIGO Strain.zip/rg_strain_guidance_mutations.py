#!/usr/bin/env python3
"""Mutation suite for rg_strain_guidance.py.

Each mutation changes one line of the battery or one value in a supplied artifact so that a claim of the guidance
paper becomes false. It is caught only when the targeted group fails. A mutation that survives is a defect of the
battery; a crash is a defect of the suite, not a catch. Runs in a temporary copy; shipped files are not modified.

    python3 -I rg_strain_guidance_mutations.py
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
NAME = 'rg_strain_guidance'
MUTATIONS = [  # (group, description, file relative to HERE, old, new)
    ('GA', 'a saved slide tail edited after the run', 'supplied/rg_v3/rg_v3_run/06_joint_baseline.json', '"tail_fraction": 0.32', '"tail_fraction": 0.33'),
    ('GA', 'a frozen feature edited', 'supplied/rg_v3/rg_final_H1_features.csv', '-4.136379220401160950e+01', '-4.136379220401160951e+01'),
    ('GB', 'primary model fitted on 384 windows instead of 512', NAME + '.py', 'X = load(d); tr = X[:512]', 'X = load(d); tr = X[:384]'),
    ('GC', 'wrong conformal rank', NAME + '.py', 'out = {}; k = math.ceil(129 * 0.95)', 'out = {}; k = math.ceil(129 * 0.90)'),
    ('GD', 'gate block length not the committed one', NAME + '.py', 'main = {d: gate(X[:512, P], X[576:, P], 16, rng)', 'main = {d: gate(X[:512, P], X[576:, P], 64, rng)'),
    ('GE', 'episode boundary moved', NAME + '.py', 'ep = (w >= 660) & (w <= 765)', 'ep = (w >= 700) & (w <= 765)'),
    ('GF', 'lag sign convention flipped', NAME + '.py', "abs(rows[t]['lag'] - 64) <= 1", "abs(rows[t]['lag'] + 64) <= 1"),
    ('GG', 'noise floor without the factor 2', NAME + '.py', 'floor = 1 / math.sqrt(2 * n)', 'floor = 1 / math.sqrt(n)'),
    ('GH', 'wrong injection bit read', NAME + '.py', "'NO_CW_HW_INJ' not in", "'NO_CBC_HW_INJ' not in"),
    ('GI', 'world B made identical to world A', NAME + '.py', 'yB[576:] += 0.3 * 2.5', 'yB[576:] += 0.0 * 2.5'),
    ('GK', 'recorded power taken as the total', NAME + '.py', 'X = np.exp(load(d)); var = X[:, 0] ** 2', 'X = np.exp(load(d)); var = X[:, [3, 4, 5, 6, 7, 8]].sum(1) * 3 / 8'),
    ('GJ', 'episode removed from the shifted records', NAME + '.py', 'ys[660:766] += 0.6', 'ys[660:766] += 0.0'),
]


def main():
    caught = 0
    for group, desc, rel, old, new in MUTATIONS:
        base = open(os.path.join(HERE, rel)).read()
        if base.count(old) != 1:
            print(f'{group}  {desc}: anchor not found exactly once -> SUITE DEFECT'); continue
        with tempfile.TemporaryDirectory() as tmp:
            work = os.path.join(tmp, 'b')
            shutil.copytree(HERE, work, ignore=shutil.ignore_patterns('__pycache__', NAME + '_results.json', NAME + '_mutations.py'))
            open(os.path.join(work, rel), 'w').write(base.replace(old, new))
            subprocess.run([sys.executable, '-I', NAME + '.py'], cwd=work, capture_output=True, text=True)
            try:
                fails = json.load(open(os.path.join(work, NAME + '_results.json')))['failures']
            except Exception:
                fails = ['CRASHED']
        ok = group in fails
        caught += ok
        print(f"{group}  {desc}: {'caught ' + str(fails) if ok else 'SURVIVED ' + str(fails)}", flush=True)
    print(f'{caught} / {len(MUTATIONS)} caught')
    return 0 if caught == len(MUTATIONS) else 1


if __name__ == '__main__':
    sys.exit(main())
