#!/usr/bin/env python3
"""Resolution Geometry in practice: record prediction on LIGO O4a strain. Guidance battery.

Every number in the guidance paper is recomputed here from the shipped artifacts of the retrospective run (the
checkpointed v3 package in supplied/rg_v3: feature tables, stage checkpoints, saved time-slide arrays). The raw
HDF5 strain (about 1 GB) is not shipped; its SHA-256 values are bound in the protocol. Nothing here re-reads raw
strain, and nothing in supplied/ is executed.

  GA evidence chain: every manifest hash verifies; the stage chain links (previous -> entry hash recomputed);
     completion is SUCCESS and binds the result and chain; features recomputed from raw equal the frozen tables
  GB primary score: conditional Gaussian log predictive gain over the training marginal (512-window fit,
     ridge 1e-3): H1 -0.1058, L1 +0.4940 nats per window, same sign in both test halves; nominal 95% coverage
     85.71% and 96.65%
  GC intervals (384-window fit, 128-window calibration): split-conformal rank ceil(129*0.95) = 123; coverage H1
     87.72% (Gaussian and conformal), L1 95.54% Gaussian and 98.88% conformal
  GD the refuted gate: the all-coordinate mean-shift gate rejects both detectors (H1 1.4505 > 0.6717, L1 1.5199 >
     0.6536), also within the training block, at blocks 64 and 128; it passes random partitions. The 2-4 kHz
     coordinate trends with time (r = 0.70, 0.77) and is autocorrelated at lag 16 (0.71, 0.81)
  GE the H1 episode (post hoc): 37 of 55 misses in windows 660-765, 36 under-predictions; coverage outside 94.74%;
     projection shift H1 -0.7588 (384 fit), -1.1213 (512 fit); L1 -0.0042, +0.1183; 35 of 37 episode misses in
     windows with every data-quality bit set
  GF joint calibration: tail fractions and 99th-percentile thresholds recomputed from the 99 saved slides; zero
     amplitude reproduces the baseline exactly; amplitudes 0.1, 0.3, 1.0 detected with the lag +64 samples; the
     baseline (lag 23) is not
  GG record-count law of the noise floor: the zero-slide correlation curve has standard deviation
     1/sqrt(2 N_windows N_bins) within 10%; the slide median lies 2-3.5 floors above zero (max over lags)
  GH quality typing: injection mask 23 has NO_CW_HW_INJ unset in every second (continuous-wave hardware injections
     active); data-quality values 511 and 415 decode to all bits and to all but BURST_CAT2/CAT3
  GI no predictor-only certificate (theorem witness): two worlds with bit-identical predictors and training records
     but different test conditional laws receive the same verdict from every predictor-only gate; the frozen
     interval covers 93.5% in one and 59.4% in the other
  GJ the conformal guarantee is conditional on exchangeability: on exchangeable synthetic records split-conformal
     coverage is at least 95% on average over 200 seeds; an unseen target-only episode of the H1 size lowers it below 92%
  GK the forced set: without a declared noise class the only admissible set is Parseval's; it contains every target
     and is vacuous (upper end 10^6 to 10^9 times the target), because power below 20 Hz dominates

Deterministic. Seed 20261123. Writes rg_strain_guidance_results.json.
Run:  python3 -I rg_strain_guidance.py      (numpy, scipy)
"""
import hashlib, json, math, sys
from pathlib import Path
import numpy as np
from scipy.stats import norm

HERE = Path(__file__).resolve().parent
S = HERE / 'supplied' / 'rg_v3'
RUN = S / 'rg_v3_run'
SEED = 20261123
P = [0, 1, 2, 3, 5, 6, 7, 8]
R, FAILS = {}, []


def must(cond, tag):
    if not cond:
        FAILS.append(tag); print('FAILED', tag, flush=True)


def fl(v, d=6):
    return float(f'{float(v):.{d}g}')


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def load(d, name='rg_final_{}_features.csv'):
    return np.loadtxt(S / name.format(d), delimiter=',', skiprows=1)


def jload(p):
    return json.loads(Path(p).read_text())


# ------------------------------------------------------------------ GA
def group_GA():
    man = jload(S / 'RG_v3_package_manifest.json')
    bad = [k for k, v in man.items() if isinstance(v, str) and len(v) == 64 and (S / k).exists() and sha(S / k) != v]
    checked = sum(1 for k, v in man.items() if isinstance(v, str) and len(v) == 64 and (S / k).exists())
    chain = jload(RUN / 'stage_chain.json'); links = True; prev = None; outs = True; npz_missing = []
    for e in chain:
        body = {k: e[k] for k in e if k != 'entry_sha256'}
        links &= hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest() == e['entry_sha256'] and e['previous'] == prev
        outs &= sha(RUN / e['output']) == e['sha256']
        for a, h in e['artifacts'].items():
            if (RUN / a).exists():
                outs &= sha(RUN / a) == h
            else:
                npz_missing.append(a)
        prev = e['entry_sha256']
    comp = jload(RUN / 'completion.json')
    comp_ok = comp['status'] == 'SUCCESS' and comp['result_sha256'] == sha(RUN / '09_results.json') and comp['chain_sha256'] == sha(RUN / 'stage_chain.json') \
        and comp['source_sha256'] == sha(S / 'rg_v3_battery.py')
    same = all((RUN / f'{d}_features.csv').read_bytes() == (S / f'rg_final_{d}_features.csv').read_bytes() for d in ('H1', 'L1'))
    ok = not bad and checked >= 30 and links and outs and comp_ok and same and all(a.endswith('.npz') for a in npz_missing)
    must(ok, 'GA')
    R['GA'] = dict(claim='Evidence chain: manifest hashes, stage-chain links, completion record and raw-recomputed features all '
                         'verify; only the two spectral NPZ arrays are not shipped (their hashes are bound in the chain)',
                   manifest_files_checked=checked, manifest_mismatches=bad, chain_stages=len(chain), chain_links_ok=links,
                   stage_outputs_ok=outs, completion=comp['status'], features_identical_to_frozen=same, not_shipped=sorted(npz_missing))


# ------------------------------------------------------------------ GB
def group_GB():
    out = {}
    for d in ('H1', 'L1'):
        X = load(d); tr = X[:512]; mu = tr.mean(0); sd = tr.std(0, ddof=1); Z = (tr - mu) / sd; C = np.cov(Z, rowvar=False)
        b = np.linalg.solve(C[np.ix_(P, P)] + 1e-3 * np.eye(8), C[P, 4]); v = C[4, 4] - C[4, P] @ b
        T = (X[576:] - mu) / sd; m = T[:, P] @ b; y = T[:, 4]
        g = norm.logpdf(y, m, math.sqrt(v)) - norm.logpdf(y, 0, math.sqrt(C[4, 4]))
        out[d] = dict(delta=fl(g.mean(), 5), half1=fl(g[:224].mean(), 4), half2=fl(g[224:].mean(), 4),
                      coverage95=fl(np.mean(np.abs(y - m) <= 1.959963984540054 * math.sqrt(v)), 5))
    ok = abs(out['H1']['delta'] + 0.1058) < 5e-4 and abs(out['L1']['delta'] - 0.4940) < 5e-4 and out['H1']['half1'] < 0 and out['H1']['half2'] < 0 \
        and out['L1']['half1'] > 0 and out['L1']['half2'] > 0 and abs(out['H1']['coverage95'] - 0.8571) < 1e-3 and abs(out['L1']['coverage95'] - 0.9665) < 1e-3
    must(ok, 'GB')
    R['GB'] = dict(claim='Primary score reproduced from the frozen features: H1 -0.1058, L1 +0.4940 nats per window, with the '
                         'same sign in both halves; nominal 95% coverage 85.71% (H1) and 96.65% (L1)', detectors=out)


# ------------------------------------------------------------------ GC
def fit384(X):
    fit = X[:384]; mu = fit.mean(0); sd = fit.std(0, ddof=1); Z = (fit - mu) / sd; C = np.cov(Z, rowvar=False)
    b = np.linalg.solve(C[np.ix_(P, P)] + 1e-3 * np.eye(8), C[P, 4]); var = (C[4, 4] - C[4, P] @ b) * sd[4] ** 2
    pred = lambda Y: mu[4] + sd[4] * (((Y[:, P] - mu[P]) / sd[P]) @ b)
    return mu, sd, b, var, pred


def group_GC():
    out = {}; k = math.ceil(129 * 0.95)
    commit = jload(RUN / '04_prediction_commitment.json')
    for d in ('H1', 'L1'):
        X = load(d); mu, sd, b, var, pred = fit384(X)
        q = float(np.sort(np.abs(X[384:512, 4] - pred(X[384:512])))[k - 1]); g = 1.959963984540054 * math.sqrt(var)
        err = np.abs(X[576:, 4] - pred(X[576:]))
        same_commit = np.allclose(pred(X[576:]), commit[d]['mean'], rtol=0, atol=1e-12) and abs(q - commit[d]['conformal_radius']) < 1e-12
        out[d] = dict(conformal_rank=k, conformal_coverage=fl(np.mean(err <= q), 5), gaussian_coverage=fl(np.mean(err <= g), 5),
                      conformal_width=fl(2 * q, 5), gaussian_width=fl(2 * g, 5), matches_committed_predictions=bool(same_commit))
    ok = k == 123 and out['H1']['conformal_coverage'] == out['H1']['gaussian_coverage'] and abs(out['H1']['gaussian_coverage'] - 0.87723) < 1e-4 \
        and abs(out['L1']['gaussian_coverage'] - 0.95536) < 1e-4 and abs(out['L1']['conformal_coverage'] - 0.98884) < 1e-4 \
        and all(v['matches_committed_predictions'] for v in out.values())
    must(ok, 'GC')
    R['GC'] = dict(claim='Intervals reproduced and equal to the committed predictions: conformal rank 123 of 128; H1 87.72% for '
                         'both rules; L1 95.54% Gaussian, 98.88% conformal', detectors=out)


# ------------------------------------------------------------------ GD
def gate(A, B, block, rng, reps=1999):
    mu = A.mean(0); sd = A.std(0, ddof=1); Z = (A - mu) / sd; T = (B - mu) / sd; obs = float(np.max(np.abs(T.mean(0) - Z.mean(0))))
    def res(n):
        st = rng.integers(0, len(Z), size=int(np.ceil(n / block))); return Z[((st[:, None] + np.arange(block)) % len(Z)).ravel()[:n]].mean(0)
    null = np.array([np.max(np.abs(res(len(A)) - res(len(B)))) for _ in range(reps)])
    th = float(np.quantile(null, .99)); return obs, th, 'REJECTED' if obs > th else 'NOT_REJECTED'


def group_GD():
    Xs = {d: load(d) for d in ('H1', 'L1')}
    rng = np.random.default_rng(SEED); main = {d: gate(X[:512, P], X[576:, P], 16, rng) for d, X in Xs.items()}
    ref = jload(RUN / '02_gate_reproduction.json')['detectors']; ctl = jload(RUN / '03_gate_controls.json')
    exact = all(abs(main[d][0] - ref[d]['statistic']) < 1e-12 and abs(main[d][1] - ref[d]['threshold']) < 1e-12 for d in main)
    out = {}
    for d, X in Xs.items():
        rng = np.random.default_rng(SEED); idx = rng.permutation(1024); v = X[:, 7]; z = v - v.mean()
        acf = float(z[:-16] @ z[16:] / math.sqrt((z[:-16] @ z[:-16]) * (z[16:] @ z[16:])))
        wt = gate(X[:256, P], X[256:512, P], 16, rng); rp = gate(X[idx[:512]][:, P], X[idx[512:]][:, P], 16, rng)
        blocks = {str(b): gate(X[:512, P], X[576:, P], b, rng) for b in (64, 128)}
        out[d] = dict(statistic=fl(main[d][0]), threshold=fl(main[d][1]), verdict=main[d][2], within_training=wt[2], random_partition=rp[2],
                      blocks={k: v_[2] for k, v_ in blocks.items()}, corr_time_2_4kHz=fl(np.corrcoef(np.arange(1024), v)[0, 1], 4),
                      lag16_2_4kHz=fl(acf, 4), matches_checkpoint=abs(wt[0] - ctl[d]['within_training']['statistic']) < 1e-12 and abs(rp[1] - ctl[d]['random_partition']['threshold']) < 1e-12)
    ok = exact and all(o['verdict'] == 'REJECTED' and o['within_training'] == 'REJECTED' and o['random_partition'] == 'NOT_REJECTED'
                       and all(v_ == 'REJECTED' for v_ in o['blocks'].values()) and o['corr_time_2_4kHz'] > 0.6 and o['lag16_2_4kHz'] > 0.6
                       and o['matches_checkpoint'] for o in out.values())
    must(ok, 'GD')
    R['GD'] = dict(claim='The proposed gate (H1 rejected, L1 not) is refuted: the all-coordinate gate rejects both detectors, '
                         'the within-training split and every block length, and passes random partitions; it measures a '
                         'shared 2-4 kHz trend', exact_reproduction=exact, detectors=out)


# ------------------------------------------------------------------ GE
def group_GE():
    out = {}
    ov = jload(S / 'RG_v3_quality_overlap.json')['detectors']
    for d in ('H1', 'L1'):
        X = load(d); mu, sd, b, var, pred = fit384(X); g = 1.959963984540054 * math.sqrt(var)
        err = X[576:, 4] - pred(X[576:]); miss = np.abs(err) > g; w = np.arange(576, 1024); ep = (w >= 660) & (w <= 765)
        proj = ((X[:, P] - mu[P]) / sd[P]) @ b; s384 = (proj[576:].mean() - proj[:384].mean()) / proj[:384].std(ddof=1)
        tr = X[:512]; m = tr.mean(0); s = tr.std(0, ddof=1); C = np.cov((tr - m) / s, rowvar=False)
        bb = np.linalg.solve(C[np.ix_(P, P)] + 1e-3 * np.eye(8), C[P, 4]); p5 = ((X[:, P] - m[P]) / s[P]) @ bb
        s512 = (p5[576:].mean() - p5[:512].mean()) / p5[:512].std(ddof=1)
        out[d] = dict(kurtosis_episode=fl(np.median(np.exp(X[660:766, 2])), 4), kurtosis_training=fl(np.median(np.exp(X[:512, 2])), 4),
                      misses=int(miss.sum()), episode_misses=int((miss & ep).sum()), episode_under=int((miss & ep & (err > 0)).sum()),
                      outside_coverage=fl(np.mean(~miss[~ep]), 5), projection_shift_384=fl(s384, 5), projection_shift_512=fl(s512, 5),
                      episode_misses_all_bits_clean=ov[d]['episode_misses_in_unflagged_windows'])
    h, l = out['H1'], out['L1']
    ok = (h['misses'], h['episode_misses'], h['episode_under']) == (55, 37, 36) and abs(h['outside_coverage'] - 0.94737) < 1e-4 \
        and abs(h['projection_shift_384'] + 0.75877) < 1e-4 and abs(h['projection_shift_512'] + 1.1213) < 1e-3 \
        and abs(l['projection_shift_384']) < 0.01 and l['episode_misses'] == 4 and h['episode_misses_all_bits_clean'] == 35 \
        and abs(h['kurtosis_episode'] - 2.796) < 1e-3 and abs(h['kurtosis_training'] - 2.733) < 1e-3
    must(ok, 'GE')
    R['GE'] = dict(claim='Post hoc localization of the H1 failure: 37 of 55 misses in windows 660-765 (36 under-predictions), '
                         '94.74% coverage outside, 35 of 37 in fully clean windows; the prediction direction moves by -0.76 '
                         'training sd in H1 and by 0.00 in L1', detectors=out, posthoc=True)


# ------------------------------------------------------------------ GF, GG
def group_GF_GG():
    base = jload(RUN / '06_joint_baseline.json'); rows = {}; ok = True
    for tag, amp in (('0', 0.0), ('0p1', 0.1), ('0p3', 0.3), ('1p0', 1.0)):
        c = jload(RUN / f'07_control_{tag}.json'); sl = np.array(c['slide_statistics'])
        tail = (1 + np.sum(sl >= c['observed'])) / 100; th = float(np.quantile(sl, .99))
        rows[tag] = dict(amplitude=amp, observed=fl(c['observed']), tail=fl(tail, 3), threshold=fl(th), detected=bool(c['observed'] > th),
                         lag=c['lag_samples_L1_minus_H1'])
        ok &= abs(tail - c['tail_fraction']) < 1e-12 and abs(th - c['threshold_99pct']) < 1e-15 and len(sl) == 99
    ok &= rows['0']['observed'] == fl(base['observed']) and jload(RUN / '07_control_0.json')['slide_statistics'] == base['slide_statistics']
    ok &= not rows['0']['detected'] and all(rows[t]['detected'] and abs(rows[t]['lag'] - 64) <= 1 for t in ('0p1', '0p3', '1p0'))
    ok &= rows['0p1']['observed'] < rows['0p3']['observed'] < rows['1p0']['observed']
    tm = jload(RUN / '01_raw_H1.json')['raw_target_mutation']; ratios = np.array([t_['ratio'] for t_ in tm])
    rows['raw_target_line'] = dict(windows=len(tm), at_least_fourfold=int(np.sum(ratios >= 4)), median_ratio=fl(np.median(ratios), 4),
                                   window_range=[min(t_['window'] for t_ in tm), max(t_['window'] for t_ in tm)])
    ok &= len(tm) == 106 and int(np.sum(ratios >= 4)) == 104 and abs(np.median(ratios) - 82.29) < 0.01
    must(ok, 'GF')
    R['GF'] = dict(claim='Joint-statistic calibration recomputed from the saved slides: the identity control reproduces the '
                         'baseline; amplitudes 0.1, 0.3 and 1.0 are detected with lag +64 samples; the baseline is not '
                         '(tail 0.32, lag 23)', controls=rows, lag_convention='positive = L1 delayed relative to H1')
    fr = np.fft.rfftfreq(65536, 1 / 16384); nb = int(((fr >= 20) & (fr < 1000)).sum()); n = 448 * nb; floor = 1 / math.sqrt(2 * n)
    curve = np.array(base['zero_slide_curve']); ratio = float(curve.std() / floor); med = float(np.median(base['slide_statistics']) / floor)
    okg = abs(ratio - 1) < 0.10 and 2.0 < med < 3.5
    must(okg, 'GG')
    R['GG'] = dict(claim='Record-count law of the noise floor: the zero-slide correlation over lags has standard deviation '
                         '1/sqrt(2 N_windows N_bins) within 10%; the slide median (maximum over 327 lags) lies 2-3.5 floors above zero',
                   bins=nb, windows=448, floor=fl(floor), curve_sd_over_floor=fl(ratio, 4), slide_median_over_floor=fl(med, 4),
                   detection_floor_amplitude_note='amplitude 0.1 gives 0.0074, about 14 floors')


# ------------------------------------------------------------------ GH
def group_GH():
    q = {d: jload(RUN / f'01_raw_{d}.json')['quality'] for d in ('H1', 'L1')}
    def bits(v, names):
        return [n for i, n in enumerate(names) if v >> i & 1]
    inj = {d: [(v, bits(v, q[d]['InjShortnames'])) for v in q[d]['injection_values']] for d in q}
    dq = {d: {v: sorted(set(q[d]['DQShortnames']) - set(bits(v, q[d]['DQShortnames']))) for v in q[d]['dq_values']} for d in q}
    ok = all(len(inj[d]) == 1 and inj[d][0][0] == 23 and 'NO_CW_HW_INJ' not in inj[d][0][1] for d in q) \
        and dq['H1'][511] == [] and dq['H1'][415] == ['BURST_CAT2', 'BURST_CAT3'] and dq['L1'][511] == []
    must(ok, 'GH')
    R['GH'] = dict(claim='Mask typing: injection value 23 in every second of both files leaves NO_CW_HW_INJ unset (continuous-wave '
                         'hardware injections active); data-quality 511 has all bits, 415 lacks BURST_CAT2 and BURST_CAT3',
                   injection=inj, dq_bits_cleared={d: {str(k): v for k, v in dq[d].items()} for d in dq})


# ------------------------------------------------------------------ GI
def group_GI():
    rng = np.random.default_rng(SEED + 1); n = 1024
    x = rng.normal(size=(n, 3)); e = rng.normal(size=n); beta = np.array([1.0, -0.5, 0.25])
    yA = x @ beta + 0.3 * e                                   # world A: same conditional law throughout
    yB = yA.copy(); yB[576:] += 0.3 * 2.5 * (np.arange(n)[576:] % 2 == 0)   # world B: unseen conditional shift on test
    def gate_verdict(X):                                       # any predictor-only gate is a function of the predictors
        return hashlib.sha256(np.ascontiguousarray(X).tobytes()).hexdigest()
    def cover(y):
        b = np.linalg.lstsq(x[:512], y[:512], rcond=None)[0]; s = np.std(y[:512] - x[:512] @ b, ddof=3)
        return float(np.mean(np.abs(y[576:] - x[576:] @ b) <= 1.959963984540054 * s))
    same_records = np.array_equal(yA[:576], yB[:576]); same_gate = gate_verdict(x) == gate_verdict(x.copy())
    cA, cB = cover(yA), cover(yB)
    ok = same_records and same_gate and cA > 0.93 and cB < 0.75
    must(ok, 'GI')
    R['GI'] = dict(claim='No predictor-only certificate: worlds A and B have identical predictors and identical training and '
                         'calibration records, so every predictor-only gate returns the same verdict; the frozen interval covers '
                         f'{cA:.3f} in A and {cB:.3f} in B', coverage_A=fl(cA, 4), coverage_B=fl(cB, 4), identical_records=same_records)


# ------------------------------------------------------------------ GJ
def group_GJ():
    rng = np.random.default_rng(SEED + 2); k = math.ceil(129 * 0.95); cov_ex = []; cov_shift = []
    for _ in range(200):
        x = rng.normal(size=(1024, 3)); y = x @ np.array([1.0, -0.5, 0.25]) + 0.3 * rng.standard_t(5, size=1024)
        b = np.linalg.lstsq(x[:384], y[:384], rcond=None)[0]; q = np.sort(np.abs(y[384:512] - x[384:512] @ b))[k - 1]
        cov_ex.append(np.mean(np.abs(y[576:] - x[576:] @ b) <= q))
        ys = y.copy(); ys[660:766] += 0.6                      # an unseen episode in the target only
        cov_shift.append(np.mean(np.abs(ys[576:] - x[576:] @ b) <= q))
    m_ex, m_sh = float(np.mean(cov_ex)), float(np.mean(cov_shift))
    ok = m_ex >= 0.945 and m_sh < 0.92 and m_ex - m_sh > 0.04
    must(ok, 'GJ')
    R['GJ'] = dict(claim='Split-conformal coverage is guaranteed only under exchangeability: mean coverage over 200 exchangeable '
                         'heavy-tailed synthetic records is at least 95%; an unseen target-only episode of the H1 size lowers it',
                   mean_coverage_exchangeable=fl(m_ex, 4), mean_coverage_with_episode=fl(m_sh, 4), seeds=200)


def group_GK():
    out = {}
    for d in ('H1', 'L1'):
        X = np.exp(load(d)); var = X[:, 0] ** 2
        U = 8 / 3 * var - X[:, [3, 5, 6, 7, 8]].sum(1)            # Parseval with Hann: total windowed power <= (8/3) var
        T = X[576:, 4]; r = U[576:] / T
        out[d] = dict(contains=bool(np.all(U[576:] >= T)), median_upper_over_target=fl(np.median(r), 4), min_upper_over_target=fl(r.min(), 4),
                      variance_over_recorded_20Hz_up=fl(np.median(var / X[:, [3, 4, 5, 6, 7, 8]].sum(1)), 4))
    ok = all(o['contains'] and o['median_upper_over_target'] > 1e8 and o['min_upper_over_target'] > 1e6 and o['variance_over_recorded_20Hz_up'] > 1e3 for o in out.values())
    must(ok, 'GK')
    R['GK'] = dict(claim='The only admissible set the records supply without a declared noise class is Parseval\'s: it contains '
                         'every target and is vacuous, its upper end 10^6 to 10^9 times the target, because power below 20 Hz '
                         'carries more than 10^3 times the recorded power above it', detectors=out)


def main():
    for g in (group_GA, group_GB, group_GC, group_GD, group_GE, group_GF_GG, group_GH, group_GI, group_GJ, group_GK):
        try:
            g()
        except Exception as ex:                                    # a crash is recorded as a failure of that group
            tag = g.__name__.split('_', 1)[1].split('_')[0]; must(False, tag); R[tag + '_crash'] = repr(ex)
    R['failures'] = FAILS; R['seed'] = SEED
    R['source_sha256'] = sha(HERE / 'rg_strain_guidance.py')
    (HERE / 'rg_strain_guidance_results.json').write_text(json.dumps(R, indent=1, sort_keys=True))
    print(json.dumps({k: R[k] for k in ('failures',)}), flush=True)
    return 1 if FAILS else 0


if __name__ == '__main__':
    sys.exit(main())
