"""Verify v3 checkpoints, derive posthoc DQ overlap, and package evidence.
This program never replaces or edits any numerical battery checkpoint.
"""
from pathlib import Path
import hashlib,json,zipfile,os,numpy as np
R=Path(__file__).resolve().parent;O=R/'rg_v3_run'
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(8388608),b''):h.update(b)
 return h.hexdigest()
def artifact(n):
 p=O/n
 return p if p.exists() else R/('RG_v3_'+n)
def load(n):return json.loads((O/n).read_text())
def write(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True,allow_nan=False))
assert load('completion.json')['status']=='SUCCESS'
chain=load('stage_chain.json');prev=None
for e in chain:
 assert e['previous']==prev
 c=dict(e);claimed=c.pop('entry_sha256');assert hashlib.sha256(json.dumps(c,sort_keys=True).encode()).hexdigest()==claimed
 assert sha(O/e['output'])==e['sha256']
 for name,h in e['artifacts'].items():assert sha(artifact(name))==h
 prev=claimed
assert sha(R/'rg_v3_battery.py')==load('00_protocol.json')['source_sha256']
assert sha(O/'09_results.json')==load('completion.json')['result_sha256']
assert sha(O/'stage_chain.json')==load('completion.json')['chain_sha256']
pr=load('04_prediction_commitment.json');supp={}
for d in ['H1','L1']:
 X=np.loadtxt(O/f'{d}_features.csv',delimiter=',',skiprows=1);z=np.load(artifact(f'{d}_raw_derived.npz'));dq=z['dq'];win=np.arange(576,1024);err=X[576:,4]-np.array(pr[d]['mean']);miss=np.abs(err)>pr[d]['gaussian_radius'];ep=(win>=660)&(win<=765);flag=(dq.reshape(1024,4)!=511).any(1)[576:];badsec=np.where((np.arange(4096)>=2640)&(np.arange(4096)<3064)&(dq!=511))[0];names=load('01_raw_'+d+'.json')['quality']['DQShortnames']
 ranges=[]
 for k in badsec:
  if ranges and k==ranges[-1][1]:ranges[-1][1]=int(k+1)
  else:ranges.append([int(k),int(k+1)])
 supp[d]={'flagged_seconds_GPS_halfopen':[[1368993792+a,1368993792+b] for a,b in ranges],'episode_flagged_windows':win[ep&flag].tolist(),'episode_misses_in_flagged_windows':int(np.sum(ep&miss&flag)),'episode_misses_in_unflagged_windows':int(np.sum(ep&miss&~flag)),'episode_median_residual_among_misses':float(np.median(err[ep&miss])) if np.any(ep&miss) else None,'cleared_bits':{str(int(v)):[names[b] for b in range(len(names)) if not (int(v)&(1<<b))] for v in np.unique(dq[2640:3064])},'raw_target_control_median_power_ratio':float(np.median([v['ratio'] for v in load('01_raw_'+d+'.json')['raw_target_mutation']])) if d=='H1' else None}
 np.savetxt(R/f'RG_v3_{d}_window_residuals.csv',np.column_stack([win,1368993792+4*win,err,miss.astype(int),ep.astype(int),flag.astype(int)]),delimiter=',',header='window,gps_start,residual,gaussian_miss,posthoc_episode,any_DQ_not_511',comments='')
write(R/'RG_v3_quality_overlap.json',{'source_sha256':sha(__file__),'derived_from_verified_chain':sha(O/'stage_chain.json'),'posthoc':True,'detectors':supp})
res=load('09_results.json');ctrl=res['positive_controls'];base=res['joint_baseline'];sc=res['scores'];g=load('02_gate_reproduction.json')['detectors'];diag=load('03_gate_controls.json')
lines=['# RG v3: repaired execution and retrospective findings','','## Execution status','The battery completed with its own results checkpoint and completion marker. All stage files and linked artifacts were verified independently by this packaging program. Numerical results were not assembled from logs or edited after the run. The first synchronous attempt was interrupted by the execution service time limit; its failure checkpoint is retained separately. The identical source was then rerun from raw inputs in a detached process and completed.','','## Evidence-chain repair','Each stage writes an atomic JSON checkpoint before the next stage begins. Raw-derived Fourier arrays, control differences, masks and feature tables are persisted. The stage chain binds source, raw input identities and artifacts. Predictions are checkpointed before scoring. All 99 slide values, offsets and maximizing lags are saved for baseline and every control amplitude. The completion marker is written only after assertions and artifact verification. This is local reproducibility evidence, not an external timestamp or prospective confirmation.','','## Real-noise positive controls','The synthetic control signals are explicitly artificial and are added to copies of real raw sample arrays before the same detrending, Hann taper and whitening. No HDF5 read-write operation is used. Control Fourier differences are persisted; other amplitudes use linearity of the declared preprocessing. A zero-amplitude control must reproduce the baseline exactly. The known positive delay is L1 minus H1 = +64 samples (3.90625 ms). The repaired lag convention reports this sign. Amplitude is a multiplier of the training-shaped control, not a claimed physical strain amplitude or coherence percentage.','','| Amplitude | Statistic | Slide tail fraction | Detected by fixed diagnostic | Recovered delay, samples |','|---|---:|---:|---|---:|']
for a,c in ctrl.items():lines.append(f"| {a} | {c['observed']:.8f} | {c['tail_fraction']:.2f} | {c['detected']} | {c['lag_samples_L1_minus_H1']} |")
lines+=['',f"Baseline statistic {base['observed']:.10f}; slide tail fraction {base['tail_fraction']:.2f}; signed maximizing lag {base['lag_samples_L1_minus_H1']} samples. The strong-control assertion tests detection and recovery of the known lag. These controls demonstrate sensitivity at the tested amplitudes in this particular real background, not a general detection limit or source identification. The 99th-percentile slide threshold is a diagnostic; dependence and persistent lines prevent treating it as a universally calibrated significance level.",'','## Meaningful raw-target mutation','A separate 150 Hz sinusoid is added to H1 raw sample copies in the user-selected episode, with amplitude fixed from training band power. The 80-300 Hz feature is recomputed by the actual periodogram stage. The assertion requires at least a fourfold increase in at least 95% of affected windows. The per-window original/mutated powers and ratios are persisted in the H1 raw-stage checkpoint. This tests a measurement stage, not the tautology that changing bytes changes a hash. It is not a test of the regression predictor, which is not asserted to remain valid under an artificial out-of-distribution signal.','',f"Median affected-window target-power ratio: {supp['H1']['raw_target_control_median_power_ratio']:.3f}.",'','## Gate findings and block sensitivity','The all-coordinate gate is retained only to reproduce and diagnose the refuted proposal. It is excluded from prospective certification. Random partitions test the implementation under randomized grouping; they do not prove physical exchangeability of the original time series.','']
for d in ['H1','L1']:
 q=diag[d];lines.append(f"- {d}: original statistic {g[d]['statistic']:.6f}, block-16 threshold {g[d]['threshold']:.6f}, verdict {g[d]['verdict']}; correlation with time in 2-4 kHz {q['correlation_time_2_4kHz']:.4f}, lag-16 correlation {q['lag16_correlation_2_4kHz']:.4f}. Within-training verdict {q['within_training']['verdict']}; random-partition verdict {q['random_partition']['verdict']}.")
 for b,v in q['block_sensitivity'].items():lines.append(f"  - Block {b}: threshold {v['threshold']:.6f}, verdict {v['verdict']}. Larger blocks are sensitivity checks, not stationarity certificates.")
lines+=['','## H1 episode: replicated localization, not a physical cause','The episode was specified after inspecting outcomes. All episode statistics and the projection direction are exploratory. The exact source of the band excess is not identified by kurtosis, regression residuals or quality flags. Normal full-band kurtosis cannot exclude all glitches.','']
for d in ['H1','L1']:
 q=sc[d];v=supp[d];lines.append(f"- {d}: {q['misses']} Gaussian misses; {q['episode_misses']} in inclusive windows 660-765; {q['episode_underpredictions']} episode misses are underpredictions. Outside-episode coverage {q['outside_episode_coverage']:.6%}. Episode median residual over all episode windows {q['episode_median_residual']:.6f}; median among misses {v['episode_median_residual_among_misses']}. Median kurtosis episode/training {q['episode_median_kurtosis']:.4f}/{q['training_median_kurtosis']:.4f}.")
 lines.append(f"  - Quality overlap: {v['episode_misses_in_flagged_windows']} episode misses in windows containing any DQ mask other than 511; {v['episode_misses_in_unflagged_windows']} in fully 511 windows. Flagged GPS ranges (half-open): {v['flagged_seconds_GPS_halfopen']}. Cleared bits: {v['cleared_bits']}.")
 lines.append(f"  - Projection mean shift: {q['projection_shift_fit384']:.6f} training projection standard deviations with the 384-window fit; {q['projection_shift_fit512']:.6f} with the 512-window fit. These definitions are explicit; they need not equal a differently normalized exploratory gate.")
lines+=['','## Coverage and limits','The matched 384-fit Gaussian and split-conformal coverages reproduce the earlier values. H1 remains at 87.7232% for both. L1 Gaussian coverage is 95.5357%, conformal coverage 98.8839%. No new forced-fibre solution or independent hardware-injection ephemeris recovery is claimed. The previous extremely loose spectral outer bound is not counted as a pass. The projection gate is a candidate for new-data preregistration, not a result locked here.','','## Reproduction and data availability','Use a fresh directory, or archive/remove an existing rg_v3_run directory first. Run `python rg_v3_battery.py` with numpy, scipy and netCDF4 installed and the two original raw files beside the script. The small audit ZIP includes the old feature CSVs and original input-hash protocol solely as declared reproduction dependencies, plus source, logs and JSON/CSV outputs. The separate NPZ spectral-checkpoint files (relocated byte-for-byte to top-level download names RG_v3_H1_raw_derived.npz and RG_v3_L1_raw_derived.npz; the verifier resolves both locations) include the full saved raw-derived arrays for rerunning joint diagnostics without rereading raw strain. Neither the audit ZIP nor the NPZ files contain the original approximately 1 GB of HDF5 binaries. Their exact names, byte lengths and SHA-256 values are in 00_protocol.json. The original user-supplied SharePoint links remain the source of the raw files. This omission is explicit, not a claim that the bundle is raw-data-complete.','','Original raw sharing links:','- [Original raw file](https://anetbrno-my.sharepoint.com/:t:/g/personal/and_anet-brno_cz/IQA_6K-QVaMcSYS_oA2FrEVjAdpw76A2sPFJU_XiYhpTUNE?e=aBMex7)','- [Original raw file](https://anetbrno-my.sharepoint.com/:t:/g/personal/and_anet-brno_cz/IQCAPpRJhHJYRbDMMdgjRl2OAUFm8QrMGRPFDUsDYJeOx3w?e=tVdv6V)','','## Verdict','Execution repair and the tested positive-control sensitivity checks are complete if completion.json says SUCCESS. This does not lock an RG-specific predictive improvement. The H1-only gate prediction remains refuted under the tested gate; episode localization is reproduced but remains post hoc.']
(R/'RG_v3_report.md').write_text('\n'.join(lines))
write(R/'RG_v3_independent_verification.json',{'packager_source_sha256':sha(__file__),'battery_source_sha256':sha(R/'rg_v3_battery.py'),'chain_sha256':sha(O/'stage_chain.json'),'verified_stages':len(chain),'result_sha256':sha(O/'09_results.json'),'all_artifacts_verified':True,'no_checkpoint_modified':True})
# Clearly separate reporting/packaging from the numerical program.
small=[R/'rg_v3_battery.py',R/'rg_v3_verify_package.py',R/'rg_v3_execution.log',R/'rg_v3_interrupted.log',R/'rg_final_protocol.json',R/'rg_final_H1_features.csv',R/'rg_final_L1_features.csv',R/'RG_v3_report.md',R/'RG_v3_quality_overlap.json',R/'RG_v3_independent_verification.json',R/'RG_v3_H1_window_residuals.csv',R/'RG_v3_L1_window_residuals.csv']
small += [p for p in O.iterdir() if p.suffix in ['.json','.csv']]
small += [R/'rg_v3_interrupted_run'/'failure.json']
manifest={str(p.relative_to(R)):sha(p) for p in small};write(R/'RG_v3_package_manifest.json',manifest);small.append(R/'RG_v3_package_manifest.json')
with zipfile.ZipFile(R/'RG_v3_audit.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in small:z.write(p,str(p.relative_to(R)))
for d in ['H1','L1']:
 assert artifact(d+'_raw_derived.npz').exists()
assert zipfile.ZipFile(R/'RG_v3_audit.zip').testzip() is None
print(json.dumps({'verification':'PASS','stages':len(chain),'source_sha256':sha(R/'rg_v3_battery.py'),'summary':res,'DQ_overlap':supp},indent=2))
