# RG v3: repaired execution and retrospective findings

## Execution status
The battery completed with its own results checkpoint and completion marker. All stage files and linked artifacts were verified independently by this packaging program. Numerical results were not assembled from logs or edited after the run. The first synchronous attempt was interrupted by the execution service time limit; its failure checkpoint is retained separately. The identical source was then rerun from raw inputs in a detached process and completed.

## Evidence-chain repair
Each stage writes an atomic JSON checkpoint before the next stage begins. Raw-derived Fourier arrays, control differences, masks and feature tables are persisted. The stage chain binds source, raw input identities and artifacts. Predictions are checkpointed before scoring. All 99 slide values, offsets and maximizing lags are saved for baseline and every control amplitude. The completion marker is written only after assertions and artifact verification. This is local reproducibility evidence, not an external timestamp or prospective confirmation.

## Real-noise positive controls
The synthetic control signals are explicitly artificial and are added to copies of real raw sample arrays before the same detrending, Hann taper and whitening. No HDF5 read-write operation is used. Control Fourier differences are persisted; other amplitudes use linearity of the declared preprocessing. A zero-amplitude control must reproduce the baseline exactly. The known positive delay is L1 minus H1 = +64 samples (3.90625 ms). The repaired lag convention reports this sign. Amplitude is a multiplier of the training-shaped control, not a claimed physical strain amplitude or coherence percentage.

| Amplitude | Statistic | Slide tail fraction | Detected by fixed diagnostic | Recovered delay, samples |
|---|---:|---:|---|---:|
| 0 | 0.00150019 | 0.32 | False | 23 |
| 0.1 | 0.00741702 | 0.01 | True | 64 |
| 0.3 | 0.05748796 | 0.01 | True | 64 |
| 1.0 | 0.38125952 | 0.01 | True | 64 |

Baseline statistic 0.0015001901; slide tail fraction 0.32; signed maximizing lag 23 samples. The strong-control assertion tests detection and recovery of the known lag. These controls demonstrate sensitivity at the tested amplitudes in this particular real background, not a general detection limit or source identification. The 99th-percentile slide threshold is a diagnostic; dependence and persistent lines prevent treating it as a universally calibrated significance level.

## Meaningful raw-target mutation
A separate 150 Hz sinusoid is added to H1 raw sample copies in the user-selected episode, with amplitude fixed from training band power. The 80-300 Hz feature is recomputed by the actual periodogram stage. The assertion requires at least a fourfold increase in at least 95% of affected windows. The per-window original/mutated powers and ratios are persisted in the H1 raw-stage checkpoint. This tests a measurement stage, not the tautology that changing bytes changes a hash. It is not a test of the regression predictor, which is not asserted to remain valid under an artificial out-of-distribution signal.

Median affected-window target-power ratio: 82.293.

## Gate findings and block sensitivity
The all-coordinate gate is retained only to reproduce and diagnose the refuted proposal. It is excluded from prospective certification. Random partitions test the implementation under randomized grouping; they do not prove physical exchangeability of the original time series.

- H1: original statistic 1.450494, block-16 threshold 0.671681, verdict REJECTED; correlation with time in 2-4 kHz 0.6966, lag-16 correlation 0.7052. Within-training verdict REJECTED; random-partition verdict NOT_REJECTED.
  - Block 128: threshold 0.902958, verdict REJECTED. Larger blocks are sensitivity checks, not stationarity certificates.
  - Block 64: threshold 0.902064, verdict REJECTED. Larger blocks are sensitivity checks, not stationarity certificates.
- L1: original statistic 1.519944, block-16 threshold 0.653569, verdict REJECTED; correlation with time in 2-4 kHz 0.7710, lag-16 correlation 0.8092. Within-training verdict REJECTED; random-partition verdict NOT_REJECTED.
  - Block 128: threshold 1.207248, verdict REJECTED. Larger blocks are sensitivity checks, not stationarity certificates.
  - Block 64: threshold 1.028531, verdict REJECTED. Larger blocks are sensitivity checks, not stationarity certificates.

## H1 episode: replicated localization, not a physical cause
The episode was specified after inspecting outcomes. All episode statistics and the projection direction are exploratory. The exact source of the band excess is not identified by kurtosis, regression residuals or quality flags. Normal full-band kurtosis cannot exclude all glitches.

- H1: 55 Gaussian misses; 37 in inclusive windows 660-765; 36 episode misses are underpredictions. Outside-episode coverage 94.736842%. Episode median residual over all episode windows 0.200087; median among misses 0.41504191490841436. Median kurtosis episode/training 2.7955/2.7329.
  - Quality overlap: 2 episode misses in windows containing any DQ mask other than 511; 35 in fully 511 windows. Flagged GPS ranges (half-open): [[1368996599, 1368996603], [1368996789, 1368996794]]. Cleared bits: {'415': ['BURST_CAT2', 'BURST_CAT3'], '511': []}.
  - Projection mean shift: -0.758771 training projection standard deviations with the 384-window fit; -1.121251 with the 512-window fit. These definitions are explicit; they need not equal a differently normalized exploratory gate.
- L1: 20 Gaussian misses; 4 in inclusive windows 660-765; 4 episode misses are underpredictions. Outside-episode coverage 95.321637%. Episode median residual over all episode windows 0.028832; median among misses 0.20137564972203847. Median kurtosis episode/training 2.8136/2.9388.
  - Quality overlap: 0 episode misses in windows containing any DQ mask other than 511; 4 in fully 511 windows. Flagged GPS ranges (half-open): []. Cleared bits: {'511': []}.
  - Projection mean shift: -0.004157 training projection standard deviations with the 384-window fit; 0.118251 with the 512-window fit. These definitions are explicit; they need not equal a differently normalized exploratory gate.

## Coverage and limits
The matched 384-fit Gaussian and split-conformal coverages reproduce the earlier values. H1 remains at 87.7232% for both. L1 Gaussian coverage is 95.5357%, conformal coverage 98.8839%. No new forced-fibre solution or independent hardware-injection ephemeris recovery is claimed. The previous extremely loose spectral outer bound is not counted as a pass. The projection gate is a candidate for new-data preregistration, not a result locked here.

## Reproduction and data availability
Use a fresh directory, or archive/remove an existing rg_v3_run directory first. Run `python rg_v3_battery.py` with numpy, scipy and netCDF4 installed and the two original raw files beside the script. The small audit ZIP includes the old feature CSVs and original input-hash protocol solely as declared reproduction dependencies, plus source, logs and JSON/CSV outputs. The separate NPZ spectral-checkpoint files (relocated byte-for-byte to top-level download names RG_v3_H1_raw_derived.npz and RG_v3_L1_raw_derived.npz; the verifier resolves both locations) include the full saved raw-derived arrays for rerunning joint diagnostics without rereading raw strain. Neither the audit ZIP nor the NPZ files contain the original approximately 1 GB of HDF5 binaries. Their exact names, byte lengths and SHA-256 values are in 00_protocol.json. The original user-supplied SharePoint links remain the source of the raw files. This omission is explicit, not a claim that the bundle is raw-data-complete.

Original raw sharing links:
- [Original raw file](https://anetbrno-my.sharepoint.com/:t:/g/personal/and_anet-brno_cz/IQA_6K-QVaMcSYS_oA2FrEVjAdpw76A2sPFJU_XiYhpTUNE?e=aBMex7)
- [Original raw file](https://anetbrno-my.sharepoint.com/:t:/g/personal/and_anet-brno_cz/IQCAPpRJhHJYRbDMMdgjRl2OAUFm8QrMGRPFDUsDYJeOx3w?e=tVdv6V)

## Verdict
Execution repair and the tested positive-control sensitivity checks are complete if completion.json says SUCCESS. This does not lock an RG-specific predictive improvement. The H1-only gate prediction remains refuted under the tested gate; episode localization is reproduced but remains post hoc.