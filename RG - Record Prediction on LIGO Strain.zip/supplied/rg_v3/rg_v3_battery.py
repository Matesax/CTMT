"""RG v3: checkpointed retrospective audit. Run: python rg_v3_battery.py
Dependencies: numpy scipy netCDF4. Raw inputs beside script. No network.
Synthetic signals are used ONLY as labeled additive positive controls on real strain.
"""
from pathlib import Path
import os,sys,json,hashlib,time,traceback,platform
import numpy as np,scipy,netCDF4
from scipy.signal import periodogram
from scipy.stats import kurtosis
R=Path(__file__).resolve().parent;O=R/'rg_v3_run';O.mkdir(exist_ok=True)
FS=16384;N=65536;P=[0,1,2,3,5,6,7,8];BANDS=[(20,80),(80,300),(300,1000),(1000,2048),(2048,4096),(4096,8192)]
paths={d:R/f'{a}-{d}_GWOSC_O4a_16KHZ_R1-1368993792-4096.hdf5.txt' for d,a in [('H1','H'),('L1','L')]}
chain=[]
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(8388608),b''):h.update(b)
 return h.hexdigest()
def atomic_json(p,x):
 t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,indent=2,sort_keys=True,allow_nan=False));os.replace(t,p)
def checkpoint(name,obj,artifacts=()):
 p=O/(name+'.json');atomic_json(p,obj)
 entry={'stage':name,'output':p.name,'sha256':sha(p),'artifacts':{Path(a).name:sha(a) for a in artifacts},'previous':chain[-1]['entry_sha256'] if chain else None}
 entry['entry_sha256']=hashlib.sha256(json.dumps(entry,sort_keys=True).encode()).hexdigest();chain.append(entry);atomic_json(O/'stage_chain.json',chain);print('CHECKPOINT',name,flush=True)
def save_npz(name,**kw):
 p=O/name;t=O/(name+'.tmp')
 with open(t,'wb') as f:np.savez_compressed(f,**kw)
 os.replace(t,p);return p

def main():
 expected=json.loads((R/'rg_final_protocol.json').read_text())['input_sha256']
 actual={d:sha(p) for d,p in paths.items()}
 if actual!=expected:raise RuntimeError('RAW_INPUT_HASH_MISMATCH')
 protocol={'version':3,'design':'retrospective repair; prior outcomes known; no external timestamp','source_sha256':sha(__file__),'inputs':{d:{'name':p.name,'bytes':p.stat().st_size,'sha256':actual[d]} for d,p in paths.items()},'environment':{'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'netCDF4':netCDF4.__version__,'platform':platform.platform()},'stages':'raw extraction; gate reproduction and controls; interval prediction commitment; scores and posthoc episode; joint slides; raw additive controls; evidence verification','gate':'old all-coordinate diagnostic retained only as refuted comparator; not a prospective certification gate','gate_blocks':[16,64,128],'gate_bootstrap_replicates':1999,'gate_seed':20261123,'split':{'fit':[0,384],'calibration':[384,512],'embargo':[512,576],'test':[576,1024]},'episode':'posthoc inclusive windows 660..765, selected by user after seeing targets','joint':{'band_Hz':[20,1000],'lags_samples':[-163,163],'lag_sign':'positive means L1 delayed relative to H1; use exp(-i*2*pi*f*lag) with H*conj(L)','slides':np.rint(np.linspace(32,416,99)).astype(int).tolist(),'statistic':'max absolute real normalized pooled cross correlation; identical max over lags for each slide','threshold':'observed greater than empirical 99th percentile of 99 slide values; diagnostic not calibrated source significance'},'positive_controls':{'synthetic_signal':True,'background':'unaltered real H1 and L1 strain','signal':'seeded Gaussian bandlimited common waveform, detector-shaped using training mean spectral power; additive in raw sample domain before detrend/Hann/whitening','seed':8181,'amplitudes':[0,.1,.3,1.0],'delay_samples':64,'lag_tolerance_samples':1,'requirement':'strong amplitude 1.0 must exceed own slide threshold and recover +64 samples; amplitude zero must match baseline; weak cases reported without guaranteed detection','raw_target_control':'H1 raw samples windows 660..765 plus 150Hz sinusoid with amplitude sqrt(2*median training 80..300 power)*10; require recomputed target power increase >=4x in >=95% affected windows; unchanged other windows exact feature match'},'claims':'no new RG novelty or exchangeability certification; independent injection ephemeris unavailable','failure_policy':'write failure.json and nonzero exit; never synthesize missing stage output'}
 checkpoint('00_protocol',protocol)
 freq=np.fft.rfftfreq(N,1/FS);mask=(freq>=20)&(freq<1000);fr=freq[mask];w=np.hanning(N)
 Xs={};Fs={};dqs={};injs={};raw_control={};control_features={};signal_components={}
 for d,p in paths.items():
  print('READING_RAW',d,flush=True);rows=[];F=[];FC=[];target_changed=[]
  # Independent per-detector reset gives the same underlying control spectrum.
  srng=np.random.default_rng(8181)
  with netCDF4.Dataset(p) as f:
   f.set_auto_mask(False);s=f.groups['strain'].variables['Strain'];dq=np.asarray(f.groups['quality'].groups['simple'].variables['DQmask'][:]);inj=np.asarray(f.groups['quality'].groups['injections'].variables['Injmask'][:]);dqs[d]=dq;injs[d]=inj
   for j in range(1024):
    x=np.asarray(s[j*N:(j+1)*N],dtype=float)
    if not np.all(np.isfinite(x)):raise ValueError('nonfinite strain')
    ff,ps=periodogram(x,fs=FS,window='hann',detrend='constant',scaling='density')
    vals=[np.std(x),np.max(np.abs(x)),kurtosis(x,fisher=False,bias=True)]+[float(ps[(ff>=a)&((ff<b) if b<8192 else (ff<=b))].sum()*.25) for a,b in BANDS]
    if min(vals)<=0 or not np.all(np.isfinite(vals)):raise ValueError('invalid feature')
    rows.append(np.log(vals));F.append(np.fft.rfft((x-x.mean())*w)[mask])
    # Separate meaningful raw sample mutation: known narrowband excess.
    if d=='H1' and 660<=j<=765:
     # Fixed amplitude from training features only, already extracted.
     amp=np.sqrt(2*np.median(np.exp(np.array(rows[:512])[:,4])))*10
     delta=amp*np.sin(2*np.pi*150*np.arange(N)/FS)
     xm=x.copy();xm+=delta
     _,pm=periodogram(xm,fs=FS,window='hann',detrend='constant',scaling='density');new=float(pm[(ff>=80)&(ff<300)].sum()*.25)
     target_changed.append({'window':j,'original_power':vals[4],'mutated_power':new,'ratio':new/vals[4],'raw_delta_rms':float(np.sqrt(np.mean(delta**2)))})
   F=np.array(F);power=np.mean(np.abs(F[:512])**2,axis=0);floor=1e-12*np.median(power);scale=np.sqrt(np.maximum(power,floor))
   # Positive control waveforms: raw-domain addition, not a post-statistic edit.
   # For each test window construct a shared bandlimited realization with detector-specific amplitude response.
   # Hann attenuates Fourier amplitudes; sqrt(N/sum(w^2)) normalizes expected control whitened power.
   normalization=np.sqrt(N/np.sum(w*w));delay=0 if d=='H1' else 64/FS
   for j in range(576,1024):
    z=(srng.normal(size=len(fr))+1j*srng.normal(size=len(fr)))/np.sqrt(2)
    rawspec=np.zeros(N//2+1,dtype=complex);rawspec[mask]=z*scale*normalization*np.exp(-2j*np.pi*fr*delay)
    delta=np.fft.irfft(rawspec,n=N)
    x=np.asarray(s[j*N:(j+1)*N],dtype=float)
    # Actual copied strain samples, then identical preprocessing. Difference is persisted.
    xm=x.copy();xm+=delta
    cf=np.fft.rfft((xm-xm.mean())*w)[mask]
    FC.append(cf-F[j])
   X=np.array(rows);Xs[d]=X;Fs[d]=F;signal_components[d]=np.array(FC)
   quality={'GPSstart':int(f.groups['meta'].variables['GPSstart'][...]),'DQShortnames':list(f.groups['quality'].groups['simple'].variables['DQShortnames'][:]),'InjShortnames':list(f.groups['quality'].groups['injections'].variables['InjShortnames'][:]),'dq_values':np.unique(dq).tolist(),'injection_values':np.unique(inj).tolist(),'episode_seconds':[660*4,766*4],'episode_dq_counts':{str(int(k)):int(v) for k,v in zip(*np.unique(dq[2640:3064],return_counts=True))},'episode_injection_counts':{str(int(k)):int(v) for k,v in zip(*np.unique(inj[2640:3064],return_counts=True))}}
  csv=O/f'{d}_features.csv';np.savetxt(csv,X,delimiter=',',header='log_std,log_maxabs,log_kurtosis,log_power_20_80,log_power_80_300,log_power_300_1000,log_power_1000_2048,log_power_2048_4096,log_power_4096_8192',comments='')
  npz=save_npz(f'{d}_raw_derived.npz',F=F,control_delta_F=signal_components[d],dq=dq,inj=inj,training_scale=scale)
  oldX=np.loadtxt(R/f'rg_final_{d}_features.csv',delimiter=',',skiprows=1)
  checkpoint('01_raw_'+d,{'features_recomputed_from_raw':True,'max_feature_difference_vs_previous':float(np.max(np.abs(X-oldX))),'quality':quality,'raw_target_mutation':target_changed,'target_mutation_status':'PASS' if d!='H1' or np.mean([q['ratio']>=4 for q in target_changed])>=.95 else 'FAIL'},[csv,npz])
 # Gate reproduction: seed sequence exactly as previous run for block16 original split.
 rng=np.random.default_rng(20261123)
 def gate(A,B,block,rng):
  mu=A.mean(0);sd=A.std(0,ddof=1);Z=(A-mu)/sd;T=(B-mu)/sd;obs=float(np.max(np.abs(T.mean(0)-Z.mean(0))))
  def res(n):
   st=rng.integers(0,len(Z),size=int(np.ceil(n/block)));return Z[((st[:,None]+np.arange(block))%len(Z)).ravel()[:n]].mean(0)
  null=np.array([np.max(np.abs(res(len(A))-res(len(B)))) for _ in range(1999)]);th=float(np.quantile(null,.99))
  return {'statistic':obs,'threshold':th,'verdict':'REJECTED' if obs>th else 'NOT_REJECTED','tail_fraction':float((1+np.sum(null>=obs))/2000),'block':block,'null_values':null.tolist()}
 gates={d:gate(X[:512,P],X[576:,P],16,rng) for d,X in Xs.items()}
 checkpoint('02_gate_reproduction',{'gate_is_refuted_comparator':True,'detectors':gates})
 diagnostics={}
 for d,X in Xs.items():
  rng=np.random.default_rng(20261123);idx=rng.permutation(1024);v=X[:,7];z=v-v.mean();acf=float(z[:-16]@z[16:]/np.sqrt((z[:-16]@z[:-16])*(z[16:]@z[16:])))
  diagnostics[d]={'correlation_time_2_4kHz':float(np.corrcoef(np.arange(1024),v)[0,1]),'lag16_correlation_2_4kHz':acf,'within_training':gate(X[:256,P],X[256:512,P],16,rng),'random_partition':gate(X[idx[:512]][:,P],X[idx[512:]][:,P],16,rng),'block_sensitivity':{str(b):gate(X[:512,P],X[576:,P],b,rng) for b in [64,128]}}
 checkpoint('03_gate_controls',diagnostics)
 predictions={};models={}
 for d,X in Xs.items():
  fit=X[:384];mu=fit.mean(0);sd=fit.std(0,ddof=1);Z=(fit-mu)/sd;C=np.cov(Z,rowvar=False);b=np.linalg.solve(C[np.ix_(P,P)]+.001*np.eye(8),C[P,4]);var=(C[4,4]-C[4,P]@b)*sd[4]**2
  def pred(Y):return mu[4]+sd[4]*(((Y[:,P]-mu[P])/sd[P])@b)
  q=float(np.sort(np.abs(X[384:512,4]-pred(X[384:512])))[122]);pm=pred(X[576:]);predictions[d]={'mean':pm.tolist(),'conformal_radius':q,'gaussian_radius':float(1.959963984540054*np.sqrt(var)),'mu':mu.tolist(),'sd':sd.tolist(),'weights':b.tolist(),'predictor_indices':P}
 checkpoint('04_prediction_commitment',predictions)
 scores={}
 for d,X in Xs.items():
  pr=predictions[d];y=X[576:,4];err=y-np.array(pr['mean']);miss=np.abs(err)>pr['gaussian_radius'];win=np.arange(576,1024);ep=(win>=660)&(win<=765);mu=np.array(pr['mu']);sd=np.array(pr['sd']);b=np.array(pr['weights']);proj=((X[:,P]-mu[P])/sd[P])@b
  trainproj=proj[:384];shift=float((proj[576:].mean()-trainproj.mean())/trainproj.std(ddof=1))
  # Also reproduce the original 512-fit direction, separately labeled.
  tr=X[:512];m=tr.mean(0);s=tr.std(0,ddof=1);C=np.cov(((tr-m)/s),rowvar=False);bb=np.linalg.solve(C[np.ix_(P,P)]+.001*np.eye(8),C[P,4]);proj512=((X[:,P]-m[P])/s[P])@bb
  scores[d]={'gaussian_coverage':float(np.mean(~miss)),'conformal_coverage':float(np.mean(np.abs(err)<=pr['conformal_radius'])),'gaussian_width':2*pr['gaussian_radius'],'conformal_width':2*pr['conformal_radius'],'misses':int(miss.sum()),'episode_misses':int(np.sum(miss&ep)),'episode_underpredictions':int(np.sum(miss&ep&(err>0))),'outside_episode_coverage':float(np.mean(~miss[~ep])),'episode_median_residual':float(np.median(err[ep])),'episode_median_kurtosis':float(np.median(np.exp(X[660:766,2]))),'training_median_kurtosis':float(np.median(np.exp(X[:512,2]))),'projection_shift_fit384':shift,'projection_shift_fit512':float((proj512[576:].mean()-proj512[:512].mean())/proj512[:512].std(ddof=1)),'exploratory_episode':True,'no_physical_cause_identified':True}
 checkpoint('05_scores_episode',scores)
 # Joint statistic; full arrays persisted at every amplitude.
 scale={d:np.sqrt(np.maximum(np.mean(np.abs(Fs[d][:512])**2,axis=0),1e-12*np.median(np.mean(np.abs(Fs[d][:512])**2,axis=0)))) for d in paths}
 A=Fs['H1'][576:]/scale['H1'];B=Fs['L1'][576:]/scale['L1'];DA=signal_components['H1']/scale['H1'];DB=signal_components['L1']/scale['L1'];lags=np.arange(-163,164);E=np.exp(-2j*np.pi*fr[:,None]*(lags/FS)[None,:]);offsets=np.rint(np.linspace(32,416,99)).astype(int)
 def joint(A,B):
  den=float(np.sqrt(np.sum(np.abs(A)**2)*np.sum(np.abs(B)**2)))
  def one(off):
   c=np.real(np.sum(A*np.conj(np.roll(B,int(off),axis=0)),axis=0)@E)/den;i=int(np.argmax(np.abs(c)));return float(abs(c[i])),int(lags[i]),c
  obs,lag,curve=one(0);slides=[];slags=[]
  for off in offsets:
   a,b,_=one(off);slides.append(a);slags.append(b)
  threshold=float(np.quantile(slides,.99));return {'observed':obs,'lag_samples_L1_minus_H1':lag,'lag_seconds_L1_minus_H1':lag/FS,'tail_fraction':float((1+np.sum(np.array(slides)>=obs))/100),'threshold_99pct':threshold,'detected':obs>threshold,'slide_offsets_windows':offsets.tolist(),'slide_statistics':slides,'slide_lags_samples':slags,'lag_grid_samples':lags.tolist(),'zero_slide_curve':curve.tolist(),'slide_max':max(slides),'slide_median':float(np.median(slides))}
 baseline=joint(A,B);checkpoint('06_joint_baseline',baseline)
 controls={}
 for amp in [0,.1,.3,1.0]:
  out=joint(A+amp*DA,B+amp*DB);out['synthetic_additive_control']=True;out['amplitude']=amp;out['known_delay_samples']=64;out['lag_recovered']=abs(out['lag_samples_L1_minus_H1']-64)<=1;out['added_to_real_raw_samples_before_preprocessing']=True
  if amp==0:out['identity_control_pass']=out['observed']==baseline['observed'] and out['slide_statistics']==baseline['slide_statistics']
  controls[str(amp)]=out;checkpoint('07_control_'+str(amp).replace('.','p'),out)
 # Strong control must flip the exact tested joint stage, not merely a hash.
 assertions={'raw_feature_reproduction':all(float(np.max(np.abs(Xs[d]-np.loadtxt(R/f'rg_final_{d}_features.csv',delimiter=',',skiprows=1))))<1e-10 for d in paths),'identity_control':controls['0']['identity_control_pass'],'strong_signal_detected':controls['1.0']['detected'],'strong_signal_lag_recovered':controls['1.0']['lag_recovered'],'target_signal_mutation_detected':json.loads((O/'01_raw_H1.json').read_text())['target_mutation_status']=='PASS','all_slide_arrays_saved':len(baseline['slide_statistics'])==99 and all(len(c['slide_statistics'])==99 for c in controls.values()),'original_inputs_unchanged':all(sha(paths[d])==actual[d] for d in paths),'source_unchanged':sha(__file__)==protocol['source_sha256']}
 checkpoint('08_assertions',assertions)
 # A failure here leaves all earlier checkpoints available and no completed result.
 if not all(assertions.values()):raise RuntimeError('ASSERTION_FAILURE: '+str([k for k,v in assertions.items() if not v]))
 summary={'status':'COMPLETED','all_assertions_pass':True,'source_sha256':protocol['source_sha256'],'inputs':protocol['inputs'],'stage_outputs':{e['stage']:{'file':e['output'],'sha256':e['sha256']} for e in chain},'gate_verdicts':{d:g['verdict'] for d,g in gates.items()},'scores':scores,'joint_baseline':{k:baseline[k] for k in ['observed','lag_samples_L1_minus_H1','tail_fraction','detected']},'positive_controls':{k:{a:v[a] for a in ['observed','tail_fraction','detected','lag_samples_L1_minus_H1','lag_recovered']} for k,v in controls.items()},'RG_improvement_lock':False,'injection_truth_recovery':'NOT_RUN_MISSING_INDEPENDENT_PARAMETERS','forced_fibre':'NOT_SOLVED; previous outer bound not treated as a pass','prospective_gate':'all-coordinate gate excluded; projection gate remains posthoc candidate'}
 checkpoint('09_results',summary)
 # Independent byte-level verification of every referenced checkpoint and artifact.
 for e in chain:
  assert sha(O/e['output'])==e['sha256']
  for name,h in e['artifacts'].items():assert sha(O/name)==h
 atomic_json(O/'completion.json',{'status':'SUCCESS','source_sha256':sha(__file__),'result_sha256':sha(O/'09_results.json'),'chain_sha256':sha(O/'stage_chain.json'),'exit_code':0})
 print('SUCCESS',flush=True)
if __name__=='__main__':
 try:main()
 except BaseException as e:
  atomic_json(O/'failure.json',{'status':'FAILED','error':repr(e),'traceback':traceback.format_exc(),'completed_stages':[q['stage'] for q in chain]});traceback.print_exc();sys.exit(1)
