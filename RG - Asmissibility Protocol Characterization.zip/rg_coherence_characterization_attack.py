import json, math
from pathlib import Path
import numpy as np

SEED=20260805
rng=np.random.default_rng(SEED)

# Candidate coherence survival morphisms c(r,t), normalized by c(r,0)=1.
# Semigroup law c(r,t+s)=c(r,t)c(r,s) is the decisive composition axiom.
def exp_survival(r,t): return np.exp(-r*t)
def stretched(r,t,p=1.5): return np.exp(-(r*t)**p)
def rational(r,t): return 1/(1+r*t)
def gaussian(r,t): return np.exp(-(r*t)**2)
def linear_cut(r,t): return np.maximum(0,1-r*t)
def constant(r,t): return np.ones_like(np.asarray(r,dtype=float))

candidates={
 'exponential': exp_survival,
 'stretched_exponential_p1.5': stretched,
 'rational': rational,
 'gaussian': gaussian,
 'linear_cutoff': linear_cut,
 'constant_degenerate': constant,
}
rates=np.array([0.08,0.19,0.43,0.91,1.7,3.2])
tests=[tuple(rng.uniform(0.01,2.0,2)) for _ in range(500)]

morphism_results={}
for name,f in candidates.items():
    norm=float(np.max(np.abs(f(rates,0)-1)))
    sem=[]
    monot=[]
    for t,s in tests:
        a=f(rates,t+s); b=f(rates,t)*f(rates,s)
        sem.append(np.max(np.abs(a-b)))
        monot.append(np.max(np.maximum(0,np.diff(f(rates,t))))) # should decrease with rate
    vals=np.concatenate([f(rates,t) for t,_ in tests])
    morphism_results[name]={
      'normalization_error':norm,
      'semigroup_max_error':float(max(sem)),
      'rate_monotonicity_violation':float(max(monot)),
      'range_ok':bool(np.all((vals>=-1e-12)&(vals<=1+1e-12))),
      'nondegenerate':bool(np.max(np.abs(f(rates,1)-1))>1e-8),
    }

# Candidate proper-time reparameterizations phi. Continuous semigroup compatibility
# requires phi(t+s)=phi(t)+phi(s), hence phi(t)=a t. Battery checks examples.
phis={
 'identity':lambda t:t,
 'scale_0.5':lambda t:.5*t,
 'scale_2':lambda t:2*t,
 'power_2':lambda t:t*t,
 'sqrt':lambda t:np.sqrt(t),
 'log1p':lambda t:np.log1p(t),
}
clock_results={}
for name,phi in phis.items():
    errs=[abs(phi(t+s)-phi(t)-phi(s)) for t,s in tests]
    clock_results[name]={'additivity_max_error':float(max(errs))}

# Candidate transforms h of survival. Composition c12=c1*c2 should become additive
# proper time h(c1*c2)=h(c1)+h(c2). Continuous solutions are a*(-log c).
hs={
 'minus_log':lambda x:-np.log(x),
 'minus_2log':lambda x:-2*np.log(x),
 'one_minus_x':lambda x:1-x,
 'inverse_minus_one':lambda x:1/x-1,
 'minus_log_squared':lambda x:(-np.log(x))**2,
}
xs=rng.uniform(.05,.99,500); ys=rng.uniform(.05,.99,500)
transform_results={}
for name,h in hs.items():
    err=np.max(np.abs(h(xs*ys)-h(xs)-h(ys)))
    transform_results[name]={'multiplicative_to_additive_max_error':float(err)}

# Fixed coherence budget B in additive proper time gives a unique hard sector.
# Survival floor eps at horizon T is equivalent to r*T <= -log eps.
T=2.0; eps=0.2; B=-math.log(eps)
canonical=(rates*T <= B)
all_masks=[np.array([(m>>i)&1 for i in range(len(rates))],dtype=bool) for m in range(2**len(rates))]
# Rules: soundness, completeness, monotone lower set in rate, product restriction.
def lower_set(mask):
    # rates sorted ascending: accepted mask cannot return to true after false
    return all(not mask[j] or all(mask[:j+1]) for j in range(len(mask)))
sound=[m for m in all_masks if not np.any(m & ~canonical)]
complete=[m for m in sound if np.array_equal(m,canonical)]
monotone=[m for m in complete if lower_set(m)]

# Gauge/coordinate covariance: similarity does not alter rate spectrum or mask.
Q,_=np.linalg.qr(rng.normal(size=(6,6)))
A=Q@np.diag(rates)@Q.T
evals=np.linalg.eigvalsh(A)
covariant_mask=(evals*T <= B)
covariance_ok=bool(np.array_equal(covariant_mask,canonical))

result={
 'title':'RG coherence characterization and canonical morphism attack',
 'seed':SEED,
 'established_structure_tested':{
   'coherence_object':'positive normalized survival/contraction morphism c_t on observable directions',
   'composition':'c_{t+s}=c_t c_s',
   'proper_time_transform':'continuous map h turning multiplicative survival into additive duration',
   'hard_admissibility':'maximal lower spectral subobject within a fixed coherence budget B',
 },
 'morphism_candidates':morphism_results,
 'clock_reparameterizations':clock_results,
 'survival_to_time_transforms':transform_results,
 'fixed_budget_sector_attack':{
   'rates':rates.tolist(),'horizon_T':T,'survival_floor_epsilon':eps,'budget_B_minus_log_epsilon':B,
   'canonical_mask':canonical.tolist(),'all_masks':len(all_masks),'sound_masks':len(sound),
   'sound_and_complete_masks':len(complete),'final_monotone_masks':len(monotone),
   'coordinate_covariance_ok':covariance_ok,
 },
 'ledger':{
  'forced_by_continuous_positive_semigroup': 'c_t=exp(-tK) on simultaneously diagonal scalar modes; mode survival is exponential in additive parameter',
  'forced_by_multiplicative_composition': 'coherence proper time is -a log c, unique up to positive scale a',
  'forced_hard_sector_given_budget': 'P_B = 1_[0,B](T K), equivalently survival c_T >= epsilon',
  'forced_by_soundness_plus_completeness': 'maximal coherence-surviving resolved sector, no arbitrary shrinkage',
  'not_forced': 'absolute time scale a, horizon T, survival floor epsilon, or budget B',
  'anchor_needed': 'one declared calibration event, unit decay rate, decision loss, resource budget, or physical clock comparison',
 },
 'verdict':{
  'canonical_morphism_form':'supported: continuous nondegenerate positive composition selects exponential survival; logarithm selects additive coherence time up to scale',
  'canonical_threshold_rule':'supported conditionally: fixed coherence budget uniquely selects a lower spectral projector and maximal sector',
  'absolute_tau_uniqueness':'refuted without an external normalization/anchor',
  'best_theorem_target':'Coherence-clock characterization up to scale, followed by fibrewise uniqueness after one calibration anchor fixes the scale and budget.',
  'relation_to_RG_tau':'If information modes decay with generator K, the coherence cut is spectral in K. It coincides with the existing P_tau cut in L=G^{-1}F only when K is a declared monotone function of L; this compatibility is an additional theorem/hypothesis, not automatic.'
 }
}
Path('/mnt/data/rg_coherence_characterization_attack.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result['fixed_budget_sector_attack'],indent=2))
print(json.dumps(result['verdict'],indent=2))
