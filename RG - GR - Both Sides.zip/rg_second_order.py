"""RG second-order lock battery.
Question: conservation (source side) + descent to the gauge quotient (RG) select the linearized Einstein operator
among SECOND-order operators. Can derivative order itself be locked?
S1  fourth-order compatible operators: exactly two (k^2 E and the R-operator) -- order is NOT forced by compatibility.
S2  spin decomposition (Barnes-Rivers projectors) of E + alpha k^2 E + beta R-op.
S3  static response: Newtonian 1/r plus Yukawa weights -4/3 (spin 2) and +1/3 (spin 0) (Stelle form).
S4  residue signs: the massive spin-2 mode is a ghost; the scalar is healthy -> stability alone does not select order.
S5  hidden state (Kalman minimal realization): 2 (E), +5 (k^2 E), +1 (R-op) propagating values per point.
S6  data window: a declared inverse-square precision eps at test scale r_t confines extra modes to ranges
    lambda <= r_t / ln(w/eps): below that scale fourth-order completions are a CORRESPONDENCE.
Run: python rg_second_order.py --out DIR   (sympy, numpy)
"""
import argparse, hashlib, json, math, pathlib, sys, time
import numpy as np, sympy as sp

RES = {}


def must(c, m):
    if not c:
        raise AssertionError(m)


k = sp.symbols("k0:4"); e = sp.symbols("e0:10"); xi = sp.symbols("xi0:4")
eta = sp.diag(-1, 1, 1, 1)
IDX = [(i, j) for i in range(4) for j in range(i, 4)]
EPS = sp.zeros(4, 4)
for n, (i, j) in enumerate(IDX):
    EPS[i, j] = EPS[j, i] = e[n]
KL = sp.Matrix(k); KU = eta * KL; K2 = (KL.T * eta * KL)[0]


def pieces(eps):
    tr = sum(eta[a, a] * eps[a, a] for a in range(4)); keps = eps * KU; kek = (KU.T * eps * KU)[0]
    return tr, keps, kek


def op2(eps, c):
    tr, keps, kek = pieces(eps)
    return sp.Matrix(4, 4, lambda a, b: c[0] * K2 * eps[a, b] + c[1] * (KL[a] * keps[b] + KL[b] * keps[a])
                     + c[2] * KL[a] * KL[b] * tr + c[3] * eta[a, b] * K2 * tr + c[4] * eta[a, b] * kek)


def op4(eps, d):
    tr, keps, kek = pieces(eps)
    return sp.Matrix(4, 4, lambda a, b: d[0] * K2 ** 2 * eps[a, b] + d[1] * K2 * (KL[a] * keps[b] + KL[b] * keps[a])
                     + d[2] * KL[a] * KL[b] * kek + d[3] * K2 * KL[a] * KL[b] * tr + d[4] * eta[a, b] * K2 ** 2 * tr
                     + d[5] * eta[a, b] * K2 * kek)


def compatible(builder, coeffs):
    O = sp.expand(builder(EPS, coeffs) * KU)
    G = sp.expand(builder(sp.Matrix(4, 4, lambda a, b: KL[a] * xi[b] + KL[b] * xi[a]), coeffs))
    eqs = set()
    for ex in O:
        eqs |= set(sp.Poly(ex, *k, *e).coeffs())
    for ex in G:
        eqs |= set(sp.Poly(ex, *k, *xi).coeffs())
    A = sp.Matrix([[sp.diff(q, c) for c in coeffs] for q in eqs])
    return A.nullspace()


def S1():
    c = sp.symbols("c0:5"); d = sp.symbols("d0:6")
    ns2 = compatible(op2, c); ns4 = compatible(op4, d)
    E2 = [1, -1, 1, -1, 1]
    kE2 = [1, -1, 0, 1, -1, 1]                       # k^2 * Einstein in the fourth-order basis
    Rop = [0, 0, -1, 1, -1, 1]                       # (eta k^2 - k k) R_lin, R_lin = k.e.k - k^2 tr
    span = sp.Matrix.hstack(*ns4)
    in_span = lambda v: sp.Matrix.hstack(span, sp.Matrix(v)).rank() == span.rank()
    must(len(ns2) == 1 and list(ns2[0] / ns2[0][0]) == E2, "second order unique")
    must(len(ns4) == 2 and in_span(kE2) and in_span(Rop) and sp.Matrix.hstack(sp.Matrix(kE2), sp.Matrix(Rop)).rank() == 2,
         "fourth-order space = span(k^2 E, R-op)")
    RES["S1"] = dict(claim="Conservation + descent force second order", status="REFUTED (order is a separate gate)",
                     witness="Second order: compatible space dim 1 = linearized Einstein (1,-1,1,-1,1). Fourth order "
                             "(six-term general ansatz): compatible space dim 2 = span{k^2 E, (eta k^2 - k k) R_lin} "
                             "(sympy nullspace). Compatibility fixes the operator at each order, not the order.")


def projectors(kv):
    """Barnes-Rivers projectors for a static spacelike k (Euclidean-signature spatial block suffices)."""
    q2 = float(kv @ kv)
    th = np.eye(3) - np.outer(kv, kv) / q2
    P2 = np.zeros((3, 3, 3, 3)); P0 = np.zeros((3, 3, 3, 3))
    for a in range(3):
        for b in range(3):
            for c_ in range(3):
                for d_ in range(3):
                    P2[a, b, c_, d_] = 0.5 * (th[a, c_] * th[b, d_] + th[a, d_] * th[b, c_]) - th[a, b] * th[c_, d_] / 3
                    P0[a, b, c_, d_] = th[a, b] * th[c_, d_] / 3
    return P2, P0


def S2_S5():
    q2, al, be, M = sp.symbols("q2 alpha beta M", positive=True)
    # spin-channel kinetic coefficients of the operators, read off by contracting with projectors (static k)
    kv = np.array([0.0, 0.0, 1.0])
    def kin(c4, c2):
        """numeric operator on spatial-spatial (and 00 via trace) components: compute spin coefficients by
        acting the full 4D operator on projector-built test tensors (k = (0,0,0,1), k^2 = 1)."""
        sub = {k[0]: 0, k[1]: 0, k[2]: 0, k[3]: 1}
        out = []
        for eps_np in test_tensors():
            Em = sp.Matrix(eps_np)
            O = (op2(Em, c2) + op4(Em, c4)).subs(sub)
            out.append(np.array(O, dtype=float))
        return out
    return None


def test_tensors():
    """Spin-2 test: TT tensor e_xy+e_yx (k along z). Spin-0 test: theta-trace tensor in the transverse 3-space incl. time."""
    t2 = np.zeros((4, 4)); t2[1, 2] = t2[2, 1] = 1
    # transverse projector theta_ab = eta_ab - k_a k_b/k^2 for k = (0,0,0,1)
    th = np.diag([-1.0, 1, 1, 0])
    return [t2, th]


def spin_coeffs(c2, c4, kk):
    """eigenvalues of the operator on the spin-2 test tensor and on the spin-0 (theta) test tensor at k^2 = kk."""
    s = math.sqrt(kk)
    sub = {k[0]: 0, k[1]: 0, k[2]: 0, k[3]: s}
    t2, th = test_tensors()
    O2 = np.array((op2(sp.Matrix(t2), c2) + op4(sp.Matrix(t2), c4)).subs(sub), dtype=float)
    O0 = np.array((op2(sp.Matrix(th), c2) + op4(sp.Matrix(th), c4)).subs(sub), dtype=float)
    a2 = O2[1, 2] / t2[1, 2]
    a0 = O0[1, 1] / th[1, 1]
    must(abs(O0[0, 0] / th[0, 0] - a0) < 1e-9 * (1 + abs(a0)), "theta is an eigen-direction")
    return a2, a0


def S2toS6():
    E2 = [1, -1, 1, -1, 1]; kE2 = [1, -1, 0, 1, -1, 1]; Rop = [0, 0, -1, 1, -1, 1]; z4 = [0] * 6; z2 = [0] * 5
    out = {}
    for name, (c2, c4) in {"E": (E2, z4), "k2E": (z2, kE2), "Rop": (z2, Rop)}.items():
        vals = {kk: spin_coeffs(c2, c4, kk) for kk in (1.0, 4.0)}
        p2 = math.log(abs(vals[4.0][0] / vals[1.0][0])) / math.log(4) if abs(vals[1.0][0]) > 1e-12 else None
        p0 = math.log(abs(vals[4.0][1] / vals[1.0][1])) / math.log(4) if abs(vals[1.0][1]) > 1e-12 else None
        out[name] = dict(spin2=vals[1.0][0], spin0=vals[1.0][1], power2=p2, power0=p0)
    # E: a2 = s2 k^2, a0 = s0 k^2 ; k2E: k^2 * same ; Rop: spin-0 only, k^4
    s2, s0 = sp.nsimplify(out["E"]["spin2"]), sp.nsimplify(out["E"]["spin0"]); r0 = sp.nsimplify(out["Rop"]["spin0"])
    must((s2, s0, r0) == (1, -2, -3) and abs(out["Rop"]["spin2"]) < 1e-12 and out["Rop"]["power0"] is not None and abs(out["Rop"]["power0"] - 2) < 1e-9
         and abs(out["k2E"]["spin2"] - s2) < 1e-9 and abs(out["k2E"]["power2"] - 2) < 1e-9
         and abs(out["E"]["power2"] - 1) < 1e-9, "spin decomposition")
    # static response for source T = M u u: amplitudes TP2T = 2/3 M^2, TP0T = 1/3 M^2 (theta = diag(-1,1,1,0))
    q2, al, be = sp.symbols("q2 alpha beta", positive=True)
    a2 = s2 * q2 * (1 + al * q2)
    a0 = s0 * q2 * (1 + al * q2) + r0 * be * q2 ** 2
    TP2T, TP0T = sp.Rational(2, 3), sp.Rational(1, 3)
    amp = sp.simplify(TP2T / a2 + TP0T / a0)
    newton = sp.limit(amp * q2, q2, 0)
    pf = sp.apart(sp.simplify(amp / newton), q2)
    terms = sp.Add.make_args(pf)
    weights = {}
    for tm in terms:
        num, den = sp.fraction(sp.together(tm))
        xx = sp.Symbol("xx")
        pole = sp.solve(den.subs(q2, xx), xx)
        mass2 = sp.simplify(-pole[0]) if pole else None
        weights[str(mass2)] = sp.simplify(num / sp.diff(den, q2))
    w_newton = weights.get("0"); w_spin2 = weights.get(str(sp.simplify(1 / al)))
    w_spin0 = [v for kk_, v in weights.items() if kk_ not in ("0", str(sp.simplify(1 / al)))]
    must(sp.simplify(w_newton - 1) == 0 and sp.simplify(w_spin2 + sp.Rational(4, 3)) == 0
         and len(w_spin0) == 1 and sp.simplify(w_spin0[0] - sp.Rational(1, 3)) == 0, "Stelle weights")
    m0sq = [kk_ for kk_ in weights if kk_ not in ("0", str(sp.simplify(1 / al)))][0]
    RES["S2"] = dict(claim="Spin content of the compatible operators", status="LOCKED",
                     witness=f"On a spin-2 TT tensor and a spin-0 transverse trace tensor (static k): E acts as "
                             f"({s2:+.3f} k^2, {s0:+.3f} k^2); k^2 E as k^2 times that; the R-operator as (0, {r0:+.3f} k^4). "
                             "k^2 E adds a spin-2 pole, the R-operator a spin-0 pole.", details=out)
    RES["S3"] = dict(claim="Static response of E + alpha k^2 E + beta R-op", status="LOCKED",
                     witness=f"Partial fractions of the source-saturated static amplitude: V(r) = -(GM/r)[1 - (4/3) e^(-r/sqrt(alpha)) "
                             f"+ (1/3) e^(-m0 r)], m0^2 = {m0sq} (the Stelle form; beta = -2 alpha/3 removes the scalar). "
                             "Only alpha = beta = 0 gives an exact inverse-square energy channel.", details={k_: str(v) for k_, v in weights.items()})
    # S4 residue signs relative to the massless graviton in the spin-2 channel
    res_massless = sp.limit(TP2T / a2 * q2, q2, 0)
    x2 = sp.Symbol("x2")
    res_massive = sp.simplify(sp.cancel(TP2T / (s2 * x2 * (1 + al * x2)) * (x2 + 1 / al)).subs(x2, -1 / al))
    ghost = sp.simplify(res_massive / res_massless)
    a0_only_R = s0 * q2 + r0 * be * q2 ** 2
    res0_massless = sp.limit(TP0T / a0_only_R * q2, q2, 0)
    xx = sp.Symbol("xx"); pole0 = sp.solve(sp.simplify(a0_only_R / q2).subs(q2, xx), xx)[0]
    x3 = sp.Symbol("x3")
    res0_massive = sp.simplify(sp.cancel((TP0T / a0_only_R.subs(q2, x3)) * (x3 - pole0)).subs(x3, pole0))
    sc = sp.simplify(res0_massive / res0_massless)
    must(res_massless > 0 and res_massive < 0 and res0_massive > 0, "residues")
    RES["S4"] = dict(claim="Stability alone selects second order", status="REFUTED (only the spin-2 extension is a ghost)",
                     witness=f"Exchange residues between conserved sources (massless graviton {res_massless}): the k^2 E massive "
                             f"spin-2 pole has residue {res_massive} < 0, a ghost (excluded by stability); the R-operator "
                             f"massive scalar pole has residue {res0_massive} > 0, a healthy scalaron (f(R), +1/3 Yukawa). "
                             "Stability excludes k^2 E but not the R-operator.")
    # S5 hidden state: propagating values per point (2J+1 per massive pole, 2 for the massless graviton)
    def count(alv, bev):
        A2 = sp.Poly(sp.expand(s2 * q2 * (1 + alv * q2)), q2); A0 = sp.Poly(sp.expand(s0 * q2 * (1 + alv * q2) + r0 * bev * q2 ** 2), q2)
        n2 = A2.degree() - 1; n0 = A0.degree() - 1              # massive poles beyond the massless one
        return 2 + 5 * n2 + 1 * n0
    dof = {"E (GR)": count(0, 0), "E + alpha k^2 E (generic quadratic)": count(1, 0),
           "E + beta R-op (f(R)-type)": count(0, 1), "E + alpha k^2 E + beta R-op, beta = -2alpha/3 (Weyl^2-type)": count(1, sp.Rational(-2, 3))}
    must(list(dof.values()) == [2, 8, 3, 7], "dof count")
    RES["S5"] = dict(claim="All compatible operators carry the same hidden state", status="REFUTED: order adds hidden values",
                     witness=f"Propagator pole count of hidden values per point (2 per massless graviton, 5 per massive spin-2 pole, "
                             f"1 per massive spin-0 pole): {dof}. The second-order operator is the "
                             "unique MINIMAL realization; every higher-order completion adds hidden values that are real "
                             "(observable as Yukawa forces), not null.", details=dof)
    return weights


def S6():
    out = {}
    for eps in (1e-2, 1e-3):
        for rt in (5e-5, 1e-3, 1.0):           # metres: laboratory torsion-balance scale to metre scale (illustrative)
            lam2 = rt / math.log((4 / 3) / eps); lam0 = rt / math.log((1 / 3) / eps)
            out[f"eps={eps}, r_test={rt} m"] = dict(lambda_spin2_max_m=lam2, lambda_spin0_max_m=lam0)
    must(all(v["lambda_spin2_max_m"] < float(k_.split("r_test=")[1].split(" ")[0]) for k_, v in out.items()), "window")
    RES["S6"] = dict(claim="Second order is locked by data", status="LOCKED DOWN TO A SCALE (correspondence below it)",
                     witness="If the inverse-square law holds to fractional precision eps at separations r >= r_test, the "
                             "Yukawa terms force lambda_2 <= r_test/ln((4/3)/eps) and lambda_0 <= r_test/ln((1/3)/eps). "
                             "Above that scale the energy channel is exactly second order; below it, fourth-order "
                             "completions remain a CORRESPONDENCE. Example: eps = 1e-3 at r_test = 50 um gives "
                             f"lambda_2 <= {out['eps=0.001, r_test=5e-05 m']['lambda_spin2_max_m'] * 1e6:.1f} um.",
                     details=out)


def main(outdir):
    out = pathlib.Path(outdir); out.mkdir(parents=True, exist_ok=True); t0 = time.time()
    S1(); S2toS6(); S6()
    canaries = {
        "compatibility (conservation+descent) alone fixes the derivative order": RES["S1"]["status"].startswith("REFUTED"),
        "stability alone fixes the derivative order": RES["S4"]["status"].startswith("REFUTED"),
        "higher-order completions add no hidden state": RES["S5"]["status"].startswith("REFUTED"),
    }
    must(all(canaries.values()), "canaries")
    verdict = ("Second order is SELECTED, not derived: by H-min (minimal hidden state: the unique compatible minimal "
               "realization, 2 values per point), confirmed by stability for the spin-2 extension and by data "
               "(inverse-square tests) down to a declared scale; the R-operator (f(R)) is excluded only by H-min and data.")
    res = dict(results=RES, canaries_rejected=canaries, verdict=verdict, runtime_s=round(time.time() - t0, 1),
               python=sys.version.split()[0], sympy=sp.__version__,
               source_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest())
    (out / "rg_second_order_results.json").write_text(json.dumps(res, indent=1, default=str))
    for k_, v in RES.items():
        print(k_, v["status"], "|", v["witness"][:260])
    print(verdict)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default="."); main(ap.parse_args().out)
