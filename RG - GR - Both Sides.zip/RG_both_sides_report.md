# RG: Both Sides of Linear Gravity — report

**Decision: pack now.** The linear-order result is complete, with every gate named. The second-order gate is now
*selected* rather than assumed. The nonlinear completion goes to the next paper.

**Locked (with stated premises)**
- **Hidden vs null.** Kalman decomposition of the history protocol: PBH 48/48 hidden; a decoupled variable is
  operationally null; at k = 0 the history rank stays 5.
- **Source side.**
  - Observer: 48 cases, task error ≤ 3.7e-8 within the deterministic bounds.
  - Free streaming: no finite closure.
  - BGK collisions: asymptotic diffusion closure (not momentum-conserving).
- **Geometry side.** The TT wave has T = 0 but nonzero tidal curvature. Observer: 48 cases, state error 1.3e-9.
- **Coupling.** Conservation ∩ descent → linearized Einstein, unique at second order (80 holdouts).

**Second-order gate (new battery, rg_second_order.py)**
- **S1.** Fourth-order compatible operators form a 2-dimensional space, span{k²E, R-op}. So the order is *not*
  forced by compatibility.
- **S2–S3.** Static potential V = −GM/r[1 − (4/3)e^{−r/λ₂} + (1/3)e^{−m₀r}] (Stelle form).
- **S4.** The spin-2 extension is a ghost (residue −2/3). The scalar is healthy (+1/6, f(R)). Stability alone is
  insufficient.
- **S5.** Hidden values per point: GR 2, f(R)-type 3, Weyl²-type 7, generic quadratic 8. GR is the unique minimal
  realization, so H-min selects second order.
- **S6.** Data lock above a scale: λ₂ ≤ r_t / ln((4/3)/ε). Below that scale, a correspondence remains.

**Still declared:** H-carrier (spin-2, flat background), H-loc, H-min, and the source microdynamics.
**Not derived:** the nonlinear completion, backreaction, a real detector inversion, and **full GR from RG**.

**Errata to rg_hidden_dynamics.py (found by your audit):**
- the observer had a sine-mode sign error;
- the Hankel matrix flattened the six output channels;
- "null" is reworded to "operationally null".

**Battery:** second-order S1–S6, 3 canaries rejected; reruns identical. Imported: both-sides 655/655
(`imported/`).
