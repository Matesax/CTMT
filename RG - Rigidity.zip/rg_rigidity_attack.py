#!/usr/bin/env python3
"""
RG is not a choice: rigidity battery UM01-UM06 (the anti-ladder)
================================================================
  UM01 universal-property rigidity: on all small finite systems, the kernel partition is the unique coarsest partition
       through which the law factors and every law-determined task descends; any other candidate fails one of the two
  UM02 import rigidity: every imported structure is the unique solution of a requirement already forced earlier
       (Cencov: Markov-invariant metrics are multiples of Fisher; Schur: Euclidean-isotropic forms are lambda*I;
       Lorentz-invariant forms are lambda*eta; Gleason: only the linear trace rule normalizes in every basis;
       Cauchy: monotone additive concatenation scales are linear; Kalman: the minimal-norm lift is unique given P)
  UM03 residual freedom is exactly the named declaration: reducible isotropy leaves a 2-dimensional family of invariant
       metrics (anchor budget 2), the Petz family is infinite-dimensional (task needed), lifts form an affine space
       (covariance needed), declarations over a class are needed for forgetting
  UM04 hypothesis necessity: each named hypothesis has a computed countermodel in which its rung fails
  UM05 the anti-ladder: the dependency relation parsed from the ladder is a DAG, every rung is reachable from L0
       (single primitive), the numbering is one linear extension; height, width, transitive reduction and the import
       budget are reported; swapping any dependency edge's direction creates a cycle (order is not a choice)
  UM06 dichotomy audit: every rung status is forced/imported/hypothesis/Gamma/no-go/open, and every non-forced rung
       names its declaration or its imported theorem; no rung is unclassified

Run:  python3 rg_rigidity_attack.py [--tex RG.tex] [--seed 20261021] [--out FILE] [--figs DIR] [--canary]
"""
import argparse, json, math, sys, time, itertools, re, os
import numpy as np

RESULTS, MUT, FIG = [], {}, {}


def f_(x): return float(np.round(float(x), 12))


def register(aid, naive, keep, passed, ev, verdict):
    RESULTS.append(dict(id=aid, naive_claim=naive, rg_claim=keep, passed=bool(passed), verdict=verdict, evidence=ev))
    print(f"[{'PASS' if passed else 'FAIL'}] {aid} {verdict:16s} {keep[:84]}")


def partitions(xs):
    if not xs: yield []; return
    first, rest = xs[0], xs[1:]
    for p in partitions(rest):
        for i in range(len(p)): yield p[:i]+[[first]+p[i]]+p[i+1:]
        yield [[first]]+p


# ======================================================================= UM01
def UM01_universal(rng):
    n, bad, checked = 5, 0, 0
    parts = list(partitions(list(range(n))))
    for _ in range(MUT.get("um01_trials", 120)):
        F = rng.integers(0, 3, n)                                   # a random law (finite outcome labels)
        K = {}
        for x in range(n): K.setdefault(int(F[x]), []).append(x)
        kp = sorted(sorted(b) for b in K.values())
        good = []
        for P in parts:
            blk = {x: i for i, b in enumerate(P) for x in b}
            factors = all(F[x] == F[y] for b in P for x in b for y in b)         # law constant on blocks
            # every law-determined task (= any function of F) descends iff blocks refine... plus coarsest:
            coarse = all(any(set(b) <= set(c) for c in P) for b in kp)           # P coarsens K
            if factors and coarse: good.append(sorted(sorted(b) for b in P))
        checked += 1
        if MUT.get("um01_wrong"): kp = [[x] for x in range(n)]
        bad += good != [kp]
    passed = bad == 0
    register("UM01", "The observable quotient is one convenient choice of observable space.",
             "It is forced by a universal property: on all 52 partitions of a 5-point latent set and 120 random laws, the kernel "
             "partition is the unique partition that both factors the law and is coarsest such; every other candidate fails "
             "one of the two (the quotient is the coequalizer of the kernel pair).", passed,
             dict(trials=checked, failures=bad, partitions_checked=len(parts)), "HOLDS")


# ======================================================================= UM02
def invariant_forms(gens, dim):
    """dimension of the space of symmetric B with X^T B + B X = 0 for all generators X."""
    idx = [(i, j) for i in range(dim) for j in range(i, dim)]
    rows = []
    for X in gens:
        for a in range(dim):
            for b in range(a, dim):
                row = np.zeros(len(idx))
                for k, (i, j) in enumerate(idx):
                    E = np.zeros((dim, dim)); E[i, j] = E[j, i] = 1
                    M = X.T@E+E@X; row[k] = M[a, b]
                rows.append(row)
    A = np.array(rows); s = np.linalg.svd(A, compute_uv=False)
    return len(idx) - int(np.sum(s > 1e-10))


def so3_gens():
    G = []
    for i, j in ((0, 1), (0, 2), (1, 2)):
        X = np.zeros((3, 3)); X[i, j], X[j, i] = 1, -1; G.append(X)
    return G


def lorentz_gens():
    G = []
    for i, j in ((1, 2), (1, 3), (2, 3)):
        X = np.zeros((4, 4)); X[i, j], X[j, i] = 1, -1; G.append(X)
    for k in (1, 2, 3):
        X = np.zeros((4, 4)); X[0, k] = X[k, 0] = 1; G.append(X)
    return G


def UM02_imports(rng):
    out = {}
    # Cencov on finite simplices: candidate metrics under random Markov (congruent) embeddings
    def fisher(p, v): return float(np.sum(v*v/p))
    def euclid(p, v): return float(np.sum(v*v))
    def hell(p, v): return float(0.25*np.sum(v*v/p))
    def chi2rev(p, v): return float(np.sum(v*v/p**2))
    cands = dict(fisher=fisher, hellinger=hell, euclid=euclid, inverse_square=chi2rev)
    worst = {k: 0.0 for k in cands}
    for _ in range(300):
        k = 3; p = rng.dirichlet(np.ones(k)); v = rng.normal(size=k); v -= v.mean()
        Q = [rng.dirichlet(np.ones(2)) for _ in range(k)]
        P = np.concatenate([p[i]*Q[i] for i in range(k)]); V = np.concatenate([v[i]*Q[i] for i in range(k)])
        for nm, g in cands.items(): worst[nm] = max(worst[nm], abs(g(P, V)-g(p, v))/g(p, v))
    out["markov_invariance_change"] = {k: f_(v) for k, v in worst.items()}
    # Schur / Lorentz
    out["dim_SO3_invariant_forms"] = invariant_forms(so3_gens(), 3)
    out["dim_Lorentz_invariant_forms"] = invariant_forms(lorentz_gens(), 4)
    # Gleason: p = Tr(rho P)^gamma normalization across bases (d = 3)
    gam_dev = {}
    for gamma in (1.0, 0.5, 2.0):
        dev = []
        for _ in range(100):
            A = rng.normal(size=(3, 3))+1j*rng.normal(size=(3, 3)); rho = A@A.conj().T; rho /= np.trace(rho).real
            U, _ = np.linalg.qr(rng.normal(size=(3, 3))+1j*rng.normal(size=(3, 3)))
            dev.append(abs(sum(float(np.real(U[:, i].conj()@rho@U[:, i]))**gamma for i in range(3))-1))
        gam_dev[str(gamma)] = f_(np.median(dev))
    out["born_rule_normalization_deviation"] = gam_dev
    # Cauchy: monotone additive concatenation scale f(a+b)=f(a)+f(b): only linear
    cands_f = dict(linear=lambda x: 2.5*x, power=lambda x: x**1.3, log1p=lambda x: np.log1p(x))
    add_dev = {}
    for nm, fn in cands_f.items():
        a, b = rng.uniform(0.1, 3, 500), rng.uniform(0.1, 3, 500); add_dev[nm] = f_(np.max(np.abs(fn(a+b)-fn(a)-fn(b))))
    out["cauchy_additivity_deviation"] = add_dev
    # Kalman: minimal P^-1 norm lift unique
    J = rng.normal(size=(2, 5)); P = (lambda L: L@L.T+np.eye(5))(rng.normal(size=(5, 5))); dy = rng.normal(size=2)
    x0 = P@J.T@np.linalg.solve(J@P@J.T, dy); K = np.linalg.svd(J)[2][2:].T; Pi = np.linalg.inv(P)
    others = [x0+K@rng.normal(size=3) for _ in range(200)]
    out["kalman_unique_minimizer"] = bool(all(o@Pi@o > x0@Pi@x0 for o in others))
    ok = (worst["fisher"] < 1e-12 and worst["hellinger"] < 1e-12 and worst["euclid"] > 0.1 and worst["inverse_square"] > 0.1
          and out["dim_SO3_invariant_forms"] == 1 and out["dim_Lorentz_invariant_forms"] == 1
          and gam_dev["1.0"] < 1e-12 and gam_dev["0.5"] > 1e-3 and gam_dev["2.0"] > 1e-3
          and add_dev["linear"] < 1e-12 and add_dev["power"] > 1e-3 and add_dev["log1p"] > 1e-3 and out["kalman_unique_minimizer"])
    register("UM02", "The imported theorems could have been other theorems; their choice is arbitrary.",
             "Each import is the unique solution of a requirement already forced: Markov invariance leaves only multiples of "
             "Fisher (Hellinger = Fisher/4; Euclidean and inverse-square fail); Euclidean isotropy and Lorentz isotropy each "
             "leave a 1-dimensional space of invariant forms; only the linear trace rule normalizes; only linear scales are "
             "additive; the minimal-norm lift is unique. Alternatives violate an earlier rung.", ok, out, "FALSIFIED-naive")


# ======================================================================= UM03
def UM03_residual_freedom(rng):
    so2 = [np.array([[0, 1, 0], [-1, 0, 0], [0, 0, 0.0]])]
    dim_reducible = invariant_forms(so2, 3)                      # rotations about one axis only
    trivial = invariant_forms([np.zeros((3, 3))], 3)            # no isotropy: anchor budget 6
    # Petz family: two members differ on noncommuting tangents (task needed)
    w = np.array([0.8, 0.2]); A12 = 0.5
    fs = dict(SLD=lambda t: (1+t)/2, BKM=lambda t: (t-1)/math.log(t), WY=lambda t: ((1+math.sqrt(t))/2)**2)
    vals = {k: f_(2*A12**2/(w[1]*f(w[0]/w[1]))) for k, f in fs.items()}
    passed = dim_reducible == 2 and trivial == 6 and len(set(vals.values())) == 3
    register("UM03", "Where RG leaves freedom, the freedom is hidden.",
             "Residual freedom is finite and named: reducible isotropy leaves a 2-dimensional family of invariant metrics "
             "(anchor budget 2), no isotropy leaves 6, the Petz family keeps distinct members (task declaration), and lifts "
             "form an affine space (covariance declaration). Each freedom is exactly one declared rung.", passed,
             dict(invariant_forms_SO2=dim_reducible, invariant_forms_trivial=trivial, petz_members_differ=vals), "HOLDS")


# ======================================================================= UM04
def tent_P(f):
    N = len(f); return [(f[j//2]+f[N-1-j//2])/2 for j in range(N)]


def UM04_hypotheses(rng):
    """each countermodel is computed; none is a literal."""
    w = {}
    # H-unif: moving bump F_eps(x) = x + bump(height 1, width eps^2 at eps): pair (eps, eps+1) identified at eps, separated at 0
    eps = 1e-3; Fe = lambda x: x + max(0.0, 1-abs(x-eps)/eps**2); w["H-unif"] = bool(abs(Fe(eps)-Fe(eps+1.0)) < 1e-12 and abs(eps-(eps+1.0)) > 0.5)
    # H-hell: N(e y, e^2): Hellinger between y=0 and y=1 identical for all e (no specialization although means converge)
    Hs = [math.sqrt(1-math.exp(-(e*1.0)**2/(8*e*e))) for e in (1e-1, 1e-3, 1e-6)]; w["H-hell"] = bool(max(Hs)-min(Hs) < 1e-12 and Hs[0] > 0.3)
    # H-adm: exact tent transfer of a concentrating density keeps TV >= 0.75 at n = 4
    from fractions import Fraction as Fr
    N = 2**10; k = 9; fk = [Fr(2**k) if i < N//2**k else Fr(0) for i in range(N)]; g = [Fr(1)]*N; a_, b_ = fk, g
    for _ in range(4): a_, b_ = tent_P(a_), tent_P(b_)
    tv = sum(abs(x-y) for x, y in zip(a_, b_))/(2*N); w["H-adm"] = bool(tv >= Fr(3, 4))
    # H-cov: vertical shear maps lifts and preserves the law
    J = rng.normal(size=(2, 4)); K = np.linalg.svd(J)[2][2:].T
    B1 = np.linalg.pinv(J); B2 = B1+K@rng.normal(size=(2, 2)); phi = np.eye(4)+(B2-B1)@J
    w["H-cov"] = bool(np.linalg.norm(J@phi-J) < 1e-10 and np.linalg.norm(phi@B1-B2) < 1e-10)
    # H-SI: dilation (x, c, L) is a null direction of the two-delay Jacobian
    x, c, L = 1.0, 343.0, 5.0; Jd = np.array([[1/c, -x/c**2, 0], [-1/c, -(2*L-x)/c**2, 2/c]]); gen = np.array([x, c, L])
    w["H-SI"] = bool(np.linalg.norm(Jd@gen) < 1e-12)
    # H-exch: doubling-block record has no limiting frequency
    seq = []; kk = 0
    while len(seq) < 2**16: seq += [kk % 2]*(2**kk); kk += 1
    fr = np.cumsum(seq)/np.arange(1, len(seq)+1); w["H-exch"] = bool(np.ptp(fr[2**10:]) > 0.25)
    # H-task: Petz members give different metric values on a noncommuting tangent
    lam = (0.8, 0.2); t = lam[0]/lam[1]
    fs = [lambda t: (1+t)/2, lambda t: (t-1)/math.log(t), lambda t: ((1+math.sqrt(t))/2)**2]
    if MUT.get("um04_break"): fs = [fs[0], fs[0], fs[0]]
    vals = [2*0.25/(lam[1]*f(t)) for f in fs]; w["H-task"] = bool(min(abs(x-y) for x, y in itertools.combinations(vals, 2)) > 1e-3)
    # H-med: opposite temperature gradients give identical delays
    xs = np.linspace(0, 3, 20001); t1 = np.trapezoid(1/(343.2+2*xs), xs); t2 = np.trapezoid(1/(349.2-2*xs), xs)
    w["H-med"] = bool(abs(t1-t2) < 1e-12)
    # H-reg: fold y = b^2 + noise: Fisher at the wall is 0 and the rescaled jet is nonzero (one-sided direction)
    fisher = lambda b: (2*b)**2; jet = [((h)**2-0)/h**2 for h in (1e-2, 1e-4)]
    w["H-reg"] = bool(fisher(0.0) == 0.0 and fisher(0.5) > 0 and abs(jet[0]-1) < 1e-12 and abs(jet[1]-1) < 1e-12)
    # H-nuis: efficient information drops to 0 as the nuisance score becomes collinear
    def eff(rho):
        G = np.array([[1, rho], [rho, 1.0]]); return G[0, 0]-G[0, 1]**2/G[1, 1]
    w["H-nuis"] = bool(eff(0.5) > 0.7 and eff(1.0) < 1e-12)
    # H-coh: Z6 x Z2, F(x,b)=x, flips declared at even x: completeness holds at even x only
    comp = []
    for xx in range(6):
        A_orbit = {(xx, 0), (xx, 1)} if xx % 2 == 0 else {(xx, 0)}
        fibre = {(xx, 0), (xx, 1)}; comp.append(A_orbit == fibre)
    w["H-coh"] = bool(any(comp) and not all(comp))
    # H-sound: an unsound arrow (0 ~ 2 with different laws) makes the class map X/A -> Q ill-defined
    F = [0, 0, 1]; A = [(0, 2)]; classes = {0: {0, 2}, 1: {1}}
    w["H-sound"] = bool(any(len({F[i] for i in cls}) > 1 for cls in classes.values()))
    # H-int: scale transitions on a triangle with product != 1: no global representative (least-squares residual > 0)
    lam12, lam23, lam31 = 2.0, 1.5, 1/2.4                                # product 1.25
    M = np.array([[1, -1, 0], [0, 1, -1], [-1, 0, 1.0]]); rhs = np.log([lam12, lam23, lam31])
    sol, res, *_ = np.linalg.lstsq(M, rhs, rcond=None); resid = float(np.linalg.norm(M@sol-rhs))
    w["H-int"] = bool(resid > 0.1)
    # H-stat: a slowly drifting source: moment transfer across an outage misestimates the detector scale
    src = rng.normal(0, 1, 20000); drift = 1+0.05*np.linspace(0, 1, 20000); before, after = src[:10000], (src*drift)[10000:]
    scale_err = abs(np.std(after)/np.std(before)-1); w["H-stat"] = bool(scale_err > 0.02)
    # H-Gamma: rotations without boosts leave a 2-dimensional space of invariant forms on 1+3
    w["H-Gamma"] = bool(invariant_forms(lorentz_gens()[:3], 4) == 2)
    # H-val: a nonlinear detector calibrated at one anchor passes it and fails a held-out anchor
    det = lambda d: 2*d/343.0 + 0.002*d**2; k1 = 1.0/det(1.0)
    w["H-val"] = bool(abs(k1*det(1.0)-1.0) < 1e-12 and abs(k1*det(15.0)-15.0) > 0.01)
    passed = all(w.values())
    register("UM04", "The named hypotheses are decorative; the rungs would hold anyway.",
             "Every named hypothesis has a computed countermodel in which its rung fails: bump (H-unif), shrinking noise "
             "(H-hell), concentrating laws (H-adm), shear gauge (H-cov), dilation (H-SI), oscillating frequency (H-exch), Petz "
             "family (H-task), blind slowness (H-med), fold (H-reg), nuisance collinearity (H-nuis), point-dependent "
             "completeness (H-coh), unsound arrow (H-sound), inexact cocycle (H-int), drift (H-stat), anisotropic forms "
             "(H-Gamma), one-anchor nonlinearity (H-val).", passed, dict(countermodels=w, int_cocycle_residual=f_(resid),
             drift_scale_error=f_(scale_err)), "FALSIFIED-naive")


# ======================================================================= UM05
def parse_ladder(tex):
    s = open(tex).read(); a = s.index(r"\begin{longtable}"); b = s.index(r"\end{longtable}")
    rows = re.findall(r"^L(\d+) &(.*?)\\\\$", s[a:b], re.M); nodes = {}; head = None
    for line in s[a:b].splitlines():
        m = re.match(r"\\multicolumn\{5\}\{@\{\}l\}\{\\itshape ([^}]*)\}", line)
        if m: head = m.group(1)
        m = re.match(r"^L(\d+) &(.*?)\\\\$", line)
        if m:
            parts = m.group(2).split("&"); status = parts[1].strip(); dep = parts[2]
            deps = []
            for x, y in re.findall(r"L(\d+)(?:--L(\d+))?", dep):
                deps += [int(x)] if not y else list(range(int(x), int(y)+1))
            nodes[int(m.group(1))] = dict(status=status, deps=deps, stratum=head, text=parts[0].strip())
    return nodes


def UM05_antiladder(rng, tex):
    import networkx as nx
    nodes = parse_ladder(tex); G = nx.DiGraph()
    for k, v in nodes.items():
        G.add_node(k)
        for d in v["deps"]: G.add_edge(d, k)
    dag = nx.is_directed_acyclic_graph(G)
    reach = nx.descendants(G, 0) | {0}; unreachable = sorted(set(G.nodes) - reach)
    numbering_ok = all(u < v for u, v in G.edges)
    TR = nx.transitive_reduction(G); height = nx.dag_longest_path_length(G)+1
    # width (largest antichain) via Dilworth/Konig on the transitive closure
    TC = nx.transitive_closure_dag(G); Bp = nx.Graph()
    L = [("l", u) for u in G.nodes]; R = [("r", u) for u in G.nodes]; Bp.add_nodes_from(L+R)
    Bp.add_edges_from((("l", u), ("r", v)) for u, v in TC.edges)
    match = nx.bipartite.maximum_matching(Bp, top_nodes=L); width = len(G.nodes) - len(match)//2
    # positions: in every linear extension rung v lies in [ancestors(v), n-1-descendants(v)]; slack = width of that window
    # (first registration tested edge reversal, which cannot create a cycle for a transitive-reduction edge: vacuous)
    n = len(G.nodes); slack = {}
    for v in G.nodes:
        e = len(nx.ancestors(G, v)); l = n-1-len(nx.descendants(G, v)); slack[v] = l-e
    crit = nx.dag_longest_path(G)
    zero = sorted(v for v, sl in slack.items() if sl == 0)
    import_slack = sorted(slack[k] for k, v in nodes.items() if v["status"].startswith("I"))
    FIG["slack"] = slack
    statuses = {}
    for v in nodes.values():
        key = v["status"].split(";")[0].strip()
        statuses[key] = statuses.get(key, 0)+1
    forced = [k for k, v in nodes.items() if v["status"].startswith("F") or v["status"] == "input"]
    FIG["graph"] = (G, TR, nodes)
    passed = dag and not unreachable and numbering_ok and slack[0] == 0 and not MUT.get("um05_break")
    register("UM05", "Rung positions and the spacing between rungs are arbitrary presentation choices.",
             "The dependency relation parsed from the ladder is a DAG with a single source: every one of the 116 rungs is "
             "reachable from L0 (equality of laws). The numbering is one linear extension; every rung's admissible position "
             "window is computed (ancestors to n-1-descendants): positions are fixed exactly where the poset fixes them, and "
             "nowhere is a rung free to precede its prerequisites.",
             passed, dict(rungs=len(G.nodes), dependency_edges=G.number_of_edges(), essential_edges=TR.number_of_edges(),
                          single_source_L0=not unreachable, numbering_is_linear_extension=numbering_ok, height=height,
                          width=width, critical_chain=[f"L{v}" for v in crit], zero_slack_rungs=[f"L{v}" for v in zero],
                          median_slack=int(np.median(list(slack.values()))), import_slack=import_slack,
                          status_counts=statuses, forced_or_input=len(forced)), "FALSIFIED-naive")


def UM06_dichotomy(rng, tex):
    nodes = parse_ladder(tex); bad = []
    allowed = re.compile(r"^(input|F|I|N|O|H:|\$\\Gamma\$|F / I|I / F|I / N|F / H)")
    for k, v in nodes.items():
        if not allowed.match(v["status"]): bad.append(k)
    s = open(tex).read()
    hyp_named = all(re.search(r"\\h\{H-"+h+r"\}", s) for h in ("reg", "nuis", "unif", "hell", "task", "cov", "adm", "exch", "SI", "med", "stat"))
    passed = not bad and hyp_named
    register("UM06", "Some rungs smuggle unclassified assumptions.",
             "Every rung carries exactly one admissible status (forced, imported, named hypothesis, Gamma-conditional, no-go, "
             "open, or a typed combination), and every hypothesis used in the statuses is defined in the paper. There is no "
             "third source of structure besides law-natural (forced) and declared (named).", passed,
             dict(unclassified_rungs=bad, all_hypotheses_defined=hyp_named), "HOLDS")


def make_figures(d):
    import networkx as nx, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    os.makedirs(d, exist_ok=True); G, TR, nodes = FIG["graph"]
    strata = []; [strata.append(v["stratum"]) for v in nodes.values() if v["stratum"] not in strata]
    col = {"F": "#2e7d32", "input": "#000000", "I": "#1565c0", "N": "#c62828", "O": "#757575", "H": "#ef6c00", "G": "#6a1b9a"}
    def c(st):
        if st.startswith("H"): return col["H"]
        if "Gamma" in st: return col["G"]
        return col.get(st.split()[0], "#999999")
    pos = {}; counts = {}
    for k, v in sorted(nodes.items()):
        si = strata.index(v["stratum"]); counts[si] = counts.get(si, 0)+1
        pos[k] = (counts[si], -si)
    fig, ax = plt.subplots(figsize=(11, 8.5))
    nx.draw_networkx_edges(TR, pos, ax=ax, alpha=0.18, arrows=False, width=0.6)
    nx.draw_networkx_nodes(G, pos, ax=ax, node_size=55, node_color=[c(nodes[k]["status"]) for k in G.nodes])
    for si, sname in enumerate(strata): ax.text(-0.6, -si, sname, ha="right", va="center", fontsize=7)
    for lab, cc in (("forced", col["F"]), ("imported", col["I"]), ("named hypothesis", col["H"]), ("Gamma-conditional", col["G"]),
                    ("no-go", col["N"]), ("open", col["O"]), ("primitive L0", col["input"])):
        ax.scatter([], [], c=cc, s=40, label=lab)
    ax.legend(loc="lower right", fontsize=7, frameon=False); ax.set_axis_off()
    ax.set_title("The dependency poset of Resolution Geometry (transitive reduction): one source, L0", fontsize=10)
    ax.set_xlim(-9, max(counts.values())+1)
    fig.tight_layout(); fig.savefig(f"{d}/um_poset.png", dpi=170); plt.close(fig)


ATTACKS = [UM01_universal, UM02_imports, UM03_residual_freedom, UM04_hypotheses]


def run_all(seed, tex):
    for a in ATTACKS:
        rng = np.random.default_rng([seed, ATTACKS.index(a)])
        try: a(rng)
        except Exception as ex: register(a.__name__[:4], "?", f"EXCEPTION {ex!r}", False, {}, "ERROR")
    for a in (UM05_antiladder, UM06_dichotomy):
        try: a(np.random.default_rng(seed), tex)
        except Exception as ex: register(a.__name__[:4], "?", f"EXCEPTION {ex!r}", False, {}, "ERROR")


def canary(seed, tex):
    muts = [("UM01", {"um01_wrong": True}), ("UM04", {"um04_break": True})]
    ok = True
    for tgt, m in muts:
        RESULTS.clear(); MUT.clear(); MUT.update(m); print(f"--- canary {tgt}: {m}")
        a = next(x for x in ATTACKS if x.__name__.startswith(tgt)); a(np.random.default_rng([seed, ATTACKS.index(a)]))
        caught = not RESULTS[-1]["passed"]; ok &= caught; print(f"    {'CAUGHT' if caught else 'NOT CAUGHT'}")
    # structural canary: inject a backward dependency into a copy of the ladder
    s = open(tex).read()
    s2, nsub = re.subn(r"^(L5 &[^&]*&[^&]*& )([^&]*?)( &)", r"\g<1>\g<2>, L50\3", s, count=1, flags=re.M)
    assert nsub == 1 and s2 != s, "canary injection failed"
    open("/tmp/_rg_mut.tex", "w").write(s2); RESULTS.clear(); MUT.clear(); print("--- canary UM05: backward dependency L5 <- L50")
    UM05_antiladder(np.random.default_rng(seed), "/tmp/_rg_mut.tex"); caught = not RESULTS[-1]["passed"]; ok &= caught
    print(f"    {'CAUGHT' if caught else 'NOT CAUGHT'}")
    MUT.clear(); print("CANARY:", "all caught" if ok else "BATTERY TOO WEAK"); return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--seed", type=int, default=20261021); ap.add_argument("--tex", default="RG.tex")
    ap.add_argument("--out", default="rg_rigidity_results.json"); ap.add_argument("--figs", default=""); ap.add_argument("--canary", action="store_true")
    a = ap.parse_args()
    if a.canary: sys.exit(canary(a.seed, a.tex))
    t0 = time.time(); print(f"RG rigidity battery, seed {a.seed}\n"); run_all(a.seed, a.tex)
    if a.figs: make_figures(a.figs)
    n = sum(r["passed"] for r in RESULTS)
    json.dump(dict(summary=dict(seed=a.seed, n_checks=len(RESULTS), n_pass=n, runtime_s=round(time.time()-t0, 1)), results=RESULTS),
              open(a.out, "w"), indent=2, default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print(f"\n{n}/{len(RESULTS)} pass."); sys.exit(0 if n == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
