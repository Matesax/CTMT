# RG - Rigidity: battery UM01-UM06 (the anti-ladder)

    python3 rg_rigidity_attack.py --tex "Resolution Geometry.tex" --figs figs   # seed 20261021
    python3 rg_rigidity_attack.py --tex "Resolution Geometry.tex" --canary      # 3 canaries, each must fail

6/6 on seeds 20261021, 1, 42, 777, 2026; canary 3/3.
UM01 universal property of the quotient | UM02 import rigidity (Cencov, Schur, Lorentz, Gleason, Cauchy, Kalman) |
UM03 residual freedom = named declarations | UM04 computed countermodel for each of 16 hypotheses |
UM05 dependency poset of the print edition: single source L0, height 23, width 46, positional slack |
UM06 dichotomy audit: every rung status is forced, imported, named, Gamma-conditional, no-go or open.
The battery parses the ladder source itself, so it re-audits any future edition.
