#!/usr/bin/env python3
"""
RG undermine, extended: battery UX01-UX09
=========================================
External critique, verified and turned into regression checks. Each attack is computed; UX09 audits the repaired texts
(print edition and rigidity paper) so the old overclaims cannot silently return.

  UX01 naturality is not selection: relabeling-invariant law-natural metrics on Bernoulli form an infinite family
       (a(p) dp^2, a(p)=a(1-p)); only Fisher survives Markov (congruent) embeddings -> selection principle H-mono
  UX02 effective symmetry depends on the latent presentation: same law image, Gamma_A = (R,+), Gamma_B = {e}
  UX03 pullback radical: ambient nondegeneracy of mu does not give rad(F*mu) = V (null image tangent); the corrected
       criterion (mu restricted to the image tangent nondegenerate) agrees with direct computation in every case
  UX04 minimal panels need finiteness: finite index sets always have minimal sufficient panels (exhaustive); the prefix
       family on {0,1}^N has sufficient panels (all infinite S) but no minimal one (removal preserves sufficiency)
  UX05 exact kernel equality is not uniformly certifiable from finite samples: TV <= n|delta|, test power ~ alpha
  UX06 kernel inclusion does not imply metric monotonicity: a garbling enlarges the kernel and INCREASES Euclidean distance;
       Fisher contracts (data processing) -> monotonicity is a selection requirement, not a consequence of L4
  UX07 non-omission is not necessity: the moving bump refutes omitting H-unif, yet the weaker hypothesis (local uniform
       convergence without a modulus) already proves kernel upper semicontinuity; the modulus is needed only to certify
  UX08 set quotient vs smooth quotient: an injective immersion with non-closed image (figure-eight) has a canonical set
       quotient that is not an embedded submanifold -> smooth statements need H-reg
  UX09 text audit of the repaired papers (fails on the pre-repair versions)

Run:  python3 rg_undermine_ext_attack.py [--tex RG.tex] [--rig RG_-_Rigidity.tex] [--seed 20261022] [--out FILE] [--canary]
"""
import argparse, json, math, sys, time, itertools, re
import numpy as np

RESULTS, MUT = [], {}


def f_(x): return float(np.round(float(x), 12))


def register(aid, naive, keep, passed, ev, verdict):
    RESULTS.append(dict(id=aid, naive_claim=naive, rg_claim=keep, passed=bool(passed), verdict=verdict, evidence=ev))
    print(f"[{'PASS' if passed else 'FAIL'}] {aid} {verdict:16s} {keep[:84]}")


def UX01_naturality_not_selection(rng):
    # family on Bernoulli: a(p) symmetric; relabeling invariance and descent hold for all
    fams = dict(fisher=lambda p: 1/(p*(1-p)), euclid=lambda p: 1.0+0*p, quartic=lambda p: 1+(p-0.5)**2*4, logit2=lambda p: 1/(p*(1-p))**2)
    ps = np.linspace(0.05, 0.95, 19)
    sym = {k: f_(np.max(np.abs(a(ps)-a(1-ps)))) for k, a in fams.items()}
    ratio_var = {k: f_(np.ptp(a(ps)/fams["fisher"](ps))) for k, a in fams.items()}
    # Markov (congruent) embeddings on simplices: metric family g_a(p; v) = sum a_i(p_i) v_i^2 extended coordinatewise
    coord = dict(fisher=lambda p: 1/p, euclid=lambda p: 1+0*p, quartic=lambda p: 1+(p-0.5)**2*4, logit2=lambda p: 1/p**2)
    worst = {k: 0.0 for k in coord}
    for _ in range(200):
        k = 3; p = rng.dirichlet(np.ones(k)); v = rng.normal(size=k); v -= v.mean(); Q = [rng.dirichlet(np.ones(2)) for _ in range(k)]
        P = np.concatenate([p[i]*Q[i] for i in range(k)]); V = np.concatenate([v[i]*Q[i] for i in range(k)])
        for nm, a in coord.items():
            g0 = float(np.sum(a(p)*v*v)); g1 = float(np.sum(a(P)*V*V)); worst[nm] = max(worst[nm], abs(g1-g0)/g0)
    # first gate demanded ratio range > 1; Euclidean/Fisher = p(1-p) has range 0.2025 on the grid: non-constant is the claim
    passed = all(v <= 1e-10 for v in sym.values()) and min(ratio_var[k] for k in ("euclid", "quartic", "logit2")) > 0.1 and worst["fisher"] < 1e-12 and \
        min(worst[k] for k in ("euclid", "quartic", "logit2")) > 0.05
    register("UX01", "Law-natural, relabeling-invariant structures are forced by the kernel and Gamma (rigidity Thm 2.2).",
             "False as stated (external attack, confirmed): every symmetric a(p) dp^2 on Bernoulli is law-natural, invariant "
             "and descends, with non-constant ratios to Fisher. Only a further selection principle -- invariance under Markov "
             "embeddings (H-mono) -- singles out Fisher (Cencov). Descent fixes M once mu is fixed; it does not select mu.",
             passed, dict(relabeling_symmetry_defect=sym, ratio_to_fisher_range=ratio_var, markov_embedding_change=
                          {k: f_(v) for k, v in worst.items()}), "FALSIFIED-naive")


def UX02_presentation(rng):
    """X_A = R, F = N(x,1); X_B = R x {0} union (0,inf) x {1}, F = N(x,1). A translation by a lifts iff it preserves
    fibre cardinality."""
    grid = np.linspace(-5, 5, 2001)
    cardA = lambda q: np.ones_like(q); cardB = lambda q: 1+(q > 0)
    lifts = {}
    for name, card in (("A", cardA), ("B", cardB)):
        ok = [a for a in np.linspace(-2, 2, 41) if np.all(card(grid) == card(grid+a))]
        lifts[name] = len(ok)
    passed = lifts["A"] == 41 and lifts["B"] == 1
    register("UX02", "The effective symmetry Gamma is a property of the observable experiment.",
             "It is the liftable symmetry of the SPECIFIED observation system: two presentations with the same law image "
             "(Gaussian location) have Gamma_A = (R,+) (41/41 tested translations lift) and Gamma_B = {e} (only a = 0), because "
             "lifts must preserve fibre cardinality. The latent presentation is an input (L0).", passed, dict(lifting_translations=lifts),
             "FALSIFIED-naive")


def UX03_pullback(rng):
    mu = np.diag([1.0, -1.0]); J = np.array([[1.0], [1.0]]); pull = float((J.T@mu@J)[0, 0])
    agree, n, nullcases = 0, 0, 0
    for _ in range(3000):
        m, d = 4, 2; S = rng.normal(size=(m, m)); mu = (S+S.T)/2
        if rng.random() < 0.3:                                    # force a null image direction
            w, U = np.linalg.eigh(mu); pos, neg = U[:, w > 0], U[:, w < 0]
            if pos.shape[1] and neg.shape[1]:
                a, b = pos[:, 0], neg[:, 0]; nv = a/math.sqrt(abs(a@mu@a))+b/math.sqrt(abs(b@mu@b))
                # a one-dimensional image along a null direction: restriction degenerate, ambient mu nondegenerate
                # (first version added a second generic direction, which made the 2x2 restriction nondegenerate: no test)
                J = nv[:, None]; nullcases += 1
            else: J = rng.normal(size=(m, d))
        else: J = rng.normal(size=(m, d))
        if MUT.get("ux03_ambient"):
            pred_full = np.linalg.matrix_rank(mu, tol=1e-9) == m                # old (wrong) criterion
        else:
            Qw, _ = np.linalg.qr(J); pred_full = abs(np.linalg.det(Qw.T@mu@Qw)) > 1e-9
        actual_full = np.linalg.matrix_rank(J.T@mu@J, tol=1e-9) == J.shape[1]
        agree += pred_full == actual_full; n += 1
    passed = pull == 0.0 and agree == n
    register("UX03", "A nondegenerate law-space tensor pulls back with radical exactly V (print, Thm natural descent (3)).",
             "False for indefinite tensors: mu = du^2 - dv^2 and F(t) = (t,t) give F*mu = 0 on an immersion. Correct criterion: "
             "mu restricted to the image tangent is nondegenerate (automatic for positive definite mu, so the Fisher branch is "
             "unaffected). The corrected criterion matches direct computation in 3000/3000 cases including forced null images.",
             passed, dict(counterexample_pullback=pull, criterion_agreement=f"{agree}/{n}", forced_null_cases=nullcases), "FALSIFIED-naive")


def UX04_panels(rng):
    # finite: exhaustive minimal existence for random tasks on 4 protocols
    ok = 0
    for _ in range(200):
        n_states, m = 6, 4; F = rng.integers(0, 2, (m, n_states)); T = rng.integers(0, 2, n_states)
        suff = []
        for r in range(m+1):
            for S in itertools.combinations(range(m), r):
                key = {}
                good = all(key.setdefault(tuple(F[list(S), x]), T[x]) == T[x] for x in range(n_states))
                if good: suff.append(set(S))
        if not suff: ok += 1; continue
        minimal = [S for S in suff if not any(R < S for R in suff)]
        ok += all(any(Mn <= S for Mn in minimal) for S in suff)
    # infinite prefix family: S sufficient iff unbounded; removing any index preserves unboundedness
    reps = {"evens": lambda k: k % 2 == 0, "multiples_of_3": lambda k: k % 3 == 0, "all": lambda k: True}
    removal_preserves = all(any(rep(k) and k > j for k in range(j+1, j+50)) for rep in reps.values() for j in range(30))
    passed = ok == 200 and removal_preserves
    register("UX04", "Every sufficient panel contains a minimal sufficient panel (print, selector theorem).",
             "Only for finite index sets (200/200 finite cases). For the prefix family on {0,1}^N with T = identity, the "
             "sufficient panels are exactly the infinite subsets, and removing any index keeps a panel sufficient: no minimal "
             "panel exists. The theorem now states finiteness; infinite families keep the upward-closed family as the object.",
             passed, dict(finite_cases_ok=f"{ok}/200", infinite_removal_preserves_sufficiency=bool(removal_preserves)), "FALSIFIED-naive")


def UX05_finite_kernel(rng):
    n, delta, reps = 10000, 1e-6, 400
    bound = n*abs(delta); rej = 0
    for _ in range(reps):
        a = rng.random(n) < 0.5; b = rng.random(n) < 0.5+delta
        z = (b.mean()-a.mean())/math.sqrt(0.5/n); rej += abs(z) > 1.96
    power = rej/reps
    passed = bound < 0.02 and power < 0.1
    register("UX05", "The kernel of a real experiment is established by its data.",
             "Exact law equality is not uniformly certifiable from finite samples: with delta = 1e-6 and n = 1e4 the two exact "
             "kernels differ, but TV <= n|delta| = 0.01 and a level-0.05 test rejects at the nominal rate. Exact-layer statements "
             "are conditional on the specified law map; data enter through confidence correspondences (L16, L46, L54).",
             passed, dict(tv_bound=f_(bound), empirical_power=f_(power)), "FALSIFIED-naive")


def UX06_monotonicity(rng):
    found = None
    for _ in range(2000):
        p = rng.dirichlet(np.ones(3)); q = rng.dirichlet(np.ones(3)); M = np.array([[1, 0], [1, 0], [0, 1.0]])
        e0 = np.linalg.norm(p-q); e1 = np.linalg.norm(M.T@p-M.T@q)
        if e1 > e0*1.05: found = (p, q, e0, e1); break     # max possible factor for one merge is sqrt(8/6) = 1.155
    p, q, e0, e1 = found
    def hell(a, b): return math.sqrt(max(0, 1-np.sum(np.sqrt(a*b))))
    h0, h1 = hell(p, q), hell(M.T@p, M.T@q)
    passed = found is not None and h1 <= h0+1e-12
    register("UX06", "Garbling enlarges the kernel (L4), hence distinguishability metrics contract.",
             "Kernel inclusion does not imply metric monotonicity: merging two outcomes enlarges the kernel yet increases the "
             "Euclidean distance (up to sqrt(8/6) = 1.155 for one merge), while Hellinger/Fisher contract. Monotonicity under Markov morphisms is a "
             "selection requirement (H-mono), satisfied by Fisher-type metrics, not a consequence of L4.", passed,
             dict(euclid_before=f_(e0), euclid_after=f_(e1), hellinger_before=f_(h0), hellinger_after=f_(h1)), "FALSIFIED-naive")


def UX07_non_omission(rng):
    # weaker hypothesis: uniform convergence without uniform modulus (bump of height eps, width eps^2)
    worst = 0.0; seps = []
    for eps in (1e-1, 1e-2, 1e-3):
        F = lambda x, e=eps: x + e*max(0.0, 1-abs(x-e)/e**2)
        # pairs identified at eps: (x, x') with F(x)=F(x'): the bump creates pairs near x = eps; their separation -> 0
        xs = np.linspace(eps-eps**2, eps+eps**2, 2001); ys = np.array([F(x) for x in xs])
        best = 0.0
        for i in range(0, len(xs), 50):
            j = np.argmin(np.abs(ys - ys[i]) + 10*(np.abs(xs-xs[i]) < 1e-15))
            if abs(ys[j]-ys[i]) < 1e-9: best = max(best, abs(xs[j]-xs[i]))
        worst = max(worst, best); seps.append(f_(best))
        lip = (eps/eps**2)
    passed = worst < 0.05 and lip > 100 and seps[0] >= seps[1] >= seps[2] and seps[2] < seps[0]
    register("UX07", "A countermodel to omitting a hypothesis shows the hypothesis is necessary.",
             "It shows non-omissibility only. Kernel upper semicontinuity already holds under the weaker hypothesis of local "
             "uniform convergence without any Lipschitz modulus (separation of identified pairs falls from 0.01 to 0 on the grid, while "
             "the slope grows to 1000). The modulus belongs to CERTIFICATION (sampling cannot see narrow bumps), not to the theorem: H-unif is "
             "split accordingly.", passed, dict(identified_separation_by_eps=seps, slope_at_eps_1em3=f_(lip)), "FALSIFIED-naive")


def UX08_set_vs_smooth(rng):
    # figure-eight immersion t in (0, 2pi) -> (sin 2t, sin t): injective, immersive, image not embedded (non-closed at origin)
    t = np.linspace(1e-3, 2*np.pi-1e-3, 200001); x, y = np.sin(2*t), np.sin(t)
    near_origin_ends = (abs(x[0]) < 1e-2 and abs(y[0]) < 1e-2 and abs(x[-1]) < 1e-2 and abs(y[-1]) < 1e-2)
    mid = np.argmin(np.abs(t-np.pi)); passes_origin = abs(x[mid]) < 1e-3 and abs(y[mid]) < 1e-3
    passed = near_origin_ends and passes_origin
    register("UX08", "The canonical quotient is a smooth space.",
             "Only under regularity: the figure-eight is an injective immersion whose image accumulates on itself at the origin "
             "(the curve passes through it at t = pi and approaches it at both ends). The set quotient is canonical; smooth and "
             "topological statements require H-reg (regular strata, closed embedded images).", passed,
             dict(ends_approach_origin=bool(near_origin_ends), passes_origin_at_pi=bool(passes_origin)), "FALSIFIED-naive")


def UX09_text_audit(rng, tex, rig):
    s = open(tex).read(); r = open(rig).read()
    checks = {
        "natural_descent_restricted_criterion": bool(re.search(r"restricted to .*?image|restriction of \$\\mu\$ to", s)),
        "selector_finite_index": "finite index set" in s,
        "gamma_liftable_scope": "liftable" in s and "presentation" in s,
        "naturality_not_selection_rung": "Naturality does not select" in s,
        "H_mono_defined": r"\h{H-mono}" in s,
        "exact_law_not_certifiable": "not uniformly certifiable" in s,
        "H_unif_split_theorem_vs_certificate": "certification" in s[s.index(r"\begin{hypothesis}[\h{H-unif}]"):s.index(r"\begin{hypothesis}[\h{H-unif}]")+900],
        "abstract_no_unconditional_forcing": "fix every law-defined structure" not in s,
        "rigidity_non_omissibility": "non-omissib" in r.lower(),
        "rigidity_no_finite_parameter_claim": "finite parameter fixed" not in r,
        "rigidity_naturality_vs_selection": "selection" in r and "Bernoulli" in r,
        "rigidity_displayed_proofs_scope": "displayed proofs" in r,
    }
    passed = all(checks.values())
    register("UX09", "The papers still contain the overclaims.",
             "Text audit of the repaired print edition and rigidity paper: every repaired statement is present and every "
             "withdrawn phrase is absent. The audit fails on the pre-repair versions.", passed, dict(checks=checks), "HOLDS")


ATTACKS = [UX01_naturality_not_selection, UX02_presentation, UX03_pullback, UX04_panels, UX05_finite_kernel, UX06_monotonicity,
           UX07_non_omission, UX08_set_vs_smooth]


def run_all(seed, tex, rig):
    for a in ATTACKS:
        rng = np.random.default_rng([seed, ATTACKS.index(a)])
        try: a(rng)
        except Exception as ex: register(a.__name__[:4], "?", f"EXCEPTION {ex!r}", False, {}, "ERROR")
    try: UX09_text_audit(None, tex, rig)
    except Exception as ex: register("UX09", "?", f"EXCEPTION {ex!r}", False, {}, "ERROR")


def canary(seed, tex, rig, old_tex, old_rig):
    ok = True
    RESULTS.clear(); MUT.clear(); MUT.update({"ux03_ambient": True}); print("--- canary UX03: ambient criterion")
    UX03_pullback(np.random.default_rng([seed, 2])); c = not RESULTS[-1]["passed"]; ok &= c; print(f"    {'CAUGHT' if c else 'NOT CAUGHT'}")
    MUT.clear(); RESULTS.clear(); print("--- canary UX09: pre-repair texts")
    UX09_text_audit(None, old_tex, old_rig); c = not RESULTS[-1]["passed"]; ok &= c; print(f"    {'CAUGHT' if c else 'NOT CAUGHT'}")
    print("CANARY:", "all caught" if ok else "BATTERY TOO WEAK"); return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--seed", type=int, default=20261022)
    ap.add_argument("--tex", default="RG.tex"); ap.add_argument("--rig", default="RG_-_Rigidity.tex")
    ap.add_argument("--old-tex", default="RG_old.tex"); ap.add_argument("--old-rig", default="RG_-_Rigidity_old.tex")
    ap.add_argument("--out", default="rg_undermine_ext_results.json"); ap.add_argument("--canary", action="store_true")
    a = ap.parse_args()
    if a.canary: sys.exit(canary(a.seed, a.tex, a.rig, a.old_tex, a.old_rig))
    t0 = time.time(); print(f"RG extended undermine battery, seed {a.seed}\n"); run_all(a.seed, a.tex, a.rig)
    n = sum(r["passed"] for r in RESULTS)
    json.dump(dict(summary=dict(seed=a.seed, n_checks=len(RESULTS), n_pass=n, runtime_s=round(time.time()-t0, 1)), results=RESULTS),
              open(a.out, "w"), indent=2, default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print(f"\n{n}/{len(RESULTS)} pass."); sys.exit(0 if n == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
