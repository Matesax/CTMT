#!/usr/bin/env python3
"""
RG residual characteristic geometry: hostile battery RX01-RX10
==============================================================
Every verdict is computed from sampled directions; no class label, component count or extreme-ray count
is supplied to any detector. Escalation (resolution, length) is part of every certificate.

  RX01 presentation invariance          RX06 window lemma (no absolute TAME/WILD from finite data)
  RX02 tame finiteness + Harnack bound  RX07 duality: smooth <-> dual strictly convex
  RX03 linear moduli (no finite GL)     RX08 dynamic cones: uniform vs nonuniform hyperbolicity
  RX04 Garding hyperbolic lock          RX09 typed certifier on held-out random instances
  RX05 sheet order + polarization Z2    RX10 Hadamard: residual characteristics => ill-posed growth

Run:  python3 rg_residual_cone_attack.py [--seed 20261001] [--out FILE] [--canary]
"""
import argparse, json, math, sys, time
import numpy as np
from scipy import ndimage, optimize

RESULTS, MUT = [], {}
TWO_PI = 2*np.pi


def f(x): return float(np.round(float(x), 12))


def _finite(o):
    if isinstance(o, dict): return all(_finite(v) for v in o.values())
    if isinstance(o, (list, tuple)): return all(_finite(v) for v in o)
    if isinstance(o, float): return math.isfinite(o)
    return True


def register(aid, target, naive, keep, passed, ev, verdict):
    if not _finite(ev): passed, verdict = False, "NONFINITE"
    RESULTS.append(dict(id=aid, target=target, naive_claim=naive, rg_claim=keep, passed=bool(passed),
                        verdict=verdict, evidence=ev))
    print(f"[{'PASS' if passed else 'FAIL'}] {aid} {verdict:16s} {keep[:82]}")


# ------------------------------------------------------------------ homogeneous polynomials in R^3
def monomials(d):
    return [(i, j, d-i-j) for i in range(d+1) for j in range(d+1-i)]


def poly_eval(coef, mons, V):
    t, x, y = V[..., 0], V[..., 1], V[..., 2]
    out = np.zeros(V.shape[:-1])
    for c, (a, b, e) in zip(coef, mons): out += c*t**a*x**b*y**e
    return out


def kostlan(d, rng):
    mons = monomials(d)
    w = [math.sqrt(math.factorial(d)/(math.factorial(a)*math.factorial(b)*math.factorial(e))) for a, b, e in mons]
    return rng.normal(size=len(mons))*np.array(w), mons


def rand_rot(rng):
    Q, R = np.linalg.qr(rng.normal(size=(3, 3))); Q = Q*np.sign(np.diag(R)); return Q if np.linalg.det(Q) > 0 else -Q


def sphere_zero_components(fun, nth, rng):
    """components of {fun=0} on S^2 from a lat-long grid; poles rotated away from the zero set; the
    longitude seam is glued by union-find."""
    best, Rbest = -1, np.eye(3)
    for _ in range(30):
        R = rand_rot(rng); pz = np.array([[0, 0, 1.0], [0, 0, -1.0]]) @ R.T
        v = np.min(np.abs(fun(pz)))
        if v > best: best, Rbest = v, R
    th = (np.arange(nth)+0.5)/nth*np.pi; ph = np.arange(2*nth)/(2*nth)*TWO_PI
    T, P = np.meshgrid(th, ph, indexing="ij")
    V = np.stack([np.sin(T)*np.cos(P), np.sin(T)*np.sin(P), np.cos(T)], -1) @ Rbest.T
    s = np.sign(fun(V))
    sr = np.concatenate([s, s[:, :1]], 1)                       # periodic in longitude
    c = sr[:-1, :-1]; mask = (c != sr[1:, :-1]) | (c != sr[:-1, 1:]) | (c != sr[1:, 1:])
    lab, n = ndimage.label(mask, structure=np.ones((3, 3)))
    parent = list(range(n+1))
    def find(a):
        while parent[a] != a: parent[a] = parent[parent[a]]; a = parent[a]
        return a
    for i in range(lab.shape[0]):
        for di in (-1, 0, 1):
            k = i+di
            if 0 <= k < lab.shape[0] and lab[i, -1] and lab[k, 0]:
                parent[find(lab[i, -1])] = find(lab[k, 0])
    return len({find(a) for a in range(1, n+1)})


# ======================================================================= checks
def RX01_presentation(rng):
    """sign(phi(g p)) = sign(p) for positive g and strictly increasing odd phi: the projective
    characteristic set and its sign sectors are presentation invariant; degree and factorization are not."""
    worst = 0
    for _ in range(40):
        c, m = kostlan(4, rng); V = rng.normal(size=(20000, 3)); p = poly_eval(c, m, V)
        L = rng.normal(size=(3, 3)); g = 0.2 + np.sum((V @ L.T)**2, 1)/np.sum(V**2, 1)
        for phi in (np.sinh, lambda z: z**3, lambda z: np.arctan(5*z)):
            worst = max(worst, int(np.sum(np.sign(phi(g*p)) != np.sign(p))))
    deg_change = 4*3                                          # degree of p^3 g with g degree 0: presentation not invariant
    passed = worst == 0
    register("RX01", "typing", "The degree or factor structure of the defining function types the cone.",
             "Only the projective set and sign sectors are invariant; positive factors and monotone maps change "
             "degree and factorization without changing the characteristic object.",
             passed, dict(sign_mismatches=worst, example_degree_after_cubing=deg_change), "HOLDS")


def RX02_tame_harnack(rng):
    """Semialgebraic (tame) characteristic sets: zero sets of random quartics on RP^2. Oval counts are
    finite, stabilize under resolution escalation, and never exceed Harnack's bound (d-1)(d-2)/2+1 = 4."""
    counts = []
    for _ in range(MUT.get("rx02_n", 40)):
        c, m = kostlan(4, rng); fun = lambda V, c=c, m=m: poly_eval(c, m, V)
        row = [sphere_zero_components(fun, nth, np.random.default_rng(int(rng.integers(1 << 30)))) // 2 for nth in (96, 192, 384)]
        counts.append(row)
    counts = np.array(counts)
    stable = float(np.mean(counts[:, 1] == counts[:, 2]))
    mx = int(counts[:, 2].max())
    hist = {str(k): int(np.sum(counts[:, 2] == k)) for k in range(0, 6)}
    passed = stable >= 0.95 and mx <= 4 and counts[:, 2].mean() > 0
    register("RX02", "tame", "Residual characteristic sets may have arbitrarily many sheets at any degree.",
             "Tame (semialgebraic) characteristic sets have finitely many sheets, stable under resolution, bounded "
             "by Harnack: a quartic has at most 4 ovals. Observed counts never exceed the bound.",
             passed, dict(stable_fraction_top_resolutions=f(stable), max_ovals=mx, oval_histogram=hist), "HOLDS")


def RX03_linear_moduli(rng):
    """Polyhedral cones with five extreme rays: projective invariants of the five rays are continuous moduli.
    Same topological type (convex pentagon section), infinitely many GL(3)-classes."""
    def inv(P):          # P: 5x3 homogeneous rays; two independent projective invariants
        d = lambda i, j, k: np.linalg.det(P[[i, j, k]])
        return np.array([d(0, 1, 2)*d(0, 3, 4)/(d(0, 1, 3)*d(0, 2, 4)), d(1, 0, 2)*d(1, 3, 4)/(d(1, 0, 3)*d(1, 2, 4))])
    def pentagon(rng):
        a = np.sort(rng.uniform(0, TWO_PI, 5));
        while np.max(np.diff(np.r_[a, a[0]+TWO_PI])) > np.pi*0.9: a = np.sort(rng.uniform(0, TWO_PI, 5))
        while True:
            r = rng.uniform(0.7, 1.3, 5); P = np.c_[np.ones(5), r*np.cos(a), r*np.sin(a)]
            from scipy.spatial import ConvexHull
            if len(ConvexHull(P[:, 1:]).vertices) == 5: return P
    P1, P2 = pentagon(rng), pentagon(rng)
    G = rng.normal(size=(3, 3)); lam = rng.uniform(0.5, 2, 5)
    inv_err = float(np.max(np.abs(inv((P1 @ G.T)*lam[:, None])-inv(P1))))
    gap = float(np.max(np.abs(inv(P1)-inv(P2))))
    # one-parameter family inside convex position: push one ray radially; moduli move continuously and
    # monotonically (a straight-line path between two cones can leave convex position: first registration)
    from scipy.spatial import ConvexHull
    delta = 0.15
    while True:                                   # largest push (halving) that keeps the whole path convex
        fam = []
        for sv in np.linspace(0, 1, 41):
            P = P1.copy(); P[4, 1:] *= 1+delta*sv; fam.append(P)
        convex_along = all(len(ConvexHull(P[:, 1:]).vertices) == 5 for P in fam)
        if convex_along or delta < 1e-3: break
        delta /= 2
    I = np.array([inv(P) for P in fam]); steps = np.abs(np.diff(I, axis=0)).max(1)
    total = float(np.abs(I[-1]-I[0]).max()); cont = float(steps.max())
    mono = bool(np.all(np.diff(I[:, 0]) > 0) or np.all(np.diff(I[:, 0]) < 0) or np.all(np.diff(I[:, 1]) > 0) or np.all(np.diff(I[:, 1]) < 0))
    hv = [len(ConvexHull(P[:, 1:]).vertices) for P in (P1, P2)]
    passed = inv_err < 1e-9 and gap > 1e-2 and hv == [5, 5] and convex_along and mono and cont < 0.1*total
    register("RX03", "moduli", "Residual cones can be finitely classified up to linear equivalence.",
             "No: already polyhedral cones with five extreme rays carry continuous projective moduli. Finite "
             "classification exists only up to stratified homeomorphism (topological type).",
             passed, dict(invariance_error_under_GL3=f(inv_err), invariant_gap_two_cones=f(gap),
                          family_total_change=f(total), family_max_step=f(cont), family_monotone=mono,
                          family_convex=convex_along, hull_vertices=hv), "HOLDS")


def lin_forms(k, rng, e):
    L = rng.normal(size=(k, len(e)))
    L[L @ e < 0] *= -1; L += 0.3*np.outer(np.ones(k), e)/np.dot(e, e)  # positive at e
    return L


def renegar_poly(L, e, nder):
    """q = D_e^nder prod_i <l_i, v>, evaluated via univariate expansion along e."""
    def q(V):
        # p(V + s e) as polynomial in s; take the nder-th s-derivative at s=0
        A = V @ L.T; b = L @ e                   # A: (...,k)
        coeffs = np.ones(A.shape[:-1]+(1,))
        for i in range(L.shape[0]):
            c = np.zeros(coeffs.shape[:-1]+(coeffs.shape[-1]+1,))
            c[..., :-1] += coeffs*A[..., i:i+1]; c[..., 1:] += coeffs*b[i]
            coeffs = c
        return coeffs[..., nder]*math.factorial(nder)
    return q


def roots_along(q, v, e, deg):
    s = np.linspace(-3, 3, deg+1)*max(1, np.linalg.norm(v))
    vals = np.array([q((v - si*e)[None])[0] for si in s])
    return np.roots(np.polyfit(s, vals, deg))


def RX04_garding(rng):
    """Garding: hyperbolic polynomials have convex hyperbolicity cones; Renegar derivatives stay hyperbolic
    with nested, larger cones. Tested on D_e^j of products of linear forms in R^4 (curved, non-polyhedral)."""
    e = np.array([1.0, 0, 0, 0]); L = lin_forms(6, rng, e)
    qs = {j: renegar_poly(L, e, j) for j in (0, 1, 2)}
    degs = {0: 6, 1: 5, 2: 4}
    complex_frac = {}
    for j in (1, 2):
        cnt = 0
        for _ in range(400):
            w = rng.normal(size=4); r = roots_along(qs[j], w, e, degs[j])
            cnt += np.max(np.abs(r.imag)) > 1e-6*max(1, np.max(np.abs(r)))
        complex_frac[str(j)] = cnt/400
    def member(j, v):
        r = roots_along(qs[j], v, e, degs[j]); return bool(np.all(r.real > 0) and np.max(np.abs(r.imag)) < 1e-6*max(1, np.max(np.abs(r))))
    pts = {j: [] for j in (0, 1, 2)}; tries = 0
    while min(len(p) for p in pts.values()) < 150 and tries < 20000:
        v = e + rng.normal(size=4)*rng.uniform(0.2, 3); tries += 1
        for j in (0, 1, 2):
            if len(pts[j]) < 150 and member(j, v): pts[j].append(v)
    conv_viol = {}
    for j in (1, 2):
        P = np.array(pts[j]); bad = 0
        for _ in range(300):
            a, b = P[rng.integers(0, len(P), 2)]; bad += not member(j, 0.5*(a+b))
        conv_viol[str(j)] = bad
    nest = sum(1 for v in pts[0] if not member(1, v)) + sum(1 for v in pts[1] if not member(2, v))
    passed = all(v == 0 for v in complex_frac.values()) and all(v == 0 for v in conv_viol.values()) and nest == 0
    register("RX04", "hyperbolic lock", "Characteristic cones of physical propagation can be nonconvex.",
             "Not for well-posed propagation: hyperbolic principal symbols (Garding) have real roots on every line "
             "through e and convex hyperbolicity cones; Renegar derivatives remain hyperbolic with nested cones.",
             passed, dict(complex_root_fraction=complex_frac, midpoint_violations=conv_viol, nesting_violations=nest,
                          members_sampled={str(k): len(v) for k, v in pts.items()}), "HOLDS")


def RX05_sheet_order(rng):
    """Hyperbolic (real-root) sheets are ordered: no label monodromy around any loop. Polarization
    (eigenvector) data at a conical point of a symmetric pencil t I + x A + y B + z C carries Z2 holonomy.
    Label exchange requires complex roots (non-hyperbolic)."""
    A, B, Cm = [(lambda M: (M+M.T)/2)(rng.normal(size=(3, 3))) for _ in range(3)]
    def gap(u):
        u = u/np.linalg.norm(u); w = np.linalg.eigvalsh(u[0]*A+u[1]*B+u[2]*Cm); return min(w[1]-w[0], w[2]-w[1])
    best = None
    for _ in range(400):
        u0 = rng.normal(size=3); r = optimize.minimize(gap, u0, method="Nelder-Mead", options=dict(xatol=1e-12, fatol=1e-14, maxiter=4000))
        if best is None or r.fun < best.fun: best = r
    c = best.x/np.linalg.norm(best.x)
    M0 = c[0]*A+c[1]*B+c[2]*Cm; w0 = np.linalg.eigvalsh(M0); k = int(np.argmin(np.diff(w0)))
    e1 = np.cross(c, rng.normal(size=3)); e1 /= np.linalg.norm(e1); e2 = np.cross(c, e1)
    eps = 1e-3; prev = None; first = None; mingap = np.inf; perm_ok = True
    for th in np.linspace(0, TWO_PI, 721):
        u = c + eps*(np.cos(th)*e1+np.sin(th)*e2); u /= np.linalg.norm(u)
        w, V = np.linalg.eigh(u[0]*A+u[1]*B+u[2]*Cm); v = V[:, k]
        mingap = min(mingap, w[k+1]-w[k])
        if prev is not None and np.dot(v, prev) < 0: v = -v
        if first is None: first = v
        prev = v
    holonomy = float(np.dot(prev, first))
    # non-hyperbolic real polynomial with roots i +- s, -i +- conj(s), s^2 = (x+iy)/4: transposition
    def roots(z):
        s = np.sqrt(z/4+0j); return np.array([1j+s, 1j-s, -1j+np.conj(s), -1j-np.conj(s)])
    tr = roots(1e-2); cur = tr.copy()
    for th in np.linspace(0, TWO_PI, 2001)[1:]:
        new = roots(1e-2*np.exp(1j*th))
        cur = np.array([new[np.argmin(np.abs(new-ci))] for ci in cur])
    perm = [int(np.argmin(np.abs(tr-ci))) for ci in cur]
    # real coefficients force monodromy to commute with conjugation (roots 0,1 conjugate to 2,3); the first
    # registration expected the single transposition [1,0,2,3] and was wrong: both pairs exchange together
    conj_eq = perm == [1, 0, 3, 2]
    passed = best.fun < 1e-6 and mingap > 0 and abs(holonomy+1) < 1e-6 and conj_eq
    register("RX05", "monodromy", "Sheets of characteristic cones can exchange labels (branch monodromy).",
             "Not in the hyperbolic class: real roots are ordered, so sheet labels have trivial monodromy. The "
             "invariant monodromy lives in polarization data: Z2 holonomy around a conical point. Label "
             "exchange occurs only for complex (non-hyperbolic) roots.",
             passed, dict(conical_point_gap=f(best.fun), loop_min_gap=f(mingap), polarization_holonomy=f(holonomy),
                          nonhyperbolic_root_permutation=perm), "HOLDS")


# ------------------------------------------------------------------ angular sets (projective circle)
def norm_intervals(I):
    """sorted, merged closed intervals on the circle [0, 2pi)."""
    I = np.array([[a % TWO_PI, a % TWO_PI + max(w, 0)] for a, w in I]) if len(I) else np.zeros((0, 2))
    out = []
    for a0, a1 in I:
        if a1 > TWO_PI: out += [[a0, TWO_PI], [0.0, a1-TWO_PI]]
        else: out.append([a0, a1])
    out = sorted(out); merged = []
    for a0, a1 in out:
        if merged and a0 <= merged[-1][1]: merged[-1][1] = max(merged[-1][1], a1)
        else: merged.append([a0, a1])
    return np.array(merged)


def arcs_set(centers, widths):
    return norm_intervals([(c-w/2, w) for c, w in zip(centers, widths)])


def cantor_set(a, L, depth=18):
    lefts = np.array([0.0]); length = 1.0
    for _ in range(depth):
        length /= 3; lefts = np.concatenate([lefts, lefts+2*length])
    return norm_intervals([(a+L*x, L*length) for x in np.sort(lefts)])


def accumulation_set(a, c, w, jmax=200000):
    j = np.arange(2, jmax); return arcs_set(a+c/j, w/j**2)


def eps_components(I, eps):
    """number of components of the eps/2-thickening: circular gaps wider than eps separate components."""
    if len(I) == 0: return 0
    gaps = np.r_[I[1:, 0]-I[:-1, 1], I[0, 0]+TWO_PI-I[-1, 1]]
    k = int(np.sum(gaps > eps)); return max(k, 1)


def arc_counts(I, levels):
    return [eps_components(I, TWO_PI/2**k) for k in levels]


def arc_certificate(counts):
    c = np.array(counts, float)
    if len(c) >= 3 and c[-1] == c[-2] == c[-3]: return "STABLE"
    sl = np.diff(np.log(np.maximum(c, 1)))/math.log(4)          # levels step by factor 4 in resolution
    if len(c) >= 4 and np.all(sl[-3:] > 0.15): return "GROWTH"
    return "ABSTAIN"


def RX06_window_lemma(rng):
    """A tame set with fine components shows growth on a coarse window and stabilizes later; a set that is wild
    only below a scale is stable on every window above it. Certificates are window-indexed; neither TAME nor
    WILD is absolute from finite resolution."""
    # tame: one cluster of 30 fine arcs whose gaps are log-uniform in [2e-6, 1e-3]; finitely many components
    gaps = np.exp(rng.uniform(np.log(2e-6), np.log(1e-3), 29)); w = 1e-6
    starts = 1.0 + np.r_[0, np.cumsum(gaps + w)]
    tame = norm_intervals([(a, w) for a in starts] + [(3.0, 0.6), (5.0, 0.4)])
    wild_late = np.r_[arcs_set([3.0], [0.8]), cantor_set(5.0, 1e-5)]
    wild_late = wild_late[np.argsort(wild_late[:, 0])]
    w0 = MUT.get("rx06_same_window")
    win = dict(tame_coarse=[12, 14, 16, 18], tame_full=[12, 14, 16, 18, 20, 22, 24, 26] if not w0 else [12, 14, 16, 18],
               wildlate_window=[12, 14, 16, 18, 20], wildlate_deep=[12, 14, 16, 18, 20, 22, 24, 26] if not w0 else [12, 14, 16, 18, 20])
    counts = dict(tame_coarse=arc_counts(tame, win["tame_coarse"]), tame_full=arc_counts(tame, win["tame_full"]),
                  wildlate_window=arc_counts(wild_late, win["wildlate_window"]),
                  wildlate_deep=arc_counts(wild_late, win["wildlate_deep"]))
    certs = {k: arc_certificate(v) for k, v in counts.items()}
    passed = (certs["tame_coarse"] == "GROWTH" and certs["tame_full"] == "STABLE" and
              certs["wildlate_window"] == "STABLE" and certs["wildlate_deep"] == "GROWTH")
    register("RX06", "wild", "Finite-resolution data can certify that a characteristic set is tame (or wild).",
             "No: a tame set shows growth on a coarse window and stabilizes later; a set wild only below a scale is "
             "stable on every window above it. Certificates are statements about their window only.",
             passed, dict(certificates=certs, counts=counts), "FALSIFIED-naive")


# ------------------------------------------------------------------ radial sections (single sheet)
def rho_quad(rng):
    Q, _ = np.linalg.qr(rng.normal(size=(2, 2))); M = Q @ np.diag(rng.uniform(0.5, 2.0, 2)) @ Q.T
    return lambda th: 1/np.sqrt(M[0, 0]*np.cos(th)**2+2*M[0, 1]*np.cos(th)*np.sin(th)+M[1, 1]*np.sin(th)**2)


def rho_from_support(h, hp):
    """radial function of the convex body with support function h (exact, Newton inversion)."""
    def X(phi):
        u = np.stack([np.cos(phi), np.sin(phi)], -1); up = np.stack([-np.sin(phi), np.cos(phi)], -1)
        return h(phi)[:, None]*u + hp(phi)[:, None]*up
    def rho(th):
        phi = th.copy()
        for _ in range(30):
            P = X(phi); ang = np.arctan2(P[:, 1], P[:, 0])
            d = (ang-th+np.pi) % TWO_PI - np.pi
            hpp = (h(phi+1e-5)-2*h(phi)+h(phi-1e-5))/1e-10
            dth = h(phi)*(h(phi)+hpp)/np.sum(P**2, 1)
            phi = phi - d/dth
        return np.linalg.norm(X(phi), axis=1)
    return rho


def rho_finsler(rng):
    a, b = rng.uniform(0.02, 0.06), rng.uniform(0.02, 0.08); p0, p1 = rng.uniform(0, TWO_PI, 2)
    h = lambda p: 1 + a*np.cos(3*p+p0) + b*np.cos(2*p+p1)
    hp = lambda p: -3*a*np.sin(3*p+p0) - 2*b*np.sin(2*p+p1)
    return rho_from_support(h, hp)


def rho_poly(rng):
    k = int(rng.integers(4, 9))
    while True:
        ang = np.sort(rng.uniform(0, TWO_PI, k)); gaps = np.diff(np.r_[ang, ang[0]+TWO_PI])
        if gaps.max() < 0.8*np.pi and gaps.min() > 0.25: break
    V = np.c_[np.cos(ang), np.sin(ang)]*rng.uniform(0.7, 1.3, k)[:, None]
    from scipy.spatial import ConvexHull
    hull = ConvexHull(V); eq = hull.equations                  # n.x + off <= 0
    n, d = eq[:, :2], -eq[:, 2]
    def rho(th):
        u = np.stack([np.cos(th), np.sin(th)], -1); nu = u @ n.T
        with np.errstate(divide="ignore"):
            r = np.where(nu > 1e-12, d[None, :]/nu, np.inf)
        return r.min(1)
    return rho


def rho_rounded(rng):
    """polygon Minkowski-summed with a disk of radius 1e-3: C^{1,1}, convex, flat faces, rounded corners
    below coarse grid scale. Radial function by vectorized bisection on dist(t u, P) = r_c."""
    rc = 1e-3
    k = int(rng.integers(4, 8))
    while True:
        ang = np.sort(rng.uniform(0, TWO_PI, k)); g = np.diff(np.r_[ang, ang[0]+TWO_PI])
        if g.max() < 0.8*np.pi and g.min() > 0.3: break
    from scipy.spatial import ConvexHull
    V = np.c_[np.cos(ang), np.sin(ang)]*rng.uniform(0.7, 1.3, k)[:, None]; V = V[ConvexHull(V).vertices]
    A, B = V, np.roll(V, -1, 0)
    def dist(X):
        AB = B-A; t = np.clip(np.einsum("nkd,kd->nk", X[:, None, :]-A[None], AB)/np.sum(AB**2, 1), 0, 1)
        Pr = A[None]+t[..., None]*AB[None]; return np.sqrt(np.sum((X[:, None, :]-Pr)**2, -1)).min(1)
    def rho(th):
        u = np.stack([np.cos(th), np.sin(th)], -1); lo = np.zeros(len(th)); hi = np.full(len(th), 3.0)
        for _ in range(60):
            mid = (lo+hi)/2; inside = dist(mid[:, None]*u) <= rc
            # inside the polygon dist = 0 (segments are boundary): use winding via support test instead
            lo = np.where(inside | inner(mid[:, None]*u), mid, lo); hi = np.where(inside | inner(mid[:, None]*u), hi, mid)
        return lo
    eq = ConvexHull(V).equations
    def inner(X): return np.all(X @ eq[:, :2].T + eq[:, 2] <= 0, axis=1)
    return rho


def rho_nonconvex(rng):
    k = int(rng.integers(3, 6)); a = rng.uniform(1.6, 3.0)/(1+k*k); p0 = rng.uniform(0, TWO_PI)
    b = rng.uniform(0, 0.02)
    return lambda th: 1 + a*np.cos(k*th+p0) + b*np.cos(2*th)


def radial_features(rho, levels=(9, 11, 13)):
    feats = []
    for lv in levels:
        n = 2**lv; th = np.arange(n)*TWO_PI/n; hh = TWO_PI/n; r = rho(th)
        d = (np.roll(r, -1)-r)/hh                                # forward differences
        jump = np.abs(d-np.roll(d, 1))
        rp = (np.roll(r, -1)-np.roll(r, 1))/(2*hh); rpp = (np.roll(r, -1)-2*r+np.roll(r, 1))/hh**2
        kap = (r*r+2*rp*rp-r*rpp)/np.mean(r)**2
        X = np.c_[np.cos(th)**2, 2*np.cos(th)*np.sin(th), np.sin(th)**2]; y = 1/r**2
        beta = np.linalg.lstsq(X, y, rcond=None)[0]; qres = np.sqrt(np.mean((X @ beta-y)**2))/np.mean(y)
        feats.append(dict(jump=float(jump.max()/np.mean(np.abs(d)+1e-12)), kap=kap, qres=float(qres), n=n))
    return feats


def radial_certificate(rho, single=False):
    """corner test with an undecided band and adaptive escalation: ratio of the finest to the coarsest
    maximal derivative jump >= 0.7 -> corner, <= 0.35 -> smooth; otherwise escalate once to 2^17 and
    abstain if still undecided. (A single 0.5 threshold misread 6/25 rounded polygons on seed 777; a one-step corner lock still
    misread 2/25; a corner must survive two escalations, 2^15 and 2^17.)"""
    if single:
        F = radial_features(rho, levels=(11,)); last = F[-1]; corner = last["jump"] > 0.05
    else:
        F = radial_features(rho, levels=(9, 12, 15)); last = F[-1]
        ratio = F[-1]["jump"]/F[0]["jump"]
        if ratio > 0.35:                                   # corner candidate or undecided: escalate again
            F = F + radial_features(rho, levels=(17,)); last = F[-1]; r2 = F[-1]["jump"]/F[0]["jump"]
            if ratio >= 0.7 and r2 >= 0.7: corner = last["jump"] > 0.05          # survives two escalations
            elif r2 <= 0.35: corner = False
            else: return "ABSTAIN"
        else:
            corner = False
    kap = last["kap"]
    if corner:
        # exclude corner spikes; flat faces have kappa ~ 0
        body = kap[np.abs(kap) < 50]
        return "CORNERED-CONVEX" if body.min() > -1e-3 else "NONCONVEX"
    if last["qres"] < 1e-6 and (single or F[-2]["qres"] < 1e-6): return "QUADRATIC"
    if kap.min() > 0.05: return "FINSLER"
    if kap.min() < -0.05: return "NONCONVEX"
    if np.mean(np.abs(kap) < 1e-3) > 0.05: return "WEAKLY-CONVEX"     # smooth, convex, flat faces
    return "ABSTAIN"


def RX07_duality(rng):
    """Smoothness of a closed convex cone <=> strict convexity of its dual (and vice versa). Stadium section:
    flat edges, no corners; its polar: corners, no flats. Corners are certified by non-decaying derivative
    jumps under escalation; flats by zero curvature on positive measure."""
    R, Lh = 0.6, 0.5
    def h_st(p): return R + Lh*np.abs(np.cos(p))                  # support of [-L,L]x{0} + disk(R)
    def rho_stadium(th):                                          # exact radial function of the stadium
        u = np.stack([np.cos(th), np.sin(th)], -1); res = []
        for ux, uy in u:
            # solve for smallest t>0 with dist((t ux, t uy), segment) = R
            g = lambda t: math.hypot(max(abs(t*ux)-Lh, 0), t*uy) - R
            res.append(optimize.brentq(g, 1e-9, 5))
        return np.array(res)
    rho_polar_st = lambda th: 1/h_st(th)                          # radial function of the polar body
    sq = rho_poly(np.random.default_rng(3)); sq_h = None
    def flats(rho, n=2**12):
        th = np.arange(n)*TWO_PI/n; hh = TWO_PI/n; r = rho(th)
        rp = (np.roll(r, -1)-np.roll(r, 1))/(2*hh); rpp = (np.roll(r, -1)-2*r+np.roll(r, 1))/hh**2
        kap = (r*r+2*rp*rp-r*rpp)/np.mean(r)**2
        return float(np.mean(np.abs(kap) < 1e-3))
    def corners(rho):
        F = radial_features(rho, levels=(9, 11, 13)); return bool(F[-1]["jump"] > 0.5*F[0]["jump"] and F[-1]["jump"] > 0.05)
    out = dict(stadium=dict(corners=corners(rho_stadium), flat_fraction=f(flats(rho_stadium))),
               stadium_polar=dict(corners=corners(rho_polar_st), flat_fraction=f(flats(rho_polar_st))),
               ellipse=dict(corners=corners(rho_quad(rng)), flat_fraction=f(flats(rho_quad(rng)))))
    passed = (not out["stadium"]["corners"] and out["stadium"]["flat_fraction"] > 0.05 and
              out["stadium_polar"]["corners"] and out["stadium_polar"]["flat_fraction"] < 0.01 and
              not out["ellipse"]["corners"] and out["ellipse"]["flat_fraction"] < 0.01)
    register("RX07", "duality", "Primal and dual certificates are independent axes.",
             "They are coupled by a theorem: a closed convex cone is smooth iff its dual is strictly convex. Flats of "
             "the stadium become corners of its polar. A Finsler realization needs smooth AND strictly convex, "
             "i.e. both the primal and the dual pass.",
             passed, out, "HOLDS")


def RX08_dynamic_cones(rng):
    """Chaotic cone processes. Cat map: constant splitting, uniform cone field (angle constant). Henon
    (1.4, 0.3): the minimal stable/unstable angle along the orbit decreases under length escalation
    (tangencies): no uniform cone field, nonuniform hyperbolicity."""
    def angles_henon(N, a=1.4, b=0.3):
        x, y = 0.1, 0.1
        for _ in range(1000): x, y = 1-a*x*x+y, b*x
        X = np.empty((N, 2))
        for n in range(N): X[n] = (x, y); x, y = 1-a*x*x+y, b*x
        U = np.empty((N, 2)); u = np.array([1.0, 0.3])
        for n in range(N):
            J = np.array([[-2*a*X[n, 0], 1.0], [b, 0.0]]); U[n] = u; u = J @ u; u /= np.linalg.norm(u)
        S = np.empty((N, 2)); s = np.array([0.2, 1.0])
        for n in range(N-1, -1, -1):
            J = np.array([[-2*a*X[n, 0], 1.0], [b, 0.0]]); s = np.linalg.solve(J, s); s /= np.linalg.norm(s); S[n] = s
        k = 60
        cosang = np.abs(np.sum(U[k:N-k]*S[k:N-k], 1))
        return float(np.degrees(np.arccos(np.clip(cosang, 0, 1))).min())
    A = np.array([[2.0, 1.0], [1.0, 1.0]]); w, V = np.linalg.eigh(A)
    cat_angle = float(np.degrees(np.arccos(abs(V[:, 0] @ V[:, 1]))))
    Ns = (20000, 20000, 20000) if MUT.get("rx08_single") else (2000, 20000, 200000)
    hen = {f"{i}:{N}": f(angles_henon(N)) for i, N in enumerate(Ns)}
    vals = list(hen.values())
    passed = abs(cat_angle-90.0) < 1e-9 and vals[0] > vals[1] > vals[2] and vals[2] < 2.0
    register("RX08", "dynamic cones", "A chaotic system has a well-defined global characteristic cone field.",
             "Only under uniform hyperbolicity (cone-field criterion). For Henon the minimal splitting angle "
             "shrinks under length escalation; the certificate is NONUNIFORM, and cones exist only on typed "
             "windows away from tangencies.",
             passed, dict(cat_map_splitting_angle_deg=f(cat_angle), henon_min_angle_deg_by_N=hen), "FALSIFIED-naive")


def RX09_certifier(rng):
    """Typed certifier on held-out random instances of seven classes (none of the parameters is seen by the
    certifier). Radial classes: QUADRATIC, FINSLER, CORNERED-CONVEX, NONCONVEX. Angular classes: MULTICONE
    (finite arcs), TAME-FINE (finite but fine arcs: must be STABLE on the full window), WILD (Cantor and
    accumulation). Wrong-type certificates must be rare; abstention is allowed."""
    n_per = MUT.get("rx09_n", 25)
    single = MUT.get("rx09_single", False)
    lv = MUT.get("rx09_levels", [10, 12, 14, 16, 18, 20, 22, 24])
    rad_gen = dict(QUADRATIC=rho_quad, FINSLER=rho_finsler, **{"CORNERED-CONVEX": rho_poly}, NONCONVEX=rho_nonconvex,
                   **{"WEAKLY-CONVEX": rho_rounded})
    conf, wrong, abst, total = {}, 0, 0, 0
    for lab, g in rad_gen.items():
        for _ in range(n_per):
            c = radial_certificate(g(rng), single=single); conf.setdefault(lab, {}).setdefault(c, 0); conf[lab][c] += 1
            total += 1; wrong += (c != lab and c != "ABSTAIN"); abst += c == "ABSTAIN"
    def multicone(rng):
        k = int(rng.integers(2, 7)); cs = np.sort(rng.uniform(0, TWO_PI, k))
        while np.min(np.diff(np.r_[cs, cs[0]+TWO_PI])) < 0.5: cs = np.sort(rng.uniform(0, TWO_PI, k))
        return arcs_set(cs, rng.uniform(0.05, 0.4, k))
    def tamefine(rng):
        m = int(rng.integers(15, 30)); return arcs_set(np.r_[[0.5, 2.5, 4.5], rng.uniform(0, TWO_PI, m)],
                                                      np.r_[[0.6, 0.5, 0.4], rng.uniform(2e-5, 5e-5, m)])
    def wild(rng):
        return cantor_set(rng.uniform(0, TWO_PI), rng.uniform(0.5, 2)) if rng.random() < 0.5 else \
            accumulation_set(rng.uniform(0, TWO_PI), rng.uniform(0.5, 1.5), rng.uniform(0.02, 0.08))
    truth = dict(MULTICONE="STABLE", **{"TAME-FINE": "STABLE"}, WILD="GROWTH")
    for lab, g in dict(MULTICONE=multicone, **{"TAME-FINE": tamefine}, WILD=wild).items():
        for _ in range(n_per):
            c = arc_certificate(arc_counts(g(rng), lv)); conf.setdefault(lab, {}).setdefault(c, 0); conf[lab][c] += 1
            total += 1; wrong += (c != truth[lab] and c != "ABSTAIN"); abst += c == "ABSTAIN"
    acc = 1 - (wrong+abst)/total
    passed = wrong/total <= 0.02 and acc >= 0.9
    register("RX09", "certifier", "A property-vector classifier separates the residual classes (RC10).",
             "Verified on held-out random instances with no label information: escalation-based features give "
             "wrong-type rate <= 2% and accuracy >= 90%; single-resolution features or a truncated window fail.",
             passed, dict(confusion=conf, wrong_rate=f(wrong/total), abstain_rate=f(abst/total), accuracy=f(acc),
                          instances=total), "HOLDS")


def RX10_hadamard(rng):
    """Contrapositive lock: a characteristic polynomial that is not hyperbolic has real covectors with complex
    roots tau; plane waves grow like exp(|Im tau(s xi)| t) = exp(s |Im tau(xi)| t): unbounded in frequency s,
    i.e. the Cauchy problem is ill-posed (Hadamard). Residual (nonconvex / exchanging) characteristic sets of
    principal symbols therefore signal ill-posed propagation, which is an observable instability."""
    e = np.array([1.0, 0, 0, 0]); L = lin_forms(6, rng, e); q = renegar_poly(L, e, 2)
    Lr = rng.normal(size=(4, 4)); pert = lambda V: np.sum((V @ Lr.T)**2, -1)**2/10
    delta = MUT.get("rx10_delta", 0.6)
    qn = lambda V: q(V) + delta*pert(V)
    rates_h, rates_n, frac_n = [], [], 0
    for _ in range(300):
        w = rng.normal(size=4); w[0] = 0; w /= np.linalg.norm(w)
        rh = roots_along(q, w, e, 4); rn = roots_along(qn, w, e, 4)
        rates_h.append(np.max(np.abs(rh.imag))); rates_n.append(np.max(np.abs(rn.imag))); frac_n += rates_n[-1] > 1e-6
    # scaling is claimed for covectors with complex roots: select one (a random covector may have real roots)
    for _ in range(200):
        w = rng.normal(size=4); w[0] = 0; w /= np.linalg.norm(w)
        if np.max(np.abs(roots_along(qn, w, e, 4).imag)) > 1e-3: break
    scal = [f(np.max(np.abs(roots_along(qn, s*w, e, 4).imag))/s) for s in (1, 10, 100)]
    passed = max(rates_h) < 1e-6 and frac_n/300 > 0.05 and np.ptp(scal) < 1e-6*max(scal)+1e-12 and max(scal) > 0
    register("RX10", "hyperbolic lock", "Residual characteristic geometry is harmless for propagation.",
             "No: failure of hyperbolicity gives complex characteristic roots whose growth rate scales linearly with "
             "frequency (Hadamard ill-posedness). Observable instability is the physical signature of the residual.",
             passed, dict(hyperbolic_max_im=f(max(rates_h)), perturbed_complex_fraction=f(frac_n/300),
                          growth_rate_per_unit_frequency=scal), "HOLDS")


ATTACKS = [RX01_presentation, RX02_tame_harnack, RX03_linear_moduli, RX04_garding, RX05_sheet_order,
           RX06_window_lemma, RX07_duality, RX08_dynamic_cones, RX09_certifier, RX10_hadamard]


def run_all(seed):
    for a in ATTACKS:
        rng = np.random.default_rng([seed, ATTACKS.index(a)])
        try: a(rng)
        except Exception as ex: register(a.__name__[:4], "?", "?", f"EXCEPTION {ex!r}", False, {}, "ERROR")


def canary(seed):
    """each mutation removes the structure a check depends on; the targeted check must fail."""
    muts = [("RX06", {"rx06_same_window": True}),         # no escalation beyond the coarse window
            ("RX08", {"rx08_single": True}),              # no length escalation for the dynamic cone test
            ("RX09", {"rx09_single": True}),              # single-resolution corner detector
            ("RX10", {"rx10_delta": 0.0})]                # nothing non-hyperbolic to detect
    ok = True
    for tgt, m in muts:
        RESULTS.clear(); MUT.clear(); MUT.update(m); print(f"--- canary {tgt}: {m}")
        a = next(x for x in ATTACKS if x.__name__.startswith(tgt))
        try: a(np.random.default_rng([seed, ATTACKS.index(a)])); caught = not RESULTS[-1]["passed"]
        except Exception as ex: print(f"    exception {ex!r} (counts as NOT a clean catch)"); caught = False
        ok &= caught; print(f"    {'CAUGHT' if caught else 'NOT CAUGHT'}")
    MUT.clear(); print("CANARY:", "all caught" if ok else "BATTERY TOO WEAK"); return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--seed", type=int, default=20261001)
    ap.add_argument("--out", default="rg_residual_cone_results.json"); ap.add_argument("--canary", action="store_true")
    a = ap.parse_args()
    if a.canary: sys.exit(canary(a.seed))
    t0 = time.time(); print(f"RG residual characteristic battery, seed {a.seed}\n"); run_all(a.seed)
    n = sum(r["passed"] for r in RESULTS)
    summ = dict(seed=a.seed, n_checks=len(RESULTS), n_pass=n, runtime_s=round(time.time()-t0, 1))
    json.dump(dict(summary=summ, results=RESULTS), open(a.out, "w"), indent=2,
              default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print(f"\n{n}/{len(RESULTS)} pass."); sys.exit(0 if n == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
