# RG - Residual Characteristic Geometry: battery RX01-RX10

    python3 rg_residual_cone_attack.py            # seed 20261001 (~2 min)
    python3 rg_residual_cone_attack.py --canary   # RX06, RX08, RX09, RX10 sabotaged; each must fail

10/10 on seeds 20261001, 1, 42, 777, 2026; canary 4/4. Every verdict is computed from sampled directions; no label,
component count or extreme-ray count is supplied to a detector. Replaces RC01-RC10 (see paper, Appendix B).
