"""Silent failures of established tools that RG's typing detects. Every witness is exact, symbolic, or a closed-form
evaluation; there is no random sampling.
S1  same Fisher field, not the same experiment (Blackwell): Hellinger affinities differ at d = 1
S2  same Hessian (Fisher), different finite divergences
S3  ray-wise limit test passes, gauge still discontinuous (curve x = y^2)
S4  Fisher-null tangent is not an exact fibre (p = (1/2 + th^2, 1/2 - th^2))
S5  zero Fisher defect everywhere, yet no global recovery (disconnected model)
S6  shape ratio and its denominator are correlated (neutron f14/f13 vs f13)
S7  equal samples, different frequencies: alias at 3M uniform samples (M = 1, closed form)
S8  the joint unitary is reversible, the reduced channel is not (complete dephasing)
S9  a coordinate component is not a prediction: g_tt differs across lapse gauges, proper time does not (FLRW, closed form)
S10 the box (equivalence principle) is blind to structure: 1911 deflection = half of 1915
S11 real QM: identity and transpose agree on every local state, differ on a composite
S12 the squared Euclidean distance is not monotone: merging outcomes raises it
Run: python rg_silent_failures.py   (sympy, numpy)
"""
import json, hashlib, pathlib, math
import sympy as sp
import numpy as np
RES = {}
def must(c, m):
    if not c: raise AssertionError(m)
R = sp.Rational

# S1
d = sp.Integer(1)
aff1 = sp.cos(d / 2); aff2 = sp.cos(d / (2 * sp.sqrt(2))) ** 2
must(abs(float(aff1 - aff2)) > 1e-3, "S1")
RES["S1"] = dict(tool="Fisher information as 'the information of the experiment'",
                 failure="Bernoulli(sin^2(theta/2)) and two iid Bernoulli(sin^2(theta/(2 sqrt 2))) both have Fisher = 1 at every theta, but their "
                         "Hellinger affinities at separation 1 differ, so no randomization maps one to the other",
                 values=[str(sp.N(aff1, 12)), str(sp.N(aff2, 12))], rg_object="global experiment comparison (rooms, deficiency), not the local metric")
# S2
p = [R(4, 5), R(1, 5)]; q = [R(3, 10), R(7, 10)]
def Df(f): return sum(q[i] * f(p[i] / q[i]) for i in range(2))
vals = [Df(lambda t: t * sp.log(t) - t + 1), Df(lambda t: (t - 1) ** 2 / 2), Df(lambda t: 2 * (sp.sqrt(t) - 1) ** 2)]
must(len({round(float(v), 8) for v in vals}) == 3, "S2")
RES["S2"] = dict(tool="the Fisher metric selects the divergence", failure="three divergences with identical Hessian (f''(1) = 1) give different finite values",
                 values=[str(sp.N(v, 10)) for v in vals], rg_object="task-declared finite loss")
# S3
X, Y, t, m = sp.symbols("x y t m", real=True); b = X * Y ** 2 / (X ** 2 + Y ** 4)
rays = sp.limit(b.subs({X: t, Y: m * t}), t, 0); curve = sp.limit(b.subs({X: t ** 2, Y: t}), t, 0)
must(rays == 0 and curve == R(1, 2), "S3")
RES["S3"] = dict(tool="checking limits along rays", failure="every ray gives 0; the curve x = y^2 gives 1/2", rg_object="definable-curve crossing criterion")
# S4
th = sp.Symbol("theta", real=True); pth = [R(1, 2) + th ** 2, R(1, 2) - th ** 2]
F = sp.simplify(sum(sp.diff(pi, th) ** 2 / pi for pi in pth))
must(F.subs(th, 0) == 0, "S4")
RES["S4"] = dict(tool="Fisher kernel = unidentifiable direction", failure="Fisher vanishes at theta = 0 although p_theta != p_0 for every theta != 0 (TV = theta^2)",
                 fisher=str(F), rg_object="hidden versus null; walls with rate lambda = 1/4")
# S5
RES["S5"] = dict(tool="zero information loss at every point = sufficiency", failure="two components with constant laws (0.2, 0.8) and (0.8, 0.2), record erased: "
                 "every tangent defect is zero, yet no single recovery reproduces both laws", rg_object="global (connected) sufficiency; components are rooms")
# S6
Xv, Yv, sx = sp.symbols("X Y sigma_X", positive=True)
cov = -Yv / Xv ** 2 * sx ** 2
must(cov.subs({Xv: R(4641, 10), Yv: R(6488, 10), sx: R(12, 10)}) != 0, "S6")
RES["S6"] = dict(tool="different channel labels = independent rows", failure="Cov(X, Y/X) = -Y sigma_X^2 / X^2 != 0 for the neutron f13 and f14/f13",
                 value=str(sp.N(cov.subs({Xv: R(4641, 10), Yv: R(6488, 10), sx: R(12, 10)}), 6)), rg_object="covariance follows shared records, not labels")
# S7 M = 1: c0 + a cos(w t) + b sin(w t) sampled at t = 0, 1, 2 (3 = 3M samples): two different w reproduce the same three samples
w1, w2 = 0.7, 1.1; tt = np.array([0.0, 1.0, 2.0]); y = 0.3 + 0.8 * np.cos(w1 * tt) - 0.2 * np.sin(w1 * tt)
A2 = np.column_stack([np.ones(3), np.cos(w2 * tt), np.sin(w2 * tt)]); coef = np.linalg.solve(A2, y)
must(np.allclose(A2 @ coef, y) and w1 != w2, "S7")
RES["S7"] = dict(tool="fit the samples you have", failure="with 3 = 3M samples a different frequency (1.1 vs 0.7) reproduces every sample exactly",
                 alias_coefficients=coef.round(12).tolist(), rg_object="minimal probe 3M + 1 and abstention")
# S8
plus = sp.Matrix([1, 1]) / sp.sqrt(2); minus = sp.Matrix([1, -1]) / sp.sqrt(2)
deph = lambda r: sp.diag(r[0, 0], r[1, 1])
must(deph(plus * plus.T) == deph(minus * minus.T) == sp.eye(2) / 2, "S8")
RES["S8"] = dict(tool="the total evolution is unitary, so the information is recoverable", failure="complete dephasing maps |+> and |-> to the same I/2: the reduced channel has no inverse",
                 rg_object="joint reversal versus reduced recovery (task-declared)")
# S9 FLRW: proper-time gauge vs conformal gauge at the same coordinate time
tau = sp.Symbol("tau", positive=True)
a_tau = (sp.Rational(3, 2) * tau) ** sp.Rational(2, 3)           # dust, C = 1, a(0) = 0
gtt_proper = -1
gtt_conf = -a_tau ** 2
must(sp.simplify(gtt_conf.subs(tau, 1) - gtt_proper) != 0, "S9")
RES["S9"] = dict(tool="metric components are physical", failure="at the same event g_tt = -1 (proper-time gauge) and -a^2 (conformal gauge); a(tau) is gauge-free",
                 g_tt_conformal_at_tau1=str(sp.N(gtt_conf.subs(tau, 1), 8)), rg_object="relational readout; spacetime as representative")
# S10
GM = 1.32712440018e20; c = 299792458.0; Rsun = 6.957e8
d1911 = 2 * GM / (c ** 2 * Rsun) * 206264.806; d1915 = 4 * GM / (c ** 2 * Rsun) * 206264.806
must(abs(d1915 / d1911 - 2) < 1e-12, "S10")
RES["S10"] = dict(tool="the equivalence principle fixes light bending", failure=f"box (energy channel only): {d1911:.3f}\"; full GR (structure): {d1915:.3f}\"",
                  rg_object="energy vs structure channels (duality)")
# S11
sy = sp.Matrix([[0, -sp.I], [sp.I, 0]]); syy = sp.simplify(sp.kronecker_product(sy, sy))
rp = (sp.eye(4) + R(1, 5) * syy) / 4
def pT(Mx):
    out = sp.zeros(4)
    for i in range(2):
        for j in range(2):
            for k in range(2):
                for l in range(2): out[2 * j + k, 2 * i + l] = Mx[2 * i + k, 2 * j + l]
    return out
must(pT(rp) != rp and all(sp.Matrix(Bm).T == sp.Matrix(Bm) for Bm in ([[1, 0], [0, 0]], [[0, 1], [1, 0]], [[0, 0], [0, 1]])), "S11")
RES["S11"] = dict(tool="a map is fixed by what it does on states", failure="in real QM identity and transpose agree on every single-system state but differ on (I + 0.2 sy x sy)/4",
                  rg_object="extension completeness (= local tomography)")
# S12
pe = sp.Matrix([R(1, 6), R(5, 12), R(5, 12)]); qe = sp.Matrix([R(2, 3), R(1, 6), R(1, 6)]); Mg = sp.Matrix([[1, 0, 0], [0, 1, 1]])
before = sum((pe - qe)[i] ** 2 for i in range(3)); after = sum((Mg * (pe - qe))[i] ** 2 for i in range(2))
must(after > before, "S12")
RES["S12"] = dict(tool="squared Euclidean (L2) distance between distributions", failure=f"merging two outcomes raises it from {before} to {after}: processing creates distinguishability",
                  rg_object="descent (monotonicity) forces Fisher")
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_silent_failures_results.json").write_text(json.dumps(RES, indent=1, default=str))
for k, v in RES.items():
    if isinstance(v, dict): print(k, "|", v["failure"][:120])
