WALL-TAP DELAY: FINAL COMPUTATIONAL PRINT
========================================
EVIDENCE: SYNTHETIC WAVEFORMS ONLY. No physical acoustic recordings were supplied.
The PDF is a self-contained formal and computational study, not an empirical
room-acoustics measurement report or a claim of historical timing precision.

START HERE
  Wall_Tap_Delay_Final_Print.pdf
  Wall_Tap_Delay_Final_Print.tex

EXECUTABLES
  walltap_final.py       Generate waveforms, fit calibration, estimate positions,
                        run 30 checks and 19 controls on five fixed seeds.
  walltap_verify.py      Independent calibration/Jacobian audit and bootstrap.
  walltap_make_print.py  Rebuild the standalone LaTeX paper from saved results.

REPRODUCTION (all commands were executed for the supplied outputs)
  python walltap_final.py --out .
  python walltap_final.py --out . --replay
  python walltap_verify.py --out .
  python walltap_make_print.py --out .
  pdflatex Wall_Tap_Delay_Final_Print.tex
  pdflatex Wall_Tap_Delay_Final_Print.tex
A single seed can be selected with --seed 83. Default seeds are development
20261020 followed by validation 17, 83, 409, 2027. Dependencies are pinned in
walltap_requirements.txt; the execution environment is recorded in JSON.
LaTeX compilation requires pdflatex with the packages named in the source.

RECORDS
  walltap_raw_<seed>.npz: raw synthetic calibration, held-out, room and silence
                         waveforms, metadata and extracted features.
  walltap_evaluation_<seed>.npz: evaluation-only positions and true readouts.
  walltap_auxiliary_<seed>.npz: uncertainty inputs/errors, Jacobian, covariance,
                              raw gain/filter/multipath controls.
  walltap_final_results.json: complete per-seed checks, controls and evidence.
  walltap_checks.csv: flattened check ledger.
  walltap_replay.json: saved-record extraction comparison, without simulation.
  walltap_verification.json: independent audit and conditional bootstrap.
  walltap_thesis_ledger.json: explicit claims and their check mappings.
  walltap_input_provenance.json: hashes of supplied background files, not copies.

AUDIT
  The source and protocol are hashed in the result JSON. The package manifest
  hashes every packaged file except itself. walltap_manifest.json is the earlier
  execution-stage manifest; walltap_package_manifest.json covers the final bundle.
  Development logs retain the initial NumPy-boolean JSON serialization error and
  the earlier 28-check development pass. Two checks were added before validation.
  Ten controls remove dispatcher gates; nine are numerical/waveform/access faults.
  Exactly coincident paths remain an explicitly unresolved observational fibre.
  Conditional waveform errors, feature-model coverage and bootstrap intervals
  have different uncertainty scopes; the paper states each separately.

LIMITS
  No general measured-WAV adapter, physical hardware acquisition, or arbitrary
  room reconstruction is implemented. Wall labels, isolated paths, known room
  extents, a pulse model and the calibration class are declared inputs.
  Passing finite checks is not a proof that every physical premise is true.
