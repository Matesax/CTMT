#!/usr/bin/env python3
"""Build the standalone Wall-Tap LaTeX print from saved, verified results.
Run after walltap_final.py and walltap_verify.py. Does not rerun simulations.
"""
import argparse,json,hashlib
from pathlib import Path
import numpy as np

def esc(s):
    return str(s).replace('\\',r'\textbackslash{}').replace('_',r'\_').replace('%',r'\%').replace('&',r'\&')

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out',default='.'); args=ap.parse_args(); root=Path(args.out)
    R=json.loads((root/'walltap_final_results.json').read_text()); P=json.loads((root/'walltap_protocol.json').read_text()); V=json.loads((root/'walltap_verification.json').read_text())
    assert R['all_pass'] and R['all_canaries_caught'] and V['all_pass']
    assert hashlib.sha256((root/'walltap_final.py').read_bytes()).hexdigest()==R['source_sha256']
    runs=R['runs']; first=runs[0]; E={r['id']:r['evidence'] for r in first['checks']}
    rows=[]
    for run in runs:
        e={r['id']:r['evidence'] for r in run['checks']}
        rows.append(f"{run['seed']} & {e['WT02']['arrival_rmse_us']:.3f} & {e['WT05']['position_rms_m']*1000:.3f} & {e['WT04']['heldout_residual_m']*1000:.3f} & {e['WT07']['coverage95']*100:.3f} \\\\")
    ledger=[]
    for row in sorted(first['checks'],key=lambda x:x['id']):
        ident=row['id']; claim=esc(row['claim'])
        types={'WT01':'analytic counterexample','WT02':'waveform recovery','WT03':'noise control','WT04':'held-out prediction','WT05':'waveform inverse','WT06':'model residual','WT07':'feature Monte Carlo','WT08':'exact ambiguity','WT09':'analytic rank','WT10':'nuisance information','WT11':'fold and finite jet','WT12':'Gaussian-law comparison','WT13':'selection counterexample','WT14':'feature Monte Carlo','WT15':'image-path geometry','WT16':'reciprocal model','WT17':'slowness quadrature','WT18':'clock algebra','WT19':'sampled energy integral','WT20':'local information','WT21':'waveform mismatch','WT22':'held-out falsification','WT23':'covariance algebra','WT24':'finite entropy identity','WT25':'projectability example','WT26':'clock cocycle','WT27':'dispatcher audit','WT28':'API guard and image test','WT29':'window equivalence','WT30':'multipath counterexample'}
        ledger.append(f"{ident} & {claim} & {types[ident]} & pass \\\\")
    canrows=[]
    for row in first['canaries']:
        typ='gate-removal mutation' if row['id'].startswith('ignore_') else 'executed control or access fault'
        canrows.append(f"\texttt{{{esc(row['id'])}}} & {typ} & detected \\\\")
    covariance=np.array(E['WT07']['predicted_covariance_m2'])*1e6
    covtex=r'\begin{pmatrix}'+f'{covariance[0,0]:.6f}&{covariance[0,1]:.6f}'+r'\\'+f'{covariance[1,0]:.6f}&{covariance[1,1]:.6f}'+r'\end{pmatrix}'
    bwidth=np.array(V['bootstrap']['interval_widths_mm'])
    truth=np.load(root/f"walltap_evaluation_{first['seed']}.npz")
    true_duration=(truth['true_times']-P['onset_s'])/P['clock_rate']
    duration=np.array(first['metrics']['calibrated_path_duration_s'])
    duration_rmse=np.sqrt(np.mean((duration-true_duration)**2))*1e6
    text=TEMPLATE.replace('@@RESULTROWS@@','\n'.join(rows)).replace('@@LEDGER@@','\n'.join(ledger)).replace('@@CANARIES@@','\n'.join(canrows))
    values={'@@COV@@':covtex,'@@DURATION@@':f'{duration_rmse:.3f}','@@BOOTMIN@@':f'{bwidth.min():.3f}','@@BOOTMAX@@':f'{bwidth.max():.3f}',
      '@@SOURCEHASH@@':R['source_sha256'],'@@PROTOCOLHASH@@':R['protocol_sha256'],
      '@@PYTHON@@':R['environment']['python'],'@@NUMPY@@':R['environment']['numpy'],'@@SCIPY@@':R['environment']['scipy'],
      '@@SPEED@@':f"{first['metrics']['inferred_speed_given_clock_m_s']:.6f}",
      '@@SHAPEMAX@@':f"{E['WT27']['evidence']['shape']:.3f}",
      '@@EQUIV@@':f"{E['WT29']['equivalence90_bound_m']*1000:.3f}",
      '@@MULTI@@':f"{E['WT30']['separated_multipath_shape']:.3f}"}
    for k,v in values.items():text=text.replace(k,v)
    assert '@@' not in text
    (root/'Wall_Tap_Delay_Final_Print.tex').write_text(text)
    claims=dict(thesis='Conditional acoustic identifiability with explicit calibration and honest non-identifiability',
      origin='SYNTHETIC',claims=[
       dict(id='T1',statement='A fixed law map has an exact quotient; finite tolerances are decision relations, not exact equivalence',checks=['WT01','WT13','WT23','WT28']),
       dict(id='T2',statement='Two distinct range anchors identify aggregate affine latency calibration under its model',checks=['WT02','WT04','WT09','WT18','WT22','WT26','WT29']),
       dict(id='T3',statement='Known rectangular geometry and labelled first-order returns identify position, not arbitrary room structure',checks=['WT05','WT06','WT08','WT15','WT16','WT17','WT30']),
       dict(id='T4',statement='Uncertainty is conditional on a covariance model; shared errors need not average away',checks=['WT07','WT14']),
       dict(id='T5',statement='Response and resolution assumptions can be falsified but cannot be certified universally by finite checks',checks=['WT03','WT10','WT11','WT12','WT19','WT20','WT21','WT22','WT30']),
       dict(id='T6',statement='Certificate statuses are explicit conditional decisions, not a theorem that all physical assumptions are true',checks=['WT24','WT25','WT27','WT28'])])
    (root/'walltap_thesis_ledger.json').write_text(json.dumps(claims,indent=2))
    print('Built standalone LaTeX print from saved results. Duration RMSE (us):',duration_rmse)

TEMPLATE=r'''\documentclass[11pt]{article}
\usepackage[a4paper,margin=22mm]{geometry}
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{lmodern}
\usepackage{amsmath,amssymb,amsthm,booktabs,longtable,array,graphicx,microtype,hyperref}
\hypersetup{hidelinks,pdftitle={Wall-Tap Delay: Calibrated Duration, Acoustic Distance, and Identifiability},pdfauthor={Matej Rada}}
\newtheorem{theorem}{Theorem}[section]
\newtheorem{proposition}[theorem]{Proposition}
\newtheorem{corollary}[theorem]{Corollary}
\theoremstyle{definition}\newtheorem{definition}[theorem]{Definition}
\theoremstyle{remark}\newtheorem{remark}[theorem]{Remark}
\newcommand{\Kk}{\mathcal K}
\newcommand{\rank}{\operatorname{rank}}
\newcommand{\Var}{\operatorname{Var}}
\newcommand{\Cov}{\operatorname{Cov}}
\newcommand{\rad}{\operatorname{rad}}
\newcommand{\im}{\operatorname{im}}
\newcolumntype{P}[1]{>{\raggedright\arraybackslash}p{#1}}
\title{\bfseries Wall--Tap Delay\\[3pt]\large Calibrated Duration, Acoustic Distance, and Identifiability\\\normalsize A Formal Model and Reproducible Waveform-Level Computational Experiment}
\author{Mat\v{e}j Rada\\\small MatejRada@email.cz\\\small Licensed under CC BY-NC-ND 4.0}
\date{October 2026}
\begin{document}\maketitle
\begin{abstract}
A triggered acoustic return records a delayed confirmation, not a distance without qualification. We formulate the wall--tap experiment as a joint observation law, distinguish exact observational equivalence from finite-resolution decisions, and derive the conditions under which recorder latency identifies propagation duration, path length, and position. The central inverse problem uses two independent range anchors to identify an aggregate affine recorder calibration and four labelled first-order returns to localize a collocated source and receiver in a known rectangular enclosure. Clock rate and sound speed are not separately identified by the acoustic slope alone. Closure checks do not resolve path-label permutations, and a shape test cannot distinguish exactly coincident paths from a single stronger return.

A new executable experiment generates and archives sampled waveforms at 48 kHz, estimates arrivals without true-delay search windows, fits calibration on two anchors, and evaluates a third anchor and six positions held out from that fit. Thirty specified checks and nineteen negative controls pass on one development seed and four subsequent validation seeds. Arrival RMSE ranges from 0.847 to 0.896 microseconds and conditional position RMS from 0.145 to 0.163 millimetres under the declared high-SNR pulse model. A separate covariance experiment gives 94.825--95.105 percent coverage for nominal 95 percent position ellipsoids. Saved-record replay and an independent Jacobian audit agree with the implementation.

These are synthetic computational results, not measurements of a physical wall, historical timing precision, or apparatus performance guarantees. The paper supplies conditional identifiability theorems, explicit falsification targets, uncertainty budgets, and a complete recorded audit. It does not infer the truth of every physical assumption from a finite collection of passed gates.
\end{abstract}
\tableofcontents

\section{Question, thesis, and evidential scope}
A wall--tap observation begins with an emitted event and a later received response. The scientific question is not whether an interval can be noticed, but what a declared record can identify. The route considered here is
\[
\begin{gathered}
\text{ordered readouts}\longrightarrow\text{calibrated duration}\\
\longrightarrow\text{acoustic path constraint}\longrightarrow\text{anchored position}.
\end{gathered}
\]
Each arrow has assumptions. Raw apparatus latency is not automatically propagation duration. One echo is not a room reconstruction. A finite tolerance is not an exact kernel, and a canonical quotient does not select its own metric or physical model.

\paragraph{Thesis.}
Under a specified clock and latency model, an independently anchored acoustic scale, a valid path model, and sufficient labelled paths, the observable law determines a local geometric task. The resulting estimate must retain covariance, model scope, and unresolved alternatives. Finite residual tests can falsify proposed extensions and delimit an accepted operating window; they cannot prove that all unobserved physical alternatives are absent.

The formulation uses the exact-law and conditional-rigidity discipline of Resolution Geometry (RG) \cite{RG}. All definitions and proofs needed for this experiment are given here. The acoustic path model is conventional and explicitly imported; it is not derived from equality of observation laws \cite{Allen,Kuttruff}.

\paragraph{What was executed.}
The completed experiment is a synthetic sampled-waveform study. No raw measured acoustic recording accompanied the source material, and none is manufactured as measured data. The archived arrays are marked \texttt{SYNTHETIC}. Earlier reported numerical results are not reused as outcomes of this run. The present numbers come from the accompanying source, saved records, and verification files.

The experiment estimates position in a known enclosure. It does not estimate arbitrary room dimensions, wall topology, a human perceptual threshold, or a unique latent material state. Its very small conditional errors reflect a smooth known pulse, high SNR, isolated labelled paths, and a correctly specified simulator. They must not be transferred to an ordinary room or phone recording.

\section{Observation law and the exact quotient}
\label{sec:law}
\subsection{Raw records and latent inputs}
Let $\theta$ contain position, path geometry, medium parameters, pulse amplitudes, aggregate apparatus latency, clock parameters, and any response variables retained by the model. Let $D$ denote declared protocol inputs: sample rate, pulse family, path labels, anchor records, environmental assumptions, and the task.

The observation law is
\[
 F_D:\theta\longmapsto\mathcal L(Y\mid\theta,D),
\]
where $Y$ is the joint raw record. Calibration and control channels are included when they are part of the declared experiment. Equality of law means equality of the full specified distribution, not merely equality of a fitted delay or a selected feature.

\begin{definition}[Exact observational equivalence]
Define
\[
 \theta\mathrel{\Kk_D}\theta'
 \quad\Longleftrightarrow\quad F_D(\theta)=F_D(\theta'),
 \qquad Q_D=X/\Kk_D.
\]
The associated equivalence-relation groupoid has one arrow between each pair of law-equivalent states. A task $T$ is identifiable from this experiment when it is constant on every fibre of $F_D$.
\end{definition}

\begin{proposition}[Task factorization]
A task $T:X\to Z$ is constant on the fibres of $F_D$ if and only if there is a unique $\bar T:Q_D\to Z$ with $T=\bar T\circ\pi$. The set quotient is canonically identified with $\im F_D$.
\end{proposition}
\begin{proof}
Set $\bar T([\theta])=T(\theta)$. Fibre constancy gives well-definedness and surjectivity of $\pi$ gives uniqueness. The map $[\theta]\mapsto F_D(\theta)$ is a bijection onto the law image.
\end{proof}

\subsection{Finite resolution does not define this quotient}
A rule $d(F_D(\theta),F_D(\theta'))\leq\eta$ is generally not transitive. On the real line, $0,.75,1.5$ with tolerance $1$ provide an immediate counterexample. Such a rule can define a decision neighbourhood or a graph, but not an equivalence relation without a separately declared construction. Taking its transitive closure can merge arbitrarily distant states along a chain.

Accordingly, exact kernels and finite-data confidence sets are kept separate. Feature extraction is a data reduction. It is not assumed to preserve the entire raw-law kernel or to be statistically sufficient. The Gaussian feature model used for uncertainty calculations is a separately declared approximation, not a theorem that matched-filter arrival estimates are exactly Gaussian.

\begin{proposition}[Confidence preimages preserve coverage]
Suppose $C(Y)$ is a confidence set for the observable law with
$\Pr_\theta\{F_D(\theta)\in C(Y)\}\geq1-\alpha$.
Then
\[
 \Theta_C(Y)=\{\theta':F_D(\theta')\in C(Y)\}
\]
contains the true state with at least that probability. Its task image $T(\Theta_C(Y))$ contains the true task value with at least that probability.
\end{proposition}
\begin{proof}
The event $F_D(\theta)\in C(Y)$ implies both asserted memberships. No inverse branch needs to be selected.
\end{proof}

This is the appropriate response to an unresolved sign, label, scale, or medium fibre. A unique estimate is not licensed merely because one numerical optimizer returns one representative.

\section{Duration and the calibration problem}
\label{sec:calibration}
\subsection{Aggregate latency and clock charts}
For a single isolated path, write the recorder readout as
\begin{equation}
 z=b+a\tau+\epsilon,\qquad a>0.
 \label{eq:clock}
\end{equation}
Here $\tau$ is physical propagation duration, $a$ is recorder time per physical time, and $b$ is the aggregate non-propagation latency relative to the trigger convention. Trigger, source, transducer, and detector contributions need not be individually identifiable. This experiment estimates their aggregate effect under the assumption that it is constant over the calibration window.

A known clock rate gives
\[
 \widehat\tau=(z-\widehat b)/\widehat a.
\]
Event order alone does not establish $a$ or $b$. Nor does equality of two clock kernels force their transition to be affine. Affineness is a constant-rate clock model, supported in practice by an independent clock calibration.

For declared charts $z_i=a_i\tau+b_i$, the transitions
\[
 z_j=\frac{a_j}{a_i}(z_i-b_i)+b_j
\]
satisfy the cocycle identity by substitution. This is a consistency property of the specified charts, not a derivation of calibrated seconds from order alone.

\subsection{Two distinct routes to metres}
In a homogeneous still medium with sound speed $c_m$, a collocated source and receiver at normal distance $d$ from a plane wall have
\begin{equation}
 \tau=2d/c_m,\qquad z=b+qd+\epsilon,\qquad q=2a/c_m.
 \label{eq:affine}
\end{equation}
There are two valid calibration routes.
\begin{enumerate}
\item \emph{Clock and medium route.} Independently calibrate $a$, the aggregate latency $b$, and the applicable medium speed $c_m$. Then $d=c_m(z-b)/(2a)$.
\item \emph{Range-anchor route.} Use two distinct independently known distances to estimate $b$ and $q$. Then $d=(z-b)/q$. A separate clock-rate calibration is required only if the result is also reported as physical duration or used to infer $c_m$.
\end{enumerate}
The completed waveform experiment uses the second route. The generator's $a$ is supplied as an external clock declaration for the duration report. It is not estimated from the acoustic records.

\begin{theorem}[Affine calibration identifiability]
\label{thm:calibration}
Under model~\eqref{eq:affine}, two distinct known ranges $d_1\ne d_2$ and their exact mean readouts $m_1,m_2$ identify
\[
 q=\frac{m_2-m_1}{d_2-d_1},\qquad b=m_1-qd_1.
\]
One range anchor does not identify both $b$ and $q$. The acoustic slope alone does not separately identify $a$ and $c_m$.
\end{theorem}
\begin{proof}
The two-anchor design matrix has determinant $d_2-d_1$, hence is invertible. One equation $m=b+qd$ leaves an affine line of parameter pairs. Finally $(a,c_m)\mapsto(ka,kc_m)$ preserves $q$ for every $k>0$.
\end{proof}

Thus $2/q$ is an effective propagation speed in recorder-time units. If $a$ is independently fixed, $2a/q$ is an inferred medium speed. It is not an independent check of the same range calibration. Moreover,
\[
 \frac{(2a/q)}2\frac{z-b}{a}=\frac{z-b}{q},
\]
so the common clock factor cancels in the range-anchor route. Counting its uncertainty twice would be incorrect.

Known room dimensions are themselves length anchors and could support other calibration designs. They are not used to fit $b,q$ here: the opposite-wall equations are reserved as checks. The no-scale statements below refer to experiments without sufficient independent length or medium information, not to an experiment that secretly retains a known room size.

\subsection{Why raw latency cannot replace path duration}
For fixed $d,c_m$, changing $b$ changes $z$ without changing the path. Conversely, $b$ can compensate a change in $d$ in a single readout. In the completed model $b=1.7$ ms. Treating it as propagation produces a wall-range error of approximately $c_m b/(2a)$, about $0.292$ m.

A common offset cancels in opposite-wall position differences. Therefore this error must be tested on individual wall ranges or closure, not asserted to bias every position estimator. The executed control makes precisely that distinction.

\section{Path geometry, labels, and medium ambiguity}
\label{sec:paths}
\subsection{Monostatic and bistatic paths are different tasks}
For source $s$, receiver $m$, and a specular reflection point $w$ on a plane wall,
\[
 \ell=\|s-w\|+\|w-m\|,\qquad \tau=\ell/c_m.
\]
Equivalently, the image-source construction gives $\ell=\|s'-m\|$ for the reflected source $s'$ \cite{Allen}. The half-path $\ell/2$ equals a normal wall distance only in the specified collocated normal-return branch.

The counterexample uses wall $x=0$, $s=(1,0)$ and $m=(3,5)$. Then
\[
 \ell=\sqrt{41}\ \mathrm m,\qquad \ell/2=3.201562\ \mathrm m,
\]
whereas the source's normal wall distance is $1$ m. This is a type error, not a small correction to the monostatic formula.

\subsection{A single delay retains scale and medium fibres}
Without a speed or length anchor, $\tau=2d/c_m$ is unchanged by $(d,c_m)\mapsto(kd,kc_m)$. For example, $(2\,\mathrm m,340\,\mathrm{m/s})$ and $(2.1\,\mathrm m,357\,\mathrm{m/s})$ give the same delay. Repetition can estimate that delay more precisely but cannot remove the exact fibre.

In a nonuniform still medium, the model becomes
\[
 \tau=\int_\gamma\frac{ds}{c_m(s)}.
\]
A single integral does not identify the speed profile. Opposite linear gradients along a segment have identical integrated slowness after reversal while their endpoint speeds differ. The experiment computes this equality by quadrature.

For uniform wind $u$ along a known segment of length $D$,
\[
 \tau_+=\frac{D}{c_m+u},\qquad
 \tau_-=\frac{D}{c_m-u},\qquad
 u=\frac D2\left(\tau_+^{-1}-\tau_-^{-1}\right).
\]
The still-air conversion of their sum yields $D/(1-u^2/c_m^2)$, not $D$. The reciprocal example tests this declared model; the main waveform run assumes still homogeneous propagation and does not estimate a general flow field.

\subsection{Localization in a known rectangular enclosure}
Let the known extents be $W,H$ and the collocated source--receiver position be $(x,y)$. Four labelled first-order paths have normal distances
\[
 d_L=x,\quad d_R=W-x,\quad d_B=y,\quad d_T=H-y.
\]
The calibrated inverse is
\begin{align}
 \widehat d_k&=(z_k-\widehat b)/\widehat q,\\
 \widehat x&=\tfrac12(\widehat d_L+W-\widehat d_R),\qquad
 \widehat y=\tfrac12(\widehat d_B+H-\widehat d_T).
 \label{eq:position}
\end{align}
The closure residuals are
\[
 r_W=\widehat d_L+\widehat d_R-W,\qquad
 r_H=\widehat d_B+\widehat d_T-H.
\]

\begin{theorem}[Conditional labelled localization]
\label{thm:position}
Assume the homogeneous monostatic first-order path model, known extents, positive $q$, a valid aggregate affine calibration, and correct wall labels. Exact mean readouts determine a unique position in the declared rectangle. The position-to-readout Jacobian has rank two. The two opposite-wall closure equations are independent residual constraints on the four readouts.
\end{theorem}
\begin{proof}
Equation~\eqref{eq:position} is an explicit inverse on the model image. The readout Jacobian is
\[
 q\begin{pmatrix}1&0\\-1&0\\0&1\\0&-1\end{pmatrix},
\]
which has rank two. The closure rows $(1,1,0,0)$ and $(0,0,1,1)$ are independent and annihilate the position-dependent part.
\end{proof}

\begin{proposition}[Closure does not identify labels]
Swapping the left and right returns preserves both closure residuals but replaces $x$ by $W-x$. Thus unordered returns do not generally identify the labelled position, even when closure is exact and the local Jacobian has full rank.
\end{proposition}
\begin{proof}
The sum $d_L+d_R$ is unchanged, while the difference changes sign. Substitute into~\eqref{eq:position}.
\end{proof}

The completed acquisition uses four separately isolated wall-path protocols with externally supplied wall identity. It does not solve the general problem of assigning peaks in a simultaneous reverberant recording. This idealization is an input, not a result of the detector.

\section{Waveform-level computational experiment}
\label{sec:experiment}
\subsection{Frozen model and records}
The source generates sampled pulses
\begin{equation}
 Y_{ik}[n]=A_k\exp\!\left[-\frac{(n/f_s-z_{ik})^2}{2w^2}\right]+\epsilon_{ikn},
 \quad \epsilon_{ikn}\sim N(0,\sigma^2),
 \label{eq:waveform}
\end{equation}
with $f_s=48000$ Hz, $w=90$ microseconds, $\sigma=.015$, and 40 ms records. Room-path amplitudes are $.9,.8,.75,.7$; calibration amplitude is $.8$. The Gaussian pulse centre is the arrival convention. It is not a strict causal wavefront: the Gaussian has noncompact support. No inference about a physical front velocity is made from its mathematical tails.

The model uses $c_m=343.2$ m/s, $a=1.00012$, $b=.0017$ s and a $6\times5$ m enclosure. The six evaluation positions are
\[
 (1.1,1.3),\ (1.8,3.4),\ (2.6,1.9),\ (3.7,2.8),\ (4.5,1.1),\ (4.9,3.7)\ \mathrm m.
\]
Each has twelve repetitions and four isolated labelled returns: 288 room waveforms per seed. Calibration uses 60 repetitions at each of $.8$ m and $3.5$ m. A separate 60-record anchor at $2.1$ m is held out from calibration. There are 200 noise-only records per seed. The principal archive therefore contains 668 waveforms per seed, plus separately archived mismatch controls and uncertainty arrays.

The nominal waveform study holds the training lengths and room dimensions fixed at their declared values. A separate uncertainty experiment introduces their stated uncertainty. Consequently, the nominal position RMS and the uncertainty-inclusive coverage study answer different questions.

\subsection{Arrival extraction without true-delay windows}
The estimator receives the waveform, fixed pulse template, sample rate, and protocol search interval. It does not receive true arrival times, evaluation positions, or a peak window centred on the answer.
\begin{enumerate}
\item Estimate the noise scale from the fixed first $.7$ ms quiet interval.
\item Correlate with the known Gaussian template truncated at six widths on each side.
\item Search the fixed $1$--$37$ ms interval for the largest positive correlation.
\item Refine the peak by a three-point parabolic interpolation, clipped to half a sample.
\item Fit local amplitude and compute a noise-normalized pulse-shape residual.
\end{enumerate}
A detection requires normalized correlation above $7$. The shape score is a local residual sum of squares divided by the estimated noise variance and residual degrees of freedom. Its cutoff is $4$. Because noise variance is estimated and a correlated scan selects the peak, neither score is assigned an exact standard-normal or chi-square false-alarm interpretation. Noise-only performance is measured directly.

Subsample timing is possible under a smooth known pulse model; it is not a claim that the sample interval itself has become smaller. Template error, coloured noise, clipping, onset conventions, or unresolved multipath can dominate the reported interpolation precision.

\subsection{Training, held-out evaluation, and access discipline}
Only the two training-anchor lengths and their extracted readouts enter the affine fit. The third anchor and all six target positions are excluded from that fit. Known room extents enter the geometric inverse, as declared. Position truth is read only after estimation through an evaluation interface. An attempted estimator access raises an exception and is recorded as a canary.

This interface guard demonstrates separation of the implemented functions. It is not a security proof that arbitrary Python code cannot inspect the simulator or its configuration. The generator necessarily knows the truth; the estimator's arguments do not contain it. Raw waveform replay recomputes features without invoking that generator.

\subsection{Protocol freeze and validation seeds}
The protocol JSON is written and hashed before the final random draws. Seed $20261020$ is the development run. After source refinement, seeds $17,83,409,2027$ are run without changing the numerical acceptance limits. This is an archived within-session protocol freeze, not an independently timestamped preregistration.

The development history includes a NumPy-boolean JSON serialization failure, repaired without changing statistical thresholds. The initial development run contained 28 checks and 17 controls. Explicit early--late equivalence and multipath/coarrival tests were added before the four validation seeds were executed. The final source contains 30 checks and 19 controls. Development logs are retained.

\section{Uncertainty, nuisance, and statistical geometry}
\label{sec:uncertainty}
\subsection{Range and position covariance}
For $d=(z-b)/q$, the local gradient in $(z,b,q)$ is
\[
 Dd=\left(\frac1q,-\frac1q,-\frac{z-b}{q^2}\right).
\]
The complete covariance, including calibration correlations, is propagated as $Dd\,\Sigma\,Dd^\top$. Cross terms cannot generally be omitted.

For position, use the input order
\[
 u=(z_L,z_R,z_B,z_T,b,q,W,H).
\]
The nonzero derivatives of $x$ are
\[
 \partial_{z_L}x=\frac1{2q},\quad
 \partial_{z_R}x=-\frac1{2q},\quad
 \partial_qx=-\frac{x-W/2}{q},\quad
 \partial_Wx=\frac12,
\]
with the analogous expressions for $y$. In particular $\partial_bx=\partial_by=0$. A common additive timing error cancels in these differences, although it remains in individual ranges and closure. A shared error is therefore a task-dependent floor, not automatically a floor for every observable.

The feature-level Monte Carlo experiment uses 20,000 draws per seed at $(1.8,3.4)$ m. Its white timing scale is the calibration waveform residual standard deviation. It adds a shared $3$ microsecond timing component, $.5$ mm independent uncertainties for the two calibration lengths, and $.5$ mm uncertainties for $W,H$. The induced covariance of $(b,q)$ is computed from the two-anchor design and retained with its off-diagonal term. Calibration and evaluation blocks are independent in this declared experiment.

This is a first-order Gaussian input model for the feature task, not a full repeated-waveform coverage experiment with every source of room-model error. The nominal waveform study does not include uncertain physical anchor realization. The Monte Carlo study does, at feature level.

The primary predicted position covariance is
\[
 \Sigma_{xy}=@@COV@@\ \mathrm{mm}^2.
\]
Joint 95 percent ellipsoids use the $\chi^2_2$ threshold. A separate finite-difference audit agrees with the analytic Jacobian to a maximum scaled defect $2.23\times10^{-9}$ across the five runs.

\subsection{Repetition floors}
For a scalar timing task with independent white error $u_i$ and a common calibration error $B$,
\[
 \epsilon_i=B+u_i,\qquad
 \Var(\bar\epsilon_n)=\sigma_B^2+\sigma_u^2/n.
\]
The separate floor experiment uses $\sigma_u=25$ microseconds and $\sigma_B=35$ microseconds. It is not the same $3$ microsecond component used in the position-covariance experiment. Its purpose is to test repeated scalar duration inference under a declared common error. At 256 repetitions, the correct standard uncertainty is $35.0349$ microseconds. Ignoring the common component gives severe undercoverage rather than increased accuracy.

\subsection{Conditional bootstrap}
The independent verification program resamples calibration readouts within each training anchor and resamples twelve repeated four-path records within each position. With 2,000 bootstrap replicates, it produces percentile intervals for the six mean positions. Primary-run interval widths range from @@BOOTMIN@@ to @@BOOTMAX@@ mm across coordinates.

These intervals condition on the observed session, fixed anchor lengths, extents, and template. They do not replace the uncertainty-inclusive covariance budget, estimate an unobserved common systematic, or establish 95 percent repeated-session coverage from one dataset.

\subsection{Nuisance information and the correct tangent spaces}
For a declared Gaussian feature law with mean $m(\theta)$ and fixed positive-definite covariance $\Sigma$, its Fisher tensor is
\[
 I=J^\top\Sigma^{-1}J,\qquad J=Dm.
\]
Then $\ker I=\ker J$. This kernel is a subspace of the latent tangent space. The observation-space complement of $\im J$ is a different object; it must not be substituted for the latent kernel.

For amplitude mean $gr$, an unknown gain $g$ and reflectivity $r$ have an exact product fibre. Profiling gain gives zero efficient information for absolute $r$ in the one-channel model. An independent gain reference restores information under its model. This auxiliary calculation does not claim that the waveform run reconstructs material reflectivity.

Fisher geometry is selected by the declared statistical model, not by descent alone. Physical metres enter through anchors and path geometry. Invertible feature changes preserve covariance-aware distances only when covariance is transformed as well. A gain change at fixed additive noise changes SNR and need not preserve the full law; accepting a free-amplitude pulse fit is not proof of an exact gain symmetry.

\section{Resolution, rhythm, and hidden alternatives}
\label{sec:resolution}
\subsection{Merged returns and finite precision}
For two Gaussian pulses with known amplitudes and unknown centres, the local information matrix is formed from the two centre derivatives. At exact coarrival these columns coincide, so delay rank drops. At small separation the least informative direction becomes weak. Its magnitude depends on width, noise, amplitudes, and the task precision; correlation-normalizing the information matrix does not create absolute precision.

This local information calculation is not a detection guarantee or a full two-echo estimator. Unknown amplitudes, a response filter, or uncertain path identity can make the problem harder. The main localization experiment uses isolated returns and does not claim to resolve all multipath mixtures.

\begin{proposition}[An exact coarrival fibre]
For the same pulse $p$, the waveform mean
\[
 A_1p(t-\tau)+A_2p(t-\tau)
 =(A_1+A_2)p(t-\tau)
\]
is identical to that of a single stronger return. With the same additive noise law, no statistic of this waveform can distinguish those two descriptions.
\end{proposition}
\begin{proof}
The means and noise distributions are equal, hence the observation laws are equal.
\end{proof}

The archived control uses identical noise realizations to display this equality numerically. This is a surviving observational alternative, not a canary that a valid detector should reject. A separated second pulse is rejected by the shape score; exactly coincident paths are not. Consequently a passed shape test cannot prove the single-path physical interpretation.

\subsection{Even overlap, signed information, and a fold}
An auxiliary overlap channel
\[
 o(\delta)=A\exp[-(\delta/w_0)^2]
\]
identifies $|\delta|$, not its sign. At $\delta=0$ its first derivative vanishes, while
\[
 \frac{o(h)-o(0)}{h^2}\longrightarrow-\frac A{w_0^2}.
\]
A separately observed signed channel, for example $A\tanh(\delta/w_0)$, separates the pair. This is an explicit model of why differential rank, global separation, and additional protocol information are distinct. The signed channel is an added measurement assumption, not something recovered from the even statistic by repetition.

\subsection{A response-dependent rhythm boundary}
Let a declared response have energy density proportional to $e^{-t/\tau_E}$ for $t\geq0$. Define the isolated-energy fraction
\[
 \chi(T)=\frac{\int_0^T |h(t)|^2dt}{\int_0^\infty |h(t)|^2dt}
 =1-e^{-T/\tau_E}.
\]
For threshold $\chi_\star$, the boundary is
\[
 T_c=-\tau_E\log(1-\chi_\star).
\]
At $\chi_\star=1/2$, the three declared energy decay times $25$ ms, $60$ ms, and $140$ ms give approximately $17.329$ ms, $41.589$ ms, and $97.041$ ms, respectively. The sampled calculation differs by at most two sample periods under its finite-tail convention.

This statistic is not a universal auditory threshold. Nor is it automatically the dominant-reflection energy fraction of a coherently summed periodic train, whose cross terms depend on phase and pulse shape. It is the specified response-energy statistic. Human localization and memory would require separate measured outcomes and are not inferred here.

\subsection{Mean convergence is not law convergence}
For equal-variance Gaussian laws with mean separation $\varepsilon$ and standard deviation $s$,
\[
 H^2=1-\exp[-\varepsilon^2/(8s^2)].
\]
At fixed $s$, distinguishability collapses as $\varepsilon\to0$. If $s=\varepsilon s_0$, the same expression remains constant. Thus a gate based only on shrinking means can falsely declare loss of distinguishability. The battery evaluates both cases explicitly; it does not infer a uniform forgetting theorem from a finite sample.

\section{Conditional identification and operational certificates}
\label{sec:certificate}
\begin{theorem}[Wall--tap task identification under the declared model]
\label{thm:main}
Fix the pulse family and noise law, an affine aggregate latency model, two distinct independent range anchors, a valid homogeneous monostatic first-order path model, known rectangular extents, and correct wall labels. Assume positive return amplitudes and an acquisition window containing the pulse centres. Then the joint law of calibration and labelled path records identifies the position task. If the clock rate is independently calibrated, it also identifies propagation durations under the aggregate latency model.

If a confidence set for that joint law has stated coverage, its full inverse image and the corresponding task image inherit at least that coverage. No claim that finite residual gates establish all the physical premises is required or implied.
\end{theorem}
\begin{proof}
For the fixed Gaussian pulse family with positive amplitude, ratios of its positive mean values at two distinct sample times identify its centre: the logarithmic ratio is affine in that centre with nonzero coefficient. The amplitude is then determined. Equality of the fixed-noise Gaussian waveform laws therefore identifies each pulse centre. The two-anchor means identify $b,q$ by Theorem~\ref{thm:calibration}. The labelled path means identify $(x,y)$ by Theorem~\ref{thm:position}. A calibrated $a$ gives $\tau=(z-b)/a$. The confidence statement follows from the preimage proposition in Section~\ref{sec:law}.
\end{proof}

This is a sufficient conditional theorem for a stated class. It is not an ``if and only if'' claim that these are the only possible protocols or weakest hypotheses. Counterexamples to omitting a premise establish non-omissibility for the relevant argument, not universal necessity of that premise in every alternative experiment.

\subsection{Implemented decision contract}
The dispatcher receives explicit evidence fields: domain, scale calibration, labels, rank, detection, early--late equivalence, pulse-shape score, closure residual, held-out residual, and propagated precision. It returns one of:
\begin{itemize}
\item \texttt{OUTSIDE\_DOMAIN}: the requested task is not in the declared model;
\item \texttt{CORRESPONDENCE}: scale or labels remain unresolved;
\item \texttt{STRUCTURAL\_WALL}: the required target rank is absent;
\item \texttt{NO\_RETURN}: the detection gate fails;
\item \texttt{INCONSISTENT}: an equivalence, shape, closure, or held-out gate fails;
\item \texttt{ESCALATE}: propagated precision misses the declared task target;
\item \texttt{CONDITIONALLY\_CERTIFIED}: the supplied structural declarations and measured gates meet this protocol's contract.
\end{itemize}
The last status is not a probability that the model is true. Structural fields are supplied from the declared model and protocol; the dispatcher does not infer an arbitrary room's path identity or medium from one waveform.

The residual tolerance is $3$ mm, the maximum coordinate standard uncertainty is $5$ mm, and the shape-score limit is $4$. The primary maximum shape score is @@SHAPEMAX@@. Early--late training-anchor differences have an approximate 90 percent Gaussian equivalence bound @@EQUIV@@ mm, below the $3$ mm margin. This supports only those two anchor windows under the declared sampling model, not global stationarity of a physical room.

For fixed structural inputs, the critical residual margin is the larger of the closure and held-out residuals. Increasing the tolerance can admit more records, but cannot supply a missing scale or label. Multiple numerical gates are not assigned a joint nominal 95 percent false-certification rate. The 95 percent coverage result below belongs to the separately specified position ellipsoid.

\section{Executed results}
\label{sec:results}
\begin{table}[htbp]\centering\small
\caption{Final frozen-source runs. Timing RMSE and position RMS are conditional waveform errors. Coverage is from the separate 20,000-draw feature experiment. The first row is development; the remaining rows are validation seeds.}
\begin{tabular}{rrrrr}\toprule
seed & timing RMSE ($\mu$s) & position RMS (mm) & held-out residual (mm) & coverage (\%)\\\midrule
@@RESULTROWS@@
\bottomrule\end{tabular}
\end{table}

All five runs pass the 30 specified checks and detect the 19 named negative controls. These are five repetitions of the same control designs, not 95 independent fault classes. The four validation seeds were not used to tune the final numerical limits.

\paragraph{Primary waveform result.}
Arrival RMSE is $.896$ microseconds. After aggregate-offset subtraction and the declared clock conversion, path-duration RMSE is @@DURATION@@ microseconds. Position RMS is $.145$ mm and the maximum position error is $.357$ mm. The maximum opposite-wall closure residual is $.672$ mm. The third-anchor mean residual is $.0677$ mm. Conditional on the declared clock rate, the fitted slope implies $c_m=@@SPEED@@$ m/s; this is derived from the same range calibration, not an independent medium validation.

\paragraph{Noise-only records.}
There are zero detections in 200 noise-only trials per seed. The one-sided 95 percent binomial upper bound is $1.487$ percent per seed, not zero. Pooling the 1,000 independently generated noise-only records under the same frozen detector gives an upper bound of approximately $.299$ percent. Neither bound applies automatically to coloured or nonstationary measured noise.

\paragraph{Uncertainty.}
Joint ellipsoid coverage ranges from $94.825$ to $95.105$ percent. At 20,000 trials the nominal binomial standard error near $.95$ is approximately $.154$ percentage points. The acceptance band $.93$--$.97$ is a fixed engineering gate, not a confidence interval for all results. The floor experiment retains near-95 percent coverage under its full model; at 256 repetitions, the primary white-only interval covers only $6.84$ percent.

\paragraph{Falsified stronger claims.}
A left--right swap leaves closure unchanged but produces about $2.776$ m position RMS. A hidden doubled pulse width gives a median shape score about $168.44$, versus about $1.15$ for the amplitude-only control. A quadratic timing distortion fits both training anchors exactly yet misses the third by about $12.13$ mm. A separated second pulse gives shape score @@MULTI@@, while the exact coarrival alternative remains observationally indistinguishable.

\begin{figure}[htbp]\centering
\includegraphics[width=\textwidth]{walltap_results_figure.png}
\caption{Recorded synthetic outputs, development seed. Upper left: four separately acquired labelled paths overlaid for display, not one simultaneous four-echo recording. Upper right: conditional position errors. Lower left: coverage with and without a common scalar timing floor. Lower right: the declared response-energy statistic for three decay times. The panels have different tasks and uncertainty assumptions; their units are not merged.}
\end{figure}

\section{Falsification design and audit interpretation}
\label{sec:falsification}
The audit has three kinds of evidence.
\begin{enumerate}
\item \emph{Positive numerical recovery:} waveform extraction, calibration, localization, closure, and covariance coverage under the declared model.
\item \emph{Analytic or numerical counterexamples:} unresolved scale, label reflection, gain--reflectivity fibre, fold, shrinking-noise law, bistatic geometry, and coarrival.
\item \emph{Mutation controls:} ten gate-removal mutations run through the same dispatcher, plus nine executed numerical, waveform, drift, or access controls.
\end{enumerate}
Gate-removal controls deliberately supply one failed evidence field and verify that bypassing that field changes the decision incorrectly. They test the implementation of a specified contract. They do not show that every failed physical assumption will be recognized from raw data. The coarrival example demonstrates why such a universal claim would be false.

A calibrated factor-of-two convention deserves particular care. If an arbitrary slope is fitted from range anchors, a consistent redefinition of that slope can absorb a factor of two. The executed scale mutation therefore doubles already calibrated ranges without refitting. It detects an inconsistent decoder, not an independent experimental proof of the round-trip convention. The physical monostatic versus bistatic distinction is tested separately by the path model.

The held-out access canary is an API-level guard. It does not certify against arbitrary malicious code. The saved-record replay is stronger than merely repeating the generator: it recomputes arrivals from archived waveforms. The independent verifier uses a separate two-mean calibration formula and finite-difference derivatives rather than trusting the stored regression output.

\section{Limits and the physical interpretation}
The main positive theorem assumes a correct first-order path model, homogeneous still propagation, known geometry, external labels, and stationary aggregate response. A finite held-out success cannot prove these globally. An unresolved additional path, an unobserved medium change, or a device response outside the tested family may preserve the checked features while changing a desired latent interpretation.

The synthetic study is deliberately favourable: no diffuse room tail is added to the localization waveforms, no clipping or automatic gain control is simulated, and the pulse family used for fitting matches the generator. The separate rhythm model is not a measured impulse response. The separate gain, entropy, and transport calculations are consistency examples, not extra physical measurements.

The paper does not establish a unique geometry among all conceivable models. It establishes the stated inverse within its candidate class and records exact alternatives outside identifiable tasks. A Fisher tensor is not converted to metres without anchors. A passed pulse-shape score is not proof of a single reflection. A high local rank is not proof of global label separation. A small standard error is not a bound on unmodelled physical bias.

A physical implementation would require an external low-level source or controlled tapper, a trigger or reference channel, independent clock and range calibration, documented source--receiver geometry, medium observations, and retained unprocessed recordings. No head or body impact is part of the protocol. These are requirements for an empirical implementation, not activities performed in this computational run. No compliance with an acoustic measurement standard is asserted.

\section{Conclusion}
The wall--tap experiment has a precise mature interpretation. A raw latency is decomposed only to the extent justified by calibration. A propagation duration constrains a path through a specified medium. Independent anchors and a valid path model permit distances in metres. Sufficient labelled paths identify a position in a known enclosure, while closure and held-out anchors provide opportunities for falsification. Covariance and unresolved fibres remain part of the result.

The completed waveform experiment and its independent audit support that conditional account. They do not turn synthetic records into measured acoustics or finite gates into a proof of every premise. The final result is a reproducible acoustic inverse problem with explicit positive theorems, explicit counterexamples, recorded uncertainty, and a documented boundary between what the record identifies and what remains assumed.

\appendix
\section{Complete check ledger}
The identifiers below belong to this final source. They are not inherited pass counts from earlier manuscripts. Auxiliary algebraic checks support the stated modelling discipline; they are not counted as additional acoustic observations.
\small\setlength{\tabcolsep}{3pt}
\begin{longtable}{@{}P{.08\textwidth}P{.53\textwidth}P{.23\textwidth}P{.07\textwidth}@{}}
\toprule ID & claim tested & evidence type & result\\\midrule\endhead
@@LEDGER@@
\bottomrule\end{longtable}\normalsize\setlength{\tabcolsep}{6pt}

\section{Complete negative-control ledger}
All nineteen named controls are detected on every final seed. ``Detected'' means that the specified test exposes the injected error; it is not a universal fault-coverage claim.
\small\setlength{\tabcolsep}{3pt}
\begin{longtable}{@{}P{.42\textwidth}P{.39\textwidth}P{.1\textwidth}@{}}
\toprule control & type & result\\\midrule\endhead
@@CANARIES@@
\bottomrule\end{longtable}\normalsize\setlength{\tabcolsep}{6pt}

\section{Auxiliary consistency calculations}
\subsection{Finite fibre entropy}
For a finite latent distribution $p(q,z)$, ordinary Shannon entropy satisfies
\[
 H(Q,Z)=H(Q)+\sum_qp(q)H(Z\mid Q=q).
\]
The archived example uses masses $.1,.2,.3,.4$ on two observable classes with two latent states each. The identity is checked numerically. A maximum-entropy completion on a finite unresolved fibre would be uniform only relative to a declared counting measure and constraints. No coordinate-free differential-entropy decomposition or unique physical prior is inferred.

\subsection{Projectability without a unique latent lift}
For the projection $\pi(x,z)=x$, two latent vectors $(1,0)$ and $(1,4)$ have the same observable velocity. A choice between them needs additional structure. Conversely, assigning observable velocities $1$ and $3$ to representatives of the same fibre is not projectable. This finite example tests representative independence, not a reconstructed room connection.

\subsection{Naturality does not select the statistical metric}
On a Bernoulli law image, both $dp^2$ and $dp^2/[p(1-p)]$ are invariant under outcome exchange, but are not constant multiples. This example prevents interpreting the descent of a chosen statistical structure as its unique selection. In the acoustic experiment the likelihood and covariance model are declared; the Fisher tensor follows from them.

\subsection{Indefinite pullbacks are not used to justify acoustic rank}
The acoustic Fisher argument uses positive-definite observation covariance. For a general symmetric tensor, ambient nondegeneracy alone would not guarantee a nondegenerate restriction to an image tangent. No indefinite-radical inference is needed for the position theorem. Its rank follows directly from the displayed path Jacobian.

\section{Uncertainty and record schema}
\begin{table}[htbp]\centering\small
\begin{tabular}{@{}P{.25\textwidth}P{.31\textwidth}P{.35\textwidth}@{}}\toprule
source & implemented treatment & scope or limitation\\\midrule
sample noise & independent Gaussian waveform samples & no coloured-noise claim\\
arrival extraction & blind matched filter and interpolation & known pulse family; high SNR\\
aggregate latency & two-anchor intercept fit & individual apparatus delays not separated\\
clock rate & external declared $a$ & not estimated from echo data\\
range scale & two-anchor slope fit & same path/medium model required\\
anchor uncertainty & $.5$ mm per calibration length in feature covariance & not present in nominal waveform truth\\
room extents & known $W,H$; $.5$ mm feature uncertainties & not unknown-room reconstruction\\
common timing & $3\,\mu$s feature component & cancels in opposite-wall position differences\\
scalar repetition floor & separate $35\,\mu$s common error & a different scalar timing experiment\\
path labels & external isolated-path identity & closure cannot certify labels\\
response mismatch & shape and held-out controls & unresolved coarrival survives\\
model discrepancy & exposed by selected alternatives & no universal discrepancy bound estimated\\\bottomrule
\end{tabular}\end{table}

\paragraph{Archived arrays.}
For each seed, \texttt{walltap\_raw\_<seed>.npz} stores the synthetic origin flag, sample rate, wall labels, calibration, held-out, room and silence waveforms, and extracted features. \texttt{walltap\_evaluation\_<seed>.npz} stores evaluation positions and true readouts separately. \texttt{walltap\_auxiliary\_<seed>.npz} stores feature-level Monte Carlo inputs and errors, the covariance and Jacobian, and raw mismatch controls. The raw archive is not an audio recording from a physical room.

\paragraph{Measured-data boundary.}
The estimator functions can operate on sampled arrays, but the supplied command-line experiment is a synthetic generator and replay tool. It is not a validated general WAV ingestion, peak-assignment, or real-room analysis system. A measured-data adapter would need explicit trigger conventions, channel metadata, units, calibration records, and model validation before its output could be given the same interpretation.

\section{Reproducibility and source identity}
The complete package contains the main experiment, an independent verifier, this print builder, the frozen protocol, per-seed results, raw and evaluation arrays, replay results, the check CSV, thesis ledger, figures, logs, and a SHA-256 manifest.
\begin{verbatim}
python walltap_final.py --out .
python walltap_final.py --out . --replay
python walltap_verify.py --out .
python walltap_make_print.py --out .
pdflatex Wall_Tap_Delay_Final_Print.tex
pdflatex Wall_Tap_Delay_Final_Print.tex
\end{verbatim}
The final run uses Python @@PYTHON@@, NumPy @@NUMPY@@, and SciPy @@SCIPY@@. Matplotlib generates the numerical figure. The verifier checks source and protocol hashes, the two-mean calibration identity, covariance propagation, exact coarrival, and the complete result counts. The replay checks all five saved raw datasets without generating new signals. The bootstrap uses seed $88421$ and 2,000 replicates.

\paragraph{Main source SHA-256.}
\noindent\texttt{\small @@SOURCEHASH@@}

\paragraph{Protocol SHA-256.}
\noindent\texttt{\small @@PROTOCOLHASH@@}

The hashes identify this run, not an independently registered scientific priority claim. Archive byte hashes may change when regenerated containers include new timestamps even when their numerical arrays are equal. Source changes require a new recorded execution; a PDF alone is not a substitute for the executable record.

\begin{thebibliography}{9}
\bibitem{RG} M. Rada, \emph{Resolution Geometry: Indistinguishability, Its Symmetries, and the Geometry of What Observations Determine}, supplied repaired print edition, October 2026. Used for exact-law, task-factorization, and conditional-rigidity terminology; the acoustic statements needed here are proved in the present paper.
\bibitem{Allen} J. B. Allen and D. A. Berkley, Image method for efficiently simulating small-room acoustics, \emph{Journal of the Acoustical Society of America} 65 (1979), 943--950.
\bibitem{Kuttruff} H. Kuttruff, \emph{Room Acoustics}, 6th ed., CRC Press, 2016.
\bibitem{Code} \emph{walltap\_final.py}, \emph{walltap\_verify.py}, frozen protocol and recorded results accompanying this paper, October 2026. All new numerical results in this print are from these computational records.
\end{thebibliography}
\end{document}
'''
if __name__=='__main__':main()
