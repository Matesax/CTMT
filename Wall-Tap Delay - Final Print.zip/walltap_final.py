#!/usr/bin/env python3
"""Wall-Tap Delay: self-contained synthetic waveform experiment and hostile audit.
Run: python walltap_final.py --out .
No measured audio is supplied or claimed. Dependencies: numpy scipy matplotlib.
The fixed protocol is written and hashed before generation. Evaluation truth is
not an estimator argument. All mutation controls run through the same dispatcher.
"""
import argparse, csv, hashlib, json, math, platform, sys, time
from pathlib import Path
import numpy as np
import scipy
from scipy.signal import correlate
from scipy.stats import norm, chi2
from scipy.integrate import quad
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

PROTOCOL = dict(version='WT-final-1.0', origin='SYNTHETIC', fs=48000, seconds=.04,
    pulse_width_s=90e-6, noise_sd=.015, onset_s=.0017, clock_rate=1.00012,
    sound_speed_m_s=343.2, room_m=[6.,5.], repeats=12,
    positions_m=[[1.1,1.3],[1.8,3.4],[2.6,1.9],[3.7,2.8],[4.5,1.1],[4.9,3.7]],
    anchor_distances_m=[.8,3.5], anchor_repeats=60, heldout_anchor_m=2.1,
    silence_trials=200, development_seed=20261020, validation_seeds=[17,83,409,2027],
    feature_mc=20000, calibration_anchor_sd_m=.0005, extent_sd_m=.0005,
    shared_timing_floor_s=3e-6, detection_z=7., waveform_rmse_limit_s=10e-6,
    position_rms_limit_m=.005, heldout_tolerance_m=.003,
    shape_reduced_chi2_limit=4., coverage_interval=[.93,.97],
    mc_sd_ratio_interval=[.9,1.1], uncertainty_precision_m=.005)


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dump(path,obj): Path(path).write_text(json.dumps(obj,indent=2,allow_nan=False,default=lambda x:x.item() if isinstance(x,np.generic) else str(x)))
def scalar(x): return float(x)
def register(rows,ident,claim,passed,evidence):
    rows.append(dict(id=ident,claim=claim,passed=bool(passed),evidence=evidence))
def cov_ok(p): return PROTOCOL['coverage_interval'][0]<=p<=PROTOCOL['coverage_interval'][1]
def inrange(v,a): return a[0]<=v<=a[1]

def template(width=None):
    fs=PROTOCOL['fs']; w=width or PROTOCOL['pulse_width_s']; k=int(np.ceil(6*w*fs))
    t=np.arange(-k,k+1)/fs
    return np.exp(-.5*(t/w)**2)

def waveform(arrival,rng,amplitude=.8,width=None,second=None):
    t=np.arange(round(PROTOCOL['seconds']*PROTOCOL['fs']))/PROTOCOL['fs']
    w=width or PROTOCOL['pulse_width_s']
    y=amplitude*np.exp(-.5*((t-arrival)/w)**2)
    if second is not None:
        delay,amp=second; y+=amp*np.exp(-.5*((t-delay)/w)**2)
    return (y+rng.normal(0,PROTOCOL['noise_sd'],len(t))).astype(np.float32)

def extract(y):
    """Blind arrival search. No true arrival, range or position is an input.
    Fixed search: 1--37 ms. Noise estimated from the first 0.7 ms.
    Returns time in recorder seconds, amplitude, detection and local shape fit.
    """
    fs=PROTOCOL['fs']; p=template(); pp=p@p
    noise=np.std(y[:int(.0007*fs)],ddof=1)
    corr=correlate(y,p,mode='same',method='direct')
    lo=int(.001*fs); hi=min(len(y)-len(p),int(.037*fs))
    k=lo+int(np.argmax(corr[lo:hi])); z=corr[k]/(max(noise,1e-12)*np.sqrt(pp))
    den=corr[k-1]-2*corr[k]+corr[k+1]
    frac=.5*(corr[k-1]-corr[k+1])/den if den<0 else 0.
    frac=float(np.clip(frac,-.5,.5)); arrival=(k+frac)/fs
    ix=np.arange(max(0,k-len(p)//2),min(len(y),k+len(p)//2+1))
    model=np.exp(-.5*((ix/fs-arrival)/PROTOCOL['pulse_width_s'])**2)
    amp=np.dot(y[ix],model)/np.dot(model,model)
    red=np.sum((y[ix]-amp*model)**2)/(max(noise,1e-12)**2*max(1,len(ix)-2))
    return np.array([arrival,amp,z,red],float)

def extract_many(y): return np.array([extract(row) for row in y])

def fit_calibration(times,anchor_lengths):
    """Affine recorder-time versus externally anchored range. No heldout input."""
    n=times.shape[1]; A=np.column_stack([np.ones(2*n),np.repeat(anchor_lengths,n)])
    beta=np.linalg.lstsq(A,times.ravel(),rcond=None)[0]
    residual=times.ravel()-A@beta; sig=np.std(residual,ddof=2)
    return beta,sig,sig**2*np.linalg.inv(A.T@A)

def decode(times,beta,extents,half_mutation=False):
    b,q=beta
    ranges=(times-b)/q
    if half_mutation: ranges*=2
    W,H=extents
    xy=np.column_stack([(ranges[:,0]+W-ranges[:,1])/2,(ranges[:,2]+H-ranges[:,3])/2])
    closure=np.column_stack([ranges[:,0]+ranges[:,1]-W,ranges[:,2]+ranges[:,3]-H])
    return xy,ranges,closure

class HeldoutTruth:
    def __init__(self,values): self._values=values; self.access=[]
    def read(self,purpose):
        self.access.append(purpose)
        if purpose!='evaluation': raise PermissionError('Held-out truth is not an estimator input')
        return self._values.copy()

def certificate(e,tolerance=.003,precision=.005,mutation=None):
    """One dispatcher for nominal evidence and all gate-removal mutations.
    Structural inputs precede numerical tolerances. This is a finite explicit
    implementation of this protocol, not a universal RG theorem prover.
    """
    e=dict(e)
    if mutation is not None:
        if mutation=='ignore_domain': e['domain']=True
        elif mutation=='ignore_scale': e['scale']=True
        elif mutation=='ignore_labels': e['labels']=True
        elif mutation=='ignore_rank': e['rank']=True
        elif mutation=='ignore_detection': e['detected']=True
        elif mutation=='ignore_shape': e['shape']=0.
        elif mutation=='ignore_stationarity': e['stationary']=True
        elif mutation=='ignore_holdout': e['heldout_residual']=0.
        elif mutation=='ignore_uncertainty': e['sd']=0.
        elif mutation=='ignore_closure': e['closure']=0.
    if not e['domain']: return 'OUTSIDE_DOMAIN'
    if not e['scale'] or not e['labels']: return 'CORRESPONDENCE'
    if not e['rank']: return 'STRUCTURAL_WALL'
    if not e['detected']: return 'NO_RETURN'
    if not e['stationary']: return 'INCONSISTENT'
    if e['shape']>PROTOCOL['shape_reduced_chi2_limit']: return 'INCONSISTENT'
    if e['closure']>tolerance or e['heldout_residual']>tolerance: return 'INCONSISTENT'
    if e['sd']>precision: return 'ESCALATE'
    return 'CONDITIONALLY_CERTIFIED'

def gate_canaries(base):
    cases=[('domain',False,'ignore_domain'),('scale',False,'ignore_scale'),
      ('labels',False,'ignore_labels'),('rank',False,'ignore_rank'),
      ('detected',False,'ignore_detection'),('shape',10.,'ignore_shape'),
      ('stationary',False,'ignore_stationarity'),('heldout_residual',.02,'ignore_holdout'),
      ('sd',.02,'ignore_uncertainty'),('closure',.02,'ignore_closure')]
    out=[]
    for key,value,mut in cases:
        e=dict(base); e[key]=value
        correct=certificate(e); wrong=certificate(e,mutation=mut)
        out.append(dict(id=mut,baseline=correct,mutant=wrong,
            caught=correct!='CONDITIONALLY_CERTIFIED' and wrong=='CONDITIONALLY_CERTIFIED'))
    return out

def run(seed,outdir):
    rng=np.random.default_rng(seed); P=PROTOCOL; rows=[]; raw={}
    fs=P['fs']; c=P['sound_speed_m_s']; a=P['clock_rate']; b=P['onset_s']; q=2*a/c
    # Calibration data and a separate held-out anchor. The estimator receives
    # only the two training lengths and their waveforms.
    anchors=np.array(P['anchor_distances_m']); n=P['anchor_repeats']
    cal=np.array([[waveform(b+q*d,rng) for _ in range(n)] for d in anchors])
    calfeat=extract_many(cal.reshape(-1,cal.shape[-1])).reshape(2,n,4)
    beta,sig,Vbeta=fit_calibration(calfeat[:,:,0],anchors)
    hold=np.array([waveform(b+q*P['heldout_anchor_m'],rng) for _ in range(n)])
    hf=extract_many(hold); holdpred=(hf[:,0]-beta[0])/beta[1]
    holdres=abs(np.mean(holdpred)-P['heldout_anchor_m'])
    pos=np.array(P['positions_m']); truth=HeldoutTruth(np.repeat(pos,P['repeats'],axis=0))
    allpos=np.repeat(pos,P['repeats'],axis=0); W,H=P['room_m']
    distances=np.column_stack([allpos[:,0],W-allpos[:,0],allpos[:,1],H-allpos[:,1]])
    expected=b+q*distances
    room=np.array([[waveform(t,rng,amplitude=amp) for t,amp in zip(ts,[.9,.8,.75,.7])] for ts in expected])
    feat=extract_many(room.reshape(-1,room.shape[-1])).reshape(len(room),4,4)
    xy,ranges,closure=decode(feat[:,:,0],beta,[W,H])
    evaluated=truth.read('evaluation'); err=xy-evaluated
    rmse=np.sqrt(np.mean((feat[:,:,0]-expected)**2)); posrms=np.sqrt(np.mean(np.sum(err**2,axis=1)))
    silence=np.array([waveform(.02,rng,amplitude=0) for _ in range(P['silence_trials'])]); sf=extract_many(silence)
    false=int(np.sum(sf[:,2]>P['detection_z'])); upper=1-.05**(1/len(sf)) if false==0 else None
    raw.update(origin=np.array('SYNTHETIC'),sampling_rate=np.array(fs),wall_labels=np.array(['left','right','bottom','top']),calibration=cal,heldout=hold,room=room,silence=silence,
        calibration_features=calfeat,heldout_features=hf,room_features=feat)
    np.savez_compressed(outdir/f'walltap_raw_{seed}.npz',**raw)
    np.savez_compressed(outdir/f'walltap_evaluation_{seed}.npz',positions=evaluated,true_times=expected)
    register(rows,'WT01','Exact equality, not a tolerance relation, defines the kernel',
      .75<=1 and .75<=1 and 1.5>1,dict(tolerance=1.,points=[0.,.75,1.5],nontransitive=True))
    register(rows,'WT02','Blind waveform arrivals and raw apparatus bias',rmse<P['waveform_rmse_limit_s'] and np.all(feat[:,:,2]>P['detection_z']),
      dict(arrival_rmse_us=rmse*1e6,raw_apparatus_bias_us=b*1e6,minimum_detection_z=np.min(feat[:,:,2]),records=len(room)*4))
    register(rows,'WT03','Noise-only control reports a finite upper bound',false==0,
      dict(false_positives=false,trials=len(sf),one_sided95_upper=upper,max_noise_z=np.max(sf[:,2])))
    register(rows,'WT04','Two training anchors predict a third held-out range',holdres<P['heldout_tolerance_m'],
      dict(fitted_offset_s=beta[0],fitted_slope_s_m=beta[1],true_slope_s_m=q,
           heldout_residual_m=holdres,timing_residual_sd_us=sig*1e6,calibration_covariance=Vbeta.tolist()))
    register(rows,'WT05','Labelled first-order paths recover six 2D positions',posrms<P['position_rms_limit_m'],
      dict(position_rms_m=posrms,max_error_m=np.max(np.linalg.norm(err,axis=1)),trials=len(room),target_rank=2))
    register(rows,'WT06','Independent opposite-wall closure checks the declared model',np.max(np.abs(closure))<.003,
      dict(closure_rms_m=np.sqrt(np.mean(closure**2)),closure_max_m=np.max(np.abs(closure)),
           label_status='protocol-supplied isolated wall channels, not inferred from peaks'))
    # Feature-level uncertainty experiment: separate from waveform extraction.
    # Two uncertain anchor lengths share their errors across calibration repeats.
    # Exact synthetic time means and their uncertainty are supplied; waveform
    # residual sigma sets the white timing scale, with a declared common floor.
    N=P['feature_mc']; sdlen=P['calibration_anchor_sd_m']; floor=P['shared_timing_floor_s']
    # analytic calibration covariance in (b,q), including anchor uncertainty
    A=np.column_stack([np.ones(2),anchors]); Ai=np.linalg.inv(A)
    Vcal=Ai@np.diag(np.full(2,sig**2/n+q*q*sdlen**2))@Ai.T
    point=np.array([1.8,3.4]); ds=np.array([point[0],W-point[0],point[1],H-point[1]])
    tt=b+q*ds
    # inputs: tL,tR,tB,tT,b,q,W,H
    Vin=np.zeros((8,8)); Vin[:4,:4]=np.eye(4)*sig**2+np.ones((4,4))*floor**2
    Vin[4:6,4:6]=Vcal; Vin[6:,6:]=np.eye(2)*P['extent_sd_m']**2
    J=np.zeros((2,8)); J[0,0]=1/(2*q); J[0,1]=-1/(2*q); J[0,5]=-(point[0]-W/2)/q; J[0,6]=.5
    J[1,2]=1/(2*q); J[1,3]=-1/(2*q); J[1,5]=-(point[1]-H/2)/q; J[1,7]=.5
    Vxy=J@Vin@J.T
    perturb=rng.multivariate_normal(np.zeros(8),Vin,N); inp=np.r_[tt,b,q,W,H]+perturb
    dmc=(inp[:,:4]-inp[:,4,None])/inp[:,5,None]
    xmc=np.column_stack([(dmc[:,0]+inp[:,6]-dmc[:,1])/2,(dmc[:,2]+inp[:,7]-dmc[:,3])/2]); emc=xmc-point
    mahal=np.einsum('ni,ij,nj->n',emc,np.linalg.inv(Vxy),emc)
    cov=float(np.mean(mahal<=chi2.ppf(.95,2))); ratios=np.sqrt(np.diag(np.cov(emc.T))/np.diag(Vxy))
    register(rows,'WT07','Full covariance propagation has joint 95 percent coverage',cov_ok(cov) and all(inrange(v,P['mc_sd_ratio_interval']) for v in ratios),
      dict(coverage95=cov,mc_trials=N,predicted_covariance_m2=Vxy.tolist(),empirical_sd_ratios=ratios.tolist(),
           covariance_input_order=['tL','tR','tB','tT','b','q','W','H'],common_trigger_cancels_in_position=True))
    # Label permutation preserves closure but changes the target chart.
    swapped=feat[:,:,0][:,[1,0,2,3]]; badxy,_,badclosure=decode(swapped,beta,[W,H])
    mirrorerror=np.sqrt(np.mean(np.sum((badxy-evaluated)**2,axis=1)))
    register(rows,'WT08','Unlabelled paths leave an exact reflection ambiguity',mirrorerror>.5 and np.max(np.abs(badclosure-closure))<1e-10,
      dict(swapped_position_rms_m=mirrorerror,closure_change_m=np.max(np.abs(badclosure-closure)),
           status='CORRESPONDENCE without external wall identity; closure alone is insufficient'))
    Jscale=np.array([[1.,-1.]])
    register(rows,'WT09','Delay-speed and single-anchor affine fibres are unresolved',np.linalg.matrix_rank(Jscale)==1,
      dict(equal_delay_pairs=[[2.,340.],[2.1,357.]],delays_s=[4/340,4.2/357],
           one_anchor_rank=1,two_affine_parameters=2,status='CORRESPONDENCE without sufficient calibration'))
    r=.6; g=1.2; noise=.03; j=np.array([g,r])/noise; I=np.outer(j,j); efficient=I[0,0]-I[0,1]**2/I[1,1]
    ja=np.array([[g,r],[0.,1.]])/noise; Ia=ja.T@ja; anchored=Ia[0,0]-Ia[0,1]**2/Ia[1,1]
    register(rows,'WT10','Gain nuisance prevents absolute reflectivity without a reference',abs(efficient)<1e-10 and anchored>0,
      dict(efficient_information_without_reference=efficient,with_reference=anchored))
    w=.0035; delta=.001; amp=.6; even=lambda z:amp*np.exp(-(z/w)**2)
    hs=np.array([1e-4,5e-5,2.5e-5]); jets=np.array([(even(h)-even(0))/h**2 for h in hs]); jetref=-amp/w**2
    register(rows,'WT11','Even overlap has a fold; signed channel resolves the pair',even(delta)==even(-delta) and abs(jets[-1]/jetref-1)<.001,
      dict(even_pair_difference=even(delta)-even(-delta),signed_pair_difference=2*amp*np.tanh(delta/w),
           second_order_coefficient=jetref,jet_estimates=jets.tolist(),fold_derivative=0.))
    eps=np.array([.1,.03,.01,.003]); sd=.04
    # Gaussian Hellinger squared, one reflected mean epsilon.
    hell=np.sqrt(-np.expm1(-eps**2/(8*sd**2))); shrink=np.sqrt(-np.expm1(-np.ones(4)/(8*sd**2)))
    slope=np.polyfit(np.log(eps[-3:]),np.log(hell[-3:]),1)[0]
    register(rows,'WT12','Mean convergence alone does not imply distinguishability collapse',.95<slope<1.05 and np.ptp(shrink)<1e-12,
      dict(epsilon=eps.tolist(),fixed_noise_hellinger=hell.tolist(),shrinking_noise_hellinger=shrink.tolist(),small_epsilon_slope=slope))
    pp=np.linspace(.05,.95,100); ratio=1/(pp*(1-pp))
    register(rows,'WT13','Descent and relabelling invariance do not select a metric',np.ptp(ratio)>10 and np.max(abs(ratio-ratio[::-1]))<1e-10,
      dict(fisher_to_euclidean_ratio_range=[np.min(ratio),np.max(ratio)],metric_selection='declared Gaussian law, not derived from quotient'))
    counts=np.array([1,4,16,64,256]); su=25e-6; sb=35e-6; sds=np.sqrt(su**2/counts+sb**2); covfloor=[]; naive=[]
    for count,ss in zip(counts,sds):
        ee=rng.normal(0,su/np.sqrt(count),N)+rng.normal(0,sb,N)
        covfloor.append(float(np.mean(abs(ee)<=norm.ppf(.975)*ss)))
        naive.append(float(np.mean(abs(ee)<=norm.ppf(.975)*su/np.sqrt(count))))
    register(rows,'WT14','Repetition retains a common timing floor',all(cov_ok(v) for v in covfloor) and naive[-1]<.2,
      dict(repeats=counts.tolist(),sd_us=(sds*1e6).tolist(),coverage95=covfloor,white_only_coverage95=naive,common_floor_us=35.))
    # Plane wall x=0, image source (-sx,sy); bistatic half path is not sx.
    source=np.array([1.,0.]); receiver=np.array([3.,5.]); image=source*np.array([-1.,1.]); ell=np.linalg.norm(receiver-image)
    register(rows,'WT15','The monostatic half-factor is not a general wall distance',abs(ell/2-source[0])>1.,
      dict(bistatic_path_m=ell,half_path_m=ell/2,source_normal_distance_m=source[0],status='PATH_SUM, not normal distance'))
    D=3.; wind=8.; tp=D/(c+wind); tm=D/(c-wind); recovered_w=D/2*(1/tp-1/tm); naiveD=c*(tp+tm)/2
    register(rows,'WT16','Reciprocal propagation identifies declared uniform wind',abs(recovered_w-wind)<1e-10 and naiveD>D,
      dict(wind_m_s=wind,recovered_wind_m_s=recovered_w,naive_still_air_distance_m=naiveD,true_distance_m=D))
    grad=3.; L=3.; sl1=quad(lambda z:1/(c+grad*(z-L/2)),0,L)[0]; sl2=quad(lambda z:1/(c-grad*(z-L/2)),0,L)[0]
    register(rows,'WT17','Integrated slowness does not identify a medium profile',abs(sl1-sl2)<1e-14,
      dict(equal_one_way_delays_s=[sl1,sl2],opposite_endpoint_speed_differences_m_s=[-grad*L,grad*L],status='CORRESPONDENCE for profile'))
    ts=np.array([.01,.02,.04]); rate=1.13; offset=.4; measured=offset+rate*ts
    inv=(measured-offset)/rate; warp=ts+.8*ts**2
    register(rows,'WT18','Clock calibration distinguishes affine rate from nonlinear warp',np.max(abs(inv-ts))<1e-15 and abs(warp[2]/warp[1]-ts[2]/ts[1])>.01,
      dict(affine_inverse_error_s=np.max(abs(inv-ts)),uncalibrated_rate=rate,warp_ratio_change=warp[2]/warp[1]-ts[2]/ts[1]))
    tails=np.array([.025,.06,.14]); tc=[]
    for tail in tails:
        ttgrid=np.arange(0,2.,1/fs); energy=np.exp(-ttgrid/tail); cum=np.cumsum(energy); cum/=cum[-1]
        tc.append(float(np.interp(.5,cum,ttgrid)))
    tref=tails*np.log(2)
    register(rows,'WT19','A declared energy-overlap threshold depends on response tail',np.max(abs(np.array(tc)-tref))<2/fs and max(tc)/min(tc)>5,
      dict(energy_decay_s=tails.tolist(),sampled_transition_s=tc,analytic_transition_s=tref.tolist(),threshold=.5,
           interpretation='response-energy statistic, not human localization'))
    # Arrival FIM for two pulses: unknown delays, known amplitudes; a local bound only.
    def info(separation,width):
        tt=np.arange(-.003,.003,1/fs); z1=tt+separation/2; z2=tt-separation/2
        J=np.column_stack([z1/width**2*np.exp(-.5*(z1/width)**2),z2/width**2*np.exp(-.5*(z2/width)**2)])
        return J.T@J/P['noise_sd']**2
    seps=np.array([0.,1e-6,1e-5,1e-4,5e-4]); eigs=[np.linalg.eigvalsh(info(d,P['pulse_width_s']))[0] for d in seps]
    register(rows,'WT20','Coincident echoes lose local delay rank',abs(eigs[0])<1 and eigs[-1]>eigs[1]*100,
      dict(separations_s=seps.tolist(),minimum_information=eigs,interpretation='known-amplitude local information, not a detection guarantee'))
    # Measured waveform controls: gain change versus shape mismatch and missing echo.
    normal_raw=np.array([waveform(.014,rng,amplitude=.5) for _ in range(40)])
    filtered_raw=np.array([waveform(.014,rng,width=2*P['pulse_width_s']) for _ in range(40)])
    missing_raw=waveform(.014,rng,amplitude=0)
    normal=extract_many(normal_raw); filtered=extract_many(filtered_raw); missing=extract(missing_raw)
    register(rows,'WT21','Gain-only equivalence does not cover a hidden filter',np.median(normal[:,3])<4 and np.median(filtered[:,3])>4,
      dict(gain_control_median_shape=np.median(normal[:,3]),hidden_filter_median_shape=np.median(filtered[:,3]),missing_return_z=missing[2]))
    # Actual nonlinear calibration misspecification, two training anchors, third heldout.
    nonlinear=lambda d:b+q*d+.00004*d*d
    Ab=np.column_stack([np.ones(2),anchors]); betabad=np.linalg.solve(Ab,nonlinear(anchors)); badheld=(nonlinear(2.1)-betabad[0])/betabad[1]
    register(rows,'WT22','Two fitted anchors do not establish global affine response',abs(badheld-2.1)>.003,
      dict(nonlinear_heldout_prediction_m=badheld,residual_m=badheld-2.1,training_residual_s=np.max(abs(Ab@betabad-nonlinear(anchors)))))
    V=np.array([[2.,.4],[.4,1.]]); B=np.array([[2.,1.],[-.3,1.5]]); v=np.array([.2,-.4])
    d0=v@np.linalg.solve(V,v); d1=(B@v)@np.linalg.solve(B@V@B.T,B@v)
    register(rows,'WT23','Invertible feature charts preserve covariance-aware distance',abs(d0-d1)<1e-12,
      dict(mahalanobis_original=d0,mahalanobis_transformed=d1))
    # Finite entropy chain rule: latent states (observable q, unresolved sign).
    p=np.array([[.1,.2],[.3,.4]]); pq=p.sum(axis=1); ent=lambda z:-np.sum(z[z>0]*np.log(z[z>0])); Hx=ent(p.ravel()); Hq=ent(pq); Hf=sum(pq[i]*ent(p[i]/pq[i]) for i in range(2))
    register(rows,'WT24','Finite observable/fibre entropy uses a declared measure',abs(Hx-Hq-Hf)<1e-14,
      dict(total_nats=Hx,observable_nats=Hq,fibre_nats=Hf,chain_rule_defect=Hx-Hq-Hf,
           scope='finite Shannon entropy; no unrestricted differential entropy identity'))
    # F(x,z)=x; latent lift (v,k) may change k without changing observable velocity.
    velocities=np.array([[1.,0.],[1.,4.]]); badvel=np.array([[1.,0.],[3.,4.]])
    register(rows,'WT25','Observable transport needs projectability, not a unique latent lift',np.ptp(velocities[:,0])==0 and np.ptp(badvel[:,0])>0,
      dict(projectable_observable_velocities=velocities[:,0].tolist(),nonprojectable_velocities=badvel[:,0].tolist(),latent_lift='declared, not forced'))
    a1,a2,a3=1.1,.9,1.3; b1,b2,b3=.1,-.2,.4
    trans=lambda t,ai,bi,aj,bj:aj/ai*(t-bi)+bj
    t=.7; via=trans(trans(t,a1,b1,a2,b2),a2,b2,a3,b3); direct=trans(t,a1,b1,a3,b3)
    register(rows,'WT26','Declared affine clock charts obey the cocycle',abs(via-direct)<1e-14,
      dict(cocycle_error=abs(via-direct),scope='calibrated affine clocks, not inferred from order alone'))
    # Equivalence of early and late anchor windows, with a declared range margin.
    early=calfeat[:,:n//2,0]; late=calfeat[:,n//2:,0]
    diff=(late.mean(axis=1)-early.mean(axis=1))/beta[1]
    se=np.sqrt(early.var(axis=1,ddof=1)/(n//2)+late.var(axis=1,ddof=1)/(n//2))/beta[1]
    equivalence_bound=np.max(np.abs(diff)+norm.ppf(.95)*se)
    drift_bound=np.max(np.abs(diff+.0001/beta[1])+norm.ppf(.95)*se)
    register(rows,'WT29','Early-late anchor equivalence is tested within a declared margin',equivalence_bound<.003 and drift_bound>.003,
      dict(range_difference_m=diff.tolist(),se_m=se.tolist(),equivalence90_bound_m=equivalence_bound,
           tolerance_m=.003,drifted_bound_m=drift_bound,scope='two anchor windows only, not global stationarity'))
    multi_raw=waveform(.014,rng,second=(.0143,.6)); mf=extract(multi_raw)
    co1=waveform(.014,np.random.default_rng(seed+10000),amplitude=.8,second=(.014,.6))
    co2=waveform(.014,np.random.default_rng(seed+10000),amplitude=1.4)
    coincident_error=np.max(abs(co1-co2))
    register(rows,'WT30','Resolvable multipath is rejected but coarrival is an exact fibre',mf[3]>4 and coincident_error<1e-6,
      dict(separated_multipath_shape=mf[3],coarrival_waveform_difference=coincident_error,
           scope='shape cannot prove absence of unresolved paths; single-path geometry remains a model assumption'))
    np.savez_compressed(outdir/f'walltap_auxiliary_{seed}.npz',
        feature_mc_errors=emc,feature_mc_inputs=inp,input_covariance=Vin,analytic_jacobian=J,
        normal_control=normal_raw,hidden_filter=filtered_raw,missing_return=missing_raw,
        multipath=multi_raw,coarrival1=co1,coarrival2=co2)
    base=dict(domain=True,scale=True,labels=True,rank=True,detected=bool(np.all(feat[:,:,2]>P['detection_z'])),stationary=bool(equivalence_bound<.003),
              shape=float(np.max(feat[:,:,3])),closure=float(np.max(abs(closure))),
              heldout_residual=float(holdres),sd=float(np.sqrt(np.max(np.diag(Vxy)))))
    status=certificate(base)
    # Increasing tolerance can admit more, but cannot fix missing scale or labels.
    tolerances=[1e-8,1e-5,.0001,.001,.003,.01]; statuses=[certificate(base,tolerance=t) for t in tolerances]
    admitted=[s=='CONDITIONALLY_CERTIFIED' for s in statuses]
    structural=dict(base,scale=False); structuralstatuses=[certificate(structural,tolerance=t) for t in tolerances]
    register(rows,'WT27','Certificates expose critical margins and structural gates',status=='CONDITIONALLY_CERTIFIED' and admitted==sorted(admitted) and len(set(structuralstatuses))==1,
      dict(status=status,evidence=base,tolerances_m=tolerances,statuses=statuses,
           critical_residual_m=max(base['closure'],base['heldout_residual']),structural_status=structuralstatuses[0]))
    blocked=False
    try: truth.read('estimation')
    except PermissionError: blocked=True
    # Two presentations duplicate latent labels but expose identical law values.
    observable=np.array([.01,.02,.03]); presentA=observable.copy(); presentB=np.repeat(observable,2)
    image_equal=np.array_equal(np.unique(presentA),np.unique(presentB))
    register(rows,'WT28','Held-out access is blocked and observable presentation is isolated',blocked and image_equal,
      dict(truth_access_log=truth.access,illegal_estimation_access_blocked=blocked,
           identical_observable_images=image_equal,scope='law-defined outputs only; latent liftability not asserted'))
    canaries=gate_canaries(base)
    # Executed numerical mutations in addition to gate-removal tests.
    rawxy,_,_=decode(feat[:,:,0],[0.,q],[W,H])
    # Position cancels a common offset, so use individual wall distances for this attack.
    rawrange=feat[:,:,0]/beta[1]; rawbias=np.mean(rawrange-distances)
    _,doubled,_=decode(feat[:,:,0],beta,[W,H],half_mutation=True)
    canaries.extend([
      dict(id='raw_latency_as_path',caught=abs(rawbias)>.1,wall_distance_bias_m=float(rawbias)),
      dict(id='double_calibrated_range',caught=np.sqrt(np.mean((doubled-distances)**2))>.5),
      dict(id='shuffle_wall_labels',caught=mirrorerror>.5),
      dict(id='hidden_filter_as_gain',caught=np.median(filtered[:,3])>4),
      dict(id='nonlinear_calibration_transport',caught=abs(badheld-2.1)>.003),
      dict(id='erase_common_floor',caught=naive[-1]<.2),
      dict(id='peek_heldout_truth',caught=blocked),
      dict(id='hidden_temporal_drift',caught=drift_bound>.003),
      dict(id='separated_multipath',caught=mf[3]>4)])
    result=dict(seed=seed,checks=rows,canaries=canaries,all_pass=all(t['passed'] for t in rows),
        all_canaries_caught=all(t['caught'] for t in canaries),status=status,
        metrics=dict(position_errors_m=err.tolist(),position_covariance_m2=Vxy.tolist(),
            closure_m=closure.tolist(),waveform_times_s=feat[:,:,0].tolist(),
            calibrated_path_duration_s=((feat[:,:,0]-beta[0])/a).tolist(),
            inferred_speed_given_clock_m_s=2*a/beta[1]),
        audit=dict(raw_file=f'walltap_raw_{seed}.npz',truth_file=f'walltap_evaluation_{seed}.npz',
            calibration='two training lengths only',heldout_used_for_fit=False))
    dump(outdir/f'walltap_results_{seed}.json',result)
    return result

def figures(outdir,run):
    raw=np.load(outdir/run['audit']['raw_file']); t=np.arange(raw['room'].shape[-1])/PROTOCOL['fs']*1000
    fig,ax=plt.subplots(2,2,figsize=(11,7))
    for j,lab in enumerate(['left','right','bottom','top']): ax[0,0].plot(t,raw['room'][0,j],label=lab)
    ax[0,0].set_xlabel('Recorder time (ms)'); ax[0,0].set_ylabel('Synthetic waveform amplitude'); ax[0,0].legend()
    err=np.array(run['metrics']['position_errors_m'])*1000; ax[0,1].plot(err[:,0],err[:,1],'.')
    ax[0,1].set_xlabel('Position x error (mm)'); ax[0,1].set_ylabel('Position y error (mm)')
    wt14=run['checks'][13]['evidence']; ax[1,0].semilogx(wt14['repeats'],wt14['coverage95'],'o-',label='Full uncertainty')
    ax[1,0].semilogx(wt14['repeats'],wt14['white_only_coverage95'],'s-',label='Common floor omitted')
    ax[1,0].axhline(.95); ax[1,0].set_xlabel('Repeated observations'); ax[1,0].set_ylabel('Nominal 95% coverage'); ax[1,0].legend()
    wt19=run['checks'][18]['evidence']
    for tail in wt19['energy_decay_s']:
        tt=np.linspace(0,.2,200); ax[1,1].plot(tt*1000,1-np.exp(-tt/tail),label=f'Energy decay {tail*1000:g} ms')
    ax[1,1].axhline(.5); ax[1,1].set_xlabel('Inter-tap interval (ms)'); ax[1,1].set_ylabel('Declared isolated-energy fraction'); ax[1,1].legend()
    fig.tight_layout(); fig.savefig(outdir/'walltap_results_figure.png',dpi=170); plt.close(fig)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out',default='.'); ap.add_argument('--seed',type=int)
    ap.add_argument('--replay',action='store_true',help='Re-extract saved raw records without simulation')
    args=ap.parse_args(); out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    if args.replay:
        replay=[]
        for file in sorted(out.glob('walltap_raw_*.npz')):
            seed=int(file.stem.rsplit('_',1)[1]); raw=np.load(file)
            cal=extract_many(raw['calibration'].reshape(-1,raw['calibration'].shape[-1])).reshape(2,PROTOCOL['anchor_repeats'],4)
            room=extract_many(raw['room'].reshape(-1,raw['room'].shape[-1])).reshape(-1,4,4)
            beta,_,_=fit_calibration(cal[:,:,0],np.array(PROTOCOL['anchor_distances_m']))
            xy,_,closure=decode(room[:,:,0],beta,PROTOCOL['room_m'])
            delta=float(np.max(abs(room-raw['room_features'])))
            replay.append(dict(seed=seed,feature_max_difference=delta,passed=delta<1e-12,position_count=len(xy),closure_max_m=float(np.max(abs(closure)))))
        dump(out/'walltap_replay.json',dict(records=replay,all_pass=bool(replay) and all(x['passed'] for x in replay)))
        print('Replay:',len(replay),'seeds;',all(x['passed'] for x in replay))
        return 0 if replay and all(x['passed'] for x in replay) else 1
    # Protocol is committed before random draws. This is a within-session fixed
    # protocol, not independent preregistration with a third-party timestamp.
    dump(out/'walltap_protocol.json',PROTOCOL)
    protocol_hash=sha(out/'walltap_protocol.json'); source_hash=sha(__file__)
    seeds=[args.seed] if args.seed is not None else [PROTOCOL['development_seed']]+PROTOCOL['validation_seeds']
    runs=[]; started=time.time()
    for seed in seeds:
        result=run(seed,out); runs.append(result)
        print(seed,':',sum(x['passed'] for x in result['checks']),'/30 checks;',sum(x['caught'] for x in result['canaries']),'/19 canaries;',result['status'],flush=True)
        for row in result['checks']:
            if not row['passed']: print('FAILED',row,flush=True)
        for row in result['canaries']:
            if not row['caught']: print('UNCATCHED',row,flush=True)
    figures(out,runs[0])
    summary=dict(origin='SYNTHETIC',protocol_sha256=protocol_hash,source_sha256=source_hash,
        seeds=seeds,environment=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__),
        all_pass=all(r['all_pass'] for r in runs),all_canaries_caught=all(r['all_canaries_caught'] for r in runs),
        runtime_s=time.time()-started,runs=runs)
    dump(out/'walltap_final_results.json',summary)
    with (out/'walltap_checks.csv').open('w',newline='') as f:
        w=csv.writer(f); w.writerow(['seed','id','claim','passed','evidence'])
        for run_ in runs:
            for row in run_['checks']: w.writerow([run_['seed'],row['id'],row['claim'],row['passed'],json.dumps(row['evidence'],default=lambda x:x.item() if isinstance(x,np.generic) else str(x))])
    manifest={p.name:sha(p) for p in out.glob('walltap_*') if p.is_file() and p.name not in ['walltap_manifest.json'] and p.suffix not in ['.zip','.pdf','.tex']}
    dump(out/'walltap_manifest.json',manifest)
    if not summary['all_pass'] or not summary['all_canaries_caught']: return 1
    return 0
if __name__=='__main__': sys.exit(main())
