#!/usr/bin/env python3
"""Independent audit of saved Wall-Tap records. Does not call the simulator.
Checks source/protocol hashes, calibration algebra, covariance Jacobian, exact
coarrival, and computes a conditional within-session bootstrap for mean position.
"""
import argparse,hashlib,json
from pathlib import Path
import numpy as np

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out',default='.'); args=ap.parse_args(); out=Path(args.out)
    summary=json.loads((out/'walltap_final_results.json').read_text()); P=json.loads((out/'walltap_protocol.json').read_text())
    assert summary['source_sha256']==sha(out/'walltap_final.py')
    assert summary['protocol_sha256']==sha(out/'walltap_protocol.json')
    checks=[]
    for run in summary['runs']:
        seed=run['seed']; raw=np.load(out/f'walltap_raw_{seed}.npz'); aux=np.load(out/f'walltap_auxiliary_{seed}.npz')
        assert str(raw['origin'])=='SYNTHETIC'; assert int(raw['sampling_rate'])==P['fs']
        means=raw['calibration_features'][:,:,0].mean(axis=1); lengths=np.array(P['anchor_distances_m'])
        q=(means[1]-means[0])/(lengths[1]-lengths[0]); b=means[0]-q*lengths[0]
        e={r['id']:r['evidence'] for r in run['checks']}
        cal_error=max(abs(q-e['WT04']['fitted_slope_s_m']),abs(b-e['WT04']['fitted_offset_s']))
        assert cal_error<1e-14
        z=aux['feature_mc_inputs'].mean(axis=0)
        # Evaluate at exact model centre, not empirical mean, to match stored Jacobian.
        c=P['sound_speed_m_s']; rate=P['clock_rate']; qt=2*rate/c; bt=P['onset_s']; W,H=P['room_m']; x,y=1.8,3.4
        z=np.r_[bt+qt*np.array([x,W-x,y,H-y]),bt,qt,W,H]
        def target(v):
            d=(v[:4]-v[4])/v[5]
            return np.array([(d[0]+v[6]-d[1])/2,(d[2]+v[7]-d[3])/2])
        steps=np.array([1e-7]*5+[1e-8,1e-5,1e-5]); J=np.empty((2,8))
        for j,h in enumerate(steps):
            delta=np.zeros(8); delta[j]=h; J[:,j]=(target(z+delta)-target(z-delta))/(2*h)
        stored=aux['analytic_jacobian']; defect=np.max(abs(J-stored)/np.maximum(1.,abs(stored)))
        assert defect<1e-6
        V=stored@aux['input_covariance']@stored.T
        assert np.max(abs(V-np.array(e['WT07']['predicted_covariance_m2'])))<1e-15
        assert np.max(abs(aux['coarrival1']-aux['coarrival2']))<1e-6
        assert len(run['checks'])==30 and len(run['canaries'])==19
        assert all(t['passed'] for t in run['checks']) and all(t['caught'] for t in run['canaries'])
        checks.append(dict(seed=seed,calibration_algebra_error=cal_error,jacobian_relative_defect=defect,passed=True))
    # Bootstrap only the development run. It conditions on lengths, room extents,
    # template and observed session. It does NOT estimate common anchor errors.
    seed=summary['runs'][0]['seed']; raw=np.load(out/f'walltap_raw_{seed}.npz'); rng=np.random.default_rng(88421)
    cal=raw['calibration_features'][:,:,0]; times=raw['room_features'][:,:,0].reshape(6,P['repeats'],4)
    B=2000; samples=[]; lengths=np.array(P['anchor_distances_m']); W,H=P['room_m']
    for _ in range(B):
        means=np.array([rng.choice(row,len(row),replace=True).mean() for row in cal])
        q=(means[1]-means[0])/(lengths[1]-lengths[0]); b=means[0]-q*lengths[0]
        ts=np.array([row[rng.integers(0,len(row),len(row))].mean(axis=0) for row in times])
        d=(ts-b)/q; xy=np.column_stack([(d[:,0]+W-d[:,1])/2,(d[:,2]+H-d[:,3])/2]); samples.append(xy)
    samples=np.array(samples); ci=np.quantile(samples,[.025,.975],axis=0)
    result=dict(all_pass=True,independent_checks=checks,bootstrap=dict(seed=88421,replicates=B,
        interval95_m=ci.tolist(),interval_widths_mm=((ci[1]-ci[0])*1000).tolist(),
        scope='conditional percentile intervals for six mean positions; fixed anchor lengths and extents; not a systematic uncertainty budget'))
    (out/'walltap_verification.json').write_text(json.dumps(result,indent=2))
    print('Independent audit:',len(checks),'seeds passed; conditional bootstrap:',B,'replicates')
    print('Maximum Jacobian defect:',max(c['jacobian_relative_defect'] for c in checks))
if __name__=='__main__':main()
