# RG - Chaotic Experiments: hostile battery

Critique under attack: (C1) real and chaotic data are not regular/dominated, and noiseless chaos is outside
RG; (C2) H-SI and H-med shift an unquantified engineering burden to the user.

    python3 rg_chaos_attack.py                 # seed 20260930 (about 1 min)
    python3 rg_chaos_attack.py --seed 42
    python3 rg_chaos_attack.py --canary        # 8 structures sabotaged; each must fail

Requires numpy, scipy. Exit code 0 only if all registered checks pass. 15/15 on seeds 20260930, 1, 42, 777, 2026.

| ID | Verdict | Result |
|---|---|---|
| MC01 | CONFIRMED | infinite-horizon noiseless law map discontinuous; short deterministic records mutually singular |
| MC02 | critique falsified | declared noise makes the experiment regular; Fisher ~ 1/sigma^2 |
| MC03 | critique falsified | windowed certification under t3 noise + 5% outliers: FC 0.00, power 1.00 |
| MC04 | holds | anchor budget = dim of invariant forms of empirical isotropy |
| MC05 | critique falsified | medium terms are kernel directions; frequency/path diversity; condition numbers |
| MC06 | CONFIRMED | multiplicative count loss reopens the dilation fibre |
| MC07 | critique falsified | chaotic dirty slice: 19/30 windows certified in metres, max 0.68%; naive 6.5% median |
| MC08 | boundary | ergodic transfer of the metre across an outage; error floor 1.0% |
| MC09 | critique falsified | noiseless finite-history experiments: finitely many kneading walls, finite Fisher, finite length across walls |
| MC10 | critique falsified | h_top from kernel class counts alone: 2^n at r=4 (ln 2), log(golden ratio) at r=3.835 |
| MC11 | critique falsified | noiseless history law: iid Bernoulli at r=4; Pesin lock at r=3.9; Ruelle lock rejects false plateau at edge |
| MC12 | four-path refuted | edge 'SYMBOLIC-PERIODIC' false: ordinal order 3-4 blind, no exact return, Feigenbaum alpha, 2^7 bands |
| MC13 | holds | typed disagreement is real at r=3.835: topological chaos, physical 3-cycle |
| MC14 | critique falsified | typed certifier sweep: 0 lock violations; naive ordinal certifier: 8 false PERIODIC |
| MC15 | naive falsified | fixed-length Lyapunov CI falsely certifies chaos at the Feigenbaum point; double length lock abstains |

`four_path_audit/` contains the independent four-path result files, unchanged, audited in Section 5 of the paper.
Development corrections are listed in the paper appendix.
