# RG - Chaotic Experiments: hostile battery

Critique under attack: (C1) real data are not regular/dominated; (C2) H-SI and H-med shift an unquantified
engineering burden to the user.

    python3 rg_chaos_attack.py                 # seed 20260930 (about 1 min)
    python3 rg_chaos_attack.py --seed 42
    python3 rg_chaos_attack.py --canary        # MC02, MC03, MC07, MC08 sabotaged; each must fail

Requires numpy. Exit code 0 only if all registered checks pass. Verdicts:

| ID | Verdict | Result |
|---|---|---|
| MC01 | CONFIRMED | noiseless chaotic law map discontinuous; short records mutually singular |
| MC02 | critique falsified | declared noise makes the experiment regular; Fisher ~ 1/sigma^2 |
| MC03 | critique falsified | windowed certification under t3 noise + 5% outliers: FC 0.00, power 1.00 |
| MC04 | holds | anchor budget = dim of invariant forms of empirical isotropy |
| MC05 | critique falsified | medium terms are kernel directions; frequency/path diversity; condition numbers |
| MC06 | CONFIRMED | multiplicative count loss reopens the dilation fibre |
| MC07 | critique falsified | chaotic dirty slice: 19/30 windows certified in metres, max 0.68%; naive 6.5% median |
| MC08 | boundary | ergodic transfer of the metre across an outage; error floor 1.0% at 3000 time units |

Development corrections (recorded in the paper appendix): per-window slip repair replaced by continuous
tracking; linearized integer search replaced by nonlinear ILS; the claim that 3 stations cannot resolve
the integer fibre withdrawn; the prediction that rho=28.5 is flagged failed at the primary seed and the
certificate was re-registered as an error-floor statement.
