#!/usr/bin/env python3
"""
RG under chaotic and dirty experiments: hostile battery
=======================================================
Critique under attack:
  (C1) "Regularity trap": real data are not regular/dominated, so the ladder never applies.
  (C2) "Anchor burden": H-SI (counted channel removes dilation) and H-med (medium resolved)
       push the whole engineering problem onto the user.
Each check registers the critique's claim and the claim RG is allowed to keep. A check passes iff the
numbers match the pre-registered prediction. Where the critique is right, the verdict is CONFIRMED and
the evidence is kept.

Run:  python3 rg_chaos_attack.py [--seed 20260930] [--out FILE] [--canary]
"""
import argparse, json, math, sys, time
import numpy as np

RESULTS, MUT = [], {}
C = 299792458.0


def f(x): return float(np.round(float(x), 12))


def _finite(o):
    if isinstance(o, dict): return all(_finite(v) for v in o.values())
    if isinstance(o, (list, tuple)): return all(_finite(v) for v in o)
    if isinstance(o, float): return math.isfinite(o)
    return True


def register(aid, target, critique, keep, passed, ev, verdict):
    if not _finite(ev): passed, verdict = False, "NONFINITE"
    RESULTS.append(dict(id=aid, target=target, critique_claim=critique, rg_claim=keep,
                        passed=bool(passed), verdict=verdict, evidence=ev))
    print(f"[{'PASS' if passed else 'FAIL'}] {aid:5s} {verdict:16s} {keep[:80]}")


# ------------------------------------------------------------------ logistic family
def logistic_hist(r, sig, rng, n=150000, bins=40):
    x, H, ly = 0.3, np.zeros(bins), 0.0
    for t in range(n+2000):
        x = r*x*(1-x)
        if sig > 0:
            x += sig*rng.normal(); x = abs(x); x = 2-x if x > 1 else x
        if t >= 2000:
            H[min(int(x*bins), bins-1)] += 1; ly += math.log(abs(r*(1-2*x))+1e-300)
    return H/H.sum(), ly/n


def MC01_regularity_wall(rng):
    """Noiseless chaotic law map: long-run law of x_t as a function of r jumps at the period-3 window
    (r* = 1+sqrt 8). Lyapunov exponent changes sign. The deterministic 2-sample experiment (x0,x1) with
    x0 ~ U(0,1) has laws on disjoint curves x1 = r x0(1-x0): mutually singular, not dominated."""
    h1, l1 = logistic_hist(3.8280, 0.0, rng); h2, l2 = logistic_hist(3.8290, 0.0, rng)
    tv = 0.5*np.abs(h1-h2).sum()
    x0 = rng.uniform(0, 1, 100000)
    # probability that a sample of r=3.8280 lies within 1e-9 of the r=3.8290 curve
    overlap = np.mean(np.abs(3.8280*x0*(1-x0) - 3.8290*x0*(1-x0)) < 1e-9)
    passed = tv > 0.3 and l1 > 0 > l2 and overlap < 1e-3
    register("MC01", "C1", "Chaotic real systems violate the regularity/domination hypotheses.",
             "CONFIRMED for the noiseless asymptotic experiment: its law map is discontinuous in r "
             "(TV jump across dr=1e-3) and short deterministic records are mutually singular. The ladder's "
             "differential layers do not apply to this experiment; only the exact layer does.",
             passed, dict(TV_jump=f(tv), lyapunov=[f(l1), f(l2)], singular_overlap=f(overlap)), "CONFIRMED")


def MC02_regularity_is_declared(rng):
    """The SAME latent chaos observed through a declared experiment with dynamical/observation noise
    sigma>0 and finite horizon is regular: the law map becomes continuous, the per-step Fisher information
    E[(x(1-x))^2]/sigma^2 is finite, and it diverges as 1/sigma^2 (non-dominated limit)."""
    sig = MUT.get("mc02_sigma", 1e-2)
    h1, _ = logistic_hist(3.8280, sig, rng); h2, _ = logistic_hist(3.8290, sig, rng)
    tv = 0.5*np.abs(h1-h2).sum()
    rs = np.linspace(3.80, 3.86, 13); fis = []
    for r in rs:
        h, _ = logistic_hist(r, sig, rng, n=40000)
        xc = (np.arange(40)+0.5)/40
        fis.append(float(np.float64(h @ (xc*(1-xc))**2)/np.float64(sig)**2) if sig > 0 else float("inf"))   # sigma=0: infinite Fisher, the wall
    fis = np.array(fis); jump = np.max(np.abs(np.diff(fis)))/np.mean(fis)
    scaling = {str(s): f(0.04/s**2) for s in (1e-1, 1e-2, 1e-3)}   # E[(x(1-x))^2] ~ 0.04
    passed = tv < 0.05 and jump < 0.1
    register("MC02", "C1", "Hence RG cannot be applied to chaotic experiments.",
             "Regularity is a property of the declared experiment, not of the latent dynamics. With declared "
             "noise the law map is continuous (small TV) and Fisher varies smoothly in r; its 1/sigma^2 growth "
             "locates the non-dominated wall at sigma=0.",
             passed, dict(noisy_TV=f(tv), fisher_rel_max_jump=f(jump), fisher_per_step_by_sigma=scaling),
             "FALSIFIED-critique")


def robust_fit(X, Y, iters=25, k=1.345):
    """Huber IRLS multivariate regression Y ~ X B (X includes intercept column)."""
    B = np.linalg.lstsq(X, Y, rcond=None)[0]
    for _ in range(iters):
        R = Y - X @ B
        s = 1.4826*np.median(np.abs(R - np.median(R, 0)), 0) + 1e-12
        u = np.abs(R)/s
        w = np.where(u <= k, 1.0, k/u).min(1)
        B = np.linalg.lstsq(X*np.sqrt(w)[:, None], Y*np.sqrt(w)[:, None], rcond=None)[0]
    return B


def MC03_wall_certification(rng):
    """Windowed certification of the response rank under heavy tails (t3) and 5% gross outliers.
    Certify rank 2 iff the bootstrap 5% lower bound of sigma_min(J_hat) exceeds tau.
    Error control: false certification on true walls (sigma_min=0) <= alpha."""
    tau, alpha, n, B = 0.3, 0.05, 60, 60
    kinds = ["wall"]*100 + ["regular"]*100
    fc = pw = 0
    for kind in kinds:
        U, _, Vt = np.linalg.svd(rng.normal(size=(3, 2)), full_matrices=False)
        s = np.array([1.5, 0.0 if kind == "wall" else rng.uniform(2*tau, 1.2)])
        J = U @ np.diag(s) @ Vt
        D = rng.normal(size=(n, 2))
        Y = D @ J.T + 0.1*rng.standard_t(3, size=(n, 3))
        out = rng.random(n) < MUT.get("mc03_out", 0.05); Y[out] += rng.normal(0, 5, (out.sum(), 3))
        X = np.c_[D, np.ones(n)]
        smins = []
        for _ in range(B):
            idx = rng.integers(0, n, n)
            Bh = robust_fit(X[idx], Y[idx], iters=8)
            smins.append(np.linalg.svd(Bh[:2].T, compute_uv=False)[-1])
        lb = np.quantile(smins, alpha)
        cert = lb > tau
        fc += cert and kind == "wall"; pw += cert and kind == "regular"
    passed = fc/100 <= alpha and pw/100 >= 0.8
    register("MC03", "C1", "On dirty data RG will almost certainly trip on a wall and output nothing.",
             "Walls are located, not fatal: windowed robust certification with bootstrap lower bounds "
             "certifies regular windows and rejects wall windows with controlled error under t3 noise and "
             "5% gross outliers. RG outputs an atlas of certified windows.",
             passed, dict(false_certification_rate=f(fc/100), power=f(pw/100), alpha=alpha, tau=tau),
             "FALSIFIED-critique")


def inv_form_dim(gens, n):
    basis = []
    for i in range(n):
        for j in range(i, n):
            E = np.zeros((n, n)); E[i, j] = E[j, i] = 1; basis.append(E)
    if not gens: return len(basis)
    A = np.vstack([np.array([(R.T @ E @ R - E).ravel() for E in basis]).T for R in gens])
    return len(basis) - np.linalg.matrix_rank(A, tol=1e-10)


def MC04_anchor_budget(rng):
    """Anchor budget theorem: a constant metric h on a chart whose empirical isotropy is K is fixed by
    exactly dim Sym^2(V*)^K radar anchors in general position; fewer leave an explicit family."""
    rot = lambda a: np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]])
    cases = {"SO(2)": [rot(0.7)], "C4": [rot(np.pi/2)], "C2": [rot(np.pi)], "none": []}
    out = {}
    for name, gens in cases.items():
        dim = inv_form_dim(gens, 2)
        # linear system: anchors Delta^T h Delta = rho^2 with h restricted to invariant forms
        basis = []
        for i in range(2):
            for j in range(i, 2):
                E = np.zeros((2, 2)); E[i, j] = E[j, i] = 1; basis.append(E)
        if gens:
            A = np.vstack([np.array([(R.T @ E @ R - E).ravel() for E in basis]).T for R in gens])
            _, _, Vt = np.linalg.svd(A); N = Vt[len(basis)-dim:].T
        else:
            N = np.eye(3)
        ranks = []
        for k in range(1, 5):
            Dl = rng.normal(size=(k, 2))
            M = np.array([[d @ (sum(N[m, c]*basis[m] for m in range(3))) @ d for c in range(N.shape[1])] for d in Dl])
            ranks.append(int(np.linalg.matrix_rank(M, tol=1e-9)))
        out[name] = dict(invariant_forms=int(dim), rank_with_k_anchors=ranks,
                         anchors_needed=int(next(k+1 for k, r in enumerate(ranks) if r == dim)))
    # explicit underdetermination for 'none' with 2 anchors
    d1, d2, d3 = np.array([1.0, 0]), np.array([0, 1.0]), np.array([1.0, 1.0])
    h1 = np.array([[1.0, 0], [0, 1]]); h2 = np.array([[1.0, 0.3], [0.3, 1]])
    same = abs(d1 @ h1 @ d1 - d1 @ h2 @ d1) + abs(d2 @ h1 @ d2 - d2 @ h2 @ d2)
    diff = abs(d3 @ h1 @ d3 - d3 @ h2 @ d3)
    passed = (out["SO(2)"]["anchors_needed"] == 1 and out["C4"]["anchors_needed"] == 1 and
              out["C2"]["anchors_needed"] == 3 and out["none"]["anchors_needed"] == 3 and same < 1e-12 and diff > 0.5)
    register("MC04", "C2", "Messy experiments need an open-ended, unquantified calibration effort.",
             "The calibration burden is computable: the number of radar anchors equals the dimension of "
             "invariant symmetric forms of the empirical isotropy (1 with irreducible rotations, 3 in 2D with "
             "none). With fewer anchors an explicit family of metrics fits and disagrees on held-out pairs.",
             passed, dict(budget=out, underdetermined_example=dict(fit_defect=f(same), heldout_gap=f(diff))), "HOLDS")


def MC05_medium_as_kernel(rng):
    """(a) Dispersive medium: tau = 2d/c + 2K/f^2 (+ 2K3/f^3). Frequencies needed = number of medium terms+1.
    (b) Non-dispersive excess path (wet troposphere): rho_e = rho0 - h sin e + Z/sin e. Elevation diversity is
    path diversity; the condition number quantifies the burden as elevation cutoff shrinks."""
    def rank_disp(freqs, terms):
        J = np.array([[2/C] + [2/fr**p for p in terms] for fr in freqs])
        J = J/np.linalg.norm(J, axis=0)
        return int(np.linalg.matrix_rank(J, tol=1e-8)), f(np.linalg.cond(J)) if len(freqs) >= J.shape[1] else None
    disp = {"1 freq, K/f^2": rank_disp([1.5e9], [2]), "2 freq, K/f^2": rank_disp([1.5e9, 1.2e9], [2]),
            "2 freq, K/f^2+K3/f^3": rank_disp([1.5e9, 1.2e9], [2, 3]),
            "3 freq, K/f^2+K3/f^3": rank_disp([1.5e9, 1.2e9, 1.17e9], [2, 3])}
    conds = {}
    for emin in (60, 30, 15, 5):
        e = np.radians(np.linspace(emin, 90, 12))
        J = np.c_[np.ones_like(e), -np.sin(e), 1/np.sin(e)]   # rho0 (clock/offset), height, zenith delay
        conds[str(emin)] = f(np.linalg.cond(J))
    one = np.c_[np.ones(1), -np.sin([0.8]), 1/np.sin([0.8])]
    passed = (disp["1 freq, K/f^2"][0] == 1 and disp["2 freq, K/f^2"][0] == 2 and
              disp["2 freq, K/f^2+K3/f^3"][0] == 2 and disp["3 freq, K/f^2+K3/f^3"][0] == 3 and
              conds["60"] > conds["5"] and np.linalg.matrix_rank(one) == 1)
    register("MC05", "C2", "H-med ('medium resolved') is an unexaminable engineering act of faith.",
             "H-med is a kernel computation: each medium term is a fibre direction removed by one more "
             "frequency (dispersive) or by path diversity (non-dispersive); the condition number states the "
             "cost. Unmodelled dispersion terms leave an exact kernel direction until a channel is added.",
             passed, dict(dispersive_rank=disp, elevation_condition_number=conds), "FALSIFIED-critique")


def MC06_count_loss(rng):
    """Does a counted channel always remove dilation? Loss models on n = k d (k = 2 nu/c):
       multiplicative loss (1-eps) n  -> exact dilation fibre (d, eps) returns;
       additive slips n - s           -> identifiable with two anchor distances;
       dead-time m = n/(1+n tau_d)     -> identifiable when the count rate is varied."""
    k = 2*9192631770.0/C
    ds = np.array([3.0, 11.0, 27.0])
    def rank(fn, th):
        J = []
        for i in range(len(th)):
            e = np.zeros(len(th)); e[i] = 1e-6*max(1, abs(th[i]))
            J.append((fn(th+e)-fn(th-e))/(2*e[i]))
        J = np.array(J).T; J = J/np.linalg.norm(J, axis=0)
        return int(np.linalg.matrix_rank(J, tol=1e-7))
    # unknown global scale s (the unit) multiplies all distances; anchors ds known only up to s
    mult = rank(lambda th: (1-th[1])*k*th[0]*ds, np.array([1.0, 0.02]))
    add = rank(lambda th: k*th[0]*ds - th[1], np.array([1.0, 5.0]))
    dead = rank(lambda th: (k*th[0]*ds)/(1+(k*th[0]*ds)*th[1]), np.array([1.0, 1e-4]))
    passed = mult == 1 and add == 2 and dead == 2
    register("MC06", "C2", "A counted channel (H-SI) perfectly removes dilations.",
             "CONFIRMED as a real gap: count rigidity removes dilation only if the count-loss mechanism is "
             "not scale-covariant. Multiplicative loss is an exact dilation and reopens the unit fibre; additive "
             "slips and rate-dependent dead time do not. H-SI must include a loss model with a signature.",
             passed, dict(fisher_rank_scale_plus_loss=dict(multiplicative=mult, additive_slip=add, dead_time=dead)),
             "CONFIRMED")


# ------------------------------------------------------------------ end-to-end chaotic slice
def lorenz(T, dt, rng):
    s = np.array([1.0, 1.0, 20.0]) + rng.normal(0, 0.5, 3); out = np.empty((T, 3))
    F = lambda v: np.array([10*(v[1]-v[0]), v[0]*(28-v[2])-v[1], v[0]*v[1]-8/3*v[2]])
    for t in range(T):
        k1 = F(s); k2 = F(s+dt/2*k1); k3 = F(s+dt/2*k2); k4 = F(s+dt*k3)
        s = s + dt/6*(k1+2*k2+2*k3+k4); out[t] = s
    return out


def slice_run(rng, S):
    """Chaotic target (Lorenz), dual-frequency two-way radar from 3 stations through a turbulent dispersive
    medium with cycle slips and outages; imaging with heavy tails, outliers, dropouts and three regimes
    (isotropic / anisotropic / pure pixel-pitch dilation). RG procedure per window vs naive global
    calibration vs all-or-nothing certification."""
    T, W, dt = 6000, 200, 0.004
    L = lorenz(T+500, dt, rng)[500:]
    P = np.c_[30+0.6*L[:, 0], 20+0.5*(L[:, 2]-25)]
    m_st = len(S)
    f1, f2 = 1.5e9, 1.2e9
    K = np.cumsum(rng.normal(0, 2e-4, T)) + 1.0
    K = np.abs(K)*1.2e10                      # 2K/f^2 ~ 1e-8 s
    sig_t = 3e-11
    outage = np.zeros(T, bool)
    for a, b in MUT.get("mc07_outages", [(1800, 2400), (2600, 3000), (3800, 4400)]): outage[a:b] = True
    d = np.linalg.norm(P[:, None, :]-S[None], axis=2)          # T x 3
    tau1 = 2*d/C + 2*K[:, None]/f1**2 + sig_t*rng.normal(size=(T, m_st))
    tau2 = 2*d/C + 2*K[:, None]/f2**2 + sig_t*rng.normal(size=(T, m_st))
    slips = np.zeros((T, m_st))
    for j in range(m_st):
        for t in np.where(rng.random(T) < 1/400)[0]:
            slips[t:, j] += rng.choice([-3, -2, -1, 1, 2, 3])/f1
    tau1 = tau1 + slips
    # imaging regimes
    rot = lambda a: np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]])
    A = [np.eye(2), rot(0.3) @ np.diag([1, 1.25]), rot(0.3) @ np.diag([1, 1.25])]
    s_pix = [0.01, 0.01, MUT.get("mc07_s3", 0.0103)]
    reg = np.minimum(np.arange(T)//2000, 2)
    xi = 0.02*rng.standard_t(3, size=(T, 2))
    Y = np.array([A[reg[t]] @ (P[t]+xi[t])/s_pix[reg[t]] for t in range(T)])
    bad = rng.random(T) < 0.03; Y[bad] = rng.uniform(0, 8000, (bad.sum(), 2))
    drop = rng.random(T) < 0.02; Y[drop] = np.nan

    # ---------- RG procedure
    def repair_segment(t1, t2):
        """continuous cycle-slip repair inside one contiguous tracking segment (geometry-free jumps)"""
        gf = t1 - t2; jumps = np.diff(gf, axis=0); fixed = t1.copy()
        thr = 6*2*sig_t
        for j in range(m_st):
            for t in np.where(np.abs(jumps[:, j]) > thr)[0]:
                n = np.round(jumps[t, j]*f1)
                if n != 0: fixed[t+1:, j] -= n/f1
        return fixed
    # tracking segments separated by outages
    tau1r = np.full_like(tau1, np.nan); seg_start = np.zeros(T, bool)
    t = 0
    while t < T:
        if outage[t]: t += 1; continue
        e = t
        while e < T and not outage[e]: e += 1
        tau1r[t:e] = repair_segment(tau1[t:e], tau2[t:e]); seg_start[t] = True; t = e
    def trilat(r, p0):
        p = p0.copy()
        for _ in range(8):
            dd = np.linalg.norm(p-S, axis=1); Jm = (p-S)/dd[:, None]
            p = p + np.linalg.lstsq(Jm, r-dd, rcond=None)[0]
        return p, np.sqrt(np.mean((np.linalg.norm(p-S, axis=1)-r)**2))
    a_if = f1**2/(f1**2-f2**2)
    beta = C/2*a_if/f1                 # metres of IF range per f1 cycle
    span = 20 if m_st == 3 else 12
    grid = np.array(np.meshgrid(*[np.arange(-span, span+1)]*m_st, indexing="ij")).reshape(m_st, -1).T
    def misclosure(rr, p0):
        E, Nn = [], []
        for i in range(0, len(rr), 5):
            p, _ = trilat(rr[i], p0); dd = np.linalg.norm(p-S, axis=1); Jm = (p-S)/dd[:, None]
            u, sv, vt = np.linalg.svd(Jm); n = u[:, 2:]          # left-null space, dim m-2
            E.append(n.T @ (rr[i]-dd)); Nn.append(n.T)
        return np.array(E), np.array(Nn)
    local = np.array(np.meshgrid(*[np.arange(-2, 3)]*m_st, indexing="ij")).reshape(m_st, -1).T
    def ils(rr_list, p0):
        """nonlinear integer least squares: coarse search on the linearized misclosure, then re-linearize on
        corrected ranges and refine locally until stable; ratio test on the final local cost."""
        N = np.zeros(m_st)
        for it in range(6):
            E, Nn = zip(*[misclosure(r - beta*N[None, :], p0) for r in rr_list])
            E, Nn = np.concatenate(E), np.concatenate(Nn)
            G = grid if it == 0 else local
            cost = np.zeros(len(G))
            for k in range(E.shape[1]):
                cost += ((E[:, k][:, None] - beta*(Nn[:, k, :] @ G.T))**2).sum(0)
            o = np.argsort(cost); step = G[o[0]]
            ratio = cost[o[1]]/max(cost[o[0]], 1e-30)
            N = N + step
            if it > 0 and not step.any(): break
        return N, ratio
    def scatter(Yw):
        Z = Yw[2:]-2*Yw[1:-1]+Yw[:-2]; Z = Z[~np.isnan(Z).any(1)]
        med = np.median(Z, 0); dev = np.linalg.norm(Z-med, axis=1); Z = Z[dev < 20*np.median(dev)] - med
        Sg = np.eye(2)
        for _ in range(50):
            q = np.einsum("ij,jk,ik->i", Z, np.linalg.inv(Sg), Z) + 1e-12
            Sg = 2*(Z.T/q) @ Z/len(Z); Sg /= np.trace(Sg)
        return Sg
    def noise_shape(Yw):
        """Tyler M-estimator of scatter shape (distribution-free for elliptical heavy tails) of the
        second differences; returns the log eigenvalue ratio. Gross outliers are removed first."""
        Z = Yw[2:]-2*Yw[1:-1]+Yw[:-2]; Z = Z[~np.isnan(Z).any(1)]
        med = np.median(Z, 0); dev = np.linalg.norm(Z-med, axis=1); Z = Z[dev < 20*np.median(dev)] - med
        Sg = np.eye(2)
        for _ in range(50):
            q = np.einsum("ij,jk,ik->i", Z, np.linalg.inv(Sg), Z) + 1e-12
            Sg = 2*(Z.T/q) @ Z/len(Z); Sg /= np.trace(Sg)
        w = np.linalg.eigvalsh(Sg)
        return np.log(w[1]/w[0])
    gap = 50
    status, err_abs, err_ratio, diag = [], [], [], []
    amb_state = None; acc = ([], [])
    naive_err, calib = [], None
    k_iso = None
    for w0 in range(0, T, W):
        idx = np.arange(w0, w0+W)
        pairs = idx[:-gap]
        true_d = np.linalg.norm(P[pairs+gap]-P[pairs], axis=1)
        Yw = Y[idx]
        ok = ~np.isnan(Yw).any(1)
        # naive: isotropic scale from first window, single-frequency radar (biased), applied everywhere
        if w0 == 0:
            r_naive = C*tau1[idx]/2
            p_naive = np.array([trilat(r_naive[i], P[idx[0]])[0] for i in range(W)])
            m = ok
            k_iso = np.median(np.linalg.norm(np.diff(Yw[m], axis=0), axis=1)/np.linalg.norm(np.diff(p_naive[m], axis=0), axis=1))
        ya, yb = Y[pairs], Y[pairs+gap]
        good = ~(np.isnan(ya).any(1) | np.isnan(yb).any(1))
        nd = np.linalg.norm(yb-ya, axis=1)/k_iso
        naive_err += list(np.abs(nd[good]-true_d[good])/true_d[good])
        # RG
        radar_ok = not outage[idx].any()
        st = "ABSTAIN"
        if radar_ok:
            t1 = tau1r[idx]
            tif = (f1**2*t1 - f2**2*tau2[idx])/(f1**2-f2**2)
            rr = C*tif/2
            if seg_start[idx].any() and w0 > 0:          # re-acquisition: fresh integer fibre
                acc = ([], []); amb_state = (np.zeros(m_st), False)
            if w0 > 0 and amb_state is not None and not amb_state[1]:
                acc[0].append(rr)
                Nhat, ratio = ils(acc[0], P[idx[0]]+rng.normal(0, 1, 2))
                amb_state = (Nhat, ratio > 3.0)
                true_N = np.round((tau1r[idx[0]] - (2*d[idx[0]]/C + 2*K[idx[0]]/f1**2))*f1)
                diag.append((w0, "ratio", f(ratio), [int(v) for v in Nhat], [int(v) for v in true_N]))
            if w0 > 0 and amb_state is not None:
                Nhat, amb_ok = amb_state
                rr = rr - beta*Nhat[None, :]
                if not amb_ok: radar_ok = False
        if radar_ok:
            prad, res = zip(*[trilat(rr[i], P[idx[0]]+rng.normal(0, 1, 2)) for i in range(W)])
            prad = np.array(prad); res = np.array(res)
            diag.append((w0, f(np.median(res)), None))
            if np.median(res) < 0.05:
                h = W//2; m1 = ok.copy(); m1[h:] = False; m2 = ok.copy(); m2[:h] = False
                Bh = robust_fit(np.c_[prad[m1], np.ones(m1.sum())], Yw[m1])
                Minv = np.linalg.inv(Bh[:2].T)
                pim = (Yw - Bh[2]) @ Minv.T
                dpred = np.linalg.norm(pim[m2][gap:]-pim[m2][:-gap], axis=1)
                drad = np.linalg.norm(prad[m2][gap:]-prad[m2][:-gap], axis=1)
                heldout = np.median(np.abs(dpred-drad)/drad)
                diag[-1] = (w0, diag[-1][1], f(heldout))
                if heldout < 0.01:
                    calib = dict(Minv=Minv, b=Bh[2], scatter=scatter(Yw))
                    st = "CERT-METRIC"
        elif calib is not None:
            # EQUIVALENCE test (not failure to reject): certify 'isotropy unchanged' only if the upper
            # bootstrap bound of the whitened shape distortion is below delta = 2 log(1+tol)
            Wh = np.linalg.inv(np.linalg.cholesky(calib["scatter"]))
            Yh = Yw @ Wh.T
            obs = noise_shape(Yh)
            bs = [noise_shape(Yh[np.sort(rng.integers(0, W, W))]) for _ in range(30)]
            ub = obs + 2*np.std(bs)
            if ub < MUT.get("mc07_delta", 2*np.log(1.02)):
                st = "CERT-RATIO"      # anchor absent: valid up to one unverified dilation
        if st != "ABSTAIN":
            pa = (ya - calib["b"]) @ calib["Minv"].T; pb = (yb - calib["b"]) @ calib["Minv"].T
            dd = np.linalg.norm(pb-pa, axis=1)
            # reject imaging outliers by robust residual on the pair
            gg = good & (np.abs(dd-np.median(dd[good])) < 10*np.median(np.abs(dd[good]-np.median(dd[good]))) + 1)
            e_abs = np.median(np.abs(dd[gg]-true_d[gg])/true_d[gg])
            rat = dd[gg]/np.median(dd[gg]); rat_t = true_d[gg]/np.median(true_d[gg])
            e_rat = np.median(np.abs(rat-rat_t)/rat_t)
            err_abs.append((st, e_abs, int(reg[w0]))); err_ratio.append((st, e_rat))
        status.append((w0, st, int(reg[w0]), bool(outage[idx].any())))
    count = {s: sum(1 for x in status if x[1] == s) for s in ("CERT-METRIC", "CERT-RATIO", "ABSTAIN")}
    met = [e for s, e, _ in err_abs if s == "CERT-METRIC"]
    rat_err = [e for s, e in err_ratio if s == "CERT-RATIO"]
    fixes = [x for x in diag if x[1] == "ratio" and x[2] > 3.0]
    wrong = sum(1 for x in fixes if x[3] != x[4])
    outage_windows = sorted({w for w, s_, r, o in status if o})
    return dict(window_status=count,
                metric_median_rel_err=f(np.median(met)) if met else -1.0,
                metric_max_rel_err=f(np.max(met)) if met else -1.0,
                ratio_windows_max_ratio_err=f(np.max(rat_err)) if rat_err else -1.0,
                accepted_integer_fixes=len(fixes), wrong_integer_fixes=int(wrong),
                first_reacquisition_ratio=f(next((x[2] for x in diag if x[1] == 'ratio'), -1.0)),
                pattern=''.join({'CERT-METRIC': 'M', 'CERT-RATIO': 'R', 'ABSTAIN': '.'}[s_] for w, s_, r, o in status),
                outage_windows_certified_metric=sum(1 for w, s_, r, o in status if o and s_ == "CERT-METRIC"),
                naive_global_median_rel_err=f(np.median(naive_err)),
                naive_global_p90_rel_err=f(np.quantile(naive_err, 0.9)),
                all_or_nothing="REJECT" if count["CERT-METRIC"] < len(status) else "ACCEPT")


def MC07_chaotic_slice(rng):
    """Chaotic target (Lorenz), dual-frequency two-way radar through a turbulent dispersive medium with
    cycle slips and outages; imaging with t3 noise, 3% gross outliers, 2% dropouts and three regimes
    (isotropic / anisotropic / pure pixel-pitch dilation). RG procedure per window versus naive global
    calibration and versus all-or-nothing certification; 3-station and 4-station geometries."""
    seed = int(rng.integers(0, 2**31))
    ev3 = slice_run(np.random.default_rng(seed), np.array([[0, 0], [60, 0], [30, 50.0]]))
    ev4 = slice_run(np.random.default_rng(seed), np.array([[0, 0], [60, 0], [30, 50.0], [60, 45.0]]))
    ok = lambda ev: (ev["metric_max_rel_err"] < 0.02 and ev["wrong_integer_fixes"] == 0 and
                     ev["outage_windows_certified_metric"] == 0 and
                     (ev["ratio_windows_max_ratio_err"] < 0.02) and ev["naive_global_median_rel_err"] > 5*ev["metric_median_rel_err"])
    passed = (ok(ev3) and ok(ev4) and ev3["accepted_integer_fixes"] >= 1 and
              ev4["first_reacquisition_ratio"] > ev3["first_reacquisition_ratio"])
    register("MC07", "C1+C2", "A chaotic, dirty experiment has no valid physical geometry; RG will only say 'too dirty'.",
             "RG returns a graded atlas: metric-certified windows (medium removed, slips repaired, integer "
             "fibre resolved by nonlinear integer least squares with a ratio test, held-out passed) and "
             "abstentions at walls and while the integer fibre is unresolved; no wrong integer fix is accepted. "
             "Redundancy (4th station) raises the ratio margin. Outages are never certified in metres from "
             "imaging alone.",
             passed, dict(three_stations=ev3, four_stations=ev4), "FALSIFIED-critique")


def lorenz_fast(Tu, rho=28.0, dt=0.005, every=4, seed=0):
    r = np.random.default_rng(seed); x, y, z = 1+r.normal(), 1+r.normal(), 20+r.normal()
    sg, b, out = 10.0, 8/3, []
    F = lambda x, y, z: (sg*(y-x), x*(rho-z)-y, x*y-b*z)
    for i in range(int(Tu/dt)+2000):
        k1 = F(x, y, z); k2 = F(x+dt/2*k1[0], y+dt/2*k1[1], z+dt/2*k1[2])
        k3 = F(x+dt/2*k2[0], y+dt/2*k2[1], z+dt/2*k2[2]); k4 = F(x+dt*k3[0], y+dt*k3[1], z+dt*k3[2])
        x += dt/6*(k1[0]+2*k2[0]+2*k3[0]+k4[0]); y += dt/6*(k1[1]+2*k2[1]+2*k3[1]+k4[1])
        z += dt/6*(k1[2]+2*k2[2]+2*k3[2]+k4[2])
        if i >= 2000 and i % every == 0: out.append((x, z))
    L = np.array(out); return np.c_[30+0.6*L[:, 0], 20+0.5*(L[:, 1]-25)]


def _moments(X):
    mu = X.mean(0); Z = X-mu
    return mu, Z.T @ Z/len(Z), np.einsum("ni,nj,nk->ijk", Z, Z, Z)/len(Z)


def _sqrtm(S):
    w, V = np.linalg.eigh(S); return V @ np.diag(np.sqrt(w)) @ V.T


def _transfer(PA, YB):
    """M with YB ~ M P + b from the invariant measure: second moments fix M up to a right orthogonal factor,
    third moments fix the factor up to symmetries of the measure (isometries, harmless for distances)."""
    _, SA, TA = _moments(PA); _, SB, TB = _moments(YB); best = None
    for refl in (1, -1):
        for th in np.linspace(0, 2*np.pi, 721):
            O = np.array([[np.cos(th), -np.sin(th)], [np.sin(th), np.cos(th)]]) @ np.diag([1, refl])
            M = _sqrtm(SB) @ O @ np.linalg.inv(_sqrtm(SA))
            c = np.linalg.norm(np.einsum("ai,bj,ck,ijk->abc", M, M, M, TA) - TB)
            if best is None or c < best[0]: best = (c, M)
    return best[1]


def _invariants(X):
    mu, S, _ = _moments(X); Z = (X-mu) @ np.linalg.inv(_sqrtm(S)).T
    r2 = (Z**2).sum(1)
    return np.array([np.linalg.norm(np.einsum("ni,nj,nk->ijk", Z, Z, Z)/len(Z)), np.mean(r2**2), np.mean(r2**3)])


def _period(X, dt_s=0.02):
    """clock-based dimensionless-in-space invariant: mean interval between maxima of the whitened radius.
    Unchanged by ANY spatial linear map, so a dilation during the outage cannot fake or hide it."""
    mu, S, _ = _moments(X); Z = (X-mu) @ np.linalg.inv(_sqrtm(S)).T
    r2 = np.convolve((Z**2).sum(1), np.ones(5)/5, "same")
    pk = np.where((r2[1:-1] > r2[:-2]) & (r2[1:-1] >= r2[2:]) & (r2[1:-1] > np.median(r2)))[0]+1
    iv = np.diff(pk)*dt_s; bl = np.array_split(iv, 20)
    return iv.mean(), np.std([b.mean() for b in bl])/np.sqrt(20)


def MC08_ergodic_transfer(rng):
    """Across a radar outage the detector changes by an unknown dilation+anisotropy (M_B). If the chaotic
    source is stationary (time translation in Gamma of the SOURCE law), its invariant measure is a natural
    module that transfers the metre: M_B is recovered from moments. Stationarity is tested with
    dilation-free (affine-invariant) invariants. A drift below the test's sensitivity biases the result:
    that sensitivity floor is the boundary."""
    Tu = MUT.get("mc08_T", 3000)
    rot = lambda a: np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]])
    MB = rot(0.3) @ np.diag([1, 1.25])/0.0103
    sA = int(rng.integers(1, 10**6))
    PA_true = lorenz_fast(Tu, seed=sA)
    PA = PA_true + 0.01*rng.normal(size=PA_true.shape)            # radar-certified positions, 1 cm
    ia = _invariants(PA); se = np.std([_invariants(b) for b in np.array_split(PA, 10)], 0)/np.sqrt(10)*np.sqrt(2)
    pA, spA = _period(PA)
    out = {}
    for rho in MUT.get("mc08_rhos", (28.0, 28.15, 28.5, 29.0, 30.0)):
        PB = lorenz_fast(Tu, rho=rho, seed=int(rng.integers(1, 10**6)))
        YB = (PB + 0.02*rng.standard_t(3, PB.shape)) @ MB.T + 5.0
        M = _transfer(PA, YB)
        idx = rng.integers(0, len(PB)-50, 4000)
        dt_ = np.linalg.norm(PB[idx+50]-PB[idx], axis=1)
        de = np.linalg.norm((YB[idx+50]-YB[idx]) @ np.linalg.inv(M).T, axis=1)
        z = (_invariants(YB)-ia)/se
        pB, spB = _period(YB); zt = 0.0 if MUT.get("mc08_no_clock") else (pB-pA)/np.hypot(spA, spB)
        out[str(rho)] = dict(median_rel_err=f(np.median(np.abs(de-dt_)/dt_)), moment_max_abs_z=f(np.max(np.abs(z))),
                             period_z=f(zt), flagged=bool(max(np.max(np.abs(z)), abs(zt)) > 3.0))
    st = out["28.0"]
    floor = max([v["median_rel_err"] for v in out.values() if not v["flagged"]])
    missed_large = [k for k, v in out.items() if v["median_rel_err"] >= 0.03 and not v["flagged"]]
    passed = st["median_rel_err"] < 0.01 and not st["flagged"] and floor <= 0.015 and not missed_large
    out["certificate"] = dict(unflagged_error_floor=f(floor), large_error_drifts_missed=missed_large)
    register("MC08", "C2 (outage)", "Without an anchor during an outage the physical unit is lost (dilation fibre).",
             "Crossed under a testable hypothesis: a stationary chaotic source's invariant measure is a natural "
             "module that carries the metre across the outage (dilation and anisotropy recovered). Source drift "
             "is flagged by a clock-based period invariant that no spatial map can alter, plus affine moment "
             "invariants; drift below their sensitivity leaves a bounded, undetectable bias (the floor).",
             passed, dict(record_time_units=Tu, by_rho=out), "BOUNDARY")


ATTACKS = [MC01_regularity_wall, MC02_regularity_is_declared, MC03_wall_certification,
           MC04_anchor_budget, MC05_medium_as_kernel, MC06_count_loss, MC07_chaotic_slice,
           MC08_ergodic_transfer]


def run_all(seed):
    for a in ATTACKS:
        rng = np.random.default_rng([seed, ATTACKS.index(a)])
        try: a(rng)
        except Exception as ex: register(a.__name__[:4], "?", "?", f"EXCEPTION {ex!r}", False, {}, "ERROR")


def canary(seed):
    muts = {"MC02": {"mc02_sigma": 0.0},                     # remove the declared noise: regularity must fail
            "MC03": {"mc03_out": 0.6},                       # 60% outliers exceed the robust design
            "MC07": {"mc07_delta": 10.0},                    # disable the equivalence test
            "MC08": {"mc08_no_clock": True}}                 # remove the clock invariant: large drift slips through
    ok = True
    for tgt, m in muts.items():
        RESULTS.clear(); MUT.clear(); MUT.update(m)
        print(f"--- canary {tgt}: {m}")
        a = next(x for x in ATTACKS if x.__name__.startswith(tgt))
        try:
            a(np.random.default_rng([seed, ATTACKS.index(a)]))
            caught = not RESULTS[-1]["passed"]
        except Exception as ex:
            print(f"    exception {ex!r} counts as failure"); caught = True
        ok &= caught
        print(f"    {'CAUGHT' if caught else 'NOT CAUGHT'}")
    MUT.clear(); print("CANARY:", "all caught" if ok else "BATTERY TOO WEAK"); return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--seed", type=int, default=20260930)
    ap.add_argument("--out", default="rg_chaos_results.json"); ap.add_argument("--canary", action="store_true")
    a = ap.parse_args()
    if a.canary: sys.exit(canary(a.seed))
    t0 = time.time(); print(f"RG chaotic/dirty-data battery, seed {a.seed}\n"); run_all(a.seed)
    n = sum(r["passed"] for r in RESULTS)
    summ = dict(seed=a.seed, n_checks=len(RESULTS), n_pass=n,
                critique_confirmed=[r["id"] for r in RESULTS if r["verdict"] == "CONFIRMED" and r["passed"]],
                critique_falsified=[r["id"] for r in RESULTS if r["verdict"] == "FALSIFIED-critique" and r["passed"]],
                runtime_s=round(time.time()-t0, 1))
    json.dump(dict(summary=summ, results=RESULTS), open(a.out, "w"), indent=2,
              default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print(f"\n{n}/{len(RESULTS)} pass. Critique confirmed: {summ['critique_confirmed']}; falsified: {summ['critique_falsified']}")
    sys.exit(0 if n == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
