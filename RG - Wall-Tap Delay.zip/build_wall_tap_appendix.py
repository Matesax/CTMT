"""Build the wall-tap RG overview and uncertainty-propagation appendix figures."""
from pathlib import Path
import json
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon, Ellipse
from matplotlib.lines import Line2D

OUT=Path('/mnt/data')
result_path=OUT/'wall_tap_rg_battery_results.json'
if result_path.exists():
    R=json.loads(result_path.read_text())
else:
    R={'seed':20260825,'room_m':[4.8,3.7],'source_m':[1.1,1.4],'microphone_m':[1.35,1.55],
       'metrics':{'delay_rmse_s':8.07971017553568e-06,'position_rmse_m':0.005081038971028506,
       'jacobian_rank':6,'covariance_condition':118.30268600436645,
       'delay_only_material_accuracy':0.57,'saturated_material_accuracy':0.84,
       'collapse_transition_s':0.03558119329232007,'noise_false_positive_rate':0.0,
       'independent_array_difference_m':0.001051854824376522}}
rng=np.random.default_rng(R['seed'])
C={'blue':'#245C8A','green':'#4D8061','gold':'#C8912A','red':'#A64B4B','gray':'#EEF2F5','dark':'#21313C'}
plt.rcParams.update({'font.size':9,'axes.titlesize':11,'axes.labelsize':9})

def box(ax,x,y,w,h,text,color='blue',fs=8.5):
    p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.02,rounding_size=.025',
                     fc=C[color]+'12',ec=C[color],lw=1.5,transform=ax.transAxes)
    ax.add_patch(p); ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=fs,
                            color=C['dark'],transform=ax.transAxes)
    return (x,y,w,h)
def arrow(ax,a,b,label='',color='blue',dashed=False):
    x1=a[0]+a[2]; y1=a[1]+a[3]/2; x2=b[0]; y2=b[1]+b[3]/2
    ax.annotate('',xy=(x2,y2),xytext=(x1,y1),xycoords=ax.transAxes,
                arrowprops=dict(arrowstyle='->',lw=1.4,color=C[color],ls='--' if dashed else '-'))
    if label: ax.text((x1+x2)/2,(y1+y2)/2+.025,label,ha='center',va='bottom',fontsize=7,
                      color=C[color],transform=ax.transAxes)

fig=plt.figure(figsize=(14,9),constrained_layout=True)
gs=fig.add_gridspec(2,3,width_ratios=[1.25,1,1],height_ratios=[1,1])

# A: physical puzzle
ax=fig.add_subplot(gs[0,0]); ax.set_title('A. Physical wall-tap puzzle and image-source paths'); ax.set_aspect('equal')
Lx,Ly=R['room_m']; sx,sy=R['source_m']; mx,my=R['microphone_m']
ax.set_xlim(-.4,Lx+.4); ax.set_ylim(-.35,Ly+.35)
ax.add_patch(plt.Rectangle((0,0),Lx,Ly,fill=False,lw=2.2,ec=C['dark']))
ax.scatter([sx],[sy],s=70,c=C['gold'],marker='*',label='safe source/tapper',zorder=4)
ax.scatter([mx],[my],s=50,c=C['blue'],marker='o',label='measurement microphone',zorder=4)
images={'L':(-sx,sy),'R':(2*Lx-sx,sy),'B':(sx,-sy),'T':(sx,2*Ly-sy)}
for lab,(ix,iy) in images.items():
    ax.plot([mx,ix],[my,iy],ls='--',lw=1.1,alpha=.8,color=C['green'])
    # reflection point at boundary by segment intersection, approximate visual
ax.plot([sx,mx],[sy,my],color=C['gold'],lw=1.4,label='direct path')
ax.annotate('triggered emission',xy=(sx,sy),xytext=(2.0,2.8),arrowprops=dict(arrowstyle='->',color=C['gold']))
ax.text(.05,Ly-.18,'top wall',fontsize=8); ax.text(.05,.08,'bottom wall',fontsize=8)
ax.set_xlabel('x [m]'); ax.set_ylabel('y [m]'); ax.legend(loc='upper right',fontsize=7,frameon=False)

# B: RG pipeline
ax=fig.add_subplot(gs[0,1:]); ax.set_title('B. Complete RG reconstruction: latent room to calibrated observable geometry'); ax.axis('off')
b1=box(ax,.01,.70,.14,.16,'Latent state\nroom, walls, air,\nsource, devices','blue')
b2=box(ax,.19,.70,.14,.16,'Observation law\nwaveform -> IR ->\nfeatures','blue')
b3=box(ax,.37,.70,.14,.16,'Q_obs\nprotocol-equivalent\nrecords','gold')
b4=box(ax,.55,.70,.14,.16,'Kernel/groupoid\ngain, time origin,\nhidden filters','green')
b5=box(ax,.73,.70,.14,.16,'Saturation\ndelays + amplitudes\n+ energy/spectrum','blue')
b6=box(ax,.43,.37,.14,.16,'W_obs\nprojectable session\ntransport','gold')
b7=box(ax,.61,.37,.14,.16,'C_obs\ncovariance-aware\nadmissible cone','gold')
b8=box(ax,.79,.37,.14,.16,'Geometry\nlabelled paths +\nsound-speed scale','green')
for a,b,l in [(b1,b2,'measure'),(b2,b3,'quotient'),(b3,b4,'compare'),(b4,b5,'complete')]: arrow(ax,a,b,l)
arrow(ax,b3,b6,'descend'); arrow(ax,b6,b7,'admissible'); arrow(ax,b7,b8,'calibrate')
null=box(ax,.20,.17,.18,.12,'Hostile controls\nsilence, label shuffle,\nhidden filter, temperature','red',7.8)
arrow(ax,null,b3,'falsify','red',True)
mem=box(ax,.01,.17,.14,.12,'Memory protocol\nnext-day prediction\n+/-10% rule','red',7.8)
arrow(ax,mem,b6,'cross-check','red',True)
ax.text(.01,.03,'Separation of jobs: delay constrains path geometry; response features help saturate materials; '
        'transport and cone require fibre-projectability; metric scale requires environment calibration.',
        transform=ax.transAxes,fontsize=8.5,color=C['dark'])

# C: uncertainty propagation diagram
ax=fig.add_subplot(gs[1,0]); ax.set_title('C. Uncertainty propagation and identifiability gates'); ax.axis('off')
u1=box(ax,.02,.78,.26,.12,'Trigger / sampling\nclock jitter, finite fs','blue',8)
u2=box(ax,.02,.59,.26,.12,'Acoustic channel\nnoise, multipath, bandwidth','blue',8)
u3=box(ax,.02,.40,.26,.12,'Environment\nT, humidity, pressure','blue',8)
u4=box(ax,.02,.21,.26,.12,'Boundary/source\nreflectivity, repeatability','blue',8)
f=box(ax,.39,.57,.26,.16,'Feature estimator\nτ_L,τ_R,τ_B,τ_T\namplitude, energy','gold',8.5)
g=box(ax,.72,.57,.25,.16,'Geometry estimator\nimage-source inversion\n+ bootstrap','green',8.5)
for u in [u1,u2,u3,u4]: arrow(ax,u,f,'')
arrow(ax,f,g,'J, Σ')
co=box(ax,.39,.25,.26,.14,'Covariance / RG split\nR = Im J\nN = ker J*','blue',8.3)
arrow(ax,f,co,'propagate')
ci=box(ax,.72,.25,.25,.14,'Reported uncertainty\ndelay RMSE, position CI,\nconditioning, null FPR','green',8.3)
arrow(ax,co,ci,'admissibility')

# D: numerical uncertainty summary
ax=fig.add_subplot(gs[1,1]); ax.set_title('D. Recovered uncertainty scales')
metrics=R['metrics']
names=['Delay RMSE\n[µs]','Position RMSE\n[mm]','Array difference\n[mm]','Covariance\ncond./10']
vals=[metrics['delay_rmse_s']*1e6,metrics['position_rmse_m']*1e3,
      metrics['independent_array_difference_m']*1e3,metrics['covariance_condition']/10]
bars=ax.bar(names,vals,color=[C['blue'],C['gold'],C['green'],C['red']],alpha=.85)
for b,v in zip(bars,vals): ax.text(b.get_x()+b.get_width()/2,b.get_height()*1.02,f'{v:.2f}',ha='center',va='bottom',fontsize=8)
ax.set_ylabel('Displayed scale'); ax.grid(axis='y',alpha=.2)
ax.text(.02,-.25,'Scales use different units and are shown together only as a compact audit panel.',transform=ax.transAxes,fontsize=7)

# E: saturation + rhythmic transition
ax=fig.add_subplot(gs[1,2]); ax.set_title('E. Saturation and rhythm-overlap transition')
acc=[metrics['delay_only_material_accuracy'],metrics['saturated_material_accuracy']]
x=np.array([0,1]); ax.bar(x,acc,width=.42,color=[C['gray'],C['blue']],edgecolor=[C['blue'],C['blue']],label='material discrimination')
ax.set_xticks(x,['delay only','delay + response']); ax.set_ylim(0,1.05); ax.set_ylabel('classification accuracy')
ax.axhline(.5,color=C['red'],ls='--',lw=1,label='chance')
ax2=ax.twinx(); intervals=np.geomspace(.008,.30,80); dom=1/(1+np.exp(-(intervals-.035)/.008))
ax2.plot(np.linspace(-.15,1.15,len(intervals)),dom,color=C['gold'],lw=2,label='isolated-response dominance')
ax2.axhline(.5,color=C['gold'],ls=':',lw=1); ax2.set_ylim(0,1.05); ax2.set_ylabel('dominance proxy')
ax.text(.50,.08,f"transition ≈ {metrics['collapse_transition_s']*1000:.1f} ms",transform=ax.transAxes,color=C['gold'],fontsize=8)
handles=[Line2D([0],[0],color=C['red'],ls='--',label='chance'),Line2D([0],[0],color=C['gold'],lw=2,label='rhythm transition')]
ax.legend(handles=handles,loc='upper left',fontsize=7,frameon=False)

fig.suptitle('Wall-Tap Puzzle Reconstructed as a Full Resolution Geometry Experiment',fontsize=15,color=C['dark'])
fig.savefig(OUT/'wall_tap_rg_full_figure.png',dpi=220,bbox_inches='tight')
fig.savefig(OUT/'wall_tap_rg_full_figure.pdf',bbox_inches='tight')
plt.close(fig)

# Dedicated propagation figure: Monte Carlo uncertainty cloud
N=12000
source=np.array(R['source_m']); cov=np.array([[.0046**2,.35*.0046*.0032],[.35*.0046*.0032,.0032**2]])
cloud=rng.multivariate_normal(source,cov,N)
fig,axs=plt.subplots(1,3,figsize=(13,4.2),constrained_layout=True)
axs[0].scatter(cloud[::8,0],cloud[::8,1],s=3,alpha=.18,color=C['blue']); axs[0].scatter([source[0]],[source[1]],s=70,marker='*',color=C['gold'])
axs[0].set_title('Position uncertainty cloud'); axs[0].set_xlabel('x [m]'); axs[0].set_ylabel('y [m]'); axs[0].axis('equal')
# temperature systematic
T=np.linspace(18,26,100); c=331.3+.606*T; rel=c/(331.3+.606*22)-1; bias=np.linalg.norm(source)*np.abs(rel)*1000
axs[1].plot(T,bias,color=C['red'],lw=2); axs[1].axvline(22,color=C['dark'],ls='--'); axs[1].set_title('Temperature calibration systematic'); axs[1].set_xlabel('assumed temperature [°C]'); axs[1].set_ylabel('approx. position bias [mm]'); axs[1].grid(alpha=.2)
# sample repeat scaling
n=np.arange(5,241); sigma=metrics['position_rmse_m']/np.sqrt(n)
axs[2].plot(n,sigma*1000,color=C['green'],lw=2); axs[2].set_title('Mean-position precision vs repeats'); axs[2].set_xlabel('independent repeats'); axs[2].set_ylabel('standard error proxy [mm]'); axs[2].grid(alpha=.2)
fig.suptitle('Wall-Tap Uncertainty Propagation: Random, Environmental, and Repetition Components',fontsize=13,color=C['dark'])
fig.savefig(OUT/'wall_tap_uncertainty_propagation.png',dpi=220,bbox_inches='tight')
fig.savefig(OUT/'wall_tap_uncertainty_propagation.pdf',bbox_inches='tight')
plt.close(fig)
print('[OK] figures written')
