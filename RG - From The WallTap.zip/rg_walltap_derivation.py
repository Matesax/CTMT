"""Exact witnesses for 'From the Wall-Tap: A Standalone Derivation'. Rational arithmetic where possible; no random sampling.
E1  processing deficit identity: F_p(u) - F_{Kp}(Ku) = sum_x p_x (u_x/p_x - (Ku)_y/(Kp)_y)^2 K(y|x), exactly, on a rational grid of cases
E2  reversible-refinement classification: on the quarter grid of 2-input / 3-output stochastic maps, a stochastic left inverse exists iff the
    columns have disjoint supports (left inverse tested by exact construction and by LP)
E3  uniform splitting: splitting each of n symbols into k equal labels maps |v|^2 to |v|^2 / k (exact)
E4  rational extension: the splitting of a rational law p = k/N into the uniform law on N symbols gives sum u_i^2 / (N p_i) (exact)
E5  binary confirmation: optimal equal-prior error = (1 - TV)/2, exactly, on a rational grid of law pairs
E6  hybrid bound: |P^n(A) - Q^n(A)| <= n TV(P, Q) for every event A of n binary records (exact, n <= 6, all events for n <= 3)
E7  Chebyshev verifier: the elementary verifier for p in (0.3, 0.7) is sound at alpha = 0.05 (exact binomial sums)
E8  gluing on a graph: a group-valued conversion system on a connected overlap graph trivializes iff every cycle has trivial holonomy
    (spanning-tree construction; exact, Z and Z_2 examples)
E9  Cramer-Rao attained for the Bernoulli mean (exact)
E10 radial reflection: F - alpha^{-1} dPsi dPsi = -(alpha/q) Hess q has inertia (1, d - 1) for q = t^2 - |x|^2 (symbolic, d = 3)
E11 obstructions: an unperformed protocol separates two models that agree on all performed ones (exact)
Run: python rg_walltap_derivation.py   (sympy, scipy)
"""
import json, itertools, hashlib, pathlib
from fractions import Fraction as Fr
import sympy as sp
from scipy.optimize import linprog
import numpy as np
RES = {}
def must(c, m):
    if not c: raise AssertionError(m)
# E1
grid = [Fr(1, 5), Fr(2, 5), Fr(3, 5)]
count = 0
for p0 in [Fr(1, 4), Fr(1, 2), Fr(2, 3)]:
    p = [p0, 1 - p0]
    for u0 in [Fr(-1), Fr(1, 3), Fr(2)]:
        u = [u0, -u0]
        for a, b in itertools.product(grid, repeat=2):
            K = [[a, b], [1 - a, 1 - b]]                                   # K[y][x]
            Kp = [sum(K[y][x] * p[x] for x in range(2)) for y in range(2)]; Ku = [sum(K[y][x] * u[x] for x in range(2)) for y in range(2)]
            Fin = sum(u[x] ** 2 / p[x] for x in range(2)); Fout = sum(Ku[y] ** 2 / Kp[y] for y in range(2) if Kp[y] != 0)
            deficit = sum(p[x] * K[y][x] * (u[x] / p[x] - Ku[y] / Kp[y]) ** 2 for x in range(2) for y in range(2) if Kp[y] != 0)
            must(Fin - Fout == deficit and deficit >= 0, "E1"); count += 1
RES["E1"] = dict(cases=count, status="exact identity verified")
# E2
vals = [Fr(i, 4) for i in range(5)]
cols = [(a, b, 1 - a - b) for a in vals for b in vals if a + b <= 1]
n_maps = 0; n_rec = 0
for c0, c1 in itertools.product(cols, repeat=2):
    n_maps += 1
    disjoint = all(not (c0[y] > 0 and c1[y] > 0) for y in range(3))
    # LP: find L (2x3) stochastic columns with L K = I
    Kmat = np.array([[float(c0[y]), float(c1[y])] for y in range(3)])
    A_eq = []; b_eq = []
    for i in range(2):
        for x in range(2):
            row = np.zeros(6)
            for y in range(3): row[i * 3 + y] = Kmat[y, x]
            A_eq.append(row); b_eq.append(1.0 if i == x else 0.0)
    for y in range(3):
        row = np.zeros(6); row[y] = 1; row[3 + y] = 1; A_eq.append(row); b_eq.append(1.0)
    res = linprog(np.zeros(6), A_eq=np.array(A_eq), b_eq=np.array(b_eq), bounds=[(0, 1)] * 6, method="highs")
    must((res.status == 0) == disjoint, "E2"); n_rec += disjoint
RES["E2"] = dict(maps=n_maps, recoverable=n_rec, status="left inverse exists iff disjoint supports (all maps)")
# E3, E4
for n, k in [(2, 3), (3, 2), (4, 5)]:
    v = [Fr(i + 1) - Fr(n + 1, 2) for i in range(n)]
    Kv = [v[i] / k for i in range(n) for _ in range(k)]
    must(sum(x * x for x in Kv) == sum(x * x for x in v) / k, "E3")
pr = [Fr(1, 6), Fr(1, 3), Fr(1, 2)]; N = 6; u = [Fr(1), Fr(-3), Fr(2)]
Ku = [u[i] / (N * pr[i]) for i in range(3) for _ in range(int(N * pr[i]))]
must(sum(x * x for x in Ku) == sum(u[i] ** 2 / (N * pr[i]) for i in range(3)), "E4")
RES["E3_E4"] = dict(status="exact splitting identities verified")
# E5
cnt = 0
for p, q in itertools.product([Fr(i, 6) for i in range(7)], repeat=2):
    P = [p, 1 - p]; Q = [q, 1 - q]
    tv = sum(abs(P[i] - Q[i]) for i in range(2)) / 2
    best = min(sum((P[i] if d[i] == 1 else 0) + (Q[i] if d[i] == 0 else 0) for i in range(2)) / 2 for d in itertools.product((0, 1), repeat=2))
    must(best == (1 - tv) / 2, "E5"); cnt += 1
RES["E5"] = dict(pairs=cnt, status="optimal error = (1 - TV)/2 exactly")
# E6 hybrid bound
p, q = Fr(1, 3), Fr(1, 2); tv = abs(p - q)
for n in range(1, 4):
    seqs = list(itertools.product((0, 1), repeat=n))
    pr_p = {s: np.prod([p if b else 1 - p for b in s]) for s in seqs}; pr_q = {s: np.prod([q if b else 1 - q for b in s]) for s in seqs}
    for r in range(len(seqs) + 1):
        for A in itertools.combinations(seqs, r):
            must(abs(sum(pr_p[s] for s in A) - sum(pr_q[s] for s in A)) <= n * tv, "E6")
RES["E6"] = dict(status="hybrid bound verified on all events for n <= 3")
# E7 Chebyshev verifier: accept iff the interval [f - r, f + r] lies in (0.3, 0.7), r = sqrt(1/(4 n alpha))
alpha = Fr(1, 20)
def acc(theta, n):
    r = (1 / (4 * n * float(alpha))) ** 0.5; tot = Fr(0)
    for k in range(n + 1):
        f = k / n
        if f - r > 0.3 and f + r < 0.7: tot += sp.binomial(n, k) * theta ** k * (1 - theta) ** (n - k)
    return tot
worst = max(float(acc(Fr(t, 100), 400)) for t in list(range(1, 31)) + list(range(70, 100)))
inside = float(acc(Fr(1, 2), 400))
must(worst <= 0.05 and inside > 0.5, "E7")
RES["E7"] = dict(n=400, worst_false_acceptance=worst, acceptance_at_half=inside, status="sound (Chebyshev) and confirming")
# E8 gluing on a graph (spanning tree)
def trivialize(nodes, edges, op, inv, unit):
    # edges: dict (i, j) -> g_ij meaning s_j = g_ij * s_i ; returns potential h with g_ij = h_j * inv(h_i), or None
    h = {nodes[0]: unit}; frontier = [nodes[0]]
    adj = {}
    for (i, j), g in edges.items(): adj.setdefault(i, []).append((j, g)); adj.setdefault(j, []).append((i, inv(g)))
    while frontier:
        i = frontier.pop()
        for j, g in adj.get(i, []):
            if j not in h: h[j] = op(g, h[i]); frontier.append(j)
    ok = all(edges[(i, j)] == op(h[j], inv(h[i])) for (i, j) in edges)
    return h if ok else None
addZ = (lambda a, b: a + b, lambda a: -a, 0)
tri_ok = {(0, 1): 2, (1, 2): 3, (0, 2): 5}; tri_bad = {(0, 1): 2, (1, 2): 3, (0, 2): 4}
must(trivialize([0, 1, 2], tri_ok, *addZ) is not None and trivialize([0, 1, 2], tri_bad, *addZ) is None, "E8 Z")
mulZ2 = (lambda a, b: a * b, lambda a: a, 1)
mob = {(0, 1): 1, (1, 2): 1, (0, 2): -1}
must(trivialize([0, 1, 2], mob, *mulZ2) is None and trivialize([0, 1, 2], {(0, 1): 1, (1, 2): -1, (0, 2): -1}, *mulZ2) is not None, "E8 Z2")
RES["E8"] = dict(status="trivialization exists iff every cycle holonomy is trivial (Z: holonomy 0 vs 1; Z_2: Moebius holonomy -1)")
# E9 Cramer-Rao Bernoulli
th = sp.Symbol("theta", positive=True)
F = sp.simplify(1 / th + 1 / (1 - th)); var_mean = th * (1 - th)
must(sp.simplify(var_mean - 1 / F) == 0, "E9")
RES["E9"] = dict(status="Var(sample record) = 1/F: bound attained (n = 1)")
# E10 radial reflection
t, x1, x2 = sp.symbols("t x1 x2", real=True); q = t ** 2 - x1 ** 2 - x2 ** 2; a_ = sp.Rational(3, 2)
Psi = -a_ * sp.log(q); X = [t, x1, x2]
Fm = sp.hessian(Psi, X); dP = sp.Matrix([sp.diff(Psi, v) for v in X])
g = sp.simplify(Fm - dP * dP.T / a_)
must(sp.simplify(g + a_ / q * sp.hessian(q, X)) == sp.zeros(3), "E10 identity")
pt = {t: 2, x1: sp.Rational(1, 2), x2: sp.Rational(1, 3)}
eF = [float(e) for e in Fm.subs(pt).eigenvals(multiple=True)]; eg = [float(e) for e in g.subs(pt).eigenvals(multiple=True)]
must(min(eF) > 0 and sum(e < 0 for e in eg) == 1 and sum(e > 0 for e in eg) == 2, "E10 inertia")
RES["E10"] = dict(fisher_eigs=eF, reflected_eigs=eg, status="F > 0; reflection has inertia (1, 2)")
# E11 unperformed protocol
mA = {"a": (Fr(1, 2), Fr(1, 2)), "b": (Fr(1, 5), Fr(4, 5))}; mB = {"a": (Fr(1, 2), Fr(1, 2)), "b": (Fr(7, 10), Fr(3, 10))}
must(mA["a"] == mB["a"] and mA["b"] != mB["b"], "E11")
RES["E11"] = dict(status="models agree on performed protocol a, differ on unperformed b: records of a cannot select the response to b")
RES["source_sha256"] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
pathlib.Path("rg_walltap_derivation_results.json").write_text(json.dumps(RES, indent=1, default=str))
for k, v in RES.items():
    if isinstance(v, dict): print(k, "|", v["status"], {kk: vv for kk, vv in v.items() if kk != "status"})
