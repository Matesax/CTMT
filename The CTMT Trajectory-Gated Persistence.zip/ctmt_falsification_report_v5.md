# CTMT trajectory-gated falsification battery v5

This run replaces single-window gating by a multi-window persistence gate. Coherent directions are classified by survival across the Fisher trajectory, while violation scenarios are assessed by trajectory inconsistency rather than snapshot thresholds.

## Summary
| module   | scenario            |   accepted_windows_trajectory |   persistence_score |   persistence_stability |   coherent_count |   mean_cond_eff |   max_rupture |   mean_leakage | mean_fro_error     |   mean_projector_drift |   trajectory_inconsistency |   block_gap |   drift_tail_slope |   canonical_not_worse_rate | transport_pass_rate   | grade_v5           | gate_detection   | low_windows   | band_windows   | high_windows   |
|:---------|:--------------------|------------------------------:|--------------------:|------------------------:|-----------------:|----------------:|--------------:|---------------:|:-------------------|-----------------------:|---------------------------:|------------:|-------------------:|---------------------------:|:----------------------|:-------------------|:-----------------|:--------------|:---------------|:---------------|
| coil     | baseline            |                            12 |                   1 |                0.964782 |                4 |     2.46609e+07 |       3.34614 |    5.00547e-16 |                    |            0.0236286   |                    2.30672 |   0.084373  |        0.000180452 |                   0.833333 |                       | STRONG             |                  |               |                |                |
| coil     | anisotropy          |                            10 |                   1 |                0.964868 |                4 |     2.45583e+07 |       3.7729  |    4.77385e-16 |                    |            0.0236286   |                    6.11992 |   0.118402  |        4.14189e-05 |                   0.666667 |                       | STRONG             |                  |               |                |                |
| coil     | radius_coupling     |                            11 |                   1 |                0.971427 |                4 |     3.86259e+07 |       3.72157 |    4.76779e-16 |                    |            0.0233789   |                    2.32899 |   0.117507  |        0.00883916  |                   0        |                       | STRONG             |                  |               |                |                |
| coil     | dispersion          |                            12 |                   1 |                0.927359 |                4 |     2.63939e+07 |       3.11668 |    6.00057e-16 |                    |            0.00080753  |                    2.22082 |   0.0705756 |       -0.00369058  |                   0        |                       | STRONG             |                  |               |                |                |
| coil     | null_seepage        |                            10 |                   1 |                0.964782 |                4 |     2.46609e+07 |       4.18418 |    5.54139e-16 | 1.1806210067263536 |            0.0236286   |                    3.38084 |   0.140521  |       -7.96974e-05 |                   0.583333 |                       | STRONG             |                  |               |                |                |
| coil     | causal_violation    |                            12 |                   1 |                0.964782 |                4 |     2.46609e+07 |       3.35624 |    4.18797e-16 |                    |            0.0236286   |                    1.0901  |   0.602186  |        0.00083516  |                   0.25     |                       | DETECTED_VIOLATION | True             |               |                |                |
| coil     | unit_leak           |                             9 |                   1 |                0.964782 |                4 |     2.46609e+07 |       4.0202  |    5.10566e-16 |                    |            0.0236286   |                    1.19003 |   2.38311   |        0.00236476  |                   1        |                       | DETECTED_VIOLATION | True             |               |                |                |
| coil     | transport_reuse     |                            12 |                   1 |                0.964782 |                4 |     2.46609e+07 |       3.01793 |    4.6769e-16  |                    |            0.0236286   |                    1.40376 |   0.0709848 |       -1.23398e-05 |                   0.833333 | 0.75                  | STRONG             |                  |               |                |                |
| weak_toy | weak_activation_toy |                            12 |                 550 |                1        |                2 |  2306.61        |       0       |    0           |                    |            4.55979e-09 |                    0       |   0         |        0           |                   1        |                       | STRONG             |                  | 2.0           | 4.0            | 6.0            |

## Comparison to earlier runs
| scenario            |   v5_accept |     v5_proj | v5_grade           |
|:--------------------|------------:|------------:|:-------------------|
| baseline            |          12 | 0.0236286   | STRONG             |
| anisotropy          |          10 | 0.0236286   | STRONG             |
| radius_coupling     |          11 | 0.0233789   | STRONG             |
| dispersion          |          12 | 0.00080753  | STRONG             |
| null_seepage        |          10 | 0.0236286   | STRONG             |
| causal_violation    |          12 | 0.0236286   | DETECTED_VIOLATION |
| unit_leak           |           9 | 0.0236286   | DETECTED_VIOLATION |
| transport_reuse     |          12 | 0.0236286   | STRONG             |
| weak_activation_toy |          12 | 4.55979e-09 | STRONG             |

## Reading
- Strong or weak benign grades now arise from persistence score + projector continuity, not single-window rank alone.
- Violation scenarios are judged by trajectory inconsistency/block mismatch/drift-tail growth.
- Weak-direction theorem support remains on the dedicated PSD Fisher toy module with explicit threshold crossing.