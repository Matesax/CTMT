# RG - Real Measurements: calibrate once, compute many

    python3 rg_gnss_real_attack.py --data data --figs figs     # RD01-RD10 on real GEONET GPS data (~1 min)
    python3 rg_gnss_real_attack.py --data data --canary        # white-only uncertainty; peeking at B's anchor
    python3 synthetic/rg_geometry_benchmark.py --out synthetic # B01-B14 implementation regression (numpy 2 fixed)

Real data: GSI GEONET stations 0759 (A) and 3040 (B), 2005-04-02 00:00-01:00 GPST, dual-frequency code + phase,
GPS broadcast ephemeris; from the public RTKLIB test-data set. SHA256SUMS in data/.
One calibration (station A, first half hour, A's anchor), frozen, then used for B's position, the A-B baseline, B's
coverage and the swap. B's anchor is read only for evaluation (logged). Each RG layer is ablated and must fail.
Results: RD 10/10, canaries 2/2; synthetic 14/14 on five seeds, controls 14/14.
Plug in any RINEX 2 obs (C1, P2, L1, L2) + nav pair (e.g. IGS data from NASA CDDIS) by replacing data/.
