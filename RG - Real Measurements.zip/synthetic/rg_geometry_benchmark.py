#!/usr/bin/env python3
"""RG geometry regression suite. All observations are SYNTHETIC, not measured.
Dependencies: numpy scipy matplotlib. Run: python rg_geometry_benchmark.py --out /mnt/data
No external network or ephemeris is used. Numerical tests do not prove RG uniqueness.
"""
import argparse, json, math, hashlib, platform, csv
from pathlib import Path
import numpy as np
import scipy
from scipy.integrate import quad, solve_ivp
from scipy.optimize import brentq
from scipy.stats import norm, chi2
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
C=299792458.0
AU=149597870700.0 # Declared conventional benchmark length, not an observed Sun distance.
SEEDS=[20261019,1,42,777,2026]
N=20000
Z=norm.ppf(.975)

def f(x): return float(x)
def coverage(z): return f(np.mean(np.abs(z)<=Z))
def coverage_ok(c,n): return abs(c-.95)<=max(.008,4*math.sqrt(.95*.05/n))
def rel(a,b): return abs(a-b)/max(abs(b),1e-300)
def check(name,passed,metrics,canary,scope):
    return dict(name=name,passed=bool(passed),metrics=metrics,canary_caught=bool(canary),scope=scope)
def wrap(a): return (a+np.pi)%(2*np.pi)-np.pi

def radar_decode(t,b,k,half=True): return C*(t-b)/(1+k)*(0.5 if half else 1.)
def metric_decode(A,y,full=True):
    if full: return np.linalg.solve(A,y.T).T
    q=np.linalg.lstsq(A[:,:3].sum(axis=1)[:,None],y.T,rcond=None)[0][0]
    return np.column_stack([q,q,q,np.zeros((len(q),3))])
def null_time(r0,r1,rs,curved=True):
    return quad(lambda r: 1/(1-rs/r) if curved else 1.,r0,r1,epsabs=1e-11,epsrel=1e-12)[0]
def flrw_return(te,x,static=False):
    if static: return te+2*x*te**(2/3)
    tr=brentq(lambda t:quad(lambda s:s**(-2/3),te,t,epsabs=1e-12)[0]-x,te,100.)
    return brentq(lambda t:quad(lambda s:s**(-2/3),tr,t,epsabs=1e-12)[0]-x,tr,100.)

def run(seed):
    rng=np.random.default_rng(seed); out=[]
    # B01: clock-calibrated two-way range, with common clock-rate uncertainty.
    d=AU; tau=2*d/C; st=20e-9; sb=50e-9; sk=2e-9
    t=tau+rng.normal(0,st,N); b=rng.normal(0,sb,N); k=rng.normal(0,sk,N)
    est=radar_decode(t,b,k); sd=C/2*np.sqrt(st**2+sb**2+(tau*sk)**2)
    cov=coverage((est-d)/sd); ratio=np.std(est,ddof=1)/sd
    mutant=radar_decode(t,b,k,False)
    out.append(check('B01 calibrated one-AU radar',coverage_ok(cov,N) and abs(ratio-1)<.035,
      dict(reference_m=d,roundtrip_s=tau,sd_m=sd,bias_m=np.mean(est-d),coverage95=cov,sd_ratio=ratio,
           timing_sd_m=C*st/2,delay_sd_m=C*sb/2,clock_sd_m=d*sk,
           numerical_roundtrip_error_m=abs(radar_decode(tau,0,0)-d)),
      abs(np.mean(mutant)-d)>10*sd,'L8,L16,L28,L34,L51,L81-L83,L93-L109; stationary vacuum, SI scale and calibrated clock declared'))
    # B02: nonlinear triangulation with correlated baseline-angle errors.
    B=1000.; a=.02; sB=.02; sa=2e-5; rho=.6
    S=np.array([[sB*sB,rho*sB*sa],[rho*sB*sa,sa*sa]])
    obs=rng.multivariate_normal([B,a],S,N); truth=B/np.tan(a)
    est=obs[:,0]/np.tan(obs[:,1]); J=np.array([1/np.tan(a),-B/np.sin(a)**2]); sd=np.sqrt(J@S@J)
    cov=coverage((est-truth)/sd); sdwrong=np.sqrt(np.sum(J*J*np.diag(S)))
    # A distinct weak-parallax model has a 95% angle interval containing zero.
    weak_a=2e-5; weak_sa=2e-5; weak_gate=(weak_a-Z*weak_sa<=0)
    out.append(check('B02 correlated triangulation',coverage_ok(cov,N) and abs(np.std(est)/sd-1)<.035 and weak_gate,
      dict(reference_m=truth,sd_m=sd,coverage95=cov,bias_m=np.mean(est-truth),sd_ratio=np.std(est)/sd,
           covariance_omission_sd_ratio=sdwrong/sd,weak_parallax_status='CORRESPONDENCE',
           weak_angle95_rad=[weak_a-Z*weak_sa,weak_a+Z*weak_sa]),
      abs(sdwrong/sd-1)>.01,'L16,L18,L28,L34,L47,L51,L59,L61; known baseline, Gaussian covariance; weak parallax must not return finite Gaussian range'))
    # B03: GNSS-like pseudoranges; nuisance clock bias is estimated, not fixed.
    stations=np.array([[0,0,0],[10000,0,0],[0,10000,0],[0,0,10000],[10000,10000,10000],[-8000,6000,5000.]])
    x=np.array([2300.,3100.,4200.]); clock=80.; sig=.03; n=3000
    rr=np.linalg.norm(x-stations,axis=1); J=np.column_stack([(x-stations)/rr[:,None],np.ones(6)])
    V=sig**2*np.linalg.inv(J.T@J); Vx=V[:3,:3]
    y=rr+clock+rng.normal(0,sig,(n,6)); q=np.tile(np.r_[x+[100,-100,50],0.],(n,1))
    for _ in range(7):
        dv=q[:,:3,None].transpose(0,2,1)-stations[None,:,:]; r=np.linalg.norm(dv,axis=2)
        A=np.concatenate([dv/r[:,:,None],np.ones((n,6,1))],axis=2)
        resid=y-r-q[:,3,None]
        delta=np.linalg.solve(np.einsum('nki,nkj->nij',A,A),np.einsum('nki,nk->ni',A,resid)[...,None])[...,0]; q+=delta  # explicit trailing axis: numpy>=2 batched-solve semantics
    err=q[:,:3]-x; md=np.einsum('ni,ij,nj->n',err,np.linalg.inv(Vx),err)
    cov=f(np.mean(md<=chi2.ppf(.95,3))); rms=np.sqrt(np.mean(np.sum(err**2,axis=1)))
    # Actual mutant: refit the same data while fixing clock bias to zero.
    bad=np.tile(x,(n,1))
    for _ in range(7):
        dv=bad[:,None,:]-stations; r=np.linalg.norm(dv,axis=2); A=dv/r[:,:,None]
        bad+=np.linalg.solve(np.einsum('nki,nkj->nij',A,A),np.einsum('nki,nk->ni',A,y-r)[...,None])[...,0]
    # Schur-complement target information agrees with covariance block.
    I=J.T@J/sig**2; eff=I[:3,:3]-np.outer(I[:3,3],I[3,:3])/I[3,3]
    out.append(check('B03 multilateration with clock nuisance',coverage_ok(cov,n) and rel(rms,np.sqrt(np.trace(Vx)))<.06 and np.max(np.abs(np.linalg.inv(eff)-Vx))<1e-12,
      dict(position_m=x.tolist(),rms_position_m=rms,predicted_rms_m=np.sqrt(np.trace(Vx)),coverage95=cov,
           condition_number=np.linalg.cond(J),schur_covariance_error=np.max(np.abs(np.linalg.inv(eff)-Vx)),
           omitted_clock_bias_m=np.linalg.norm(np.mean(bad,axis=0)-x)),
      np.linalg.norm(np.mean(bad,axis=0)-x)>10*np.sqrt(np.trace(Vx)),
      'L3,L12,L18,L28,L34,L47,L51,L59,L80,L102,L109; station coordinates and clock model declared; not actual GNSS data'))
    # B04: six-parameter anisotropic metric from six independent anchors.
    dirs=np.array([[1,0,0],[0,1,0],[0,0,1],[1,1,0],[1,0,1],[0,1,1]],float)
    dirs/=np.linalg.norm(dirs,axis=1)[:,None]
    def design(v): return np.column_stack([v[:,0]**2,v[:,1]**2,v[:,2]**2,2*v[:,0]*v[:,1],2*v[:,0]*v[:,2],2*v[:,1]*v[:,2]])
    h=np.array([1.4,.9,1.2,.2,.1,-.08]); A=design(dirs); sy=.002
    y=A@h+rng.normal(0,sy,(N,6)); fit=metric_decode(A,y)
    v=np.array([[.3,.5,.8]]); v/=np.linalg.norm(v); av=design(v)[0]
    truth=av@h; pred=fit@av; sd=sy*np.linalg.norm(av@np.linalg.inv(A)); cov=coverage((pred-truth)/sd)
    bad=metric_decode(A,y,False)@av
    out.append(check('B04 anisotropic metric anchors',coverage_ok(cov,N) and np.linalg.matrix_rank(A)==6,
      dict(metric_parameters=h.tolist(),anchor_rank=6,heldout_squared_length=truth,sd_squared_length=sd,coverage95=cov,
           heldout_bias=np.mean(pred-truth),isotropic_mutant_bias=np.mean(bad-truth),isotropic_mutant_coverage95=coverage((bad-truth)/sd)),
      not coverage_ok(coverage((bad-truth)/sd),N),'L19,L28,L99,L100,L109; six independent anchors; isotropy not assumed'))
    # B05: curved connection: parallel transport on a unit sphere latitude.
    theta=.9
    def r(phi): return np.array([np.sin(theta)*np.cos(phi),np.sin(theta)*np.sin(phi),np.cos(theta)])
    def rp(phi): return np.array([-np.sin(theta)*np.sin(phi),np.sin(theta)*np.cos(phi),0.])
    e0=np.array([np.cos(theta),0.,-np.sin(theta)]); ephi=np.array([0.,1.,0.])
    sol=solve_ivp(lambda phi,v:-np.dot(v,rp(phi))*r(phi),[0,2*np.pi],e0,rtol=1e-11,atol=1e-12)
    vf=sol.y[:,-1]; angle=np.arctan2(vf@ephi,vf@e0); ref=wrap(-2*np.pi*np.cos(theta)); defect=abs(wrap(angle-ref))
    out.append(check('B05 sphere connection holonomy',defect<2e-9 and abs(np.linalg.norm(vf)-1)<2e-9,
      dict(holonomy_rad=angle,reference_rad=ref,error_rad=defect,norm_error=abs(np.linalg.norm(vf)-1),flat_mutant_error_rad=abs(ref)),
      abs(ref)>1e-2,'L19,L74-L80,L111; sphere metric and Levi-Civita transport declared, not selected by law equality'))
    # B06: Schwarzschild static radial radar vs proper rod length, c=1 dimensionless.
    rs=1.; r0=4.; r1=20.; lapse=np.sqrt(1-rs/r0)
    rad=lapse*null_time(r0,r1,rs); ref=lapse*((r1-r0)+rs*np.log((r1-rs)/(r0-rs)))
    rod=quad(lambda r:1/np.sqrt(1-rs/r),r0,r1,epsabs=1e-11)[0]
    bad=lapse*null_time(r0,r1,rs,False)
    out.append(check('B06 static curved radar versus rod',rel(rad,ref)<1e-11 and abs(rad-rod)>.1,
      dict(radar_rs=rad,analytic_radar_rs=ref,proper_rod_rs=rod,numerical_error_rs=abs(rad-ref),radar_rod_difference_rs=rad-rod,flat_mutant_error_rs=bad-ref),
      abs(bad-ref)>.1,'L67,L74,L81,L102-L104; Schwarzschild model imported; radar and rod tasks kept distinct'))
    # B07: rotating ring: null propagation quadrature vs Sagnac formula.
    beta=.2; R=1.; gamma=np.sqrt(1-beta*beta)
    tp=quad(lambda phi:R/(1-beta),0,2*np.pi)[0]*gamma
    tm=quad(lambda phi:R/(1+beta),0,2*np.pi)[0]*gamma
    delta=tp-tm; ref=4*np.pi*beta*R/gamma
    out.append(check('B07 rotating ring Sagnac',rel(delta,ref)<1e-12,
      dict(beta=beta,proper_delay_R_over_c=delta,reference_R_over_c=ref,error=abs(delta-ref),static_mutant_error=abs(delta)),
      abs(delta)>1.,'L81-L83,L93,L104-L105; stationary rotating ring, source proper time; not a static slice'))
    # B08: FLRW a(t)=t^(2/3), two emission epochs.
    xcom=.1; epochs=[1.,8.]; values=[]; defects=[]; static_errors=[]
    for te in epochs:
        ret=flrw_return(te,xcom); exact=(te**(1/3)+2*xcom/3)**3
        values.append((ret-te)/2); defects.append(abs(ret-exact)); static_errors.append(abs(flrw_return(te,xcom,True)-exact)/2)
    out.append(check('B08 expanding FLRW radar',max(defects)<1e-10 and values[1]>values[0]*3,
      dict(emission_times=epochs,radar_distances=values,root_errors=defects,static_mutant_errors=static_errors,status='OUTSIDE DOMAIN for time-independent radar metric'),
      max(static_errors)>1e-3,'L81,L102,L106; cosmological scale factor declared; numerical null-ray solution vs analytic solution'))
    # B09: fold, exact preimage correspondence vs an illicit positive branch.
    mu=4.; sigma=.5; obs=mu+rng.normal(0,sigma,N); lo=obs-Z*sigma; hi=obs+Z*sigma
    contains=(lo<=mu)&(mu<=hi); cov=f(np.mean(contains)); branch=np.sqrt(np.maximum(obs,0))
    negative_truth=-2.; branch_sd=sigma/(2*np.sqrt(mu)); badcov=f(np.mean(np.abs(branch-negative_truth)<=Z*branch_sd))
    out.append(check('B09 fold confidence correspondence',coverage_ok(cov,N) and badcov<.01,
      dict(correspondence_coverage95=cov,negative_branch_coverage95=badcov,observable_mean=mu,status='CORRESPONDENCE; sign unresolved'),
      badcov<.01,'L1-L2,L16,L21-L22,L47,L51; Gaussian observable law, no sign prior; confidence set pulled back through x squared'))
    # B10: medium distance-speed scale fibre.
    d=1000.; v=2e8; J=np.array([[2/v,-2*d/v**2]])
    # Dimensionless log coordinates avoid misleading unit-dependent rank thresholds.
    Jlog=J@np.diag([d,v]); null=np.array([1.,1.]); defect=np.linalg.norm(Jlog@null)
    anchored_sd=v/2*2e-9
    out.append(check('B10 medium scale ambiguity',np.linalg.matrix_rank(Jlog)==1 and defect<1e-18,
      dict(log_jacobian=Jlog.tolist(),rank=1,dimension=2,null_defect=defect,anchored_timing_sd_m=anchored_sd,
           alternative_distances_m=[1000.,1250.],alternative_speeds_m_s=[2e8,2.5e8],same_roundtrip_s=[2*1000/2e8,2*1250/2.5e8],status='CORRESPONDENCE without speed anchor'),
      np.linalg.matrix_rank(Jlog)<2,'L18,L28,L44,L94-L96,L102,L107; distance cannot be inferred from delay with unknown speed'))
    # B11: Lorentz cone recovery up to scale, then anchor.
    u=rng.normal(size=(80,3)); u/=np.linalg.norm(u,axis=1)[:,None]; rays=np.column_stack([np.ones(80),u])
    pairs=[(i,j) for i in range(4) for j in range(i,4)]
    A=np.column_stack([rays[:,i]*rays[:,j]*(1 if i==j else 2) for i,j in pairs])
    _,s,Vh=np.linalg.svd(A); h=Vh[-1]; h/=h[0]; target=np.array([-1 if i==j and i>0 else 1 if i==j else 0 for i,j in pairs],dtype=float)
    err=np.max(np.abs(h-target)); bad=target.copy(); bad[1]=.2
    out.append(check('B11 null cone conformal reconstruction',err<1e-12 and s[-2]>1e-2,
      dict(parameter_error=err,smallest_singular_value=s[-1],next_singular_value=s[-2],cone_residual=np.linalg.norm(A@h),
           normalization='h00=1 declared; scale not obtained from cone'),
      np.linalg.norm(A@bad)>.1,'L18,L19,L64-L68,L74; exact synthetic null directions; quadratic branch assumed; conformal factor unresolved'))
    # B12: physical distance invariant under noise, Fisher length is not.
    d=1200.; sigmas=np.array([1.,2.,10.,100.]); fisher=d/sigmas
    recovered=fisher*sigmas; bad=fisher*sigmas[0]
    out.append(check('B12 statistical versus physical distance',np.max(np.abs(recovered-d))<1e-10 and np.all(np.diff(fisher)<0),
      dict(physical_m=d,noise_m=sigmas.tolist(),fisher_lengths=fisher.tolist(),anchored_m=recovered.tolist(),fixed_scale_mutant_m=bad.tolist()),
      np.max(np.abs(bad-d))>100.,'L28-L29,L35,L59-L63,L99,L109; experiment-dependent calibration required'))
    # B13: one-anchor calibration does not validate a nonlinear response.
    L=1000.; alpha=.01
    response=lambda d:d+alpha*d*d/L
    gain=L/response(L); heldout=3000.; wrong=gain*response(heldout)
    tolerance=1.; rejected=abs(wrong-heldout)>tolerance
    out.append(check('B13 held-out anchor validation',abs(gain*response(L)-L)<1e-10 and rejected,
      dict(training_anchor_m=L,heldout_anchor_m=heldout,predicted_m=wrong,residual_m=wrong-heldout,tolerance_m=tolerance,
           status='INCONSISTENT with single-scale model'),
      rejected,'L99,L102,L108-L109; nonlinear detector deliberately violates global proportionality; one-anchor-only lock is rejected'))
    # B14: common systematic uncertainty cannot be averaged away.
    sizes=[1,10,100,1000]; white=10.; common=3.; covs=[]; naive=[]; sds=[]
    for count in sizes:
        err=rng.normal(0,white/np.sqrt(count),N)+rng.normal(0,common,N)
        sd=np.sqrt(white*white/count+common*common)
        covs.append(coverage(err/sd)); naive.append(coverage(err/(white/np.sqrt(count)))); sds.append(sd)
    out.append(check('B14 systematic uncertainty floor',all(coverage_ok(c,N) for c in covs),
      dict(sample_sizes=sizes,sd_m=sds,coverage95=covs,naive_coverage95=naive,systematic_floor_m=common),
      naive[-1]<.5,'L16,L28,L34,L51,L93,L108; common calibration error declared Gaussian; not iid across repeated observations'))
    return out

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out',default='.'); ap.add_argument('--seed',type=int); args=ap.parse_args()
    outdir=Path(args.out); outdir.mkdir(exist_ok=True,parents=True)
    seeds=[args.seed] if args.seed is not None else SEEDS
    runs=[dict(seed=s,checks=run(s)) for s in seeds]
    result=dict(protocol='synthetic conditional recovery, not empirical validation',seeds=seeds,monte_carlo_draws=N,
      constants=dict(c_m_s=C,declared_AU_m=AU),environment=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__),
      thresholds='coverage: abs(p-.95)<=max(.008,4 sqrt(.95*.05/n)); SD ratio .035; fixed deterministic tolerances in source',
      runs=runs,all_pass=all(t['passed'] for r in runs for t in r['checks']),
      all_canaries_caught=all(t['canary_caught'] for r in runs for t in r['checks']))
    result['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (outdir/'rg_geometry_results.json').write_text(json.dumps(result,indent=2))
    # Default matplotlib styling; labels in English.
    fig,ax=plt.subplots(1,2,figsize=(11,4))
    for j in range(4):
        cs=[r['checks'][j]['metrics']['coverage95'] for r in runs]
        ax[0].plot(range(len(seeds)),cs,'o',label=f'B0{j+1}')
    ax[0].set_xticks(range(len(seeds)),[str(s) for s in seeds],rotation=25); ax[0].axhline(.95); ax[0].set_xlabel('Seed'); ax[0].set_ylabel('95% interval coverage'); ax[0].legend()
    b12=runs[0]['checks'][11]['metrics']; ax[1].loglog(b12['noise_m'],np.array(b12['fisher_lengths'])/b12['fisher_lengths'][0],'o-',label='Fisher length / initial Fisher length')
    ax[1].loglog(b12['noise_m'],np.array(b12['anchored_m'])/b12['physical_m'],'s-',label='Physical distance / reference distance')
    ax[1].set_xlabel('Noise standard deviation (m)'); ax[1].set_ylabel('Dimensionless ratio'); ax[1].legend()
    fig.tight_layout(); fig.savefig(outdir/'rg_geometry_final_comparison.png',dpi=160); plt.close(fig)
    for r in runs:
        print('seed',r['seed'],'pass',sum(t['passed'] for t in r['checks']),'/14; canaries',sum(t['canary_caught'] for t in r['checks']),'/14')
        for t in r['checks']:
            if not t['passed'] or not t['canary_caught']: print('FAILED',t)
    print('All pass:',result['all_pass'],'All negative controls caught:',result['all_canaries_caught'])
    if not result['all_pass'] or not result['all_canaries_caught']: raise SystemExit(1)
if __name__=='__main__': main()
