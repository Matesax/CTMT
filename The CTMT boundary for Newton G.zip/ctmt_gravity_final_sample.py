import json
import numpy as np
import numpy.linalg as npl

mu0 = 4e-7 * np.pi

def loop_polyline(radius=0.05, nseg=400):
    phi = np.linspace(0, 2*np.pi, nseg, endpoint=False)
    return np.c_[radius*np.cos(phi), radius*np.sin(phi), np.zeros_like(phi)]

def axial_and_radial_sensors(nz=60, zmax=0.06, nr=40, rmax=0.08):
    z_axis = np.linspace(-zmax, zmax, nz)
    axis_pts = np.c_[np.zeros(nz), np.zeros(nz), z_axis]
    r_line = np.linspace(0.0, rmax, nr)
    rad_pts = np.c_[r_line, np.zeros(nr), np.zeros(nr)]
    return np.vstack([axis_pts, rad_pts])

def biot_savart_line(sensors, polyline, current=1.0):
    P0 = polyline
    P1 = np.roll(polyline, -1, axis=0)
    dL = P1 - P0
    B = np.zeros((sensors.shape[0], 3))
    for i, s in enumerate(sensors):
        r = s[None, :] - P0
        r_norm = np.maximum(np.linalg.norm(r, axis=1), 1e-15)
        r_hat = r / r_norm[:, None]
        cross = np.cross(dL, r_hat)
        contrib = mu0 * current * cross / (4*np.pi * r_norm[:, None]**2)
        B[i] = np.sum(contrib, axis=0)
    return B

def forward_Bz(theta, sensors, conductors):
    I, dx, dy = theta
    shifted = [poly + np.array([dx, dy, 0.0]) for poly in conductors]
    B = np.zeros((sensors.shape[0], 3))
    for poly in shifted:
        B += biot_savart_line(sensors, poly, current=I)
    return B[:, 2]

def jacobian_fd(theta0, sensors, conductors, h_frac=1e-6):
    base = forward_Bz(theta0, sensors, conductors)
    J = np.zeros((base.size, len(theta0)))
    for j in range(len(theta0)):
        t1 = theta0.copy()
        step = h_frac * max(1.0, abs(theta0[j]))
        t1[j] += step
        J[:, j] = (forward_Bz(t1, sensors, conductors) - base) / step
    return base, J

def fisher(J, C, jitter=1e-18):
    Csym = 0.5*(C + C.T) + jitter*np.eye(C.shape[0])
    X = J.T @ npl.pinv(Csym) @ J
    return 0.5*(X + X.T)

def stable_rank(F):
    lam = np.clip(npl.eigvalsh(0.5*(F+F.T)), 0.0, None)
    return float((np.sum(lam)**2)/(np.sum(lam**2)+1e-30))

def effective_rank(F):
    lam = np.clip(npl.eigvalsh(0.5*(F+F.T)), 0.0, None)
    s = np.sum(lam)
    if s <= 0:
        return 0.0
    p = lam/s
    p = p[p > 0]
    return float(np.exp(-np.sum(p*np.log(p))))

def visible_fraction(F, F0):
    eta_tr = float(np.trace(F)/(np.trace(F0)+1e-30))
    eta_acc = float(effective_rank(F)/(effective_rank(F0)+1e-30))
    return {
        'eta_trace': eta_tr,
        'eta_access': eta_acc,
        'eta_visible': eta_tr*eta_acc,
        'stable_rank': stable_rank(F),
        'effective_rank': effective_rank(F),
        'evals': npl.eigvalsh(F)[::-1].tolist(),
    }

def pairwise_coarse_grain_matrix(m):
    rows = []
    for i in range(0, m-1, 2):
        row = np.zeros(m)
        row[i] = 0.5
        row[i+1] = 0.5
        rows.append(row)
    if m % 2 == 1:
        row = np.zeros(m)
        row[-1] = 1.0
        rows.append(row)
    return np.vstack(rows)

def random_transport_kernel(m, keep=12, mild=(0.35, 0.75), severe=20, rng=None):
    rng = np.random.default_rng() if rng is None else rng
    Q, _ = np.linalg.qr(rng.normal(size=(m, m)))
    c = np.ones(m)
    if m > keep:
        c[keep:] = rng.uniform(mild[0], mild[1], size=m - keep)
        sev = min(severe, m - keep)
        if sev > 0:
            idx = rng.choice(np.arange(keep, m), size=sev, replace=False)
            c[idx] *= rng.uniform(0.02, 0.12, size=sev)
    return Q @ np.diag(c) @ Q.T

def transform(K, J, C):
    Jn = K @ J
    Cn = K @ C @ K.T
    return Jn, 0.5*(Cn + Cn.T) + 1e-18*np.eye(Cn.shape[0])

def make_sensor_noise_cov(m):
    sig = np.linspace(1e-8, 4e-8, m)
    C = np.diag(sig**2)
    for i in range(m - 1):
        C[i, i+1] = C[i+1, i] = 0.15 * sig[i] * sig[i+1]
    return C

def run_sample(seed=7, n_transport=8, n_coarse=6, n_hybrid=6):
    rng = np.random.default_rng(seed)
    sensors = axial_and_radial_sensors()
    conductors = [loop_polyline()]
    theta0 = np.array([4.0, 0.0, 0.0], dtype=float)
    _, J0 = jacobian_fd(theta0, sensors, conductors)
    C0 = make_sensor_noise_cov(J0.shape[0])
    F0 = fisher(J0, C0)
    out = {'transport': [], 'coarse': [], 'hybrid': []}
    Jn, Cn = J0.copy(), C0.copy()
    for _ in range(n_transport):
        K = random_transport_kernel(Jn.shape[0], keep=max(4, Jn.shape[0]//10), rng=rng)
        Jn, Cn = transform(K, Jn, Cn)
        out['transport'].append(visible_fraction(fisher(Jn, Cn), F0))
    Jn, Cn = J0.copy(), C0.copy()
    for _ in range(n_coarse):
        P = pairwise_coarse_grain_matrix(Jn.shape[0])
        Jn, Cn = transform(P, Jn, Cn)
        out['coarse'].append(visible_fraction(fisher(Jn, Cn), F0))
        if Jn.shape[0] <= 3:
            break
    Jn, Cn = J0.copy(), C0.copy()
    for _ in range(n_hybrid):
        L = random_transport_kernel(Jn.shape[0], keep=max(2, Jn.shape[0]//6), rng=rng)
        Jn, Cn = transform(L, Jn, Cn)
        P = pairwise_coarse_grain_matrix(Jn.shape[0])
        Jn, Cn = transform(P, Jn, Cn)
        out['hybrid'].append(visible_fraction(fisher(Jn, Cn), F0))
        if Jn.shape[0] <= 3:
            break
    print(json.dumps(out, indent=2))

if __name__ == '__main__':
    run_sample(seed=7)
