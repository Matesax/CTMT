# Final prediction lock attack

Seeds: `[1729, 271828, 314159]`

**Attacked predictions:** 5
**Unconditional predictions surviving:** 0
**Locked results:** 3
**Conditional empirical targets:** 1

## Overall verdict

The previous five extrapolations do not lock from kappa_1. The foundation closes only as a typed separation theorem plus a one-sided singular diagnostic. New physics starts only after an independent compatibility axiom links relict profiles to causal or transport structure.

## P1_integer_relict_exponent_hierarchy: REFUTED_AS_UNIVERSAL

Finite integer exponents hold for finite-order analytic germs, not for general differentiable or smooth maps. The lockable object is a scale profile, not a universally discrete exponent.

```json
{
  "analytic_monomials_q_exponents": {
    "x^2": 1,
    "x^3": 2,
    "x^5": 4
  },
  "C1_nonanalytic_F=sign(x)|x|^1.5_q_exponent": 0.5,
  "smooth_flat_profile_has_no_finite_power_law": {
    "first": 3.7200759760207834e-43,
    "last": 0.0,
    "underflow_zero_count": 14
  }
}
```

## P2_relict_density_classifier: REFUTED_IN_PROPOSED_LIMIT_FORM

The local Lipschitz-style limit cannot separate higher-order relicts from exact fibres: both give zero. Only the full germ/profile or an exact existence statement at every neighborhood separates them.

```json
{
  "F=x^3_D_epsilon": {
    "0.1": 0.010000000000000002,
    "0.01": 0.0001,
    "0.0001": 1e-08,
    "1e-08": 1.0000000000000001e-16
  },
  "limit_epsilon_to_zero": 0.0,
  "exact_fibre_example": "F(x,y)=x along v=(0,1): D_epsilon=0",
  "finite_resolution_issue": "flat injective germs can be below every fixed threshold"
}
```

## P3_relict_growth_precedes_criticality: REFUTED

Relict dimension can appear only at the critical parameter, persist without a transition, or remain zero through rank collapse. No universal precursor law follows.

```json
{
  "abrupt_family_F_t=t*x+x^3": {
    "-1": {
      "rank": 1,
      "relict_dim": 0
    },
    "-0.1": {
      "rank": 1,
      "relict_dim": 0
    },
    "-1e-06": {
      "rank": 1,
      "relict_dim": 0
    },
    "0": {
      "rank": 0,
      "relict_dim": 1
    },
    "1e-06": {
      "rank": 1,
      "relict_dim": 0
    },
    "0.1": {
      "rank": 1,
      "relict_dim": 0
    },
    "1": {
      "rank": 1,
      "relict_dim": 0
    }
  },
  "persistent_without_transition": "F_t=x^3 has relict_dim=1 for every t",
  "rank_collapse_without_relict_F_t=t*x": {
    "-1": {
      "rank": 1,
      "relict_dim": 0
    },
    "-1e-06": {
      "rank": 1,
      "relict_dim": 0
    },
    "0": {
      "rank": 0,
      "relict_dim": 0
    },
    "1e-06": {
      "rank": 1,
      "relict_dim": 0
    },
    "1": {
      "rank": 1,
      "relict_dim": 0
    }
  }
}
```

## P4_causal_cone_divergence: UNDERDETERMINED_NOT_PREDICTED

Causal order is independent declared/imported structure. Identical pullback and relict data admit incompatible causal preorders, so cone divergence is not forced. A comparison theorem needs an explicit compatibility axiom between reachability and F.

```json
{
  "observation_map": "F(x)=x^3, exact quotient is R, dF_0=0",
  "model_A": "declare standard order x<=y; exact quotient has standard order",
  "model_B": "declare equality-only preorder; exact quotient has equality-only order",
  "same_pullback_relict_data": true
}
```

## P5_transport_ambiguity_lower_bound: REFUTED_WITHOUT_COMPATIBILITY_AXIOMS

Relict dimension neither lower-bounds nor determines connection ambiguity in the current axioms. The claim becomes meaningful only after defining admissible connections and the observation/transport map whose fibre is the ambiguity window.

```json
{
  "countermodel_1": {
    "M": "R",
    "F": "x^3",
    "relict_dim_at_0": 1,
    "connection": "declared flat Gamma=0",
    "connection_ambiguity_dimension": 0
  },
  "countermodel_2": {
    "M": "R",
    "F": "x",
    "relict_dim": 0,
    "compatible_data_absent": "infinitely many declared affine connections Gamma(x)"
  },
  "reason": "(F,Sigma,K) has no specified forward map to connection or equivalence relation on connections"
}
```

## L1_pullback_form: LOCKED_RELATIVE_THEOREM

This is canonical relative to declared (F,Sigma), not relative to the kernel pair alone.

```json
{
  "random_trials": 300,
  "seeds": [
    1729,
    271828,
    314159
  ],
  "max_relative_coordinate_error": 1.570563173536226e-12,
  "exact_statement": "For differentiable F and positive-definite Sigma, g=F*(Sigma^-1) is PSD and rad(g)=ker(dF)."
}
```

## L2_regular_fibre_identification: LOCKED_WITH_GATE

Exact tangent ignorance is identified by the Fisher radical only on a constant-rank stratum.

```json
{
  "gate": "F has locally constant rank",
  "consequence": "ker(dF_x)=T_x(F^{-1}(F(x)))",
  "failure_example": "F=x^3 at 0"
}
```

## L3_relict_falsification: LOCKED_ONE_SIDED

The diagnostic can falsify exact nullness. Certification requires symbolic/tame/quasianalytic assumptions or direct access to the exact fibre germ.

```json
{
  "rule": "If dF_x v=0 and for every neighborhood there exists nonzero s with F(x+s v)!=F(x), then v is not an exact straight-line fibre direction.",
  "numerical_status": "Finite multiscale tests can witness differences but cannot certify their absence."
}
```

## L4_novel_empirical_target: CONDITIONAL_PREDICTION

The honest novel prediction is not a universal exponent or transport law. It is excess finite-scale distinguishability inside the first-order null sector, conditional on a specified observation model and perturbation protocol.

```json
{
  "observable": "scale-dependent distinguishability profile rho_x(v,r)=||F(x+rv)-F(x)||_{Sigma^-1}/|r| for v in ker(dF_x)",
  "null_standard_first_order_prediction": "rho tends to zero",
  "additional_testable_content": "nonzero finite-scale rho and its scaling/crossover structure",
  "required_protocol": "declare perturbation path, noise model, resolution floor, and compare repeated scales"
}
```

## Minimal locked ladder

- K0 Exact layer: kernel pair R_F and quotient Q_F are extensional data.
- K1 Declared smooth-statistical lift: choose differentiable F and positive-definite Sigma.
- K2 Pullback theorem: g_F=F*(Sigma^-1), rad(g_F)=ker dF.
- K3 Regularity gate: constant rank implies rad(g_F)=tangent to exact fibre.
- K4 Singular diagnostic: finite-scale separation inside rad(g_F) falsifies exact fibre membership.
- K5 Non-closure: no unrestricted C-infinity jet/numerical procedure certifies exact fibre equality.
- K6 Prediction interface: rho(v,r) is measurable only after perturbation, covariance, and resolution protocols are declared.
- K7 Causal/transport firewall: no claim about cones, memory, or connection follows until a separate compatibility law is stated and attacked.

## Required next axiom for a real prediction

{
  "name": "Relict-response compatibility law",
  "form": "Specify an independently measurable response Y and a preregistered functional H such that Y=H[rho] (or a bounded inequality) across systems/scales.",
  "falsification": "Find equal rho profiles with different Y, or different rho profiles with equal Y, under matched declared controls.",
  "warning": "Without this law, causal and transport statements are interpretations, not predictions."
}

## Non-claims

- No causal cone was derived from Fisher/relict data.
- No connection was selected from a memory kernel.
- No criticality precursor was established.
- No universal discrete exponent spectrum was established.