#!/usr/bin/env python3
"""Hostile attack of K7 directions: rho -> response -> causal/transport structure.
Builds explicit finite/analytic countermodels and identifies the minimal conditional locks.
"""
from __future__ import annotations
import json, math
from pathlib import Path
import numpy as np

SEEDS=[1729,271828,314159]

def rho_power(m,r): return r**(m-1)

def conv_response(kernel, forcing, dt):
    n=len(forcing); y=np.zeros(n)
    for i in range(n):
        # causal discrete convolution
        y[i]=dt*np.dot(kernel[:i+1][::-1],forcing[:i+1])
    return y

def result(name,status,evidence,verdict):
    return dict(name=name,status=status,evidence=evidence,verdict=verdict)

R=[]
# K7-A: rho -> scalar dynamic response Y cannot be universal.
r=np.logspace(-4,-1,40); rho=rho_power(3,r)
# Same rho, independently selectable gain/dynamics.
t=np.linspace(0,8,801); dt=t[1]-t[0]; u=np.sin(1.3*t)+.3*np.sin(3.1*t)
k1=np.exp(-t); k2=2*np.exp(-.2*t)*np.cos(1.7*t)
y1=conv_response(k1,u,dt); y2=conv_response(k2,u,dt)
R.append(result('K7A_universal_rho_to_response','REFUTED',{
 'same_observation_germ':'F(x)=x^3 at x=0','same_rho_sample':[float(rho[0]),float(rho[-1])],
 'kernel_1':'exp(-t)','kernel_2':'2 exp(-0.2t) cos(1.7t)',
 'relative_response_difference':float(np.linalg.norm(y1-y2)/(1+np.linalg.norm(y1)))},
 'The static relict profile does not determine a dynamical response. Identical rho admits arbitrarily different memory kernels and outputs.'))

# K7-B: response does not identify kernel under restricted excitation.
# Constant forcing only measures cumulative integral; construct kernels differing by zero-integral oscillation over window.
T=10; tt=np.linspace(0,T,1001); dtt=tt[1]-tt[0]
base=np.exp(-tt)
h=np.sin(2*np.pi*tt/T)
# remove discrete mean exactly
h=h-np.sum(h)*np.ones_like(h)/len(h)
kA=base; kB=base+0.8*h
u_const=np.ones_like(tt)
yA=conv_response(kA,u_const,dtt); yB=conv_response(kB,u_const,dtt)
# final-time equality from equal integrals, trajectories differ; a single terminal response cannot identify K.
R.append(result('K7B_response_to_memory_kernel','REFUTED_WITHOUT_PERSISTENT_EXCITATION',{
 'terminal_response_difference':float(abs(yA[-1]-yB[-1])),
 'kernel_L2_difference':float(np.linalg.norm(kA-kB)*math.sqrt(dtt)),
 'full_trajectory_difference':float(np.linalg.norm(yA-yB)*math.sqrt(dtt)),
 'observation_protocol':'only terminal response to constant forcing'},
 'A restricted response protocol leaves a nontrivial kernel nullspace. Kernel recovery needs a declared forward equation, sufficiently rich excitation, observation horizon, and regularization/identifiability gate.'))

# K7-C: even known K does not select affine connection.
R.append(result('K7C_memory_kernel_to_connection','REFUTED',{
 'fixed_kernel':'K(t)=exp(-t)',
 'connection_family':'on R, Gamma_c(x)=c for arbitrary real c',
 'same_kernel_for_all_connections':True,
 'missing_structure':'no forward operator A: connection -> observable kernel'},
 'Without an explicit transport-to-memory forward map and gauge/equivalence choice, K and connection are independent typed data.'))

# K7-D: holonomy may constrain but not identify a connection.
# Abelian U(1): loop integrals see curvature/periods, gauge-related potentials differ; on interval no loops, all connection 1-forms invisible to holonomy.
R.append(result('K7D_holonomy_to_connection','LOCKED_ONLY_UP_TO_GAUGE_WITH_COMPLETENESS_GATE',{
 'gauge_example':'A and A+dphi have identical closed-loop holonomy in Abelian theory',
 'topology_counterexample':'on a contractible 1D interval there are no nontrivial closed loops, yet arbitrary connection 1-forms exist',
 'required_gate':'sufficient loop family plus bundle/group specification and reconstruction theorem'},
 'Holonomy is a legitimate transport observable, but connection reconstruction is at best gauge-relative and requires loop completeness.'))

# K7-E: rho/order to causal cone.
R.append(result('K7E_relict_profile_to_causal_order','REFUTED',{
 'fixed_data':'F(x)=x^3, rho(r)=r^2',
 'preorder_1':'usual order <=','preorder_2':'reverse order >=','preorder_3':'equality only',
 'all_share_same_rho':True},
 'Relict profiles contain distinguishability magnitude, not temporal orientation or reachability. No causal preorder follows without an independent directional compatibility law.'))

# K7-F: response support can induce a preorder, but only under explicit protocol.
# finite directed impulse graph; reachability is transitive closure. Show threshold instability.
A=np.array([[0,1,0,0],[0,0,1,0],[0,0,0,1],[0,0,0,0]],float)
def closure(adj):
    c=adj.astype(bool).copy(); n=len(c)
    for k in range(n): c |= c[:,k,None]&c[None,k,:]
    np.fill_diagonal(c,True); return c
C1=closure(A>0)
A_noisy=A.copy(); A_noisy[0,3]=1e-8
C_lo=closure(A_noisy>1e-9); C_hi=closure(A_noisy>1e-7)
R.append(result('K7F_response_support_to_preorder','CONDITIONAL_LOCK',{
 'construction':'i precedes j iff an allowed intervention at i produces detectable response at j; take transitive closure',
 'is_reflexive_transitive':True,
 'low_vs_high_threshold_closure_difference':int(np.sum(C_lo!=C_hi)),
 'required_gates':['intervention semantics','no hidden common causes or explicit latent treatment','detection threshold','composition stability','quotient projectability']},
 'A causal preorder can be operationally constructed from intervention-response support, but it is protocol-relative and threshold-sensitive. HKMM still requires its own spacetime/topological hypotheses.'))

# K7-G cone/conformal metric nonuniqueness unless quadratic cone gate.
# In 2D, Lorentz cone determines conformal ray under assumed quadratic Lorentz signature; arbitrary star-shaped directional boundary does not.
R.append(result('K7G_preorder_to_conformal_class','CONDITIONAL_EXISTING_THEOREM_INTERFACE',{
 'locked_input':'a sufficiently regular causal order on a spacetime satisfying causal/topological hypotheses',
 'not_from_rho':'rho alone supplies neither orientation nor cone composition',
 'quadraticity_gate':'observed directional boundary must be compatible with null cone of a Lorentzian quadratic form',
 'scale_status':'conformal factor remains unselected'},
 'The conformal class is a downstream realization result from causal order, not a prediction of the pullback leg. Absolute scale remains external.'))

# K7-H: strongest possible empirical bridge: inequalities, not exact universal map.
# Synthetic falsification of monotonic law Y increasing with integrated rho: create same rho integrals / opposite Y and noisy robustness.
rng=np.random.default_rng(SEEDS[0]); n=200
z=rng.uniform(0,1,n) # proposed rho summary
Y_pos=z+0.05*rng.normal(size=n)
Y_neg=1-z+0.05*rng.normal(size=n)
def spearman(a,b):
    ra=np.argsort(np.argsort(a)); rb=np.argsort(np.argsort(b)); return float(np.corrcoef(ra,rb)[0,1])
R.append(result('K7H_monotone_relict_response_law','NOT_DERIVABLE_BUT_FALSIFIABLE_AXIOM',{
 'same_relict_summary_distribution':True,
 'model_positive_spearman':spearman(z,Y_pos),'model_negative_spearman':spearman(z,Y_neg),
 'preregistered_test':'sign and lower confidence bound of rank association on held-out systems'},
 'A monotonic response law can be proposed as new physics, but it is an independent empirical axiom. Kappa_1 provides the covariate, not the sign or functional form.'))

# K7-I composability condition gives a theorem-shaped route.
R.append(result('K7I_composable_response_functor','MINIMAL_NOVEL_ROUTE',{
 'axioms':['identity intervention has identity response','serial interventions compose','observationally equivalent interventions have equivalent responses','response support is stable under declared coarse-graining'],
 'forced_output':'a representation/functor from the intervention category or quotient groupoid into response operators',
 'not_forced':'specific kernel, causal metric, affine connection, or physical law'},
 'This is the cleanest lock: composability converts experiments into transport-like operators. Geometry appears only after adding faithfulness, locality/nonlocality, continuity, and reconstruction gates.'))

summary={
 'directions_attacked':9,
 'unconditional_K7_physical_maps_surviving':0,
 'conditional_locks':3,
 'minimal_novel_route':'intervention-response composability -> operator representation; then separately test reconstruction to preorder, kernel, holonomy, or connection',
 'verdict':'K7 cannot be a single arrow. It must be a firewall of separately typed inverse problems. The only foundation-level bridge is composability/projectability of intervention responses; every geometric reconstruction needs its own identifiability theorem.'}
report={'title':'K7 hostile direction attack','seeds':SEEDS,'summary':summary,'results':R,
'locked_K7_ladder':[
 'K7.0 Declare intervention category I and observation quotient Q_F.',
 'K7.1 Measure response operators T_a for interventions a, with uncertainty and resolution.',
 'K7.2 Projectability gate: equivalent representatives induce equivalent observable responses.',
 'K7.3 Composability test: T_{b o a}=T_b T_a within preregistered error.',
 'K7.4 If memory representation is chosen, test kernel identifiability under persistent excitation.',
 'K7.5 If causal order is chosen, define it from intervention support and test transitivity, antisymmetry conditions, threshold stability, and hidden-confound controls.',
 'K7.6 If transport geometry is chosen, define forward map from admissible connections to response/holonomy and prove injectivity modulo gauge.',
 'K7.7 Only after K7.5 may an HKMM-type conformal realization be invoked; only after K7.6 may a connection be reconstructed.',
 'K7.8 rho is an input covariate/stratifier, not by itself a generator of dynamics, causality, or connection.'
],
'nonclaims':['No universal rho-to-response map was found.','No memory kernel selects a connection without a forward model.','No causal orientation follows from distinguishability magnitude.','No absolute metric scale follows from causal order.']}
Path('/mnt/data/k7_direction_attack_results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
md=['# K7 hostile direction attack','',f"Seeds: `{SEEDS}`",'',f"**Directions attacked:** {summary['directions_attacked']}",f"**Unconditional physical maps surviving:** {summary['unconditional_K7_physical_maps_surviving']}",f"**Conditional locks:** {summary['conditional_locks']}",'',f"## Verdict\n\n{summary['verdict']}",'']
for q in R:
    md += [f"## {q['name']}: {q['status']}",'',q['verdict'],'','```json',json.dumps(q['evidence'],indent=2,ensure_ascii=False),'```','']
md += ['## Locked K7 ladder','']+[f'- {z}' for z in report['locked_K7_ladder']]
md += ['','## Non-claims','']+[f'- {z}' for z in report['nonclaims']]
Path('/mnt/data/k7_direction_attack_report.md').write_text('\n'.join(md),encoding='utf-8')
print(json.dumps(summary,indent=2))
for q in R: print(q['status'],q['name'])
