#!/usr/bin/env python3
"""Final hostile attack on predictions proposed from the kappa_1 pullback/relict bridge.

Purpose: separate theorem-level consequences from attractive but non-forced extrapolations.
The battery builds explicit countermodels. No universal claim survives merely because a
finite numerical sample agrees with it.
"""
from __future__ import annotations
import json, math
from pathlib import Path
import numpy as np
import sympy as sp

SEEDS=[1729,271828,314159]
x,t=sp.symbols('x t', real=True)

def order_of_vanishing_poly(p,var=x,point=0,max_order=64):
    for k in range(max_order+1):
        if sp.simplify(sp.diff(p,var,k).subs(var,point)) != 0:
            return k
    return math.inf

def jac_rank_scalar(p,var=x,point=0):
    return 0 if sp.diff(p,var).subs(var,point)==0 else 1

def fibre_tangent_dim_poly(p,var=x,point=0):
    eq=sp.expand(p-p.subs(var,point))
    return 1 if eq==0 else 0  # in R, a nonzero polynomial has isolated local zero at point

def relict_dim_poly(p):
    return (1 if jac_rank_scalar(p)==0 else 0)-fibre_tangent_dim_poly(p)

def result(name,status,evidence,verdict):
    return {"name":name,"status":status,"evidence":evidence,"verdict":verdict}

R=[]
# P1 Universal integer relict exponent.
examples={"x^2":x**2,"x^3":x**3,"x^5":x**5}
orders={k:order_of_vanishing_poly(v)-1 for k,v in examples.items()}
# Counterexamples beyond analytic finite-order case.
def frac_map(z,a=1.5): return math.copysign(abs(z)**a,z)
def flat_map(z): return 0.0 if z==0 else math.copysign(math.exp(-1/z**2),z)
r=np.logspace(-1,-6,16)
def secant_exp(F):
    q=np.array([abs(F(float(h))-F(0.0))/h for h in r])
    good=q>0
    A=np.column_stack([np.log(r[good]),np.ones(good.sum())])
    slope=np.linalg.lstsq(A,np.log(q[good]),rcond=None)[0][0] if good.sum()>2 else math.inf
    return float(slope),q.tolist()
frac_slope,frac_q=secant_exp(frac_map)
flat_slope,flat_q=secant_exp(flat_map)
R.append(result("P1_integer_relict_exponent_hierarchy","REFUTED_AS_UNIVERSAL",
 {"analytic_monomials_q_exponents":orders,"C1_nonanalytic_F=sign(x)|x|^1.5_q_exponent":frac_slope,
  "smooth_flat_profile_has_no_finite_power_law":{"first":flat_q[0],"last":flat_q[-1],"underflow_zero_count":sum(v==0 for v in flat_q)}},
 "Finite integer exponents hold for finite-order analytic germs, not for general differentiable or smooth maps. The lockable object is a scale profile, not a universally discrete exponent."))

# P2 proposed D=sup ||delta F||/r classifies exact vs relict.
def D_eps_power(m,eps): return eps**(m-1)
D={str(e):D_eps_power(3,e) for e in [1e-1,1e-2,1e-4,1e-8]}
# Exact fibre direction example F(x,y)=x, v=(0,1), D=0; relict x^3 has D_eps>0 for each eps but tends to 0.
R.append(result("P2_relict_density_classifier","REFUTED_IN_PROPOSED_LIMIT_FORM",
 {"F=x^3_D_epsilon":D,"limit_epsilon_to_zero":0.0,
  "exact_fibre_example":"F(x,y)=x along v=(0,1): D_epsilon=0",
  "finite_resolution_issue":"flat injective germs can be below every fixed threshold"},
 "The local Lipschitz-style limit cannot separate higher-order relicts from exact fibres: both give zero. Only the full germ/profile or an exact existence statement at every neighborhood separates them."))

# P3 relict growth precedes criticality. Families with abrupt, persistent, absent precursor.
# F_t(x)=t*x+x^3: rank 1 for t!=0, relict dim 0; at t=0 relict dim 1. No pre-growth.
family={}
for tv in [-1,-0.1,-1e-6,0,1e-6,0.1,1]:
    p=tv*x+x**3
    family[str(tv)]={"rank":jac_rank_scalar(p),"relict_dim":relict_dim_poly(p)}
# Persistent relict with no event: x^3 for all t.
# Rank collapse with true fibre, no relict: F_t(x)=t*x; at t=0 constant, ker dim1 fibre tangent dim1 => relict0.
collapse={}
for tv in [-1,-1e-6,0,1e-6,1]:
    p=tv*x
    collapse[str(tv)]={"rank":jac_rank_scalar(p),"relict_dim":relict_dim_poly(p)}
R.append(result("P3_relict_growth_precedes_criticality","REFUTED",
 {"abrupt_family_F_t=t*x+x^3":family,"persistent_without_transition":"F_t=x^3 has relict_dim=1 for every t",
  "rank_collapse_without_relict_F_t=t*x":collapse},
 "Relict dimension can appear only at the critical parameter, persist without a transition, or remain zero through rank collapse. No universal precursor law follows."))

# P4 exact quotient causal cone differs from linearized quotient near singularity.
# Same F=x^3, same exact quotient point separation, same relict. Choose causal preorders producing same or different descent.
R.append(result("P4_causal_cone_divergence","UNDERDETERMINED_NOT_PREDICTED",
 {"observation_map":"F(x)=x^3, exact quotient is R, dF_0=0",
  "model_A":"declare standard order x<=y; exact quotient has standard order",
  "model_B":"declare equality-only preorder; exact quotient has equality-only order",
  "same_pullback_relict_data":True},
 "Causal order is independent declared/imported structure. Identical pullback and relict data admit incompatible causal preorders, so cone divergence is not forced. A comparison theorem needs an explicit compatibility axiom between reachability and F."))

# P5 dim connection ambiguity >= dim relict. Countermodel: Euclidean line with F=x^3 and independently fixed flat connection.
# Also regular F=x with arbitrary affine connections Gamma(x)=c, showing ambiguity without relict unless compatibility constrains it.
R.append(result("P5_transport_ambiguity_lower_bound","REFUTED_WITHOUT_COMPATIBILITY_AXIOMS",
 {"countermodel_1":{"M":"R","F":"x^3","relict_dim_at_0":1,"connection":"declared flat Gamma=0","connection_ambiguity_dimension":0},
  "countermodel_2":{"M":"R","F":"x","relict_dim":0,"compatible_data_absent":"infinitely many declared affine connections Gamma(x)"},
  "reason":"(F,Sigma,K) has no specified forward map to connection or equivalence relation on connections"},
 "Relict dimension neither lower-bounds nor determines connection ambiguity in the current axioms. The claim becomes meaningful only after defining admissible connections and the observation/transport map whose fibre is the ambiguity window."))

# What can actually lock.
# Verify coordinate covariance random battery and regular constant rank exemplars.
maxerr=0.0
for seed in SEEDS:
    rng=np.random.default_rng(seed)
    for _ in range(100):
        J=rng.normal(size=(4,3)); B=rng.normal(size=(4,4)); S=B@B.T+np.eye(4)
        A=rng.normal(size=(4,4)); C=rng.normal(size=(3,3))
        while abs(np.linalg.det(A))<.1: A=rng.normal(size=(4,4))
        while abs(np.linalg.det(C))<.1: C=rng.normal(size=(3,3))
        g=J.T@np.linalg.inv(S)@J
        gp=(A@J@C).T@np.linalg.inv(A@S@A.T)@(A@J@C)
        err=np.linalg.norm(gp-C.T@g@C)/(1+np.linalg.norm(C.T@g@C))
        maxerr=max(maxerr,float(err))
R.append(result("L1_pullback_form","LOCKED_RELATIVE_THEOREM",
 {"random_trials":300,"seeds":SEEDS,"max_relative_coordinate_error":maxerr,
  "exact_statement":"For differentiable F and positive-definite Sigma, g=F*(Sigma^-1) is PSD and rad(g)=ker(dF)."},
 "This is canonical relative to declared (F,Sigma), not relative to the kernel pair alone."))
R.append(result("L2_regular_fibre_identification","LOCKED_WITH_GATE",
 {"gate":"F has locally constant rank","consequence":"ker(dF_x)=T_x(F^{-1}(F(x)))",
  "failure_example":"F=x^3 at 0"},
 "Exact tangent ignorance is identified by the Fisher radical only on a constant-rank stratum."))
R.append(result("L3_relict_falsification","LOCKED_ONE_SIDED",
 {"rule":"If dF_x v=0 and for every neighborhood there exists nonzero s with F(x+s v)!=F(x), then v is not an exact straight-line fibre direction.",
  "numerical_status":"Finite multiscale tests can witness differences but cannot certify their absence."},
 "The diagnostic can falsify exact nullness. Certification requires symbolic/tame/quasianalytic assumptions or direct access to the exact fibre germ."))
R.append(result("L4_novel_empirical_target","CONDITIONAL_PREDICTION",
 {"observable":"scale-dependent distinguishability profile rho_x(v,r)=||F(x+rv)-F(x)||_{Sigma^-1}/|r| for v in ker(dF_x)",
  "null_standard_first_order_prediction":"rho tends to zero",
  "additional_testable_content":"nonzero finite-scale rho and its scaling/crossover structure",
  "required_protocol":"declare perturbation path, noise model, resolution floor, and compare repeated scales"},
 "The honest novel prediction is not a universal exponent or transport law. It is excess finite-scale distinguishability inside the first-order null sector, conditional on a specified observation model and perturbation protocol."))

summary={
 "attacked_predictions":5,
 "unconditional_predictions_surviving":0,
 "locked_results":3,
 "conditional_empirical_targets":1,
 "overall_verdict":"The previous five extrapolations do not lock from kappa_1. The foundation closes only as a typed separation theorem plus a one-sided singular diagnostic. New physics starts only after an independent compatibility axiom links relict profiles to causal or transport structure."
}
report={"title":"Final prediction lock attack","seeds":SEEDS,"summary":summary,"results":R,
 "minimal_locked_ladder":[
  "K0 Exact layer: kernel pair R_F and quotient Q_F are extensional data.",
  "K1 Declared smooth-statistical lift: choose differentiable F and positive-definite Sigma.",
  "K2 Pullback theorem: g_F=F*(Sigma^-1), rad(g_F)=ker dF.",
  "K3 Regularity gate: constant rank implies rad(g_F)=tangent to exact fibre.",
  "K4 Singular diagnostic: finite-scale separation inside rad(g_F) falsifies exact fibre membership.",
  "K5 Non-closure: no unrestricted C-infinity jet/numerical procedure certifies exact fibre equality.",
  "K6 Prediction interface: rho(v,r) is measurable only after perturbation, covariance, and resolution protocols are declared.",
  "K7 Causal/transport firewall: no claim about cones, memory, or connection follows until a separate compatibility law is stated and attacked."
 ],
 "required_next_axiom_for_real_prediction":{
  "name":"Relict-response compatibility law",
  "form":"Specify an independently measurable response Y and a preregistered functional H such that Y=H[rho] (or a bounded inequality) across systems/scales.",
  "falsification":"Find equal rho profiles with different Y, or different rho profiles with equal Y, under matched declared controls.",
  "warning":"Without this law, causal and transport statements are interpretations, not predictions."
 },
 "non_claims":["No causal cone was derived from Fisher/relict data.","No connection was selected from a memory kernel.","No criticality precursor was established.","No universal discrete exponent spectrum was established."]}
Path('/mnt/data/final_prediction_lock_results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
md=["# Final prediction lock attack","",f"Seeds: `{SEEDS}`","",f"**Attacked predictions:** {summary['attacked_predictions']}",f"**Unconditional predictions surviving:** {summary['unconditional_predictions_surviving']}",f"**Locked results:** {summary['locked_results']}",f"**Conditional empirical targets:** {summary['conditional_empirical_targets']}","",f"## Overall verdict\n\n{summary['overall_verdict']}",""]
for z in R:
    md += [f"## {z['name']}: {z['status']}","",z['verdict'],"","```json",json.dumps(z['evidence'],indent=2,ensure_ascii=False),"```",""]
md += ["## Minimal locked ladder",""]+[f"- {q}" for q in report['minimal_locked_ladder']]
md += ["","## Required next axiom for a real prediction","",json.dumps(report['required_next_axiom_for_real_prediction'],indent=2,ensure_ascii=False),"","## Non-claims",""]+[f"- {q}" for q in report['non_claims']]
Path('/mnt/data/final_prediction_lock_report.md').write_text('\n'.join(md),encoding='utf-8')
print(json.dumps(summary,indent=2))
for z in R: print(z['status'],z['name'])
print('maxerr',maxerr)
