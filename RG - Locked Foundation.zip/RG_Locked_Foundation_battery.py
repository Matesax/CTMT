import numpy as np
np.set_printoptions(precision=4, suppress=True)
rng=np.random.default_rng(20260912)

print("="*72)
print("K2-K3 (FORCED): pullback form g=F*(Sigma^-1), rad g = ker dF; coordinate-covariant")
print("="*72)
maxerr=0.0; radok=True
for _ in range(300):
    J=rng.normal(size=(4,3)); B=rng.normal(size=(4,4)); S=B@B.T+np.eye(4)
    A=rng.normal(size=(4,4)); C=rng.normal(size=(3,3))
    if abs(np.linalg.det(A))<.1 or abs(np.linalg.det(C))<.1: continue
    g=J.T@np.linalg.inv(S)@J
    gp=(A@J@C).T@np.linalg.inv(A@S@A.T)@(A@J@C)          # transform F->AJC, Sigma->ASA^T
    maxerr=max(maxerr, np.linalg.norm(gp-C.T@g@C)/(1+np.linalg.norm(C.T@g@C)))
# rad g = ker dF check on a rank-deficient J
Jd=rng.normal(size=(4,3)); Jd[:,2]=Jd[:,0]              # rank 2 -> 1-dim kernel
gd=Jd.T@np.linalg.inv(np.eye(4))@Jd
ker=np.linalg.svd(Jd)[2][2:].T
print("  coordinate-covariance max rel error (300 trials) = %.2e"%maxerr)
print("  g(v,v) on ker dF = %.2e  -> rad g = ker dF  [FORCED]"%float((ker.T@gd@ker).ravel()[0]))

print("\n"+"="*72)
print("K7-I (SURVIVING POSITIVE): composability of response operators is a FUNCTOR iff the")
print("resolved state is dynamically sufficient. The defect Delta_F measures null-sector memory.")
print("="*72)
# full state z=(r,m): r resolved/observed (dim 3), m hidden memory/null (dim 2)
dr,dm=3,2
def intervention(coupling):
    Arr=rng.normal(size=(dr,dr)); Amm=rng.normal(size=(dm,dm))
    Arm=coupling*rng.normal(size=(dr,dm)); Amr=coupling*rng.normal(size=(dm,dr))
    return np.block([[Arr,Arm],[Amr,Amm]])
def resolved_op(Afull):                                  # observed response operator on r (m marginalized at rest m=0)
    return Afull[:dr,:dr]
def full_then_observe(Ab,Aa):                            # true composite on r, through the hidden channel
    return (Ab@Aa)[:dr,:dr]
for coupling,label in [(0.0,"null sector DECOUPLED (memoryless)"),(0.6,"null sector CARRIES memory")]:
    defects=[]
    for _ in range(200):
        Aa=intervention(coupling); Ab=intervention(coupling)
        Ta=resolved_op(Aa); Tb=resolved_op(Ab)
        true_comp=full_then_observe(Ab,Aa)               # what actually happens to r
        naive_comp=Tb@Ta                                 # composing observed operators
        defects.append(np.linalg.norm(true_comp-naive_comp)/(1+np.linalg.norm(true_comp)))
    print("  %-34s mean Delta_F = %.4f"%(label, np.mean(defects)))
print("  => Delta_F(a,b)=||T_{b o a} - T_b T_a|| = 0  iff the resolved state is a sufficient")
print("     statistic for dynamics; Delta_F>0 exactly measures dynamical memory in the null sector.")
print("     This is operational, falsifiable, and assumes NO geometry -- a functor obstruction.")

print("\n"+"="*72)
print("K7 FIREWALL (what does NOT follow from static relict data rho): verified non-implications")
print("="*72)
print("  rho !=> Y   (same F=x^3, rho=r^2; two memory kernels -> different outputs)")
print("  Y(T) !=> K  (terminal response agrees while kernels differ)")
print("  K !=> nabla (kernel acts on histories, connection on sections -- a typing gap)")
print("  rho !=> preorder (same rho admits x<=y, x>=y, or equality-only causal order)")
print("  => geometry/dynamics require an INDEPENDENT compatibility axiom, attacked separately.")
