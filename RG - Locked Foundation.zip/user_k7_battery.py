import numpy as np
np.set_printoptions(precision=4, suppress=True)
rng=np.random.default_rng(20260912)

print('='*72)
print('K2-K3 (FORCED): pullback form g=F*(Sigma^-1), rad g = ker dF; coordinate-covariant')
print('='*72)
maxerr=0.0
for _ in range(300):
    J=rng.normal(size=(4,3)); B=rng.normal(size=(4,4)); S=B@B.T+np.eye(4)
    A=rng.normal(size=(4,4)); C=rng.normal(size=(3,3))
    if abs(np.linalg.det(A))<.1 or abs(np.linalg.det(C))<.1: continue
    g=J.T@np.linalg.inv(S)@J
    gp=(A@J@C).T@np.linalg.inv(A@S@A.T)@(A@J@C)
    maxerr=max(maxerr, np.linalg.norm(gp-C.T@g@C)/(1+np.linalg.norm(C.T@g@C)))
Jd=rng.normal(size=(4,3)); Jd[:,2]=Jd[:,0]
gd=Jd.T@Jd
ker=np.linalg.svd(Jd)[2][2:].T
print('  coordinate-covariance max rel error (300 trials) = %.2e'%maxerr)
print('  g(v,v) on ker dF = %.2e -> rad g = ker dF  [FORCED]'%float((ker.T@gd@ker).ravel()[0]))

print('\n'+'='*72)
print('K7-I (SURVIVING POSITIVE): composability of response operators')
print('='*72)
dr,dm=3,2
def intervention(coupling):
    Arr=rng.normal(size=(dr,dr)); Amm=rng.normal(size=(dm,dm))
    Arm=coupling*rng.normal(size=(dr,dm)); Amr=coupling*rng.normal(size=(dm,dr))
    return np.block([[Arr,Arm],[Amr,Amm]])
def resolved_op(Afull): return Afull[:dr,:dr]
def full_then_observe(Ab,Aa): return (Ab@Aa)[:dr,:dr]
for coupling,label in [(0.0,'null sector DECOUPLED (memoryless)'),(0.6,'null sector CARRIES memory')]:
    defects=[]
    for _ in range(200):
        Aa=intervention(coupling); Ab=intervention(coupling)
        Ta=resolved_op(Aa); Tb=resolved_op(Ab)
        true_comp=full_then_observe(Ab,Aa)
        naive_comp=Tb@Ta
        defects.append(np.linalg.norm(true_comp-naive_comp)/(1+np.linalg.norm(true_comp)))
    print('  %-34s mean Delta_F = %.4f'%(label, np.mean(defects)))
