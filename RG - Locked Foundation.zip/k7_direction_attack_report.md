# K7 hostile direction attack

Seeds: `[1729, 271828, 314159]`

**Directions attacked:** 9
**Unconditional physical maps surviving:** 0
**Conditional locks:** 3

## Verdict

K7 cannot be a single arrow. It must be a firewall of separately typed inverse problems. The only foundation-level bridge is composability/projectability of intervention responses; every geometric reconstruction needs its own identifiability theorem.

## K7A_universal_rho_to_response: REFUTED

The static relict profile does not determine a dynamical response. Identical rho admits arbitrarily different memory kernels and outputs.

```json
{
  "same_observation_germ": "F(x)=x^3 at x=0",
  "same_rho_sample": [
    9.999999999999999e-09,
    0.009999999999999998
  ],
  "kernel_1": "exp(-t)",
  "kernel_2": "2 exp(-0.2t) cos(1.7t)",
  "relative_response_difference": 3.0098743057026507
}
```

## K7B_response_to_memory_kernel: REFUTED_WITHOUT_PERSISTENT_EXCITATION

A restricted response protocol leaves a nontrivial kernel nullspace. Kernel recovery needs a declared forward equation, sufficiently rich excitation, observation horizon, and regularization/identifiability gate.

```json
{
  "terminal_response_difference": 2.220446049250313e-16,
  "kernel_L2_difference": 1.7888543819998324,
  "full_trajectory_difference": 4.931227440943987,
  "observation_protocol": "only terminal response to constant forcing"
}
```

## K7C_memory_kernel_to_connection: REFUTED

Without an explicit transport-to-memory forward map and gauge/equivalence choice, K and connection are independent typed data.

```json
{
  "fixed_kernel": "K(t)=exp(-t)",
  "connection_family": "on R, Gamma_c(x)=c for arbitrary real c",
  "same_kernel_for_all_connections": true,
  "missing_structure": "no forward operator A: connection -> observable kernel"
}
```

## K7D_holonomy_to_connection: LOCKED_ONLY_UP_TO_GAUGE_WITH_COMPLETENESS_GATE

Holonomy is a legitimate transport observable, but connection reconstruction is at best gauge-relative and requires loop completeness.

```json
{
  "gauge_example": "A and A+dphi have identical closed-loop holonomy in Abelian theory",
  "topology_counterexample": "on a contractible 1D interval there are no nontrivial closed loops, yet arbitrary connection 1-forms exist",
  "required_gate": "sufficient loop family plus bundle/group specification and reconstruction theorem"
}
```

## K7E_relict_profile_to_causal_order: REFUTED

Relict profiles contain distinguishability magnitude, not temporal orientation or reachability. No causal preorder follows without an independent directional compatibility law.

```json
{
  "fixed_data": "F(x)=x^3, rho(r)=r^2",
  "preorder_1": "usual order <=",
  "preorder_2": "reverse order >=",
  "preorder_3": "equality only",
  "all_share_same_rho": true
}
```

## K7F_response_support_to_preorder: CONDITIONAL_LOCK

A causal preorder can be operationally constructed from intervention-response support, but it is protocol-relative and threshold-sensitive. HKMM still requires its own spacetime/topological hypotheses.

```json
{
  "construction": "i precedes j iff an allowed intervention at i produces detectable response at j; take transitive closure",
  "is_reflexive_transitive": true,
  "low_vs_high_threshold_closure_difference": 0,
  "required_gates": [
    "intervention semantics",
    "no hidden common causes or explicit latent treatment",
    "detection threshold",
    "composition stability",
    "quotient projectability"
  ]
}
```

## K7G_preorder_to_conformal_class: CONDITIONAL_EXISTING_THEOREM_INTERFACE

The conformal class is a downstream realization result from causal order, not a prediction of the pullback leg. Absolute scale remains external.

```json
{
  "locked_input": "a sufficiently regular causal order on a spacetime satisfying causal/topological hypotheses",
  "not_from_rho": "rho alone supplies neither orientation nor cone composition",
  "quadraticity_gate": "observed directional boundary must be compatible with null cone of a Lorentzian quadratic form",
  "scale_status": "conformal factor remains unselected"
}
```

## K7H_monotone_relict_response_law: NOT_DERIVABLE_BUT_FALSIFIABLE_AXIOM

A monotonic response law can be proposed as new physics, but it is an independent empirical axiom. Kappa_1 provides the covariate, not the sign or functional form.

```json
{
  "same_relict_summary_distribution": true,
  "model_positive_spearman": 0.9861171529288235,
  "model_negative_spearman": -0.9856791419785496,
  "preregistered_test": "sign and lower confidence bound of rank association on held-out systems"
}
```

## K7I_composable_response_functor: MINIMAL_NOVEL_ROUTE

This is the cleanest lock: composability converts experiments into transport-like operators. Geometry appears only after adding faithfulness, locality/nonlocality, continuity, and reconstruction gates.

```json
{
  "axioms": [
    "identity intervention has identity response",
    "serial interventions compose",
    "observationally equivalent interventions have equivalent responses",
    "response support is stable under declared coarse-graining"
  ],
  "forced_output": "a representation/functor from the intervention category or quotient groupoid into response operators",
  "not_forced": "specific kernel, causal metric, affine connection, or physical law"
}
```

## Locked K7 ladder

- K7.0 Declare intervention category I and observation quotient Q_F.
- K7.1 Measure response operators T_a for interventions a, with uncertainty and resolution.
- K7.2 Projectability gate: equivalent representatives induce equivalent observable responses.
- K7.3 Composability test: T_{b o a}=T_b T_a within preregistered error.
- K7.4 If memory representation is chosen, test kernel identifiability under persistent excitation.
- K7.5 If causal order is chosen, define it from intervention support and test transitivity, antisymmetry conditions, threshold stability, and hidden-confound controls.
- K7.6 If transport geometry is chosen, define forward map from admissible connections to response/holonomy and prove injectivity modulo gauge.
- K7.7 Only after K7.5 may an HKMM-type conformal realization be invoked; only after K7.6 may a connection be reconstructed.
- K7.8 rho is an input covariate/stratifier, not by itself a generator of dynamics, causality, or connection.

## Non-claims

- No universal rho-to-response map was found.
- No memory kernel selects a connection without a forward model.
- No causal orientation follows from distinguishability magnitude.
- No absolute metric scale follows from causal order.