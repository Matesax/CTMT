#!/usr/bin/env python3
"""
RG Assembly-at-the-Kernel Hostile Battery
=========================================
Companion to "Assembly of Resolution Geometry". Target: the claim that ONE kernel groupoid K of
ONE joint observation law F_tot (source + clock + radar protocols), together with its covariance
group Stab and effective symmetry Gamma = Stab/Gauge, FORCES the ignorance law, the observable
invariants, operational duration, the cone branch and physical distance on a physical slice.

Discipline (unchanged from the corpus):
  * each attack registers a NAIVE claim and a SHARPENED claim;
  * a check PASSES iff the observed numbers match the pre-registered sharpened prediction;
  * any NaN/inf in the evidence fails the check;
  * --canary sabotages four structures; exactly the targeted checks must fail.

Run:  python3 rg_kernel_assembly_attack.py [--seed 20260929] [--out FILE] [--canary]
"""
import argparse, itertools, json, math, sys, time
import numpy as np
from scipy.linalg import expm
from scipy.stats import norm

RESULTS = []
MUT = {}
C_LIGHT = 299792458.0
NU_CS = 9192631770.0


def f(x):
    return float(np.round(float(x), 15))


def _finite(o):
    if isinstance(o, dict):
        return all(_finite(v) for v in o.values())
    if isinstance(o, (list, tuple)):
        return all(_finite(v) for v in o)
    if isinstance(o, float):
        return math.isfinite(o)
    return True


def register(aid, rung, naive, sharp, passed, ev, verdict):
    if not _finite(ev):
        passed, verdict = False, "NONFINITE"
    RESULTS.append(dict(id=aid, rung=rung, naive_claim=naive, sharpened_claim=sharp,
                        passed=bool(passed), verdict=verdict, evidence=ev))
    print(f"[{'PASS' if passed else 'FAIL'}] {aid:5s} {verdict:15s} {sharp[:84]}")


# ----------------------------------------------------------------- shared physical slice
def gaussian_fisher(mean_fn, cov_fn, theta, h=1e-6):
    """Exact Gaussian Fisher: dm' S^-1 dm + 1/2 tr(S^-1 dS S^-1 dS), central differences."""
    theta = np.asarray(theta, float)
    k = len(theta)
    S = cov_fn(theta); Si = np.linalg.inv(S)
    dm, dS = [], []
    for i in range(k):
        e = np.zeros(k); e[i] = h*max(1.0, abs(theta[i]))
        dm.append((mean_fn(theta+e)-mean_fn(theta-e))/(2*e[i]))
        dS.append((cov_fn(theta+e)-cov_fn(theta-e))/(2*e[i]))
    I = np.zeros((k, k))
    for i in range(k):
        for j in range(k):
            I[i, j] = dm[i] @ Si @ dm[j] + 0.5*np.trace(Si @ dS[i] @ Si @ dS[j])
    return 0.5*(I+I.T)


class Slice:
    """One physical slice, one joint law. Latent theta = (px, py, s, sigma, h).
       imaging : y_img ~ N(A p / s, (sigma/s)^2 I2)     detector in pixel units, pitch s unknown
       radar   : k     ~ N(2 nu |p| / c, sk^2)          Cs-cycle count at a reference station at 0
       clock   : r     ~ N(N0 (1 + kappa p_y), sc^2)     count ratio of a clock at p vs reference
       h       : silent latent label (enters nothing)."""
    def __init__(self, kappa=0.0, aniso=(1.0, 1.0), sk=0.5, sc=0.5, N0=1e4, sigma_grad=0.0,
                 channels=("img", "rad", "clk")):
        self.kappa, self.A, self.sk, self.sc, self.N0 = kappa, np.diag(aniso), sk, sc, N0
        self.sigma_grad, self.channels = sigma_grad, channels

    def mean(self, th):
        px, py, s, sig, h = th
        p = np.array([px, py]); out = []
        if "img" in self.channels: out += list(self.A @ p / s)
        if "rad" in self.channels: out += [2*NU_CS*np.linalg.norm(p)/C_LIGHT]
        if "clk" in self.channels: out += [self.N0*(1+self.kappa*py)]
        return np.array(out)

    def cov(self, th):
        px, py, s, sig, h = th
        d = []
        sg = sig*(1+self.sigma_grad*px)
        if "img" in self.channels: d += [(sg/s)**2]*2
        if "rad" in self.channels: d += [self.sk**2]
        if "clk" in self.channels: d += [self.sc**2]
        return np.diag(d)

    def fisher(self, th):
        return gaussian_fisher(self.mean, self.cov, th)


# ======================================================================== ATTACKS
def AK01_joint_kernel(rng):
    """K_(F1,F2) = K_F1 cap K_F2 (corpus: Ignorance Prop. 2.3). Naive: Q_tot = Q1 x Q2."""
    worst = 0; prod_gap = []
    for _ in range(300):
        n = 14
        F1 = rng.integers(0, 4, n); F2 = rng.integers(0, 4, n)
        K1 = {(i, j) for i in range(n) for j in range(n) if F1[i] == F1[j]}
        K2 = {(i, j) for i in range(n) for j in range(n) if F2[i] == F2[j]}
        Kt = {(i, j) for i in range(n) for j in range(n) if F1[i] == F1[j] and F2[i] == F2[j]}
        worst = max(worst, len(Kt ^ (K1 & K2)))
        prod_gap.append(len(set(F1))*len(set(F2)) - len(set(zip(F1, F2))))
    passed = worst == 0 and max(prod_gap) > 0
    register("AK01", "K0 (forced)",
             "The joint quotient of several protocols is the product of their quotients.",
             "Joint kernel is the intersection of kernels; Q_tot embeds in Q1 x Q2 and is generally a proper "
             "subset: protocols are coupled through the one latent space.",
             passed, dict(max_symmetric_difference=int(worst), max_product_minus_joint=int(max(prod_gap)),
                          mean_product_minus_joint=f(np.mean(prod_gap))), "FALSIFIED-naive")


def AK02_garbling_kernel(rng):
    """Markov garbling M: P_th = P_th' => M P_th = M P_th'. Strict enlargement exists."""
    viol = 0
    for _ in range(300):
        k = 6; T = 10
        base = rng.dirichlet(np.ones(k), size=6)
        idx = rng.integers(0, 6, T); P = base[idx]
        M = rng.dirichlet(np.ones(3), size=k)
        for i, j in itertools.combinations(range(T), 2):
            if np.allclose(P[i], P[j]) and not np.allclose(P[i] @ M, P[j] @ M):
                viol += 1
    P1 = np.array([0.1, 0.3, 0.6]); P2 = np.array([0.3, 0.1, 0.6])
    merge = np.array([[1, 0], [1, 0], [0, 1.0]])
    strict = (not np.allclose(P1, P2)) and np.allclose(P1 @ merge, P2 @ merge)
    passed = viol == 0 and strict
    register("AK02", "K0 (forced)",
             "Post-processing can be treated as a change of coordinates on the quotient.",
             "Garbling can only enlarge the kernel (K_F subset K_MF), strictly in general: ignorance growth "
             "under processing is forced by the kernel, not a separate law.",
             passed, dict(kernel_violations=int(viol), strict_enlargement_example=bool(strict)), "FALSIFIED-naive")


def AK03_count_rigidity(rng):
    """Order automorphisms of a count record {0..N} are trivial; real readouts carry an affine gauge."""
    counts = {}
    for N in range(1, 8):
        counts[N] = sum(1 for p in itertools.permutations(range(N+1))
                        if all(p[i] < p[i+1] for i in range(N)))
    # real readout: t -> a t + b preserves order and ratios of differences
    t = np.sort(rng.uniform(0, 10, 50)); a, b = 3.7, -2.0
    ratio_def = np.max(np.abs(np.diff(a*t+b)[1:]/np.diff(a*t+b)[:-1] - np.diff(t)[1:]/np.diff(t)[:-1]))
    surj = len(set(2*n for n in range(50)) & set(range(50)))  # n->2n image inside [0,50)
    passed = all(v == 1 for v in counts.values()) and ratio_def < 1e-9 and surj < 50
    register("AK03", "K1 (forced)",
             "A clock unit is a relabeling of outcomes like any other.",
             "Aut(N, <=) = {id}: a counted record admits no relabeling, so Psi acts trivially on count "
             "channels; continuous readouts carry an affine gauge. Unit rigidity enters only through counts.",
             passed, dict(order_automorphisms_by_N={str(k): int(v) for k, v in counts.items()},
                          affine_ratio_defect=f(ratio_def), image_size_of_n_to_2n_in_50=int(surj)), "HOLDS")


def AK04_exact_sequence(rng):
    """Brute force on X = Z4, F(x) = x mod 2. Stab (Psi = Sym(Y)), Gauge, Gamma; normality, faithfulness.
       Declared G = Z4 rotations: G cap Gauge = {0,2}, image Z2, extension does NOT split."""
    X = list(range(4)); F = [x % 2 for x in X]
    stab, gauge = [], []
    for phi in itertools.permutations(X):
        for psi in itertools.permutations(range(2)):
            if all(F[phi[x]] == psi[F[x]] for x in X):
                stab.append((phi, psi))
                if psi == (0, 1): gauge.append(phi)
    comp = lambda a, b: tuple(a[b[i]] for i in range(4))
    inv = lambda a: tuple(sorted(range(4), key=lambda i: a[i]))
    normal = all(comp(comp(s[0], g), inv(s[0])) in gauge for s in stab for g in gauge)
    gamma = {s[1] for s in stab}
    rot = [tuple((x+k) % 4 for x in X) for k in range(4)]
    G_gauge = [r for r in rot if all(F[r[x]] == F[x] for x in X)]
    # splitting: subgroup of G of order |image| meeting G_gauge trivially
    image = {tuple(F[r[x]] for x in (0, 1)) for r in rot}
    split = any(len(set(H)) == len(image) and set(H) & set(G_gauge) == {tuple(X)}
                for H in [[tuple(X), r] for r in rot if comp(r, r) == tuple(X)])
    passed = (len(stab) == 8 and len(gauge) == 4 and normal and len(gamma) == 2 and
              len(G_gauge) == 2 and len(image) == 2 and not split)
    register("AK04", "K1 (forced)",
             "Every observable symmetry lifts to a latent symmetry of the same order (Stab = Gauge x Gamma).",
             "1 -> Gauge -> Stab -> Gamma -> 1 is exact with Gauge normal and Gamma faithful on Q, but need not "
             "split: Z4 rotations over x mod 2 give a non-split extension of Z2 by Z2.",
             passed, dict(stab_order=len(stab), gauge_order=len(gauge), gauge_normal=bool(normal),
                          gamma_order=len(gamma), declared_G_gauge_part=len(G_gauge), splits=bool(split)),
             "FALSIFIED-naive")


def AK05_natural_descent(rng):
    """Curved fibres: q = (a + 0.5 h^2, b). Law y ~ N((q1, q2, q1 q2), I). Fisher is automatically
       vertical-annihilating and representative invariant. A non-natural construction (latent Euclidean
       metric on the orthogonal complement of the fibre) is NOT representative invariant."""
    pi = lambda t: np.array([t[0]+0.5*t[2]**2, t[1]])
    Dpi = lambda t: np.array([[1, 0, t[2]], [0, 1, 0.0]])
    mu = lambda q: np.array([q[0], q[1], q[0]*q[1]])
    Dmu = lambda q: np.array([[1, 0], [0, 1], [q[1], q[0]]])
    gF = lambda t: (Dmu(pi(t)) @ Dpi(t)).T @ (Dmu(pi(t)) @ Dpi(t))
    worst_v = worst_rep = 0.0; nonnat = 0.0
    for _ in range(300):
        t = rng.normal(size=3)
        v = np.array([-t[2], 0, 1.0])                          # fibre tangent
        worst_v = max(worst_v, np.linalg.norm(gF(t) @ v))
        t2 = t.copy(); t2[2] = rng.normal(); t2[0] = t[0]+0.5*t[2]**2-0.5*t2[2]**2   # same fibre
        w = rng.normal(size=2)
        lift = lambda tt: np.linalg.pinv(Dpi(tt)) @ w          # any lift (Fisher ignores vertical part)
        worst_rep = max(worst_rep, abs(lift(t) @ gF(t) @ lift(t) - lift(t2) @ gF(t2) @ lift(t2)))
        # non-natural: Euclidean norm of the minimal-norm (orthogonal) lift
        nonnat = max(nonnat, abs(lift(t) @ lift(t) - lift(t2) @ lift(t2)))
    passed = worst_v < 1e-12 and worst_rep < 1e-9 and nonnat > 1e-2
    register("AK05", "K2 (forced)",
             "Kernel-groupoid basicness must be verified separately for every module.",
             "Any module computed from the law and its derivatives (natural module) is automatically "
             "basic and representative invariant; a basicness failure diagnoses a non-natural, latent-"
             "structure-dependent construction.",
             passed, dict(max_vertical_annihilation=f(worst_v), max_representative_defect=f(worst_rep),
                          non_natural_representative_defect=f(nonnat)), "FALSIFIED-naive")


def AK06_declared_gauge_stability(rng):
    """X = Z_n x Z_2 (position, silent bit), F(x,b)=x. Declared A = bit flips at even x (sound).
       Physical G = shifts x -> x+1 is in Stab. A is not G-stable: completeness depends on the frame.
       G-stable A (flips everywhere): completeness is G-invariant."""
    n = MUT.get("ak06_n", 6)
    def complete_at(Aset, x):   # does A connect (x,0) and (x,1)?
        return x in Aset
    A_decl = {x for x in range(n) if x % 2 == 0}
    shifted = {(x+1) % n for x in A_decl}
    A_stab = set(range(n))
    comp_decl = [complete_at(A_decl, x) for x in range(n)]
    comp_stab = [complete_at(A_stab, x) for x in range(n)]
    passed = (shifted != A_decl) and (len(set(comp_decl)) == 2) and all(comp_stab)
    register("AK06", "K3 (gated)",
             "Gauge completeness is a property of the declared groupoid alone.",
             "Completeness is frame dependent unless A is normalized by the physical group G "
             "(gAg^-1 = A); for G-stable A and transitive G, completeness at one point is completeness "
             "everywhere.",
             passed, dict(A_declared=sorted(A_decl), A_shifted=sorted(shifted), complete_declared=comp_decl,
                          complete_G_stable=comp_stab), "FALSIFIED-naive")


def AK07_forced_cocycle(rng):
    """Clock readouts as functions of one hidden history variable tau. Equal kernels => unique transition
       maps and AUTOMATIC cocycle closure. Time-translation covariance => affine. Unequal kernel (environment-
       dependent clock) => no transition map exists."""
    tau = np.sort(rng.uniform(0, 10, 4000)); E = rng.normal(size=tau.size)
    T1 = 2*tau+1; T2 = 0.5*tau-3; T3 = tau+0.05*tau**2
    T4 = tau + MUT.get("ak07_env", 0.3)*E
    f21 = lambda t: np.interp(t, T1, T2); f32 = lambda t: np.interp(t, T2, T3); f31 = lambda t: np.interp(t, T1, T3)
    grid = np.linspace(T1.min()+0.1, T1.max()-0.1, 500)
    cocycle = np.max(np.abs(f32(f21(grid)) - f31(grid)))
    # affinity from translation covariance: T(tau+s)-T(tau) independent of tau
    s = 1.0
    cov_def = {name: f(np.ptp(fn(tau[tau < 9]+s)-fn(tau[tau < 9]))) for name, fn in
               [("T1", lambda x: 2*x+1), ("T2", lambda x: 0.5*x-3), ("T3", lambda x: x+0.05*x**2)]}
    A = np.vstack([grid, np.ones_like(grid)]).T
    aff_res = {"f21": f(np.max(np.abs(A @ np.linalg.lstsq(A, f21(grid), rcond=None)[0]-f21(grid)))),
               "f31": f(np.max(np.abs(A @ np.linalg.lstsq(A, f31(grid), rcond=None)[0]-f31(grid))))}
    # non-functionality of T4 over T1: nearly equal T1, different T4
    order = np.argsort(T1); d1 = np.diff(T1[order]); d4 = np.abs(np.diff(T4[order]))
    nonfun = float(np.max(d4[d1 < 1e-2])) if np.any(d1 < 1e-2) else 0.0
    passed = (cocycle < 1e-6 and cov_def["T1"] < 1e-9 and cov_def["T3"] > 0.1 and aff_res["f21"] < 1e-9
              and aff_res["f31"] > 0.1 and nonfun > 0.5)
    register("AK07", "K4 (forced + gated)",
             "Cross-clock cocycle closure is an empirical coincidence that must be tested separately.",
             "Clocks with equal kernel pairs have unique transition maps whose cocycle closure is forced; "
             "time-translation covariance forces affinity; a clock with a different kernel admits no "
             "transition map at all. Testing closure tests kernel equality.",
             passed, dict(cocycle_defect=f(cocycle), translation_covariance_defect=cov_def,
                          affine_fit_residual=aff_res, T4_nonfunctionality=f(nonfun)), "FALSIFIED-naive")


def AK08_anchor_is_kernel_intersection(rng):
    ranks = {}; nulls = []
    for ch in [("img",), ("img", "rad")]:
        S = Slice(channels=ch); rk = []
        for _ in range(100):
            th = np.array([rng.uniform(1, 5), rng.uniform(1, 5), rng.uniform(1e-3, 1e-2), rng.uniform(1e-3, 1e-2), 0.3])
            I = S.fisher(th)[:4, :4]
            Ii = I/np.linalg.norm(I)
            rk.append(int(np.sum(np.linalg.svd(Ii, compute_uv=False) > 1e-9)))
            if ch == ("img",):
                gen = th[:4]/np.linalg.norm(th[:4]); nulls.append(gen @ Ii @ gen)
        ranks["+".join(ch)] = sorted(set(rk))
    passed = ranks["img"] == [3] and ranks["img+rad"] == [4] and max(nulls) < 1e-9
    register("AK08", "K5 (forced)",
             "The physical unit is an external calibration step applied after the RG geometry is built.",
             "The anchor is one more protocol in the joint law: adding radar intersects the kernel and "
             "removes the dilation arrow (Fisher rank 3 -> 4 in (px,py,s,sigma)).",
             passed, dict(fisher_rank=ranks, imaging_dilation_form_max=f(max(nulls))), "FALSIFIED-naive")


def rot2(a):
    return np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]])


def stab_defect_rotation(S, th, a):
    """Is the rotation (p -> R p, outcomes: imaging -> R imaging, radar/clock fixed) in Stab?"""
    R = rot2(a); th2 = th.copy(); th2[:2] = R @ th[:2]
    m1, m2 = S.mean(th), S.mean(th2)
    psi = m1.copy(); psi[:2] = R @ m1[:2]
    C1, C2 = S.cov(th), S.cov(th2)
    return max(np.max(np.abs(psi-m2)/np.sqrt(np.diag(C1))), np.max(np.abs(np.diag(C1)-np.diag(C2))))


def AK09_redshift_is_gamma_membership(rng):
    k = MUT.get("ak09_kappa", 1e-3)
    out = {}
    for kap in (0.0, k):
        S = Slice(kappa=kap)
        d = max(stab_defect_rotation(S, np.array([*rng.uniform(1, 5, 2), 5e-3, 5e-3, 0.0]), rng.uniform(0, 2*np.pi))
                for _ in range(200))
        out[str(kap)] = f(d)
    passed = out["0.0"] < 1e-9 and out[str(k)] > 1.0
    register("AK09", "K5 (forced)",
             "'No redshift' (G4) is an independent physical gate of the distance module.",
             "No-redshift is membership of rotations/translations in the joint stabilizer: a clock-rate "
             "gradient removes the rotation from Gamma (defect in noise units), and with it Schur isotropy.",
             passed, dict(max_rotation_stab_defect_by_kappa=out), "FALSIFIED-naive")


def AK10_two_point_homogeneity(rng):
    """Diagonal action on pairs (s,t). E(2): orbit space dim 1 (distance). Translations only: dim 2.
       Explicit E(2) element maps any pair to any other pair with the same distance."""
    def gens_E2(z):  # infinitesimal generators on (s,t) in R^4
        s, t = z[:2], z[2:]; J = np.array([[0, -1], [1, 0.0]])
        return np.array([[1, 0, 1, 0], [0, 1, 0, 1], np.r_[J @ s, J @ t]])
    def gens_T2(z):
        return np.array([[1, 0, 1, 0], [0, 1, 0, 1.0]])
    dimE = {4-np.linalg.matrix_rank(gens_E2(rng.normal(size=4))) for _ in range(50)}
    dimT = {4-np.linalg.matrix_rank(gens_T2(rng.normal(size=4))) for _ in range(50)}
    worst = 0.0
    for _ in range(500):
        s1, t1 = rng.normal(size=2), rng.normal(size=2)
        d = np.linalg.norm(t1-s1); s2 = rng.normal(size=2); ang = rng.uniform(0, 2*np.pi)
        t2 = s2 + d*np.array([np.cos(ang), np.sin(ang)])
        a = np.arctan2(*(t2-s2)[::-1]) - np.arctan2(*(t1-s1)[::-1]); R = rot2(a); b = s2 - R @ s1
        worst = max(worst, np.linalg.norm(R @ s1 + b - s2) + np.linalg.norm(R @ t1 + b - t2))
    passed = dimE == {1} and dimT == {2} and worst < 1e-10
    register("AK10", "K6 (forced)",
             "Physical distance is a quantity the theory must postulate.",
             "If the joint law is E(n)-invariant under moving apparatus and target together (n >= 2), the "
             "orbit space of (station, target) pairs is one-dimensional: every two-point observable is a "
             "function of one invariant. With translations only, a 2-vector survives and distance is not forced.",
             passed, dict(orbit_space_dim_E2=sorted(dimE), orbit_space_dim_T2=sorted(dimT),
                          max_orbit_connection_error=f(worst)), "FALSIFIED-naive")


def AK11_lambda_constancy(rng):
    """lambda^2 = (Fisher metric of imaging in metres) / (radar metric): Gamma-invariant scalar.
       Homogeneous slice: constant. Position-dependent noise (translation covariance broken): varies."""
    g = MUT.get("ak11_grad", 0.2)
    out = {}
    for grad in (0.0, g):
        S = Slice(sigma_grad=grad, channels=("img",)); lam = []
        for _ in range(200):
            th = np.array([rng.uniform(0.5, 4), rng.uniform(0.5, 4), 1.0, 0.01, 0.0])   # s = 1 m/pixel after anchor
            G = S.fisher(th)[:2, :2]
            lam.append(np.sqrt(np.linalg.eigvalsh(G)))
        lam = np.array(lam)
        out[str(grad)] = dict(rel_spread=f(np.ptp(lam)/np.mean(lam)))
    passed = out["0.0"]["rel_spread"] < 1e-6 and out[str(g)]["rel_spread"] > 0.1
    register("AK11", "K6 (forced)",
             "A constant isotropic chart (lambda constant) must be assumed for the Euclidean limit.",
             "lambda_E is a ratio of two natural modules, hence a Gamma-invariant function on Q; Gamma-"
             "transitivity forces it constant. Breaking translation covariance (sigma(p)) makes it vary.",
             passed, dict(lambda_relative_spread=out), "FALSIFIED-naive")


def AK12_lorentz_cone_forced(rng):
    """SO+(1,2): invariant cones and invariant symmetric forms. Light cone invariant; quartic Finsler cone
       not; in 1+1 the spacelike wedge is an extra invariant convex cone (n = 1 boundary)."""
    K1 = np.array([[0, 1, 0], [1, 0, 0], [0, 0, 0.0]]); K2 = np.array([[0, 0, 1], [0, 0, 0], [1, 0, 0.0]])
    Jr = np.array([[0, 0, 0], [0, 0, -1], [0, 1, 0.0]])
    def rand_L():
        c = rng.normal(size=3)*0.8
        return expm(c[0]*K1 + c[1]*K2 + c[2]*Jr)
    # a cone is defined by a spatial norm N: C = {t >= N(x)}; membership AND boundary sampler both
    # derive from N (a decoupled sampler let an early canary slip through; see ledger)
    N_light = lambda u: np.hypot(u[0], u[1])
    N_quart = MUT.get("ak12_norm", lambda u: (u[0]**4+u[1]**4)**0.25)
    def violation(N):
        worst = 0.0
        for _ in range(400):
            ph = rng.uniform(0, 2*np.pi); u = np.array([np.cos(ph), np.sin(ph)])
            w = rand_L() @ np.array([N(u), u[0], u[1]])
            worst = min(worst, (w[0] - N(w[1:]))/np.linalg.norm(w))
        return -worst
    vl, vq = violation(N_light), violation(N_quart)
    # invariant symmetric forms: X^T G + G X = 0 for all generators
    basis = []
    for i in range(3):
        for j in range(i, 3):
            E = np.zeros((3, 3)); E[i, j] = E[j, i] = 1; basis.append(E)
    A = np.vstack([np.array([(X.T @ E + E @ X).ravel() for E in basis]).T for X in (K1, K2, Jr)])
    dim_forms = len(basis) - np.linalg.matrix_rank(A)
    # 1+1: wedge x >= |t| invariant under boosts
    wedge_ok = True
    for _ in range(300):
        b = rng.normal()*2; L = np.array([[np.cosh(b), np.sinh(b)], [np.sinh(b), np.cosh(b)]])
        t, x = rng.normal(), 0.0; x = abs(t) + abs(rng.normal())
        w = L @ np.array([t, x]); wedge_ok &= w[1] >= abs(w[0]) - 1e-12
    passed = vl < 1e-10 and vq > 1e-3 and dim_forms == 1 and wedge_ok
    register("AK12", "K7 (forced given Gamma)",
             "Quadraticity of the observable cone is a separate realization gate (R18 vs R19/R20).",
             "If Gamma contains SO+(1,n), n >= 2, acting on the horizontal tangent space, the invariant cone is "
             "the Lorentz cone and the invariant symmetric forms are one-dimensional: [g] is forced. Finsler "
             "branches are exactly boost-covariance breaking. For n = 1 an invariant spacelike wedge exists.",
             passed, dict(light_cone_violation=f(vl), quartic_cone_violation=f(vq),
                          invariant_form_dim=int(dim_forms), wedge_invariant_1p1=bool(wedge_ok)), "FALSIFIED-naive")


def AK13_dilation_not_in_gamma(rng):
    """Physical dilation p -> k p, sigma -> k sigma. Continuous imaging channel: outcome rescaling psi=k
       restores the law => dilation in Stab => no unit. Count channel: Psi trivial => not in Stab."""
    k = 1.37
    th = np.array([2.0, 3.0, 5e-3, 5e-3, 0.0]); th2 = th.copy(); th2[:2] *= k; th2[3] *= k
    Si = Slice(channels=("img",)); Sj = Slice(channels=("img", "rad"))
    m1, m2 = Si.mean(th), Si.mean(th2)
    img_def = max(np.max(np.abs(k*m1-m2)/np.sqrt(np.diag(Si.cov(th2)))),
                  np.max(np.abs(k**2*np.diag(Si.cov(th)) - np.diag(Si.cov(th2)))/np.diag(Si.cov(th2))))
    mj1, mj2 = Sj.mean(th), Sj.mean(th2)
    rad_def = abs(mj1[2]-mj2[2])/Sj.sk          # psi must be identity on counts
    passed = img_def < 1e-9 and rad_def > 10.0      # 10 noise units (threshold corrected from an unjustified 1e3, see ledger)
    register("AK13", "K5 (forced)",
             "Scale is fixed by adding any further physical measurement.",
             "Scale is fixed exactly when dilations leave Gamma. Continuous readouts keep dilations in Stab "
             "(outcome rescaling); a count channel is Psi-rigid (AK03) and removes them.",
             passed, dict(imaging_dilation_defect=f(img_def), radar_dilation_defect_noise_units=f(rad_def)),
             "FALSIFIED-naive")


def AK14_cross_module_lock(rng):
    """Isometry algebra of the imaging Fisher metric must equal that of the radar metric (both natural
       modules on one Q). Isotropic: equal. Anisotropic detector: mismatch -> the slice is falsified as a
       whole from data alone."""
    out = {}
    for an in [(1.0, 1.0), MUT.get("ak14_aniso", (1.0, 1.6))]:
        S = Slice(aniso=an, channels=("img",))
        G = S.fisher(np.array([2.0, 1.0, 1.0, 0.01, 0.0]))[:2, :2]
        # so(G) generator: X = G^-1 J (J skew) ; radar metric delta: X0 = J
        J = np.array([[0, -1], [1, 0.0]]); X = np.linalg.inv(G) @ J
        X /= np.linalg.norm(X); X0 = J/np.linalg.norm(J)
        out[str(an)] = f(min(np.linalg.norm(X-X0), np.linalg.norm(X+X0)))
    passed = out["(1.0, 1.0)"] < 1e-9 and out[str(MUT.get("ak14_aniso", (1.0, 1.6)))] > 1e-2
    register("AK14", "K8 (lock)",
             "Each module can be validated on its own protocol.",
             "Modules on one quotient must share one isometry algebra; a Fisher/radar mismatch falsifies "
             "the slice as a whole, without any external truth.",
             passed, dict(isometry_algebra_mismatch=out), "FALSIFIED-naive")


def AK15_end_to_end(rng):
    """Monte-Carlo slice. Empirical Gamma test for rotations by standardized mean differences.
       H0 homogeneous: rotation retained; three single-gear sabotages each remove it and each
       dependent prediction fails. Bonferroni-controlled z threshold."""
    n = 4000; pts = 30; zcrit = norm.isf(0.001/(pts*4)/2)
    variants = {"H0": Slice(), "redshift": Slice(kappa=2e-4), "anisotropic": Slice(aniso=(1.0, 1.02)),
                "noise_gradient": Slice(sigma_grad=0.05)}
    res = {}
    for name, S in variants.items():
        zmax = 0.0
        for _ in range(pts):
            th = np.array([*rng.uniform(1, 4, 2), 1e-3, 2e-3, 0.0]); a = rng.uniform(0.3, 2.8)
            R = rot2(a); th2 = th.copy(); th2[:2] = R @ th[:2]
            y1 = rng.normal(S.mean(th), np.sqrt(np.diag(S.cov(th))), size=(n, 4))
            y2 = rng.normal(S.mean(th2), np.sqrt(np.diag(S.cov(th2))), size=(n, 4))
            y1[:, :2] = y1[:, :2] @ R.T          # outcome relabeling psi
            z = (y1.mean(0)-y2.mean(0))/np.sqrt(y1.var(0)/n + y2.var(0)/n)
            zv = (np.log(y1.var(0)[:2]) - np.log(y2.var(0)[:2]))/np.sqrt(4/n)
            zmax = max(zmax, np.max(np.abs(z)), np.max(np.abs(zv)))
        res[name] = dict(max_z=f(zmax), rotation_in_Gamma=bool(zmax < zcrit))
    passed = res["H0"]["rotation_in_Gamma"] and not any(res[k]["rotation_in_Gamma"] for k in variants if k != "H0")
    register("AK15", "K8 (whole-slice test)",
             "A physical slice can pass some RG modules and fail others independently.",
             "One empirical object, Gamma, carries all modules: homogeneous slice retains rotations; "
             "each single-gear sabotage (redshift, anisotropy, noise gradient) is detected as loss of the "
             "same generator, so the dependent distance/angle/scale predictions fall together.",
             passed, dict(z_critical=f(zcrit), variants=res, samples_per_point=n, points=pts), "FALSIFIED-naive")


ATTACKS = [AK01_joint_kernel, AK02_garbling_kernel, AK03_count_rigidity, AK04_exact_sequence,
           AK05_natural_descent, AK06_declared_gauge_stability, AK07_forced_cocycle,
           AK08_anchor_is_kernel_intersection, AK09_redshift_is_gamma_membership, AK10_two_point_homogeneity,
           AK11_lambda_constancy, AK12_lorentz_cone_forced, AK13_dilation_not_in_gamma,
           AK14_cross_module_lock, AK15_end_to_end]


def run_all(seed):
    for atk in ATTACKS:
        rng = np.random.default_rng([seed, ATTACKS.index(atk)])
        try:
            atk(rng)
        except Exception as ex:
            register(atk.__name__.split("_")[0], "?", "?", f"EXCEPTION: {ex!r}", False, {}, "ERROR")


def canary(seed):
    muts = {"AK09": {"ak09_kappa": 0.0},                       # remove the redshift: no counterexample
            "AK12": {"ak12_norm": lambda u: np.hypot(u[0], u[1])},   # quartic norm replaced by Euclidean
            "AK07": {"ak07_env": 0.0},                         # environmental clock made functional
            "AK11": {"ak11_grad": 0.0}}                        # noise gradient removed
    ok = True
    for target, m in muts.items():
        RESULTS.clear(); MUT.clear(); MUT.update(m)
        print(f"--- canary: mutate {target}")
        run_all(seed)
        failed = sorted(r["id"] for r in RESULTS if not r["passed"])
        good = failed == [target]; ok &= good
        print(f"    failed: {failed} -> {'CAUGHT' if good else 'NOT CAUGHT'}")
    MUT.clear()
    print("\nCANARY RESULT:", "all mutations caught" if ok else "BATTERY TOO WEAK")
    return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=20260929)
    ap.add_argument("--out", default="rg_kernel_assembly_results.json")
    ap.add_argument("--canary", action="store_true")
    a = ap.parse_args()
    if a.canary:
        sys.exit(canary(a.seed))
    t0 = time.time()
    print(f"RG kernel-assembly hostile battery, seed {a.seed}\n")
    run_all(a.seed)
    n_pass = sum(r["passed"] for r in RESULTS)
    summ = dict(seed=a.seed, n_checks=len(RESULTS), n_pass=n_pass,
                naive_falsified=sum(r["verdict"] == "FALSIFIED-naive" and r["passed"] for r in RESULTS),
                runtime_s=round(time.time()-t0, 2), numpy=np.__version__)
    json.dump(dict(summary=summ, results=RESULTS), open(a.out, "w"), indent=2, default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print(f"\n{n_pass}/{len(RESULTS)} checks pass; {summ['naive_falsified']} naive claims falsified.")
    sys.exit(0 if n_pass == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
