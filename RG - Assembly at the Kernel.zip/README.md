# RG Assembly-at-the-Kernel Hostile Battery

Companion to *Resolution Geometry as an Observable Orbit-Cone Structure* (Assembly).
Claim under attack: one joint observation law F_tot (source + clock + radar), its kernel groupoid K and its
effective symmetry Gamma = Stab/Gauge force ignorance, observable invariants, duration, cone and physical distance.

## Run
```
python3 rg_kernel_assembly_attack.py            # seed 20260929
python3 rg_kernel_assembly_attack.py --seed 42
python3 rg_kernel_assembly_attack.py --canary   # sabotage AK07, AK09, AK11, AK12; exactly the target must fail
```
Requires numpy, scipy. Exit code 0 only if all registered checks pass.

## Result
15/15 pass, 14 naive claims falsified with counterexamples.
Seeds 1, 42, 777, 2026: 15/15. Canary: 4/4 caught.

| ID | Rung | Verdict | Naive claim attacked |
|---|---|---|---|
| AK01 | K0 (forced) | FALSIFIED-naive | The joint quotient of several protocols is the product of their quotients. |
| AK02 | K0 (forced) | FALSIFIED-naive | Post-processing can be treated as a change of coordinates on the quotient. |
| AK03 | K1 (forced) | HOLDS | A clock unit is a relabeling of outcomes like any other. |
| AK04 | K1 (forced) | FALSIFIED-naive | Every observable symmetry lifts to a latent symmetry of the same order (Stab = Gauge x Gamma). |
| AK05 | K2 (forced) | FALSIFIED-naive | Kernel-groupoid basicness must be verified separately for every module. |
| AK06 | K3 (gated) | FALSIFIED-naive | Gauge completeness is a property of the declared groupoid alone. |
| AK07 | K4 (forced + gated) | FALSIFIED-naive | Cross-clock cocycle closure is an empirical coincidence that must be tested separately. |
| AK08 | K5 (forced) | FALSIFIED-naive | The physical unit is an external calibration step applied after the RG geometry is built. |
| AK09 | K5 (forced) | FALSIFIED-naive | 'No redshift' (G4) is an independent physical gate of the distance module. |
| AK10 | K6 (forced) | FALSIFIED-naive | Physical distance is a quantity the theory must postulate. |
| AK11 | K6 (forced) | FALSIFIED-naive | A constant isotropic chart (lambda constant) must be assumed for the Euclidean limit. |
| AK12 | K7 (forced given Gamma) | FALSIFIED-naive | Quadraticity of the observable cone is a separate realization gate (R18 vs R19/R20). |
| AK13 | K5 (forced) | FALSIFIED-naive | Scale is fixed by adding any further physical measurement. |
| AK14 | K8 (lock) | FALSIFIED-naive | Each module can be validated on its own protocol. |
| AK15 | K8 (whole-slice test) | FALSIFIED-naive | A physical slice can pass some RG modules and fail others independently. |

## Self-attack ledger
- AK13 first registered with an unjustified 1e3 noise-unit threshold; failed at 164. Re-registered at 10 noise
  units (the standard used elsewhere); counterexample unchanged. Kept visible in the paper.
- First AK12 canary NOT caught: cone boundary sampler was decoupled from the cone. Cones now derive from one norm.

## Files
- `rg_kernel_assembly_attack.py`, `rg_kernel_assembly_results.json`
- `RG_-_Assembly_at_the_Kernel.tex/.pdf` (Kernel-Stabilizer Theorem, gate collapse, Stratum 8: R45-R58)
